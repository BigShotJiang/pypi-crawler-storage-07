#!/usr/bin/python3
"""A package and CLI for WWVB timecodes

This is the full featured library suitable for use on 'real computers'.
For a reduced version suitable for use on MicroPython & CircuitPython,
see `uwwvb`.

This package also includes the commandline programs listed above,
perhaps most importantly ``wwvbgen`` for generating WWVB timecodes.
"""

# SPDX-FileCopyrightText: 2011-2024 Jeff Epler
#
# SPDX-License-Identifier: GPL-3.0-only

from __future__ import annotations

import datetime
import enum
import json
import warnings
from collections.abc import MutableSequence, Sequence
from dataclasses import dataclass
from typing import ClassVar, Literal

from . import iersdata
from .tz import Mountain

WWVBChannel = Literal["amplitude", "phase", "both"]

TYPE_CHECKING = False
if TYPE_CHECKING:
    from collections.abc import Generator
    from typing import NotRequired, Self, TextIO, TypedDict, TypeVar

    class JsonMinute(TypedDict):
        """Implementation detail

        This is the Python object type that is serialized by `print_timecodes_json`
        """

        year: int
        days: int
        hour: int
        minute: int
        amplitude: NotRequired[str]
        phase: NotRequired[str]

    T = TypeVar("T")

HOUR = datetime.timedelta(seconds=3600)
SECOND = datetime.timedelta(seconds=1)


def _date(dt: datetime.date) -> datetime.date:
    """Return the date object itself, or the date property of a datetime"""
    if isinstance(dt, datetime.datetime):
        return dt.date()
    return dt


def _maybe_warn_update(dt: datetime.date, stacklevel: int = 1) -> None:
    """Maybe print a notice to run updateiers, if it seems useful to do so."""
    # We already know this date is not covered.
    # If the date is less than 300 days after today, there should be (possibly)
    # prospective available now.
    today = datetime.datetime.now(tz=datetime.timezone.utc).date()
    if _date(dt) < today + datetime.timedelta(days=330):
        warnings.warn(
            "Note: Running `updateiers` may provide better DUT1 and LS information",
            stacklevel=stacklevel + 1,
        )


def _put_am_bcd(l: AmplitudeModulationMutableSequence | list[AmplitudeModulation], v: int, *poslist: int) -> None:
    """Insert BCD coded data into the AM signal

    The bits at ``self.am[poslist[i]]`` in MSB order are filled with
    the conversion of `v` to BCD
    Treating 'poslist' as a sequence of indices, update the AM signal with the value as a BCD number
    """
    pos = list(poslist)[::-1]
    for p, b in zip(pos, _bcd_bits(v), strict=False):
        if b:
            l[p] = AmplitudeModulation.ONE
        else:
            l[p] = AmplitudeModulation.ZERO


def _put_pm_bit(l: PhaseModulationMutableSequence, i: int, v: PhaseModulation | int) -> None:
    """Update a bit of the Phase Modulation signal"""
    l[i] = PhaseModulation(v)


def _put_pm_bin(l: PhaseModulationMutableSequence, st: int, n: int, v: int) -> None:
    """Update an n-digit binary number in the Phase Modulation signal"""
    for i in range(n):
        _put_pm_bit(l, st + i, _extract_bit(v, (n - i - 1)))


def get_dut1(dt: datetime.date, *, warn_outdated: bool = True) -> float:
    """Return the DUT1 number for the given timestamp"""
    date = _date(dt)
    i = (date - iersdata.DUT1_DATA_START).days
    if i < 0:
        v = iersdata.DUT1_OFFSETS[0]
    elif i >= len(iersdata.DUT1_OFFSETS):
        if warn_outdated:
            _maybe_warn_update(dt, stacklevel=2)
        v = iersdata.DUT1_OFFSETS[-1]
    else:
        v = iersdata.DUT1_OFFSETS[i]
    return (ord(v) - ord("k")) / 10.0


def isly(year: int) -> bool:
    """Return True if the year is a leap year"""
    d1 = datetime.date(year, 1, 1)
    d2 = d1 + datetime.timedelta(days=365)
    return d1.year == d2.year


def isls(t: datetime.date) -> bool:
    """Return True if a leap second occurs at the end of this month"""
    dut1_today = get_dut1(t)
    month_today = t.month
    while t.month == month_today:
        t += datetime.timedelta(1)
    dut1_next_month = get_dut1(t)
    return dut1_today * dut1_next_month < 0


def isdst(t: datetime.date, tz: datetime.tzinfo = Mountain) -> bool:
    """Return true if daylight saving time is active at the start of the given UTC day"""
    utc_daystart = datetime.datetime(t.year, t.month, t.day, tzinfo=datetime.timezone.utc)
    return bool(utc_daystart.astimezone(tz).dst())


def _first_sunday_on_or_after(dt: datetime.date) -> datetime.date:
    """Return the first sunday on or after the reference time"""
    days_to_go = 6 - dt.weekday()
    if days_to_go:
        return dt + datetime.timedelta(days_to_go)
    return dt


def _first_sunday_in_month(y: int, m: int) -> datetime.date:
    """Find the first sunday in a given month"""
    return _first_sunday_on_or_after(datetime.datetime(y, m, 1, tzinfo=datetime.timezone.utc))


def _is_dst_change_day(t: datetime.date, tz: datetime.tzinfo = Mountain) -> bool:
    """Return True if the day is a DST change day"""
    return isdst(t, tz) != isdst(t + datetime.timedelta(1), tz)


def _get_dst_change_hour(t: datetime.date, tz: datetime.tzinfo = Mountain) -> int | None:
    """Return the hour when DST changes"""
    lt0 = datetime.datetime(t.year, t.month, t.day, hour=0, tzinfo=tz)
    dst0 = lt0.dst()
    for i in (1, 2, 3):
        lt1 = (lt0.astimezone(datetime.timezone.utc) + HOUR * i).astimezone(tz)
        dst1 = lt1.dst()
        lt2 = lt1 - SECOND
        dst2 = lt2.dst()
        if dst0 == dst2 and dst0 != dst1:
            return i - 1
    return None


def _get_dst_change_date_and_row(
    d: datetime.date,
    tz: datetime.tzinfo = Mountain,
) -> tuple[datetime.date | None, int | None]:
    """Classify DST information for the WWVB phase modulation signal"""
    if isdst(d, tz):
        n = _first_sunday_in_month(d.year, 11)
        for offset in range(-28, 28, 7):
            d1 = n + datetime.timedelta(days=offset)
            if _is_dst_change_day(d1, tz):
                return d1, (offset + 28) // 7
    else:
        m = _first_sunday_in_month(d.year + (d.month > 3), 3)
        for offset in range(0, 52, 7):
            d1 = m + datetime.timedelta(days=offset)
            if _is_dst_change_day(d1, tz):
                return d1, offset // 7

    return None, None


# "Table 8", likely with transcrption errors
_dsttable = [
    [
        [
            0b110001,
            0b100110,
            0b100101,
            0b010101,
            0b111110,
            0b010110,
            0b110111,
            0b111101,
        ],
        [
            0b101010,
            0b011011,
            0b001110,
            0b000001,
            0b000010,
            0b001000,
            0b001101,
            0b101001,
        ],
        [
            0b000100,
            0b100000,
            0b110100,
            0b101100,
            0b111000,
            0b010000,
            0b110010,
            0b011100,
        ],
    ],
    [
        [
            0b110111,
            0b010101,
            0b110001,
            0b010110,
            0b100110,
            0b111110,
            0b100101,
            0b111101,
        ],
        [
            0b001101,
            0b000001,
            0b101010,
            0b001000,
            0b011011,
            0b000010,
            0b001110,
            0b101001,
        ],
        [
            0b110010,
            0b101100,
            0b000100,
            0b010000,
            0b100000,
            0b111000,
            0b110100,
            0b011100,
        ],
    ],
]


def _lfsr_gen(x: list[int]) -> None:
    """Generate the next bit of the 6-minute codes sequence"""
    x.append(x[-7] ^ x[-6] ^ x[-5] ^ x[-2])


_lfsr_seq = [1] * 7
while len(_lfsr_seq) < 255:
    _lfsr_gen(_lfsr_seq)

# Table 12 - Fixed 106-bit timing word
_ftw = [
    int(c)
    for c in "1101000111"
    "0101100101"
    "1001101110"
    "0011000010"
    "1101001110"
    "1001010100"
    "0010111000"
    "1011010110"
    "1101111111"
    "1000000100"
    "100100"
]


def _get_dst_next(d: datetime.date, tz: datetime.tzinfo = Mountain) -> int:
    """Find the "dst next" value for the phase modulation signal"""
    dst_now = isdst(d, tz)  # dst_on[1]
    dst_midwinter = isdst(datetime.datetime(d.year, 1, 1, tzinfo=datetime.timezone.utc), tz)
    dst_midsummer = isdst(datetime.datetime(d.year, 7, 1, tzinfo=datetime.timezone.utc), tz)

    if dst_midwinter and dst_midsummer:
        return 0b101111
    if not (dst_midwinter or dst_midsummer):
        return 0b000111

    # Southern hemisphere
    if dst_midwinter or not dst_midsummer:
        return 0b100011

    dst_change_date, dst_next_row = _get_dst_change_date_and_row(d, tz)
    if dst_change_date is None:
        return 0b100011
    assert dst_next_row is not None

    dst_change_hour = _get_dst_change_hour(dst_change_date, tz)
    if dst_change_hour is None:
        return 0b100011

    return _dsttable[dst_now][dst_change_hour][dst_next_row]


_hamming_weight = [
    [23, 21, 20, 17, 16, 15, 14, 13, 9, 8, 6, 5, 4, 2, 0],
    [24, 22, 21, 18, 17, 16, 15, 14, 10, 9, 7, 6, 5, 3, 1],
    [25, 23, 22, 19, 18, 17, 16, 15, 11, 10, 8, 7, 6, 4, 2],
    [24, 21, 19, 18, 15, 14, 13, 12, 11, 7, 6, 4, 3, 2, 0],
    [25, 22, 20, 19, 16, 15, 14, 13, 12, 8, 7, 5, 4, 3, 1],
]

# Identifies the phase data as a time signal (SYNC_T bits present)
# or a message signal (SYNC_M bits present); No message signals are defined
# by NIST at this time.
SYNC_T = 0x768
SYNC_M = 0x1A3A


def _extract_bit(v: int, p: int) -> bool:
    """Extract bit 'p' from integer 'v' as a bool"""
    return bool((v >> p) & 1)


def _hamming_parity(value: int) -> int:
    """Compute the "hamming parity" of a 26-bit number, such as the minute-of-century

    For more details, see Enhanced WWVB Broadcast Format 4.3
    """
    parity = 0
    for i in range(4, -1, -1):
        bit = 0
        for j in range(15):
            bit ^= _extract_bit(value, _hamming_weight[i][j])
        parity = (parity << 1) | bit
    return parity


_dst_ls_lut = [
    0b01000,
    0b10101,
    0b10110,
    0b00011,
    0b01000,
    0b10101,
    0b10110,
    0b00011,
    0b00100,
    0b01110,
    0b10000,
    0b01101,
    0b11001,
    0b11100,
    0b11010,
    0b11111,
]


@enum.unique
class DstStatus(enum.IntEnum):
    """Constants that describe the DST status of a minute"""

    DST_NOT_IN_EFFECT = 0b00
    """DST not in effect today"""
    DST_STARTS_TODAY = 0b01
    """DST starts today at 0200 local standard time"""
    DST_ENDS_TODAY = 0b10
    """DST ends today at 0200 local standard time"""
    DST_IN_EFFECT = 0b11
    """DST in effect all day today"""


@dataclass(frozen=True)
class WWVBMinute:
    """Uniquely identifies a minute of time in the WWVB system.

    To use ``ut1`` and ``ls`` information from IERS, create a `WWVBMinuteIERS`
    object instead.
    """

    year: int
    """2-digit year within the WWVB epoch"""

    days: int
    """1-based day of year"""

    hour: int
    """UTC hour of day"""

    minute: int
    """Minute of hour"""

    dst: DstStatus
    """2-bit DST code """

    ut1: int
    """UT1 offset in units of 100ms, range -900 to +900ms"""

    ls: bool
    """Leap second warning flag"""

    ly: bool
    """Leap year flag"""

    epoch: ClassVar[int] = 1970

    def __init__(
        self,
        year: int,
        days: int,
        hour: int,
        minute: int,
        dst: DstStatus | int | None = None,
        ut1: int | None = None,
        *,
        ls: bool | None = None,
        ly: bool | None = None,
    ) -> None:
        """Construct a WWVBMinute

        :param year: The 2- or 4-digit year. This parameter is converted by the `full_year` method.
        :param days: 1-based day of year

        :param hour: UTC hour of day

        :param minute: Minute of hour
        :param dst: 2-bit DST code
        :param ut1: UT1 offset in units of 100ms, range -900 to +900ms
        :param ls: Leap second warning flag
        :param ly: Leap year flag
        """
        dst = self.get_dst(year, days) if dst is None else DstStatus(dst)
        if ut1 is None and ls is None:
            ut1, ls = self._get_dut1_info(year, days)
        elif ut1 is None or ls is None:
            raise ValueError("sepecify both ut1 and ls or neither one")
        year = self.full_year(year)
        if ly is None:
            ly = isly(year)

        super().__setattr__("year", year)
        super().__setattr__("days", days)
        super().__setattr__("hour", hour)
        super().__setattr__("minute", minute)
        super().__setattr__("dst", dst)
        super().__setattr__("ut1", ut1)
        super().__setattr__("ls", ls)
        super().__setattr__("ly", ly)

    @classmethod
    def full_year(cls, year: int) -> int:
        """Convert a (possibly two-digit) year to a full year.

        If the argument is above 100, it is assumed to be a full year.
        Otherwise, the intuitive method is followed: Say the epoch is 1970,
        then 70..99 means 1970..99 and 00..69 means 2000..2069.

        To actually use a different epoch, derive a class from WWVBMinute (or
        WWVBMinuteIERS) and give it a different epoch property.  Then, create
        instances of that class instead of WWVBMinute.
        """
        century = cls.epoch // 100 * 100
        if year < (cls.epoch % 100):
            return year + century + 100
        if year < 100:
            return year + century
        return year

    @staticmethod
    def get_dst(year: int, days: int) -> DstStatus:
        """Get the 2-bit WWVB DST value for the given day"""
        d0 = datetime.datetime(year, 1, 1, tzinfo=datetime.timezone.utc) + datetime.timedelta(days - 1)
        d1 = d0 + datetime.timedelta(1)
        dst0 = isdst(d0)
        dst1 = isdst(d1)
        return DstStatus(dst1 * 2 + dst0)

    def __str__(self) -> str:
        """Implement str()"""
        return (
            f"year={self.year:4d} days={self.days:03d} hour={self.hour:02d} "
            f"min={self.minute:02d} dst={self.dst} ut1={self.ut1} ly={int(self.ly)} "
            f"ls={int(self.ls)}"
        )

    def as_datetime_utc(self) -> datetime.datetime:
        """Convert to a UTC datetime

        The returned object has ``tzinfo=datetime.timezone.utc``.
        """
        d = datetime.datetime(self.year, 1, 1, tzinfo=datetime.timezone.utc)
        d += datetime.timedelta(self.days - 1, self.hour * 3600 + self.minute * 60)
        return d

    as_datetime = as_datetime_utc

    def as_datetime_local(
        self,
        standard_time_offset: int = 7 * 3600,
        *,
        dst_observed: bool = True,
    ) -> datetime.datetime:
        """Convert to a local datetime according to the DST bits

        The returned object has ``tz=datetime.timezone(computed_offset)``.

        :param standard_time_offset: The UTC offset of local standard time, in seconds west of UTC.
            The default value, ``7 * 3600``, is for Colorado, the source of the WWVB broadcast.

        :param dst_observed: If ``True`` then the locale observes DST, and a
            one hour offset is applied according to WWVB rules. If ``False``, then
            the standard time offset is used at all times.

        """
        u = self.as_datetime_utc()
        offset = datetime.timedelta(seconds=-standard_time_offset)
        d = u - datetime.timedelta(seconds=standard_time_offset)
        if not dst_observed:
            dst = False
        elif self.dst == 0b10:
            transition_time = u.replace(hour=2)
            dst = d >= transition_time
        elif self.dst == 0b11:
            dst = True
        elif self.dst == 0b01:
            transition_time = u.replace(hour=1)
            dst = d < transition_time
        else:  # self.dst == 0b00
            dst = False
        if dst:
            offset += datetime.timedelta(seconds=3600)
        return u.astimezone(datetime.timezone(offset))

    def _is_end_of_month(self) -> bool:
        """Return True if minute is the last minute in a month"""
        d = self.as_datetime()
        e = d + datetime.timedelta(1)
        return d.month != e.month

    def minute_length(self) -> int:
        """Return the length of the minute, 60, 61, or (theoretically) 59 seconds"""
        if not self.ls:
            return 60
        if not self._is_end_of_month():
            return 60
        if self.hour != 23 or self.minute != 59:
            return 60
        if self.ut1 > 0:
            return 59
        return 61

    def as_timecode(self) -> WWVBTimecode:
        """Fill a WWVBTimecode structure representing this minute.  Fills both the amplitude and phase codes."""
        return WWVBTimecode(self.am_timecode, self.pm_timecode)

    def as_timecode_am(self) -> WWVBTimecodeAM:
        """Fill a WWVBTimecodeAM structure representing this minute."""
        return WWVBTimecodeAM(self.am_timecode)

    def as_timecode_pm(self) -> WWVBTimecodePhase:
        """Fill a WWVBTimecodePM structure representing this minute."""
        return WWVBTimecodePhase(self.pm_timecode)

    @property
    def _leap_sec(self) -> int:
        """Return the 2-bit _leap_sec value used by the PM code"""
        if not self.ls:
            return 0
        if self.ut1 < 0:
            return 3
        return 2

    @property
    def minute_of_century(self) -> int:
        """Return the minute of the century"""
        century = (self.year // 100) * 100
        # note: This relies on timedelta seconds never including leapseconds!
        return (
            int((self.as_datetime() - datetime.datetime(century, 1, 1, tzinfo=datetime.timezone.utc)).total_seconds())
            // 60
        )

    @property
    def am_timecode(self) -> AmplitudeModulationSequence:
        """Fill the amplitude (AM) portion of a timecode object"""
        result: list[AmplitudeModulation | None] = [None] * self.minute_length()
        for i in [0, 9, 19, 29, 39, 49]:
            result[i] = AmplitudeModulation.MARK
        if len(result) > 59:
            result[59] = AmplitudeModulation.MARK
        if len(result) > 60:
            result[60] = AmplitudeModulation.MARK
        for i in [4, 10, 11, 14, 20, 21, 24, 34, 35, 44, 54]:
            result[i] = AmplitudeModulation.ZERO
        _put_am_bcd(result, self.minute, 1, 2, 3, 5, 6, 7, 8)
        _put_am_bcd(result, self.hour, 12, 13, 15, 16, 17, 18)
        _put_am_bcd(result, self.days, 22, 23, 25, 26, 27, 28, 30, 31, 32, 33)
        ut1_sign = self.ut1 >= 0
        result[36] = result[38] = AmplitudeModulation(ut1_sign)
        result[37] = AmplitudeModulation(not ut1_sign)
        _put_am_bcd(result, abs(self.ut1) // 100, 40, 41, 42, 43)
        _put_am_bcd(
            result, self.year, 45, 46, 47, 48, 50, 51, 52, 53
        )  # Implicitly discards all but lowest 2 digits of year
        result[55] = AmplitudeModulation(self.ly)
        result[56] = AmplitudeModulation(self.ls)
        _put_am_bcd(result, self.dst, 57, 58)
        return tuple(_require_not_none(i) for i in result)

    def _fill_pm_timecode_extended(self, result: PhaseModulationMutableSequence) -> None:
        """During minutes 10..15 and 40..45, the amplitude signal holds 'extended information'"""
        assert 10 <= self.minute < 16 or 40 <= self.minute < 46
        minno = self.minute % 10
        assert minno < 6
        # Cannot be a leap minute
        assert len(result) == 60

        dst = self.dst
        # Note that these are 1 different than Table 11
        # because our LFSR sequence is zero-based
        seqno = (self.minute // 30) * 2
        if dst == 0:
            pass
        elif dst == 3:
            seqno = seqno + 1
        elif dst == 2:
            if self.hour < 4:
                pass
            elif self.hour < 11:
                seqno = seqno + 90
            else:
                seqno = seqno + 1
        elif self.hour < 4:
            seqno = seqno + 1
        elif self.hour < 11:
            seqno = seqno + 91

        info_seq = _lfsr_seq[seqno : seqno + 127]
        full_seq = info_seq + _ftw + info_seq[::-1]
        assert len(full_seq) == 360

        offset = minno * 60
        for i in range(60):
            _put_pm_bit(result, i, full_seq[i + offset])

    def _fill_pm_timecode_regular(self, result: PhaseModulationMutableSequence) -> None:  # noqa: PLR0915
        """Except during minutes 10..15 and 40..45, the amplitude signal holds 'regular information'"""
        _put_pm_bin(result, 0, 13, SYNC_T)
        # Cannot be a leap minute
        assert 59 <= len(result) <= 61

        moc = self.minute_of_century
        _leap_sec = self._leap_sec
        dst_on = self.dst
        dst_ls = _dst_ls_lut[dst_on | (_leap_sec << 2)]
        dst_next = _get_dst_next(self.as_datetime())
        _put_pm_bin(result, 13, 5, _hamming_parity(moc))
        _put_pm_bit(result, 18, _extract_bit(moc, 25))
        _put_pm_bit(result, 19, _extract_bit(moc, 0))
        _put_pm_bit(result, 20, _extract_bit(moc, 24))
        _put_pm_bit(result, 21, _extract_bit(moc, 23))
        _put_pm_bit(result, 22, _extract_bit(moc, 22))
        _put_pm_bit(result, 23, _extract_bit(moc, 21))
        _put_pm_bit(result, 24, _extract_bit(moc, 20))
        _put_pm_bit(result, 25, _extract_bit(moc, 19))
        _put_pm_bit(result, 26, _extract_bit(moc, 18))
        _put_pm_bit(result, 27, _extract_bit(moc, 17))
        _put_pm_bit(result, 28, _extract_bit(moc, 16))
        _put_pm_bit(result, 29, False)  # noqa: FBT003 # Reserved
        _put_pm_bit(result, 30, _extract_bit(moc, 15))
        _put_pm_bit(result, 31, _extract_bit(moc, 14))
        _put_pm_bit(result, 32, _extract_bit(moc, 13))
        _put_pm_bit(result, 33, _extract_bit(moc, 12))
        _put_pm_bit(result, 34, _extract_bit(moc, 11))
        _put_pm_bit(result, 35, _extract_bit(moc, 10))
        _put_pm_bit(result, 36, _extract_bit(moc, 9))
        _put_pm_bit(result, 37, _extract_bit(moc, 8))
        _put_pm_bit(result, 38, _extract_bit(moc, 7))
        _put_pm_bit(result, 39, True)  # noqa: FBT003 # Reserved
        _put_pm_bit(result, 40, _extract_bit(moc, 6))
        _put_pm_bit(result, 41, _extract_bit(moc, 5))
        _put_pm_bit(result, 42, _extract_bit(moc, 4))
        _put_pm_bit(result, 43, _extract_bit(moc, 3))
        _put_pm_bit(result, 44, _extract_bit(moc, 2))
        _put_pm_bit(result, 45, _extract_bit(moc, 1))
        _put_pm_bit(result, 46, _extract_bit(moc, 0))
        _put_pm_bit(result, 47, _extract_bit(dst_ls, 4))
        _put_pm_bit(result, 48, _extract_bit(dst_ls, 3))
        _put_pm_bit(result, 49, True)  # noqa: FBT003 # Notice
        _put_pm_bit(result, 50, _extract_bit(dst_ls, 2))
        _put_pm_bit(result, 51, _extract_bit(dst_ls, 1))
        _put_pm_bit(result, 52, _extract_bit(dst_ls, 0))
        _put_pm_bit(result, 53, _extract_bit(dst_next, 5))
        _put_pm_bit(result, 54, _extract_bit(dst_next, 4))
        _put_pm_bit(result, 55, _extract_bit(dst_next, 3))
        _put_pm_bit(result, 56, _extract_bit(dst_next, 2))
        _put_pm_bit(result, 57, _extract_bit(dst_next, 1))
        _put_pm_bit(result, 58, _extract_bit(dst_next, 0))
        if len(result) > 59:
            _put_pm_bit(result, 59, PhaseModulation.ZERO)
        if len(result) > 60:
            _put_pm_bit(result, 60, PhaseModulation.ZERO)

    @property
    def pm_timecode(self) -> PhaseModulationSequence:
        """Fill the phase portion of a timecode object"""
        result: list[PhaseModulation | None] = [None] * self.minute_length()
        if 10 <= self.minute < 16 or 40 <= self.minute < 46:
            self._fill_pm_timecode_extended(result)
        else:
            self._fill_pm_timecode_regular(result)
        return tuple(_require_not_none(i) for i in result)

    def next_minute(self, *, newut1: int | None = None, newls: bool | None = None) -> Self:
        """Return an object representing the next minute"""
        d = self.as_datetime() + datetime.timedelta(minutes=1)
        return self.from_datetime(d, newut1=newut1, newls=newls, old_time=self)

    def previous_minute(self, *, newut1: int | None = None, newls: bool | None = None) -> Self:
        """Return an object representing the previous minute"""
        d = self.as_datetime() - datetime.timedelta(minutes=1)
        return self.from_datetime(d, newut1=newut1, newls=newls, old_time=self)

    @classmethod
    def _get_dut1_info(cls: type, year: int, days: int, old_time: WWVBMinute | None = None) -> tuple[int, bool]:  # noqa: ARG003
        """Return the DUT1 information for a given day, possibly propagating information from a previous timestamp"""
        if old_time is not None:
            if old_time.minute_length() != 60:
                newls = False
                newut1 = old_time.ut1 + 1000 if old_time.ut1 < 0 else old_time.ut1 - 1000
            else:
                newls = old_time.ls
                newut1 = old_time.ut1
            return newut1, newls
        return 0, False

    @classmethod
    def fromstring(cls, s: str) -> Self:
        """Construct a WWVBMinute from a string representation created by print_timecodes"""
        s = s.removeprefix("WWVB timecode: ")
        d: dict[str, int] = {}
        for part in s.split():
            k, v = part.split("=")
            if k == "min":
                k = "minute"
            d[k] = int(v)
        year = d.pop("year")
        days = d.pop("days")
        hour = d.pop("hour")
        minute = d.pop("minute")
        dst = d.pop("dst", None)
        ut1 = d.pop("ut1", None)
        ls = d.pop("ls", None)
        d.pop("ly", None)  # Always use calculated ly flag
        if d:
            raise ValueError(f"Invalid options: {d}")
        return cls(year, days, hour, minute, dst, ut1=ut1, ls=None if ls is None else bool(ls))

    @classmethod
    def from_datetime(
        cls,
        d: datetime.datetime,
        *,
        newut1: int | None = None,
        newls: bool | None = None,
        old_time: WWVBMinute | None = None,
    ) -> Self:
        """Construct a WWVBMinute from a datetime, possibly specifying ut1/ls data or propagating it from an old time"""
        u = d.utctimetuple()
        if newls is None and newut1 is None:
            newut1, newls = cls._get_dut1_info(u.tm_year, u.tm_yday, old_time)
        return cls(u.tm_year, u.tm_yday, u.tm_hour, u.tm_min, ut1=newut1, ls=newls)

    @classmethod
    def from_timecode_am(cls, t: WWVBTimecodeAM) -> Self | None:  # noqa: PLR0912
        """Construct a WWVBMinute from a WWVBTimecode"""
        for i in (0, 9, 19, 29, 39, 49, 59):
            if t.am[i] != AmplitudeModulation.MARK:
                return None
        for i in (4, 10, 11, 14, 20, 21, 24, 34, 35, 44, 54):
            if t.am[i] != AmplitudeModulation.ZERO:
                return None
        if t.am[36] == t.am[37]:
            return None
        if t.am[36] != t.am[38]:
            return None
        minute = _get_am_bcd(t.am, 1, 2, 3, 5, 6, 7, 8)
        if minute is None:
            return None
        if minute >= 60:
            return None
        hour = _get_am_bcd(t.am, 12, 13, 15, 16, 17, 18)
        if hour is None:
            return None
        if hour >= 24:
            return None
        days = _get_am_bcd(t.am, 22, 23, 25, 26, 27, 28, 30, 31, 32, 33)
        if days is None:
            return None
        abs_ut1 = _get_am_bcd(t.am, 40, 41, 42, 43)
        if abs_ut1 is None:
            return None
        abs_ut1 *= 100
        ut1_sign = t.am[38]
        ut1 = abs_ut1 if ut1_sign else -abs_ut1
        year = _get_am_bcd(t.am, 45, 46, 47, 48, 50, 51, 52, 53)
        if year is None:
            return None
        ly = bool(t.am[55])
        if days > 366 or (not ly and days > 365):
            return None
        ls = bool(t.am[56])
        dst = _get_am_bcd(t.am, 57, 58)
        if dst is None:
            return None
        return cls(year, days, hour, minute, dst, ut1, ls=ls, ly=ly)

    @property
    def min(self) -> int:
        """Deprecated alias for `WWVBMinute.minute`

        Update your code to use the `minute` property instead of the `min` property.
        """
        warnings.warn("WWVBMinute.min property is deprecated", category=DeprecationWarning, stacklevel=1)
        return self.minute


class WWVBMinuteIERS(WWVBMinute):
    """A WWVBMinute that uses a database of DUT1 information"""

    @classmethod
    def _get_dut1_info(cls, year: int, days: int, old_time: WWVBMinute | None = None) -> tuple[int, bool]:  # noqa: ARG003
        d = datetime.datetime(year, 1, 1, tzinfo=datetime.timezone.utc) + datetime.timedelta(days - 1)
        return round(get_dut1(d) * 10) * 100, isls(d)


def _bcd_bits(n: int) -> Generator[bool]:
    """Return the (infinite) bcd representation of n, starting with the least significant bit

    This continues to yield `False` forever after the nonzero bcd digits have been genrated.
    This allows to `zip(strict=False)` the resulting bits together with a sequence of indices
    and ensure all the upper bits are set to zero.
    """
    while True:
        d = n % 10
        n = n // 10
        for i in (1, 2, 4, 8):
            yield bool(d & i)


@enum.unique
class AmplitudeModulation(enum.IntEnum):
    """Constants that describe an Amplitude Modulation value"""

    ZERO = 0
    """A zero bit (reduced carrier during the first 200ms of the second)"""
    ONE = 1
    """A one bit (reduced carrier during the first 500ms of the second)"""
    MARK = 2
    """A mark bit (reduced carrier during the first 800ms of the second)"""


AmplitudeModulationSequence = Sequence[AmplitudeModulation]
AmplitudeModulationMutableSequence = MutableSequence[AmplitudeModulation | None]


def _require_not_none(val: T | None) -> T:
    if val is None:
        raise ValueError("Value may not be None")
    return val


@enum.unique
class PhaseModulation(enum.IntEnum):
    """Constants that describe a Phase Modulation value"""

    ZERO = 0
    """A one bit (180° phase shift during the second)"""
    ONE = 1
    """A zero bit (No phase shift during the second)"""


PhaseModulationSequence = Sequence[PhaseModulation]
PhaseModulationMutableSequence = MutableSequence[PhaseModulation | None]


def _get_am_bcd(am: AmplitudeModulationSequence, *poslist: int) -> int | None:
    """Convert AM data to BCD

    The the bits ``am[poslist[i]]`` in MSB order are converted from
    BCD to integer
    """
    pos = list(poslist)[::-1]
    for p in pos:
        if am[p] not in {AmplitudeModulation.ZERO, AmplitudeModulation.ONE}:
            return None
    val = [bool(am[p]) for p in pos]
    result = 0
    base = 1
    for i in range(0, len(val), 4):
        digit = 0
        for j, b in enumerate(val[i : i + 4]):
            digit += b << j
        if digit > 9:
            return None
        result += digit * base
        base *= 10
    return result


@dataclass(frozen=True)
class WWVBTimecodeAM:
    """Represent the WWVB amplitude signal (only), usually over 1 minute"""

    am: AmplitudeModulationSequence
    """The amplitude modulation data"""

    def __str__(self) -> str:
        """Implement str()"""
        return self.to_am_string("012")

    def __repr__(self) -> str:
        """Implement repr()"""
        return f"<{type(self).__name__} {self}>"

    def to_am_string(self, charset: Sequence[str] | str) -> str:
        """Convert the amplitude signal to a string"""
        return "".join(charset[i] for i in self.am)

    to_string = to_am_string


@dataclass(frozen=True)
class WWVBTimecodePhase:
    """Represent the WWVB phase signal, usually over 1 minute"""

    phase: PhaseModulationSequence
    """The phase modulation data"""

    def __str__(self) -> str:
        """Implement str()"""
        return self.to_pm_string("v^")

    def __repr__(self) -> str:
        """Implement repr()"""
        return f"<{type(self).__name__} {self}>"

    def to_pm_string(self, charset: Sequence[str] | str) -> str:
        """Convert the phase signal to a string"""
        return "".join(charset[i] for i in self.phase)


@dataclass(frozen=True)
class WWVBTimecode(WWVBTimecodePhase, WWVBTimecodeAM):
    """Represent the WWVB amplitude and phase signal, usually over 1 minute"""

    def __str__(self) -> str:
        """Implement str()"""
        return self.to_both_string(styles["supsub"])

    def to_both_string(self, charset: Sequence[str] | str) -> str:
        """Convert both channels to a string"""
        return "".join(charset[i + j * 3] for i, j in zip(self.am, self.phase, strict=True))


styles = {
    "default": ["0", "1", "2"],
    "duration": ["2", "5", "8"],
    "cradek": ["0", "1", "-"],
    "bar": ["🬍🬎", "🬋🬎", "🬋🬍"],
    "sextant": ["🬍🬎", "🬋🬎", "🬋🬍", "🬩🬹", "🬋🬹", "🬋🬩"],
    "supsub": "₀₁₂⁰¹²",
}


def print_timecodes(
    w: WWVBMinute,
    minutes: int,
    channel: WWVBChannel,
    style: str,
    file: TextIO,
    *,
    all_timecodes: bool = False,
) -> None:
    """Print a range of timecodes with a header.  This header is in a format understood by WWVBMinute.fromstring"""
    channel_text = "" if channel == "amplitude" else f" --channel={channel}"
    style_text = "" if style == "default" else f" --style={style}"
    style_chars = styles.get(style, ["0", "1", "2"])
    first = True
    for _ in range(minutes):
        if not first and channel == "both":
            print(file=file)
        if first or all_timecodes:
            if not first:
                print(file=file)
            print(f"WWVB timecode: {w!s}{channel_text}{style_text}", file=file)
        first = False
        pfx = f"{w.year:04d}-{w.days:03d} {w.hour:02d}:{w.minute:02d} "
        tc = w.as_timecode()
        if len(style_chars) == 6:
            print(f"{pfx} {tc.to_both_string(style_chars)}", file=file)
            print(file=file)
            pfx = " " * len(pfx)
        else:
            if channel in ("amplitude", "both"):
                print(f"{pfx} {tc.to_am_string(style_chars)}", file=file)
                pfx = " " * len(pfx)
            if channel in ("phase", "both"):
                print(f"{pfx} {tc.to_pm_string(style_chars)}", file=file)
        w = w.next_minute()


def print_timecodes_json(
    w: WWVBMinute,
    minutes: int,
    channel: WWVBChannel,
    file: TextIO,
) -> None:
    """Print a range of timecodes in JSON format.

    The result is a json array of minute data. Each minute data is an object with the following members:

        * year (int)
        * days (int)
        * hour (int)
        * minute (int)
        * amplitude (string; only if channel is amplitude or both)
        * phase: (string; only if channel is phase or both)

    The amplitude and phase strings are of length 60 during most minutes, length 61
    during a minute that includes a (positive) leap second, and theoretically
    length 59 in the case of a negative leap second.
    """
    result = []
    for _ in range(minutes):
        data: JsonMinute = {
            "year": w.year,
            "days": w.days,
            "hour": w.hour,
            "minute": w.minute,
        }

        tc = w.as_timecode()
        if channel in ("amplitude", "both"):
            data["amplitude"] = tc.to_am_string(["0", "1", "2"])
        if channel in ("phase", "both"):
            data["phase"] = tc.to_pm_string(["0", "1"])

        result.append(data)
        w = w.next_minute()
    json.dump(result, file)
    print(file=file)
