import time
from .base_model import BaseRequst, BaseResponse, ApiRegistry


def register_api(api_name: str, handler):
    pass


def invoke_server_api(api_name: str, request: BaseRequst):
    handler = ApiRegistry.mappings[api_name]
    # TODO 签名验证
    time.time()

    return handler(request)