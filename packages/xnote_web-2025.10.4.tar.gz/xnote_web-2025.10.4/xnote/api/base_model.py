
class BaseRequst:
    timestamp = 0
    signature = ""
    content = ""

class BaseResponse:
    pass


class ApiRegistry:
    mappings = {}
