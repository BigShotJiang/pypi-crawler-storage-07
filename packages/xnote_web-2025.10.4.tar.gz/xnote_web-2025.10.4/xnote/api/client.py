import time
from .base_model import BaseRequst, ApiRegistry


def invoke_api(api_name: str, request: BaseRequst):
    handler = ApiRegistry.mappings[api_name]
    # TODO 签名验证
    time.time

    return handler(request)


