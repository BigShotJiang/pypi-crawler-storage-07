str1 = '这是一个测试项目，测试成功。'
print(str1)