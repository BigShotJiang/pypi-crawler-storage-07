"""This subpackage implements the graphical user interface."""

from .app import run
