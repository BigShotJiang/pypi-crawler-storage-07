import math

# Probability for each rarity
probabilities = {
    "common": 0.64,
    "unusual": 0.32,
    "rare": 0.16,
    "epic": 0.08,
    "legendary": 0.04,
    "mythic": 0.02,
    "ultra": 0.01,
    "super": 0.005  # Extra rarity after ultra
}

# Order of rarities
rarity_order = [
    "common", "unusual", "rare", "epic", "legendary", "mythic", "ultra", "super"
]

def expected_successes(petals: int, chance: float) -> float:
    """
    Calculate the average successes based on petals and chance.
    """
    if petals < 5:
        return 0.0
    return (petals - 2.5 * (1 - chance)) / ((2.5 / chance) + 2.5)

def craft(rarity: str, petals: int) -> tuple[float, str]:
    """
    Calculate how many petals of the next rarity you get on average.
    """
    rarity = rarity.lower()
    if rarity not in rarity_order:
        raise ValueError(f"Unknown rarity: {rarity}")

    index = rarity_order.index(rarity)
    if index + 1 >= len(rarity_order):
        raise ValueError(f"{rarity} cannot be crafted into a higher rarity.")

    next_rarity = rarity_order[index + 1]
    chance = probabilities.get(rarity)
    if chance is None:
        raise ValueError(f"Probability for rarity {rarity} not found.")

    return expected_successes(petals, chance), next_rarity
