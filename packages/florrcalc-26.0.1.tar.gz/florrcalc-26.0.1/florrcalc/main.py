from functions import craft

def main():
    command = input(">>> ").strip().lower().split()

    if len(command) != 2 or command[0] != "craft":
        print("Usage: craft [rarity]")
        return

    rarity = command[1]
    try:
        petals = int(input(f"Number of {rarity} petals: "))
    except ValueError:
        print("Invalid number for petals.")
        return

    try:
        result, next_rarity = craft(rarity, petals)
        print(f"With {petals} {rarity} petals you will craft approximately {result:.2f} {next_rarity} petals.")
    except ValueError as e:
        print(e)

if __name__ == "__main__":
    main()
