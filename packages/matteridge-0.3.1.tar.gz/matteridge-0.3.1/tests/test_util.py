import pytest

from matteridge.util import ensure_newline_after_quote

INS = []
OUTS = []

INS.append("""> some quoted stuff
> more
blabla
""")
OUTS.append("""> some quoted stuff
> more

blabla
""")

INS.append("""> some quoted stuff
> more

blabla
""")
OUTS.append("""> some quoted stuff
> more

blabla
""")

INS.append("""> some quoted stuff
> more
blabla

> more quote
> more
reply
""")
OUTS.append("""> some quoted stuff
> more

blabla

> more quote
> more

reply
""")

INS.append("""> some quoted stuff
> more

blabla

> more quote
> more
reply
""")
OUTS.append("""> some quoted stuff
> more

blabla

> more quote
> more

reply
""")


@pytest.mark.parametrize("in_,out", zip(INS, OUTS))
def test_add_newlines_after_quote(in_, out):
    assert ensure_newline_after_quote(in_) == out
