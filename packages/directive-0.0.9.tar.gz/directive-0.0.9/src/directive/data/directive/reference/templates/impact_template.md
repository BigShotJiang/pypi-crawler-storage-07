# Impact Analysis — <Feature Name>

## Modules/packages likely touched
-  

## Contracts to update (APIs, events, schemas, migrations)
-  

## Risks
- Security:  
- Performance/Availability:  
- Data integrity:  

## Observability needs
- Logs:  
- Metrics:  
- Alerts:
