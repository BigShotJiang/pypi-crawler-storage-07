# do imports here so I can do a single line import
from pathlib import Path
from textwrap import dedent
import math
import random
import time
from copy import copy, deepcopy
from math import floor, ceil, inf

from ursina.window import instance as window
from ursina.camera import instance as camera
from ursina.mouse import instance as mouse
from ursina.scene import instance as scene
from ursina.main import Ursina
from panda3d.core import Mat3, Mat4
from ursina.ursinamath import *
from ursina.destroy import destroy
from ursina.ursinastuff import *
from ursina.array_tools import *
from ursina import input_handler
from ursina.input_handler import held_keys, Keys
from ursina.string_utilities import *
from ursina.mesh_importer import load_model, load_blender_scene
from ursina.texture import Texture
from ursina.texture_importer import load_texture
from ursina import color
from ursina.color import Color, hsv, rgb
from ursina.sequence import Sequence, Func, Wait
from ursina import curve
from ursina.entity import Entity
from ursina.collider import *
from ursina.raycast import raycast
from ursina.boxcast import boxcast
from ursina.audio import Audio
from ursina import music_system
from ursina.duplicate import duplicate
from panda3d.core import Quat
from ursina.vec2 import Vec2
from ursina.vec3 import Vec3
from ursina.vec4 import Vec4
from ursina.shader import Shader
from ursina.lights import *

from ursina.text import Text
from ursina.mesh import Mesh, MeshModes
from ursina.models.procedural.nine_slice import NineSlice

from ursina.prefabs.sprite import Sprite
from ursina.prefabs.button import Button
from ursina.prefabs.panel import Panel
from ursina.prefabs.sprite_sheet_animation import SpriteSheetAnimation
from ursina.prefabs.animation import Animation
from ursina.prefabs.frame_animation_3d import FrameAnimation3d
from ursina.prefabs.animator import Animator
from ursina.prefabs.sky import Sky
from ursina.prefabs.cursor import Cursor

from ursina.models.procedural.quad import Quad
from ursina.models.procedural.plane import Plane
from ursina.models.procedural.circle import Circle
from ursina.models.procedural.pipe import Pipe
from ursina.models.procedural.cone import Cone
from ursina.models.procedural.cube import Cube
from ursina.models.procedural.cylinder import Cylinder
from ursina.models.procedural.capsule import Capsule
from ursina.models.procedural.grid import Grid
from ursina.models.procedural.terrain import Terrain

from ursina.terraincast import terraincast
from ursina.scripts.smooth_follow import SmoothFollow
from ursina.scripts.grid_layout import grid_layout
from ursina.scripts.scrollable import Scrollable
from ursina.scripts.property_generator import generate_properties_for_class
from ursina.scripts.every_decorator import every

from ursina.prefabs.tooltip import Tooltip
from ursina.prefabs.text_field import TextField
from ursina.prefabs.input_field import InputField, ContentTypes
from ursina.prefabs.draggable import Draggable
from ursina.prefabs.slider import Slider, ThinSlider
from ursina.prefabs.button_group import ButtonGroup
from ursina.prefabs.window_panel import WindowPanel, Space
from ursina.prefabs.button_list import ButtonList
from ursina.prefabs.checkbox import Checkbox
# from ursina.prefabs.file_browser import FileBrowser
# from ursina.prefabs import primitives

# from ursina.prefabs.debug_menu import DebugMenu
from ursina.prefabs.editor_camera import EditorCamera
# from ursina.prefabs.hot_reloader import HotReloader
