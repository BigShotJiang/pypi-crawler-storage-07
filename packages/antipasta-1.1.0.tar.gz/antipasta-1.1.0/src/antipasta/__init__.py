"""antipasta: A code quality enforcement tool that analyzes code complexity metrics."""

from antipasta.__version__ import __version__, __version_info__

__all__ = ["__version__", "__version_info__"]
