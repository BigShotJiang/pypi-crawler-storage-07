"""Configuration generation module."""

from .main import generate

__all__ = ["generate"]
