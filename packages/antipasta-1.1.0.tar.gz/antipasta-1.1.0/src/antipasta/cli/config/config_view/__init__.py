"""Configuration view command module."""

from .main import view

__all__ = ["view"]
