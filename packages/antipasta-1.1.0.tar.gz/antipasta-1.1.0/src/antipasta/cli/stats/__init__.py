"""Statistics command for code metrics analysis."""

from .command import stats

__all__ = ["stats"]
