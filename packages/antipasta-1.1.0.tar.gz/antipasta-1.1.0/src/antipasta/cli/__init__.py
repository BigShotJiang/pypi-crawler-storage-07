"""CLI module for antipasta."""

from antipasta.cli.main import main

__all__ = ["main"]
