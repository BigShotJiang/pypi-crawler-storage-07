Validators
==========

The ``otter.validators`` package contains tools for validation of tasks, and some
built-in validators.


Module contents
---------------

.. automodule:: otter.validators
   :members:
   :undoc-members:
   :show-inheritance:

validators.file module
----------------------

.. automodule:: otter.validators.file
   :members:
   :undoc-members:
   :show-inheritance:
