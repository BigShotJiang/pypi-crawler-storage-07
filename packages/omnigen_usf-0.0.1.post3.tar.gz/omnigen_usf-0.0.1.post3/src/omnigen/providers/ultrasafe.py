"""Ultrasafe AI provider implementation."""

import time
from typing import List, Dict, Optional, Any
from openai import OpenAI
from omnigen.core.base import BaseLLMProvider
from omnigen.core.types import Message
from omnigen.core.exceptions import ProviderError, APIError, RateLimitError, AuthenticationError


class UltrasafeProvider(BaseLLMProvider):
    """
    Ultrasafe AI provider using OpenAI-compatible API.
    
    Default provider for OmniGen with base URL https://api.us.inc
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize Ultrasafe provider.
        
        Args:
            config: Provider configuration
        """
        super().__init__(config)
        
        self.api_key = config.get('api_key')
        self.base_url = config.get('base_url', 'https://api.us.inc')
        self.model = config.get('model', 'usf-mini')
        self.timeout = config.get('timeout', 300)
        self.max_retries = config.get('max_retries', 5)
        self.retry_delay = config.get('retry_delay', 2)
        
        if not self.api_key:
            raise AuthenticationError("Ultrasafe API key is required")
        
        self.client = OpenAI(
            api_key=self.api_key,
            base_url=self.base_url,
            timeout=self.timeout
        )
    
    def chat_completion(
        self,
        messages: List[Message],
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> str:
        """
        Generate chat completion using Ultrasafe AI.
        
        Args:
            messages: Conversation messages
            model: Model override (defaults to config)
            temperature: Sampling temperature
            max_tokens: Maximum tokens
            **kwargs: Additional parameters
            
        Returns:
            Generated text
            
        Raises:
            APIError: If API call fails
            RateLimitError: If rate limited
        """
        model = model or self.model
        formatted_messages = self._prepare_messages(messages)
        
        for attempt in range(self.max_retries):
            try:
                response = self.client.chat.completions.create(
                    model=model,
                    messages=formatted_messages,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    **kwargs
                )
                
                return response.choices[0].message.content.strip()
                
            except Exception as e:
                error_str = str(e).lower()
                
                # Handle rate limiting
                if 'rate limit' in error_str or '429' in error_str:
                    if attempt < self.max_retries - 1:
                        wait_time = self.retry_delay * (2 ** attempt)
                        time.sleep(wait_time)
                        continue
                    raise RateLimitError(f"Rate limit exceeded: {e}")
                
                # Handle timeout
                if 'timeout' in error_str:
                    if attempt < self.max_retries - 1:
                        time.sleep(self.retry_delay ** attempt)
                        continue
                    raise APIError(f"Request timeout: {e}")
                
                # Handle authentication
                if 'auth' in error_str or '401' in error_str or '403' in error_str:
                    raise AuthenticationError(f"Authentication failed: {e}")
                
                # Generic retry
                if attempt < self.max_retries - 1:
                    time.sleep(self.retry_delay ** attempt)
                    continue
                
                raise APIError(f"API call failed: {e}")
        
        raise APIError("Max retries exceeded")
    
    def validate_config(self) -> bool:
        """
        Validate Ultrasafe provider configuration.
        
        Returns:
            True if valid
            
        Raises:
            AuthenticationError: If API key is missing
        """
        if not self.api_key:
            raise AuthenticationError("API key is required")
        
        if not self.base_url:
            raise ProviderError("Base URL is required")
        
        return True