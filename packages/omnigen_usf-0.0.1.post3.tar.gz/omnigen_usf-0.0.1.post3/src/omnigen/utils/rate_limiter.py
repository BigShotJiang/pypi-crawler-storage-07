"""Rate limiting utilities."""

import time
import threading
from collections import deque
from typing import Optional


class RateLimiter:
    """
    Thread-safe rate limiter for API calls.
    
    Tracks requests per minute and handles rate limit scenarios.
    """
    
    def __init__(self, rpm: int = 60):
        """
        Initialize rate limiter.
        
        Args:
            rpm: Requests per minute limit
        """
        self.rpm = rpm
        self.request_times = deque()
        self.lock = threading.Lock()
        self.rate_limit_hits = 0
    
    def acquire(self, timeout: Optional[float] = None) -> bool:
        """
        Wait until a request slot is available.
        
        Args:
            timeout: Maximum time to wait in seconds
            
        Returns:
            True if acquired, False if timeout
        """
        start_time = time.time()
        
        while True:
            with self.lock:
                self._cleanup_old_requests()
                
                if len(self.request_times) < self.rpm:
                    return True
            
            # Check timeout
            if timeout and (time.time() - start_time) >= timeout:
                return False
            
            # Wait a bit before retrying
            time.sleep(0.1)
    
    def record_request(self) -> None:
        """Record a request timestamp."""
        with self.lock:
            self.request_times.append(time.time())
            self._cleanup_old_requests()
    
    def get_rpm(self) -> int:
        """
        Get current requests per minute.
        
        Returns:
            Number of requests in the last minute
        """
        with self.lock:
            self._cleanup_old_requests()
            return len(self.request_times)
    
    def record_rate_limit(self) -> None:
        """Record a rate limit hit."""
        with self.lock:
            self.rate_limit_hits += 1
    
    def get_rate_limit_hits(self) -> int:
        """
        Get total rate limit hits.
        
        Returns:
            Number of rate limit hits
        """
        with self.lock:
            return self.rate_limit_hits
    
    def _cleanup_old_requests(self) -> None:
        """Remove request timestamps older than 1 minute."""
        cutoff = time.time() - 60
        while self.request_times and self.request_times[0] < cutoff:
            self.request_times.popleft()
    
    def reset(self) -> None:
        """Reset the rate limiter."""
        with self.lock:
            self.request_times.clear()
            self.rate_limit_hits = 0