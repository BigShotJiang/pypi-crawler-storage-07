"""Storage management for conversation extension pipeline."""

import json
import os
from pathlib import Path
from typing import Dict, Any
from omnigen.core.exceptions import StorageError


class ConversationExtensionStorage:
    """
    Storage manager for Conversation Extension Pipeline.
    
    Each pipeline has its own storage class with pipeline-specific needs.
    Handles JSONL output with automatic workspace isolation.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """Initialize storage."""
        self.config = config
        self.storage_type = config.get('type', 'jsonl')
        self.output_file = config.get('output_file', 'output.jsonl')
        self.partial_file = config.get('partial_file', 'partial.jsonl')
        self.failed_file = config.get('failed_file', 'failed.jsonl')
        
        # Create directories if needed
        self._ensure_directories()
    
    def _ensure_directories(self):
        """Create output directories if they don't exist."""
        for filepath in [self.output_file, self.partial_file, self.failed_file]:
            Path(filepath).parent.mkdir(parents=True, exist_ok=True)
    
    def save(self, conversation: Dict[str, Any]):
        """
        Save a conversation to appropriate file.
        
        Args:
            conversation: Conversation data with 'success' flag
        """
        try:
            if conversation.get('success'):
                # Save successful conversation
                self._append_jsonl(self.output_file, conversation)
            elif conversation.get('is_partial'):
                # Save partial conversation
                self._append_jsonl(self.partial_file, conversation)
            else:
                # Save failed conversation
                self._append_jsonl(self.failed_file, conversation)
        except Exception as e:
            raise StorageError(f"Failed to save conversation: {e}")
    
    def _append_jsonl(self, filepath: str, data: Dict[str, Any]):
        """Append data to JSONL file."""
        with open(filepath, 'a', encoding='utf-8') as f:
            f.write(json.dumps(data, ensure_ascii=False) + '\n')
    
    def get_stats(self) -> Dict[str, Any]:
        """Get storage statistics."""
        stats = {}
        
        for name, filepath in [
            ('output', self.output_file),
            ('partial', self.partial_file),
            ('failed', self.failed_file)
        ]:
            if os.path.exists(filepath):
                with open(filepath, 'r') as f:
                    stats[f'{name}_count'] = sum(1 for _ in f)
            else:
                stats[f'{name}_count'] = 0
        
        return stats