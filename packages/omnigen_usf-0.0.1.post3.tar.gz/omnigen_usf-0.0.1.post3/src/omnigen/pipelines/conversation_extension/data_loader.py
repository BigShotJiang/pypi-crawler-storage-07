"""Data loader for conversation extension pipeline."""

import json
import random
import threading
from pathlib import Path
from typing import List, Optional, Dict, Any
from omnigen.core.config import Config


class BaseConversationLoader:
    """Load base conversations from file or HuggingFace."""
    
    def __init__(self, config: Config):
        self.config = config
        self.base_conversations: List[Dict[str, Any]] = []
        self.current_index = 0
        self.lock = threading.Lock()
        
        source_type = config.get('base_data.source_type', 'file')
        
        if source_type == 'file':
            self._load_from_file()
        elif source_type == 'huggingface':
            self._load_from_huggingface()
        else:
            raise ValueError(f"Invalid source_type: {source_type}")
        
        if not self.base_conversations:
            raise ValueError("No valid base conversations found")
    
    def _load_from_file(self):
        """Load from local JSONL/JSON file."""
        file_path = self.config.get('base_data.file_path')
        if not file_path or not Path(file_path).exists():
            raise FileNotFoundError(f"Base conversation file not found: {file_path}")
        
        data_format = self.config.get('base_data.format', 'conversations')
        
        with open(file_path, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    data = json.loads(line)
                    convs = data.get(data_format, [])
                    
                    if convs:
                        # Validate and process conversation
                        conv_data = self._validate_conversation(convs)
                        if conv_data:
                            self.base_conversations.append(conv_data)
                except:
                    continue
        
        if self.config.get('base_data.shuffle', False):
            random.shuffle(self.base_conversations)
    
    def _load_from_huggingface(self):
        """Load from HuggingFace dataset."""
        try:
            from datasets import load_dataset
        except ImportError:
            raise ImportError("datasets package required. Install with: pip install datasets")
        
        hf_dataset = self.config.get('base_data.hf_dataset')
        hf_split = self.config.get('base_data.hf_split', 'train')
        hf_token = self.config.get('base_data.hf_token')
        data_format = self.config.get('base_data.format', 'conversations')
        
        splits = [hf_split] if isinstance(hf_split, str) else hf_split
        
        for split_name in splits:
            dataset = load_dataset(
                hf_dataset,
                split=split_name,
                token=hf_token,
                streaming=self.config.get('base_data.hf_streaming', False)
            )
            
            for example in dataset:
                try:
                    conversations = example.get(data_format, [])
                    if conversations:
                        # Validate and process conversation
                        conv_data = self._validate_conversation(conversations)
                        if conv_data:
                            self.base_conversations.append(conv_data)
                except:
                    continue
        
        if self.config.get('base_data.shuffle', False):
            random.shuffle(self.base_conversations)
    
    def _validate_conversation(self, conversations: List[Dict]) -> Optional[Dict[str, Any]]:
        """
        Validate conversation and return processed data with metadata.
        
        Returns:
            Dict with conversations, last_role, and is_valid, or None if invalid
        """
        if not conversations or not isinstance(conversations, list):
            return None
        
        # Check if first message is from user
        if not conversations[0].get('role') == 'user':
            return None
        
        # Check if first user message has content
        if not conversations[0].get('content'):
            return None
        
        # Determine last role
        last_role = 'other'
        if conversations:
            last_msg = conversations[-1]
            role = last_msg.get('role', '')
            if role in ['user', 'assistant']:
                last_role = role
        
        return {
            'conversations': conversations,
            'last_role': last_role,
            'is_valid': True
        }
    
    def get_next_conversation(self) -> Dict[str, Any]:
        """Get next conversation with metadata (thread-safe)."""
        with self.lock:
            # Safety check - prevent cycling to avoid duplicates
            if self.current_index >= len(self.base_conversations):
                raise RuntimeError(
                    f"No more unique base conversations available. "
                    f"Requested index {self.current_index} but only "
                    f"{len(self.base_conversations)} conversations loaded. "
                    f"This should not happen if Runner properly limits generation count."
                )
            
            conversation = self.base_conversations[self.current_index]
            self.current_index += 1
            return conversation
    
    def get_next_question(self) -> str:
        """
        Get next question (legacy method for backward compatibility).
        
        Returns just the first user message content.
        """
        conv = self.get_next_conversation()
        if conv and conv.get('conversations'):
            first_user = next((m for m in conv['conversations'] if m.get('role') == 'user'), None)
            if first_user:
                return first_user.get('content', '')
        return ''