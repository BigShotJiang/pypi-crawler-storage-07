"""Custom exceptions for OmniGen."""


class OmniGenError(Exception):
    """Base exception for all OmniGen errors."""
    pass


class ConfigurationError(OmniGenError):
    """Configuration-related errors."""
    pass


class InvalidConfigError(ConfigurationError):
    """Invalid configuration error."""
    pass


class MissingConfigError(ConfigurationError):
    """Missing required configuration error."""
    pass


class ProviderError(OmniGenError):
    """Provider-related errors."""
    pass


class APIError(ProviderError):
    """API call error."""
    pass


class RateLimitError(ProviderError):
    """Rate limit exceeded error."""
    pass


class AuthenticationError(ProviderError):
    """Authentication error."""
    pass


class DataError(OmniGenError):
    """Data-related errors."""
    pass


class LoaderError(DataError):
    """Data loader error."""
    pass


class ValidationError(DataError):
    """Data validation error."""
    pass


class StorageError(OmniGenError):
    """Storage-related errors."""
    pass


class WriterError(StorageError):
    """Writer error."""
    pass


class FormatError(StorageError):
    """Format error."""
    pass