"""Core components for OmniGen.

Note: Config classes are now pipeline-specific.
Each pipeline has its own config.py and storage.py for complete isolation.
"""

from omnigen.core.types import (
    Message,
    Conversation,
    ProviderConfig,
    GeneratorConfig,
    DataConfig,
    StorageConfig,
)
from omnigen.core.exceptions import (
    OmniGenError,
    ConfigurationError,
    ProviderError,
    DataError,
    StorageError,
)

__all__ = [
    "Message",
    "Conversation",
    "ProviderConfig",
    "GeneratorConfig",
    "DataConfig",
    "StorageConfig",
    "OmniGenError",
    "ConfigurationError",
    "ProviderError",
    "DataError",
    "StorageError",
]