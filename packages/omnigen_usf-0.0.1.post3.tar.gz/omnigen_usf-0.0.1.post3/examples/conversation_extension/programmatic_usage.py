"""
Example: Programmatic configuration without YAML files.

This demonstrates how to create and run the conversation extension pipeline
using direct Python configuration, without needing a config.yaml file.
"""

import os
from omnigen.pipelines.conversation_extension.config import (
    ConversationExtensionConfig,
    ConversationExtensionConfigBuilder
)
from omnigen.pipelines.conversation_extension import ConversationExtensionPipeline


def example_with_dict():
    """Create config using dictionary."""
    config = ConversationExtensionConfig({
        'providers': {
            'user_followup': {
                'name': 'openai',
                'api_key': os.getenv('OPENAI_API_KEY'),
                'model': 'gpt-4-turbo',
                'temperature': 0.7,
                'max_tokens': 2048
            },
            'assistant_response': {
                'name': 'anthropic',
                'api_key': os.getenv('ANTHROPIC_API_KEY'),
                'model': 'claude-3-5-sonnet-20241022',
                'temperature': 0.7,
                'max_tokens': 8192
            }
        },
        'generation': {
            'num_conversations': 10,
            'turn_range': {'min': 3, 'max': 8},
            'parallel_workers': 5
        },
        'base_data': {
            'source_type': 'file',
            'file_path': 'sample_data.jsonl',
            'format': 'conversations'
        },
        'storage': {
            'type': 'jsonl',
            'output_file': 'output_programmatic.jsonl'
        },
        'prompts': {
            'followup_question': """
## Your Task
Generate intelligent follow-up user question based on conversation history.

### CONVERSATION HISTORY:
{history}

### INSTRUCTIONS:
- Generate a meaningful follow-up question
- Be conversational and natural
- Build on the assistant's last response

Return your follow-up question wrapped in XML tags:
<user>Your follow-up question here</user>
"""
        }
    })
    
    # Run pipeline
    pipeline = ConversationExtensionPipeline(config)
    pipeline.run()


def example_with_builder():
    """Create config using fluent ConfigBuilder API."""
    config = (ConversationExtensionConfigBuilder()
        # Add provider for user followup generation
        .add_provider(
            role='user_followup',
            name='openai',
            api_key=os.getenv('OPENAI_API_KEY'),
            model='gpt-4-turbo',
            temperature=0.8,
            max_tokens=1024
        )
        # Add provider for assistant response generation
        .add_provider(
            role='assistant_response',
            name='anthropic',
            api_key=os.getenv('ANTHROPIC_API_KEY'),
            model='claude-3-5-sonnet-20241022',
            temperature=0.7,
            max_tokens=4096
        )
        # Set generation parameters
        .set_generation(
            num_conversations=10,
            turn_range=(3, 8),
            parallel_workers=5
        )
        # Set data source
        .set_data_source(
            source_type='file',
            file_path='sample_data.jsonl'
        )
        # Set storage
        .set_storage(
            type='jsonl',
            output_file='output_builder.jsonl'
        )
        # Set datetime config
        .set_datetime_config(
            enabled=True,
            mode='random_from_range',
            timezone='UTC',
            range={
                'start': '2025-01-01 00:00:00',
                'end': '2025-12-31 23:59:59'
            }
        )
        # Set system messages
        .set_system_messages(
            prepend_always={
                'enabled': True,
                'content': 'You are a helpful AI assistant. Current time: {current_datetime} ({timezone}).'
            }
        )
        # Build config
        .build()
    )
    
    # Run pipeline
    pipeline = ConversationExtensionPipeline(config)
    pipeline.run()


def example_same_provider_different_keys():
    """Use same provider with different API keys for billing/rate limit separation."""
    config = (ConversationExtensionConfigBuilder()
        .add_provider(
            role='user_followup',
            name='ultrasafe',
            api_key=os.getenv('ULTRASAFE_TEAM_A_KEY'),  # Team A's key
            model='usf-mini',
            temperature=0.7
        )
        .add_provider(
            role='assistant_response',
            name='ultrasafe',
            api_key=os.getenv('ULTRASAFE_TEAM_B_KEY'),  # Team B's key
            model='usf-max',
            temperature=0.6
        )
        .set_generation(100)
        .set_data_source('file', file_path='sample_data.jsonl')
        .set_storage('jsonl', output_file='output_separate_billing.jsonl')
        .build()
    )
    
    pipeline = ConversationExtensionPipeline(config)
    pipeline.run()


if __name__ == '__main__':
    print("Example 1: Config from dictionary")
    # example_with_dict()
    
    print("\nExample 2: Config with builder")
    # example_with_builder()
    
    print("\nExample 3: Same provider, different keys")
    # example_same_provider_different_keys()
    
    print("\nUncomment the examples you want to run!")