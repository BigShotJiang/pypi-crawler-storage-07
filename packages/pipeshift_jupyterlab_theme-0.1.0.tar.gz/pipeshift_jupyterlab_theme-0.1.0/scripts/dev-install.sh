#!/bin/bash

# Pipeshift JupyterLab Theme Development Installation Script
# This script sets up the development environment

set -euo pipefail

echo "🛠️  Setting up Pipeshift JupyterLab Theme for development..."

# Check requirements
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is required but not installed. Please install Node.js first."
    exit 1
fi

if ! command -v python &> /dev/null && ! command -v python3 &> /dev/null; then
    echo "❌ Python is required but not installed. Please install Python first."
    exit 1
fi

# Use python3 if python is not available
PYTHON_CMD="python"
if ! command -v python &> /dev/null; then
    PYTHON_CMD="python3"
fi

if ! command -v jupyter &> /dev/null; then
    echo "❌ JupyterLab is required but not installed. Please install JupyterLab first:"
    echo "   pip install jupyterlab>=4.4.5"
    exit 1
fi

echo "Installing Node.js dependencies..."
npm install

echo "Installing Python package in development mode..."
$PYTHON_CMD -m pip install -e .

echo "🔗 Linking extension for development..."
jupyter labextension develop . --overwrite

echo "🔨 Building extension..."
npm run build

echo "✅ Development setup complete!"
echo ""
echo "🚀 To start developing:"
echo "   # Terminal 1 - Watch for changes:"
echo "   npm run watch"
echo ""
echo "   # Terminal 2 - Start JupyterLab:"
echo "   jupyter lab --watch"
echo ""
echo "🎨 Your themes will be available in Settings → Theme:"
echo "   - Pipeshift Light"
echo "   - Pipeshift Dark"