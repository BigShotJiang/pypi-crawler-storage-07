#!/bin/bash

# Pipeshift JupyterLab Theme Build Script
# This script builds the theme extension for distribution

set -euo pipefail

echo "🎨 Building Pipeshift JupyterLab Theme..."

# Check if Node.js is available
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is required but not installed. Please install Node.js first."
    exit 1
fi

# Check if Python is available
if ! command -v python &> /dev/null && ! command -v python3 &> /dev/null; then
    echo "❌ Python is required but not installed. Please install Python first."
    exit 1
fi

# Use python3 if python is not available
PYTHON_CMD="python"
if ! command -v python &> /dev/null; then
    PYTHON_CMD="python3"
fi

echo "📦 Installing dependencies..."
npm install

echo "🧹 Cleaning previous builds..."
npm run clean:lib && npm run clean:labextension && npm run clean:lintcache

echo "🔨 Building TypeScript..."
npm run build:lib:prod

echo "🎯 Building JupyterLab extension..."
npm run build:labextension

echo "📋 Validating package..."
npm run lint:check

echo "🐍 Building Python package..."
$PYTHON_CMD -m build

echo "✅ Build complete!"
echo ""
echo "📁 Distribution files created:"
echo "   - dist/ (Python packages)"
echo "   - pipeshift_jupyterlab_theme/labextension/ (JupyterLab extension)"
echo ""
echo "🚀 To install locally:"
echo "   pip install dist/pipeshift_jupyterlab_theme-0.1.0-py3-none-any.whl"
echo ""
echo "🌐 To publish to PyPI:"
echo "   twine upload dist/*"