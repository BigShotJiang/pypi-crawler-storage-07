import {
    JupyterFrontEnd,
    JupyterFrontEndPlugin
} from '@jupyterlab/application';

import { IThemeManager } from '@jupyterlab/apputils';

/**
 * Initialization data for the pipeshift-jupyterlab-theme extension.
 */
const plugin: JupyterFrontEndPlugin<void> = {
    id: 'pipeshift-jupyterlab-theme:plugin',
    description: 'Pipeshift custom themes for JupyterLab',
    autoStart: true,
    requires: [IThemeManager],
    activate: (app: JupyterFrontEnd, manager: IThemeManager) => {
        // console.log('JupyterLab extension pipeshift-jupyterlab-theme is activated!');

        // Register Pipeshift Light theme
        manager.register({
            name: 'Pipeshift Light',
            displayName: 'Pipeshift Light',
            isLight: true,
            themeScrollbars: false,
            load: () => manager.loadCSS('pipeshift-jupyterlab-theme/index.css'),
            unload: () => Promise.resolve()
        });

        // Register Pipeshift Dark theme
        manager.register({
            name: 'Pipeshift Dark',
            displayName: 'Pipeshift Dark',
            isLight: false,
            themeScrollbars: true,
            load: () => manager.loadCSS('pipeshift-jupyterlab-theme/index.css'),
            unload: () => Promise.resolve()
        });
    }
};

export default plugin;