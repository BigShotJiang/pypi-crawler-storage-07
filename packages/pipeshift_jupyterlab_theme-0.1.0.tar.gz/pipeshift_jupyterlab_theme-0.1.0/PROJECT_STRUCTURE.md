# Pipeshift JupyterLab Theme - Project Structure

This document explains the complete project structure and how each file contributes to the theme extension.

## 📁 Complete Directory Structure

```
pipeshift-jupyterlab-theme/
├── 📄 package.json                    # NPM package configuration
├── 📄 pyproject.toml                  # Python packaging (pip install)
├── 📄 tsconfig.json                   # TypeScript compiler settings
├── 📄 install.json                    # JupyterLab extension metadata
├── 📄 README.md                       # Project documentation
├── 📄 LICENSE                         # MIT license
├── 📄 PROJECT_STRUCTURE.md             # This file
├── 📁 src/
│   └── 📄 index.ts                    # TypeScript entry point
├── 📁 style/
│   ├── 📄 index.css                   # Main CSS entry point
│   ├── 📄 variables.css               # CSS custom properties
│   ├── 📄 light.css                   # Pipeshift Light theme
│   └── 📄 dark.css                    # Pipeshift Dark theme
├── 📁 scripts/
│   ├── 📄 build.sh                    # Production build script
│   └── 📄 dev-install.sh              # Development setup script
└── 📁 pipeshift_jupyterlab_theme/
    └── 📄 __init__.py                 # Python package initialization
```

## 🔧 Core Configuration Files

### `package.json`
- Defines the NPM package
- Lists JupyterLab dependencies
- Contains build scripts
- Specifies the extension entry point

### `pyproject.toml` 
- Modern Python packaging configuration
- Enables `pip install pipeshift-jupyterlab-theme`
- Defines dependencies and metadata
- Configures build system with Hatch

### `tsconfig.json`
- TypeScript compiler configuration
- Ensures compatibility with JupyterLab 4.4.5+
- Sets up proper module resolution

### `install.json`
- JupyterLab installation metadata
- Tells JupyterLab how to handle the extension
- Links to Python package for uninstall instructions

## 🎨 Theme Implementation

### `src/index.ts`
**Purpose**: TypeScript entry point that registers both themes with JupyterLab

**Key Features**:
- Registers "Pipeshift Light" theme (isLight: true)
- Registers "Pipeshift Dark" theme (isLight: false)
- Uses JupyterLab's IThemeManager API
- Auto-starts when JupyterLab loads

### `style/variables.css`
**Purpose**: Central CSS custom properties definition

**Organization**:
- ✨ **Brand Colors**: Accent colors and brand palette
- 🌅 **Light Theme Variables**: All light mode colors
- 🌙 **Dark Theme Variables**: All dark mode colors  
- 🔤 **Typography**: Font families, sizes, weights
- 📏 **Spacing**: Margins, padding, border radius
- 🎭 **Effects**: Shadows, transitions

**Why This Approach**:
- Easy future customization
- Consistent color usage
- Component-based organization
- Simple theme switching

### `style/light.css` & `style/dark.css`
**Purpose**: Apply theme-specific styling using the variables

**Key Features**:
- Override JupyterLab's CSS custom properties
- Style all major UI components:
  - Notebook cells and outputs
  - File browser and navigation
  - Code editor and terminal
  - Toolbars and menus
  - Status bar and tabs
  - Sidebars and panels
- Enhanced interactions (hover, focus, selection)
- Custom scrollbars
- Improved accessibility

### `style/index.css`
**Purpose**: Main entry point that imports all theme files

## 🐍 Python Package Structure

### `pipeshift_jupyterlab_theme/__init__.py`
**Purpose**: Python package initialization

**Functions**:
- Defines package version
- Provides JupyterLab extension path discovery
- Enables proper pip installation/uninstallation

## 🚀 Build & Development Scripts

### `scripts/build.sh`
**Purpose**: Production build automation

**Steps**:
1. Install dependencies
2. Clean previous builds  
3. Build TypeScript → JavaScript
4. Build JupyterLab extension
5. Run linting/validation
6. Build Python package for PyPI

### `scripts/dev-install.sh`
**Purpose**: Development environment setup

**Steps**:
1. Check prerequisites (Node.js, Python, JupyterLab)
2. Install dependencies
3. Install package in development mode
4. Link extension for hot reloading
5. Initial build

## 🔄 Development Workflow

### Initial Setup
```bash
# Clone and enter directory
git clone <repo-url>
cd pipeshift-jupyterlab-theme

# Run development setup
chmod +x scripts/dev-install.sh
./scripts/dev-install.sh
```

### Active Development
```bash
# Terminal 1: Watch for changes
npm run watch

# Terminal 2: Start JupyterLab with auto-reload
jupyter lab --watch
```

### Production Build
```bash
# Build for distribution
chmod +x scripts/build.sh
./scripts/build.sh

# Install locally to test
pip install dist/pipeshift_jupyterlab_theme-0.1.0-py3-none-any.whl
```

## 🎯 How Users Install & Use

### Installation
```bash
pip install pipeshift-jupyterlab-theme
```

### Usage
1. Restart JupyterLab
2. Settings → Theme
3. Choose "Pipeshift Light" or "Pipeshift Dark"

## 🛠️ Customization Guide

### Changing Colors
Edit `style/variables.css`:
```css
:root {
  --ps-accent-color: #YOUR_COLOR;
}
```

### Adding New Components
1. Add variables to `style/variables.css`
2. Add styles to `style/light.css` and `style/dark.css`
3. Rebuild: `npm run build`

### Creating Theme Variants
1. Copy `style/light.css` → `style/custom.css`
2. Modify colors and styles
3. Register in `src/index.ts`
4. Import in `style/index.css`

## 📦 Distribution

### NPM Package
- Contains TypeScript source and CSS
- Used during development
- Installed via `npm install`

### Python Package (PyPI)
- Contains compiled JavaScript and CSS
- Used by end users
- Installed via `pip install`
- Automatically discovered by JupyterLab

## 🔍 Key Design Decisions

1. **CSS Custom Properties**: Maximum flexibility for customization
2. **Dual Package System**: NPM for development, PyPI for users  
3. **Component Organization**: Logical grouping of CSS variables
4. **TypeScript**: Type safety and better JupyterLab integration
5. **Modern Python Packaging**: pyproject.toml for better dependency management

This structure ensures the theme is professional, maintainable, and easy to customize while providing a seamless installation experience for users.