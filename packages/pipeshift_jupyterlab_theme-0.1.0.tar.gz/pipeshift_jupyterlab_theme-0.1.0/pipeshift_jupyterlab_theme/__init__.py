"""
Pipeshift JupyterLab Theme

A custom theme extension for JupyterLab featuring both light and dark modes
with Pipeshift branding.
"""

import json
import os.path as osp

__version__ = "0.1.0"

HERE = osp.abspath(osp.dirname(__file__))

with open(osp.join(HERE, "labextension", "package.json")) as fid:
    data = json.load(fid)

def _jupyter_labextension_paths():
    return [{
        "src": "labextension",
        "dest": data["name"]
    }]