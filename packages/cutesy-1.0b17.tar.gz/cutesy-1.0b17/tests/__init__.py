"""Test the Cutesy package."""
