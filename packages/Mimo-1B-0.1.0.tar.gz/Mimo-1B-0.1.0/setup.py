from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="Mimo-1B",
    version="0.1.0",
    author="ABDESSEMED Mohamed Redha",
    author_email="mohamedredha.abdessemed@example.com", # Assuming a placeholder email
    description="This project provides the necessary scripts and instructions to fine-tune the `deepseek-ai/DeepSeek-R1-Distill-Qwen-1.5B` model using QLoRA on a macOS system with limited RAM (~8GB), convert it to the GGUF format, and make it ready for use with Ollama and LM Studio.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/your-repo", # Placeholder URL, user might want to update this
    packages=find_packages(where="."), # Assuming the package is in the root directory
    install_requires=[
        "torch==2.8.0",
        "transformers==4.56.2",
        "datasets==4.1.1",
        "accelerate==1.10.1",
        "peft==0.17.1",
        "sentencepiece==0.2.1",
        "llama-cpp-python",
        "huggingface_hub==0.35.1",
        "pandas==2.3.2",
        "regex>=2025.9.18",
        "pyarrow==21.0.0",
        "psutil==7.1.0",
        "dill==0.4.0",
        "xxhash",
        "safetensors==0.6.2",
        "tokenizers==0.22.1",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License", # Assuming MIT license, user might want to change
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.8', # Assuming a reasonable Python version requirement
)
