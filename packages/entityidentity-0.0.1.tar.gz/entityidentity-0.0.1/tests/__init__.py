"""Tests for entityidentity package"""

