

mines_primary = {"dark_blue":"#21314d",
                 "blaster_blue" : "#09396C",
                 "light_blue" :  "#879EC3" ,
                 "colorado_red" : "#CC4628",
                 "pale_blue" : "#CFDCE9"}

mines_neutral = {"white" : "#FFFFFF",
                 "light_gray" : "#AEB3B8",
                 "silver" : "#81848A",
                 "dark_gray" : "#75757D"}

mines_accent = {"earth_blue" : "#0272DE",
                "muted_blue" : "#57A2BD",
                "energy_yellow" : "#F0F600",
                "golden_tech" : "#F1B91A",
                "environment_green" : "#80C342",
                "red_flannel" : "#B42024"}