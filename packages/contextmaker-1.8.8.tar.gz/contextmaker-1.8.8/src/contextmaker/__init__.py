from .contextmaker import make
# Simple API: just use make()
__all__ = ['make']
