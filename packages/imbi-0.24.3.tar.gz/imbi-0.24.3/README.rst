Imbi API
========
The backend API for `Imbi <https://github.com/AWeber-Imbi/imbi>`_.

|Version| |Coverage| |License|

Contributing
------------
For information on contributing, including development environment setup, see
`CONTRIBUTING.md <https://github.com/aweber/imbi/blob/main/CONTRIBUTING.md>`_.

Etymology
---------
Imbi is Old High German for "Swarm of Bees"

.. |Version| image:: https://img.shields.io/pypi/v/imbi.svg
   :target: https://pypi.python.org/pypi/imbi

.. |Coverage| image:: https://img.shields.io/codecov/c/github/aweber/imbi.svg
   :target: https://codecov.io/github/AWeber-Imbi/imbi-api?branch=master

.. |License| image:: https://img.shields.io/pypi/l/imbi.svg?
   :target: https://imbi.readthedocs.org
