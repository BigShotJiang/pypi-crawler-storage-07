from abstract_hugpy.hugpy_console.hugpy_flasks.hugpy_deepcoder_flask_app import hugpy_deepcoder_app

app = hugpy_deepcoder_app()

