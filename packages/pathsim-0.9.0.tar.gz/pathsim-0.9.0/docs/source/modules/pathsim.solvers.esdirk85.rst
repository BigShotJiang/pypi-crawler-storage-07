pathsim.solvers.esdirk85 module
===============================

.. automodule:: pathsim.solvers.esdirk85
   :members:
   :show-inheritance:
   :undoc-members:
