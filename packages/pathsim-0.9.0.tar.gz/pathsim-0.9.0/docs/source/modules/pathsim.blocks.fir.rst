pathsim.blocks.fir module
=========================

.. automodule:: pathsim.blocks.fir
   :members:
   :show-inheritance:
   :undoc-members:
