pathsim.blocks.function module
==============================

.. automodule:: pathsim.blocks.function
   :members:
   :show-inheritance:
   :undoc-members:
