pathsim.optim
=============

.. toctree::
   :maxdepth: 4

   pathsim.optim.operator
   pathsim.optim.anderson
   pathsim.optim.booster
   pathsim.optim.value
   pathsim.optim.numerical
