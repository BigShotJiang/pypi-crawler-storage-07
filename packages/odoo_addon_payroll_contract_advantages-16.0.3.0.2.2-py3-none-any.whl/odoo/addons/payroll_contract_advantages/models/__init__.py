# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import hr_contract_advantage_template
from . import hr_contract_advantage
from . import hr_contract
from . import hr_payslip
