release 0.1.6: fix(patch)

Changes
--------------------------------------------------------------------------------
- Update lock file
- 💄 style: add blank line for import grouping
- 🔧 chore: comment out unused imports and version display

