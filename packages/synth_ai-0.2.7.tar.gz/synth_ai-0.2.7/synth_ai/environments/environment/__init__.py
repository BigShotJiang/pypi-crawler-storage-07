"""Environment core module."""
