# -*- coding: utf-8 -*-

from .caster import codeguru_security_caster

caster = codeguru_security_caster

__version__ = "1.40.0"