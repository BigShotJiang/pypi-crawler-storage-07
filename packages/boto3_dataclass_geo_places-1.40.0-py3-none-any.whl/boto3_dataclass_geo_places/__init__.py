# -*- coding: utf-8 -*-

from .caster import geo_places_caster

caster = geo_places_caster

__version__ = "1.40.0"