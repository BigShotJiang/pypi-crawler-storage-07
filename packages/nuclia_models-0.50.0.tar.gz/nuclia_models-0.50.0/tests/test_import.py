def test_import() -> None:
    from nuclia_models.common.client import ClientType  # noqa: F401
    from nuclia_models.common.pagination import Pagination  # noqa: F401
    from nuclia_models.common.user import UserType  # noqa: F401
    from nuclia_models.events.activity_logs import ActivityLogs  # noqa: F401
