"""Content summarization functionality for content-core."""

from .core import summarize

__all__ = ["summarize"]
