"""Type definitions and type aliases for Carbonic.

This module contains common type definitions used throughout the Carbonic library
to improve type safety and code readability.
"""

# Future type definitions will be added here as the library grows
