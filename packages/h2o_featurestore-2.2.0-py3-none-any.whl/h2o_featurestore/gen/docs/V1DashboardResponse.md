# V1DashboardResponse


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**project_number** | **str** |  | [optional] 
**feature_sets_number** | **str** |  | [optional] 
**features_number** | **str** |  | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


