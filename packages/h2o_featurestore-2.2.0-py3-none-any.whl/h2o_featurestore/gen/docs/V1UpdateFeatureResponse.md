# V1UpdateFeatureResponse


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**updated_feature_set** | [**Apiv1FeatureSet**](Apiv1FeatureSet.md) |  | [optional] 
**updated_feature** | [**V1Feature**](V1Feature.md) |  | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


