# -*- coding: utf-8 -*-

from .caster import ivschat_caster

caster = ivschat_caster

__version__ = "1.40.0"