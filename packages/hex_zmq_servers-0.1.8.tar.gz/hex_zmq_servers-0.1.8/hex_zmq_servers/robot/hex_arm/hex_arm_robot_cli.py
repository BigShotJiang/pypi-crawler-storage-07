#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2025 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2025-09-14
################################################################

import numpy as np

from ..robot_base import HexRobotClientBase
from ...zmq_base import (
    MAX_SEQ_NUM,
    hex_zmq_ts_now,
)
from .hex_arm_robot import HexHexArmRobot

NET_CONFIG = {
    "ip": "127.0.0.1",
    "port": 12345,
    "client_timeout_ms": 200,
    "server_timeout_ms": 1_000,
    "server_num_workers": 4,
}

ROBOT_CONFIG = {
    "device_ip": "172.18.8.161",
    "device_port": 8439,
    "control_hz": 250,
    "arm_type": 16,
    "sens_ts": True,
}


class HexHexArmRobotClient(HexRobotClientBase):

    def __init__(
        self,
        net_config: dict = NET_CONFIG,
    ):
        HexRobotClientBase.__init__(self, net_config)
