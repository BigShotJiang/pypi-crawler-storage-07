"""
Django CFG Tasks App

Provides admin interface for Dramatiq task management.
"""
