# -*- coding: utf-8 -*-

from .caster import codeguru_reviewer_caster

caster = codeguru_reviewer_caster

__version__ = "1.40.0"