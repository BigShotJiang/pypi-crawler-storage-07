"""
EcoDonut
========

EcoDonut is a Python package for the creation Eco-Frames and water graphs.

Homepage https://github.com/DDonnyy/EcoDonut.
"""

from ._version import VERSION as __version__
