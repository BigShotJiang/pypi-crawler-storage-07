"""
Main entry point when running undockit as a module
"""

import sys
from .main import main

if __name__ == "__main__":
    sys.exit(main())
