# WTFPL + Warranty

Licensed under the WTFPL with one additional clause:

1. Don't blame me.

Do whatever the fuck you want, just don't blame me.
