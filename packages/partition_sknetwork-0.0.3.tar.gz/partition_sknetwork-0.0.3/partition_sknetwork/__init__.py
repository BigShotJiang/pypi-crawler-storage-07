__version__ = "0.0.2"
from .partition_sknetwork import (
    gam,
    ECG,
)