#!/bin/bash

set -e 


curl --version
