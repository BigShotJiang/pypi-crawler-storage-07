# -*- coding: utf-8 -*-

from .caster import dms_caster

caster = dms_caster

__version__ = "1.40.0"