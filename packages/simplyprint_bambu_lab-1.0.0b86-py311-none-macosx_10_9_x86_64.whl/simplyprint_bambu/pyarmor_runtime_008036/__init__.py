# Pyarmor 9.0.8 (ci), 008036, 2025-09-27T19:22:24.203705
from .pyarmor_runtime import __pyarmor__
