from typing import Tuple, Union

ParamPath = Tuple[Union[int, str], ...]
