class ConfigurationError(Exception):
    """configuration error"""
