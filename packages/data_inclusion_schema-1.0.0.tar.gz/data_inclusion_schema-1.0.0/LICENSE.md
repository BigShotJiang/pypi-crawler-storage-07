# LICENCE OUVERTE 2.0 / OPEN LICENCE 2.0

## « Réutilisation » de l'« Information » sous cette licence

Le « Concédant » concède au « Réutilisateur » un droit non exclusif et gratuit de libre « Réutilisation » de l'« Information » objet de la présente licence, à des fins commerciales ou non, dans le monde entier et pour une durée illimitée, dans les conditions exprimées ci-dessous.

**Le « Réutilisateur » est libre de réutiliser l'« Information » :**

- de la reproduire, la copier,
- de l‘adapter, la modifier, l‘extraire et la transformer, pour créer des « Informations dérivées », des produits ou des services,
- de la communiquer, la diffuser, la redistribuer, la publier et la transmettre,
- de l'exploiter à titre commercial, par exemple en la combinant avec d'autres informations, ou en l'incluant dans son propre produit ou application.

**Sous réserve de :**

- mentionner la paternité de l'« Information » : sa source (au moins le nom du « Concédant ») et la date de dernière mise à jour de l'« Information » réutilisée.

Le « Réutilisateur » peut notamment s'acquitter de cette condition en renvoyant, par un lien hypertexte, vers la source de «l'Information» et assurant une mention effective de sa paternité.
Par exemple : *« Ministère de xxx - Données originales téléchargées sur http://www.data.gouv.fr/fr/datasets/xxx/, mise à jour du 14 février 2017 »*.

Cette mention de paternité ne confère aucun caractère officiel à la « Réutilisation » de l'« Information », et ne doit pas suggérer une quelconque reconnaissance ou caution par le « Concédant », ou par toute autre entité publique, du « Réutilisateur » ou de sa « Réutilisation ».

## « Données à caractère personnel »

L‘ « Information » mise à disposition peut contenir des « Données à caractère personnel » pouvant faire l'objet d'une « Réutilisation ». Si tel est le cas, le « Concédant » informe le « Réutilisateur » de leur présence. L' « Information » peut être librement réutilisée, dans le cadre des droits accordés par la présente licence, à condition de respecter le cadre légal relatif à la protection des données à caractère personnel.

## « Droits de propriété intellectuelle »

Il est garanti au « Réutilisateur » que les éventuels « Droits de propriété intellectuelle » détenus par des tiers ou par le « Concédant » sur l'« Information » ne font pas obstacle aux droits accordés par la présente licence.

Lorsque le « Concédant » détient des « Droits de propriété intellectuelle » cessibles sur l'« Information », il les cède au « Réutilisateur » de façon non exclusive, à titre gracieux, pour le monde entier, pour toute la durée des « Droits de propriété intellectuelle », et le « Réutilisateur » peut faire tout usage de l'« Information » conformément aux libertés et aux conditions définies par la présente licence.

## Responsabilité

L' « Information » est mise à disposition telle que produite ou reçue par le « Concédant », sans autre garantie expresse ou tacite que celles prévues par la présente licence. L'absence de défauts ou d'erreurs éventuellement contenues dans l'« Information », comme la fourniture continue de l'« Information » n'est pas garantie par le « Concédant ». Il ne peut être tenu pour responsable de toute perte, préjudice ou dommage de quelque sorte causé à des tiers du fait de la « Réutilisation ».

Le « Réutilisateur » est seul responsable de la « Réutilisation » de l'« Information ».

La « Réutilisation » ne doit pas induire en erreur des tiers quant au contenu de l'« Information », sa source et sa date de mise à jour.

## Droit applicable

La présente licence est régie par le droit français.

## Compatibilité de la présente licence

La présente licence a été conçue pour être compatible avec toute licence libre qui exige au moins la mention de paternité et notamment avec la version antérieure de la présente licence ainsi qu'avec les licences « Open Government Licence » (OGL) du Royaume-Uni, « Creative Commons Attribution » (CC-BY) de Creative Commons et « Open Data Commons Attribution » (ODC-BY) de l'Open Knowledge Foundation.

## Définitions

Sont considérés, au sens de la présente licence comme :

- Le **« Concédant »** : toute personne concédant un droit de « Réutilisation » sur l'« Information » dans les libertés et les conditions prévues par la présente licence
- L'**« Information »** :
  - toute information publique figurant dans des documents communiqués ou publiés par une administration mentionnée au premier alinéa de l'article L.300-2 du CRPA ;
  - toute information mise à disposition par toute personne selon les termes et conditions de la présente licence.
- La **« Réutilisation »** : l'utilisation de l'« Information » à d'autres fins que celles pour lesquelles elle a été produite ou reçue.
- Le **« Réutilisateur »** : toute personne qui réutilise les « Informations » conformément aux conditions de la présente licence.
- Des **« Données à caractère personnel »** : toute information se rapportant à une personne physique identifiée ou identifiable, pouvant être identifiée directement ou indirectement. Leur « Réutilisation » est subordonnée au respect du cadre juridique en vigueur.
- Une **« Information dérivée »** : toute nouvelle donnée ou information créées directement à partir de l'« Information » ou à partir d'une combinaison de l'« Information » et d'autres données ou informations non soumises à cette licence.
- Les **« Droits de propriété intellectuelle »** : tous droits identifiés comme tels par le Code de la propriété intellectuelle (notamment le droit d'auteur, droits voisins au droit d'auteur, droit sui generis des producteurs de bases de données…).

## À propos de cette licence

La présente licence a vocation à être utilisée par les administrations pour la réutilisation de leurs informations publiques. Elle peut également être utilisée par toute personne souhaitant mettre à disposition de l'« Information » dans les conditions définies par la présente licence

La France est dotée d'un cadre juridique global visant à une diffusion spontanée par les administrations de leurs informations publiques afin d'en permettre la plus large réutilisation.

Le droit de la « Réutilisation » de l'« Information » des administrations est régi par le code des relations entre le public et l'administration (CRPA).

Cette licence facilite la réutilisation libre et gratuite des informations publiques et figure parmi les licences qui peuvent être utilisées par l'administration en vertu du décret pris en application de l'article L.323-2 du CRPA.

Etalab est la mission chargée, sous l'autorité du Premier ministre, d'ouvrir le plus grand nombre de données publiques des administrations de l'État et de ses établissements publics. Elle a réalisé la Licence Ouverte pour faciliter la réutilisation libre et gratuite de ces informations publiques, telles que définies par l'article L321-1 du CRPA.

Cette licence est la version 2.0 de la Licence Ouverte.

Etalab se réserve la faculté de proposer de nouvelles versions de la Licence Ouverte. Cependant, les « Réutilisateurs » pourront continuer à réutiliser les informations qu'ils ont obtenues sous cette licence s'ils le souhaitent.
