# flake8_no_emoji/__init__.py
from .checker import NoEmojiChecker

__all__ = ["NoEmojiChecker"]
