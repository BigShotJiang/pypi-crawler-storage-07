"""Abstract base classes for database marshaling."""
