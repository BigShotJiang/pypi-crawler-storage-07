"""Main entry point for the package."""

from supabase_pydantic.cli import cli

if __name__ == '__main__':
    cli()
