from pydantic import BaseModel


class DebugAnalysisResult(BaseModel):
    outcome: str
    explanation: str
