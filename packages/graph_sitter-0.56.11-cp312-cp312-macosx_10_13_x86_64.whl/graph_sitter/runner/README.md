# graph_sitter.runner

A module to run functions with managed state + lifecycle.

### Dependencies

- [codegen.sdk](https://github.com/codegen-sh/graph-sitter/tree/develop/src/codegen/sdk)
- [codegen.git](https://github.com/codegen-sh/graph-sitter/tree/develop/src/codegen/git)
- [codegen.shared](https://github.com/codegen-sh/graph-sitter/tree/develop/src/codegen/shared)
