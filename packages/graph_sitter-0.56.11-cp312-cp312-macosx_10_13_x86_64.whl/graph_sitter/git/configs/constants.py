"""Git related constants"""

CODEGEN_BOT_NAME = "codegen-sh[bot]"
CODEGEN_BOT_EMAIL = "131295404+codegen-sh[bot]@users.noreply.github.com"
CODEOWNERS_FILEPATHS = [".github/CODEOWNERS", "CODEOWNERS", "docs/CODEOWNERS"]
