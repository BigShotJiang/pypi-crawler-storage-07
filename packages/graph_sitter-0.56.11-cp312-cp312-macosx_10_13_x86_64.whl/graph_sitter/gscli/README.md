# Graph-sitter GS CLI

This module to be moved out into `src/code_generation`
