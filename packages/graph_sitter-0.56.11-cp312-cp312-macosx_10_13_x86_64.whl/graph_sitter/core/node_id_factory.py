NodeId = int
