"""Allow running the package as a module with python -m ynab_amazon_categorizer."""

from .cli import main

if __name__ == "__main__":
    main()
