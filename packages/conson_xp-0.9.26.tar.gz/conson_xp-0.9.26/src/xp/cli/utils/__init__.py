"""CLI utilities for common functionality."""
