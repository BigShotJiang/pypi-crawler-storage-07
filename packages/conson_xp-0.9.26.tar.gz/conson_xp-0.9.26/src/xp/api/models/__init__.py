"""API models for request and response validation."""
