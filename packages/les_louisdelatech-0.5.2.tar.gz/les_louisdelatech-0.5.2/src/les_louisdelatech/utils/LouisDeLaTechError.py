class LouisDeLaTechError(Exception):
    pass
