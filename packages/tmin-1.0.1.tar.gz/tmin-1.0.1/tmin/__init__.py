from .core_dev import PIPE

__all__ = ['PIPE']
