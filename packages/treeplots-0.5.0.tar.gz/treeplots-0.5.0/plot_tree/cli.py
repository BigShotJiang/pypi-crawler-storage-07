#!/usr/bin/env python

from pathlib import Path
from typing import Annotated, Optional

import typer
from rich import print

from plot_tree.common import PACKAGE_VERSION
from plot_tree.default import CSV_FILE_NAME, OUTPUT_DIR_NAME
from plot_tree.tree_plotter import TreePlotter

app = typer.Typer(
    context_settings=dict(help_option_names=['-h', '--help']),
    add_completion=False
)


def version_callback(value: bool):
    if value:
        typer.echo(f'Version: {PACKAGE_VERSION}')
        raise typer.Exit()


@app.command()
def csv(
        csv_file: str = typer.Argument(default=CSV_FILE_NAME, help='csv file name'),
        output_dir: str = typer.Option(OUTPUT_DIR_NAME, '--output-dir', '-o', help='output directory'),
        version: Annotated[
            Optional[bool],
            typer.Option('--version', '-v', callback=version_callback, is_eager=True, help=PACKAGE_VERSION),
        ] = None,
):
    '''Plot tree from a csv file with child-parent relationships.
    '''

    csv_file_path = Path(csv_file)
    output_dir_path = Path(output_dir)

    plotter = TreePlotter(csv_file=csv_file_path, output_dir=output_dir_path)
    plotter.plot()

    print(f'\n[green]Read from: `{csv_file_path}` and wrote to folder: `{output_dir_path}`')


if __name__ == '__main__':
    app()
