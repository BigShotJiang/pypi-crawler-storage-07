from typing import Any

import os
import shutil

from ut_log.log import Log, LogEq
from ut_path.path import Path
from ut_path.dopath import DoPath
from ut_ioc.yaml_ import Yaml_

TyAny = Any
TyDic = dict[Any, Any]
TyDoD = dict[Any, TyDic]
TyAoD = list[TyDic]
TyAoDoD = list[TyDoD]
TyPath = str
TyStr = str

TnAny = None | TyAny
TnDic = None | TyDic
TnAoDoD = None | TyAoDoD
TnPath = None | TyPath
TyToPath = tuple[TnPath, TnPath]
TyAoToPath = list[TyToPath]


class Setup:
    """
    Setup function class
    """
    @staticmethod
    def copytree(topath: TyToPath) -> None:
        """
        Copy source path tree to destination path tree while preserving timestamps,
        and allow existing destination.
        """
        src, dst = topath
        if not src:
            msg = f"source path `{src}` is undefined or empty"
            Log.error(msg)
            return
        if not dst:
            msg = f"destination path `{dst}` is undefined or empty"
            Log.error(msg)
            return
        if not os.path.exists(dst):
            os.makedirs(dst)
        # Copy the entire directory tree
        try:
            shutil.copytree(
                    src, dst, copy_function=shutil.copy2, dirs_exist_ok=True)
            _msg = f"Directory tree copied from {src} to {dst}"
            Log.debug(_msg)
        except Exception as e:
            _msg = f"Could not copy Directory tree from {src} to {dst}"
            raise Exception(_msg) from e

    @classmethod
    def sh_path_for_loc(cls, dod_copy: TyDoD, loc: TyStr, kwargs: TyDic) -> TnPath:
        _d_copy: TnDic = dod_copy.get(loc)
        if not _d_copy:
            _msg = f"directory _d_copy for loc = {loc} is undefined or empty"
            Log.error(_msg)
            # raise Exception(msg)
            return None
        _path: TnPath = DoPath.sh_path(_d_copy, kwargs)
        if not _path:
            _msg = (f"Path _path for _d_copy = {_d_copy} and "
                    f"loc = {loc} is undefined or empty")
            Log.error(_msg)
            return None
            # raise Exception(msg)
        return _path

    @classmethod
    def get_aot_copy(cls, aodod_copy, kwargs: TyDic) -> TyAoToPath:
        _aot: TyAoToPath = []
        for _dod_copy in aodod_copy:
            LogEq.debug("_dod_copy", _dod_copy)
            _src_path: TnPath = cls.sh_path_for_loc(_dod_copy, 'src', kwargs)
            _dst_path: TnPath = cls.sh_path_for_loc(_dod_copy, 'dst', kwargs)
            LogEq.debug("_src_path", _src_path)
            LogEq.debug("_dst_path", _dst_path)
            _aot.append((_src_path, _dst_path))
        return _aot

    @staticmethod
    def get_aodod_copy(kwargs: TyDic) -> TyAoDoD:
        _aodod_copy: TnAoDoD = kwargs.get('aodod_copy')
        LogEq.debug("_aodod_copy", _aodod_copy)
        if _aodod_copy is not None:
            return _aodod_copy

        _in_path_copy: TnPath = kwargs.get('in_path_copy')
        _path: TnPath = Path.sh_path_by_tpl_pac_sep(_in_path_copy, kwargs)
        _aodod_yaml: TnAoDoD = Yaml_.read_with_safeloader(_path)
        if not _aodod_yaml:
            _msg = f"Content of yaml file = {_path} is undefined or empty"
            raise Exception(_msg)
        return _aodod_yaml

    @classmethod
    def setup(cls, kwargs: TyDic) -> None:
        _aodod_copy: TyAoDoD = cls.get_aodod_copy(kwargs)
        _aot_copy: TyAoToPath = cls.get_aot_copy(_aodod_copy, kwargs)
        LogEq.debug("_aodod_copy", _aodod_copy)
        LogEq.debug("_aot_copy", _aot_copy)
        for _tup_path in _aot_copy:
            cls.copytree(_tup_path)
