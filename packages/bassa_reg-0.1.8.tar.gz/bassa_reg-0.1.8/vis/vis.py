import os

import numpy as np
import matplotlib as mpl
import pandas as pd
from matplotlib import pyplot as plt
import shutil
from PIL import Image, ImageColor
import io

from matplotlib.patches import Rectangle
from matplotlib.patches import FancyArrowPatch

from bassa_reg.spike_and_slab.bassa_survival import SurvivalSample
from bassa_reg.spike_and_slab.utils.bassa_enums import SurvivalMetric
from bassa_reg.spike_and_slab.utils.upsert_plot import generate_bassa_plot

# --- 1. Data and Configuration ---
S_MATRIX = np.array([
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 0, 0, 1, 1, 1, 0, 1],
    [0, 0, 1, 0, 0, 0, 0, 0, 0, 1],
    [0, 0, 0, 1, 0, 0, 0, 0, 0, 0]
])

FEATURE_NAMES = [r's_1', r's_2', r's_3', r's_4']
MODEL_NAMES = {
    1: r'$s_1$',
    2: r'$s_1, s_2$',
    3: r'$s_1, s_2, s_3$',
    4: r'$s_1, s_4$'
}
COLORS = ['white', '#ff9999', '#99ccff', '#99ff99', '#ffcc99', 'gray']


def _setup_matplotlib_style():
    """Configures Matplotlib settings, including LaTeX rendering if available."""
    if shutil.which('latex'):
        mpl.rcParams['text.usetex'] = True
    mpl.rcParams['figure.dpi'] = 150  # Higher DPI for better quality


def create_mcmc_figure(s_matrix, feature_names, model_names, colors):
    """
    Creates the top grid of 4 plots as a single Matplotlib figure.

    Returns:
        tuple: (matplotlib.figure.Figure, dict) The generated figure and the
               calculated model percentages.
    """
    print("1. Generating MCMC iteration figure...")
    fig, axes = plt.subplots(1, 5, figsize=(22, 2.5))
    fig.subplots_adjust(wspace=0.4)
    print("1a. Generating MCMC input plot...")
    ax_input = axes[0]
    # Use a binary colormap (0=white, 1=black)
    ax_input.imshow(s_matrix, cmap='binary', aspect='auto', interpolation='none')
    ax_input.set_title(r'MCMC Samples Input', fontsize=14)
    ax_input.set_ylabel(r'Features', fontsize=12)
    ax_input.set_xlabel(r'MCMC Iteration', fontsize=12)
    ax_input.set_yticks(range(len(feature_names)))
    yticklabels = [rf'${name}$' for name in feature_names]
    ax_input.set_yticklabels(yticklabels, fontsize=12)
    # --- END NEW ---

    cmap = mpl.colors.ListedColormap(colors)
    bounds = [-0.5, 0.5, 1.5, 2.5, 3.5, 4.5, 5.5]
    norm = mpl.colors.BoundaryNorm(bounds, cmap.N)
    total_cols = s_matrix.shape[1]
    all_percentages = {model_code: [] for model_code in model_names.keys()}

    for i in range(1, 5):
        ax = axes[i]
        color_matrix = np.zeros_like(s_matrix, dtype=int)
        model_counts = {}

        # Logic to assign a color code and count each model per iteration
        for j in range(s_matrix.shape[1]):
            s_col = s_matrix[:, j]
            model_code = 0  # Default to white (no model)

            if i == 1:
                if s_col[0] == 1: model_code = 1
            elif i == 2:
                sub_vector = tuple(s_col[0:2])
                if sub_vector == (1, 1):
                    model_code = 2
                elif sub_vector == (1, 0):
                    model_code = 1
            elif i == 3:
                sub_vector = tuple(s_col[0:3])
                if sub_vector == (1, 1, 1):
                    model_code = 3
                elif sub_vector == (1, 1, 0):
                    model_code = 2
                elif sub_vector == (1, 0, 0):
                    model_code = 1
            elif i == 4:
                s_col_tuple = tuple(s_col)
                if s_col_tuple == (1, 0, 0, 1):
                    model_code = 4
                elif s_col_tuple == (1, 1, 1, 0):
                    model_code = 3
                elif s_col_tuple == (1, 1, 0, 0):
                    model_code = 2
                elif s_col_tuple == (1, 0, 0, 0):
                    model_code = 1

            if model_code != 0:
                model_counts[model_code] = model_counts.get(model_code, 0) + 1
            color_matrix[:, j] = s_col * model_code

        # Store percentages for the summary plot
        for model_code in all_percentages.keys():
            count = model_counts.get(model_code, 0)
            all_percentages[model_code].append((count / total_cols) * 100 if count > 0 else np.nan)

        if i < 4:
            color_matrix[i:, :] = 5  # Gray out unused features

        # --- Plotting and Styling ---
        ax.imshow(color_matrix, cmap=cmap, norm=norm, aspect='auto', interpolation='none')
        ax.set_title(fr'Bassa Iteration: {i}', fontsize=14)
        #ax.set_ylabel(r'Features', fontsize=12)
        ax.set_yticks(range(len(feature_names)))

        yticklabels = [rf'${name}$' for name in feature_names]
        ax.set_yticklabels(yticklabels, fontsize=12)

        text_lines = []
        for mc in sorted(model_counts.keys()):
            # 1. Manually calculate the percentage value
            percentage_val = (model_counts.get(mc, 0) / total_cols) * 100

            # 2. Format the value as a number (e.g., integer with ':.0f')
            #    and then append the escaped LaTeX percent sign
            line = fr'{model_names[mc]} = {percentage_val:.0f}\%'
            text_lines.append(line)

        xlabel_text = '\n'.join(text_lines)
        ax.set_xlabel(xlabel_text, fontsize=12, linespacing=1.5)

    # --- Add a rectangle to group the 4 iteration plots ---
    pos1 = axes[1].get_position() # Bbox of 'Bassa Iteration: 1'
    pos4 = axes[4].get_position() # Bbox of 'Bassa Iteration: 4'
    rect_x, rect_y = pos1.x0, pos1.y0
    rect_width = pos4.x1 - pos1.x0
    rect_height = pos1.height
    padding_x = 0.02
    padding_y = 0.31
    y_shift = 0.17

    rect = Rectangle(
        (rect_x - padding_x, rect_y - padding_y - y_shift),
        rect_width + (2 * padding_x),
        rect_height + (2 * padding_y),
        transform=fig.transFigure,
        facecolor='none',
        edgecolor='gray',
        linewidth=2,
        linestyle='--',
        clip_on=False
    )

    axes[0].add_patch(rect)

    pos0 = axes[0].get_position()

    # Calculate the vertical center point for the arrow
    y_center = pos0.y0 + pos0.height / 2

    # Define arrow start and end points in figure coordinates
    arrow_start_x = pos0.x1 + 0.025  # Right edge of the input plot + small gap
    arrow_end_x = rect.get_x() - 0.025 # Left edge of the rectangle - small gap

    # Create an arrow patch that exists on the FIGURE, not the AXES
    arrow = FancyArrowPatch(
        (arrow_start_x, y_center),  # Start point
        (arrow_end_x, y_center),    # End point
        transform=fig.transFigure,  # Use figure coordinates
        arrowstyle='<-',
        mutation_scale=15,          # Size of the arrow head
        lw=2,
        color='black'
    )
    # Add the arrow artist to the figure
    fig.add_artist(arrow)

    return fig, all_percentages


HEIGHT = 5
def create_survival_figure(all_percentages, model_names, colors):
    """Creates the 'Survival Plot' as a separate Matplotlib figure."""
    print("2a. Generating original survival plot figure...")
    fig, ax = plt.subplots(figsize=(4, HEIGHT), constrained_layout=True)
    iterations = range(1, 5)

    for model_code, percentages in all_percentages.items():
        ax.plot(iterations, percentages, marker='o', linestyle='-',
                color=colors[model_code], label=model_names[model_code], markersize=5)

    # --- Styling ---
    ax.set_title(r'Survival Plot', fontsize=14)
    ax.set_xlabel(r'Bassa Iteration', fontsize=12)
    ax.set_ylabel(r'Combination Inclusion (\%)', fontsize=10)
    ax.set_xticks(iterations)
    ax.set_ylim(0, 105)
    ax.legend(loc="center left", bbox_to_anchor=(1, 0.5), frameon=False)

    return fig


def create_filtered_survival_figure(all_percentages, model_names, colors):
    """Creates the 'Survival Plot' with only red (1) and blue (2) data."""
    print("2b. Generating filtered survival plot figure...")
    fig, ax = plt.subplots(figsize=(4, HEIGHT), constrained_layout=True)
    iterations = range(1, 5)
    filtered_model_codes = [1, 2] # Red and Blue

    for model_code in filtered_model_codes:
        percentages = all_percentages[model_code]
        ax.plot(iterations, percentages, marker='o', linestyle='-',
                color=colors[model_code], label=model_names[model_code], markersize=5)

    # --- Styling (Identical to the original) ---
    ax.set_title(r'Survival Plot', fontsize=14)
    ax.set_xlabel(r'Bassa Iteration', fontsize=12)
    ax.set_ylabel(r'Combination Inclusion (\%)', fontsize=10)
    ax.set_xticks(iterations)
    ax.set_ylim(0, 105)
    ax.legend(loc="center left", bbox_to_anchor=(1, 0.5), frameon=False)

    return fig


def create_arrow_figure():
    """Creates a figure containing just an arrow and text using FancyArrowPatch."""
    print("2c. Generating arrow figure...")
    fig, ax = plt.subplots(figsize=(2, 4), constrained_layout=True)

    # Create the arrow using FancyArrowPatch
    arrow = FancyArrowPatch(
        (0.1, 0.5),  # Start point in axes coordinates (from 0 to 1)
        (0.9, 0.5),  # End point in axes coordinates
        arrowstyle='->',
        mutation_scale=20,  # Controls the size of the arrowhead
        lw=2,
        color='black'
    )
    # Add the patch to the axes
    ax.add_patch(arrow)

    ax.text(0.5, 0.6, r"$t = 10\%$\\$min\_points$ = $3$",
            ha='center', va='center', fontsize=12)
    ax.axis('off')  # Hide the axes box and ticks
    return fig


# --- PIL Utility Functions ---
def convert_fig_to_pil(fig):
    """Converts a Matplotlib figure to a PIL Image object."""
    buf = io.BytesIO()
    fig.savefig(buf, format='png', bbox_inches='tight', pad_inches=0.1)
    buf.seek(0)
    img = Image.open(buf)
    return img


def add_padding_to_image(image, padding, bg_color='white'):
    """Adds padding (a border) to a PIL Image."""
    old_width, old_height = image.size
    new_width = old_width + 2 * padding
    new_height = old_height + 2 * padding
    padded_img = Image.new("RGB", (new_width, new_height), bg_color)
    padded_img.paste(image, (padding, padding))
    return padded_img


def stack_images_horizontally(images, bg_color='white'):
    """Sticks a list of PIL images together in a single row."""
    widths, heights = zip(*(i.size for i in images))
    total_width = sum(widths)
    max_height = max(heights)

    combined_img = Image.new('RGB', (total_width, max_height), color=bg_color)
    x_offset = 0
    for img in images:
        y_offset = (max_height - img.height) // 2 # Center vertically
        combined_img.paste(img, (x_offset, y_offset))
        x_offset += img.width

    return combined_img


def stack_images_vertically(top_image, bottom_image, bg_color='white', bottom_align='center', padding=0):
    """
    Sticks two PIL images together vertically with alignment options for the bottom image.

    Args:
        top_image (PIL.Image): The image for the top.
        bottom_image (PIL.Image): The image for the bottom.
        bg_color (str): Background color for the new image canvas.
        bottom_align (str): Horizontal alignment for the bottom image: 'left', 'center', or 'right'.
        padding (int): Horizontal padding to apply for 'left' or 'right' alignment.
    """
    # Create a new canvas that is wide enough for the widest image and tall enough for both
    new_width = max(top_image.width, bottom_image.width)
    new_height = top_image.height + bottom_image.height
    combined_img = Image.new("RGB", (new_width, new_height), bg_color)

    # Paste the top image, always centered horizontally
    top_x = (new_width - top_image.width) // 2
    combined_img.paste(top_image, (top_x, 0))

    # Calculate the x-coordinate for the bottom image based on the desired alignment
    if bottom_align == 'left':
        bottom_x = padding
    elif bottom_align == 'right':
        bottom_x = new_width - bottom_image.width - padding
    else:  # Default to 'center'
        bottom_x = (new_width - bottom_image.width) // 2

    # Paste the bottom image at its calculated position
    combined_img.paste(bottom_image, (bottom_x, top_image.height))

    return combined_img


def add_latex_title_to_image(image, title_text, font_size=32, space_above=20, space_below=10, bg_color='white',
                             subtitle_text=None, subtitle_font_size=12, space_between=5):
    """
    Adds a centered LaTeX title and an optional subtitle (as images) above a base PIL Image.
    """
    # 1. Create the main title image using our Matplotlib helper
    title_img = create_latex_title_image(title_text, fontsize=font_size)
    header_img = title_img  # Default header is just the title

    # 2. If a subtitle is provided, create it and combine it with the title
    if subtitle_text:
        subtitle_img = create_latex_title_image(subtitle_text, fontsize=subtitle_font_size)

        # Create a new canvas for the combined header (title + subtitle)
        header_width = max(title_img.width, subtitle_img.width)
        header_height = title_img.height + space_between + subtitle_img.height
        combined_header = Image.new("RGBA", (header_width, header_height)) # Keep RGBA for transparency

        # Paste title (centered)
        title_x = (header_width - title_img.width) // 2
        combined_header.paste(title_img, (title_x, 0), title_img)

        # Paste subtitle (centered)
        subtitle_y = int(title_img.height / 1.5) + space_between
        subtitle_x = (header_width - subtitle_img.width) // 2
        combined_header.paste(subtitle_img, (subtitle_x, subtitle_y), subtitle_img)

        header_img = combined_header # The new header is the combined image

    # 3. Calculate dimensions for the final canvas (with the base image)
    total_header_height = header_img.height + space_above + space_below
    new_width = max(image.width, header_img.width)
    new_height = image.height + total_header_height

    # 4. Create the final canvas
    color_rgb = ImageColor.getrgb(bg_color)
    titled_image = Image.new("RGBA", (new_width, new_height), (*color_rgb, 255))

    # 5. Paste the header image (which could be title-only or title+subtitle)
    header_x = (new_width - header_img.width) // 2
    header_y = space_above
    titled_image.paste(header_img, (header_x, header_y), header_img)

    # 6. Paste the original image below it
    image_x = (new_width - image.width) // 2
    image_y = total_header_height
    titled_image.paste(image, (image_x, image_y))

    return titled_image

def create_latex_title_image(title_text, fontsize=32, dpi=150):
    """
    Creates a transparent PIL image of a title rendered using Matplotlib/LaTeX.

    Args:
        title_text (str): The LaTeX-formatted string to render.
        fontsize (int): The font size.
        dpi (int): The resolution of the output image.

    Returns:
        PIL.Image: A transparent PIL image containing the rendered text.
    """
    # Create a figure just for the text. The initial size is arbitrary
    # as we will use bbox_inches='tight' to crop it perfectly.
    fig = plt.figure(figsize=(6, 1), dpi=dpi)
    fig.text(0.5, 0.5, title_text, ha='center', va='center', fontsize=fontsize)

    # Save the figure to an in-memory buffer
    buf = io.BytesIO()
    # 'transparent=True' is key to making a clean image for pasting
    fig.savefig(buf, format='png', bbox_inches='tight', pad_inches=0.1, transparent=True)
    plt.close(fig)  # Close the figure to free up memory
    buf.seek(0)

    # Create a PIL image from the buffer
    img = Image.open(buf)
    return img


def orchestrate_plot_creation():
    """
    Main orchestration function to generate, combine, and display all plots.
    """
    _setup_matplotlib_style()

    # --- Generate Matplotlib Figures ---
    mcmc_fig, percentages = create_mcmc_figure(S_MATRIX, FEATURE_NAMES, MODEL_NAMES, COLORS)
    survival_fig = create_survival_figure(percentages, MODEL_NAMES, COLORS)
    filtered_survival_fig = create_filtered_survival_figure(percentages, MODEL_NAMES, COLORS)
    arrow_fig = create_arrow_figure()

    # --- Convert to PIL and Combine ---
    print("3. Converting figures to PIL images...")
    mcmc_pil = convert_fig_to_pil(mcmc_fig)
    survival_pil = convert_fig_to_pil(survival_fig)
    filtered_survival_pil = convert_fig_to_pil(filtered_survival_fig)
    arrow_pil = convert_fig_to_pil(arrow_fig)

    print("3a. Adding 'Step 1 - Survival Process' LaTeX title...")
    mcmc_pil = add_latex_title_to_image(
        mcmc_pil,
        title_text=r'\textbf{Step 1 - Survival Process}',
        subtitle_text=r'We iterate over the MCMC samples, each iteration with a growing number of features, ordered by occurrence in the chain. In here, $N_f=4$.',
        font_size=16,  # Title font size
        subtitle_font_size=11,  # Subtitle font size
        space_below=5
    )

    # Close original matplotlib figures to prevent double display
    plt.close('all')

    print("4. Assembling bottom row (plot -> arrow -> plot)...")
    bottom_row_pil = stack_images_horizontally([survival_pil, arrow_pil, filtered_survival_pil])

    # --- UPDATED: Add LaTeX Title for Step 2 ---
    text = r"""
    \begin{center}We see the survival plot, and prune models that fall below thresholds. \\Model $s_1$, $s_2$, $s_3$ falls below the 3 point threshold, and is pruned.\\Model $s_1$, $s_4$ is below the 10\% (and the minimum required points), and is also pruned. \end{center}
    """

    print("4a. Adding 'Step 2 - Pruning' LaTeX title...")
    bottom_row_pil = add_latex_title_to_image(
        bottom_row_pil,
        title_text=r'\textbf{Step 2 - Pruning}',
        subtitle_text=text,
        font_size=16,
        subtitle_font_size=11,
        space_above=0,
        space_below=0,
        space_between=0,
    )

    print("6. Stacking images vertically with left alignment...")
    final_image = stack_images_vertically(
        mcmc_pil,
        bottom_row_pil,
        bottom_align='left',
        padding=50  # This adds the space on the left
    )

    # --- Display Final Result ---
    # This section remains mostly the same, just with the updated title logic for the Bassa plot
    print("Done! Displaying final combined image.")
    final_image.save('combined_plot.png')

    clean2 = [x for x in percentages[2] if x == x]
    s_1 = SurvivalSample(name=r's_1', y_values=percentages[1], x_values=[1, 2, 3, 4], r2=0.7, num_features=1,
                         feature_names=[r's_1'], q2=0, mse=0, mae=0, ratio=0)
    s_2 = SurvivalSample(name=r's_1, s_2', y_values=clean2, x_values=[2, 3, 4], r2=0.86, num_features=2,
                         feature_names=[r's_1', r's_2'], q2=0, mse=0, mae=0, ratio=0)
    ls = [s_1, s_2]
    ratios = pd.DataFrame({
        'feature_name': [r's_1', r's_2'],
        'relative_occurrence': [1.0, 0.7],
    })
    abs_dir = os.path.dirname(os.path.abspath(__file__))
    generate_bassa_plot(ls, SurvivalMetric.R2, ratios, path=abs_dir)

    print("\n--- Starting final combination step ---")
    bassa_plot_path = os.path.join(abs_dir, 'bassa_plot.png')

    # --- 7. Load, Resize, and Combine Final Bassa Plot ---
    print("\n--- Starting final combination step ---")
    bassa_plot_path = os.path.join(abs_dir, 'bassa_plot.png')

    try:
        print(f"7. Loading bassa plot from: {bassa_plot_path}")
        bassa_pil = Image.open(bassa_plot_path)

    except FileNotFoundError:
        print(f"Error: Could not find {bassa_plot_path}. Aborting final combination.")
        return

    # --- 8. Calculate the target position and size ---
    print("8. Calculating position and size for the bassa plot...")
    mcmc_height = mcmc_pil.height
    bottom_row_width = bottom_row_pil.width
    final_width, final_height = final_image.size

    left_padding = 50
    margin = 40

    paste_area_x_start = left_padding + bottom_row_width + margin
    paste_area_y_start = mcmc_height + margin

    available_width = final_width - paste_area_x_start - left_padding
    available_height = final_height - paste_area_y_start - margin

    # --- LOGIC CHANGE START ---

    # 8a. Resize the plot FIRST, before adding any title.
    resized_bassa_plot = bassa_pil.copy()

    bassa_plot_scale_factor = 0.95
    target_width = int(available_width * bassa_plot_scale_factor)
    target_height = int(available_height * bassa_plot_scale_factor)

    resized_bassa_plot.thumbnail((target_width, target_height), Image.Resampling.LANCZOS)
    print(f"   - Resized bassa plot to: {resized_bassa_plot.width}x{resized_bassa_plot.height}")

    # 8b. NOW, add the title to the already-resized plot.
    # The title's font size will now be constant and unaffected by the thumbnail scaling.
    print("8c. Adding LaTeX title to the resized plot...")
    final_bassa_component = add_latex_title_to_image(
        resized_bassa_plot,
        title_text=r'\textbf{Step 3 - Final BASSA Plot}',
        subtitle_text=r'The final BASSA plot after pruning, with the $R^2$ values of every model.',
        font_size=14,
        subtitle_font_size=10,
        space_above=5,
        space_below=5,
        space_between=1,
    )

    # 8d. Recalculate the final paste coordinates to center the new component (title + plot)
    # within the available area.
    paste_x = paste_area_x_start + (available_width - final_bassa_component.width) // 2
    paste_y = paste_area_y_start + (available_height - final_bassa_component.height) // 2
    print(f"   - Final paste coordinates (x, y): ({paste_x}, {paste_y})")

    # --- LOGIC CHANGE END ---

    # --- 9. Paste the final component onto the main canvas ---
    print("9. Pasting final component onto the main image canvas...")
    # The final_bassa_component is an RGBA image due to the transparent title background.
    # We paste it using its alpha channel as a mask for clean blending.
    final_image.paste(final_bassa_component, (paste_x, paste_y), final_bassa_component)

    # --- 10. Save the final composite image ---
    final_composite_path = 'fully_combined_plot.png'
    print(f"10. Saving the final composite image to '{final_composite_path}'")
    final_image.save(final_composite_path)

    # --- Optional: Clean up intermediate files ---
    print("11. Cleaning up intermediate files...")
    os.remove('combined_plot.png')
    os.remove(bassa_plot_path)

    print("\nOrchestration complete! ✨")


# --- Run the Orchestration ---
if __name__ == '__main__':
    orchestrate_plot_creation()