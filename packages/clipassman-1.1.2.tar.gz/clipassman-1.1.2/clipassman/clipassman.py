# Copyright © 2025, Alexander Suvorov
from clipassman.app_manager import AppManager


def main():
    app_manager = AppManager()
    app_manager.run()
