from enum import StrEnum
from enum import unique


@unique
class BrowserAddonExtensionEnum(StrEnum):
	FIREFOX=".xpi"
