## v0.2.0 (2025-09-27)

### Feat

- initial release of duplicaid CLI tool

### Fix

- update uv version in workflow
- resolve all test failures for CI pipeline
- resolve test failures in CI workflow
- configure Git identity for automated releases
- add --yes flag to commitizen commands for CI
- add OIDC permissions and fix build step logic
- workflow dependency issue preventing releases
