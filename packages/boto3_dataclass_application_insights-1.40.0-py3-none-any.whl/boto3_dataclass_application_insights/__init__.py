# -*- coding: utf-8 -*-

from .caster import application_insights_caster

caster = application_insights_caster

__version__ = "1.40.0"