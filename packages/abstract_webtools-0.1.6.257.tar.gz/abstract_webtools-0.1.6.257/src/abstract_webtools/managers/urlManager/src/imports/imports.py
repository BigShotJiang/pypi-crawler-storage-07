from urllib.parse import urlparse, urljoin
from abstract_utilities import eatAll
import socket
