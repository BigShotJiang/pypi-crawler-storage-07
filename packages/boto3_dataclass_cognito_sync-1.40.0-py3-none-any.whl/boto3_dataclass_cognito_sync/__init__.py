# -*- coding: utf-8 -*-

from .caster import cognito_sync_caster

caster = cognito_sync_caster

__version__ = "1.40.0"