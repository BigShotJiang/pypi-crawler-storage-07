# Referencia de la API

::: py_lerchs_grossmann
