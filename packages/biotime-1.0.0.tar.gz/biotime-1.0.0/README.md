# Biotime Client

Python client for Biotime API.

## Installation

```bash
pip install biotime
