from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="PaginatedResultCategoryResultsItem")


@_attrs_define
class PaginatedResultCategoryResultsItem:
    """
    Example:
        {'page': 1, 'pageSize': 10, 'results': [{'ancestors': 'ENERGY_SOURCES/ELECTRICITY', 'name': 'ELECTRICITY'},
            {'ancestors': 'ENERGY_SOURCES/GAS', 'name': 'GAS'}], 'total': 50}

    Attributes:
        ancestors (str):
        name (str):
    """

    ancestors: str
    name: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        ancestors = self.ancestors

        name = self.name

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "ancestors": ancestors,
                "name": name,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        ancestors = d.pop("ancestors")

        name = d.pop("name")

        paginated_result_category_results_item = cls(
            ancestors=ancestors,
            name=name,
        )

        paginated_result_category_results_item.additional_properties = d
        return paginated_result_category_results_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
