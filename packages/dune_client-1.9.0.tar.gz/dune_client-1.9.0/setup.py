# Legacy setup.py for backward compatibility
# All configuration is now in pyproject.toml
import setuptools

if __name__ == "__main__":
    setuptools.setup()
