## Installation

```
pip install bigwig-io
```

Requires numpy and pybind11.

## Usage

### Read bigWig and bigBed header

```python
reader = bigwig_io.Reader(path)
print(reader.main_header, reader.zoom_headers, reader.auto_sql, reader.total_summary)
print(reader.chr_sizes)
print(reader.type)
```

Content:
- `main_header` General file formatting info.
- `zoom_headers` Zooms levels info (reduction level and location).
- `auto_sql` BED entries declaration (only in bigBed).
- `total_summary` Statistical summary of entire file values (coverage, sums and extremes).
- `chr_sizes` Chromosomes IDs and sizes.
- `type` Either "bigwig" or "bigbed".

### Read signal

```python
values = reader.read_signal(chr_ids, start, span)
```

Parameters:
- `chr_ids` `starts` Chromosomes ids and starts of locations.
- `span` Reading window in bp from locations starts. 1 by default.
- `bin_size` Output bin size in bp. 1 by default.
- `bin_mode` Method to aggregate bin values. Either "mean", "sum" or "single" (one randomly selected value per bin). "mean" by default.
- `full_bin` Extend locations starts and ends to overlapping bins if true. Not by default.
- `def_value` Default value to use when no data overlap a bin. 0 by default.
- `zoom` BigWig zoom level to use. Use full data if -1. Auto-detect the best level if 0 by selecting the larger level whose bin size is lower that the third of `bin_size` (may be the full data). 0 by default.
- `progress` Function called during data extraction. Takes the extracted coverage and the total coverage in bp as parameters. None by default.

Returns a numpy float32 array of shape (locations, span//bin_size).

### Quantify signal

```python
values = reader.quantify(chr_ids, start, span)
values = reader.quantify(chr_ids, start, ends)
```

Parameters:
- `chr_ids` `starts` `span` `def_value` `zoom` `progress` Identical to `read_signal` method.
- `ends` Ends of locations. Takes precedence over `span` is specified. None by default.
- `reduce` Method to aggregate values over span. Either "mean", "sd", "sem", "sum", "min" or "max". "mean" by default.

Returns a numpy float32 array of shape (locations).

### Profile signal

```python
values = reader.profile(chr_ids, start, span)
```

Parameters:
- `chr_ids` `starts` `span` `bin_size` `bin_mode` `full_bin` `def_value` `zoom` `progress` Identical to `read_signal` method.
- `reduce` Method to aggregate values over locations. Either "mean", "sd", "sem", "sum", "min" or "max". "mean" by default.

Returns a numpy float32 array of shape (span//bin_size).

### Read bigBed entries

```python
values = reader.read_entries(chr_ids, start, span)
values = reader.read_entries(chr_ids, start, ends)
```

Parameters:
- `chr_ids` `starts` Chromosomes ids and starts of locations.
- `span` Reading window in bp from locations starts. 1 by default.
- `ends` Ends of locations. Takes precedence over `span` is specified. None by default.
- `progress` Function called during data extraction. Takes the extracted coverage and the total coverage in bp as parameters. None by default.

Returns a list (locations) of list of entries (dict with at least "chr", "start" and "end" keys).

### Convert bigWig to bedGraph or WIG

```python
reader.to_bedgraph(output_path)
reader.to_wig(output_path)
```

Parameters:
- `output_path` Path to output file.
- `chr_ids` Only extract data from these chromomes. All by default.
- `zoom` Zoom level to use. Full data by default.
- `progress` Function called during data extraction. Takes the extracted coverage and the total coverage in bp as parameters. None by default.

### Convert bigBed to BED

```python
reader.to_bed(output_path)
```

Parameters:
- `output_path` `chr_ids` `progress` Identical to `to_bedgraph` and `to_wig` methods.
- `col_count` Only write this number of columns (eg, 3 for chr, start and end). All by default.
