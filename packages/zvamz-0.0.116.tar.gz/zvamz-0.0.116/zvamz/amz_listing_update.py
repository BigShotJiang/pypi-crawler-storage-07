import requests
from datetime import datetime, timezone, timedelta
import json
from .ratelimit import RateLimiter
from .api import get_sellerId

def raw_sku_attributes(marketplace_action, access_token, sku):
    """
    This will pull SKU attributes in specific Marketplace.

    Parameter:
    - marketplace_action: the specific marketplace command to pull the data
    - access_token: matching access token of the marketplace
    - sku: SKU to pull the attribute details

    return:
    - json format of the SKU attributes
    """
    # get sellerID
    try:
        sellerId = get_sellerId(marketplace_action, access_token, sku)
    except KeyError as e:
        raise ValueError(f'❌ Error in getting sellerID: {e}')

    # API Pull
    rate_limiter = RateLimiter(tokens_per_second=5, capacity=10)
    regionUrl, marketplace_id = marketplace_action()

    url = regionUrl + f'/listings/2021-08-01/items/{sellerId}/{sku}'
    headers = {
            'x-amz-access-token': access_token
        }

    request_params  = {
        'marketplaceIds': marketplace_id,
        'includedData': 'attributes'
    }

    try:
        response =  rate_limiter.send_request(requests.get, url, headers=headers, params=request_params)
        return json.dumps(response.json(), indent=4)
    except Exception as e:
        raise ValueError(f'{response.status_code} - {response.text}')

def get_productType(marketplace_action, access_token, sellerId, sku):
    """
    This will pull SKU productType in specific Marketplace.

    Parameter:
    - marketplace_action: the specific marketplace command to pull the data
    - access_token: matching access token of the marketplace
    - sellerId: sellerId of the account
    - sku: SKU to pull the attribute details

    return:
    - productType of the SKU
    """
    # get productType
    print('Getting product type...')
    try:
        region_url, marketplace = marketplace_action()
        endpoint = f"/listings/2021-08-01/items/{sellerId}/{sku}?marketplaceIds={marketplace}&includedData=summaries"
        url = region_url + endpoint

        headers = {
            "accept": "application/json",
            "x-amz-access-token": access_token
            }
        response = requests.get(url, headers=headers)
        productType = response.json()['summaries'][0]['productType']
        print(f'SKU product type is: {productType}')
        return productType
    except KeyError as e:
        raise ValueError(f'❌ Error getting product type: {e}')

def patch_builder(updates):
    """
    This will create the correct patch in updating product attributes base on available data.

    Parameter:
    - updates: json format of sku and update values
        e.g.: {'sku': 'SMAPLE-SKU', 'salePrice': 55.99, 'main_image_url': 'https://m.public.com/images/A/yourimage.jpg'}

    return:
    - json format patch data
    """
    # set sale dates
    start_date = datetime.now(timezone.utc).isoformat()
    end_date = (datetime.now(timezone.utc) + timedelta(days=365)).isoformat()

    patches = []

    # sale price patch
    if 'salePrice' in updates:
        salePrice = updates['salePrice']
        patches.append(
                {
                    "op": "replace",
                    "path": "/attributes/purchasable_offer",
                    "value": [
                        {
                            "discounted_price": [
                                {
                                    "schedule": [
                                        {
                                          "end_at": f"{end_date}",
                                          "start_at": f"{start_date}",
                                          "value_with_tax": salePrice
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
        )

    if 'main_image_url' in updates:
        main_image_url = updates['main_image_url']
        patches.append(
                {
                    "op": "replace",
                    "path": "/attributes/main_product_image_locator",
                    "value": [
                        {
                            "media_location": f"{main_image_url}"
                        }
                    ]
                }
        )
    return patches

def update_sku_attributes(marketplace_action, access_token, updates):
    """
    This will update SKU attirbutes in specific Marketplace.

    Parameter:
    - marketplace_action: the specific marketplace command to pull the data
    - access_token: matching access token of the marketplace
    - updates: json format of sku and update values
        e.g.: {'sku': 'SMAPLE-SKU', 'salePrice': 55.99, 'main_image_url': 'https://m.public.com/images/A/yourimage.jpg'}

    return:
    - product update status
    """
    # get update values
    sku = updates['sku']
    salePrice = updates.get('salePrice')
    main_image_url = updates.get('main_image_url')

    # get sellerId
    print('Getting seller ID...')
    try:
        sellerId = get_sellerId(marketplace_action, access_token, sku)
    except KeyError as e:
        raise ValueError(f'❌ Error getting seller ID: {e}')

    # get productType
    productType = get_productType(marketplace_action, access_token, sellerId, sku)

    # set sale dates
    start_date = datetime.now(timezone.utc).isoformat()
    end_date = (datetime.now(timezone.utc) + timedelta(days=365)).isoformat()

    # update sale price
    region_url, marketplaceId = marketplace_action()
    endpoint = f"/listings/2021-08-01/items/{sellerId}/{sku}?marketplaceIds={marketplaceId}&includedData=issues"
    url = region_url + endpoint

    # get patches
    patches = patch_builder(updates)

    payload = {
        "patches": patches,
        "productType": f"{productType}"
    }
    headers = {
        "accept": "application/json",
        "content-type": "application/json",
        "x-amz-access-token": access_token
    }

    response = requests.patch(url, json=payload, headers=headers)
    if response.status_code == 200:
        msg_parts = [f"✅ Success:\n  - sku: {sku}"]
        if salePrice:
            msg_parts.append(f"  - Sale Price set to: ${salePrice}")

        if main_image_url:
            msg_parts.append(f"  - Main Image set to: {main_image_url}")

        msg_parts.append(f"  - Submission ID: {response.json()['submissionId']}")

        success_message = "\n".join(msg_parts)
        return print(success_message)
    else:
        raise ValueError(f"❌ Error: {json.dumps(response.json(), indent=4)}")
    
