# -*- coding: utf-8 -*-

from .caster import bedrock_agentcore_caster

caster = bedrock_agentcore_caster

__version__ = "1.40.0"