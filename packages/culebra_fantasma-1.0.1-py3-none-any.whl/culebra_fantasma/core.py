"""
Culebra Fantasma Core - Funciones principales traducidas
=======================================================

Este módulo contiene las funciones built-in de Python traducidas al español.
Proporciona una interfaz completa para trabajar con tipos de datos,
operaciones matemáticas y utilidades básicas.
"""

# ============================================================================
# CONSTANTES BOOLEANAS TRADUCIDAS AL ESPAÑOL
# ============================================================================

Verdadero = True
Falso = False
Ninguno = None

# ============================================================================
# FUNCIONES INTERNAS (BUILT-IN) TRADUCIDAS AL ESPAÑOL
# ============================================================================

# Funciones de entrada/salida
imprimir = print
entrada = input

# Funciones de apertura de archivos
abrir = open

# Funciones de tipo y conversión
tipo = type
cadena = str
entero = int
flotante = float
lista = list
diccionario = dict
conjunto = set
tupla = tuple

# Funciones matemáticas básicas
longitud = len
maximo = max
minimo = min
suma = sum
absoluto = abs
redondear = round

# Funciones de verificación
es_instancia = isinstance

# Funciones de iteración
rango = range
enumerar = enumerate
zip_func = zip
revertir = reversed
ordenar = sorted

# Funciones de trabajo con texto
formato = format
mayusculas = str.upper
minusculas = str.lower
capitalizar = str.capitalize
titulo = str.title

# Funciones de listas avanzadas
filtrar = filter
mapear = map
cualquier = any
todo = all

# Funciones de atributos y métodos
tiene_atributo = hasattr
obtener_atributo = getattr
establecer_atributo = setattr
eliminar_atributo = delattr

# Funciones de ejecución
ejecutar = eval
compilar = compile

# Funciones especiales
dir_func = dir
ayuda = help
id_func = id
hash_func = hash

# ============================================================================
# FUNCIONES MATEMÁTICAS AVANZADAS
# ============================================================================

import math

seno = math.sin
coseno = math.cos
tangente = math.tan
logaritmo = math.log
logaritmo10 = math.log10
exponencial = math.exp
raiz_cuadrada = math.sqrt
potencia = math.pow
factorial = math.factorial
pi_numero = math.pi
euler_numero = math.e

# Funciones trigonométricas inversas
arco_seno = math.asin
arco_coseno = math.acos
arco_tangente = math.atan

# Funciones hiperbólicas
seno_hiperbolico = math.sinh
coseno_hiperbolico = math.cosh
tangente_hiperbolico = math.tanh

# Funciones matemáticas adicionales
techo = math.ceil
piso = math.floor
truncar = math.trunc
grado_a_radian = math.radians
radian_a_grado = math.degrees

# ============================================================================
# FUNCIONES DE FECHA Y HORA
# ============================================================================

import datetime

fecha_actual = datetime.date.today
hora_actual = datetime.datetime.now
fecha_hora_actual = datetime.datetime.now

def crear_fecha(ano, mes, dia):
    """Crea un objeto fecha."""
    return datetime.date(ano, mes, dia)

def crear_hora(hora, minuto, segundo):
    """Crea un objeto hora."""
    return datetime.time(hora, minuto, segundo)

def crear_fecha_hora(ano, mes, dia, hora=0, minuto=0, segundo=0):
    """Crea un objeto fecha y hora."""
    return datetime.datetime(ano, mes, dia, hora, minuto, segundo)

def dia_semana(fecha):
    """Obtiene el día de la semana."""
    return fecha.weekday()

def nombre_dia(fecha):
    """Obtiene el nombre del día de la semana."""
    dias = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]
    return dias[fecha.weekday()]

def nombre_mes(fecha):
    """Obtiene el nombre del mes."""
    meses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
             "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]
    return meses[fecha.month - 1]

# ============================================================================
# FUNCIONES DE ARCHIVOS
# ============================================================================

def leer_archivo(nombre_archivo, modo="r", codificacion="utf-8"):
    """Lee el contenido de un archivo."""
    with open(nombre_archivo, modo, encoding=codificacion) as archivo:
        return archivo.read()

def escribir_archivo(nombre_archivo, contenido, modo="w", codificacion="utf-8"):
    """Escribe contenido en un archivo."""
    with open(nombre_archivo, modo, encoding=codificacion) as archivo:
        archivo.write(contenido)

def agregar_archivo(nombre_archivo, contenido, codificacion="utf-8"):
    """Agrega contenido al final de un archivo."""
    with open(nombre_archivo, "a", encoding=codificacion) as archivo:
        archivo.write(contenido)

def existe_archivo(nombre_archivo):
    """Verifica si existe un archivo."""
    import os
    return os.path.exists(nombre_archivo)

def tamano_archivo(nombre_archivo):
    """Obtiene el tamaño de un archivo en bytes."""
    import os
    return os.path.getsize(nombre_archivo)

def eliminar_archivo(nombre_archivo):
    """Elimina un archivo."""
    import os
    if existe_archivo(nombre_archivo):
        os.remove(nombre_archivo)
        return Verdadero
    return Falso

# ============================================================================
# FUNCIONES DE CADENAS AVANZADAS
# ============================================================================

def buscar(texto, subcadena, inicio=0, fin=None):
    """Busca una subcadena en un texto."""
    return texto.find(subcadena, inicio, fin)

def reemplazar(texto, viejo, nuevo, conteo=None):
    """Reemplaza texto en una cadena."""
    return texto.replace(viejo, nuevo, conteo)

def dividir_texto(texto, separador=None, maximo=None):
    """Divide texto en una lista."""
    return texto.split(separador, maximo)

def unir_texto(lista_palabras, separador=" "):
    """Une una lista de palabras con un separador."""
    return separador.join(lista_palabras)

def contar_subcadena(texto, subcadena):
    """Cuenta cuántas veces aparece una subcadena."""
    return texto.count(subcadena)

def es_mayuscula(texto):
    """Verifica si el texto está en mayúsculas."""
    return texto.isupper()

def es_minuscula(texto):
    """Verifica si el texto está en minúsculas."""
    return texto.islower()

def es_titulo(texto):
    """Verifica si el texto está en formato título."""
    return texto.istitle()

def es_numerico(texto):
    """Verifica si el texto representa un número."""
    return texto.isnumeric()

def es_alfabetico(texto):
    """Verifica si el texto contiene solo letras."""
    return texto.isalpha()

def es_alfanumerico(texto):
    """Verifica si el texto contiene letras y números."""
    return texto.isalnum()

def comenzar_con(texto, prefijo):
    """Verifica si el texto comienza con un prefijo."""
    return texto.startswith(prefijo)

def terminar_con(texto, sufijo):
    """Verifica si el texto termina con un sufijo."""
    return texto.endswith(sufijo)

def remover_espacios(texto, lado=None):
    """Remueve espacios en blanco."""
    if lado == "izquierda":
        return texto.lstrip()
    elif lado == "derecha":
        return texto.rstrip()
    else:
        return texto.strip()

# ============================================================================
# FUNCIONES DE LISTAS AVANZADAS
# ============================================================================

def insertar_elemento(lista_original, indice, elemento):
    """Inserta un elemento en una posición específica."""
    lista_original.insert(indice, elemento)
    return lista_original

def remover_elemento(lista_original, elemento):
    """Remueve la primera ocurrencia de un elemento."""
    if elemento in lista_original:
        lista_original.remove(elemento)
    return lista_original

def invertir_lista(lista_original):
    """Invierte el orden de una lista."""
    return lista_original[::-1]

def encontrar_indice(lista_original, elemento, inicio=0, fin=None):
    """Encuentra el índice de un elemento."""
    try:
        return lista_original.index(elemento, inicio, fin)
    except ValueError:
        return -1

def contar_elementos(lista_original, elemento):
    """Cuenta cuántas veces aparece un elemento."""
    return lista_original.count(elemento)

def extender_lista(lista_original, otra_lista):
    """Extiende una lista con otra lista."""
    lista_original.extend(otra_lista)
    return lista_original

def limpiar_lista(lista_original):
    """Remueve todos los elementos de una lista."""
    lista_original.clear()
    return lista_original

def copiar_lista(lista_original):
    """Crea una copia superficial de una lista."""
    return lista_original.copy()

def lista_comprension(funcion, iterable):
    """Aplica una función a cada elemento de un iterable."""
    return [funcion(x) for x in iterable]

# ============================================================================
# FUNCIONES DE DICCIONARIOS AVANZADAS
# ============================================================================

def obtener_claves(diccionario_original):
    """Obtiene todas las claves de un diccionario."""
    return list(diccionario_original.keys())

def obtener_valores(diccionario_original):
    """Obtiene todos los valores de un diccionario."""
    return list(diccionario_original.values())

def obtener_elementos(diccionario_original):
    """Obtiene todos los pares clave-valor."""
    return list(diccionario_original.items())

def actualizar_diccionario(diccionario_original, otro_diccionario):
    """Actualiza un diccionario con otro."""
    diccionario_original.update(otro_diccionario)
    return diccionario_original

def obtener_valor_predeterminado(diccionario_original, clave, valor_predeterminado=None):
    """Obtiene un valor con valor predeterminado."""
    return diccionario_original.get(clave, valor_predeterminado)

def establecer_predeterminado(diccionario_original, clave, valor_predeterminado):
    """Establece un valor predeterminado si la clave no existe."""
    return diccionario_original.setdefault(clave, valor_predeterminado)

def eliminar_clave(diccionario_original, clave):
    """Elimina una clave del diccionario."""
    if clave in diccionario_original:
        del diccionario_original[clave]
        return Verdadero
    return Falso

def copiar_diccionario(diccionario_original):
    """Crea una copia superficial de un diccionario."""
    return diccionario_original.copy()

def limpiar_diccionario(diccionario_original):
    """Remueve todos los elementos de un diccionario."""
    diccionario_original.clear()
    return diccionario_original

# ============================================================================
# FUNCIONES DE CONJUNTOS AVANZADAS
# ============================================================================

def union_conjuntos(conjunto1, conjunto2):
    """Une dos conjuntos."""
    return conjunto1 | conjunto2

def interseccion_conjuntos(conjunto1, conjunto2):
    """Obtiene la intersección de dos conjuntos."""
    return conjunto1 & conjunto2

def diferencia_conjuntos(conjunto1, conjunto2):
    """Obtiene la diferencia entre conjuntos."""
    return conjunto1 - conjunto2

def diferencia_simetrica(conjunto1, conjunto2):
    """Obtiene la diferencia simétrica entre conjuntos."""
    return conjunto1 ^ conjunto2

def es_subconjunto(conjunto1, conjunto2):
    """Verifica si un conjunto es subconjunto de otro."""
    return conjunto1 <= conjunto2

def es_superconjunto(conjunto1, conjunto2):
    """Verifica si un conjunto es superconjunto de otro."""
    return conjunto1 >= conjunto2

def agregar_elemento_conjunto(conjunto_original, elemento):
    """Agrega un elemento a un conjunto."""
    conjunto_original.add(elemento)
    return conjunto_original

def remover_elemento_conjunto(conjunto_original, elemento):
    """Remueve un elemento de un conjunto."""
    conjunto_original.discard(elemento)
    return conjunto_original

def limpiar_conjunto(conjunto_original):
    """Remueve todos los elementos de un conjunto."""
    conjunto_original.clear()
    return conjunto_original

def copiar_conjunto(conjunto_original):
    """Crea una copia de un conjunto."""
    return conjunto_original.copy()

# ============================================================================
# FUNCIONES DE SISTEMA Y OS
# ============================================================================

import os
import sys

def directorio_actual():
    """Obtiene el directorio de trabajo actual."""
    return os.getcwd()

def cambiar_directorio(ruta):
    """Cambia el directorio de trabajo."""
    os.chdir(ruta)

def listar_directorio(ruta="."):
    """Lista los archivos en un directorio."""
    return os.listdir(ruta)

def crear_directorio(ruta):
    """Crea un directorio."""
    os.makedirs(ruta, exist_ok=Verdadero)

def eliminar_directorio(ruta):
    """Elimina un directorio."""
    import shutil
    if os.path.exists(ruta):
        shutil.rmtree(ruta)
        return Verdadero
    return Falso

def ruta_absoluta(ruta):
    """Obtiene la ruta absoluta."""
    return os.path.abspath(ruta)

def ruta_base(ruta):
    """Obtiene el nombre base de una ruta."""
    return os.path.basename(ruta)

def ruta_directorio(ruta):
    """Obtiene el directorio de una ruta."""
    return os.path.dirname(ruta)

def unir_rutas(*rutas):
    """Une múltiples rutas."""
    return os.path.join(*rutas)

def nombre_archivo(ruta):
    """Obtiene el nombre del archivo sin extensión."""
    return os.path.splitext(os.path.basename(ruta))[0]

def extension_archivo(ruta):
    """Obtiene la extensión del archivo."""
    return os.path.splitext(ruta)[1]

def es_archivo(ruta):
    """Verifica si una ruta es un archivo."""
    return os.path.isfile(ruta)

def es_directorio(ruta):
    """Verifica si una ruta es un directorio."""
    return os.path.isdir(ruta)

def tamano_archivo_bytes(ruta):
    """Obtiene el tamaño de un archivo en bytes."""
    return os.path.getsize(ruta)

def ultima_modificacion(ruta):
    """Obtiene la fecha de última modificación."""
    return os.path.getmtime(ruta)

# ============================================================================
# FUNCIONES DE TIEMPO Y RETRASO
# ============================================================================

import time

def dormir(segundos):
    """Pausa la ejecución por segundos."""
    time.sleep(segundos)

def tiempo_actual():
    """Obtiene el tiempo actual en segundos."""
    return time.time()

def tiempo_formateado(formato="%Y-%m-%d %H:%M:%S"):
    """Obtiene el tiempo formateado."""
    return time.strftime(formato)

def tiempo_desde_epoca():
    """Obtiene el tiempo desde la época Unix."""
    return time.time()

# ============================================================================
# FUNCIONES DE NÚMEROS ALEATORIOS
# ============================================================================

import random

def numero_aleatorio(minimo=0, maximo=1):
    """Genera un número aleatorio."""
    return random.uniform(minimo, maximo)

def entero_aleatorio(minimo, maximo):
    """Genera un entero aleatorio."""
    return random.randint(minimo, maximo)

def elegir_aleatorio(secuencia):
    """Elige un elemento aleatorio de una secuencia."""
    return random.choice(secuencia)

def revolver_lista(lista_original):
    """Revuelve los elementos de una lista."""
    random.shuffle(lista_original)
    return lista_original

def muestra_aleatoria(lista_original, cantidad):
    """Obtiene una muestra aleatoria."""
    return random.sample(lista_original, cantidad)

# ============================================================================
# FUNCIONES DE ESTADÍSTICA BÁSICA
# ============================================================================

def calcular_promedio(lista_numeros):
    """Calcula el promedio de una lista de números."""
    if longitud(lista_numeros) == 0:
        return Ninguno
    return suma(lista_numeros) / longitud(lista_numeros)

def calcular_mediana(lista_numeros):
    """Calcula la mediana de una lista de números."""
    if longitud(lista_numeros) == 0:
        return Ninguno

    lista_ordenada = ordenar(lista_numeros)
    n = longitud(lista_ordenada)
    medio = n // 2

    if n % 2 == 0:
        return (lista_ordenada[medio - 1] + lista_ordenada[medio]) / 2
    else:
        return lista_ordenada[medio]

def calcular_moda(lista_numeros):
    """Calcula la moda de una lista de números."""
    if longitud(lista_numeros) == 0:
        return Ninguno

    from collections import Counter
    contador = Counter(lista_numeros)
    max_conteo = max(contador.values())
    modas = [num for num, conteo in contador.items() if conteo == max_conteo]

    return modas[0] if longitud(modas) == 1 else modas

def calcular_desviacion_estandar(lista_numeros):
    """Calcula la desviación estándar."""
    if longitud(lista_numeros) == 0:
        return Ninguno

    promedio = calcular_promedio(lista_numeros)
    varianza = suma([(x - promedio) ** 2 for x in lista_numeros]) / longitud(lista_numeros)
    return raiz_cuadrada(varianza)

def calcular_varianza(lista_numeros):
    """Calcula la varianza."""
    if longitud(lista_numeros) == 0:
        return Ninguno

    promedio = calcular_promedio(lista_numeros)
    return suma([(x - promedio) ** 2 for x in lista_numeros]) / longitud(lista_numeros)

# ============================================================================
# FUNCIONES DE VALIDACIÓN
# ============================================================================

def es_vacio(valor):
    """Verifica si un valor está vacío."""
    return longitud(str(valor)) == 0

def es_nulo(valor):
    """Verifica si un valor es None."""
    return valor is None

def es_verdadero(valor):
    """Verifica si un valor es verdadero."""
    return bool(valor)

def es_falso(valor):
    """Verifica si un valor es falso."""
    return not bool(valor)

def validar_numero(valor):
    """Verifica si un valor es un número."""
    try:
        flotante(valor)
        return Verdadero
    except:
        return Falso

def validar_entero(valor):
    """Verifica si un valor es un entero."""
    try:
        entero(valor)
        return Verdadero
    except:
        return Falso

def validar_email(email):
    """Verifica si un email tiene formato válido."""
    import re
    patron = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(patron, email))

def validar_telefono(telefono):
    """Verifica si un teléfono tiene formato válido."""
    import re
    # Acepta formatos: (123) 456-7890, 123-456-7890, 1234567890
    patron = r'^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$'
    return bool(re.match(patron, telefono))

# ============================================================================
# FUNCIONES DE CONVERSIONES AVANZADAS
# ============================================================================

def binario_a_decimal(binario):
    """Convierte binario a decimal."""
    return entero(binario, 2)

def decimal_a_binario(decimal):
    """Convierte decimal a binario."""
    return bin(decimal)[2:]

def hexadecimal_a_decimal(hexadecimal):
    """Convierte hexadecimal a decimal."""
    return entero(hexadecimal, 16)

def decimal_a_hexadecimal(decimal):
    """Convierte decimal a hexadecimal."""
    return hex(decimal)[2:]

def grados_a_radianes(grados):
    """Convierte grados a radianes."""
    return math.radians(grados)

def radianes_a_grados(radianes):
    """Convierte radianes a grados."""
    return math.degrees(radianes)

def celsius_a_fahrenheit(celsius):
    """Convierte Celsius a Fahrenheit."""
    return (celsius * 9/5) + 32

def fahrenheit_a_celsius(fahrenheit):
    """Convierte Fahrenheit a Celsius."""
    return (fahrenheit - 32) * 5/9

def kilometros_a_millas(kilometros):
    """Convierte kilómetros a millas."""
    return kilometros * 0.621371

def millas_a_kilometros(millas):
    """Convierte millas a kilómetros."""
    return millas / 0.621371

# ============================================================================
# FUNCIONES DE TEXTO AVANZADAS
# ============================================================================

def texto_a_lista(texto, separador=None):
    """Convierte texto a lista."""
    return texto.split(separador)

def lista_a_texto(lista_elementos, separador=" "):
    """Convierte lista a texto."""
    return separador.join([str(elem) for elem in lista_elementos])

def primera_letra_mayuscula(texto):
    """Convierte la primera letra a mayúscula."""
    return texto.capitalize()

def invertir_texto(texto):
    """Invierte el orden de un texto."""
    return texto[::-1]

def palindromo(texto):
    """Verifica si un texto es palíndromo."""
    texto_limpio = "".join(c.lower() for c in texto if c.isalnum())
    return texto_limpio == invertir_texto(texto_limpio)

def contar_palabras(texto):
    """Cuenta el número de palabras en un texto."""
    palabras = texto.split()
    return longitud(palabras)

def contar_caracteres(texto, incluir_espacios=Verdadero):
    """Cuenta caracteres en un texto."""
    if incluir_espacios:
        return longitud(texto)
    else:
        return longitud(texto.replace(" ", ""))

def texto_a_minusculas(texto):
    """Convierte texto a minúsculas."""
    return texto.lower()

def texto_a_mayusculas(texto):
    """Convierte texto a mayúsculas."""
    return texto.upper()

def texto_a_titulo(texto):
    """Convierte texto a formato título."""
    return texto.title()

# ============================================================================
# FUNCIONES DE DEPURACIÓN Y DESARROLLO
# ============================================================================

def inspeccionar_objeto(objeto, nombre="objeto"):
    """Inspecciona un objeto mostrando su información."""
    imprimir(f"🔍 Inspección de {nombre}:")
    imprimir(f"   Tipo: {tipo(objeto)}")
    imprimir(f"   Valor: {objeto}")
    imprimir(f"   ID: {id_func(objeto)}")

    if es_instancia(objeto, (lista, tupla)):
        imprimir(f"   Longitud: {longitud(objeto)}")
    elif es_instancia(objeto, diccionario):
        imprimir(f"   Claves: {longitud(obtener_claves(objeto))}")
    elif es_instancia(objeto, cadena):
        imprimir(f"   Caracteres: {longitud(objeto)}")

def mostrar_estructura_datos(objeto, nombre="datos"):
    """Muestra la estructura de datos de un objeto."""
    imprimir(f"🏗️ Estructura de {nombre}:")
    imprimir(f"   Tipo: {tipo(objeto)}")

    if es_instancia(objeto, lista):
        imprimir(f"   Elementos: {longitud(objeto)}")
        imprimir(f"   Contenido: {objeto}")
    elif es_instancia(objeto, diccionario):
        imprimir(f"   Pares clave-valor: {longitud(objeto)}")
        imprimir(f"   Claves: {obtener_claves(objeto)}")
        imprimir(f"   Valores: {obtener_valores(objeto)}")
    elif es_instancia(objeto, conjunto):
        imprimir(f"   Elementos únicos: {longitud(objeto)}")
        imprimir(f"   Contenido: {objeto}")

def mostrar_variables_globales():
    """Muestra todas las variables globales disponibles."""
    imprimir("🌍 Variables globales disponibles:")
    variables = [nombre for nombre in dir() if not nombre.startswith('_')]
    for variable in ordenar(variables):
        imprimir(f"   {variable}")

def mostrar_funciones_disponibles():
    """Muestra todas las funciones disponibles en este módulo."""
    imprimir("🔧 Funciones disponibles en Culebra Fantasma Core:")
    funciones = [nombre for nombre in dir() if callable(eval(nombre)) and not nombre.startswith('_')]
    for funcion in ordenar(funciones):
        imprimir(f"   {funcion}()")

# ============================================================================
# FUNCIONES DE UTILIDAD PARA CULEBRA FANTASMA CORE
# ============================================================================

def mostrar_ayuda_core():
    """
    Muestra información de ayuda sobre las funciones core de Culebra Fantasma.
    """
    imprimir("=" * 70)
    imprimir("CULBRA FANTASMA CORE - FUNCIONES TRADUCIDAS")
    imprimir("=" * 70)
    imprimir()
    imprimir("Funciones disponibles:")
    imprimir("- imprimir, entrada (print, input)")
    imprimir("- longitud, suma, maximo, minimo (len, sum, max, min)")
    imprimir("- lista, diccionario, conjunto, tupla (list, dict, set, tuple)")
    imprimir("- cadena, entero, flotante (str, int, float)")
    imprimir("- tipo, es_instancia (type, isinstance)")
    imprimir("- rango, enumerar, ordenar (range, enumerate, sorted)")
    imprimir("- filtrar, mapear, cualquier, todo (filter, map, any, all)")
    imprimir("- y muchas más funciones built-in traducidas...")
    imprimir()
    imprimir("=" * 70)

def version_core():
    """
    Muestra la versión del módulo core.
    """
    imprimir("Culebra Fantasma Core versión 1.0.0")

def ejemplo_uso_core():
    """
    Ejemplo básico de uso de las funciones core.
    """
    imprimir("🚀 EJEMPLO DE USO DE CULEBRA FANTASMA CORE")
    imprimir("=" * 60)

    # Ejemplo básico
    imprimir("¡Hola desde Culebra Fantasma Core!")

    # Ejemplo de listas
    numeros = lista([1, 2, 3, 4, 5])
    imprimir(f"La longitud de la lista es: {longitud(numeros)}")

    # Ejemplo de operaciones matemáticas
    resultado = suma(numeros)
    imprimir(f"La suma es: {resultado}")

    # Ejemplo de tipos
    texto = cadena("Hola")
    imprimir(f"El tipo es: {tipo(texto)}")

    # Ejemplo de operaciones con texto
    imprimir(f"Mayúsculas: {mayusculas(texto)}")
    imprimir(f"Minúsculas: {minusculas(cadena('MUNDO'))}")

    imprimir("\n✅ ¡Culebra Fantasma Core funciona perfectamente!")

# ============================================================================
# VARIABLES INTERNAS DEL MÓDULO
# ============================================================================

__version__ = "1.0.0"
__author__ = "Miguel Arturo Campos Gomez"
__description__ = "Funciones principales de Python traducidas al español"

# ============================================================================
# INICIALIZACIÓN DEL MÓDULO
# ============================================================================

if __name__ == "__main__":
    mostrar_ayuda_core()
    print()
    ejemplo_uso_core()
