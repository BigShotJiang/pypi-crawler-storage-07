#!/usr/bin/env python3
"""
🐍 TRANSPILER DE CULEBRA FANTASMA
================================

Este módulo convierte código Python escrito en español
a código Python estándar válido.

Convierte palabras clave como:
- si → if
- sino → else
- para → for
- mientras → while
- fun → def
- retornar → return
- imprimir → print
- Y muchas más...

Autor: Culebra Fantasma Team
Versión: 1.0.0
"""

import re
import ast
import sys
from typing import Dict, List, Tuple, Any

class TranspilerCulebra:
    """Transpiler que convierte código español a Python válido."""

    def __init__(self):
        """Inicializa el transpiler con las reglas de traducción."""
        self.palabras_clave = {
            # Estructuras de control
            'si': 'if',
            'sino': 'else',
            'para': 'for',
            'mientras': 'while',
            'romper': 'break',
            'continuar': 'continue',

            # Funciones y clases
            'fun': 'def',
            'retornar': 'return',
            'clase': 'class',
            'lambda_funcion': 'lambda',

            # Manejo de excepciones
            'intentar': 'try',
            'excepto': 'except',
            'lanzar': 'raise',
            'finalmente': 'finally',

            # Funciones built-in traducidas
            'imprimir': 'print',
            'entrada': 'input',
            'longitud': 'len',
            'suma': 'sum',
            'maximo': 'max',
            'minimo': 'min',
            'absoluto': 'abs',
            'redondear': 'round',

            # Tipos y conversión
            'tipo': 'type',
            'cadena': 'str',
            'entero': 'int',
            'flotante': 'float',
            'lista': 'list',
            'diccionario': 'dict',
            'conjunto': 'set',
            'tupla': 'tuple',

            # Verificaciones
            'es_instancia': 'isinstance',

            # Iteración
            'rango': 'range',
            'enumerar': 'enumerate',
            'ordenar': 'sorted',
            'revertir': 'reversed',
            'zip_funcion': 'zip',

            # Texto
            'mayusculas': 'upper',
            'minusculas': 'lower',
            'capitalizar': 'capitalize',
            'titulo': 'title',
            'formato': 'format',

            # Avanzadas
            'filtrar': 'filter',
            'mapear': 'map',
            'cualquier': 'any',
            'todo': 'all',

            # Atributos
            'tiene_atributo': 'hasattr',
            'obtener_atributo': 'getattr',
            'establecer_atributo': 'setattr',
            'eliminar_atributo': 'delattr',
        }

        self.constantes = {
            'Verdadero': 'True',
            'Falso': 'False',
            'Ninguno': 'None',
        }

        # Patrones regex para diferentes tipos de reemplazos
        self.patrones = [
            # Comentarios (no tocar)
            (r'#.*', lambda m: m.group(0)),

            # Strings (no tocar)
            (r'(["\'])(.*?)\1', lambda m: m.group(0)),
            (r'(["\']{3})(.*?)\1{3}', lambda m: m.group(0)),

            # Constantes
            (r'\bVerdadero\b', 'True'),
            (r'\bFalso\b', 'False'),
            (r'\bNinguno\b', 'None'),

            # Funciones con punto (objeto.metodo)
            (r'\b(\w+)\.mayusculas\b', r'\1.upper'),
            (r'\b(\w+)\.minusculas\b', r'\1.lower'),
            (r'\b(\w+)\.capitalizar\b', r'\1.capitalize'),
            (r'\b(\w+)\.titulo\b', r'\1.title'),
            (r'\b(\w+)\.formato\b', r'\1.format'),

            # Palabras clave simples
            (r'\bsi\b', 'if'),
            (r'\bsino\b', 'else'),
            (r'\bpara\b', 'for'),
            (r'\bmientras\b', 'while'),
            (r'\bromper\b', 'break'),
            (r'\bcontinuar\b', 'continue'),
            (r'\bfun\b', 'def'),
            (r'\bretornar\b', 'return'),
            (r'\bclase\b', 'class'),
            (r'\bintentar\b', 'try'),
            (r'\bexcepto\b', 'except'),
            (r'\blanzar\b', 'raise'),
            (r'\bfinalmente\b', 'finally'),

            # Funciones built-in
            (r'\bimprimir\b', 'print'),
            (r'\bentrada\b', 'input'),
            (r'\blongitud\b', 'len'),
            (r'\bsuma\b', 'sum'),
            (r'\bmaximo\b', 'max'),
            (r'\bminimo\b', 'min'),
            (r'\babsoluto\b', 'abs'),
            (r'\bredondear\b', 'round'),
            (r'\btipo\b', 'type'),
            (r'\bcadena\b', 'str'),
            (r'\bentero\b', 'int'),
            (r'\bflotante\b', 'float'),
            (r'\blista\b', 'list'),
            (r'\bdiccionario\b', 'dict'),
            (r'\bconjunto\b', 'set'),
            (r'\btupla\b', 'tuple'),
            (r'\bes_instancia\b', 'isinstance'),
            (r'\brango\b', 'range'),
            (r'\benumerar\b', 'enumerate'),
            (r'\borderar\b', 'sorted'),
            (r'\brevertir\b', 'reversed'),
            (r'\bzip_funcion\b', 'zip'),
            (r'\bfiltrar\b', 'filter'),
            (r'\bmapear\b', 'map'),
            (r'\bcualquier\b', 'any'),
            (r'\btodo\b', 'all'),
            (r'\btiene_atributo\b', 'hasattr'),
            (r'\bobtener_atributo\b', 'getattr'),
            (r'\bestablecer_atributo\b', 'setattr'),
            (r'\beliminar_atributo\b', 'delattr'),
        ]

    def transpile_linea(self, linea: str) -> str:
        """Transpila una sola línea de código."""
        linea_original = linea.strip()

        # Saltar líneas vacías y comentarios
        if not linea_original or linea_original.startswith('#'):
            return linea_original

        # Aplicar todas las transformaciones
        for patron, reemplazo in self.patrones:
            if callable(reemplazo):
                linea_original = re.sub(patron, reemplazo, linea_original)
            else:
                linea_original = re.sub(patron, reemplazo, linea_original)

        return linea_original

    def transpile_codigo(self, codigo: str) -> str:
        """Transpila un bloque completo de código."""
        lineas = codigo.split('\n')
        lineas_transpiladas = []

        for linea in lineas:
            linea_transpilada = self.transpile_linea(linea)
            lineas_transpiladas.append(linea_transpilada)

        return '\n'.join(lineas_transpiladas)

    def ejecutar_codigo_espanol(self, codigo_espanol: str) -> Any:
        """Transpila y ejecuta código escrito en español."""
        try:
            # Transpilar el código
            codigo_python = self.transpile_codigo(codigo_espanol)

            # Ejecutar el código transpilado
            resultado = eval(codigo_python)

            return resultado

        except SyntaxError as e:
            print(f"Error de sintaxis en el código español: {e}")
            print(f"Código transpilado: {codigo_python}")
            return None
        except Exception as e:
            print(f"Error al ejecutar el código: {e}")
            return None

    def mostrar_ayuda(self):
        """Muestra la ayuda del transpiler."""
        print("🐍 TRANSPILER DE CULEBRA FANTASMA")
        print("=" * 50)
        print()
        print("📝 PALABRAS CLAVE SOPORTADAS:")
        print()
        print("🔧 ESTRUCTURAS DE CONTROL:")
        print("   si           → if")
        print("   sino         → else")
        print("   para         → for")
        print("   mientras     → while")
        print("   romper       → break")
        print("   continuar    → continue")
        print()
        print("🏗️ FUNCIONES Y CLASES:")
        print("   fun          → def")
        print("   retornar     → return")
        print("   clase        → class")
        print("   intentar     → try")
        print("   excepto      → except")
        print("   lanzar       → raise")
        print("   finalmente   → finally")
        print()
        print("📊 FUNCIONES BUILT-IN:")
        print("   imprimir     → print")
        print("   entrada      → input")
        print("   longitud     → len")
        print("   suma         → sum")
        print("   maximo       → max")
        print("   minimo       → min")
        print("   absoluto     → abs")
        print("   redondear    → round")
        print()
        print("🔢 TIPOS Y CONVERSIÓN:")
        print("   tipo         → type")
        print("   cadena       → str")
        print("   entero       → int")
        print("   flotante     → float")
        print("   lista        → list")
        print("   diccionario  → dict")
        print("   conjunto     → set")
        print("   tupla        → tuple")
        print()
        print("✅ CONSTANTES:")
        print("   Verdadero    → True")
        print("   Falso        → False")
        print("   Ninguno      → None")
        print()
        print("💡 EJEMPLO DE USO:")
        print("   Código español:")
        print("       si Verdadero:")
        print("           imprimir('¡Funciona!')")
        print()
        print("   Código transpilado:")
        print("       if True:")
        print("           print('¡Funciona!')")

def ejemplo_uso_transpiler():
    """Ejemplo práctico del uso del transpiler."""
    print("🚀 EJEMPLO DE USO DEL TRANSPILER")
    print("=" * 50)

    transpiler = TranspilerCulebra()

    # Ejemplo 1: Código simple
    codigo_espanol_1 = '''
si Verdadero:
    imprimir("¡Hola desde Culebra Fantasma!")
'''

    print("📝 Código español:")
    print(codigo_espanol_1)
    print("🔄 Código transpilado:")
    codigo_python_1 = transpiler.transpile_codigo(codigo_espanol_1)
    print(codigo_python_1)

    # Ejemplo 2: Funciones matemáticas
    codigo_espanol_2 = '''
numeros = lista([1, 2, 3, 4, 5])
total = suma(numeros)
promedio = total / longitud(numeros)
imprimir(f"El promedio es: {promedio}")
'''

    print("\n📊 Código español (matemáticas):")
    print(codigo_espanol_2)
    print("🔄 Código transpilado:")
    codigo_python_2 = transpiler.transpile_codigo(codigo_espanol_2)
    print(codigo_python_2)

    # Ejemplo 3: Estructuras de datos
    codigo_espanol_3 = '''
datos = diccionario([("nombre", "Culebra"), ("version", "1.0.0")])
texto = cadena("Programación en español")
texto_mayus = texto.mayusculas()
imprimir(f"Texto: {texto_mayus}")
'''

    print("\n🏗️ Código español (estructuras):")
    print(codigo_espanol_3)
    print("🔄 Código transpilado:")
    codigo_python_3 = transpiler.transpile_codigo(codigo_espanol_3)
    print(codigo_python_3)

def main():
    """Función principal de demostración."""
    print("🐍 TRANSPILER DE CULEBRA FANTASMA")
    print("=" * 60)
    print("¡Convierte código Python en español a Python estándar!")
    print("=" * 60)

    ejemplo_uso_transpiler()

    print("\n" + "=" * 60)
    print("✅ ¡Transpiler funcionando correctamente!")
    print("🎯 Ahora puedes escribir código en español")
    print("🚀 Más de 35 palabras clave traducidas soportadas")
    print("=" * 60)

if __name__ == "__main__":
    main()
