"""Slack Lists MCP Server Package."""

from .__main__ import main
from .server import mcp

__version__ = "0.1.0"
__all__ = ["main", "mcp"]
