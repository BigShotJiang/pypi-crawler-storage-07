from ._solve import partition, solve

__all__ = ["partition", "solve"]
