# -*- coding: utf-8 -*-

from .caster import resource_explorer_2_caster

caster = resource_explorer_2_caster

__version__ = "1.40.0"