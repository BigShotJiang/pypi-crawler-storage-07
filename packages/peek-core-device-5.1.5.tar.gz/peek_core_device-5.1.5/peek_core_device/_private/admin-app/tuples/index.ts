export { DeviceInfoTable } from "./DeviceInfoTable";
