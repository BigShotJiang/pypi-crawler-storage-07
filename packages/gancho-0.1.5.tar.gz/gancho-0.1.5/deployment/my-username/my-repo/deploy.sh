#!/usr/bin/bash

echo "deploying"
