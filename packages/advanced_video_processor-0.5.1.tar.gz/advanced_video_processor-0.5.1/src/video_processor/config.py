"""Configuration management using Pydantic."""

from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

# Optional dependency detection for 360° features
try:
    from .utils.video_360 import (
        HAS_360_SUPPORT,
        ProjectionType,
        StereoMode,
        Video360Utils,
    )
except ImportError:
    # Fallback types when 360° libraries not available
    ProjectionType = str
    StereoMode = str
    HAS_360_SUPPORT = False


class ProcessorConfig(BaseModel):
    """Configuration for video processor."""

    # Storage settings
    storage_backend: Literal["local", "s3"] = "local"
    base_path: Path = Field(default=Path("/tmp/videos"))

    # Encoding settings - properly separated codecs and containers
    output_containers: list[Literal["mp4", "webm", "ogv"]] = Field(default=["mp4"])
    video_codecs: list[Literal["h264", "hevc", "av1", "vp9"]] = Field(default=["h264"])
    quality_preset: Literal["low", "medium", "high", "ultra"] = "medium"

    # FFmpeg settings with validation
    ffmpeg_path: str = Field(default="/usr/bin/ffmpeg")

    @field_validator("ffmpeg_path")
    @classmethod
    def validate_ffmpeg_path(cls, v: str) -> str:
        """Validate that FFmpeg exists at the specified path."""
        from shutil import which

        # Check if it's an absolute path that exists
        if Path(v).exists():
            return v

        # Check if it's available in PATH
        if which(v.split("/")[-1]):
            return v

        raise ValueError(f"FFmpeg not found at {v}. Please install FFmpeg or specify correct path.")

    # Thumbnail settings
    thumbnail_timestamps: list[int] = Field(default=[1])  # seconds
    thumbnail_width: int = 640

    # Sprite settings
    generate_sprites: bool = True
    sprite_interval: int = 10  # seconds between sprite frames

    # Custom FFmpeg options
    custom_ffmpeg_options: dict[str, str] = Field(default_factory=dict)

    # Advanced codec settings
    enable_av1_encoding: bool = Field(default=False)
    enable_hevc_encoding: bool = Field(default=False)

    # AI processing settings
    enable_ai_analysis: bool = Field(default=True)
    enable_hardware_acceleration: bool = Field(default=True)
    av1_cpu_used: int = Field(default=6, ge=0, le=8)  # AV1 speed vs quality tradeoff
    prefer_two_pass_av1: bool = Field(default=True)
    enable_hdr_processing: bool = Field(default=False)

    # File permissions
    file_permissions: int = 0o644
    directory_permissions: int = 0o755

    # 360° Video settings (only active if 360° libraries are available)
    enable_360_processing: bool = Field(default=HAS_360_SUPPORT)
    auto_detect_360: bool = Field(default=True)
    force_360_projection: ProjectionType | None = Field(default=None)
    video_360_bitrate_multiplier: float = Field(default=2.5, ge=1.0, le=5.0)
    generate_360_thumbnails: bool = Field(default=True)
    thumbnail_360_projections: list[
        Literal["front", "back", "up", "down", "left", "right", "stereographic"]
    ] = Field(default=["front", "stereographic"])

    # Transcription settings
    enable_transcription: bool = Field(default=False)
    whisper_model: Literal["tiny", "base", "small", "medium", "large"] = Field(default="base")
    enable_ollama_enhancement: bool = Field(default=True)
    ollama_host: str = Field(default="localhost")
    ollama_port: int = Field(default=11434, ge=1, le=65535)
    transcription_domain_context: Literal["general", "technical", "educational"] = Field(default="general")

    @field_validator("base_path")
    @classmethod
    def validate_base_path(cls, v: Path) -> Path:
        """Ensure base path is absolute."""
        return v.resolve()

    @field_validator("output_containers")
    @classmethod
    def validate_output_containers(cls, v: list[str]) -> list[str]:
        """Ensure at least one output container is specified."""
        if not v:
            raise ValueError("At least one output container must be specified")
        return v

    @field_validator("enable_360_processing")
    @classmethod
    def validate_360_processing(cls, v: bool) -> bool:
        """Validate 360° processing can be enabled."""
        if v and not HAS_360_SUPPORT:
            raise ValueError(
                "360° processing requires optional dependencies. "
                "Install with: pip install 'video-processor[video-360]' or uv add 'video-processor[video-360]'"
            )
        return v

    model_config = ConfigDict(validate_assignment=True)
