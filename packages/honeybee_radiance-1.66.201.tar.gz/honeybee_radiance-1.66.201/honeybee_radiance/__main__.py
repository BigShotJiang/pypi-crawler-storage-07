from honeybee_radiance.cli import radiance

if __name__ == '__main__':
    radiance()
