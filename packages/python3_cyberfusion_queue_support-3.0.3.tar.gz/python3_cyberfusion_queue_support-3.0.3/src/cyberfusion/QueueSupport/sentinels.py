from typing import TypeVar

UNKNOWN = TypeVar("UNKNOWN")
