kmlorm.models.placemark module
==============================

.. automodule:: kmlorm.models.placemark
   :members:
   :show-inheritance:
   :undoc-members:
