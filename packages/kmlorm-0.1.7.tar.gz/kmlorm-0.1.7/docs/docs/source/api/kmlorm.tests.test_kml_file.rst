kmlorm.tests.test\_kml\_file module
===================================

.. automodule:: kmlorm.tests.test_kml_file
   :members:
   :show-inheritance:
   :undoc-members:
