"""
tsnkit.

A simple scheduling toolkit for time-sensitive network in Python.
"""


__version__ = "0.3.0"
__author__ = 'Chuanyu Xue'
__credits__ = 'UConn CPS Lab'
