"""
Author: Elaine Hu (elainehu222@gmail.com)
__init__.py (c) 2024
Desc: tool for debugging and benchmarking scheduling models
Created:  2024-07-19
"""
