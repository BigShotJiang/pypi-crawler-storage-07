# -*- coding: utf-8 -*-

from .caster import backupsearch_caster

caster = backupsearch_caster

__version__ = "1.40.0"