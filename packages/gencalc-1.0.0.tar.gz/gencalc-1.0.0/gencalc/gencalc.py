def oldgen_start(p):
    """Returns the start year of an old generation (A�Z) based on its position p (A=1, B=2, ... Z=26)."""
    print(1606 + 15*p)

def oldgen_last(p):
    """Returns the end year of an old generation (A�Z) based on its position p (A=1, B=2, ... Z=26)."""
    print(1620 + 15*p)

def newgen_start(p):
    """Returns the start year of a new generation (Alpha�Omega) based on its position p (Alpha = 1, ... Omega=24)."""
    print(1996 + 15*p)

def newgen_last(p):
    """Returns the end year of a new generation (Alpha�Omega) based on its position p (Alpha = 1, ... Omega=24)."""
    print(2010 + 15*p)