"""Basic Framework Example.

This example demonstrates the fundamental usage of MCP Proxy Adapter
with minimal configuration and basic command registration.

Note: This package provides a basic example of MCP Proxy Adapter usage.
The main application is created dynamically in main.py and not exported
as a global variable for this example.
"""
