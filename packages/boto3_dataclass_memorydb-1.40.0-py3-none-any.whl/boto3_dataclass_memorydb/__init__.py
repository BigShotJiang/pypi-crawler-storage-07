# -*- coding: utf-8 -*-

from .caster import memorydb_caster

caster = memorydb_caster

__version__ = "1.40.0"