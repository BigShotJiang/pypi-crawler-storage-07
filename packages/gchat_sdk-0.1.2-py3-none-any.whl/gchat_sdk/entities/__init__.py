from gchat_sdk.entities.chat import Chat, Contact
