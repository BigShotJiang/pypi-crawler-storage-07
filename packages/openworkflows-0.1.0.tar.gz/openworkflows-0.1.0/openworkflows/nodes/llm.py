"""LLM nodes for text generation."""

from typing import Dict, Any, Optional

from openworkflows.node import Node
from openworkflows.context import ExecutionContext
from openworkflows.parameters import Parameter
from openworkflows.providers.litellm_engine import AsyncLiteLLMPCompletion


class GenerateTextNode(Node):
    """Node that generates text using an LLM.

    Parameters:
        model: Model name (provider-specific, e.g., "gpt-4", "claude-3-opus")
        temperature: Sampling temperature between 0 and 1 (default: 0.7)
        max_tokens: Maximum tokens to generate (optional)
        top_p: Nucleus sampling parameter (optional)
        frequency_penalty: Frequency penalty parameter (optional)
        presence_penalty: Presence penalty parameter (optional)
    """

    inputs = {"prompt": str, "system": Optional[str]}
    outputs = {"text": str}
    parameters = {
        "provider": Parameter(
            name="provider",
            type=str,
            default=None,
            required=False,
            description="LLM provider name (e.g., 'openai', 'anthropic')",
        ),
        "model": Parameter(
            name="model",
            type=str,
            default=None,
            required=False,
            description="Model name (e.g., 'gpt-4', 'claude-3-opus')",
        ),
    }

    async def execute(self, ctx: ExecutionContext) -> Dict[str, Any]:
        """Generate text using the LLM provider.

        Args:
            ctx: Execution context (must have llm_provider set)

        Returns:
            Dictionary with 'text' key containing generated text

        Raises:
            ValueError: If no LLM provider configured
        """
        prompt = ctx.input("prompt")
        system = ctx.input("system")

        llm = AsyncLiteLLMPCompletion(provider=self.param("provider"), model=self.param("model"))
        generated = await llm(
            prompt=prompt,
            system=system,
        )
        return {"text": generated}
