"""Output node for collecting workflow outputs."""

from typing import Dict, Any

from openworkflows.node import Node
from openworkflows.context import ExecutionContext


class OutputNode(Node):
    """Node that collects output values from the workflow.

    Config:
        name: The name for this output (default: "output")
    """

    inputs = {"value": Any}
    outputs = {"result": Any}

    async def execute(self, ctx: ExecutionContext) -> Dict[str, Any]:
        """Pass through the input value as output.

        Args:
            ctx: Execution context

        Returns:
            Dictionary with 'result' key containing the value
        """
        value = ctx.input("value")
        return {"result": value}
