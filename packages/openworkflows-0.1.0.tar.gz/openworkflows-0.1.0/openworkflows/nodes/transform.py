"""Transform nodes for data manipulation."""

from typing import Dict, Any, Optional, Literal

from openworkflows.node import Node
from openworkflows.context import ExecutionContext
from openworkflows.parameters import Parameter


class TemplateNode(Node):
    """Node that fills a template with values.

    Parameters:
        template: Template string with {variable} placeholders (required)
        strict: If True, raise error on missing variables (default: True)
    """

    inputs = {"variables": Optional[Dict[str, Any]]}
    outputs = {"text": str}
    parameters = {
        "template": Parameter(
            name="template",
            type=str,
            required=True,
            description="Template string with {variable} placeholders",
        ),
        "strict": Parameter(
            name="strict",
            type=bool,
            default=True,
            required=False,
            description="Raise error on missing variables",
        ),
    }

    async def execute(self, ctx: ExecutionContext) -> Dict[str, Any]:
        """Fill template with variables.

        Args:
            ctx: Execution context

        Returns:
            Dictionary with 'text' key containing filled template
        """
        template = self.param("template")
        strict = self.param("strict")
        variables = ctx.input("variables", {})

        # Support both dict input and individual workflow inputs
        if not variables:
            variables = ctx.workflow_inputs

        try:
            filled = template.format(**variables)
        except KeyError as e:
            if strict:
                raise ValueError(f"Missing template variable: {e}")
            else:
                # Return template with unfilled variables
                filled = template

        return {"text": filled}


class TransformNode(Node):
    """Node that applies a transformation function to input.

    Parameters:
        transform: Name of built-in transform (required)

    Available transforms:
        - identity: Pass through unchanged
        - upper: Convert to uppercase
        - lower: Convert to lowercase
        - strip: Remove leading/trailing whitespace
        - length: Get length
        - str: Convert to string
        - int: Convert to integer
        - float: Convert to float
    """

    inputs = {"input": Any}
    outputs = {"output": Any}
    parameters = {
        "transform": Parameter(
            name="transform",
            type=str,
            default="identity",
            required=False,
            description="Transformation to apply",
            choices=[
                "identity",
                "upper",
                "lower",
                "strip",
                "length",
                "str",
                "int",
                "float",
            ],
        ),
    }

    async def execute(self, ctx: ExecutionContext) -> Dict[str, Any]:
        """Apply transformation to input.

        Args:
            ctx: Execution context

        Returns:
            Dictionary with 'output' key containing transformed value
        """
        value = ctx.input("input")
        transform_name = self.param("transform")

        # Built-in transforms
        transforms = {
            "identity": lambda x: x,
            "upper": lambda x: str(x).upper() if x else "",
            "lower": lambda x: str(x).lower() if x else "",
            "strip": lambda x: str(x).strip() if x else "",
            "length": lambda x: len(x) if x else 0,
            "str": lambda x: str(x),
            "int": lambda x: int(x),
            "float": lambda x: float(x),
        }

        transform_fn = transforms[transform_name]
        result = transform_fn(value)
        return {"output": result}


class MergeNode(Node):
    """Node that merges multiple inputs into a dictionary or list.

    Parameters:
        mode: "dict" or "list" (default: "dict")
        max_inputs: Maximum number of inputs to collect (default: 10)
    """

    # Dynamic inputs - accepts any number of inputs
    outputs = {"result": Any}
    parameters = {
        "mode": Parameter(
            name="mode",
            type=str,
            default="dict",
            required=False,
            description="Output mode",
            choices=["dict", "list"],
        ),
        "max_inputs": Parameter(
            name="max_inputs",
            type=Literal[1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
            default=10,
            required=False,
            description="Maximum number of inputs to collect",
            validator=lambda x: x > 0 and x <= 100,
        ),
    }

    async def execute(self, ctx: ExecutionContext) -> Dict[str, Any]:
        """Merge inputs.

        Args:
            ctx: Execution context

        Returns:
            Dictionary with 'result' key containing merged values
        """
        mode = self.param("mode")
        max_inputs = self.param("max_inputs")

        # Collect all available inputs
        collected = {}

        # Try common input names
        for i in range(max_inputs):
            input_name = f"input{i}" if i > 0 else "input"
            value = ctx.get_input(input_name)
            if value is not None:
                collected[input_name] = value

        if mode == "list":
            result = list(collected.values())
        else:
            result = collected

        return {"result": result}
