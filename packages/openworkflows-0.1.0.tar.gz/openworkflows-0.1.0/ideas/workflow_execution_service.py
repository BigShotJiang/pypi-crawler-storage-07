from typing import Dict, List, Any, Tuple
import logging

from app.services.litellm_service import LiteLLMService
from app.services.nodes.base import NodeExecutionContext
from app.services.nodes.registry import get_node

logging.basicConfig(level=logging.DEBUG)


class WorkflowExecutionService:
    """Service for executing workflows with simple-ai components"""

    def __init__(self):
        self.litellm_service = LiteLLMService()
        self.edges = []  # Store edges for input resolution

    async def execute_workflow(
        self,
        nodes: List[Dict[str, Any]],
        edges: List[Dict[str, Any]],
        input_variables: Dict[str, Any],
        user_id: str,
        db,
        provider: str = "ollama",
    ) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        """
        Execute a workflow by processing nodes in the correct order

        Args:
            nodes: List of React Flow nodes
            edges: List of React Flow edges
            input_variables: Input variables for the workflow
            user_id: User ID for the execution
            db: Database connection

        Returns:
            Tuple of (node_results, final_result)
        """
        logging.info("WorkflowExecutionService: Starting workflow execution")
        logging.info(f"WorkflowExecutionService: Nodes count: {len(nodes)}")
        logging.info(f"WorkflowExecutionService: Edges count: {len(edges)}")
        logging.info(f"WorkflowExecutionService: Input variables: {input_variables}")

        # Store edges for input resolution
        self.edges = edges

        try:
            # Build execution order based on edges
            logging.info("WorkflowExecutionService: Building execution order")
            execution_order = self._build_execution_order(nodes, edges)
            logging.info(f"WorkflowExecutionService: Execution order: {execution_order}")

            # Initialize results storage
            node_results = {}

            # Execute nodes in order
            for node_id in execution_order:
                logging.info(f"WorkflowExecutionService: Executing node {node_id}")
                node = self._find_node_by_id(nodes, node_id)
                if not node:
                    logging.warning(f"WorkflowExecutionService: Node {node_id} not found")
                    continue

                logging.info(f"WorkflowExecutionService: Node {node_id} type: {node.get('type')}")
                logging.info(f"WorkflowExecutionService: Node {node_id} data: {node.get('data')}")

                try:
                    result = await self._execute_node(
                        node, node_results, input_variables, user_id, db, provider
                    )
                    node_results[node_id] = result
                    logging.info(
                        f"WorkflowExecutionService: Node {node_id} executed successfully: {result}"
                    )
                except Exception as e:
                    logging.error(
                        f"WorkflowExecutionService: Error executing node {node_id}: {str(e)}"
                    )
                    node_results[node_id] = {"error": str(e)}
                    raise Exception(f"Error executing node {node_id}: {str(e)}")

            # Collect outputs from output nodes
            logging.info("WorkflowExecutionService: Collecting outputs")
            outputs = self._collect_outputs(nodes, node_results)
            logging.info(f"WorkflowExecutionService: Final outputs: {outputs}")

            return node_results, outputs

        except Exception as e:
            logging.error(f"WorkflowExecutionService: Workflow execution failed: {str(e)}")
            raise

    def _build_execution_order(
        self, nodes: List[Dict[str, Any]], edges: List[Dict[str, Any]]
    ) -> List[str]:
        """
        Build the execution order of nodes based on their dependencies
        """
        # Create adjacency list
        dependencies = {node["id"]: [] for node in nodes}

        for edge in edges:
            source = edge["source"]
            target = edge["target"]
            dependencies[target].append(source)

        # Topological sort
        visited = set()
        temp_visited = set()
        execution_order = []

        def dfs(node_id: str):
            if node_id in temp_visited:
                raise Exception("Circular dependency detected in workflow")
            if node_id in visited:
                return

            temp_visited.add(node_id)

            for dependency in dependencies[node_id]:
                dfs(dependency)

            temp_visited.remove(node_id)
            visited.add(node_id)
            execution_order.append(node_id)

        for node in nodes:
            if node["id"] not in visited:
                dfs(node["id"])

        return execution_order

    def _find_node_by_id(self, nodes: List[Dict[str, Any]], node_id: str) -> Dict[str, Any]:
        """
        Find a node by its ID
        """
        for node in nodes:
            if node["id"] == node_id:
                return node
        return None

    async def _execute_node(
        self,
        node: Dict[str, Any],
        node_results: Dict[str, Any],
        input_variables: Dict[str, Any],
        user_id: str,
        db,
        provider: str = "ollama",
    ) -> Dict[str, Any]:
        """Execute a single node by delegating to its registered implementation."""
        node_type = node.get("type")
        node_impl = get_node(node_type)
        if not node_impl:
            raise Exception(f"Unknown node type: {node_type}")

        def resolve_input(handle: str) -> Any:
            return self._get_node_input(node, node_results, handle)

        context = NodeExecutionContext(
            node=node,
            input_resolver=resolve_input,
            node_results=node_results,
            input_variables=input_variables,
            user_id=user_id,
            db=db,
            provider=provider,
            services={"llm_service": self.litellm_service},
        )

        return await node_impl.execute(context)

    def _get_node_input(
        self, node: Dict[str, Any], node_results: Dict[str, Any], handle: str
    ) -> Any:
        """
        Get input value for a node from connected nodes by following edges
        """
        node_id = node["id"]
        logging.info(
            f"WorkflowExecutionService: Getting input for node {node_id}, handle '{handle}'"
        )

        # Find edges that connect to this node's specific handle
        connected_edges = []
        for edge in self.edges:
            if edge["target"] == node_id and edge.get("targetHandle") == handle:
                connected_edges.append(edge)

        logging.info(
            f"WorkflowExecutionService: Found {len(connected_edges)} edges for node {node_id}, handle '{handle}'"
        )

        if not connected_edges:
            logging.info(
                f"WorkflowExecutionService: No edges found for node {node_id}, handle '{handle}'"
            )
            return None

        # For now, take the first connected edge (in a more complex system, you might handle multiple inputs)
        edge = connected_edges[0]
        source_node_id = edge["source"]
        source_handle = edge.get("sourceHandle") or "result"

        logging.info(
            f"WorkflowExecutionService: Following edge from {source_node_id}:{source_handle} to {node_id}:{handle}"
        )

        # Get the result from the source node
        if source_node_id not in node_results:
            logging.warning(
                f"WorkflowExecutionService: Source node {source_node_id} not found in results"
            )
            return None

        source_result = node_results[source_node_id]
        logging.info(
            f"WorkflowExecutionService: Source node {source_node_id} result: {source_result}"
        )

        value = None
        outputs = source_result.get("outputs") if isinstance(source_result, dict) else None
        candidate_handles = [
            source_handle,
            handle,
            "result",
        ]
        if isinstance(outputs, dict):
            for handle_key in candidate_handles:
                if handle_key and handle_key in outputs:
                    value = outputs[handle_key]
                    break
            if value is None and "result" in outputs:
                value = outputs["result"]

        if value is None and isinstance(source_result, dict):
            result_type = source_result.get("type")
            if result_type in {"text-input", "input", "audio-input"}:
                value = source_result.get("value")
            elif result_type == "prompt-crafter":
                value = source_result.get("prompt")
            elif result_type == "generate-text":
                for key in [source_handle, "generated_text", "result", "value"]:
                    if key and source_result.get(key) is not None:
                        value = source_result.get(key)
                        break
            elif result_type == "visualize-text":
                value = source_result.get("display_text")
            else:
                value = source_result.get(source_handle) or source_result.get("value")

        logging.info(
            f"WorkflowExecutionService: Resolved input value for {node_id}:{handle} = {value}"
        )
        return value

    def _collect_outputs(
        self, nodes: List[Dict[str, Any]], node_results: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Collect outputs from all output nodes in the workflow
        """
        outputs = {}

        # Find all output nodes and collect their values
        for node in nodes:
            if node.get("type") == "output":
                node_id = node["id"]
                if node_id in node_results:
                    result = node_results[node_id]
                    output_name = result.get("name", node_id)
                    output_value = None
                    result_outputs = result.get("outputs") if isinstance(result, dict) else None
                    if isinstance(result_outputs, dict):
                        output_value = result_outputs.get("result")
                        if output_value is None and result_outputs:
                            output_value = next(iter(result_outputs.values()))
                    if output_value is None:
                        output_value = result.get("value", "")
                    outputs[output_name] = output_value

        # If no output nodes found, fall back to legacy behavior
        if not outputs:
            # Find the last visualize-text node or the last executed node
            for node in reversed(nodes):
                node_id = node["id"]
                if node_id in node_results:
                    result = node_results[node_id]
                    if result.get("type") == "visualize-text":
                        outputs["result"] = result.get("display_text", "")
                        break
                    elif result.get("type") == "generate-text":
                        outputs["result"] = result.get("generated_text", "")
                        break
                    else:
                        result_outputs = result.get("outputs") if isinstance(result, dict) else None
                        if isinstance(result_outputs, dict) and result_outputs:
                            outputs["result"] = next(iter(result_outputs.values()))
                            break

            # If still no outputs, return the last result
            if not outputs and node_results:
                last_result = list(node_results.values())[-1]
                if isinstance(last_result, dict):
                    result_outputs = last_result.get("outputs")
                    if isinstance(result_outputs, dict) and result_outputs:
                        outputs["result"] = str(next(iter(result_outputs.values())))
                    else:
                        outputs["result"] = str(
                            last_result.get(
                                "value",
                                last_result.get("generated_text", str(last_result)),
                            )
                        )
                else:
                    outputs["result"] = str(last_result)

        return outputs if outputs else {"result": "No output generated"}
