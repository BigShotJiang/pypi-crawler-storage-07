import httpx
import time
from typing import Dict, Any, List
from fastapi import HTTPException, status
import os


class OllamaClient:
    def __init__(self, base_url: str = None):
        self.base_url = base_url or os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434")
        self.timeout = 300  # 5 minutes timeout for LLM responses

    async def generate_response(
        self, model: str, system_prompt: str, user_message: str, stream: bool = False
    ) -> Dict[str, Any]:
        """Generate a response using Ollama API."""
        url = f"{self.base_url}/api/generate"

        payload = {
            "model": model,
            "prompt": user_message,
            "system": system_prompt,
            "stream": stream,
            "options": {"temperature": 0.7, "top_p": 0.9, "top_k": 40},
        }

        start_time = time.time()

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.post(url, json=payload)

                if response.status_code != 200:
                    raise HTTPException(
                        status_code=status.HTTP_502_BAD_GATEWAY,
                        detail=f"Ollama API error: {response.text}",
                    )

                result = response.json()
                execution_time = time.time() - start_time

                return {
                    "response": result.get("response", ""),
                    "model": model,
                    "execution_time": execution_time,
                    "done": result.get("done", True),
                }

        except httpx.TimeoutException:
            raise HTTPException(
                status_code=status.HTTP_504_GATEWAY_TIMEOUT, detail="Ollama API request timed out"
            )
        except httpx.ConnectError:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Cannot connect to Ollama service. Please ensure Ollama is running.",
            )
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error communicating with Ollama: {str(e)}",
            )

    async def list_models(self) -> Dict[str, Any]:
        """List available models from Ollama."""
        url = f"{self.base_url}/api/tags"
        payload: Dict[str, Any] = {}

        try:
            async with httpx.AsyncClient(timeout=30) as client:
                response = await client.get(url)

            if response.status_code != 200:
                raise HTTPException(
                    status_code=status.HTTP_502_BAD_GATEWAY,
                    detail=f"Ollama API error: {response.text}",
                )

            payload = response.json()

        except httpx.TimeoutException:
            raise HTTPException(
                status_code=status.HTTP_504_GATEWAY_TIMEOUT, detail="Ollama API request timed out"
            )
        except httpx.ConnectError:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Cannot connect to Ollama service. Please ensure Ollama is running.",
            )
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail="Ollama returned an invalid response",
            )
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error communicating with Ollama: {str(e)}",
            )

        models: List[Dict[str, Any]] = []
        for model_data in payload.get("models", []):
            if not isinstance(model_data, dict):
                continue

            model_name = model_data.get("name")
            if not model_name:
                continue

            entry: Dict[str, Any] = {"name": model_name}

            size = model_data.get("size")
            if size is not None:
                entry["size"] = size

            modified_at = model_data.get("modified_at")
            if modified_at:
                entry["modified_at"] = modified_at

            digest = model_data.get("digest")
            if digest:
                entry["digest"] = digest

            details = model_data.get("details")
            if details:
                entry["details"] = details

            models.append(entry)

        return {"models": models}

    async def check_model_exists(self, model: str) -> bool:
        """Check if a model exists in Ollama."""
        try:
            models_response = await self.list_models()
            available_models = [m["name"] for m in models_response.get("models", [])]
            return model in available_models
        except:
            return False


# Global instance
ollama_client = OllamaClient()
