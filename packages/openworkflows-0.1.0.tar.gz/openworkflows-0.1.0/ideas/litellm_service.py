import asyncio
import time
import os
from typing import Dict, Any, Optional, List

import httpx
from fastapi import HTTPException, status
from litellm import completion
from sqlalchemy.orm import Session

from app.models.api_key import APIKey


class LiteLLMService:
    def __init__(self):
        self.supported_providers = {
            "ollama": {
                "requires_api_key": False,
                "api_base": os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434"),
            },
            "openai": {"requires_api_key": True, "env_key": "OPENAI_API_KEY"},
            "google": {"requires_api_key": True, "env_key": "GOOGLE_API_KEY"},
            "anthropic": {"requires_api_key": True, "env_key": "ANTHROPIC_API_KEY"},
            "openrouter": {"requires_api_key": True, "env_key": "OPENROUTER_API_KEY"},
        }

    def _set_api_key_env(self, provider: str, api_key: str):
        """Set the API key in environment variables for the provider."""
        if provider in self.supported_providers:
            provider_config = self.supported_providers[provider]
            if provider_config.get("requires_api_key") and "env_key" in provider_config:
                os.environ[provider_config["env_key"]] = api_key

    def _get_provider_api_key(self, provider: str, db: Session) -> Optional[str]:
        """Get the shared API key for the specified provider."""
        api_key_record = db.query(APIKey).filter(APIKey.provider == provider).first()
        if api_key_record:
            return api_key_record.api_key
        return None

    async def generate_response(
        self,
        model: str,
        system_prompt: str,
        user_message: str,
        user_id: str,
        db: Session,
        provider: str = "ollama",
    ) -> Dict[str, Any]:
        """Generate a response using LiteLLM with the specified provider."""

        # Validate provider
        if provider not in self.supported_providers:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Unsupported provider: {provider}",
            )

        provider_config = self.supported_providers[provider]

        # Handle API key for providers that require it
        if provider_config.get("requires_api_key"):
            api_key = self._get_provider_api_key(provider, db)
            if not api_key:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"API key for {provider} is not configured. Contact an administrator.",
                )
            self._set_api_key_env(provider, api_key)

        # Prepare messages
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message},
        ]

        # Prepare model name with provider prefix
        if provider == "ollama":
            model_name = f"ollama/{model}"
        elif provider == "openrouter":
            model_name = f"openrouter/{model}"
        else:
            model_name = model

        start_time = time.time()

        try:
            # Prepare completion arguments
            completion_args = {
                "model": model_name,
                "messages": messages,
                "temperature": 0.7,
                "max_tokens": 4000,
            }

            # Add api_base for Ollama
            if provider == "ollama":
                completion_args["api_base"] = provider_config["api_base"]

            # Call LiteLLM
            response = await asyncio.to_thread(completion, **completion_args)

            execution_time = time.time() - start_time

            return {
                "response": response.choices[0].message.content,
                "model": model,
                "provider": provider,
                "execution_time": execution_time,
                "done": True,
            }

        except Exception as e:
            error_msg = str(e)

            # Handle specific error cases
            if "API key" in error_msg.lower():
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail=f"Invalid API key for {provider}",
                )
            elif "model" in error_msg.lower() and "not found" in error_msg.lower():
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Model '{model}' not found for provider '{provider}'",
                )
            elif "connection" in error_msg.lower() or "connect" in error_msg.lower():
                raise HTTPException(
                    status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                    detail=f"Cannot connect to {provider} service",
                )
            else:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Error with {provider}: {error_msg}",
                )

    async def list_models(
        self,
        provider: str = "ollama",
        user_id: Optional[str] = None,
        db: Optional[Session] = None,
    ) -> Dict[str, Any]:
        """List available models for the specified provider."""

        if provider == "ollama":
            # For Ollama, we can still use the direct API
            url = f"{self.supported_providers['ollama']['api_base']}/api/tags"

            try:
                async with httpx.AsyncClient(timeout=30) as client:
                    response = await client.get(url)

                    if response.status_code != 200:
                        raise HTTPException(
                            status_code=status.HTTP_502_BAD_GATEWAY,
                            detail=f"Ollama API error: {response.text}",
                        )

                    return response.json()

            except httpx.ConnectError:
                raise HTTPException(
                    status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                    detail="Cannot connect to Ollama service. Please ensure Ollama is running.",
                )
            except Exception as e:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Error communicating with Ollama: {str(e)}",
                )
        elif provider == "openrouter":
            return await self._list_openrouter_models(db)
        else:
            # For other providers, return predefined model lists
            provider_models = {
                "openai": {
                    "models": [
                        {"name": "gpt-4", "size": 0},
                        {"name": "gpt-4-turbo", "size": 0},
                        {"name": "gpt-3.5-turbo", "size": 0},
                    ]
                },
                "google": {
                    "models": [
                        {"name": "gemini-pro", "size": 0},
                        {"name": "gemini-pro-vision", "size": 0},
                    ]
                },
                "anthropic": {
                    "models": [
                        {"name": "claude-3-opus-20240229", "size": 0},
                        {"name": "claude-3-sonnet-20240229", "size": 0},
                        {"name": "claude-3-haiku-20240307", "size": 0},
                    ]
                },
            }

            return provider_models.get(provider, {"models": []})

    async def _list_openrouter_models(self, db: Optional[Session]) -> Dict[str, Any]:
        """Fetch available OpenRouter models dynamically from their public API."""

        url = "https://openrouter.ai/api/v1/models"

        headers: Dict[str, str] = {}

        api_key: Optional[str] = None
        if db:
            api_key = self._get_provider_api_key("openrouter", db)
        if not api_key:
            api_key = os.getenv("OPENROUTER_API_KEY")

        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"

        referer = os.getenv("OPENROUTER_SITE_URL")
        if referer:
            headers["HTTP-Referer"] = referer

        app_title = os.getenv("OPENROUTER_APP_TITLE") or os.getenv("OPENROUTER_APP_NAME")
        if app_title:
            headers["X-Title"] = app_title

        try:
            async with httpx.AsyncClient(timeout=30) as client:
                response = await client.get(url, headers=headers or None)

            if response.status_code != 200:
                raise HTTPException(
                    status_code=status.HTTP_502_BAD_GATEWAY,
                    detail=f"OpenRouter API error: {response.text}",
                )

            payload = response.json()

        except httpx.TimeoutException:
            raise HTTPException(
                status_code=status.HTTP_504_GATEWAY_TIMEOUT,
                detail="OpenRouter API request timed out",
            )
        except httpx.ConnectError:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Cannot connect to OpenRouter. Please verify network access and API key configuration.",
            )
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail="OpenRouter returned an invalid response",
            )
        except Exception as exc:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error communicating with OpenRouter: {str(exc)}",
            )

        models: List[Dict[str, Any]] = []
        for model_data in payload.get("data", []):
            if not isinstance(model_data, dict):
                continue

            model_id = model_data.get("id")
            if not model_id:
                continue

            model_entry: Dict[str, Any] = {"name": model_id, "size": 0}

            display_name = model_data.get("name")
            if display_name and display_name != model_id:
                model_entry["display_name"] = display_name

            context_length = model_data.get("top_provider", {}).get(
                "context_length"
            ) or model_data.get("context_length")
            if context_length:
                model_entry["context_length"] = context_length

            pricing = model_data.get("pricing")
            if pricing:
                model_entry["pricing"] = pricing

            canonical_slug = model_data.get("canonical_slug")
            if canonical_slug and canonical_slug != model_id:
                model_entry["canonical_slug"] = canonical_slug

            models.append(model_entry)

        return {"models": models}

    async def check_model_exists(self, model: str, provider: str = "ollama") -> bool:
        """Check if a model exists for the specified provider."""
        try:
            models_response = await self.list_models(provider)
            available_models = [m["name"] for m in models_response.get("models", [])]
            return model in available_models
        except:
            return False

    def get_supported_providers(self) -> List[str]:
        """Get list of supported providers."""
        return list(self.supported_providers.keys())


# Global instance
litellm_service = LiteLLMService()
