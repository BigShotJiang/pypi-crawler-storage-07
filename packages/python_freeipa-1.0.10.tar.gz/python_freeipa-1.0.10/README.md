python-freeipa is lightweight FreeIPA client.
API documentation: https://python-freeipa.readthedocs.io/
