#!/usr/bin/env bash

python -m siga_mcp.main
