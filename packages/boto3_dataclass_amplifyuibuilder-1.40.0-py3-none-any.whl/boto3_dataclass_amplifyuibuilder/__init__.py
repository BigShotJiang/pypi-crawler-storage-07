# -*- coding: utf-8 -*-

from .caster import amplifyuibuilder_caster

caster = amplifyuibuilder_caster

__version__ = "1.40.0"