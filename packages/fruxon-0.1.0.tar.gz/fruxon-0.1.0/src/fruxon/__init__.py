"""Top-level package for fruxon."""

__author__ = """Hagai Cohen"""
__email__ = 'hagai@fruxon.com'
