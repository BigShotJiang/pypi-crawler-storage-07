"""Unit test package for fruxon."""
