# -*- coding: utf-8 -*-

from .caster import qapps_caster

caster = qapps_caster

__version__ = "1.40.0"