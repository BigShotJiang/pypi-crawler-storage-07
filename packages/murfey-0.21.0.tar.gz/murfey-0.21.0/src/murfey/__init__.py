from __future__ import annotations

__version__ = "0.21.0"
__supported_client_version__ = "0.21.0"
