# dbt-fabric-samdebruyn

This is a maintained and extended fork of the [dbt-fabric](https://github.com/microsoft/dbt-fabric) adapter. This fork has lots of additional features and bugfixes compared to the original adapter.

The adapter was [originally developed by the community](https://github.com/microsoft/dbt-fabric/graphs/contributors) and later adopted by Microsoft.
Given Microsoft's limited investments in the future of the adapter, this fork aims to continue its development and maintenance.

[![PyPI - Version](https://img.shields.io/pypi/v/dbt-fabric-samdebruyn)](https://pypi.org/project/dbt-fabric-samdebruyn/)

## License

[MIT](./LICENSE)

## Acknowledgements

Special thanks to:

* [Jacob Mastel](https://github.com/jacobm001): for his initial work on building dbt-sqlserver.
* [Mikael Ene](https://github.com/mikaelene): for his initial work and continued maintenance on the dbt-sqlserver adapter.
* [Anders Swanson](https://github.com/dataders): for his continued maintenance of the dbt-sqlserver adapter and the creation of the dbt-synapse adapter. And for his work at [dbt Labs](https://www.getdbt.com/).
* [dbt Labs](https://www.getdbt.com/): for their continued support of the dbt open source ecosystem.
* the Microsoft Fabric product team, for their support and contributions to the dbt-fabric adapter.
* every other contributor to dbt-sqlserver, dbt-synapse, and dbt-fabric.
