"""Data and utilities for testing."""

from .JapanStock import DataReader, JapanStocks


TOYOTA = DataReader('72030')

