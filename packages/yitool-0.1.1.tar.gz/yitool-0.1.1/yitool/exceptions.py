class YiToolException(Exception):
    pass