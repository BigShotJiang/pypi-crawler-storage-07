"""Segment class."""
from attrs import define

from .point import Point


@define
class Segment:
    p1: Point
    p2: Point

