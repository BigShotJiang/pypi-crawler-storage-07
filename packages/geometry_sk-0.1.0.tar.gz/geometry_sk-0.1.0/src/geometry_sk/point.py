"""Point class."""
from attrs import define

@define
class Point:
    x: float
    y: float


