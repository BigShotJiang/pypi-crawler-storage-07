Projet de fausse bibliothèque pour le cours de 2025-40.
