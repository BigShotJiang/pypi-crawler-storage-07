"""
Use :class:`screenmirrored`.
"""