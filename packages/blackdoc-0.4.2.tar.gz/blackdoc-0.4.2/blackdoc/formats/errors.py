class InvalidFormatError(ValueError):
    pass
