class URLNames:
    IS_USER_AUTHENTICATED = 'is_user_authenticated'
    AJAX_CALLBACK_HANDLER = 'ajax_callback_handler'
    ADMIN_UTILS_JS_CALLBACK = 'admin_utils_js_callback'
    LOG = 'log'
