# -*- coding: utf-8 -*-

from .caster import cloud9_caster

caster = cloud9_caster

__version__ = "1.40.0"