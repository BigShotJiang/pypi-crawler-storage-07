In standard Odoo the discount is only displayed if it benefits the
customer. In the case of wanting to always show the discount (for
example a surcharge), this module allows to choose whether to show or
not.
