To use this module, you need to:

1.  Go on a pricelist
2.  Set a pricelist rule
3.  Check the "Show Surcharge" box, from now when using this rule the
    discount will be always displayed (if the pricelist is checked as
    show to customers).
