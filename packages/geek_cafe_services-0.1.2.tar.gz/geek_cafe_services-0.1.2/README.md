# geek-cafe-services

## Description
Base Reusable Services for SaaS applications.  This is a prescriptive library for DynamoDB and AWS Lambda services and Common way to respond to API Gateway requests.

## Installation

```bash
# Clone the repository
git clone https://github.com/geekcafe/geek-cafe-services.git
cd geek-cafe-services

# Setup the environment
./pysetup.sh
```

## Usage

Describe how to use your project here.

## Features

- Feature 1
- Feature 2
- Feature 3

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.
We welcome bug reports and feature requests.

## License

Add your license here.
