# Example notebooks

Landing spot for example notebooks. Note that notebooks in `usage` are (often)
used in the generated documentation. If the examples have a large file size,
consider spinning them off as a a submodule.
