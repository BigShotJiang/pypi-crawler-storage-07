jupyter execute --inplace --allow-error examples/usage/motivation.ipynb examples/usage/usage_notebook.ipynb
