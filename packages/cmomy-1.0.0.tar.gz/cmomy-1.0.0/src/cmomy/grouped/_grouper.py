"""Routines to work with grouping."""
