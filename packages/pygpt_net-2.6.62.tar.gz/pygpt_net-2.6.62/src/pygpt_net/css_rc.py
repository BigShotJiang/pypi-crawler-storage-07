# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.9.1
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00[\xec\
@\
font-face{font-f\
amily:KaTeX_AMS;\
font-style:norma\
l;font-weight:40\
0;src:url(qrc://\
/fonts/KaTeX_AMS\
-Regular.woff2) \
format(\x22woff2\x22),\
url(qrc:///fonts\
/KaTeX_AMS-Regul\
ar.woff) format(\
\x22woff\x22),url(qrc:\
///fonts/KaTeX_A\
MS-Regular.ttf) \
format(\x22truetype\
\x22)}@font-face{fo\
nt-family:KaTeX_\
Caligraphic;font\
-style:normal;fo\
nt-weight:700;sr\
c:url(qrc:///fon\
ts/KaTeX_Caligra\
phic-Bold.woff2)\
 format(\x22woff2\x22)\
,url(qrc:///font\
s/KaTeX_Caligrap\
hic-Bold.woff) f\
ormat(\x22woff\x22),ur\
l(qrc:///fonts/K\
aTeX_Caligraphic\
-Bold.ttf) forma\
t(\x22truetype\x22)}@f\
ont-face{font-fa\
mily:KaTeX_Calig\
raphic;font-styl\
e:normal;font-we\
ight:400;src:url\
(qrc:///fonts/Ka\
TeX_Caligraphic-\
Regular.woff2) f\
ormat(\x22woff2\x22),u\
rl(qrc:///fonts/\
KaTeX_Caligraphi\
c-Regular.woff) \
format(\x22woff\x22),u\
rl(qrc:///fonts/\
KaTeX_Caligraphi\
c-Regular.ttf) f\
ormat(\x22truetype\x22\
)}@font-face{fon\
t-family:KaTeX_F\
raktur;font-styl\
e:normal;font-we\
ight:700;src:url\
(qrc:///fonts/Ka\
TeX_Fraktur-Bold\
.woff2) format(\x22\
woff2\x22),url(qrc:\
///fonts/KaTeX_F\
raktur-Bold.woff\
) format(\x22woff\x22)\
,url(qrc:///font\
s/KaTeX_Fraktur-\
Bold.ttf) format\
(\x22truetype\x22)}@fo\
nt-face{font-fam\
ily:KaTeX_Fraktu\
r;font-style:nor\
mal;font-weight:\
400;src:url(qrc:\
///fonts/KaTeX_F\
raktur-Regular.w\
off2) format(\x22wo\
ff2\x22),url(qrc://\
/fonts/KaTeX_Fra\
ktur-Regular.wof\
f) format(\x22woff\x22\
),url(qrc:///fon\
ts/KaTeX_Fraktur\
-Regular.ttf) fo\
rmat(\x22truetype\x22)\
}@font-face{font\
-family:KaTeX_Ma\
in;font-style:no\
rmal;font-weight\
:700;src:url(qrc\
:///fonts/KaTeX_\
Main-Bold.woff2)\
 format(\x22woff2\x22)\
,url(qrc:///font\
s/KaTeX_Main-Bol\
d.woff) format(\x22\
woff\x22),url(qrc:/\
//fonts/KaTeX_Ma\
in-Bold.ttf) for\
mat(\x22truetype\x22)}\
@font-face{font-\
family:KaTeX_Mai\
n;font-style:ita\
lic;font-weight:\
700;src:url(qrc:\
///fonts/KaTeX_M\
ain-BoldItalic.w\
off2) format(\x22wo\
ff2\x22),url(qrc://\
/fonts/KaTeX_Mai\
n-BoldItalic.wof\
f) format(\x22woff\x22\
),url(qrc:///fon\
ts/KaTeX_Main-Bo\
ldItalic.ttf) fo\
rmat(\x22truetype\x22)\
}@font-face{font\
-family:KaTeX_Ma\
in;font-style:it\
alic;font-weight\
:400;src:url(qrc\
:///fonts/KaTeX_\
Main-Italic.woff\
2) format(\x22woff2\
\x22),url(qrc:///fo\
nts/KaTeX_Main-I\
talic.woff) form\
at(\x22woff\x22),url(q\
rc:///fonts/KaTe\
X_Main-Italic.tt\
f) format(\x22truet\
ype\x22)}@font-face\
{font-family:KaT\
eX_Main;font-sty\
le:normal;font-w\
eight:400;src:ur\
l(qrc:///fonts/K\
aTeX_Main-Regula\
r.woff2) format(\
\x22woff2\x22),url(qrc\
:///fonts/KaTeX_\
Main-Regular.wof\
f) format(\x22woff\x22\
),url(qrc:///fon\
ts/KaTeX_Main-Re\
gular.ttf) forma\
t(\x22truetype\x22)}@f\
ont-face{font-fa\
mily:KaTeX_Math;\
font-style:itali\
c;font-weight:70\
0;src:url(qrc://\
/fonts/KaTeX_Mat\
h-BoldItalic.wof\
f2) format(\x22woff\
2\x22),url(qrc:///f\
onts/KaTeX_Math-\
BoldItalic.woff)\
 format(\x22woff\x22),\
url(qrc:///fonts\
/KaTeX_Math-Bold\
Italic.ttf) form\
at(\x22truetype\x22)}@\
font-face{font-f\
amily:KaTeX_Math\
;font-style:ital\
ic;font-weight:4\
00;src:url(qrc:/\
//fonts/KaTeX_Ma\
th-Italic.woff2)\
 format(\x22woff2\x22)\
,url(qrc:///font\
s/KaTeX_Math-Ita\
lic.woff) format\
(\x22woff\x22),url(qrc\
:///fonts/KaTeX_\
Math-Italic.ttf)\
 format(\x22truetyp\
e\x22)}@font-face{f\
ont-family:\x22KaTe\
X_SansSerif\x22;fon\
t-style:normal;f\
ont-weight:700;s\
rc:url(qrc:///fo\
nts/KaTeX_SansSe\
rif-Bold.woff2) \
format(\x22woff2\x22),\
url(qrc:///fonts\
/KaTeX_SansSerif\
-Bold.woff) form\
at(\x22woff\x22),url(q\
rc:///fonts/KaTe\
X_SansSerif-Bold\
.ttf) format(\x22tr\
uetype\x22)}@font-f\
ace{font-family:\
\x22KaTeX_SansSerif\
\x22;font-style:ita\
lic;font-weight:\
400;src:url(qrc:\
///fonts/KaTeX_S\
ansSerif-Italic.\
woff2) format(\x22w\
off2\x22),url(qrc:/\
//fonts/KaTeX_Sa\
nsSerif-Italic.w\
off) format(\x22wof\
f\x22),url(qrc:///f\
onts/KaTeX_SansS\
erif-Italic.ttf)\
 format(\x22truetyp\
e\x22)}@font-face{f\
ont-family:\x22KaTe\
X_SansSerif\x22;fon\
t-style:normal;f\
ont-weight:400;s\
rc:url(qrc:///fo\
nts/KaTeX_SansSe\
rif-Regular.woff\
2) format(\x22woff2\
\x22),url(qrc:///fo\
nts/KaTeX_SansSe\
rif-Regular.woff\
) format(\x22woff\x22)\
,url(qrc:///font\
s/KaTeX_SansSeri\
f-Regular.ttf) f\
ormat(\x22truetype\x22\
)}@font-face{fon\
t-family:KaTeX_S\
cript;font-style\
:normal;font-wei\
ght:400;src:url(\
qrc:///fonts/KaT\
eX_Script-Regula\
r.woff2) format(\
\x22woff2\x22),url(qrc\
:///fonts/KaTeX_\
Script-Regular.w\
off) format(\x22wof\
f\x22),url(qrc:///f\
onts/KaTeX_Scrip\
t-Regular.ttf) f\
ormat(\x22truetype\x22\
)}@font-face{fon\
t-family:KaTeX_S\
ize1;font-style:\
normal;font-weig\
ht:400;src:url(q\
rc:///fonts/KaTe\
X_Size1-Regular.\
woff2) format(\x22w\
off2\x22),url(qrc:/\
//fonts/KaTeX_Si\
ze1-Regular.woff\
) format(\x22woff\x22)\
,url(qrc:///font\
s/KaTeX_Size1-Re\
gular.ttf) forma\
t(\x22truetype\x22)}@f\
ont-face{font-fa\
mily:KaTeX_Size2\
;font-style:norm\
al;font-weight:4\
00;src:url(qrc:/\
//fonts/KaTeX_Si\
ze2-Regular.woff\
2) format(\x22woff2\
\x22),url(qrc:///fo\
nts/KaTeX_Size2-\
Regular.woff) fo\
rmat(\x22woff\x22),url\
(qrc:///fonts/Ka\
TeX_Size2-Regula\
r.ttf) format(\x22t\
ruetype\x22)}@font-\
face{font-family\
:KaTeX_Size3;fon\
t-style:normal;f\
ont-weight:400;s\
rc:url(qrc:///fo\
nts/KaTeX_Size3-\
Regular.woff2) f\
ormat(\x22woff2\x22),u\
rl(qrc:///fonts/\
KaTeX_Size3-Regu\
lar.woff) format\
(\x22woff\x22),url(qrc\
:///fonts/KaTeX_\
Size3-Regular.tt\
f) format(\x22truet\
ype\x22)}@font-face\
{font-family:KaT\
eX_Size4;font-st\
yle:normal;font-\
weight:400;src:u\
rl(qrc:///fonts/\
KaTeX_Size4-Regu\
lar.woff2) forma\
t(\x22woff2\x22),url(q\
rc:///fonts/KaTe\
X_Size4-Regular.\
woff) format(\x22wo\
ff\x22),url(qrc:///\
fonts/KaTeX_Size\
4-Regular.ttf) f\
ormat(\x22truetype\x22\
)}@font-face{fon\
t-family:KaTeX_T\
ypewriter;font-s\
tyle:normal;font\
-weight:400;src:\
url(qrc:///fonts\
/KaTeX_Typewrite\
r-Regular.woff2)\
 format(\x22woff2\x22)\
,url(qrc:///font\
s/KaTeX_Typewrit\
er-Regular.woff)\
 format(\x22woff\x22),\
url(qrc:///fonts\
/KaTeX_Typewrite\
r-Regular.ttf) f\
ormat(\x22truetype\x22\
)}.katex{text-re\
ndering:auto;fon\
t:normal 1.21em \
KaTeX_Main,Times\
 New Roman,serif\
;line-height:1.2\
;text-indent:0}.\
katex *{-ms-high\
-contrast-adjust\
:none!important;\
border-color:cur\
rentColor}.katex\
 .katex-version:\
after{content:\x220\
.16.7\x22}.katex .k\
atex-mathml{clip\
:rect(1px,1px,1p\
x,1px);border:0;\
height:1px;overf\
low:hidden;paddi\
ng:0;position:ab\
solute;width:1px\
}.katex .katex-h\
tml>.newline{dis\
play:block}.kate\
x .base{position\
:relative;white-\
space:nowrap;wid\
th:-webkit-min-c\
ontent;width:-mo\
z-min-content;wi\
dth:min-content}\
.katex .base,.ka\
tex .strut{displ\
ay:inline-block}\
.katex .textbf{f\
ont-weight:700}.\
katex .textit{fo\
nt-style:italic}\
.katex .textrm{f\
ont-family:KaTeX\
_Main}.katex .te\
xtsf{font-family\
:KaTeX_SansSerif\
}.katex .texttt{\
font-family:KaTe\
X_Typewriter}.ka\
tex .mathnormal{\
font-family:KaTe\
X_Math;font-styl\
e:italic}.katex \
.mathit{font-fam\
ily:KaTeX_Main;f\
ont-style:italic\
}.katex .mathrm{\
font-style:norma\
l}.katex .mathbf\
{font-family:KaT\
eX_Main;font-wei\
ght:700}.katex .\
boldsymbol{font-\
family:KaTeX_Mat\
h;font-style:ita\
lic;font-weight:\
700}.katex .amsr\
m,.katex .mathbb\
,.katex .textbb{\
font-family:KaTe\
X_AMS}.katex .ma\
thcal{font-famil\
y:KaTeX_Caligrap\
hic}.katex .math\
frak,.katex .tex\
tfrak{font-famil\
y:KaTeX_Fraktur}\
.katex .mathtt{f\
ont-family:KaTeX\
_Typewriter}.kat\
ex .mathscr,.kat\
ex .textscr{font\
-family:KaTeX_Sc\
ript}.katex .mat\
hsf,.katex .text\
sf{font-family:K\
aTeX_SansSerif}.\
katex .mathbolds\
f,.katex .textbo\
ldsf{font-family\
:KaTeX_SansSerif\
;font-weight:700\
}.katex .mathits\
f,.katex .textit\
sf{font-family:K\
aTeX_SansSerif;f\
ont-style:italic\
}.katex .mainrm{\
font-family:KaTe\
X_Main;font-styl\
e:normal}.katex \
.vlist-t{border-\
collapse:collaps\
e;display:inline\
-table;table-lay\
out:fixed}.katex\
 .vlist-r{displa\
y:table-row}.kat\
ex .vlist{displa\
y:table-cell;pos\
ition:relative;v\
ertical-align:bo\
ttom}.katex .vli\
st>span{display:\
block;height:0;p\
osition:relative\
}.katex .vlist>s\
pan>span{display\
:inline-block}.k\
atex .vlist>span\
>.pstrut{overflo\
w:hidden;width:0\
}.katex .vlist-t\
2{margin-right:-\
2px}.katex .vlis\
t-s{display:tabl\
e-cell;font-size\
:1px;min-width:2\
px;vertical-alig\
n:bottom;width:2\
px}.katex .vbox{\
align-items:base\
line;display:inl\
ine-flex;flex-di\
rection:column}.\
katex .hbox{widt\
h:100%}.katex .h\
box,.katex .thin\
box{display:inli\
ne-flex;flex-dir\
ection:row}.kate\
x .thinbox{max-w\
idth:0;width:0}.\
katex .msupsub{t\
ext-align:left}.\
katex .mfrac>spa\
n>span{text-alig\
n:center}.katex \
.mfrac .frac-lin\
e{border-bottom-\
style:solid;disp\
lay:inline-block\
;width:100%}.kat\
ex .hdashline,.k\
atex .hline,.kat\
ex .mfrac .frac-\
line,.katex .ove\
rline .overline-\
line,.katex .rul\
e,.katex .underl\
ine .underline-l\
ine{min-height:1\
px}.katex .mspac\
e{display:inline\
-block}.katex .c\
lap,.katex .llap\
,.katex .rlap{po\
sition:relative;\
width:0}.katex .\
clap>.inner,.kat\
ex .llap>.inner,\
.katex .rlap>.in\
ner{position:abs\
olute}.katex .cl\
ap>.fix,.katex .\
llap>.fix,.katex\
 .rlap>.fix{disp\
lay:inline-block\
}.katex .llap>.i\
nner{right:0}.ka\
tex .clap>.inner\
,.katex .rlap>.i\
nner{left:0}.kat\
ex .clap>.inner>\
span{margin-left\
:-50%;margin-rig\
ht:50%}.katex .r\
ule{border:0 sol\
id;display:inlin\
e-block;position\
:relative}.katex\
 .hline,.katex .\
overline .overli\
ne-line,.katex .\
underline .under\
line-line{border\
-bottom-style:so\
lid;display:inli\
ne-block;width:1\
00%}.katex .hdas\
hline{border-bot\
tom-style:dashed\
;display:inline-\
block;width:100%\
}.katex .sqrt>.r\
oot{margin-left:\
.27777778em;marg\
in-right:-.55555\
556em}.katex .fo\
ntsize-ensurer.r\
eset-size1.size1\
,.katex .sizing.\
reset-size1.size\
1{font-size:1em}\
.katex .fontsize\
-ensurer.reset-s\
ize1.size2,.kate\
x .sizing.reset-\
size1.size2{font\
-size:1.2em}.kat\
ex .fontsize-ens\
urer.reset-size1\
.size3,.katex .s\
izing.reset-size\
1.size3{font-siz\
e:1.4em}.katex .\
fontsize-ensurer\
.reset-size1.siz\
e4,.katex .sizin\
g.reset-size1.si\
ze4{font-size:1.\
6em}.katex .font\
size-ensurer.res\
et-size1.size5,.\
katex .sizing.re\
set-size1.size5{\
font-size:1.8em}\
.katex .fontsize\
-ensurer.reset-s\
ize1.size6,.kate\
x .sizing.reset-\
size1.size6{font\
-size:2em}.katex\
 .fontsize-ensur\
er.reset-size1.s\
ize7,.katex .siz\
ing.reset-size1.\
size7{font-size:\
2.4em}.katex .fo\
ntsize-ensurer.r\
eset-size1.size8\
,.katex .sizing.\
reset-size1.size\
8{font-size:2.88\
em}.katex .fonts\
ize-ensurer.rese\
t-size1.size9,.k\
atex .sizing.res\
et-size1.size9{f\
ont-size:3.456em\
}.katex .fontsiz\
e-ensurer.reset-\
size1.size10,.ka\
tex .sizing.rese\
t-size1.size10{f\
ont-size:4.148em\
}.katex .fontsiz\
e-ensurer.reset-\
size1.size11,.ka\
tex .sizing.rese\
t-size1.size11{f\
ont-size:4.976em\
}.katex .fontsiz\
e-ensurer.reset-\
size2.size1,.kat\
ex .sizing.reset\
-size2.size1{fon\
t-size:.83333333\
em}.katex .fonts\
ize-ensurer.rese\
t-size2.size2,.k\
atex .sizing.res\
et-size2.size2{f\
ont-size:1em}.ka\
tex .fontsize-en\
surer.reset-size\
2.size3,.katex .\
sizing.reset-siz\
e2.size3{font-si\
ze:1.16666667em}\
.katex .fontsize\
-ensurer.reset-s\
ize2.size4,.kate\
x .sizing.reset-\
size2.size4{font\
-size:1.33333333\
em}.katex .fonts\
ize-ensurer.rese\
t-size2.size5,.k\
atex .sizing.res\
et-size2.size5{f\
ont-size:1.5em}.\
katex .fontsize-\
ensurer.reset-si\
ze2.size6,.katex\
 .sizing.reset-s\
ize2.size6{font-\
size:1.66666667e\
m}.katex .fontsi\
ze-ensurer.reset\
-size2.size7,.ka\
tex .sizing.rese\
t-size2.size7{fo\
nt-size:2em}.kat\
ex .fontsize-ens\
urer.reset-size2\
.size8,.katex .s\
izing.reset-size\
2.size8{font-siz\
e:2.4em}.katex .\
fontsize-ensurer\
.reset-size2.siz\
e9,.katex .sizin\
g.reset-size2.si\
ze9{font-size:2.\
88em}.katex .fon\
tsize-ensurer.re\
set-size2.size10\
,.katex .sizing.\
reset-size2.size\
10{font-size:3.4\
5666667em}.katex\
 .fontsize-ensur\
er.reset-size2.s\
ize11,.katex .si\
zing.reset-size2\
.size11{font-siz\
e:4.14666667em}.\
katex .fontsize-\
ensurer.reset-si\
ze3.size1,.katex\
 .sizing.reset-s\
ize3.size1{font-\
size:.71428571em\
}.katex .fontsiz\
e-ensurer.reset-\
size3.size2,.kat\
ex .sizing.reset\
-size3.size2{fon\
t-size:.85714286\
em}.katex .fonts\
ize-ensurer.rese\
t-size3.size3,.k\
atex .sizing.res\
et-size3.size3{f\
ont-size:1em}.ka\
tex .fontsize-en\
surer.reset-size\
3.size4,.katex .\
sizing.reset-siz\
e3.size4{font-si\
ze:1.14285714em}\
.katex .fontsize\
-ensurer.reset-s\
ize3.size5,.kate\
x .sizing.reset-\
size3.size5{font\
-size:1.28571429\
em}.katex .fonts\
ize-ensurer.rese\
t-size3.size6,.k\
atex .sizing.res\
et-size3.size6{f\
ont-size:1.42857\
143em}.katex .fo\
ntsize-ensurer.r\
eset-size3.size7\
,.katex .sizing.\
reset-size3.size\
7{font-size:1.71\
428571em}.katex \
.fontsize-ensure\
r.reset-size3.si\
ze8,.katex .sizi\
ng.reset-size3.s\
ize8{font-size:2\
.05714286em}.kat\
ex .fontsize-ens\
urer.reset-size3\
.size9,.katex .s\
izing.reset-size\
3.size9{font-siz\
e:2.46857143em}.\
katex .fontsize-\
ensurer.reset-si\
ze3.size10,.kate\
x .sizing.reset-\
size3.size10{fon\
t-size:2.9628571\
4em}.katex .font\
size-ensurer.res\
et-size3.size11,\
.katex .sizing.r\
eset-size3.size1\
1{font-size:3.55\
428571em}.katex \
.fontsize-ensure\
r.reset-size4.si\
ze1,.katex .sizi\
ng.reset-size4.s\
ize1{font-size:.\
625em}.katex .fo\
ntsize-ensurer.r\
eset-size4.size2\
,.katex .sizing.\
reset-size4.size\
2{font-size:.75e\
m}.katex .fontsi\
ze-ensurer.reset\
-size4.size3,.ka\
tex .sizing.rese\
t-size4.size3{fo\
nt-size:.875em}.\
katex .fontsize-\
ensurer.reset-si\
ze4.size4,.katex\
 .sizing.reset-s\
ize4.size4{font-\
size:1em}.katex \
.fontsize-ensure\
r.reset-size4.si\
ze5,.katex .sizi\
ng.reset-size4.s\
ize5{font-size:1\
.125em}.katex .f\
ontsize-ensurer.\
reset-size4.size\
6,.katex .sizing\
.reset-size4.siz\
e6{font-size:1.2\
5em}.katex .font\
size-ensurer.res\
et-size4.size7,.\
katex .sizing.re\
set-size4.size7{\
font-size:1.5em}\
.katex .fontsize\
-ensurer.reset-s\
ize4.size8,.kate\
x .sizing.reset-\
size4.size8{font\
-size:1.8em}.kat\
ex .fontsize-ens\
urer.reset-size4\
.size9,.katex .s\
izing.reset-size\
4.size9{font-siz\
e:2.16em}.katex \
.fontsize-ensure\
r.reset-size4.si\
ze10,.katex .siz\
ing.reset-size4.\
size10{font-size\
:2.5925em}.katex\
 .fontsize-ensur\
er.reset-size4.s\
ize11,.katex .si\
zing.reset-size4\
.size11{font-siz\
e:3.11em}.katex \
.fontsize-ensure\
r.reset-size5.si\
ze1,.katex .sizi\
ng.reset-size5.s\
ize1{font-size:.\
55555556em}.kate\
x .fontsize-ensu\
rer.reset-size5.\
size2,.katex .si\
zing.reset-size5\
.size2{font-size\
:.66666667em}.ka\
tex .fontsize-en\
surer.reset-size\
5.size3,.katex .\
sizing.reset-siz\
e5.size3{font-si\
ze:.77777778em}.\
katex .fontsize-\
ensurer.reset-si\
ze5.size4,.katex\
 .sizing.reset-s\
ize5.size4{font-\
size:.88888889em\
}.katex .fontsiz\
e-ensurer.reset-\
size5.size5,.kat\
ex .sizing.reset\
-size5.size5{fon\
t-size:1em}.kate\
x .fontsize-ensu\
rer.reset-size5.\
size6,.katex .si\
zing.reset-size5\
.size6{font-size\
:1.11111111em}.k\
atex .fontsize-e\
nsurer.reset-siz\
e5.size7,.katex \
.sizing.reset-si\
ze5.size7{font-s\
ize:1.33333333em\
}.katex .fontsiz\
e-ensurer.reset-\
size5.size8,.kat\
ex .sizing.reset\
-size5.size8{fon\
t-size:1.6em}.ka\
tex .fontsize-en\
surer.reset-size\
5.size9,.katex .\
sizing.reset-siz\
e5.size9{font-si\
ze:1.92em}.katex\
 .fontsize-ensur\
er.reset-size5.s\
ize10,.katex .si\
zing.reset-size5\
.size10{font-siz\
e:2.30444444em}.\
katex .fontsize-\
ensurer.reset-si\
ze5.size11,.kate\
x .sizing.reset-\
size5.size11{fon\
t-size:2.7644444\
4em}.katex .font\
size-ensurer.res\
et-size6.size1,.\
katex .sizing.re\
set-size6.size1{\
font-size:.5em}.\
katex .fontsize-\
ensurer.reset-si\
ze6.size2,.katex\
 .sizing.reset-s\
ize6.size2{font-\
size:.6em}.katex\
 .fontsize-ensur\
er.reset-size6.s\
ize3,.katex .siz\
ing.reset-size6.\
size3{font-size:\
.7em}.katex .fon\
tsize-ensurer.re\
set-size6.size4,\
.katex .sizing.r\
eset-size6.size4\
{font-size:.8em}\
.katex .fontsize\
-ensurer.reset-s\
ize6.size5,.kate\
x .sizing.reset-\
size6.size5{font\
-size:.9em}.kate\
x .fontsize-ensu\
rer.reset-size6.\
size6,.katex .si\
zing.reset-size6\
.size6{font-size\
:1em}.katex .fon\
tsize-ensurer.re\
set-size6.size7,\
.katex .sizing.r\
eset-size6.size7\
{font-size:1.2em\
}.katex .fontsiz\
e-ensurer.reset-\
size6.size8,.kat\
ex .sizing.reset\
-size6.size8{fon\
t-size:1.44em}.k\
atex .fontsize-e\
nsurer.reset-siz\
e6.size9,.katex \
.sizing.reset-si\
ze6.size9{font-s\
ize:1.728em}.kat\
ex .fontsize-ens\
urer.reset-size6\
.size10,.katex .\
sizing.reset-siz\
e6.size10{font-s\
ize:2.074em}.kat\
ex .fontsize-ens\
urer.reset-size6\
.size11,.katex .\
sizing.reset-siz\
e6.size11{font-s\
ize:2.488em}.kat\
ex .fontsize-ens\
urer.reset-size7\
.size1,.katex .s\
izing.reset-size\
7.size1{font-siz\
e:.41666667em}.k\
atex .fontsize-e\
nsurer.reset-siz\
e7.size2,.katex \
.sizing.reset-si\
ze7.size2{font-s\
ize:.5em}.katex \
.fontsize-ensure\
r.reset-size7.si\
ze3,.katex .sizi\
ng.reset-size7.s\
ize3{font-size:.\
58333333em}.kate\
x .fontsize-ensu\
rer.reset-size7.\
size4,.katex .si\
zing.reset-size7\
.size4{font-size\
:.66666667em}.ka\
tex .fontsize-en\
surer.reset-size\
7.size5,.katex .\
sizing.reset-siz\
e7.size5{font-si\
ze:.75em}.katex \
.fontsize-ensure\
r.reset-size7.si\
ze6,.katex .sizi\
ng.reset-size7.s\
ize6{font-size:.\
83333333em}.kate\
x .fontsize-ensu\
rer.reset-size7.\
size7,.katex .si\
zing.reset-size7\
.size7{font-size\
:1em}.katex .fon\
tsize-ensurer.re\
set-size7.size8,\
.katex .sizing.r\
eset-size7.size8\
{font-size:1.2em\
}.katex .fontsiz\
e-ensurer.reset-\
size7.size9,.kat\
ex .sizing.reset\
-size7.size9{fon\
t-size:1.44em}.k\
atex .fontsize-e\
nsurer.reset-siz\
e7.size10,.katex\
 .sizing.reset-s\
ize7.size10{font\
-size:1.72833333\
em}.katex .fonts\
ize-ensurer.rese\
t-size7.size11,.\
katex .sizing.re\
set-size7.size11\
{font-size:2.073\
33333em}.katex .\
fontsize-ensurer\
.reset-size8.siz\
e1,.katex .sizin\
g.reset-size8.si\
ze1{font-size:.3\
4722222em}.katex\
 .fontsize-ensur\
er.reset-size8.s\
ize2,.katex .siz\
ing.reset-size8.\
size2{font-size:\
.41666667em}.kat\
ex .fontsize-ens\
urer.reset-size8\
.size3,.katex .s\
izing.reset-size\
8.size3{font-siz\
e:.48611111em}.k\
atex .fontsize-e\
nsurer.reset-siz\
e8.size4,.katex \
.sizing.reset-si\
ze8.size4{font-s\
ize:.55555556em}\
.katex .fontsize\
-ensurer.reset-s\
ize8.size5,.kate\
x .sizing.reset-\
size8.size5{font\
-size:.625em}.ka\
tex .fontsize-en\
surer.reset-size\
8.size6,.katex .\
sizing.reset-siz\
e8.size6{font-si\
ze:.69444444em}.\
katex .fontsize-\
ensurer.reset-si\
ze8.size7,.katex\
 .sizing.reset-s\
ize8.size7{font-\
size:.83333333em\
}.katex .fontsiz\
e-ensurer.reset-\
size8.size8,.kat\
ex .sizing.reset\
-size8.size8{fon\
t-size:1em}.kate\
x .fontsize-ensu\
rer.reset-size8.\
size9,.katex .si\
zing.reset-size8\
.size9{font-size\
:1.2em}.katex .f\
ontsize-ensurer.\
reset-size8.size\
10,.katex .sizin\
g.reset-size8.si\
ze10{font-size:1\
.44027778em}.kat\
ex .fontsize-ens\
urer.reset-size8\
.size11,.katex .\
sizing.reset-siz\
e8.size11{font-s\
ize:1.72777778em\
}.katex .fontsiz\
e-ensurer.reset-\
size9.size1,.kat\
ex .sizing.reset\
-size9.size1{fon\
t-size:.28935185\
em}.katex .fonts\
ize-ensurer.rese\
t-size9.size2,.k\
atex .sizing.res\
et-size9.size2{f\
ont-size:.347222\
22em}.katex .fon\
tsize-ensurer.re\
set-size9.size3,\
.katex .sizing.r\
eset-size9.size3\
{font-size:.4050\
9259em}.katex .f\
ontsize-ensurer.\
reset-size9.size\
4,.katex .sizing\
.reset-size9.siz\
e4{font-size:.46\
296296em}.katex \
.fontsize-ensure\
r.reset-size9.si\
ze5,.katex .sizi\
ng.reset-size9.s\
ize5{font-size:.\
52083333em}.kate\
x .fontsize-ensu\
rer.reset-size9.\
size6,.katex .si\
zing.reset-size9\
.size6{font-size\
:.5787037em}.kat\
ex .fontsize-ens\
urer.reset-size9\
.size7,.katex .s\
izing.reset-size\
9.size7{font-siz\
e:.69444444em}.k\
atex .fontsize-e\
nsurer.reset-siz\
e9.size8,.katex \
.sizing.reset-si\
ze9.size8{font-s\
ize:.83333333em}\
.katex .fontsize\
-ensurer.reset-s\
ize9.size9,.kate\
x .sizing.reset-\
size9.size9{font\
-size:1em}.katex\
 .fontsize-ensur\
er.reset-size9.s\
ize10,.katex .si\
zing.reset-size9\
.size10{font-siz\
e:1.20023148em}.\
katex .fontsize-\
ensurer.reset-si\
ze9.size11,.kate\
x .sizing.reset-\
size9.size11{fon\
t-size:1.4398148\
1em}.katex .font\
size-ensurer.res\
et-size10.size1,\
.katex .sizing.r\
eset-size10.size\
1{font-size:.241\
08004em}.katex .\
fontsize-ensurer\
.reset-size10.si\
ze2,.katex .sizi\
ng.reset-size10.\
size2{font-size:\
.28929605em}.kat\
ex .fontsize-ens\
urer.reset-size1\
0.size3,.katex .\
sizing.reset-siz\
e10.size3{font-s\
ize:.33751205em}\
.katex .fontsize\
-ensurer.reset-s\
ize10.size4,.kat\
ex .sizing.reset\
-size10.size4{fo\
nt-size:.3857280\
6em}.katex .font\
size-ensurer.res\
et-size10.size5,\
.katex .sizing.r\
eset-size10.size\
5{font-size:.433\
94407em}.katex .\
fontsize-ensurer\
.reset-size10.si\
ze6,.katex .sizi\
ng.reset-size10.\
size6{font-size:\
.48216008em}.kat\
ex .fontsize-ens\
urer.reset-size1\
0.size7,.katex .\
sizing.reset-siz\
e10.size7{font-s\
ize:.57859209em}\
.katex .fontsize\
-ensurer.reset-s\
ize10.size8,.kat\
ex .sizing.reset\
-size10.size8{fo\
nt-size:.6943105\
1em}.katex .font\
size-ensurer.res\
et-size10.size9,\
.katex .sizing.r\
eset-size10.size\
9{font-size:.833\
17261em}.katex .\
fontsize-ensurer\
.reset-size10.si\
ze10,.katex .siz\
ing.reset-size10\
.size10{font-siz\
e:1em}.katex .fo\
ntsize-ensurer.r\
eset-size10.size\
11,.katex .sizin\
g.reset-size10.s\
ize11{font-size:\
1.19961427em}.ka\
tex .fontsize-en\
surer.reset-size\
11.size1,.katex \
.sizing.reset-si\
ze11.size1{font-\
size:.20096463em\
}.katex .fontsiz\
e-ensurer.reset-\
size11.size2,.ka\
tex .sizing.rese\
t-size11.size2{f\
ont-size:.241157\
56em}.katex .fon\
tsize-ensurer.re\
set-size11.size3\
,.katex .sizing.\
reset-size11.siz\
e3{font-size:.28\
135048em}.katex \
.fontsize-ensure\
r.reset-size11.s\
ize4,.katex .siz\
ing.reset-size11\
.size4{font-size\
:.32154341em}.ka\
tex .fontsize-en\
surer.reset-size\
11.size5,.katex \
.sizing.reset-si\
ze11.size5{font-\
size:.36173633em\
}.katex .fontsiz\
e-ensurer.reset-\
size11.size6,.ka\
tex .sizing.rese\
t-size11.size6{f\
ont-size:.401929\
26em}.katex .fon\
tsize-ensurer.re\
set-size11.size7\
,.katex .sizing.\
reset-size11.siz\
e7{font-size:.48\
231511em}.katex \
.fontsize-ensure\
r.reset-size11.s\
ize8,.katex .siz\
ing.reset-size11\
.size8{font-size\
:.57877814em}.ka\
tex .fontsize-en\
surer.reset-size\
11.size9,.katex \
.sizing.reset-si\
ze11.size9{font-\
size:.69453376em\
}.katex .fontsiz\
e-ensurer.reset-\
size11.size10,.k\
atex .sizing.res\
et-size11.size10\
{font-size:.8336\
0129em}.katex .f\
ontsize-ensurer.\
reset-size11.siz\
e11,.katex .sizi\
ng.reset-size11.\
size11{font-size\
:1em}.katex .del\
imsizing.size1{f\
ont-family:KaTeX\
_Size1}.katex .d\
elimsizing.size2\
{font-family:KaT\
eX_Size2}.katex \
.delimsizing.siz\
e3{font-family:K\
aTeX_Size3}.kate\
x .delimsizing.s\
ize4{font-family\
:KaTeX_Size4}.ka\
tex .delimsizing\
.mult .delim-siz\
e1>span{font-fam\
ily:KaTeX_Size1}\
.katex .delimsiz\
ing.mult .delim-\
size4>span{font-\
family:KaTeX_Siz\
e4}.katex .nulld\
elimiter{display\
:inline-block;wi\
dth:.12em}.katex\
 .delimcenter,.k\
atex .op-symbol{\
position:relativ\
e}.katex .op-sym\
bol.small-op{fon\
t-family:KaTeX_S\
ize1}.katex .op-\
symbol.large-op{\
font-family:KaTe\
X_Size2}.katex .\
accent>.vlist-t,\
.katex .op-limit\
s>.vlist-t{text-\
align:center}.ka\
tex .accent .acc\
ent-body{positio\
n:relative}.kate\
x .accent .accen\
t-body:not(.acce\
nt-full){width:0\
}.katex .overlay\
{display:block}.\
katex .mtable .v\
ertical-separato\
r{display:inline\
-block;min-width\
:1px}.katex .mta\
ble .arraycolsep\
{display:inline-\
block}.katex .mt\
able .col-align-\
c>.vlist-t{text-\
align:center}.ka\
tex .mtable .col\
-align-l>.vlist-\
t{text-align:lef\
t}.katex .mtable\
 .col-align-r>.v\
list-t{text-alig\
n:right}.katex .\
svg-align{text-a\
lign:left}.katex\
 svg{fill:curren\
tColor;stroke:cu\
rrentColor;fill-\
rule:nonzero;fil\
l-opacity:1;stro\
ke-width:1;strok\
e-linecap:butt;s\
troke-linejoin:m\
iter;stroke-mite\
rlimit:4;stroke-\
dasharray:none;s\
troke-dashoffset\
:0;stroke-opacit\
y:1;display:bloc\
k;height:inherit\
;position:absolu\
te;width:100%}.k\
atex svg path{st\
roke:none}.katex\
 img{border-styl\
e:none;max-heigh\
t:none;max-width\
:none;min-height\
:0;min-width:0}.\
katex .stretchy{\
display:block;ov\
erflow:hidden;po\
sition:relative;\
width:100%}.kate\
x .stretchy:afte\
r,.katex .stretc\
hy:before{conten\
t:\x22\x22}.katex .hid\
e-tail{overflow:\
hidden;position:\
relative;width:1\
00%}.katex .half\
arrow-left{left:\
0;overflow:hidde\
n;position:absol\
ute;width:50.2%}\
.katex .halfarro\
w-right{overflow\
:hidden;position\
:absolute;right:\
0;width:50.2%}.k\
atex .brace-left\
{left:0;overflow\
:hidden;position\
:absolute;width:\
25.1%}.katex .br\
ace-center{left:\
25%;overflow:hid\
den;position:abs\
olute;width:50%}\
.katex .brace-ri\
ght{overflow:hid\
den;position:abs\
olute;right:0;wi\
dth:25.1%}.katex\
 .x-arrow-pad{pa\
dding:0 .5em}.ka\
tex .cd-arrow-pa\
d{padding:0 .555\
56em 0 .27778em}\
.katex .mover,.k\
atex .munder,.ka\
tex .x-arrow{tex\
t-align:center}.\
katex .boxpad{pa\
dding:0 .3em}.ka\
tex .fbox,.katex\
 .fcolorbox{bord\
er:.04em solid;b\
ox-sizing:border\
-box}.katex .can\
cel-pad{padding:\
0 .2em}.katex .c\
ancel-lap{margin\
-left:-.2em;marg\
in-right:-.2em}.\
katex .sout{bord\
er-bottom-style:\
solid;border-bot\
tom-width:.08em}\
.katex .angl{bor\
der-right:.049em\
 solid;border-to\
p:.049em solid;b\
ox-sizing:border\
-box;margin-righ\
t:.03889em}.kate\
x .anglpad{paddi\
ng:0 .03889em}.k\
atex .eqn-num:be\
fore{content:\x22(\x22\
 counter(katexEq\
nNo) \x22)\x22;counter\
-increment:katex\
EqnNo}.katex .mm\
l-eqn-num:before\
{content:\x22(\x22 cou\
nter(mmlEqnNo) \x22\
)\x22;counter-incre\
ment:mmlEqnNo}.k\
atex .mtr-glue{w\
idth:50%}.katex \
.cd-vert-arrow{d\
isplay:inline-bl\
ock;position:rel\
ative}.katex .cd\
-label-left{disp\
lay:inline-block\
;position:absolu\
te;right:calc(50\
% + .3em);text-a\
lign:left}.katex\
 .cd-label-right\
{display:inline-\
block;left:calc(\
50% + .3em);posi\
tion:absolute;te\
xt-align:right}.\
katex-display{di\
splay:block;marg\
in:1em 0;text-al\
ign:center}.kate\
x-display>.katex\
{display:block;t\
ext-align:center\
;white-space:now\
rap}.katex-displ\
ay>.katex>.katex\
-html{display:bl\
ock;position:rel\
ative}.katex-dis\
play>.katex>.kat\
ex-html>.tag{pos\
ition:absolute;r\
ight:0}.katex-di\
splay.leqno>.kat\
ex>.katex-html>.\
tag{left:0;right\
:auto}.katex-dis\
play.fleqn>.kate\
x{padding-left:2\
em;text-align:le\
ft}body{counter-\
reset:katexEqnNo\
 mmlEqnNo}\x0a\
"

qt_resource_name = b"\
\x00\x03\
\x00\x00j\xa3\
\x00c\
\x00s\x00s\
\x00\x0d\
\x01\x14\xdd\xc3\
\x00k\
\x00a\x00t\x00e\x00x\x00.\x00m\x00i\x00n\x00.\x00c\x00s\x00s\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x02\
\x00\x00\x00\x0c\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x01, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x01, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
