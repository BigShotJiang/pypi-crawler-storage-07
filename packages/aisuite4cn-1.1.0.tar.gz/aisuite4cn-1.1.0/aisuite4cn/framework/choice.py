from .message import Message


class Choice:
    def __init__(self):
        self.message = Message()
