skpoly documentation
====================

.. toctree::
   :maxdepth: 2
   :caption: Contents

   getting_started
   api
   examples

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`

