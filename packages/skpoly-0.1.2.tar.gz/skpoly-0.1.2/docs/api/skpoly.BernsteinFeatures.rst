﻿skpoly.BernsteinFeatures
========================

.. currentmodule:: skpoly

.. autoclass:: BernsteinFeatures

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~BernsteinFeatures.__init__
      ~BernsteinFeatures.fit
      ~BernsteinFeatures.fit_transform
      ~BernsteinFeatures.get_metadata_routing
      ~BernsteinFeatures.get_params
      ~BernsteinFeatures.set_output
      ~BernsteinFeatures.set_params
      ~BernsteinFeatures.transform
   
   

   
   
   