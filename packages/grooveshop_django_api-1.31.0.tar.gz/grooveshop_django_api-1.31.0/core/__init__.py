from core.celery import celery_app

__all__ = ("celery_app",)
