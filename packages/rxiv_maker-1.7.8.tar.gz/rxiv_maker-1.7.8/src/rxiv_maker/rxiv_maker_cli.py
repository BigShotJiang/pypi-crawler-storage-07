"""Main entry point for rxiv-maker CLI."""

from rxiv_maker.cli.main import main

if __name__ == "__main__":
    main()
