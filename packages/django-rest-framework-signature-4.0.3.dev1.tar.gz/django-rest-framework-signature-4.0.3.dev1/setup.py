from distutils.core import setup


setup(
    name='django-rest-framework-signature',
    version='4.0.3.dev1',
    description='Django Rest Framework Signature Authentication',
    author='Skyler Cain',
    author_email='skylercain@gmail.com',
    url='https://github.com/Skylude/django-rest-framework-signature',
    packages=['rest_framework_signature', 'rest_framework_signature.models'],
    keywords='django rest_framework authentication api_key signature'
)
