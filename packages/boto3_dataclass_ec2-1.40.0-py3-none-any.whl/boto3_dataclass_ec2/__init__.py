# -*- coding: utf-8 -*-

from .caster import ec2_caster

caster = ec2_caster

__version__ = "1.40.0"