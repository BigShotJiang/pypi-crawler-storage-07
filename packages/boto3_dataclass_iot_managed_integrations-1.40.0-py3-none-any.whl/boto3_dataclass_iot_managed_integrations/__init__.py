# -*- coding: utf-8 -*-

from .caster import iot_managed_integrations_caster

caster = iot_managed_integrations_caster

__version__ = "1.40.0"