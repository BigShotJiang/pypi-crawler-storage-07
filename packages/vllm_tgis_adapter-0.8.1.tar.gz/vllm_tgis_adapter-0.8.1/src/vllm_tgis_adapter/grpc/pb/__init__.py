""".proto definition and generated protobuf code.

See setup.py for `protoc` invocation
"""
