import vllm_tgis_adapter


def test_version():
    assert vllm_tgis_adapter.__version__
