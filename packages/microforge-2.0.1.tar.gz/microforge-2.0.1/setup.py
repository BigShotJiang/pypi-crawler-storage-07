"""Setup configuration for Microforge."""

from setuptools import setup, find_packages
from pathlib import Path

# Read the contents of README file
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text()

# Read version from constants file
import sys
sys.path.insert(0, str(this_directory / "src"))
from microforge.config.constants import APP_VERSION

setup(
    name="microforge",
    version=APP_VERSION,
    description="AI-enhanced Python microservice platform with intelligent code generation",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Microforge Team",
    author_email="support@microforge.ai",
    url="https://github.com/inviz-search/microforge-ai",
    project_urls={
        "Documentation": "https://github.com/inviz-search/microforge-ai#readme",
        "Source": "https://github.com/inviz-search/microforge-ai",
        "Issues": "https://github.com/inviz-search/microforge-ai/issues",
    },
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    python_requires=">=3.11",
    install_requires=[
        "click>=8.1.0",
        "rich>=13.0.0",
        "pyyaml>=6.0",
        "ruamel.yaml>=0.17.0",  # For better YAML formatting
        "pydantic>=2.0.0",      # For data validation
        "pydantic-settings>=2.0.0",  # For settings management (required for pydantic v2)
        "packaging>=23.0",
        "tinydb>=4.8.0",
        "fastapi>=0.104.0",     # For web UI and MCP server
        "uvicorn[standard]>=0.24.0",  # For running web server
        "jinja2>=3.1.0",        # For web templates
        "requests>=2.31.0",     # For version checking, updates, and downloading attachments
        "azure-storage-blob>=12.19.0",  # For Azure blob storage support
    ],
    extras_require={
        "dev": [
            "pytest>=7.4.0",
            "pytest-cov>=4.1.0",
            "pytest-mock>=3.12.0",
            "black>=23.9.0",
            "flake8>=6.0.0",
            "mypy>=1.6.0",
        ],
        "mcp": [
            "mcp>=0.1.0",  # Optional MCP server support
        ],
    },
    entry_points={
        "console_scripts": [
            "microforge=microforge.cli.main:cli",
        ],
    },
    package_data={
        "microforge": [
            "registries/configs/*.yaml",
            "web/templates/**/*",
            "web/static/**/*",
            "resources/**/*",
            "services/**/*.py",
            "workflows/**/*.py",
            "providers/**/*.py",
            "repositories/**/*.py",
            "config/**/*.py",
        ],
    },
    include_package_data=True,
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Code Generators",
        "Topic :: Software Development :: Libraries :: Application Frameworks",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
        "Environment :: Console",
    ],
    keywords="microservices ai code-generation cli development automation",
)