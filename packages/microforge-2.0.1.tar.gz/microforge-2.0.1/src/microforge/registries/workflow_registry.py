"""
Workflow Registry for managing workflow configurations.

This registry manages workflow definitions that orchestrate multi-agent
execution using LangGraph.
"""

from typing import Dict, List, Optional, Any
from pathlib import Path

from ..core.common import console
from ..core.exceptions import ValidationError, NotFoundError
from ..repositories import RepositoryFactory, QueryFilter
from .base import BaseRegistry
from .models import WorkflowModel, WorkflowStepModel


class WorkflowRegistry(BaseRegistry):
    """Registry for workflow configurations with validation.

    Extends BaseRegistry with workflow-specific functionality.
    """

    def __init__(self, refresh_interval: float = 5.0):
        """Initialize workflow registry.

        Args:
            refresh_interval: Seconds between auto-refresh checks
        """
        super().__init__("workflows", refresh_interval)
        # Create repository instance using factory
        self.repository = RepositoryFactory.create_workflow_repository()
        self._validate_workflows()

    def _validate_workflows(self):
        """Validate all workflows against Pydantic model.

        Logs warnings for invalid configurations.
        """
        all_workflows = self.repository.find_all()
        for config in all_workflows:
            try:
                # Get the workflow name from the data
                name = config.get('id', config.get('name', ''))
                if not name:
                    continue

                # Ensure ID is set
                if 'id' not in config:
                    config['id'] = name
                if 'display_name' not in config:
                    config['display_name'] = name.replace('_', ' ').title()

                # Validate against model
                WorkflowModel(**config)
            except Exception as e:
                name = config.get('id', 'unknown')
                console.print(f"[yellow]Warning: Workflow '{name}' validation failed: {e}[/yellow]")

    def get_workflow(self, workflow_id: str) -> Optional[WorkflowModel]:
        """Get validated workflow model.

        Args:
            workflow_id: Workflow ID to retrieve

        Returns:
            WorkflowModel instance or None if not found
        """
        config = self.repository.find_by_id(workflow_id)
        if not config:
            return None

        try:
            # Ensure required fields
            if 'id' not in config:
                config['id'] = workflow_id
            if 'display_name' not in config:
                config['display_name'] = workflow_id.replace('_', ' ').title()

            return WorkflowModel(**config)
        except Exception as e:
            console.print(f"[red]Error creating workflow model for '{workflow_id}': {e}[/red]")
            return None

    def add_workflow(
        self,
        workflow_id: str,
        steps: List[Dict],
        display_name: Optional[str] = None,
        description: str = "",
        **kwargs
    ) -> bool:
        """Add new workflow to registry.

        Args:
            workflow_id: Unique workflow identifier
            steps: List of workflow steps
            display_name: Display name for UI
            description: Workflow description
            **kwargs: Additional workflow configuration

        Returns:
            True if workflow was added successfully
        """
        if self.repository.exists(workflow_id):
            raise ValidationError(f"Workflow '{workflow_id}' already exists", field="id", value=workflow_id)

        # Validate steps
        validated_steps = []
        for step in steps:
            try:
                validated_step = WorkflowStepModel(**step)
                validated_steps.append(validated_step.dict())
            except Exception as e:
                raise ValidationError(f"Invalid step configuration: {e}", field="steps", value=step)

        workflow_config = {
            "id": workflow_id,
            "display_name": display_name or workflow_id.replace('_', ' ').title(),
            "description": description,
            "steps": validated_steps,
            "enabled": kwargs.get('enabled', True),
            "version": kwargs.get('version', "1.0.0"),
            **kwargs
        }

        try:
            # Validate before adding
            WorkflowModel(**workflow_config)
            # Save using repository
            saved_entity = self.repository.save(workflow_config)
            return saved_entity is not None
        except Exception as e:
            console.print(f"[red]Failed to add workflow '{workflow_id}': {e}[/red]")
            return False

    def update_workflow(self, workflow_id: str, **updates) -> bool:
        """Update existing workflow configuration.

        Args:
            workflow_id: Workflow ID to update
            **updates: Fields to update

        Returns:
            True if workflow was updated successfully
        """
        # Update using repository
        updated_entity = self.repository.update(workflow_id, updates)
        if not updated_entity:
            raise NotFoundError(f"Workflow '{workflow_id}' not found", resource_type="workflow", resource_id=workflow_id)

        try:
            # Validate updated config
            WorkflowModel(**updated_entity)
            return True
        except Exception as e:
            console.print(f"[red]Failed to update workflow '{workflow_id}': {e}[/red]")
            return False

    def remove_workflow(self, workflow_id: str) -> bool:
        """Remove workflow from registry.

        Args:
            workflow_id: Workflow ID to remove

        Returns:
            True if workflow was removed successfully
        """
        # Remove using repository
        deleted = self.repository.delete(workflow_id)
        if not deleted:
            raise NotFoundError(f"Workflow '{workflow_id}' not found", resource_type="workflow", resource_id=workflow_id)
        return True

    def list_workflows(self, enabled_only: bool = False) -> List[WorkflowModel]:
        """List all workflows as validated models.

        Args:
            enabled_only: If True, only return enabled workflows

        Returns:
            List of WorkflowModel instances
        """
        workflows = []
        filters = [QueryFilter(field="enabled", value=True)] if enabled_only else None
        all_workflows = self.repository.find_all(filters)

        for config in all_workflows:
            try:
                # Get the workflow name from the data
                name = config.get('id', config.get('name', ''))
                if not name:
                    continue

                # Ensure required fields
                if 'id' not in config:
                    config['id'] = name
                if 'display_name' not in config:
                    config['display_name'] = name.replace('_', ' ').title()

                workflow = WorkflowModel(**config)
                workflows.append(workflow)
            except Exception as e:
                name = config.get('id', 'unknown')
                console.print(f"[yellow]Warning: Failed to load workflow '{name}': {e}[/yellow]")
        return workflows

    def get_workflows_by_category(self, category: str) -> List[WorkflowModel]:
        """Get workflows filtered by category.

        Args:
            category: Category of workflows to retrieve

        Returns:
            List of matching WorkflowModel instances
        """
        workflows = []
        for workflow in self.list_workflows():
            if workflow.category == category:
                workflows.append(workflow)
        return workflows

    def get_workflows_by_tag(self, tag: str) -> List[WorkflowModel]:
        """Get workflows that have a specific tag.

        Args:
            tag: Tag to filter by

        Returns:
            List of matching WorkflowModel instances
        """
        workflows = []
        for workflow in self.list_workflows():
            if tag in workflow.tags:
                workflows.append(workflow)
        return workflows

    def get_dynamic_workflows(self) -> List[WorkflowModel]:
        """Get workflows that support dynamic generation.

        Returns:
            List of dynamic WorkflowModel instances
        """
        workflows = []
        for workflow in self.list_workflows():
            if workflow.supports_dynamic:
                workflows.append(workflow)
        return workflows

    def get_template_workflows(self) -> List[WorkflowModel]:
        """Get workflow templates.

        Returns:
            List of template WorkflowModel instances
        """
        workflows = []
        for workflow in self.list_workflows():
            if workflow.is_template:
                workflows.append(workflow)
        return workflows

    def validate_workflow_graph(self, workflow_id: str) -> Dict[str, Any]:
        """Validate workflow graph structure.

        Checks for:
        - Circular dependencies
        - Missing dependencies
        - Unreachable nodes

        Args:
            workflow_id: Workflow to validate

        Returns:
            Validation results
        """
        workflow = self.get_workflow(workflow_id)
        if not workflow:
            raise NotFoundError(f"Workflow '{workflow_id}' not found")

        issues = []
        warnings = []

        # Build dependency graph
        steps_by_id = {step.id: step for step in workflow.steps}

        # Check for missing dependencies
        for step in workflow.steps:
            for dep in step.depends_on:
                if dep not in steps_by_id:
                    issues.append(f"Step '{step.id}' depends on missing step '{dep}'")

        # Check for circular dependencies
        visited = set()
        rec_stack = set()

        def has_cycle(step_id: str) -> bool:
            visited.add(step_id)
            rec_stack.add(step_id)

            step = steps_by_id.get(step_id)
            if step:
                for dep in step.depends_on:
                    if dep not in visited:
                        if has_cycle(dep):
                            return True
                    elif dep in rec_stack:
                        return True

            rec_stack.remove(step_id)
            return False

        for step in workflow.steps:
            if step.id not in visited:
                if has_cycle(step.id):
                    issues.append(f"Circular dependency detected involving step '{step.id}'")

        # Check for unreachable nodes
        reachable = set()

        def mark_reachable(step_id: str):
            if step_id in reachable:
                return
            reachable.add(step_id)
            step = steps_by_id.get(step_id)
            if step:
                for other_step in workflow.steps:
                    if step_id in other_step.depends_on:
                        mark_reachable(other_step.id)

        # Find entry points (nodes with no dependencies)
        for step in workflow.steps:
            if not step.depends_on:
                mark_reachable(step.id)

        for step in workflow.steps:
            if step.id not in reachable:
                warnings.append(f"Step '{step.id}' is unreachable")

        return {
            "valid": len(issues) == 0,
            "issues": issues,
            "warnings": warnings
        }