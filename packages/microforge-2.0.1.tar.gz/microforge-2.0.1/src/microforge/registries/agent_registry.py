"""
Agent Registry with validation and auto-refresh for Microforge v2.

Manages agent configurations with type safety and validation.
Now supports Azure Blob Storage for agent prompts.
"""

import os
from typing import Dict, List, Optional
from pathlib import Path

from ..core.common import console, print_info, print_warning
from ..core.exceptions import ValidationError, NotFoundError, StorageError
from ..repositories import RepositoryFactory, QueryFilter
from .base import BaseRegistry
from .models import AgentModel


class AgentRegistry(BaseRegistry):
    """Registry for agents with validation and Azure storage support.

    Extends BaseRegistry with agent-specific functionality and
    optional Azure Blob Storage integration for prompts.
    """

    def __init__(self, refresh_interval: float = 5.0):
        """Initialize agent registry.

        Args:
            refresh_interval: Seconds between auto-refresh checks
        """
        super().__init__("agents", refresh_interval)
        # Create repository instance using factory
        self.repository = RepositoryFactory.create_agent_repository()

        # Initialize storage provider from factory
        from ..providers.storage import StorageFactory
        self.storage = StorageFactory.create_storage_provider()

        if self.storage:
            provider_type = StorageFactory.get_configured_provider()
            print_info(f"Storage provider configured: {provider_type}")

        self._validate_agents()

    def _validate_agents(self):
        """Validate all agents against Pydantic model.

        Logs warnings for invalid configurations.
        """
        all_agents = self.repository.find_all()
        for config in all_agents:
            try:
                # Get the agent name from the data
                name = config.get('id', config.get('name', ''))
                if not name:
                    continue

                # Ensure ID is set
                if 'id' not in config:
                    config['id'] = name
                if 'display_name' not in config:
                    config['display_name'] = name.replace('_', ' ').title()

                # Validate against model
                AgentModel(**config)
            except Exception as e:
                name = config.get('id', 'unknown')
                console.print(f"[yellow]Warning: Agent '{name}' validation failed: {e}[/yellow]")

    def get_agent(self, name: str) -> Optional[AgentModel]:
        """Get validated agent model.

        Args:
            name: Agent name to retrieve

        Returns:
            AgentModel instance or None if not found
        """
        config = self.repository.find_by_id(name)
        if not config:
            return None

        try:
            # Ensure required fields
            if 'id' not in config:
                config['id'] = name
            if 'display_name' not in config:
                config['display_name'] = name.replace('_', ' ').title()

            return AgentModel(**config)
        except Exception as e:
            console.print(f"[red]Error creating agent model for '{name}': {e}[/red]")
            return None

    def add_agent(
        self,
        name: str,
        file_name: str,
        description: str = "",
        service: Optional[str] = None,
        **kwargs
    ) -> bool:
        """Add new agent to registry.

        Args:
            name: Agent name
            file_name: Instruction file name
            description: Agent description
            service: Optional service name for service-specific agents
            **kwargs: Additional agent configuration

        Returns:
            True if agent was added successfully
        """
        if self.repository.exists(name):
            raise ValidationError(f"Agent '{name}' already exists", field="name", value=name)

        # Validate service if provided (non-fatal warning)
        if service:
            from ..registries.manager import get_registry_manager
            from ..core.common import print_warning
            registry_manager = get_registry_manager()
            if not registry_manager.services.get_service(service):
                print_warning(f"Service '{service}' not found in service registry, but creating agent anyway")

        agent_config = {
            "id": name,
            "display_name": kwargs.get('display_name', name.replace('_', ' ').title()),
            "description": description,
            "file_name": file_name,
            "service": service,
            "is_global": service is None,
            "enabled": kwargs.get('enabled', True),
            "version": kwargs.get('version', "1.0.0"),
            "category": kwargs.get('category'),
            "tags": kwargs.get('tags', []),
            **kwargs
        }

        try:
            # Validate before adding
            AgentModel(**agent_config)
            # Save using repository
            saved_entity = self.repository.save(agent_config)
            return saved_entity is not None
        except Exception as e:
            console.print(f"[red]Failed to add agent '{name}': {e}[/red]")
            return False

    def update_agent(self, name: str, **updates) -> bool:
        """Update existing agent configuration.

        Args:
            name: Agent name to update
            **updates: Fields to update

        Returns:
            True if agent was updated successfully
        """
        # Update using repository
        updated_entity = self.repository.update(name, updates)
        if not updated_entity:
            raise NotFoundError(f"Agent '{name}' not found", resource_type="agent", resource_id=name)

        try:
            # Validate updated config
            AgentModel(**updated_entity)
            return True
        except Exception as e:
            console.print(f"[red]Failed to update agent '{name}': {e}[/red]")
            return False

    def remove_agent(self, name: str) -> bool:
        """Remove agent from registry.

        Args:
            name: Agent name to remove

        Returns:
            True if agent was removed successfully
        """
        # Remove using repository
        deleted = self.repository.delete(name)
        if not deleted:
            raise NotFoundError(f"Agent '{name}' not found", resource_type="agent", resource_id=name)
        return True

    def list_agents(self, enabled_only: bool = False) -> List[AgentModel]:
        """List all agents as validated models.

        Args:
            enabled_only: If True, only return enabled agents

        Returns:
            List of AgentModel instances
        """
        agents = []
        filters = [QueryFilter(field="enabled", value=True)] if enabled_only else None
        all_agents = self.repository.find_all(filters)

        for config in all_agents:
            try:
                # Get the agent name from the data
                name = config.get('id', config.get('name', ''))
                if not name:
                    continue

                # Ensure required fields
                if 'id' not in config:
                    config['id'] = name
                if 'display_name' not in config:
                    config['display_name'] = name.replace('_', ' ').title()

                agent = AgentModel(**config)
                agents.append(agent)
            except Exception as e:
                name = config.get('id', 'unknown')
                console.print(f"[yellow]Warning: Failed to load agent '{name}': {e}[/yellow]")
        return agents

    def get_agents_by_type(self, agent_type: str) -> List[AgentModel]:
        """Get agents filtered by type.

        Args:
            agent_type: Type of agents to retrieve

        Returns:
            List of matching AgentModel instances
        """
        agents = []
        for agent in self.list_agents():
            # Check if agent has type field or infer from ID
            if hasattr(agent, 'agent_type') and agent.agent_type == agent_type:
                agents.append(agent)
            elif agent_type in agent.id:
                agents.append(agent)
        return agents

    def get_enabled_agents(self) -> List[AgentModel]:
        """Get all enabled agents.

        Returns:
            List of enabled AgentModel instances
        """
        return self.list_agents(enabled_only=True)

    def get_agent_prompt(self, agent_name: str, service: Optional[str] = None) -> Optional[str]:
        """Get agent prompt from storage or local files.

        Args:
            agent_name: Name of the agent
            service: Optional service name for service-specific agents

        Returns:
            Agent prompt content or None if not found
        """
        # Construct path for the prompt
        if service:
            prompt_path = f"{service}/{agent_name}.md"
        else:
            prompt_path = f"{agent_name}.md"

        # Try to get from storage provider
        if self.storage:
            try:
                return self.storage.get_blob_text(prompt_path)
            except (StorageError, NotFoundError) as e:
                print_warning(f"Failed to get prompt from storage: {e}")

        # Fallback to local agent_templates directory
        from ..config.constants import PACKAGE_DIR
        local_path = PACKAGE_DIR / "resources" / "agent_templates"
        if service:
            prompt_file = local_path / service / f"{agent_name}.md"
        else:
            prompt_file = local_path / f"{agent_name}.md"

        if prompt_file.exists():
            return prompt_file.read_text()

        return None

    def list_storage_agents(self, service: Optional[str] = None) -> List[Dict]:
        """List agents available in storage.

        Args:
            service: Optional service name to filter agents

        Returns:
            List of agent information from storage
        """
        if not self.storage:
            return []

        try:
            # List blobs with .md extension
            prefix = f"{service}/" if service else None
            blobs = self.storage.list_blobs(prefix=prefix, extension=".md")

            # Convert blob info to agent info
            agents = []
            for blob in blobs:
                # Extract agent name from path
                name = blob['name']
                if service and name.startswith(f"{service}/"):
                    name = name[len(f"{service}/"):]
                if name.endswith('.md'):
                    name = name[:-3]

                agents.append({
                    'name': name,
                    'path': blob['name'],
                    'service': service,
                    'size': blob['size'],
                    'last_modified': blob['last_modified']
                })

            return agents
        except StorageError as e:
            print_warning(f"Failed to list storage agents: {e}")
            return []

    def sync_with_storage(self, direction: str = "download", service: Optional[str] = None) -> Dict:
        """Sync agents between local and storage.

        Args:
            direction: 'download' from storage or 'upload' to storage
            service: Optional service name for service-specific sync

        Returns:
            Sync result statistics
        """
        if not self.storage:
            raise StorageError("Storage provider not configured")

        from ..config.constants import PACKAGE_DIR
        local_dir = PACKAGE_DIR / "resources" / "agent_templates"
        remote_prefix = service if service else ""

        return self.storage.sync_directory(
            local_dir=local_dir,
            remote_prefix=remote_prefix,
            direction=direction,
            extension_filter=".md"
        )

    def get_agent_with_prompt(self, agent_name: str, service: Optional[str] = None) -> Optional[Dict]:
        """Get agent metadata and prompt combined.

        Args:
            agent_name: Name of the agent
            service: Optional service name for service-specific agents

        Returns:
            Dict with agent metadata and prompt, or None if not found
        """
        agent = self.get_agent(agent_name)
        if not agent:
            return None

        prompt = self.get_agent_prompt(agent_name, service=service)
        if not prompt:
            return None

        return {
            'metadata': agent.dict(),
            'prompt': prompt,
            'service': service
        }

    def get_agents_by_service(self, service_name: str) -> List[AgentModel]:
        """Get all agents for a specific service.

        Args:
            service_name: Name of the service

        Returns:
            List of AgentModel instances for the service
        """
        # First validate the service exists
        from ..registries.manager import get_registry_manager
        registry_manager = get_registry_manager()
        if not registry_manager.services.get_service(service_name):
            raise NotFoundError(
                f"Service '{service_name}' not found in service registry",
                resource_type="service",
                resource_id=service_name
            )

        # Filter agents by service
        agents = []
        for agent in self.list_agents():
            if hasattr(agent, 'service') and agent.service == service_name:
                agents.append(agent)

        return agents

    def get_global_agents(self) -> List[AgentModel]:
        """Get all global agents (not service-specific).

        Returns:
            List of global AgentModel instances
        """
        agents = []
        for agent in self.list_agents():
            if not hasattr(agent, 'service') or agent.service is None:
                agents.append(agent)

        return agents