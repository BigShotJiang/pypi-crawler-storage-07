"""
Base Registry with auto-refresh and versioning support for Microforge v2.

Enhanced registry base class providing auto-refresh, version management, and type safety.
"""

import time
from pathlib import Path
from typing import Dict, Any, Optional, List
from datetime import datetime
from dataclasses import dataclass

from ..core.common import load_config_file, console, print_warning
from ..core.exceptions import ConfigurationError, FileSystemError
from ..config.constants import PACKAGE_DIR, HOOKS_SUBDIR


@dataclass
class RegistryMetadata:
    """Metadata for all registry files."""
    version: str
    created_at: datetime
    last_modified: datetime
    description: str
    schema_version: str = "1.0"  # For migration tracking

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RegistryMetadata":
        """Create from dictionary."""
        return cls(
            version=data.get("version", "1.0.0"),
            created_at=datetime.fromisoformat(data.get("created_at", datetime.now().isoformat())),
            last_modified=datetime.fromisoformat(data.get("last_modified", datetime.now().isoformat())),
            description=data.get("description", ""),
            schema_version=data.get("schema_version", "1.0")
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "version": self.version,
            "created_at": self.created_at.isoformat(),
            "last_modified": self.last_modified.isoformat(),
            "description": self.description,
            "schema_version": self.schema_version
        }


class BaseRegistry:
    """
    Enhanced base registry with auto-refresh and versioning.

    Features:
    - Auto-refresh based on time interval or file modification
    - Version checking and compatibility
    - Metadata tracking
    - Type-safe validation support
    """

    def __init__(self, registry_name: str, refresh_interval: float = 5.0):
        """
        Initialize the registry with auto-refresh support.

        Args:
            registry_name: Name of the registry (used to find config file)
            refresh_interval: Seconds between auto-refresh checks (default: 5.0)
        """
        self.registry_name = registry_name
        self._last_refresh = time.time()
        self._refresh_interval = refresh_interval
        self._file_mtime = 0
        self.metadata: Optional[RegistryMetadata] = None
        self.items: Dict[str, Any] = {}

        # Try to load from config file
        self.registry_file = self._find_registry_file()
        if self.registry_file:
            self.items = self._load_registry()
        else:
            self.items = {}

    def _find_registry_file(self) -> Optional[Path]:
        """Find the registry configuration file."""
        # Look in multiple locations
        possible_paths = [
            PACKAGE_DIR / "registries" / "configs" / f"{self.registry_name}.yaml",
            PACKAGE_DIR / "resources" / "schemas" / f"{self.registry_name}.yaml",
            Path(f".microforge/registries/{self.registry_name}.yaml"),
        ]

        for path in possible_paths:
            if path.exists():
                return path

        # If no file found, that's okay - we'll start with empty registry
        return None

    @property
    def should_refresh(self) -> bool:
        """Check if registry should be refreshed."""
        current_time = time.time()

        # Check time-based refresh
        if current_time - self._last_refresh > self._refresh_interval:
            return True

        # Check file modification time if file exists
        if self.registry_file and self.registry_file.exists():
            try:
                current_mtime = self.registry_file.stat().st_mtime
                if current_mtime > self._file_mtime:
                    return True
            except OSError:
                pass  # Ignore file access errors

        return False

    def _load_registry(self) -> Dict[str, Any]:
        """Load registry data from file."""
        if not self.registry_file or not self.registry_file.exists():
            return {}

        try:
            data = load_config_file(self.registry_file, default={})

            # Extract metadata if present
            if "metadata" in data:
                self.metadata = RegistryMetadata.from_dict(data["metadata"])

            # Update file modification time
            self._file_mtime = self.registry_file.stat().st_mtime

            # Return the actual registry items (extract from section)
            # For registries like agents.yaml, the structure is:
            # metadata: {...}
            # agents: { item1: {...}, item2: {...} }
            # We want to return the contents of the section that matches our registry name

            if self.registry_name in data:
                # Extract items from the named section (e.g., "agents", "hooks", "services")
                return data[self.registry_name]
            else:
                # Return everything except metadata (for backwards compatibility)
                items = {k: v for k, v in data.items() if k != "metadata"}
                return items

        except Exception as e:
            print_warning(f"Failed to load {self.registry_name} registry: {e}")
            return {}

    def refresh(self) -> bool:
        """Manually refresh the registry from file."""
        try:
            self.items = self._load_registry()
            self._last_refresh = time.time()
            return True
        except Exception as e:
            print_warning(f"Failed to refresh {self.registry_name} registry: {e}")
            return False

    def auto_refresh(self) -> bool:
        """Auto-refresh if needed."""
        if self.should_refresh:
            return self.refresh()
        return True

    def get_all(self) -> Dict[str, Any]:
        """Get all registry items, auto-refreshing if needed."""
        self.auto_refresh()
        return self.items.copy()

    def get_item(self, key: str) -> Optional[Any]:
        """Get a specific item from the registry."""
        self.auto_refresh()
        return self.items.get(key)

    def list_keys(self) -> List[str]:
        """List all keys in the registry."""
        self.auto_refresh()
        return list(self.items.keys())

    def count(self) -> int:
        """Get count of items in registry."""
        self.auto_refresh()
        return len(self.items)

    def is_empty(self) -> bool:
        """Check if registry is empty."""
        return self.count() == 0

    def get_metadata(self) -> Optional[RegistryMetadata]:
        """Get registry metadata."""
        self.auto_refresh()
        return self.metadata

    def get_version(self) -> str:
        """Get registry version."""
        meta = self.get_metadata()
        return meta.version if meta else "unknown"

    def get_info(self) -> Dict[str, Any]:
        """Get registry information."""
        self.auto_refresh()
        return {
            "name": self.registry_name,
            "file": str(self.registry_file) if self.registry_file else None,
            "count": self.count(),
            "version": self.get_version(),
            "last_refresh": datetime.fromtimestamp(self._last_refresh).isoformat(),
            "refresh_interval": self._refresh_interval,
            "metadata": self.metadata.to_dict() if self.metadata else None
        }

    def __str__(self) -> str:
        return f"{self.registry_name}Registry(count={self.count()}, version={self.get_version()})"

    def __repr__(self) -> str:
        return f"<BaseRegistry name='{self.registry_name}' count={self.count()} file='{self.registry_file}'>"