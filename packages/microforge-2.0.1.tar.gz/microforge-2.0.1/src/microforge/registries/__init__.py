"""
Microforge v2 Registries System.

Manages agents, hooks, services, and applications with auto-refresh and versioning.
"""

from .manager import RegistryManager, get_registry_manager, reset_registry_manager
from .service_registry import ServiceRegistry
from .agent_registry import AgentRegistry
from .application_registry import ApplicationRegistry
from .hook_registry import HookRegistry
from .base import BaseRegistry
from .models import (
    RegistryItem,
    AgentModel,
    HookModel,
    ServiceModel,
    ApplicationModel,
    CapabilityModel
)

__all__ = [
    "RegistryManager",
    "get_registry_manager",
    "reset_registry_manager",
    "ServiceRegistry",
    "AgentRegistry",
    "ApplicationRegistry",
    "HookRegistry",
    "BaseRegistry",
    "RegistryItem",
    "AgentModel",
    "HookModel",
    "ServiceModel",
    "ApplicationModel",
    "CapabilityModel"
]