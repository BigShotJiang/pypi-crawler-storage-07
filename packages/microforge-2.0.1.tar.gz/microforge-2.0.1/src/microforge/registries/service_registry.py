"""
Service Registry for Microforge v2.

Manages service registrations using the repository pattern for flexible storage.
"""

from typing import Dict, Any, Optional, List
from dataclasses import dataclass, asdict
from datetime import datetime

from ..core.exceptions import ValidationError, NotFoundError
from ..core.common import console
from ..repositories import RepositoryFactory, QueryFilter
from .base import BaseRegistry


@dataclass
class ServiceModel:
    """Service model for registry operations."""
    id: str
    name: str
    repo_url: str
    branch: str = "main"
    description: str = ""
    impl_agent: str = "implementation"  # Changed to match the actual field name
    application: Optional[str] = None
    enabled: bool = True
    created_at: Optional[str] = None

    @classmethod
    def from_yaml_data(cls, name: str, yaml_data: Dict[str, Any]) -> "ServiceModel":
        """Create ServiceModel from YAML data."""
        return cls(
            id=yaml_data.get('id', name),
            name=name,
            repo_url=yaml_data.get('repo_url', ''),
            branch=yaml_data.get('branch', 'main'),
            description=yaml_data.get('description', ''),
            impl_agent=yaml_data.get('impl_agent', 'implementation'),
            application=yaml_data.get('application'),
            enabled=yaml_data.get('enabled', True),
            created_at=yaml_data.get('registered_at', yaml_data.get('created_at'))
        )

    def to_yaml_data(self) -> Dict[str, Any]:
        """Convert to YAML format for storage."""
        data = {
            'id': self.id,
            'repo_url': self.repo_url,
            'branch': self.branch,
            'description': self.description,
            'enabled': self.enabled,
            'impl_agent': self.impl_agent,
            'registered_at': self.created_at
        }
        if self.application:
            data['application'] = self.application

        # Remove None values
        return {k: v for k, v in data.items() if v is not None}


class ServiceRegistry(BaseRegistry):
    """Registry for managing services using repository pattern."""

    def __init__(self, refresh_interval: float = 5.0):
        super().__init__("services", refresh_interval)
        # Create repository instance using factory
        self.repository = RepositoryFactory.create_service_repository()

    def add_service(
        self,
        name: str,
        repo_url: str,
        branch: str = "main",
        description: str = "",
        implementation_agent: str = "implementation",
        application: Optional[str] = None
    ) -> bool:
        """
        Add a new service to the registry.

        Args:
            name: Service name (unique identifier)
            repo_url: Repository URL
            branch: Git branch to use
            description: Service description
            implementation_agent: Agent to use for implementation
            application: Application group this service belongs to

        Returns:
            True if service was added successfully

        Raises:
            ValidationError: If service data is invalid
        """
        # Validate service name
        if self.get_service(name):
            raise ValidationError(f"Service '{name}' already exists", field="name", value=name)

        # Create service data
        service_data = {
            'id': name,
            'repo_url': repo_url,
            'branch': branch,
            'description': description,
            'enabled': True,
            'impl_agent': implementation_agent,
            'registered_at': datetime.now().isoformat()
        }

        if application:
            service_data['application'] = application

        # Save using repository
        saved_entity = self.repository.save(service_data)
        return saved_entity is not None

    def update_service(
        self,
        name: str,
        repo_url: Optional[str] = None,
        branch: Optional[str] = None,
        description: Optional[str] = None,
        implementation_agent: Optional[str] = None,
        application: Optional[str] = None,
        enabled: Optional[bool] = None
    ) -> bool:
        """Update an existing service."""
        # Build updates dictionary
        updates = {}
        if repo_url is not None:
            updates['repo_url'] = repo_url
        if branch is not None:
            updates['branch'] = branch
        if description is not None:
            updates['description'] = description
        if implementation_agent is not None:
            updates['impl_agent'] = implementation_agent
        if application is not None:
            updates['application'] = application
        if enabled is not None:
            updates['enabled'] = enabled

        # Update using repository
        updated_entity = self.repository.update(name, updates)
        if not updated_entity:
            raise NotFoundError(f"Service '{name}' not found", resource_type="service", resource_id=name)

        return True

    def remove_service(self, name: str) -> bool:
        """Remove a service from the registry."""
        # Remove using repository
        deleted = self.repository.delete(name)
        if not deleted:
            raise NotFoundError(f"Service '{name}' not found", resource_type="service", resource_id=name)
        return True

    def get_service_by_repo_url(self, repo_url: str) -> Optional[ServiceModel]:
        """Get a service by its repository URL.

        Args:
            repo_url: Repository URL to search for (can be in various formats)

        Returns:
            ServiceModel if found, None otherwise
        """
        # Normalize repo URL - remove trailing .git and slash
        normalized_url = repo_url.rstrip('/').rstrip('.git')

        # Try different URL formats
        url_variations = [
            normalized_url,
            f"https://github.com/{normalized_url.replace('https://github.com/', '')}",
            f"git@github.com:{normalized_url.replace('https://github.com/', '').replace('/', ':', 1)}.git",
        ]

        # Get all services and search for matching repo URL
        all_services = self.list_services()
        for service in all_services:
            if service.repo_url:
                service_url_normalized = service.repo_url.rstrip('/').rstrip('.git')
                for url_variant in url_variations:
                    if service_url_normalized == url_variant or url_variant == service_url_normalized:
                        return service

        return None

    def get_service(self, name: str) -> Optional[ServiceModel]:
        """Get a service by name."""
        service_data = self.repository.find_by_id(name)
        if service_data:
            try:
                return ServiceModel.from_yaml_data(name, service_data)
            except Exception as e:
                console.print(f"[yellow]Warning: Failed to load service '{name}': {e}[/yellow]")
        return None

    def list_services(self) -> List[ServiceModel]:
        """List all services from registry."""
        services = []
        all_services = self.repository.find_all()
        for service_data in all_services:
            try:
                # Get the service name from the data
                name = service_data.get('id', service_data.get('name', ''))
                if name:
                    service = ServiceModel.from_yaml_data(name, service_data)
                    services.append(service)
            except Exception as e:
                console.print(f"[yellow]Warning: Failed to load service: {e}[/yellow]")
        return services

    def list_services_by_application(self, application: str) -> List[ServiceModel]:
        """List services by application."""
        from ..repositories import QueryFilter

        services = []
        # Use repository filtering
        filters = [QueryFilter(field="application", value=application)]
        filtered_services = self.repository.find_all(filters)

        for service_data in filtered_services:
            try:
                # Get the service name from the data
                name = service_data.get('id', service_data.get('name', ''))
                if name:
                    service = ServiceModel.from_yaml_data(name, service_data)
                    services.append(service)
            except Exception as e:
                console.print(f"[yellow]Warning: Failed to load service: {e}[/yellow]")
        return services

    def get_applications(self) -> List[str]:
        """Get list of all applications."""
        applications = set()
        all_services = self.repository.find_all()
        for service_data in all_services:
            app = service_data.get('application')
            if app:
                applications.add(app)
        return list(applications)

    def get_service_count_by_application(self) -> Dict[str, int]:
        """Get service count grouped by application."""
        counts = {}
        all_services = self.repository.find_all()
        for service_data in all_services:
            app = service_data.get('application') or 'uncategorized'
            counts[app] = counts.get(app, 0) + 1
        return counts

    def exists(self, name: str) -> bool:
        """Check if service exists."""
        return self.repository.exists(name)

    def validate_service_data(self, name: str, repo_url: str) -> bool:
        """Validate service data."""
        if not name or not name.strip():
            raise ValidationError("Service name cannot be empty", field="name")

        if not repo_url or not repo_url.strip():
            raise ValidationError("Repository URL cannot be empty", field="repo_url")

        # Additional validation can be added here
        return True