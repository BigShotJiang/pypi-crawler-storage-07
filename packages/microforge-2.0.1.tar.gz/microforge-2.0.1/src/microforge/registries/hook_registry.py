"""
Hook Registry with validation and auto-refresh for Microforge v2.

Manages hook configurations with type safety and priority sorting.
"""

from typing import Dict, List, Optional
from pathlib import Path

from ..core.common import console
from ..core.exceptions import ValidationError, NotFoundError
from ..repositories import RepositoryFactory, QueryFilter
from .base import BaseRegistry
from .models import HookModel


class HookRegistry(BaseRegistry):
    """Registry for hooks with validation.

    Extends BaseRegistry with hook-specific functionality including
    pre/post hook filtering and priority sorting.
    """

    def __init__(self, refresh_interval: float = 5.0):
        """Initialize hook registry.

        Args:
            refresh_interval: Seconds between auto-refresh checks
        """
        super().__init__("hooks", refresh_interval)
        # Create repository instance using factory
        self.repository = RepositoryFactory.create_hook_repository()
        # Initialize with default hooks if empty
        if self._is_repository_empty():
            self._initialize_default_hooks()
        self._validate_hooks()

    def _is_repository_empty(self) -> bool:
        """Check if repository is empty."""
        return self.repository.count() == 0

    def _initialize_default_hooks(self):
        """Initialize with default hooks."""
        default_hooks = [
            {
                "id": "planning",
                "display_name": "Planning Hook",
                "file_name": "planning_pre_hook.md",
                "description": "Creates implementation plans before code changes",
                "enabled": True,
                "priority": 1,
                "version": "1.0.0",
                "event_type": "pre_code_change"
            },
            {
                "id": "code_quality",
                "display_name": "Code Quality Hook",
                "file_name": "code_quality_hook.md",
                "description": "Enforces tests, docs, and quality standards",
                "enabled": True,
                "priority": 2,
                "version": "1.0.0",
                "event_type": "post_code_change"
            }
        ]
        # Save default hooks using repository
        for hook in default_hooks:
            self.repository.save(hook)

    def _validate_hooks(self):
        """Validate all hooks against Pydantic model.

        Logs warnings for invalid configurations.
        """
        all_hooks = self.repository.find_all()
        for config in all_hooks:
            try:
                # Get the hook name from the data
                name = config.get('id', config.get('name', ''))
                if not name:
                    continue

                # Ensure required fields
                if 'id' not in config:
                    config['id'] = name
                if 'display_name' not in config:
                    config['display_name'] = name.replace('_', ' ').title()
                if 'event_type' not in config:
                    config['event_type'] = 'generic'

                # Validate against model
                HookModel(**config)
            except Exception as e:
                name = config.get('id', 'unknown')
                console.print(f"[yellow]Warning: Hook '{name}' validation failed: {e}[/yellow]")

    def get_hook(self, name: str) -> Optional[HookModel]:
        """Get validated hook model.

        Args:
            name: Hook name to retrieve

        Returns:
            HookModel instance or None if not found
        """
        config = self.repository.find_by_id(name)
        if not config:
            return None

        try:
            # Ensure required fields
            if 'id' not in config:
                config['id'] = name
            if 'display_name' not in config:
                config['display_name'] = name.replace('_', ' ').title()
            if 'event_type' not in config:
                config['event_type'] = 'generic'

            return HookModel(**config)
        except Exception as e:
            console.print(f"[red]Error creating hook model for '{name}': {e}[/red]")
            return None

    def add_hook(
        self,
        name: str,
        file_name: str,
        event_type: str,
        description: str = "",
        priority: int = 10,
        **kwargs
    ) -> bool:
        """Add new hook to registry.

        Args:
            name: Hook name
            file_name: Hook instruction file name
            event_type: Event type that triggers this hook
            description: Hook description
            priority: Hook execution priority
            **kwargs: Additional hook configuration

        Returns:
            True if hook was added successfully
        """
        if self.repository.exists(name):
            raise ValidationError(f"Hook '{name}' already exists", field="name", value=name)

        hook_config = {
            "id": name,
            "display_name": kwargs.get('display_name', name.replace('_', ' ').title()),
            "description": description,
            "file_name": file_name,
            "event_type": event_type,
            "priority": priority,
            "enabled": kwargs.get('enabled', True),
            "version": kwargs.get('version', "1.0.0"),
            **kwargs
        }

        try:
            # Validate before adding
            HookModel(**hook_config)
            # Save using repository
            saved_entity = self.repository.save(hook_config)
            return saved_entity is not None
        except Exception as e:
            console.print(f"[red]Failed to add hook '{name}': {e}[/red]")
            return False

    def update_hook(self, name: str, **updates) -> bool:
        """Update existing hook configuration.

        Args:
            name: Hook name to update
            **updates: Fields to update

        Returns:
            True if hook was updated successfully
        """
        # Update using repository
        updated_entity = self.repository.update(name, updates)
        if not updated_entity:
            raise NotFoundError(f"Hook '{name}' not found", resource_type="hook", resource_id=name)

        try:
            # Validate updated config
            HookModel(**updated_entity)
            return True
        except Exception as e:
            console.print(f"[red]Failed to update hook '{name}': {e}[/red]")
            return False

    def remove_hook(self, name: str) -> bool:
        """Remove hook from registry.

        Args:
            name: Hook name to remove

        Returns:
            True if hook was removed successfully
        """
        # Remove using repository
        deleted = self.repository.delete(name)
        if not deleted:
            raise NotFoundError(f"Hook '{name}' not found", resource_type="hook", resource_id=name)
        return True

    def list_hooks(self, enabled_only: bool = False) -> List[HookModel]:
        """List all hooks as validated models.

        Args:
            enabled_only: If True, only return enabled hooks

        Returns:
            List of HookModel instances sorted by priority
        """
        hooks = []
        filters = [QueryFilter(field="enabled", value=True)] if enabled_only else None
        all_hooks = self.repository.find_all(filters)

        for config in all_hooks:
            try:
                # Get the hook name from the data
                name = config.get('id', config.get('name', ''))
                if not name:
                    continue

                # Ensure required fields
                if 'id' not in config:
                    config['id'] = name
                if 'display_name' not in config:
                    config['display_name'] = name.replace('_', ' ').title()
                if 'event_type' not in config:
                    config['event_type'] = 'generic'

                hook = HookModel(**config)
                hooks.append(hook)
            except Exception as e:
                name = config.get('id', 'unknown')
                console.print(f"[yellow]Warning: Failed to load hook '{name}': {e}[/yellow]")

        # Sort by priority (lower numbers = higher priority)
        return sorted(hooks, key=lambda h: h.priority)

    def get_hooks_by_event(self, event_type: str, enabled_only: bool = True) -> List[HookModel]:
        """Get hooks filtered by event type.

        Args:
            event_type: Event type to filter by
            enabled_only: If True, only return enabled hooks

        Returns:
            List of matching HookModel instances sorted by priority
        """
        # Build filters for event type and optionally enabled status
        filters = [QueryFilter(field="event_type", value=event_type)]
        if enabled_only:
            filters.append(QueryFilter(field="enabled", value=True))

        hooks = []
        filtered_hooks = self.repository.find_all(filters)

        for config in filtered_hooks:
            try:
                # Get the hook name from the data
                name = config.get('id', config.get('name', ''))
                if not name:
                    continue

                # Ensure required fields
                if 'id' not in config:
                    config['id'] = name
                if 'display_name' not in config:
                    config['display_name'] = name.replace('_', ' ').title()
                if 'event_type' not in config:
                    config['event_type'] = 'generic'

                hook = HookModel(**config)
                hooks.append(hook)
            except Exception as e:
                name = config.get('id', 'unknown')
                console.print(f"[yellow]Warning: Failed to load hook '{name}': {e}[/yellow]")

        # Sort by priority (lower numbers = higher priority)
        return sorted(hooks, key=lambda h: h.priority)

    def toggle_hook(self, name: str) -> bool:
        """Toggle hook enabled/disabled state.

        Args:
            name: Hook name to toggle

        Returns:
            True if hook was toggled successfully
        """
        hook_data = self.repository.find_by_id(name)
        if not hook_data:
            raise NotFoundError(f"Hook '{name}' not found", resource_type="hook", resource_id=name)

        current_state = hook_data.get('enabled', True)
        return self.update_hook(name, enabled=not current_state)

    def get_enabled_hooks(self) -> List[HookModel]:
        """Get all enabled hooks.

        Returns:
            List of enabled HookModel instances sorted by priority
        """
        return self.list_hooks(enabled_only=True)