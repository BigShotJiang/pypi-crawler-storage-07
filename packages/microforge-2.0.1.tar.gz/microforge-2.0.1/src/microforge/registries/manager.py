"""
Central Registry Manager for Microforge v2.

Singleton manager for all Microforge registries with auto-refresh support.
"""

from typing import Dict, Any, Optional, List
from datetime import datetime

from .service_registry import ServiceRegistry
from .agent_registry import AgentRegistry
from .application_registry import ApplicationRegistry
from .hook_registry import HookRegistry
from .workflow_registry import WorkflowRegistry


class RegistryManager:
    """
    Central manager for all registries.

    Singleton pattern ensures only one instance exists.
    Manages agents, hooks, services, and applications registries.
    """

    _instance = None

    def __new__(cls):
        """Ensure singleton pattern."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self, refresh_interval: float = 5.0):
        """
        Initialize registry manager.

        Args:
            refresh_interval: Default refresh interval for all registries
        """
        if self._initialized:
            return

        self._refresh_interval = refresh_interval

        # Initialize all registries
        self.services = ServiceRegistry(refresh_interval)
        self.agents = AgentRegistry()
        self.hooks = HookRegistry()
        self.applications = ApplicationRegistry()
        # self.workflows = WorkflowRegistry()  # Temporarily disabled - needs langgraph
        self.workflows = None  # Placeholder

        self._initialized = True

    def refresh_all(self) -> Dict[str, bool]:
        """Refresh all registries."""
        results = {}

        registries = {
            "services": self.services,
            "agents": self.agents,
            "hooks": self.hooks,
            "applications": self.applications
            # "workflows": self.workflows  # Temporarily disabled
        }

        for name, registry in registries.items():
            if registry is None:  # Skip None registries
                results[name] = False
                continue
            try:
                results[name] = registry.refresh()
            except Exception as e:
                results[name] = False

        return results

    def get_status(self) -> Dict[str, Any]:
        """Get status of all registries."""
        return {
            "services": self.services.get_info(),
            "agents": self.agents.get_info(),
            "hooks": self.hooks.get_info(),
            "applications": self.applications.get_info(),
            "workflows": {} if self.workflows is None else self.workflows.get_info(),
            "manager": {
                "refresh_interval": self._refresh_interval,
                "initialized": self._initialized
            }
        }

    def get_counts(self) -> Dict[str, int]:
        """Get counts from all registries."""
        return {
            "services": self.services.count(),
            "agents": self.agents.count(),
            "hooks": self.hooks.count(),
            "applications": self.applications.count(),
            "workflows": 0 if self.workflows is None else self.workflows.count()
        }

    def validate_all(self) -> Dict[str, List[str]]:
        """Validate all registries."""
        issues = {
            "services": [],
            "agents": [],
            "hooks": [],
            "applications": [],
            "workflows": []
        }

        # Basic validation - can be expanded
        if self.services.is_empty():
            issues["services"].append("No services registered")

        if self.hooks.is_empty():
            issues["hooks"].append("No hooks available")

        return issues


# Global registry manager instance
_registry_manager: Optional[RegistryManager] = None


def get_registry_manager() -> RegistryManager:
    """Get the global registry manager instance."""
    global _registry_manager
    if _registry_manager is None:
        _registry_manager = RegistryManager()
    return _registry_manager


def reset_registry_manager() -> None:
    """Reset the global registry manager (for testing)."""
    global _registry_manager
    _registry_manager = None