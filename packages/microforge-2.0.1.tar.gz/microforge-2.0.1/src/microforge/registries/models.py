"""
Pydantic models for type-safe registry items in Microforge v2.

These models provide validation and type safety for all registry configurations.
Migrated and enhanced from the original registry models.
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime


class RegistryItem(BaseModel):
    """Base model for all registry items.

    Common fields shared by all registry items (agents, hooks, services, applications).
    """
    id: str = Field(..., description="Unique identifier")
    display_name: str = Field(..., description="Display name for UI")
    description: str = Field("", description="Item description")
    enabled: bool = Field(True, description="Whether item is enabled")
    version: str = Field("1.0.0", description="Item version")
    created_at: str = Field(default_factory=lambda: datetime.now().isoformat(), description="Creation timestamp")
    updated_at: str = Field(default_factory=lambda: datetime.now().isoformat(), description="Last update timestamp")

    class Config:
        extra = "allow"  # Allow additional fields


class AgentModel(RegistryItem):
    """Model for agent configuration.

    Validates agent registry entries with specific agent fields.
    """
    file_name: str = Field(..., description="Instruction file name (markdown)")
    service: Optional[str] = Field(None, description="Service name for service-specific agents")
    is_global: bool = Field(True, description="Whether agent is global or service-specific")
    input_schema: Dict[str, Any] = Field(
        default_factory=dict,
        description="JSON schema for input parameters"
    )
    output: Dict[str, str] = Field(
        default_factory=dict,
        description="Output configuration (format, location)"
    )
    category: Optional[str] = Field(None, description="Agent category (analysis, security, etc.)")
    tags: List[str] = Field(default_factory=list, description="Agent tags for filtering")

    # Optional model parameters
    temperature: Optional[float] = Field(
        None, ge=0.0, le=1.0,
        description="Controls randomness in responses"
    )
    max_tokens: Optional[int] = Field(
        None,
        description="Maximum tokens to generate"
    )
    provider: str = Field(default="claude", description="LLM provider to use")


class HookModel(RegistryItem):
    """Model for hook configuration.

    Validates hook registry entries with hook-specific fields.
    """
    file_name: str = Field(..., description="Hook instruction file name")
    priority: int = Field(1, description="Hook execution priority")
    event_type: str = Field(..., description="Event type that triggers this hook")

    # Hook conditions
    conditions: Dict[str, Any] = Field(
        default_factory=dict,
        description="Conditions for hook execution"
    )


class ServiceModel(RegistryItem):
    """Model for service configuration.

    Validates service registry entries with service-specific fields.
    """
    name: str = Field(..., description="Service name")
    repo_url: str = Field(..., description="Repository URL")
    branch: str = Field(default="main", description="Git branch")
    application: Optional[str] = Field(None, description="Application group")
    impl_agent: str = Field(default="implementation", description="Implementation agent")

    # Service metadata
    tags: List[str] = Field(default_factory=list, description="Service tags")
    dependencies: List[str] = Field(default_factory=list, description="Service dependencies")


class ApplicationModel(RegistryItem):
    """Model for application group configuration.

    Validates application registry entries with application-specific fields.
    """
    name: str = Field(..., description="Application name")
    services: List[str] = Field(default_factory=list, description="Services in this application")

    # Application metadata
    owner: Optional[str] = Field(None, description="Application owner")
    repository: Optional[str] = Field(None, description="Main repository")


class CapabilityModel(RegistryItem):
    """Model for capability configuration.

    Validates capability registry entries.
    """
    capability_type: str = Field(..., description="Type of capability")
    provider: str = Field(..., description="Provider for this capability")
    config: Dict[str, Any] = Field(
        default_factory=dict,
        description="Capability-specific configuration"
    )


class WorkflowStepModel(BaseModel):
    """Model for a single workflow step."""
    id: str = Field(..., description="Unique step identifier")
    type: str = Field(default="agent", description="Step type (agent, parallel, service, custom)")
    agent: Optional[str] = Field(None, description="Agent ID from registry")
    agents: Optional[List[str]] = Field(None, description="Agent IDs for parallel execution")
    service: Optional[str] = Field(None, description="Service method to call")
    depends_on: List[str] = Field(default_factory=list, description="Step dependencies")
    parallel_with: Optional[List[str]] = Field(None, description="Steps to run in parallel with")
    context_from: List[str] = Field(default_factory=list, description="Context sources from previous steps")
    inputs: Dict[str, Any] = Field(default_factory=dict, description="Step-specific inputs")
    conditions: Optional[List[Dict[str, Any]]] = Field(None, description="Conditional routing rules")
    branches: Optional[Dict[str, str]] = Field(None, description="Branch targets for conditions")
    description: Optional[str] = Field(None, description="Step description")


class WorkflowModel(RegistryItem):
    """Model for workflow configuration.

    Defines multi-agent workflow orchestration using LangGraph.
    """
    # Workflow structure
    steps: List[WorkflowStepModel] = Field(..., description="Workflow steps")

    # Workflow metadata
    category: str = Field(default="general", description="Workflow category")
    tags: List[str] = Field(default_factory=list, description="Workflow tags")

    # Input/Output specification
    input_schema: Dict[str, Any] = Field(
        default_factory=dict,
        description="JSON schema for workflow inputs"
    )
    output_schema: Dict[str, Any] = Field(
        default_factory=dict,
        description="Expected output structure"
    )

    # Execution configuration
    timeout_seconds: Optional[int] = Field(None, description="Workflow timeout")
    max_retries: int = Field(default=0, description="Maximum retry attempts")
    retry_on_failure: bool = Field(default=False, description="Whether to retry on failure")

    # LangGraph specific
    checkpointing: bool = Field(default=True, description="Enable state checkpointing")
    parallel_execution: bool = Field(default=True, description="Enable parallel step execution")

    # Dynamic workflow support
    is_template: bool = Field(default=False, description="Whether this is a workflow template")
    supports_dynamic: bool = Field(default=False, description="Whether workflow supports dynamic generation")