"""
Application Registry for managing application groups in Microforge v2.

Applications are logical groups that contain multiple related microservices.
"""

from typing import Dict, List, Optional, Any
from datetime import datetime

from ..core.common import console
from ..core.exceptions import ValidationError, NotFoundError
from ..repositories import RepositoryFactory, QueryFilter
from .base import BaseRegistry
from .models import ApplicationModel


class ApplicationRegistry(BaseRegistry):
    """Registry for managing applications (groups of services).

    Applications group related microservices together for better organization.
    """

    def __init__(self, refresh_interval: float = 5.0):
        """Initialize application registry.

        Args:
            refresh_interval: Seconds between auto-refresh checks
        """
        super().__init__("applications", refresh_interval)
        # Create repository instance using factory
        self.repository = RepositoryFactory.create_application_repository()

    def add_application(self, name: str, description: str = "", **kwargs) -> bool:
        """Register a new application.

        Args:
            name: Application name (unique identifier)
            description: Application description
            **kwargs: Additional application configuration

        Returns:
            True if registered successfully, False if already exists
        """
        if self.repository.exists(name):
            raise ValidationError(f"Application '{name}' already exists", field="name", value=name)

        app_config = {
            "id": name,
            "name": name,
            "display_name": kwargs.get('display_name', name.replace('_', ' ').title()),
            "description": description,
            "enabled": kwargs.get('enabled', True),
            "version": kwargs.get('version', "1.0.0"),
            "services": [],
            "owner": kwargs.get('owner'),
            "repository": kwargs.get('repository'),
            "created_at": datetime.now().isoformat()
        }

        try:
            # Validate before adding
            ApplicationModel(**app_config)
            # Save using repository
            saved_entity = self.repository.save(app_config)
            return saved_entity is not None
        except Exception as e:
            console.print(f"[red]Failed to add application '{name}': {e}[/red]")
            return False

    def get_application(self, name: str) -> Optional[ApplicationModel]:
        """Get application by name.

        Args:
            name: Application name

        Returns:
            ApplicationModel instance or None if not found
        """
        config = self.repository.find_by_id(name)
        if not config:
            return None

        try:
            # Ensure required fields
            if 'id' not in config:
                config['id'] = name
            if 'name' not in config:
                config['name'] = name
            if 'display_name' not in config:
                config['display_name'] = name.replace('_', ' ').title()

            return ApplicationModel(**config)
        except Exception as e:
            console.print(f"[red]Error creating application model for '{name}': {e}[/red]")
            return None

    def update_application(self, name: str, **updates) -> bool:
        """Update existing application.

        Args:
            name: Application name to update
            **updates: Fields to update

        Returns:
            True if updated successfully
        """
        # Add timestamp to updates
        updates['updated_at'] = datetime.now().isoformat()

        # Update using repository
        updated_entity = self.repository.update(name, updates)
        if not updated_entity:
            raise NotFoundError(f"Application '{name}' not found", resource_type="application", resource_id=name)

        try:
            # Validate updated config
            ApplicationModel(**updated_entity)
            return True
        except Exception as e:
            console.print(f"[red]Failed to update application '{name}': {e}[/red]")
            return False

    def remove_application(self, name: str) -> bool:
        """Remove application from registry.

        Args:
            name: Application name to remove

        Returns:
            True if removed successfully
        """
        # Remove using repository
        deleted = self.repository.delete(name)
        if not deleted:
            raise NotFoundError(f"Application '{name}' not found", resource_type="application", resource_id=name)
        return True

    def list_applications(self) -> List[Dict[str, Any]]:
        """List all applications as dictionaries (for backwards compatibility).

        Returns:
            List of application dictionaries
        """
        applications = []
        all_apps = self.repository.find_all()
        for config in all_apps:
            # Get the app name from the data
            name = config.get('id', config.get('name', ''))
            if not name:
                continue

            # Ensure required fields are present
            app_data = dict(config)
            if 'name' not in app_data:
                app_data['name'] = name
            if 'id' not in app_data:
                app_data['id'] = name
            if 'display_name' not in app_data:
                app_data['display_name'] = name.replace('_', ' ').title()
            if 'services' not in app_data:
                app_data['services'] = []

            applications.append(app_data)
        return applications

    def list_application_models(self) -> List[ApplicationModel]:
        """List all applications as validated models.

        Returns:
            List of ApplicationModel instances
        """
        applications = []
        all_apps = self.repository.find_all()
        for config in all_apps:
            try:
                # Get the app name from the data
                name = config.get('id', config.get('name', ''))
                if not name:
                    continue

                # Ensure required fields
                if 'id' not in config:
                    config['id'] = name
                if 'name' not in config:
                    config['name'] = name
                if 'display_name' not in config:
                    config['display_name'] = name.replace('_', ' ').title()

                app = ApplicationModel(**config)
                applications.append(app)
            except Exception as e:
                name = config.get('id', 'unknown')
                console.print(f"[yellow]Warning: Failed to load application '{name}': {e}[/yellow]")
        return applications

    def add_service_to_application(self, app_name: str, service_name: str) -> bool:
        """Add service to application.

        Args:
            app_name: Application name
            service_name: Service name to add

        Returns:
            True if service was added successfully
        """
        app_data = self.repository.find_by_id(app_name)
        if not app_data:
            raise NotFoundError(f"Application '{app_name}' not found", resource_type="application", resource_id=app_name)

        services = app_data.get('services', [])
        if service_name not in services:
            services.append(service_name)
            return self.update_application(app_name, services=services)
        return True

    def remove_service_from_application(self, app_name: str, service_name: str) -> bool:
        """Remove service from application.

        Args:
            app_name: Application name
            service_name: Service name to remove

        Returns:
            True if service was removed successfully
        """
        app_data = self.repository.find_by_id(app_name)
        if not app_data:
            raise NotFoundError(f"Application '{app_name}' not found", resource_type="application", resource_id=app_name)

        services = app_data.get('services', [])
        if service_name in services:
            services.remove(service_name)
            return self.update_application(app_name, services=services)
        return True

    def get_application_services(self, app_name: str) -> List[str]:
        """Get services for an application.

        Args:
            app_name: Application name

        Returns:
            List of service names in the application
        """
        app = self.get_application(app_name)
        return app.services if app else []

    def get_service_count_by_application(self) -> Dict[str, int]:
        """Get service count for each application.

        Returns:
            Dictionary mapping application names to service counts
        """
        counts = {}
        all_apps = self.repository.find_all()
        for config in all_apps:
            name = config.get('id', config.get('name', ''))
            if name:
                counts[name] = len(config.get('services', []))
        return counts