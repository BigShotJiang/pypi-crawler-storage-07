"""
GitHub provider for GitHub-specific operations in Microforge v2.

Migrated from src/microforge/utils/github.py with improved architecture.
"""

import re
from pathlib import Path
from typing import Optional, Dict, Any

from ...config.constants import (
    GITHUB_CLI_EXECUTABLE,
    GITHUB_URL_PATTERN,
    GITHUB_SSH_PATTERN
)
from ...core.common import run_command
from ...core.exceptions import ProviderError
from ..base import BaseProvider
from .git import GitProvider


class GitHubProvider(BaseProvider):
    """
    GitHub operations provider for GitHub-specific functionality.

    Provides GitHub CLI integration and repository parsing with proper error handling.
    """

    def __init__(self):
        super().__init__("github")

    def get_repo_info(self, path: Optional[Path] = None) -> Optional[Dict[str, str]]:
        """
        Get GitHub repository information from git remote.

        Args:
            path: Repository path (default: current directory)

        Returns:
            Dict with keys: owner, repo, full_name
            None if not a GitHub repository
        """
        try:
            # Get remote URL using GitProvider
            remote_url = GitProvider.get_remote_url(path)
            if not remote_url:
                return None
            return self.parse_github_repo(remote_url)

        except Exception:
            return None

    def is_cli_available(self) -> bool:
        """
        Check if GitHub CLI is installed and authenticated.

        Returns:
            True if gh CLI is available and authenticated
        """
        try:
            # Check if gh is installed
            result = run_command([GITHUB_CLI_EXECUTABLE, "--version"], capture_output=True)
            if result.returncode != 0:
                return False

            # Check if authenticated
            result = run_command(
                [GITHUB_CLI_EXECUTABLE, "auth", "status"],
                capture_output=True
            )
            return result.returncode == 0

        except Exception:
            return False

    def parse_github_repo(self, repo: str) -> Optional[Dict[str, str]]:
        """
        Parse GitHub repository from various formats.

        Args:
            repo: Repository in format:
                - owner/repo
                - https://github.com/owner/repo
                - git@github.com:owner/repo.git

        Returns:
            Dict with keys: owner, repo, full_name
            None if invalid format
        """
        if not repo:
            return None

        # Handle full URL formats
        if '://' in repo or repo.startswith('git@'):
            # Try HTTPS pattern
            match = re.search(GITHUB_URL_PATTERN, repo)
            if not match:
                # Try SSH pattern
                match = re.search(GITHUB_SSH_PATTERN, repo)

            if match:
                owner = match.group(1)
                repo_name = match.group(2).replace('.git', '')
                return {
                    'owner': owner,
                    'repo': repo_name,
                    'full_name': f"{owner}/{repo_name}"
                }

        # Handle owner/repo format
        elif '/' in repo and not repo.startswith('http'):
            parts = repo.split('/')
            if len(parts) == 2:
                return {
                    'owner': parts[0],
                    'repo': parts[1],
                    'full_name': repo
                }

        return None

    def is_correct_repo(self, expected_repo_url: str, path: Optional[Path] = None) -> bool:
        """
        Check if current directory matches the expected GitHub repository.

        Args:
            expected_repo_url: Expected repository URL
            path: Repository path (default: current directory)

        Returns:
            True if current repo matches expected repo
        """
        try:
            # Get current repo URL using GitProvider
            current_remote = GitProvider.get_remote_url(path)
            if not current_remote:
                return False

            # Normalize URLs for comparison
            current = self._normalize_url(current_remote)
            expected = self._normalize_url(expected_repo_url)

            # Check if they match (handle both directions for flexibility)
            return expected in current or current in expected

        except Exception:
            return False

    def _normalize_url(self, url: str) -> str:
        """
        Normalize GitHub URL for comparison.

        Args:
            url: GitHub URL to normalize

        Returns:
            Normalized URL string
        """
        normalized = url.lower().replace('.git', '')

        # Convert SSH to HTTPS format for comparison
        if normalized.startswith('git@github.com:'):
            normalized = normalized.replace('git@github.com:', 'github.com/')

        # Ensure github.com/ format
        if not normalized.startswith('http'):
            if not normalized.startswith('github.com/'):
                normalized = 'github.com/' + normalized

        return normalized

    def run_gh_command(self, args: list, cwd: Optional[Path] = None) -> Dict[str, Any]:
        """
        Run GitHub CLI command with proper error handling.

        Args:
            args: GitHub CLI arguments (without 'gh')
            cwd: Working directory

        Returns:
            Dict with command result information

        Raises:
            ProviderError: If GitHub CLI is not available or command fails
        """
        if not self.is_cli_available():
            raise ProviderError(
                "GitHub CLI is not available or not authenticated",
                context={"command": args}
            )

        try:
            command = [GITHUB_CLI_EXECUTABLE] + args
            result = run_command(command, cwd=cwd, capture_output=True)

            return {
                "success": result.returncode == 0,
                "returncode": result.returncode,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "command": command
            }

        except Exception as e:
            raise ProviderError(
                f"GitHub CLI command failed: {str(e)}",
                context={"command": args}
            ) from e

    def get_status(self) -> Dict[str, Any]:
        """Get GitHub provider status."""
        try:
            # Check GitHub CLI availability
            cli_available = self.is_cli_available()

            # Get version if available
            version = None
            if cli_available:
                result = run_command([GITHUB_CLI_EXECUTABLE, "--version"], capture_output=True)
                if result.returncode == 0:
                    version = result.stdout.strip()

            return {
                "available": cli_available,
                "cli_version": version,
                "provider": self.name
            }

        except Exception:
            return {
                "available": False,
                "cli_version": None,
                "provider": self.name,
                "error": "GitHub CLI not found"
            }