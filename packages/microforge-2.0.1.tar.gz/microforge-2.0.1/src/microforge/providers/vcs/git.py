"""
Git provider for repository operations in Microforge v2.

Provides all git functionality in a single, centralized location.
"""

import subprocess
import tempfile
import shutil
from pathlib import Path
from typing import Optional, Dict, List, Tuple, Any
from urllib.parse import urlparse

from ...config.constants import (
    GIT_TIMEOUT_SECONDS,
    TEMP_PREFIX,
    GIT_CLONE_DEPTH,
    SUBPROCESS_DEFAULT_TIMEOUT,
    SUBPROCESS_ENCODING,
    SUBPROCESS_ERRORS
)
from ...core.common import run_command
from ...core.exceptions import ProviderError, GitError, create_exception
from ..base import BaseProvider


class GitProvider(BaseProvider):
    """
    Git operations provider for repository management.

    Provides comprehensive Git functionality with proper error handling and audit logging.
    """

    def __init__(self):
        super().__init__("git")

    @staticmethod
    def run_git_command(
        command: List[str],
        cwd: Optional[Path] = None,
        timeout: Optional[int] = None,
        capture_output: bool = True,
        check: bool = True
    ) -> subprocess.CompletedProcess:
        """
        Run a git command with standardized error handling.

        Args:
            command: Git command as list (e.g., ['git', 'status'])
            cwd: Working directory
            timeout: Command timeout in seconds
            capture_output: Whether to capture output
            check: Whether to raise on non-zero exit

        Returns:
            CompletedProcess result

        Raises:
            GitError: If git command fails
        """
        if not command or command[0] != 'git':
            command = ['git'] + command

        timeout = timeout or SUBPROCESS_DEFAULT_TIMEOUT

        try:
            result = subprocess.run(
                command,
                cwd=cwd,
                timeout=timeout,
                capture_output=capture_output,
                text=True,
                encoding=SUBPROCESS_ENCODING,
                errors=SUBPROCESS_ERRORS,
                check=check
            )
            return result

        except subprocess.TimeoutExpired as e:
            raise GitError(
                f"Git command timed out after {timeout} seconds",
                command=' '.join(command),
                timeout=timeout
            ) from e

        except subprocess.CalledProcessError as e:
            raise GitError(
                f"Git command failed with exit code {e.returncode}",
                command=' '.join(command),
                exit_code=e.returncode,
                stdout=e.stdout,
                stderr=e.stderr
            ) from e

    @classmethod
    def is_git_repository(cls, path: Optional[Path] = None) -> bool:
        """
        Check if a directory is a git repository.

        Args:
            path: Directory to check (defaults to current directory)

        Returns:
            True if it's a git repository, False otherwise
        """
        try:
            result = cls.run_git_command(
                ['rev-parse', '--git-dir'],
                cwd=path,
                capture_output=True,
                check=False
            )
            return result.returncode == 0
        except Exception:
            return False

    @classmethod
    def get_repository_root(cls, path: Optional[Path] = None) -> Optional[Path]:
        """
        Get the root directory of a git repository.

        Args:
            path: Path within the repository

        Returns:
            Repository root path or None if not a git repo
        """
        try:
            result = cls.run_git_command(
                ['rev-parse', '--show-toplevel'],
                cwd=path,
                capture_output=True,
                check=False
            )
            if result.returncode == 0 and result.stdout:
                return Path(result.stdout.strip())
        except Exception:
            pass
        return None

    @classmethod
    def get_remote_url(cls, path: Optional[Path] = None, remote: str = "origin") -> Optional[str]:
        """
        Get the URL of a git remote.

        Args:
            path: Repository path
            remote: Remote name (default: "origin")

        Returns:
            Remote URL or None if not found
        """
        try:
            result = cls.run_git_command(
                ['remote', 'get-url', remote],
                cwd=path,
                capture_output=True,
                check=False
            )
            if result.returncode == 0 and result.stdout:
                return result.stdout.strip()
        except Exception:
            pass
        return None

    @classmethod
    def get_current_branch(cls, path: Optional[Path] = None) -> Optional[str]:
        """
        Get the current git branch.

        Args:
            path: Repository path

        Returns:
            Branch name or None if not on a branch
        """
        try:
            result = cls.run_git_command(
                ['branch', '--show-current'],
                cwd=path,
                capture_output=True,
                check=False
            )
            if result.returncode == 0 and result.stdout:
                return result.stdout.strip()
        except Exception:
            pass
        return None

    @classmethod
    def get_repository_info(cls, path: Optional[Path] = None) -> Optional[Dict[str, str]]:
        """
        Get comprehensive git repository information.

        Args:
            path: Repository path (defaults to current directory)

        Returns:
            Dictionary with repository info or None if not a git repo
        """
        if not cls.is_git_repository(path):
            return None

        return {
            'remote_url': cls.get_remote_url(path) or '',
            'current_branch': cls.get_current_branch(path) or '',
            'repo_root': str(cls.get_repository_root(path) or '')
        }

    @classmethod
    def clone_repository(
        cls,
        repo_url: str,
        target_path: Path,
        branch: Optional[str] = None,
        depth: Optional[int] = None
    ) -> Path:
        """
        Clone a git repository.

        Args:
            repo_url: Repository URL (HTTPS or SSH)
            target_path: Target directory for clone
            branch: Specific branch to clone
            depth: Shallow clone depth

        Returns:
            Path to cloned repository

        Raises:
            GitError: If cloning fails
        """
        command = ['clone']

        if branch:
            command.extend(['-b', branch])

        if depth:
            command.extend(['--depth', str(depth)])

        command.extend([repo_url, str(target_path)])

        cls.run_git_command(command)
        return target_path

    @classmethod
    def clone_temp_repository(
        cls,
        repo_url: str,
        branch: str = "main",
        cleanup: bool = True
    ) -> Tuple[Path, Optional[callable]]:
        """
        Clone a repository to a temporary directory.

        Args:
            repo_url: Repository URL
            branch: Branch to clone (default: "main")
            cleanup: Whether to return cleanup function

        Returns:
            Tuple of (temp_path, cleanup_function)
            cleanup_function is None if cleanup=False

        Raises:
            GitError: If cloning fails
        """
        temp_dir = Path(tempfile.mkdtemp(prefix="microforge_clone_"))

        try:
            cls.clone_repository(repo_url, temp_dir, branch=branch, depth=1)

            # Create cleanup function if requested
            cleanup_fn = None
            if cleanup:
                def cleanup_temp_repo():
                    if temp_dir.exists():
                        shutil.rmtree(temp_dir, ignore_errors=True)
                cleanup_fn = cleanup_temp_repo

            return temp_dir, cleanup_fn

        except Exception:
            # Clean up on failure
            if temp_dir.exists():
                shutil.rmtree(temp_dir, ignore_errors=True)
            raise

    def clone_temp_repo(self, repo_url: str, branch: str = "main") -> Path:
        """
        Clone repository to temporary directory for analysis.

        Legacy method for backward compatibility.
        """
        temp_path, _ = self.clone_temp_repository(repo_url, branch, cleanup=False)
        return temp_path

    @classmethod
    def get_changed_files(
        cls,
        path: Optional[Path] = None,
        staged: bool = False
    ) -> List[str]:
        """
        Get list of changed files in repository.

        Args:
            path: Repository path
            staged: If True, only show staged files

        Returns:
            List of changed file paths
        """
        try:
            command = ['diff', '--name-only']
            if staged:
                command.append('--cached')

            result = cls.run_git_command(
                command,
                cwd=path,
                capture_output=True,
                check=False
            )

            if result.returncode == 0 and result.stdout:
                return [f.strip() for f in result.stdout.splitlines() if f.strip()]
        except Exception:
            pass
        return []

    @classmethod
    def get_commit_hash(
        cls,
        path: Optional[Path] = None,
        short: bool = True
    ) -> Optional[str]:
        """
        Get current commit hash.

        Args:
            path: Repository path
            short: If True, return short hash

        Returns:
            Commit hash or None
        """
        try:
            command = ['rev-parse']
            if short:
                command.append('--short')
            command.append('HEAD')

            result = cls.run_git_command(
                command,
                cwd=path,
                capture_output=True,
                check=False
            )

            if result.returncode == 0 and result.stdout:
                return result.stdout.strip()
        except Exception:
            pass
        return None

    @classmethod
    def add_files(cls, files: List[str], path: Optional[Path] = None) -> bool:
        """
        Add files to git staging area.

        Args:
            files: List of file paths to add
            path: Repository path

        Returns:
            True if successful
        """
        try:
            command = ['add'] + files
            result = cls.run_git_command(
                command,
                cwd=path,
                capture_output=True,
                check=False
            )
            return result.returncode == 0
        except Exception:
            return False

    @classmethod
    def commit(
        cls,
        message: str,
        path: Optional[Path] = None,
        author: Optional[str] = None
    ) -> bool:
        """
        Create a git commit.

        Args:
            message: Commit message
            path: Repository path
            author: Author string (e.g., "Name <email>")

        Returns:
            True if successful
        """
        try:
            command = ['commit', '-m', message]
            if author:
                command.extend(['--author', author])

            result = cls.run_git_command(
                command,
                cwd=path,
                capture_output=True,
                check=False
            )
            return result.returncode == 0
        except Exception:
            return False

    @classmethod
    def push(
        cls,
        path: Optional[Path] = None,
        remote: str = "origin",
        branch: Optional[str] = None
    ) -> bool:
        """
        Push commits to remote repository.

        Args:
            path: Repository path
            remote: Remote name
            branch: Branch to push (defaults to current)

        Returns:
            True if successful
        """
        try:
            command = ['push', remote]
            if branch:
                command.append(branch)

            result = cls.run_git_command(
                command,
                cwd=path,
                capture_output=True,
                check=False
            )
            return result.returncode == 0
        except Exception:
            return False

    @classmethod
    def checkout(cls, branch: str, create: bool = False, path: Optional[Path] = None) -> bool:
        """
        Checkout a git branch.

        Args:
            branch: Branch name to checkout
            create: If True, create a new branch
            path: Repository path

        Returns:
            True if successful
        """
        try:
            command = ['checkout']
            if create:
                command.append('-b')
            command.append(branch)

            result = cls.run_git_command(
                command,
                cwd=path,
                capture_output=True,
                check=False
            )
            return result.returncode == 0
        except Exception:
            return False

    @classmethod
    def pull(
        cls,
        path: Optional[Path] = None,
        remote: str = "origin",
        branch: Optional[str] = None
    ) -> bool:
        """
        Pull changes from remote repository.

        Args:
            path: Repository path
            remote: Remote name
            branch: Branch to pull

        Returns:
            True if successful
        """
        try:
            command = ['pull', remote]
            if branch:
                command.append(branch)

            result = cls.run_git_command(
                command,
                cwd=path,
                capture_output=True,
                check=False
            )
            return result.returncode == 0
        except Exception:
            return False

    @classmethod
    def extract_repo_info_from_url(cls, url: str) -> Dict[str, str]:
        """
        Extract repository information from a git URL.

        Args:
            url: Git repository URL (HTTPS or SSH)

        Returns:
            Dictionary with owner and repo name
        """
        info = {'owner': '', 'repo': ''}

        # Handle SSH URLs
        if url.startswith('git@'):
            # git@github.com:owner/repo.git
            parts = url.split(':')
            if len(parts) == 2:
                path_parts = parts[1].replace('.git', '').split('/')
                if len(path_parts) == 2:
                    info['owner'] = path_parts[0]
                    info['repo'] = path_parts[1]

        # Handle HTTPS URLs
        else:
            parsed = urlparse(url)
            path_parts = parsed.path.strip('/').replace('.git', '').split('/')
            if len(path_parts) >= 2:
                info['owner'] = path_parts[-2]
                info['repo'] = path_parts[-1]

        return info

    def cleanup_temp_repo(self, repo_path: Optional[Path]) -> bool:
        """
        Clean up temporary repository.

        Args:
            repo_path: Path to repository to clean up

        Returns:
            True if cleanup successful, False otherwise
        """
        try:
            if not repo_path or not repo_path.exists():
                return True

            # Find the temp directory (parent of repo)
            temp_dir = repo_path.parent

            # Safety check - only remove directories with our prefix
            if temp_dir.name.startswith(TEMP_PREFIX.rstrip('_')):
                shutil.rmtree(temp_dir, ignore_errors=True)
                return True
            else:
                # If not our temp dir, just remove the repo directory
                shutil.rmtree(repo_path, ignore_errors=True)
                return True

        except Exception:
            return False

    @classmethod
    def get_commit_history(cls, path: Optional[Path] = None, limit: int = 200) -> List[Dict[str, Any]]:
        """
        Get detailed commit history with messages and stats.

        Args:
            path: Repository path
            limit: Maximum number of commits to retrieve

        Returns:
            List of commit dictionaries with details
        """
        try:
            # Get commit log with detailed information
            command = [
                'log',
                f'--max-count={limit}',
                '--pretty=format:%H|%an|%ae|%at|%s',
                '--name-status'
            ]

            result = cls.run_git_command(
                command,
                cwd=path,
                capture_output=True,
                check=False
            )

            if result.returncode != 0:
                return []

            # Parse the commit log
            commits = []
            current_commit = None

            for line in result.stdout.splitlines():
                if '|' in line and len(line.split('|')) == 5:
                    # This is a commit line
                    if current_commit:
                        commits.append(current_commit)

                    parts = line.split('|')
                    current_commit = {
                        'hash': parts[0],
                        'author': parts[1],
                        'email': parts[2],
                        'timestamp': int(parts[3]),
                        'message': parts[4],
                        'files': []
                    }
                elif line.strip() and current_commit:
                    # This is a file change line
                    parts = line.strip().split('\t')
                    if len(parts) >= 2:
                        current_commit['files'].append({
                            'status': parts[0],
                            'path': parts[1]
                        })

            if current_commit:
                commits.append(current_commit)

            return commits

        except Exception as e:
            return []


    @classmethod
    def get_file_change_frequency(cls, path: Optional[Path] = None, limit: int = 200) -> Dict[str, int]:
        """
        Get frequency of file changes in recent commits.

        Args:
            path: Repository path
            limit: Number of commits to analyze

        Returns:
            Dictionary mapping file paths to change frequency
        """
        commits = cls.get_commit_history(path, limit)
        file_frequency = {}

        for commit in commits:
            for file_info in commit.get('files', []):
                file_path = file_info['path']
                file_frequency[file_path] = file_frequency.get(file_path, 0) + 1

        return file_frequency

    def get_status(self) -> Dict[str, Any]:
        """Get Git provider status."""
        try:
            # Check if git is available
            result = run_command(["git", "--version"], capture_output=True)
            git_available = result.returncode == 0
            git_version = result.stdout.strip() if git_available else None

            return {
                "available": git_available,
                "version": git_version,
                "provider": self.name
            }
        except Exception:
            return {
                "available": False,
                "version": None,
                "provider": self.name,
                "error": "Git not found"
            }


# Convenience functions for backward compatibility
def is_git_repository(path: Optional[Path] = None) -> bool:
    """Check if a directory is a git repository."""
    try:
        import subprocess
        result = subprocess.run(
            ['git', 'rev-parse', '--git-dir'],
            cwd=path,
            capture_output=True,
            text=True,
            timeout=1
        )
        return result.returncode == 0
    except Exception:
        return False


def get_git_repository_info(path: Optional[Path] = None) -> Optional[Dict[str, str]]:
    """Get git repository information."""
    return GitProvider.get_repository_info(path)


def clone_temp_repo(repo_url: str, branch: str = "main") -> Path:
    """Clone a repository to a temporary directory (legacy interface)."""
    temp_path, _ = GitProvider.clone_temp_repository(repo_url, branch, cleanup=False)
    return temp_path