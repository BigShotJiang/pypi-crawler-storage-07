"""
VCS (Version Control System) providers for Microforge v2.

This module provides abstraction for different VCS systems.
"""

from .git import GitProvider, is_git_repository, get_git_repository_info
from .github import GitHubProvider

__all__ = [
    "GitProvider",
    "GitHubProvider",
    "is_git_repository",
    "get_git_repository_info"
]