"""
Base provider classes for Microforge v2.

Provides abstract base classes for all provider implementations.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional


class BaseProvider(ABC):
    """
    Abstract base class for all providers.

    Providers handle external integrations like Git, GitHub, Claude CLI, etc.
    """

    def __init__(self, name: str):
        """
        Initialize base provider.

        Args:
            name: Provider name for identification
        """
        self.name = name

    @abstractmethod
    def get_status(self) -> Dict[str, Any]:
        """
        Get provider status information.

        Returns:
            Dictionary with provider status details
        """
        pass

    def is_available(self) -> bool:
        """
        Check if provider is available.

        Returns:
            True if provider is available, False otherwise
        """
        try:
            status = self.get_status()
            return status.get("available", False)
        except Exception:
            return False

    def __str__(self) -> str:
        """String representation of provider."""
        return f"{self.__class__.__name__}(name={self.name})"

    def __repr__(self) -> str:
        """Detailed string representation of provider."""
        return f"{self.__class__.__name__}(name='{self.name}')"