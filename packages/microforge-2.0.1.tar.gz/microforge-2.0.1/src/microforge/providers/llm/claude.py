"""
Claude LLM provider for Microforge v2.

Preserves the existing Claude CLI subprocess pattern while providing abstraction.
"""

import os
import shutil
import subprocess
from pathlib import Path
from typing import Dict, Any, Optional, List

from ...core.common import console, check_executable_available, run_command
from ...core.exceptions import ClaudeError, TimeoutError
from ...config.constants import (
    CLAUDE_CLI_EXECUTABLE,
    CLAUDE_DEFAULT_TOOLS,
    CLAUDE_ANALYSIS_TOOLS,
    CLAUDE_DEFAULT_TIMEOUT,
    CLAUDE_BATCH_TIMEOUT,
    AGENTS_SUBDIR,
    ERROR_CLAUDE_CLI_NOT_FOUND,
    ERROR_CLAUDE_EXECUTION_FAILED,
    ERROR_CLAUDE_TIMEOUT
)
from .base import BaseLLMProvider, LLMProviderType


class ClaudeProvider(BaseLLMProvider):
    """Claude CLI provider maintaining subprocess pattern."""

    def __init__(self):
        super().__init__(LLMProviderType.CLAUDE)
        self.claude_path = self._find_claude_cli()
        self.agents_dir = self._get_agents_directory()
        self.last_output = None
        self.last_error = None

    def _find_claude_cli(self) -> Optional[str]:
        """Find Claude CLI executable."""
        claude_path = shutil.which(CLAUDE_CLI_EXECUTABLE)
        if not claude_path:
            console.print(f"[red]❌ {ERROR_CLAUDE_CLI_NOT_FOUND}[/red]")
            console.print("[dim]Install with: npm install -g @anthropic-ai/claude[/dim]")
        return claude_path

    def _get_agents_directory(self) -> Path:
        """Get the agents directory path."""
        from ...config.constants import PACKAGE_DIR
        return PACKAGE_DIR / AGENTS_SUBDIR

    def is_available(self) -> bool:
        """Check if Claude CLI is available."""
        return self.claude_path is not None and check_executable_available(CLAUDE_CLI_EXECUTABLE)

    def get_health_status(self) -> Dict[str, Any]:
        """Get health status of Claude provider."""
        status = {
            "executable_found": self.claude_path is not None,
            "executable_path": self.claude_path,
            "agents_directory": str(self.agents_dir),
            "agents_exist": self.agents_dir.exists()
        }

        if self.agents_dir.exists():
            agent_files = list(self.agents_dir.glob("*.md"))
            status["available_agents"] = [f.name for f in agent_files]
            status["agent_count"] = len(agent_files)
        else:
            status["available_agents"] = []
            status["agent_count"] = 0

        return status

    def execute_prompt(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        tools: Optional[List[str]] = None,
        interactive: bool = True,
        working_dir: Optional[Path] = None
    ) -> bool:
        """
        Execute a prompt with Claude CLI.

        Args:
            prompt: The prompt to execute
            system_prompt: Optional system prompt
            tools: List of allowed tools
            interactive: Run interactively or batch mode
            working_dir: Working directory for execution

        Returns:
            Success status

        Raises:
            ClaudeError: If Claude execution fails
        """
        if not self.is_available():
            raise ClaudeError(ERROR_CLAUDE_CLI_NOT_FOUND)

        # Set up environment
        original_dir = os.getcwd()
        if working_dir:
            os.chdir(working_dir)

        try:
            if interactive:
                return self._run_interactive_claude(prompt, system_prompt, tools or CLAUDE_DEFAULT_TOOLS)
            else:
                return self._run_batch_claude(prompt, tools or CLAUDE_ANALYSIS_TOOLS, system_prompt)

        finally:
            os.chdir(original_dir)


    def _run_interactive_claude(
        self,
        prompt: str,
        system_prompt: Optional[str],
        tools: List[str]
    ) -> bool:
        """Run Claude in interactive mode."""
        console.print("\n[bold cyan]🤖 Starting Claude Interactive Session[/bold cyan]")
        console.print("[dim]Executing prompt with Claude...[/dim]\n")

        try:
            # Build Claude command
            cmd = [self.claude_path]

            # Add allowed tools
            cmd.extend(["--allowed-tools", ",".join(tools)])

            # Add system prompt if provided
            if system_prompt:
                cmd.extend(["--append-system-prompt", system_prompt])

            # Add the prompt
            cmd.append(prompt)

            console.print(f"[dim]Working directory: {os.getcwd()}[/dim]")
            console.print(f"[yellow]Claude will execute the command.[/yellow]\n")

            # Run Claude interactively with the initial command
            result = subprocess.run(cmd, check=False, timeout=CLAUDE_DEFAULT_TIMEOUT)

            return result.returncode == 0

        except subprocess.TimeoutExpired:
            console.print(f"[red]❌ {ERROR_CLAUDE_TIMEOUT}[/red]")
            raise TimeoutError(
                ERROR_CLAUDE_TIMEOUT,
                timeout_seconds=CLAUDE_DEFAULT_TIMEOUT,
                operation="claude_interactive"
            )
        except Exception as e:
            console.print(f"[red]❌ Error launching Claude: {e}[/red]")
            raise ClaudeError(
                f"Failed to launch Claude: {str(e)}"
            ) from e

    def _run_batch_claude(
        self,
        prompt: str,
        tools: List[str],
        system_prompt: Optional[str] = None
    ) -> bool:
        """Run Claude in batch mode (non-interactive)."""
        console.print("\n[bold cyan]🤖 Running Claude in Batch Mode[/bold cyan]")
        console.print("[dim]Executing without user interaction...[/dim]\n")

        # Build command with prompt as positional argument
        cmd = [
            self.claude_path,
            "--print",  # Non-interactive mode
            "--output-format", "text",
            "--allowed-tools", ",".join(tools)
        ]

        # Add system prompt if provided
        if system_prompt:
            cmd.extend(["--append-system-prompt", system_prompt])

        # Add prompt as positional argument at the end
        cmd.append(prompt)

        try:
            # Run without stdin input
            process = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=CLAUDE_BATCH_TIMEOUT,
                check=False
            )

            if process.returncode == 0:
                console.print("[green]✅ Claude execution completed[/green]")
                if process.stdout:
                    # Store the full output
                    self.last_output = process.stdout
                    self.last_error = None

                    # Show truncated output
                    output = process.stdout
                    if len(output) > 1000:
                        console.print("\n[dim]Claude output (truncated):[/dim]")
                        console.print(output[:1000] + "...")
                    else:
                        console.print("\n[dim]Claude output:[/dim]")
                        console.print(output)
                else:
                    self.last_output = "Claude execution completed successfully"
                    self.last_error = None
                return True
            else:
                console.print("[red]❌ Claude execution failed[/red]")
                if process.stderr:
                    console.print(f"[dim]Error: {process.stderr[:500]}[/dim]")
                    self.last_error = process.stderr
                    self.last_output = None
                else:
                    self.last_error = "Claude execution failed"
                    self.last_output = None
                return False

        except subprocess.TimeoutExpired:
            console.print(f"[red]❌ {ERROR_CLAUDE_TIMEOUT}[/red]")
            raise TimeoutError(
                ERROR_CLAUDE_TIMEOUT,
                timeout_seconds=CLAUDE_BATCH_TIMEOUT,
                operation="claude_batch"
            )
        except Exception as e:
            console.print(f"[red]❌ {ERROR_CLAUDE_EXECUTION_FAILED}: {e}[/red]")
            raise ClaudeError(
                f"Claude batch execution failed: {str(e)}"
            ) from e