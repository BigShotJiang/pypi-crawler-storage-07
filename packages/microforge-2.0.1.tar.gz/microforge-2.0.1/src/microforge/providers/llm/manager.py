"""
LLM Manager for Microforge v2.

Provides a simplified interface for LLM operations that automatically
selects the appropriate provider based on configuration.
"""

from typing import Dict, Any, Optional
import logging

from .factory import get_llm_provider
from .base import BaseLLMProvider, LLMRequest
from ...config.settings import get_settings
from ...core.exceptions import LLMError

logger = logging.getLogger(__name__)


class LLMManager:
    """
    Manages LLM operations with automatic provider selection.

    This class provides a simplified interface that automatically
    selects the appropriate LLM provider based on configuration
    and availability.
    """

    def __init__(self, provider_override: Optional[str] = None):
        """
        Initialize LLM Manager.

        Args:
            provider_override: Optional provider name to override config
        """
        self.settings = get_settings()
        self.provider_override = provider_override
        self._provider: Optional[BaseLLMProvider] = None

    @property
    def provider(self) -> BaseLLMProvider:
        """Get the active LLM provider."""
        if self._provider is None:
            self._provider = get_llm_provider(self.provider_override)
        return self._provider

    def run_analysis(
        self,
        command_type: str,
        context: Dict[str, Any],
        interactive: bool = True
    ) -> bool:
        """
        Run an analysis command using the configured LLM provider.

        Args:
            command_type: Type of command to run
            context: Context for the command
            interactive: Whether to run in interactive mode

        Returns:
            True if successful, False otherwise
        """

        try:
            logger.info(f"Running {command_type} with {self.provider.provider_type.value} provider")

            # Create LLM request from context
            request = LLMRequest(
                command_type=command_type,
                context=context,
                interactive=interactive
            )

            # Execute request through provider
            response = self.provider.execute(request)
            return response.success

        except LLMError as e:
            logger.error(f"LLM error during {command_type}: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error during {command_type}: {e}")
            return False

    def generate_content(
        self,
        prompt: str,
        context: Optional[Dict[str, Any]] = None,
        **kwargs
    ) -> Optional[str]:
        """
        Generate content using the configured LLM provider.

        Args:
            prompt: The prompt to send to the LLM
            context: Optional context for the generation
            **kwargs: Additional provider-specific parameters

        Returns:
            Generated content or None if failed
        """
        try:
            result_context = context or {}
            result_context['prompt'] = prompt

            # Create request and execute
            request = LLMRequest(
                command_type='generate',
                context=result_context,
                interactive=False
            )

            response = self.provider.execute(request)

            # Return output if available
            if response.success and response.output:
                return response.output
            return "Generation successful" if response.success else None

        except Exception as e:
            logger.error(f"Failed to generate content: {e}")
            return None

    def supports_command(self, command_type: str) -> bool:
        """
        Check if the current provider supports a command type.

        Args:
            command_type: Type of command to check

        Returns:
            True if supported, False otherwise
        """
        try:
            return self.provider.supports_command(command_type)
        except Exception as e:
            logger.error(f"Failed to check command support: {e}")
            return False

    def get_provider_info(self) -> Dict[str, Any]:
        """Get information about the current provider."""
        try:
            return {
                'name': self.provider.provider_type.value,
                'info': self.provider.get_provider_info(),
                'available': self.provider.is_available()
            }
        except Exception as e:
            logger.error(f"Failed to get provider info: {e}")
            return {
                'name': 'unknown',
                'error': str(e),
                'available': False
            }


# Global manager instance
_llm_manager: Optional[LLMManager] = None


def get_llm_manager(provider_override: Optional[str] = None) -> LLMManager:
    """
    Get the global LLM manager instance.

    Args:
        provider_override: Optional provider name to override config

    Returns:
        LLM manager instance
    """
    global _llm_manager
    if _llm_manager is None or (provider_override and _llm_manager.provider_override != provider_override):
        _llm_manager = LLMManager(provider_override)
    return _llm_manager


def run_llm_analysis(
    command_type: str,
    context: Dict[str, Any],
    interactive: bool = True,
    provider: Optional[str] = None
) -> bool:
    """
    Convenience function to run an LLM analysis.

    This replaces the old execute_with_claude function.

    Args:
        command_type: Type of command to run
        context: Context for the command
        interactive: Whether to run in interactive mode
        provider: Optional provider override

    Returns:
        True if successful, False otherwise
    """
    manager = get_llm_manager(provider)
    return manager.run_analysis(command_type, context, interactive)