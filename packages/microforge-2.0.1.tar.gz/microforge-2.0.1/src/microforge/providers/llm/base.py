"""
Base LLM provider interface for Microforge v2.

Provides abstract interface for all LLM providers with consistent functionality.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, List
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

from ...core.exceptions import LLMError


class LLMProviderType(Enum):
    """Types of LLM providers."""
    CLAUDE = "claude"
    OPENAI = "openai"
    CURSOR = "cursor"
    LOCAL = "local"


@dataclass
class LLMRequest:
    """Request for LLM operations."""
    command_type: str
    context: Dict[str, Any]
    interactive: bool = True
    tools: Optional[List[str]] = None
    timeout: Optional[int] = None


@dataclass
class LLMResponse:
    """Response from LLM operations."""
    success: bool
    provider: str
    command_type: str
    duration_ms: Optional[float] = None
    output: Optional[str] = None
    error: Optional[str] = None
    context: Optional[Dict[str, Any]] = None


class BaseLLMProvider(ABC):
    """Abstract base class for LLM providers."""

    def __init__(self, provider_type: LLMProviderType):
        self.provider_type = provider_type
        self.provider_name = provider_type.value

    @abstractmethod
    def is_available(self) -> bool:
        """Check if the LLM provider is available."""
        pass

    @abstractmethod
    def get_health_status(self) -> Dict[str, Any]:
        """Get health status of the provider."""
        pass

    @abstractmethod
    def execute_prompt(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        tools: Optional[List[str]] = None,
        interactive: bool = True,
        working_dir: Optional[Path] = None
    ) -> bool:
        """
        Execute a prompt with the LLM provider.

        Args:
            prompt: The prompt to execute
            system_prompt: Optional system prompt
            tools: List of allowed tools
            interactive: Run interactively or batch mode
            working_dir: Working directory for execution

        Returns:
            Success status
        """
        pass

    def execute(self, request: LLMRequest) -> LLMResponse:
        """
        Execute an LLM request.

        Args:
            request: LLM request with all parameters

        Returns:
            LLM response with results
        """
        try:
            # Extract prompt info from context
            prompt = request.context.get('prompt', f'Execute {request.command_type} command')
            system_prompt = request.context.get('system_prompt', '')
            tools = request.context.get('tools')
            working_dir = request.context.get('repo_path')

            if working_dir and not isinstance(working_dir, Path):
                working_dir = Path(working_dir)

            success = self.execute_prompt(
                prompt=prompt,
                system_prompt=system_prompt,
                tools=tools,
                interactive=request.interactive,
                working_dir=working_dir
            )

            # Try to get output from provider if it supports it
            output = None
            error = None
            if hasattr(self, 'last_output'):
                output = self.last_output
            if hasattr(self, 'last_error'):
                error = self.last_error

            return LLMResponse(
                success=success,
                provider=self.provider_name,
                command_type=request.command_type,
                output=output,
                error=error,
                context=request.context
            )

        except Exception as e:
            return LLMResponse(
                success=False,
                provider=self.provider_name,
                command_type=request.command_type,
                error=str(e),
                context=request.context
            )

    def get_supported_commands(self) -> List[str]:
        """Get list of supported command types."""
        return ["analyze", "audit", "setup", "hooks", "service", "issue_submit"]

    def supports_command(self, command_type: str) -> bool:
        """Check if provider supports a command type."""
        return command_type in self.get_supported_commands()

    def get_provider_info(self) -> Dict[str, Any]:
        """Get information about the provider."""
        return {
            "name": self.provider_name,
            "type": self.provider_type.value,
            "available": self.is_available(),
            "supported_commands": self.get_supported_commands(),
            "health": self.get_health_status()
        }

    def __str__(self) -> str:
        return f"{self.provider_name} LLM Provider"

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__} provider='{self.provider_name}' available={self.is_available()}>"