"""
LLM provider factory for Microforge v2.

Manages provider instantiation, selection, and fallback logic.
"""

from typing import Dict, Optional, List, Type
import logging

from ...core.exceptions import LLMError, IntegrationError
from ...config.settings import get_settings
from .base import BaseLLMProvider, LLMProviderType
from .claude import ClaudeProvider

logger = logging.getLogger(__name__)


class LLMProviderFactory:
    """Factory for creating and managing LLM providers."""

    def __init__(self):
        self.settings = get_settings()
        self._providers: Dict[str, BaseLLMProvider] = {}
        self._provider_classes: Dict[LLMProviderType, Type[BaseLLMProvider]] = {
            LLMProviderType.CLAUDE: ClaudeProvider,
            # Future providers can be added here
            # LLMProviderType.OPENAI: OpenAIProvider,
            # LLMProviderType.CURSOR: CursorProvider,
        }
        self._initialize_providers()

    def _initialize_providers(self) -> None:
        """Initialize all available providers."""
        for provider_type, provider_class in self._provider_classes.items():
            try:
                provider = provider_class()
                self._providers[provider_type.value] = provider
                logger.info(f"Initialized {provider_type.value} provider")
            except Exception as e:
                logger.warning(f"Failed to initialize {provider_type.value} provider: {e}")

    def get_provider(self, provider_name: Optional[str] = None) -> BaseLLMProvider:
        """
        Get an LLM provider by name or use default selection.

        Args:
            provider_name: Specific provider name or None for auto-selection

        Returns:
            LLM provider instance

        Raises:
            LLMError: If no suitable provider is available
        """
        if provider_name:
            # Get specific provider
            provider = self._providers.get(provider_name)
            if not provider:
                raise LLMError(
                    f"LLM provider '{provider_name}' not found",
                    provider=provider_name
                )

            if not provider.is_available():
                raise LLMError(
                    f"LLM provider '{provider_name}' is not available",
                    provider=provider_name
                )

            return provider

        # Auto-select best available provider
        return self._select_best_provider()

    def _select_best_provider(self) -> BaseLLMProvider:
        """Select the best available provider based on configuration and availability."""
        # Get preferred provider from settings
        preferred_provider = self.settings.llm.provider

        # Try preferred provider first
        if preferred_provider in self._providers:
            provider = self._providers[preferred_provider]
            if provider.is_available():
                logger.info(f"Using preferred provider: {preferred_provider}")
                return provider
            else:
                logger.warning(f"Preferred provider {preferred_provider} is not available")

        # Fallback to first available provider
        for provider_name, provider in self._providers.items():
            if provider.is_available():
                logger.info(f"Using fallback provider: {provider_name}")
                return provider

        # No providers available
        available_providers = list(self._providers.keys())
        raise LLMError(
            f"No LLM providers are available. Registered providers: {available_providers}",
            provider="none"
        )

    def list_providers(self) -> List[Dict[str, any]]:
        """List all registered providers with their status."""
        providers = []
        for name, provider in self._providers.items():
            providers.append({
                "name": name,
                "type": provider.provider_type.value,
                "available": provider.is_available(),
                "info": provider.get_provider_info()
            })
        return providers

    def get_available_providers(self) -> List[str]:
        """Get list of available provider names."""
        return [
            name for name, provider in self._providers.items()
            if provider.is_available()
        ]

    def health_check(self) -> Dict[str, Dict[str, any]]:
        """Perform health check on all providers."""
        health_status = {}
        for name, provider in self._providers.items():
            try:
                health_status[name] = provider.get_health_status()
                health_status[name]["available"] = provider.is_available()
            except Exception as e:
                health_status[name] = {
                    "available": False,
                    "error": str(e)
                }
        return health_status

    def reload_providers(self) -> None:
        """Reload all providers (useful for configuration changes)."""
        self._providers.clear()
        self._initialize_providers()

    def register_provider(self, provider_type: LLMProviderType, provider_class: Type[BaseLLMProvider]) -> None:
        """Register a new provider type."""
        self._provider_classes[provider_type] = provider_class
        try:
            provider = provider_class()
            self._providers[provider_type.value] = provider
            logger.info(f"Registered new provider: {provider_type.value}")
        except Exception as e:
            logger.error(f"Failed to register provider {provider_type.value}: {e}")

    def supports_command(self, command_type: str, provider_name: Optional[str] = None) -> bool:
        """Check if a provider supports a specific command type."""
        try:
            provider = self.get_provider(provider_name)
            return provider.supports_command(command_type)
        except LLMError:
            return False


# Global factory instance
_llm_factory: Optional[LLMProviderFactory] = None


def get_llm_factory() -> LLMProviderFactory:
    """Get the global LLM provider factory."""
    global _llm_factory
    if _llm_factory is None:
        _llm_factory = LLMProviderFactory()
    return _llm_factory


def get_llm_provider(provider_name: Optional[str] = None) -> BaseLLMProvider:
    """Get an LLM provider instance."""
    factory = get_llm_factory()
    return factory.get_provider(provider_name)


def list_llm_providers() -> List[Dict[str, any]]:
    """List all available LLM providers."""
    factory = get_llm_factory()
    return factory.list_providers()


def check_llm_health() -> Dict[str, Dict[str, any]]:
    """Perform health check on all LLM providers."""
    factory = get_llm_factory()
    return factory.health_check()


# Note: execute_with_claude removed - use get_llm_provider() or LLMManager instead