"""
Azure Blob Storage provider for Microforge.

Generic blob storage operations for Azure.
"""

import os
from pathlib import Path
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
import hashlib

try:
    from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient
    from azure.core.exceptions import ResourceNotFoundError
    AZURE_AVAILABLE = True
except ImportError:
    AZURE_AVAILABLE = False
    BlobServiceClient = None
    BlobClient = None
    ContainerClient = None
    ResourceNotFoundError = None

from ...core.common import console, print_info, print_error, print_success
from ...core.exceptions import StorageError, NotFoundError
from ...config.constants import (
    STORAGE_CACHE_DIR,
    STORAGE_CACHE_TTL_HOURS,
    DEFAULT_STORAGE_CONTAINER,
    AZURE_STORAGE_CONNECTION_STRING
)
from .base import BaseStorageProvider


class AzureBlobStorage(BaseStorageProvider):
    """Azure Blob Storage provider for generic blob operations."""

    def __init__(self, connection_string: str = None, container_name: str = None):
        """
        Initialize Azure storage provider.

        Args:
            connection_string: Azure Storage connection string.
                              Falls back to AZURE_STORAGE_CONNECTION_STRING env var.
            container_name: Container name. Falls back to AZURE_STORAGE_CONTAINER env var.
        """
        if not AZURE_AVAILABLE:
            raise StorageError(
                "Azure storage provider requires 'azure-storage-blob' package. "
                "Install it with: pip install azure-storage-blob"
            )

        conn_str = connection_string or AZURE_STORAGE_CONNECTION_STRING
        if not conn_str:
            raise StorageError(
                "Azure Storage connection string not provided. "
                "Set AZURE_STORAGE_CONNECTION_STRING environment variable."
            )

        try:
            self.blob_service_client = BlobServiceClient.from_connection_string(conn_str)
            self.container_name = container_name or os.getenv(
                "AZURE_STORAGE_CONTAINER", DEFAULT_STORAGE_CONTAINER
            )

            # Ensure cache directory exists
            STORAGE_CACHE_DIR.mkdir(parents=True, exist_ok=True)

            # Initialize container client
            self.container_client = self.blob_service_client.get_container_client(
                self.container_name
            )

            # Test connection by getting account info (with timeout)
            print_info("Testing Azure storage connection...")
            # Note: This will fail fast if the account doesn't exist

        except Exception as e:
            raise StorageError(
                f"Failed to initialize Azure storage: {str(e)}. "
                "Check if the storage account exists and connection string is valid."
            )

    def list_blobs(self, prefix: Optional[str] = None,
                   extension: Optional[str] = None) -> List[Dict[str, Any]]:
        """List all blobs in storage."""
        try:
            blobs = []

            if prefix:
                blob_list = self.container_client.list_blobs(name_starts_with=prefix)
            else:
                blob_list = self.container_client.list_blobs()

            for blob in blob_list:
                # Filter by extension if specified
                if extension and not blob.name.endswith(extension):
                    continue

                blob_info = {
                    'name': blob.name,
                    'size': blob.size,
                    'last_modified': blob.last_modified,
                    'etag': blob.etag,
                    'content_type': blob.content_settings.content_type if blob.content_settings else None,
                    'metadata': blob.metadata
                }
                blobs.append(blob_info)

            return blobs

        except Exception as e:
            raise StorageError(f"Failed to list blobs: {str(e)}")

    def get_blob(self, path: str, use_cache: bool = True) -> bytes:
        """Get blob content from storage."""
        # Check cache first if enabled
        if use_cache:
            cached_content = self._get_cached_blob(path)
            if cached_content is not None:
                print_info(f"Using cached blob: {path}")
                return cached_content

        try:
            blob_client = self.blob_service_client.get_blob_client(
                container=self.container_name,
                blob=path
            )

            downloader = blob_client.download_blob()
            content = downloader.readall()

            # Cache the content
            self._cache_blob(path, content)

            return content

        except ResourceNotFoundError:
            raise NotFoundError(f"Blob not found: {path}")
        except Exception as e:
            raise StorageError(f"Failed to download blob: {str(e)}")

    def get_blob_text(self, path: str, encoding: str = 'utf-8',
                      use_cache: bool = True) -> str:
        """Get blob content as text."""
        content = self.get_blob(path, use_cache=use_cache)
        return content.decode(encoding)

    def upload_blob(self, path: str, content: bytes,
                    overwrite: bool = True, metadata: Optional[Dict] = None) -> bool:
        """Upload blob to storage."""
        try:
            blob_client = self.blob_service_client.get_blob_client(
                container=self.container_name,
                blob=path
            )

            # Add standard metadata
            if metadata is None:
                metadata = {}
            metadata['uploaded_at'] = datetime.utcnow().isoformat()
            metadata['content_hash'] = hashlib.md5(content).hexdigest()

            # Upload the content
            blob_client.upload_blob(
                content,
                overwrite=overwrite,
                metadata=metadata
            )

            # Invalidate cache
            self._invalidate_cache(path)

            print_success(f"Uploaded blob: {path}")
            return True

        except Exception as e:
            raise StorageError(f"Failed to upload blob: {str(e)}")

    def upload_blob_text(self, path: str, content: str, encoding: str = 'utf-8',
                        overwrite: bool = True, metadata: Optional[Dict] = None) -> bool:
        """Upload text content as blob."""
        return self.upload_blob(path, content.encode(encoding), overwrite, metadata)

    def delete_blob(self, path: str) -> bool:
        """Delete blob from storage."""
        try:
            blob_client = self.blob_service_client.get_blob_client(
                container=self.container_name,
                blob=path
            )

            blob_client.delete_blob()

            # Invalidate cache
            self._invalidate_cache(path)

            print_success(f"Deleted blob: {path}")
            return True

        except ResourceNotFoundError:
            raise NotFoundError(f"Blob not found: {path}")
        except Exception as e:
            raise StorageError(f"Failed to delete blob: {str(e)}")

    def blob_exists(self, path: str) -> bool:
        """Check if blob exists."""
        try:
            blob_client = self.blob_service_client.get_blob_client(
                container=self.container_name,
                blob=path
            )
            blob_client.get_blob_properties()
            return True
        except ResourceNotFoundError:
            return False
        except Exception as e:
            raise StorageError(f"Failed to check blob existence: {str(e)}")

    def sync_directory(self, local_dir: Path, remote_prefix: str,
                      direction: str = "download",
                      extension_filter: Optional[str] = None) -> Dict[str, Any]:
        """Sync directory between local and remote."""
        result = {
            'synced': [],
            'failed': [],
            'skipped': [],
            'total': 0
        }

        if direction == "download":
            # Download from Azure to local
            blobs = self.list_blobs(prefix=remote_prefix, extension=extension_filter)
            result['total'] = len(blobs)

            for blob in blobs:
                try:
                    # Get relative path
                    rel_path = blob['name']
                    if remote_prefix:
                        rel_path = rel_path[len(remote_prefix):].lstrip('/')

                    local_path = local_dir / rel_path
                    local_path.parent.mkdir(parents=True, exist_ok=True)

                    # Download content
                    content = self.get_blob(blob['name'], use_cache=False)
                    local_path.write_bytes(content)

                    result['synced'].append(rel_path)

                except Exception as e:
                    result['failed'].append({
                        'name': blob['name'],
                        'error': str(e)
                    })

        elif direction == "upload":
            # Upload from local to Azure
            pattern = f"**/*{extension_filter}" if extension_filter else "**/*"

            for local_file in local_dir.glob(pattern):
                if local_file.is_file():
                    result['total'] += 1

                    try:
                        # Calculate remote path
                        rel_path = local_file.relative_to(local_dir)
                        remote_path = f"{remote_prefix}/{rel_path}".replace('\\', '/')

                        # Upload content
                        content = local_file.read_bytes()
                        self.upload_blob(remote_path, content)

                        result['synced'].append(str(rel_path))

                    except Exception as e:
                        result['failed'].append({
                            'name': str(local_file),
                            'error': str(e)
                        })

        return result

    def list_prefixes(self, delimiter: str = '/') -> List[str]:
        """List all prefixes (folders) in storage."""
        prefixes = set()
        blobs = self.container_client.list_blobs()

        for blob in blobs:
            parts = blob.name.split(delimiter)
            if len(parts) > 1:
                # Add each level of prefix
                for i in range(1, len(parts)):
                    prefix = delimiter.join(parts[:i]) + delimiter
                    prefixes.add(prefix)

        return sorted(list(prefixes))

    def ensure_container_exists(self):
        """Ensure the Azure container exists."""
        try:
            self.container_client.get_container_properties()
            print_info(f"Container '{self.container_name}' exists")
        except ResourceNotFoundError:
            print_info(f"Creating container '{self.container_name}'")
            self.container_client.create_container()
            print_success(f"Container '{self.container_name}' created")

    def get_blob_metadata(self, path: str) -> Optional[Dict[str, Any]]:
        """Get metadata for a specific blob."""
        try:
            blob_client = self.blob_service_client.get_blob_client(
                container=self.container_name,
                blob=path
            )
            properties = blob_client.get_blob_properties()

            return {
                'name': properties.name,
                'size': properties.size,
                'last_modified': properties.last_modified,
                'etag': properties.etag,
                'content_type': properties.content_settings.content_type if properties.content_settings else None,
                'metadata': properties.metadata
            }
        except ResourceNotFoundError:
            return None
        except Exception as e:
            raise StorageError(f"Failed to get blob metadata: {str(e)}")

    def _get_cached_blob(self, path: str) -> Optional[bytes]:
        """Get cached blob if available and not expired."""
        cache_file = STORAGE_CACHE_DIR / path.replace('/', '_')

        if cache_file.exists():
            # Check if cache is still valid
            cache_age = datetime.now() - datetime.fromtimestamp(cache_file.stat().st_mtime)
            if cache_age < timedelta(hours=STORAGE_CACHE_TTL_HOURS):
                return cache_file.read_bytes()

        return None

    def _cache_blob(self, path: str, content: bytes):
        """Cache blob locally."""
        cache_file = STORAGE_CACHE_DIR / path.replace('/', '_')
        cache_file.parent.mkdir(parents=True, exist_ok=True)
        cache_file.write_bytes(content)

    def _invalidate_cache(self, path: str):
        """Invalidate cached blob."""
        cache_file = STORAGE_CACHE_DIR / path.replace('/', '_')
        if cache_file.exists():
            cache_file.unlink()