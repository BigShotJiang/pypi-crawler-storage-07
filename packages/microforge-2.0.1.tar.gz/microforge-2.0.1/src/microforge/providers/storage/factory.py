"""
Storage provider factory for Microforge.

Creates appropriate storage provider based on configuration.
"""

import os
from typing import Optional

from ...core.exceptions import StorageError
from ...config.constants import STORAGE_PROVIDER, DEFAULT_STORAGE_CONTAINER, AZURE_STORAGE_CONNECTION_STRING
from .base import BaseStorageProvider


class StorageFactory:
    """Factory for creating storage providers."""

    @staticmethod
    def create_storage_provider(provider_type: Optional[str] = None) -> Optional[BaseStorageProvider]:
        """
        Create storage provider based on configuration.

        Args:
            provider_type: Override provider type.
                          If None, uses MICROFORGE_STORAGE_PROVIDER env var.

        Returns:
            Storage provider instance or None if disabled.
        """
        # Get provider type from env or parameter
        if provider_type is None:
            provider_type = STORAGE_PROVIDER

        provider_type = provider_type.upper()

        # Return None if storage is disabled
        if provider_type == "NONE" or provider_type == "DISABLED":
            return None

        # Local storage (default)
        if provider_type == "LOCAL":
            from .local_file import LocalFileStorage
            return LocalFileStorage()

        # Azure Blob Storage
        elif provider_type == "AZURE":
            # Check if Azure credentials are configured
            if not AZURE_STORAGE_CONNECTION_STRING:
                raise StorageError(
                    "Azure storage selected but AZURE_STORAGE_CONNECTION_STRING not set"
                )
            from .azure_blob import AzureBlobStorage
            container = os.getenv("AZURE_STORAGE_CONTAINER", DEFAULT_STORAGE_CONTAINER)
            return AzureBlobStorage(container_name=container)

        # AWS S3
        elif provider_type == "AWS":
            # Check if AWS credentials are configured
            if not (os.getenv("AWS_ACCESS_KEY_ID") and os.getenv("AWS_SECRET_ACCESS_KEY")):
                raise StorageError(
                    "AWS storage selected but AWS credentials not configured"
                )
            # TODO: Implement AWS S3 storage
            raise NotImplementedError("AWS S3 storage provider not yet implemented")

        # Google Cloud Storage
        elif provider_type == "GCP" or provider_type == "GOOGLE":
            # Check if GCP credentials are configured
            if not os.getenv("GOOGLE_APPLICATION_CREDENTIALS"):
                raise StorageError(
                    "Google Cloud Storage selected but GOOGLE_APPLICATION_CREDENTIALS not set"
                )
            # TODO: Implement GCP storage
            raise NotImplementedError("GCP storage provider not yet implemented")

        else:
            raise StorageError(f"Unknown storage provider: {provider_type}")

    @staticmethod
    def get_configured_provider() -> str:
        """Get the currently configured storage provider type."""
        return STORAGE_PROVIDER