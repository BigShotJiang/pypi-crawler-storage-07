"""
Local file storage provider for Microforge.

Generic file operations for local filesystem.
"""

import os
from pathlib import Path
from typing import Dict, List, Optional, Any
from datetime import datetime

from ...core.common import print_info, print_error, print_success
from ...core.exceptions import StorageError, NotFoundError
from ...config.constants import LOCAL_STORAGE_BASE
from .base import BaseStorageProvider


class LocalFileStorage(BaseStorageProvider):
    """Local file storage provider for generic file operations."""

    def __init__(self, base_dir: Optional[Path] = None):
        """
        Initialize local storage provider.

        Args:
            base_dir: Base directory for storage.
                     Defaults to LOCAL_STORAGE_BASE from constants.
        """
        if base_dir is None:
            self.base_dir = LOCAL_STORAGE_BASE
        else:
            self.base_dir = Path(base_dir)

        # Ensure base directory exists
        self.base_dir.mkdir(parents=True, exist_ok=True)

    def list_blobs(self, prefix: Optional[str] = None,
                   extension: Optional[str] = None) -> List[Dict[str, Any]]:
        """List all files in local storage."""
        blobs = []

        # Determine search path
        if prefix:
            search_path = self.base_dir / prefix
        else:
            search_path = self.base_dir

        if not search_path.exists():
            return blobs

        # Search pattern
        pattern = f"**/*{extension}" if extension else "**/*"

        for file_path in search_path.glob(pattern):
            if file_path.is_file():
                # Get relative path from base_dir
                try:
                    rel_path = file_path.relative_to(self.base_dir)
                except ValueError:
                    # Path is outside base_dir
                    continue

                blob_info = {
                    'name': str(rel_path).replace('\\', '/'),
                    'size': file_path.stat().st_size,
                    'last_modified': datetime.fromtimestamp(file_path.stat().st_mtime),
                    'etag': None,  # Local files don't have ETags
                    'content_type': self._guess_content_type(file_path),
                    'metadata': {}
                }
                blobs.append(blob_info)

        return blobs

    def get_blob(self, path: str, use_cache: bool = True) -> bytes:
        """Get file content."""
        file_path = self.base_dir / path

        if not file_path.exists():
            raise NotFoundError(f"File not found: {path}")

        try:
            return file_path.read_bytes()
        except Exception as e:
            raise StorageError(f"Failed to read file: {str(e)}")

    def get_blob_text(self, path: str, encoding: str = 'utf-8',
                      use_cache: bool = True) -> str:
        """Get file content as text."""
        content = self.get_blob(path, use_cache=use_cache)
        return content.decode(encoding)

    def upload_blob(self, path: str, content: bytes,
                    overwrite: bool = True, metadata: Optional[Dict] = None) -> bool:
        """Save file to local storage."""
        file_path = self.base_dir / path

        if file_path.exists() and not overwrite:
            raise StorageError(f"File already exists: {path}")

        try:
            # Ensure parent directory exists
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_bytes(content)
            print_success(f"Saved file: {path}")
            return True
        except Exception as e:
            raise StorageError(f"Failed to save file: {str(e)}")

    def upload_blob_text(self, path: str, content: str, encoding: str = 'utf-8',
                        overwrite: bool = True, metadata: Optional[Dict] = None) -> bool:
        """Save text content as file."""
        return self.upload_blob(path, content.encode(encoding), overwrite, metadata)

    def delete_blob(self, path: str) -> bool:
        """Delete file from local storage."""
        file_path = self.base_dir / path

        if not file_path.exists():
            raise NotFoundError(f"File not found: {path}")

        try:
            file_path.unlink()
            print_success(f"Deleted file: {path}")
            return True
        except Exception as e:
            raise StorageError(f"Failed to delete file: {str(e)}")

    def blob_exists(self, path: str) -> bool:
        """Check if file exists."""
        file_path = self.base_dir / path
        return file_path.exists() and file_path.is_file()

    def sync_directory(self, local_dir: Path, remote_prefix: str,
                      direction: str = "download",
                      extension_filter: Optional[str] = None) -> Dict[str, Any]:
        """Sync directory (copy operation for local storage)."""
        result = {
            'synced': [],
            'failed': [],
            'skipped': [],
            'total': 0
        }

        if direction == "download":
            # Copy from base_dir to local_dir
            source_dir = self.base_dir / remote_prefix if remote_prefix else self.base_dir
            dest_dir = local_dir

            if not source_dir.exists():
                return result

            pattern = f"**/*{extension_filter}" if extension_filter else "**/*"

            for source_file in source_dir.glob(pattern):
                if source_file.is_file():
                    result['total'] += 1
                    try:
                        rel_path = source_file.relative_to(source_dir)
                        dest_file = dest_dir / rel_path
                        dest_file.parent.mkdir(parents=True, exist_ok=True)
                        dest_file.write_bytes(source_file.read_bytes())
                        result['synced'].append(str(rel_path))
                    except Exception as e:
                        result['failed'].append({
                            'name': str(source_file),
                            'error': str(e)
                        })

        elif direction == "upload":
            # Copy from local_dir to base_dir
            source_dir = local_dir
            dest_dir = self.base_dir / remote_prefix if remote_prefix else self.base_dir

            pattern = f"**/*{extension_filter}" if extension_filter else "**/*"

            for source_file in source_dir.glob(pattern):
                if source_file.is_file():
                    result['total'] += 1
                    try:
                        rel_path = source_file.relative_to(source_dir)
                        dest_file = dest_dir / rel_path
                        dest_file.parent.mkdir(parents=True, exist_ok=True)
                        dest_file.write_bytes(source_file.read_bytes())
                        result['synced'].append(str(rel_path))
                    except Exception as e:
                        result['failed'].append({
                            'name': str(source_file),
                            'error': str(e)
                        })

        return result

    def list_prefixes(self, delimiter: str = '/') -> List[str]:
        """List all directories in storage."""
        prefixes = set()

        for item in self.base_dir.rglob("*"):
            if item.is_dir():
                try:
                    rel_path = item.relative_to(self.base_dir)
                    prefix = str(rel_path).replace('\\', '/') + '/'
                    prefixes.add(prefix)
                except ValueError:
                    continue

        return sorted(list(prefixes))

    def ensure_container_exists(self):
        """Ensure the local storage directory exists."""
        self.base_dir.mkdir(parents=True, exist_ok=True)
        print_info(f"Local storage directory: {self.base_dir}")

    def get_blob_metadata(self, path: str) -> Optional[Dict[str, Any]]:
        """Get metadata for a specific file."""
        file_path = self.base_dir / path

        if not file_path.exists():
            return None

        try:
            stat = file_path.stat()
            return {
                'name': path,
                'size': stat.st_size,
                'last_modified': datetime.fromtimestamp(stat.st_mtime),
                'etag': None,
                'content_type': self._guess_content_type(file_path),
                'metadata': {}
            }
        except Exception as e:
            raise StorageError(f"Failed to get file metadata: {str(e)}")

    def _guess_content_type(self, file_path: Path) -> str:
        """Guess content type based on file extension."""
        extension = file_path.suffix.lower()
        content_types = {
            '.md': 'text/markdown',
            '.txt': 'text/plain',
            '.json': 'application/json',
            '.yaml': 'text/yaml',
            '.yml': 'text/yaml',
            '.py': 'text/x-python',
            '.js': 'application/javascript',
            '.html': 'text/html',
            '.css': 'text/css',
            '.xml': 'application/xml'
        }
        return content_types.get(extension, 'application/octet-stream')