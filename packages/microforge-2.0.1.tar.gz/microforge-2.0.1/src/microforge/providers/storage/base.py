"""
Base storage provider interface for Microforge.

Provides abstraction for different cloud storage backends.
Generic blob storage operations for any use case.
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any, BinaryIO
from pathlib import Path


class BaseStorageProvider(ABC):
    """Abstract base class for generic blob storage providers."""

    @abstractmethod
    def list_blobs(self, prefix: Optional[str] = None,
                   extension: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        List all blobs in storage.

        Args:
            prefix: Optional prefix to filter blobs (e.g., "folder/")
            extension: Optional file extension filter (e.g., ".md")

        Returns:
            List of blob metadata dictionaries
        """
        pass

    @abstractmethod
    def get_blob(self, path: str, use_cache: bool = True) -> bytes:
        """
        Get blob content from storage.

        Args:
            path: Full path to the blob
            use_cache: Whether to use local cache if available

        Returns:
            Blob content as bytes
        """
        pass

    @abstractmethod
    def get_blob_text(self, path: str, encoding: str = 'utf-8',
                      use_cache: bool = True) -> str:
        """
        Get blob content as text.

        Args:
            path: Full path to the blob
            encoding: Text encoding (default: utf-8)
            use_cache: Whether to use local cache

        Returns:
            Blob content as string
        """
        pass

    @abstractmethod
    def upload_blob(self, path: str, content: bytes,
                    overwrite: bool = True, metadata: Optional[Dict] = None) -> bool:
        """
        Upload blob to storage.

        Args:
            path: Full path for the blob
            content: Content as bytes
            overwrite: Whether to overwrite existing blob
            metadata: Optional metadata to attach

        Returns:
            True if successful
        """
        pass

    @abstractmethod
    def upload_blob_text(self, path: str, content: str, encoding: str = 'utf-8',
                        overwrite: bool = True, metadata: Optional[Dict] = None) -> bool:
        """
        Upload text content as blob.

        Args:
            path: Full path for the blob
            content: Text content
            encoding: Text encoding (default: utf-8)
            overwrite: Whether to overwrite existing
            metadata: Optional metadata

        Returns:
            True if successful
        """
        pass

    @abstractmethod
    def delete_blob(self, path: str) -> bool:
        """
        Delete blob from storage.

        Args:
            path: Full path to the blob

        Returns:
            True if successful
        """
        pass

    @abstractmethod
    def blob_exists(self, path: str) -> bool:
        """
        Check if blob exists.

        Args:
            path: Full path to the blob

        Returns:
            True if blob exists
        """
        pass

    @abstractmethod
    def sync_directory(self, local_dir: Path, remote_prefix: str,
                      direction: str = "download",
                      extension_filter: Optional[str] = None) -> Dict[str, Any]:
        """
        Sync directory between local and remote.

        Args:
            local_dir: Local directory path
            remote_prefix: Remote path prefix
            direction: "download" or "upload"
            extension_filter: Optional file extension filter

        Returns:
            Sync result statistics
        """
        pass

    @abstractmethod
    def list_prefixes(self, delimiter: str = '/') -> List[str]:
        """
        List all prefixes (folders) in storage.

        Args:
            delimiter: Path delimiter

        Returns:
            List of prefixes
        """
        pass

    @abstractmethod
    def ensure_container_exists(self):
        """Ensure the storage container/bucket exists."""
        pass

    @abstractmethod
    def get_blob_metadata(self, path: str) -> Optional[Dict[str, Any]]:
        """
        Get metadata for a specific blob.

        Args:
            path: Full path to the blob

        Returns:
            Metadata dictionary or None if not found
        """
        pass