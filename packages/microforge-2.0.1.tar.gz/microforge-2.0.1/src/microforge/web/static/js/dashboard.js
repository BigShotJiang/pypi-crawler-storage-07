/**
 * User Segment Dashboard JavaScript
 */

// Dashboard state
const dashboardState = {
    currentDateRange: null,
    dashboardData: null,
    performanceChart: null,
    sortColumn: null,
    sortDirection: 'asc'
};

// Initialize dashboard on page load
document.addEventListener('DOMContentLoaded', function() {
    initializeDashboard();
});

/**
 * Initialize the dashboard
 */
async function initializeDashboard() {
    // Set up event listeners
    setupEventListeners();

    // Set default date range (last 30 days)
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - 30);

    // Set date inputs
    document.getElementById('end-date').value = formatDateForInput(endDate);
    document.getElementById('start-date').value = formatDateForInput(startDate);

    // Load dashboard data
    await loadDashboardData(startDate, endDate);
}

/**
 * Set up event listeners
 */
function setupEventListeners() {
    // Date range selector
    const datePreset = document.getElementById('date-preset');
    datePreset.addEventListener('change', handleDatePresetChange);

    // Apply date range button
    const applyBtn = document.getElementById('apply-date-range');
    applyBtn.addEventListener('click', handleCustomDateRange);

    // Export buttons
    document.getElementById('export-csv').addEventListener('click', () => exportData('csv'));
    document.getElementById('export-pdf').addEventListener('click', () => exportData('pdf'));

    // Table sorting
    const sortableHeaders = document.querySelectorAll('.sortable');
    sortableHeaders.forEach(header => {
        header.addEventListener('click', () => handleSort(header.dataset.column));
    });
}

/**
 * Handle date preset change
 */
function handleDatePresetChange(event) {
    const preset = event.target.value;
    const customRangeDiv = document.getElementById('custom-date-range');

    if (preset === 'custom') {
        customRangeDiv.style.display = 'flex';
    } else {
        customRangeDiv.style.display = 'none';

        const endDate = new Date();
        let startDate = new Date();

        switch(preset) {
            case 'last7days':
                startDate.setDate(startDate.getDate() - 7);
                break;
            case 'last30days':
                startDate.setDate(startDate.getDate() - 30);
                break;
            case 'last90days':
                startDate.setDate(startDate.getDate() - 90);
                break;
        }

        loadDashboardData(startDate, endDate);
    }
}

/**
 * Handle custom date range
 */
function handleCustomDateRange() {
    const startDate = new Date(document.getElementById('start-date').value);
    const endDate = new Date(document.getElementById('end-date').value);

    if (startDate && endDate && startDate <= endDate) {
        loadDashboardData(startDate, endDate);
    } else {
        alert('Please select valid date range');
    }
}

/**
 * Load dashboard data from API
 */
async function loadDashboardData(startDate, endDate) {
    showLoading(true);

    try {
        const startStr = formatDateForAPI(startDate);
        const endStr = formatDateForAPI(endDate);

        const response = await fetch(`/api/dashboard/segments?start_date=${startStr}&end_date=${endStr}`);

        if (!response.ok) {
            throw new Error('Failed to load dashboard data');
        }

        const data = await response.json();
        dashboardState.dashboardData = data;
        dashboardState.currentDateRange = { start: startDate, end: endDate };

        // Update UI with data
        updateKPICards(data.metrics);
        updateSegmentTable(data.segments);
        updatePerformanceChart(data.timeSeries);

    } catch (error) {
        console.error('Error loading dashboard:', error);
        alert('Failed to load dashboard data. Please try again.');
    } finally {
        showLoading(false);
    }
}

/**
 * Update KPI cards with data
 */
function updateKPICards(metrics) {
    // Total Users
    document.getElementById('total-users').textContent = formatNumber(metrics.totalUsers.value);
    document.getElementById('users-growth').textContent = formatGrowth(metrics.totalUsers);

    // Revenue Contribution
    document.getElementById('revenue-contribution').textContent = formatCurrency(metrics.revenueContribution.value);
    document.getElementById('revenue-growth').textContent = formatGrowth(metrics.revenueContribution);

    // CTR %
    document.getElementById('ctr-percentage').textContent = metrics.ctr.value.toFixed(1) + '%';
    document.getElementById('ctr-growth').textContent = formatGrowth(metrics.ctr, true);

    // Conversion %
    document.getElementById('conversion-percentage').textContent = metrics.conversion.value.toFixed(1) + '%';
    document.getElementById('conversion-growth').textContent = formatGrowth(metrics.conversion, true);
}

/**
 * Update segment performance table
 */
function updateSegmentTable(segments) {
    const tbody = document.getElementById('segment-tbody');
    tbody.innerHTML = '';

    segments.forEach(segment => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td><strong>${segment.name}</strong></td>
            <td>${formatNumber(segment.users)}</td>
            <td>${formatCurrency(segment.revenue)}</td>
            <td>${formatCurrency(segment.aov)}</td>
            <td>${segment.ctr.toFixed(1)}%</td>
            <td>${segment.conversion.toFixed(1)}%</td>
            <td>
                <button class="view-details-btn" onclick="viewSegmentDetails('${segment.name}')">
                    View Details
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

/**
 * Update performance chart
 */
function updatePerformanceChart(timeSeries) {
    const ctx = document.getElementById('performance-chart').getContext('2d');

    // Destroy existing chart if exists
    if (dashboardState.performanceChart) {
        dashboardState.performanceChart.destroy();
    }

    // Create new chart
    dashboardState.performanceChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: timeSeries.map(point => formatDateForChart(point.date)),
            datasets: [{
                label: 'Performance',
                data: timeSeries.map(point => point.value),
                borderColor: '#4a90e2',
                backgroundColor: 'rgba(74, 144, 226, 0.1)',
                borderWidth: 2,
                tension: 0.4,
                fill: true,
                pointRadius: 4,
                pointHoverRadius: 6,
                pointBackgroundColor: '#4a90e2',
                pointBorderColor: '#fff',
                pointBorderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    padding: 12,
                    callbacks: {
                        label: function(context) {
                            return formatNumber(context.parsed.y);
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false
                    }
                },
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)'
                    },
                    ticks: {
                        callback: function(value) {
                            return formatNumber(value);
                        }
                    }
                }
            }
        }
    });
}

/**
 * View segment details
 */
async function viewSegmentDetails(segmentName) {
    const segmentMap = {
        'High Value': 'high_value',
        'Bargain Hunters': 'bargain_hunters',
        'Dormant Users': 'dormant_users'
    };

    const segmentId = segmentMap[segmentName];

    try {
        const response = await fetch(`/api/dashboard/segments/${segmentId}/details`);
        if (!response.ok) {
            throw new Error('Failed to load segment details');
        }

        const details = await response.json();

        // Display details in a modal or redirect to details page
        alert(`Segment: ${segmentName}\n\nAvg Session Duration: ${details.behavior.avg_session_duration}\nRetention Rate: ${details.behavior.retention_rate}%\n\nTop Products:\n${details.top_products.map(p => `- ${p.name}: ${formatCurrency(p.revenue)}`).join('\n')}`);

    } catch (error) {
        console.error('Error loading segment details:', error);
        alert('Failed to load segment details');
    }
}

/**
 * Export data
 */
async function exportData(format) {
    const { start, end } = dashboardState.currentDateRange;
    const startStr = formatDateForAPI(start);
    const endStr = formatDateForAPI(end);

    try {
        const response = await fetch(`/api/dashboard/export?format=${format}&start_date=${startStr}&end_date=${endStr}`);

        if (!response.ok) {
            throw new Error('Export failed');
        }

        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = `dashboard_export_${startStr}_${endStr}.${format === 'pdf' ? 'pdf' : 'csv'}`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);

    } catch (error) {
        console.error('Error exporting data:', error);
        alert('Failed to export data');
    }
}

/**
 * Handle table sorting
 */
function handleSort(column) {
    if (dashboardState.sortColumn === column) {
        dashboardState.sortDirection = dashboardState.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
        dashboardState.sortColumn = column;
        dashboardState.sortDirection = 'asc';
    }

    const segments = [...dashboardState.dashboardData.segments];

    segments.sort((a, b) => {
        let aVal = a[column];
        let bVal = b[column];

        if (column === 'segment') {
            aVal = a.name;
            bVal = b.name;
        }

        if (typeof aVal === 'string') {
            return dashboardState.sortDirection === 'asc'
                ? aVal.localeCompare(bVal)
                : bVal.localeCompare(aVal);
        } else {
            return dashboardState.sortDirection === 'asc'
                ? aVal - bVal
                : bVal - aVal;
        }
    });

    updateSegmentTable(segments);
}

/**
 * Show/hide loading overlay
 */
function showLoading(show) {
    const overlay = document.getElementById('loading-overlay');
    overlay.classList.toggle('active', show);
}

/**
 * Format number with commas
 */
function formatNumber(num) {
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
        return (num / 1000).toFixed(0) + 'K';
    }
    return num.toLocaleString();
}

/**
 * Format currency
 */
function formatCurrency(amount) {
    if (amount >= 1000000) {
        return '$' + (amount / 1000000).toFixed(1) + 'M';
    } else if (amount >= 1000) {
        return '$' + (amount / 1000).toFixed(0) + 'K';
    }
    return '$' + amount.toLocaleString();
}

/**
 * Format growth indicator
 */
function formatGrowth(metric, isPercentage = false) {
    const sign = metric.growth >= 0 ? '+' : '';
    if (isPercentage) {
        return `${sign}${metric.growth.toFixed(1)}%`;
    }
    return `${sign}${formatNumber(metric.growth)}`;
}

/**
 * Format date for input
 */
function formatDateForInput(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

/**
 * Format date for API
 */
function formatDateForAPI(date) {
    return formatDateForInput(date);
}

/**
 * Format date for chart
 */
function formatDateForChart(dateStr) {
    const date = new Date(dateStr);
    const month = date.toLocaleString('en', { month: 'short' });
    const day = date.getDate();
    return `${month} ${day}`;
}