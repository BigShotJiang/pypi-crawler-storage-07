"""
FastAPI application for Microforge Web UI.

Provides a futuristic interface for workflow and agent management.
"""

import asyncio
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.templating import Jinja2Templates

from ..registries.manager import get_registry_manager
from ..core.common import console
from ..workflows import WorkflowManager
from .api import dashboard

# Get the web directory path
WEB_DIR = Path(__file__).parent

# Setup Jinja2 templates
templates = Jinja2Templates(directory=str(WEB_DIR / "templates"))

# Create FastAPI app
app = FastAPI(
    title="Microforge UI",
    description="Futuristic Multi-Agent Workflow Management System",
    version="2.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files
app.mount("/static", StaticFiles(directory=str(WEB_DIR / "static")), name="static")

# Include routers
app.include_router(dashboard.router)

# Store active websocket connections
active_connections: Dict[str, List[WebSocket]] = {}


class ConnectionManager:
    """Manage WebSocket connections for real-time updates."""

    def __init__(self):
        self.active_connections: Dict[str, List[WebSocket]] = {}

    async def connect(self, websocket: WebSocket, client_id: str):
        await websocket.accept()
        if client_id not in self.active_connections:
            self.active_connections[client_id] = []
        self.active_connections[client_id].append(websocket)

    def disconnect(self, websocket: WebSocket, client_id: str):
        if client_id in self.active_connections:
            self.active_connections[client_id].remove(websocket)
            if not self.active_connections[client_id]:
                del self.active_connections[client_id]

    async def send_message(self, message: str, client_id: str):
        if client_id in self.active_connections:
            for connection in self.active_connections[client_id]:
                await connection.send_text(message)

    async def broadcast(self, message: str):
        for connections in self.active_connections.values():
            for connection in connections:
                await connection.send_text(message)


manager = ConnectionManager()
workflow_manager = WorkflowManager()


# HTML Routes
@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    """Serve the main dashboard."""
    return templates.TemplateResponse("dashboard.html", {"request": request, "page": "dashboard"})


@app.get("/user-segments", response_class=HTMLResponse)
async def user_segments_dashboard(request: Request):
    """Serve the user segments dashboard."""
    return templates.TemplateResponse("dashboard/user_segments.html", {"request": request, "page": "user-segments"})


@app.get("/workflows", response_class=HTMLResponse)
async def workflows_page(request: Request):
    """Serve the workflows management page."""
    return templates.TemplateResponse("workflows.html", {"request": request, "page": "workflows"})


@app.get("/agents", response_class=HTMLResponse)
async def agents_page(request: Request):
    """Serve the agents management page."""
    return templates.TemplateResponse("agents.html", {"request": request, "page": "agents"})


@app.get("/agents/{agent_id}", response_class=HTMLResponse)
async def agent_detail_page(request: Request, agent_id: str):
    """Serve the agent detail page."""
    return templates.TemplateResponse("agent_detail.html", {"request": request, "page": "agents", "agent_id": agent_id})


@app.get("/services", response_class=HTMLResponse)
async def services_page(request: Request):
    """Serve the services management page."""
    return templates.TemplateResponse("services.html", {"request": request, "page": "services"})


@app.get("/applications", response_class=HTMLResponse)
async def applications_page(request: Request):
    """Serve the applications management page."""
    return templates.TemplateResponse("applications.html", {"request": request, "page": "applications"})


@app.get("/executions", response_class=HTMLResponse)
async def executions_page(request: Request):
    """Serve the workflow executions page."""
    return templates.TemplateResponse("executions.html", {"request": request, "page": "executions"})


@app.get("/executions/{execution_id}", response_class=HTMLResponse)
async def execution_detail_page(request: Request, execution_id: str):
    """Serve the execution detail page."""
    return templates.TemplateResponse("execution_detail.html", {"request": request, "page": "executions", "execution_id": execution_id})


@app.get("/approvals", response_class=HTMLResponse)
async def approvals_page(request: Request):
    """Serve the approvals management page."""
    return templates.TemplateResponse("approvals.html", {"request": request, "page": "approvals"})


@app.get("/approvals/{approval_id}", response_class=HTMLResponse)
async def approval_detail_page(request: Request, approval_id: str):
    """Serve the approval detail page."""
    return templates.TemplateResponse("approval_detail.html", {"request": request, "page": "approvals", "approval_id": approval_id})


@app.get("/issues", response_class=HTMLResponse)
async def issues_page(request: Request):
    """Serve the GitHub issues integration page."""
    return templates.TemplateResponse("issues.html", {"request": request, "page": "issues"})


@app.get("/execution/{workflow_id}", response_class=HTMLResponse)
async def execution_page(request: Request, workflow_id: str):
    """Serve the execution monitor page."""
    return templates.TemplateResponse("execution.html", {
        "request": request,
        "page": "execution",
        "WORKFLOW_ID": workflow_id
    })


# API Routes
@app.get("/api/stats")
async def get_stats():
    """Get system statistics."""
    registry = get_registry_manager()
    counts = registry.get_counts()

    return {
        "workflows": counts.get("workflows", 0),
        "agents": counts.get("agents", 0),
        "services": counts.get("services", 0),
        "applications": counts.get("applications", 0),
        "timestamp": datetime.now().isoformat()
    }


@app.get("/api/workflows")
async def list_workflows():
    """List all available workflows."""
    registry = get_registry_manager()
    # workflows = registry.workflows.list_workflows()  # Temporarily disabled
    workflows = []  # Return empty for now

    return [
        {
            "id": w.id,
            "display_name": w.display_name,
            "description": w.description,
            "category": w.category,
            "tags": w.tags,
            "steps": len(w.steps),
            "enabled": w.enabled,
            "supports_dynamic": w.supports_dynamic,
            "parallel_execution": w.parallel_execution
        }
        for w in workflows
    ]


@app.get("/api/workflows/{workflow_id}")
async def get_workflow(workflow_id: str):
    """Get detailed workflow information."""
    registry = get_registry_manager()
    # workflow = registry.workflows.get_workflow(workflow_id)  # Temporarily disabled
    workflow = None

    if not workflow:
        raise HTTPException(status_code=404, detail="Workflow not found")

    return workflow.dict()


@app.post("/api/workflows/{workflow_id}/execute")
async def execute_workflow(workflow_id: str, request: Request):
    """Execute a workflow."""
    body = await request.json()
    inputs = body.get("inputs", {})

    # Create unique execution ID
    execution_id = f"{workflow_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

    # Start execution in background
    asyncio.create_task(run_workflow_async(workflow_id, inputs, execution_id))

    return {
        "execution_id": execution_id,
        "status": "started",
        "workflow_id": workflow_id
    }


@app.get("/api/agents")
async def list_agents():
    """List all available agents."""
    registry = get_registry_manager()
    agents = registry.agents.list_agents()

    return [
        {
            "id": a.id,
            "display_name": a.display_name,
            "description": a.description,
            "category": getattr(a, 'category', 'general'),
            "tags": getattr(a, 'tags', []),
            "enabled": a.enabled,
            "file_name": a.file_name,
            "provider": a.provider
        }
        for a in agents
    ]


@app.get("/api/agents/{agent_id}")
async def get_agent(agent_id: str):
    """Get detailed agent information."""
    registry = get_registry_manager()
    agent = registry.agents.get_agent(agent_id)

    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    return agent.dict()


@app.get("/api/agents/{agent_id}/content")
async def get_agent_content(agent_id: str):
    """Get the agent's markdown content."""
    registry = get_registry_manager()
    agent = registry.agents.get_agent(agent_id)

    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    # Build the agent file path - agents are in resources/agent_templates
    agents_dir = Path("src/microforge/resources/agent_templates")
    agent_file = agents_dir / agent.file_name

    if agent_file.exists():
        content = agent_file.read_text()
    else:
        content = f"# {agent.display_name}\n\n{agent.description}\n\n*Agent file not found at {agent_file}*"

    return {"content": content, "agent": agent.dict()}


@app.get("/api/services")
async def list_services():
    """List all registered services."""
    registry = get_registry_manager()
    services = registry.services.list_services()

    return [
        {
            "name": s.name,
            "repo_url": s.repo_url,
            "branch": s.branch,
            "application": s.application,
            "tags": getattr(s, 'tags', []),
            "description": s.description
        }
        for s in services
    ]


@app.get("/api/applications")
async def list_applications():
    """List all registered applications."""
    registry = get_registry_manager()
    applications = registry.applications.list_applications()

    return [
        {
            "name": a.get('name', a.get('id', '')),
            "display_name": a.get('display_name', a.get('name', '')),
            "description": a.get('description', ''),
            "tags": a.get('tags', []),
            "repo_url": a.get('repo_url', ''),
            "branch": a.get('branch', 'main'),
            "service_count": a.get('service_count', 0)
        }
        for a in applications
    ]


# Workflow API endpoints
@app.post("/api/workflows/create")
async def create_workflow_from_issue(request: Request):
    """Create workflow from GitHub issue."""
    try:
        body = await request.json()
        issue_id = body.get("issue_id")
        services = body.get("services")
        auto_approve = body.get("auto_approve", False)

        if not issue_id:
            raise HTTPException(status_code=400, detail="issue_id is required")

        result = workflow_manager.create_workflow_from_issue(
            issue_id=issue_id,
            services=services,
            auto_approve=auto_approve
        )

        return result

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/executions")
async def list_executions():
    """List all active workflow executions."""
    executions = workflow_manager.get_active_executions()
    return [
        {
            "id": e.id,
            "workflow_id": e.workflow_id,
            "status": e.status,
            "started_at": e.started_at.isoformat() if e.started_at else None,
            "current_step": e.current_step,
            "completed_steps": len(e.completed_steps),
            "failed_steps": len(e.failed_steps),
            "github_issue": {
                "id": e.github_issue.issue_id,
                "title": e.github_issue.issue_title,
                "labels": e.github_issue.issue_labels
            } if e.github_issue else None
        }
        for e in executions
    ]


@app.get("/api/executions/{execution_id}")
async def get_execution(execution_id: str):
    """Get detailed execution information."""
    execution = workflow_manager.get_execution(execution_id)
    if not execution:
        raise HTTPException(status_code=404, detail="Execution not found")

    # Handle both Pydantic v1 and v2 serialization methods
    try:
        return execution.model_dump()  # Pydantic v2
    except AttributeError:
        return execution.dict()  # Pydantic v1


@app.post("/api/executions/{execution_id}/cancel")
async def cancel_execution(execution_id: str):
    """Cancel workflow execution."""
    result = workflow_manager.cancel_execution(execution_id)
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["error"])
    return result


@app.get("/api/approvals")
async def list_approvals():
    """List all pending approvals."""
    approvals = workflow_manager.get_pending_approvals()
    return [
        {
            "id": a.id,
            "workflow_execution_id": a.workflow_execution_id,
            "title": a.title,
            "description": a.description,
            "status": a.status,
            "requested_at": a.requested_at.isoformat(),
            "timeout_minutes": a.timeout_minutes
        }
        for a in approvals
    ]


@app.post("/api/approvals/{approval_id}/respond")
async def respond_to_approval(approval_id: str, request: Request):
    """Respond to approval request."""
    try:
        body = await request.json()
        approved = body.get("approved")
        comments = body.get("comments")

        if approved is None:
            raise HTTPException(status_code=400, detail="approved field is required")

        result = workflow_manager.approve_workflow(
            approval_id=approval_id,
            approved=approved,
            comments=comments
        )

        if not result["success"]:
            raise HTTPException(status_code=400, detail=result["error"])

        return result

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/workflows/{workflow_id}/validate")
async def validate_workflow(workflow_id: str):
    """Validate a workflow structure."""
    registry = get_registry_manager()
    # validation = registry.workflows.validate_workflow_graph(workflow_id)  # Temporarily disabled
    validation = {"valid": False, "message": "Workflows temporarily disabled"}
    return validation


# WebSocket endpoint for real-time updates
@app.websocket("/ws/{client_id}")
async def websocket_endpoint(websocket: WebSocket, client_id: str):
    """WebSocket endpoint for real-time execution updates."""
    await manager.connect(websocket, client_id)

    try:
        while True:
            # Keep connection alive
            data = await websocket.receive_text()

            # Echo back for now
            await manager.send_message(
                json.dumps({
                    "type": "ping",
                    "data": data,
                    "timestamp": datetime.now().isoformat()
                }),
                client_id
            )
    except WebSocketDisconnect:
        manager.disconnect(websocket, client_id)


async def run_workflow_async(workflow_id: str, inputs: dict, execution_id: str):
    """Run workflow asynchronously and send updates via WebSocket."""
    # executor = WorkflowExecutor()  # Temporarily disabled
    pass

    try:
        # Send start message
        await manager.broadcast(
            json.dumps({
                "type": "execution_started",
                "execution_id": execution_id,
                "workflow_id": workflow_id,
                "timestamp": datetime.now().isoformat()
            })
        )

        # Execute workflow
        # result = await executor.execute_workflow(workflow_id, inputs)  # Temporarily disabled
        result = {"status": "disabled", "message": "Workflow execution temporarily disabled"}

        # Send completion message
        await manager.broadcast(
            json.dumps({
                "type": "execution_completed",
                "execution_id": execution_id,
                "workflow_id": workflow_id,
                "result": result,
                "timestamp": datetime.now().isoformat()
            })
        )

    except Exception as e:
        # Send error message
        await manager.broadcast(
            json.dumps({
                "type": "execution_failed",
                "execution_id": execution_id,
                "workflow_id": workflow_id,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            })
        )


# GitHub API Routes
@app.get("/api/github/issues")
async def get_github_issues(state: str = "open"):
    """Fetch GitHub issues from the microforge repository."""
    try:
        from ..providers.vcs.github import GitHubProvider

        github_provider = GitHubProvider()

        # Build command to fetch issues from microforge repo
        gh_command = [
            "issue", "list",
            "--repo", "inviz-search/microforge-ai",
            "--state", state,
            "--limit", "100",
            "--json", "number,title,body,labels,state,createdAt,author,comments,url"
        ]

        result = github_provider.run_gh_command(gh_command)

        if result['success']:
            import json
            issues = json.loads(result['stdout'])

            # Transform the data for the frontend
            transformed_issues = []
            for issue in issues:
                transformed_issues.append({
                    "number": issue.get("number"),
                    "title": issue.get("title"),
                    "body": issue.get("body", ""),
                    "state": issue.get("state", "open"),
                    "created_at": issue.get("createdAt"),
                    "html_url": issue.get("url"),
                    "comments": issue.get("comments", 0),
                    "labels": [{"name": label["name"], "color": label.get("color", "666666")}
                              for label in issue.get("labels", [])],
                    "user": {
                        "login": issue.get("author", {}).get("login", "unknown"),
                        "avatar_url": f"https://github.com/{issue.get('author', {}).get('login', 'ghost')}.png?size=32"
                    }
                })

            return transformed_issues
        else:
            raise HTTPException(status_code=500, detail=f"Failed to fetch issues: {result['stderr']}")

    except Exception as e:
        console.print(f"[red]Error fetching GitHub issues: {e}[/red]")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/github/issues/{issue_number}/implement")
async def implement_github_issue(issue_number: int):
    """Implement a GitHub issue by creating a workflow execution."""
    try:
        # Use the global workflow manager instance
        global workflow_manager

        # Create workflow from issue with auto-approval for web UI
        result = workflow_manager.create_workflow_from_issue(
            issue_id=str(issue_number),
            services=None,
            auto_approve=True  # Auto-approve for web UI implementation
        )

        if result["success"]:
            execution = result["execution"]
            return {
                "success": True,
                "message": f"Issue #{issue_number} workflow created and executing",
                "execution_id": execution.id,
                "execution_url": result["execution_url"]
            }
        else:
            return {
                "success": False,
                "error": result.get("error", "Failed to create workflow")
            }

    except Exception as e:
        console.print(f"[red]Error implementing issue: {e}[/red]")
        return {
            "success": False,
            "error": str(e)
        }


@app.on_event("startup")
async def startup_event():
    """Initialize application on startup."""
    console.print("[bold cyan]🚀 Microforge UI starting up...[/bold cyan]")

    # Ensure registry is loaded
    registry = get_registry_manager()
    counts = registry.get_counts()

    console.print(f"[green]✓[/green] Loaded {counts['workflows']} workflows")
    console.print(f"[green]✓[/green] Loaded {counts['agents']} agents")
    console.print(f"[green]✓[/green] Loaded {counts['services']} services")


@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown."""
    console.print("[dim]Shutting down Microforge UI...[/dim]")