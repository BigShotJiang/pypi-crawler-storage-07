"""
Microforge Web UI - Futuristic workflow management interface.

A modern, glassmorphic UI for managing multi-agent workflows with LangGraph.
"""

from .app import app

__all__ = ["app"]