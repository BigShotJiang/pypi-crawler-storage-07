"""
Exception hierarchy for Microforge v2.

Provides structured error handling with clear categorization and context.
"""

from typing import Optional, Dict, Any


class MicroforgeException(Exception):
    """Base exception for all Microforge errors."""

    def __init__(
        self,
        message: str,
        context: Optional[Dict[str, Any]] = None,
        cause: Optional[Exception] = None
    ):
        super().__init__(message)
        self.message = message
        self.context = context or {}
        self.cause = cause

    def __str__(self) -> str:
        """Return formatted error message."""
        if self.context:
            context_str = ", ".join(f"{k}={v}" for k, v in self.context.items())
            return f"{self.message} (context: {context_str})"
        return self.message


class ValidationError(MicroforgeException):
    """Exception raised for input validation errors."""

    def __init__(
        self,
        message: str,
        field: Optional[str] = None,
        value: Optional[Any] = None,
        **kwargs
    ):
        context = kwargs.get('context', {})
        if field:
            context['field'] = field
        if value is not None:
            context['value'] = str(value)
        super().__init__(message, context, kwargs.get('cause'))
        self.field = field
        self.value = value


class ConfigurationError(MicroforgeException):
    """Exception raised for configuration-related errors."""

    def __init__(
        self,
        message: str,
        config_path: Optional[str] = None,
        config_key: Optional[str] = None,
        **kwargs
    ):
        context = kwargs.get('context', {})
        if config_path:
            context['config_path'] = config_path
        if config_key:
            context['config_key'] = config_key
        super().__init__(message, context, kwargs.get('cause'))
        self.config_path = config_path
        self.config_key = config_key


class ServiceError(MicroforgeException):
    """Exception raised for business logic service errors."""

    def __init__(
        self,
        message: str,
        service_name: Optional[str] = None,
        operation: Optional[str] = None,
        **kwargs
    ):
        context = kwargs.get('context', {})
        if service_name:
            context['service_name'] = service_name
        if operation:
            context['operation'] = operation
        super().__init__(message, context, kwargs.get('cause'))
        self.service_name = service_name
        self.operation = operation


class IntegrationError(MicroforgeException):
    """Exception raised for external integration errors."""

    def __init__(
        self,
        message: str,
        provider: Optional[str] = None,
        integration_type: Optional[str] = None,
        **kwargs
    ):
        context = kwargs.get('context', {})
        if provider:
            context['provider'] = provider
        if integration_type:
            context['integration_type'] = integration_type
        super().__init__(message, context, kwargs.get('cause'))
        self.provider = provider
        self.integration_type = integration_type


class ProviderError(IntegrationError):
    """Exception raised for provider operation errors."""

    def __init__(
        self,
        message: str,
        provider_name: Optional[str] = None,
        operation: Optional[str] = None,
        **kwargs
    ):
        context = kwargs.get('context', {})
        if operation:
            context['operation'] = operation
        super().__init__(message, provider_name, "provider", **kwargs)
        self.provider_name = provider_name
        self.operation = operation


class GitError(IntegrationError):
    """Exception raised for Git operation errors."""

    def __init__(
        self,
        message: str,
        command: Optional[str] = None,
        repo_path: Optional[str] = None,
        **kwargs
    ):
        context = kwargs.get('context', {})
        if command:
            context['git_command'] = command
        if repo_path:
            context['repo_path'] = repo_path
        super().__init__(message, provider="git", integration_type="vcs", context=context, **kwargs)
        self.command = command
        self.repo_path = repo_path


class GitHubError(IntegrationError):
    """Exception raised for GitHub integration errors."""

    def __init__(
        self,
        message: str,
        command: Optional[str] = None,
        repo: Optional[str] = None,
        **kwargs
    ):
        context = kwargs.get('context', {})
        if command:
            context['github_command'] = command
        if repo:
            context['repo'] = repo
        super().__init__(message, provider="github", integration_type="api", context=context, **kwargs)
        self.command = command
        self.repo = repo


class LLMError(IntegrationError):
    """Exception raised for LLM provider errors."""

    def __init__(
        self,
        message: str,
        provider: Optional[str] = None,
        command: Optional[str] = None,
        **kwargs
    ):
        context = kwargs.get('context', {})
        if command:
            context['llm_command'] = command
        super().__init__(message, provider=provider, integration_type="llm", context=context, **kwargs)
        self.command = command


class ClaudeError(LLMError):
    """Exception raised for Claude CLI errors."""

    def __init__(self, message: str, command: Optional[str] = None, **kwargs):
        super().__init__(message, provider="claude", command=command, **kwargs)


class NotFoundError(MicroforgeException):
    """Exception raised when a resource is not found."""

    def __init__(
        self,
        message: str,
        resource_type: Optional[str] = None,
        resource_id: Optional[str] = None,
        **kwargs
    ):
        context = kwargs.get('context', {})
        if resource_type:
            context['resource_type'] = resource_type
        if resource_id:
            context['resource_id'] = resource_id
        super().__init__(message, context, kwargs.get('cause'))
        self.resource_type = resource_type
        self.resource_id = resource_id


class FileSystemError(MicroforgeException):
    """Exception raised for file system operation errors."""

    def __init__(
        self,
        message: str,
        path: Optional[str] = None,
        operation: Optional[str] = None,
        **kwargs
    ):
        context = kwargs.get('context', {})
        if path:
            context['path'] = path
        if operation:
            context['operation'] = operation
        super().__init__(message, context, kwargs.get('cause'))
        self.path = path
        self.operation = operation


class StorageError(MicroforgeException):
    """Exception raised for storage provider errors."""

    def __init__(
        self,
        message: str,
        provider: Optional[str] = None,
        operation: Optional[str] = None,
        **kwargs
    ):
        context = kwargs.get('context', {})
        if provider:
            context['provider'] = provider
        if operation:
            context['operation'] = operation
        super().__init__(message, context, kwargs.get('cause'))
        self.provider = provider
        self.operation = operation


class PermissionError(FileSystemError):
    """Exception raised for permission-related errors."""

    def __init__(self, message: str, path: Optional[str] = None, **kwargs):
        super().__init__(message, path=path, operation="permission_check", **kwargs)


class TimeoutError(MicroforgeException):
    """Exception raised when an operation times out."""

    def __init__(
        self,
        message: str,
        timeout_seconds: Optional[int] = None,
        operation: Optional[str] = None,
        **kwargs
    ):
        context = kwargs.get('context', {})
        if timeout_seconds:
            context['timeout_seconds'] = timeout_seconds
        if operation:
            context['operation'] = operation
        super().__init__(message, context, kwargs.get('cause'))
        self.timeout_seconds = timeout_seconds
        self.operation = operation


class WorkflowError(MicroforgeException):
    """Exception raised for workflow execution errors."""

    def __init__(
        self,
        message: str,
        workflow_id: Optional[str] = None,
        step_id: Optional[str] = None,
        **kwargs
    ):
        context = kwargs.get('context', {})
        if workflow_id:
            context['workflow_id'] = workflow_id
        if step_id:
            context['step_id'] = step_id
        super().__init__(message, context, kwargs.get('cause'))
        self.workflow_id = workflow_id
        self.step_id = step_id


# Exception mapping for common error scenarios
ERROR_TYPE_MAPPING = {
    "file_not_found": NotFoundError,
    "directory_not_found": NotFoundError,
    "service_not_found": NotFoundError,
    "permission_denied": PermissionError,
    "timeout": TimeoutError,
    "validation": ValidationError,
    "configuration": ConfigurationError,
    "git": GitError,
    "github": GitHubError,
    "claude": ClaudeError,
    "llm": LLMError,
    "service": ServiceError,
    "integration": IntegrationError,
    "workflow": WorkflowError,
}


def create_exception(
    error_type: str,
    message: str,
    **kwargs
) -> MicroforgeException:
    """Create an exception of the appropriate type."""
    exception_class = ERROR_TYPE_MAPPING.get(error_type, MicroforgeException)
    return exception_class(message, **kwargs)