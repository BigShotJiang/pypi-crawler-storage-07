"""
Common utilities for Microforge v2.

Shared functionality to eliminate code duplication throughout the codebase.
All common patterns and utilities should be defined here.
"""

import subprocess
import shutil
import json
import yaml
from pathlib import Path
from typing import Any, Dict, List, Optional, Union, Tuple
from datetime import datetime
from rich.console import Console

# Removed audit decorators to prevent recursion when used by audit system itself
from .exceptions import (
    ValidationError,
    FileSystemError,
    GitError,
    TimeoutError,
    create_exception
)
from ..config.constants import (
    SUBPROCESS_DEFAULT_TIMEOUT,
    SUBPROCESS_ENCODING,
    SUBPROCESS_ERRORS,
    YAML_EXTENSIONS,
    JSON_EXTENSIONS,
    SERVICE_NAME_PATTERN,
    SERVICE_NAME_MIN_LENGTH,
    SERVICE_NAME_MAX_LENGTH,
    GITHUB_URL_PATTERN,
    GITHUB_SSH_PATTERN,
    FILENAME_INVALID_CHARS,
    SUCCESS_EMOJI,
    ERROR_EMOJI,
    WARNING_EMOJI,
    INFO_EMOJI,
    COLOR_SUCCESS,
    COLOR_ERROR,
    COLOR_WARNING,
    COLOR_INFO
)

# Global console instance for consistent formatting
console = Console()


# =============================================================================
# SUBPROCESS UTILITIES
# =============================================================================

def run_command(
    command: Union[str, List[str]],
    cwd: Optional[Path] = None,
    timeout: Optional[int] = None,
    capture_output: bool = True,
    check: bool = True,
    encoding: str = SUBPROCESS_ENCODING,
    errors: str = SUBPROCESS_ERRORS
) -> subprocess.CompletedProcess:
    """
    Run a subprocess command with standardized configuration.

    Args:
        command: Command to run (string or list)
        cwd: Working directory
        timeout: Command timeout in seconds
        capture_output: Whether to capture stdout/stderr
        check: Whether to raise exception on non-zero exit
        encoding: Text encoding for output
        errors: How to handle encoding errors

    Returns:
        CompletedProcess result

    Raises:
        TimeoutError: If command times out
        subprocess.CalledProcessError: If command fails and check=True
    """
    if isinstance(command, str):
        command = command.split()

    timeout = timeout or SUBPROCESS_DEFAULT_TIMEOUT

    try:
        result = subprocess.run(
            command,
            cwd=cwd,
            timeout=timeout,
            capture_output=capture_output,
            text=True,
            encoding=encoding,
            errors=errors,
            check=check
        )
        return result

    except subprocess.TimeoutExpired as e:
        raise TimeoutError(
            f"Command timed out after {timeout} seconds",
            timeout_seconds=timeout,
            operation="subprocess",
            context={'command': command, 'cwd': str(cwd) if cwd else None}
        ) from e

    except subprocess.CalledProcessError as e:
        raise create_exception(
            "subprocess",
            f"Command failed with exit code {e.returncode}",
            context={
                'command': command,
                'cwd': str(cwd) if cwd else None,
                'exit_code': e.returncode,
                'stdout': e.stdout,
                'stderr': e.stderr
            }
        ) from e


def run_command_silent(
    command: Union[str, List[str]],
    cwd: Optional[Path] = None,
    timeout: Optional[int] = None
) -> bool:
    """
    Run a command silently and return success status.

    Args:
        command: Command to run
        cwd: Working directory
        timeout: Command timeout

    Returns:
        True if command succeeded, False otherwise
    """
    try:
        run_command(command, cwd=cwd, timeout=timeout, capture_output=True, check=True)
        return True
    except Exception:
        return False


def check_executable_available(executable: str) -> bool:
    """Check if an executable is available in PATH."""
    return shutil.which(executable) is not None


# =============================================================================
# FILE SYSTEM UTILITIES
# =============================================================================

def read_file_safe(
    file_path: Union[str, Path],
    encoding: str = "utf-8",
    errors: str = "replace"
) -> str:
    """
    Safely read a text file with error handling.

    Args:
        file_path: Path to the file
        encoding: Text encoding
        errors: How to handle encoding errors

    Returns:
        File contents as string

    Raises:
        FileSystemError: If file cannot be read
    """
    path = Path(file_path)

    if not path.exists():
        raise FileSystemError(
            f"File not found: {path}",
            path=str(path),
            operation="read"
        )

    try:
        with open(path, 'r', encoding=encoding, errors=errors) as f:
            return f.read()
    except Exception as e:
        raise FileSystemError(
            f"Failed to read file: {path}",
            path=str(path),
            operation="read"
        ) from e


def write_file_safe(
    file_path: Union[str, Path],
    content: str,
    encoding: str = "utf-8",
    create_dirs: bool = True
) -> None:
    """
    Safely write content to a file with error handling.

    Args:
        file_path: Path to the file
        content: Content to write
        encoding: Text encoding
        create_dirs: Whether to create parent directories

    Raises:
        FileSystemError: If file cannot be written
    """
    path = Path(file_path)

    if create_dirs:
        path.parent.mkdir(parents=True, exist_ok=True)

    try:
        with open(path, 'w', encoding=encoding) as f:
            f.write(content)
    except Exception as e:
        raise FileSystemError(
            f"Failed to write file: {path}",
            path=str(path),
            operation="write"
        ) from e


def copy_file_safe(
    source: Union[str, Path],
    destination: Union[str, Path],
    create_dirs: bool = True
) -> None:
    """
    Safely copy a file with error handling.

    Args:
        source: Source file path
        destination: Destination file path
        create_dirs: Whether to create parent directories

    Raises:
        FileSystemError: If file cannot be copied
    """
    src_path = Path(source)
    dst_path = Path(destination)

    if not src_path.exists():
        raise FileSystemError(
            f"Source file not found: {src_path}",
            path=str(src_path),
            operation="copy"
        )

    if create_dirs:
        dst_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        shutil.copy2(src_path, dst_path)
    except Exception as e:
        raise FileSystemError(
            f"Failed to copy file from {src_path} to {dst_path}",
            path=str(src_path),
            operation="copy"
        ) from e


def delete_file_safe(file_path: Union[str, Path]) -> bool:
    """
    Safely delete a file.

    Args:
        file_path: Path to the file

    Returns:
        True if file was deleted, False if it didn't exist

    Raises:
        FileSystemError: If file cannot be deleted
    """
    path = Path(file_path)

    if not path.exists():
        return False

    try:
        path.unlink()
        return True
    except Exception as e:
        raise FileSystemError(
            f"Failed to delete file: {path}",
            path=str(path),
            operation="delete"
        ) from e


# =============================================================================
# CONFIGURATION FILE UTILITIES
# =============================================================================

def load_config_file(
    file_path: Union[str, Path],
    default: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Load configuration from YAML or JSON file.

    Args:
        file_path: Path to configuration file
        default: Default configuration if file doesn't exist

    Returns:
        Configuration dictionary

    Raises:
        FileSystemError: If file cannot be parsed
    """
    path = Path(file_path)

    if not path.exists():
        return default or {}

    try:
        content = read_file_safe(path)

        if path.suffix.lower() in YAML_EXTENSIONS:
            return yaml.safe_load(content) or {}
        elif path.suffix.lower() in JSON_EXTENSIONS:
            return json.loads(content) or {}
        else:
            # Try YAML first, then JSON
            try:
                return yaml.safe_load(content) or {}
            except yaml.YAMLError:
                return json.loads(content) or {}

    except Exception as e:
        raise FileSystemError(
            f"Failed to parse configuration file: {path}",
            path=str(path),
            operation="parse"
        ) from e


def save_config_file(
    file_path: Union[str, Path],
    config: Dict[str, Any],
    format_type: str = "auto"
) -> None:
    """
    Save configuration to YAML or JSON file.

    Args:
        file_path: Path to configuration file
        config: Configuration to save
        format_type: Format type ('yaml', 'json', or 'auto')

    Raises:
        FileSystemError: If file cannot be written
    """
    path = Path(file_path)

    # Determine format
    if format_type == "auto":
        if path.suffix.lower() in YAML_EXTENSIONS:
            format_type = "yaml"
        elif path.suffix.lower() in JSON_EXTENSIONS:
            format_type = "json"
        else:
            format_type = "yaml"  # Default to YAML

    try:
        if format_type == "yaml":
            content = yaml.dump(config, default_flow_style=False, sort_keys=False)
        else:
            content = json.dumps(config, indent=2, ensure_ascii=False)

        write_file_safe(path, content)

    except Exception as e:
        raise FileSystemError(
            f"Failed to save configuration file: {path}",
            path=str(path),
            operation="save"
        ) from e


# =============================================================================
# VALIDATION UTILITIES
# =============================================================================

def validate_service_name(name: str) -> bool:
    """
    Validate service name format.

    DEPRECATED: Use validation.validate_service_name() instead.

    Args:
        name: Service name to validate

    Returns:
        True if valid, False otherwise
    """
    from .validation import validate_service_name as new_validate
    is_valid, _ = new_validate(name)
    return is_valid


def validate_github_url(url: str) -> bool:
    """
    Validate GitHub repository URL format.

    DEPRECATED: Use validation.validate_github_url() instead.

    Args:
        url: URL to validate

    Returns:
        True if valid GitHub URL, False otherwise
    """
    from .validation import validate_github_url as new_validate
    is_valid, _ = new_validate(url)
    return is_valid


def validate_filename(filename: str) -> bool:
    """
    Validate filename for safety.

    DEPRECATED: Use validation.validate_filename() instead.

    Args:
        filename: Filename to validate

    Returns:
        True if valid, False otherwise
    """
    from .validation import validate_filename as new_validate
    is_valid, _ = new_validate(filename)
    return is_valid


def sanitize_filename(filename: str) -> str:
    """
    Sanitize filename by removing invalid characters.

    Args:
        filename: Filename to sanitize

    Returns:
        Sanitized filename
    """
    if not filename:
        return "untitled"

    sanitized = filename
    for char in FILENAME_INVALID_CHARS:
        sanitized = sanitized.replace(char, '_')

    return sanitized


# =============================================================================
# CONSOLE UTILITIES
# =============================================================================

def print_success(message: str, emoji: bool = True) -> None:
    """Print success message with consistent formatting."""
    prefix = f"{SUCCESS_EMOJI} " if emoji else ""
    console.print(f"[{COLOR_SUCCESS}]{prefix}{message}[/{COLOR_SUCCESS}]")


def print_error(message: str, emoji: bool = True) -> None:
    """Print error message with consistent formatting."""
    prefix = f"{ERROR_EMOJI} " if emoji else ""
    console.print(f"[{COLOR_ERROR}]{prefix}{message}[/{COLOR_ERROR}]")


def print_warning(message: str, emoji: bool = True) -> None:
    """Print warning message with consistent formatting."""
    prefix = f"{WARNING_EMOJI} " if emoji else ""
    console.print(f"[{COLOR_WARNING}]{prefix}{message}[/{COLOR_WARNING}]")


def print_info(message: str, emoji: bool = True) -> None:
    """Print info message with consistent formatting."""
    prefix = f"{INFO_EMOJI} " if emoji else ""
    console.print(f"[{COLOR_INFO}]{prefix}{message}[/{COLOR_INFO}]")


# =============================================================================
# GIT UTILITIES (imported from providers/vcs)
# =============================================================================



# =============================================================================
# TIMESTAMP UTILITIES
# =============================================================================

def get_timestamp() -> str:
    """Get current timestamp in ISO format."""
    return datetime.utcnow().isoformat() + 'Z'


def get_timestamp_filename() -> str:
    """Get timestamp suitable for filename."""
    return datetime.now().strftime("%Y%m%d-%H%M%S")


# =============================================================================
# DATA FORMATTING UTILITIES
# =============================================================================

def format_duration(duration_ms: float) -> str:
    """Format duration in milliseconds to human-readable string."""
    if duration_ms < 1000:
        return f"{duration_ms:.0f}ms"
    elif duration_ms < 60000:
        return f"{duration_ms / 1000:.1f}s"
    else:
        minutes = int(duration_ms / 60000)
        seconds = (duration_ms % 60000) / 1000
        return f"{minutes}m {seconds:.1f}s"


def format_file_size(size_bytes: int) -> str:
    """Format file size in bytes to human-readable string."""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024:
            return f"{size_bytes:.1f}{unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f}TB"


def truncate_string(text: str, max_length: int = 100, suffix: str = "...") -> str:
    """Truncate string to maximum length with suffix."""
    if len(text) <= max_length:
        return text
    return text[:max_length - len(suffix)] + suffix


# =============================================================================
# PATH UTILITIES
# =============================================================================

def ensure_path_exists(path: Union[str, Path]) -> Path:
    """
    Ensure a directory path exists, creating it if necessary.

    Args:
        path: Directory path to ensure exists

    Returns:
        Path object for the directory
    """
    path_obj = Path(path)
    path_obj.mkdir(parents=True, exist_ok=True)
    return path_obj


def get_relative_path(path: Union[str, Path], base: Optional[Path] = None) -> Path:
    """
    Get relative path from base (default: current working directory).

    Args:
        path: Path to make relative
        base: Base path (default: current directory)

    Returns:
        Relative path
    """
    path_obj = Path(path)
    if base is None:
        base = Path.cwd()

    try:
        return path_obj.relative_to(base)
    except ValueError:
        # If path is not relative to base, return original path
        return path_obj


# =============================================================================
# FORMATTING UTILITIES (from old common.py)
# =============================================================================

def format_success(message: str, emoji: bool = True) -> str:
    """Format a success message string (without printing)."""
    return f"{SUCCESS_EMOJI} {message}" if emoji else message


def format_error(message: str, emoji: bool = True) -> str:
    """Format an error message string (without printing)."""
    return f"{ERROR_EMOJI} {message}" if emoji else message


def format_warning(message: str, emoji: bool = True) -> str:
    """Format a warning message string (without printing)."""
    return f"{WARNING_EMOJI} {message}" if emoji else message


def format_info(message: str, emoji: bool = True) -> str:
    """Format an info message string (without printing)."""
    return f"{INFO_EMOJI} {message}" if emoji else message