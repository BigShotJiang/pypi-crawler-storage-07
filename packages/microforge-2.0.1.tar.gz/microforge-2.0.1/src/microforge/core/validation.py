"""
Centralized validation utilities for Microforge v2.

Consolidates all validation logic in one place to avoid duplication.
"""

import re
from pathlib import Path
from typing import Optional, Tuple
from urllib.parse import urlparse

from ..config.constants import ERRORS


def validate_service_name(name: str) -> Tuple[bool, Optional[str]]:
    """
    Validate a service name.

    Args:
        name: Service name to validate

    Returns:
        Tuple of (is_valid, error_message)
    """
    if not name:
        return False, "Service name cannot be empty"

    if len(name) < 3:
        return False, "Service name must be at least 3 characters"

    if len(name) > 50:
        return False, "Service name must be less than 50 characters"

    # Check for valid characters (alphanumeric, hyphen, underscore)
    pattern = r'^[a-zA-Z][a-zA-Z0-9_-]*$'
    if not re.match(pattern, name):
        return False, "Service name must start with a letter and contain only letters, numbers, hyphens, and underscores"

    # Check for reserved names
    reserved_names = ['all', 'none', 'test', 'debug', 'admin', 'root']
    if name.lower() in reserved_names:
        return False, f"'{name}' is a reserved name"

    return True, None


def validate_github_url(url: str) -> Tuple[bool, Optional[str]]:
    """
    Validate a GitHub repository URL.

    Args:
        url: URL to validate

    Returns:
        Tuple of (is_valid, error_message)
    """
    if not url:
        return False, "URL cannot be empty"

    # Parse the URL
    try:
        parsed = urlparse(url)
    except Exception:
        return False, "Invalid URL format"

    # Check if it's a GitHub URL
    if parsed.hostname not in ['github.com', 'www.github.com']:
        return False, "URL must be a GitHub repository"

    # Check for valid GitHub repo path
    path_parts = parsed.path.strip('/').split('/')
    if len(path_parts) != 2:
        return False, "Invalid GitHub repository path. Expected format: github.com/owner/repo"

    owner, repo = path_parts
    if not owner or not repo:
        return False, "GitHub owner and repository name cannot be empty"

    # Remove .git extension if present
    if repo.endswith('.git'):
        repo = repo[:-4]

    # Validate owner and repo names
    github_pattern = r'^[a-zA-Z0-9]([a-zA-Z0-9-])*[a-zA-Z0-9]$'
    if not re.match(github_pattern, owner):
        return False, f"Invalid GitHub owner name: {owner}"

    if not re.match(github_pattern, repo):
        return False, f"Invalid GitHub repository name: {repo}"

    return True, None


def validate_filename(filename: str, allow_path: bool = False) -> Tuple[bool, Optional[str]]:
    """
    Validate a filename or file path.

    Args:
        filename: Filename to validate
        allow_path: Whether to allow path separators

    Returns:
        Tuple of (is_valid, error_message)
    """
    if not filename:
        return False, "Filename cannot be empty"

    if not allow_path and ('/' in filename or '\\' in filename):
        return False, "Filename cannot contain path separators"

    # Check for invalid characters
    invalid_chars = '<>:"|?*' if not allow_path else '<>:"|?*'
    for char in invalid_chars:
        if char in filename:
            return False, f"Filename cannot contain '{char}'"

    # Check for reserved names (Windows)
    reserved_names = ['CON', 'PRN', 'AUX', 'NUL'] + [f'COM{i}' for i in range(1, 10)] + [f'LPT{i}' for i in range(1, 10)]
    name_without_ext = Path(filename).stem.upper()
    if name_without_ext in reserved_names:
        return False, f"'{name_without_ext}' is a reserved filename"

    # Check for trailing dots or spaces
    if filename.endswith('.') or filename.endswith(' '):
        return False, "Filename cannot end with a dot or space"

    return True, None


def validate_branch_name(branch: str) -> Tuple[bool, Optional[str]]:
    """
    Validate a git branch name.

    Args:
        branch: Branch name to validate

    Returns:
        Tuple of (is_valid, error_message)
    """
    if not branch:
        return False, "Branch name cannot be empty"

    # Check for invalid characters
    invalid_patterns = [
        '..',  # Double dots
        '~',   # Tilde
        '^',   # Caret
        ':',   # Colon
        '?',   # Question mark
        '*',   # Asterisk
        '[',   # Square bracket
        '\\',  # Backslash
        ' ',   # Space
    ]

    for pattern in invalid_patterns:
        if pattern in branch:
            return False, f"Branch name cannot contain '{pattern}'"

    # Check for invalid starting/ending characters
    if branch.startswith('/') or branch.endswith('/'):
        return False, "Branch name cannot start or end with '/'"

    if branch.startswith('.') or branch.endswith('.'):
        return False, "Branch name cannot start or end with '.'"

    if branch.endswith('.lock'):
        return False, "Branch name cannot end with '.lock'"

    # Check for @{
    if '@{' in branch:
        return False, "Branch name cannot contain '@{'"

    return True, None


def validate_email(email: str) -> Tuple[bool, Optional[str]]:
    """
    Validate an email address.

    Args:
        email: Email address to validate

    Returns:
        Tuple of (is_valid, error_message)
    """
    if not email:
        return False, "Email cannot be empty"

    # Basic email regex pattern
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    if not re.match(pattern, email):
        return False, "Invalid email format"

    return True, None


def validate_port(port: int) -> Tuple[bool, Optional[str]]:
    """
    Validate a port number.

    Args:
        port: Port number to validate

    Returns:
        Tuple of (is_valid, error_message)
    """
    if not isinstance(port, int):
        return False, "Port must be an integer"

    if port < 1 or port > 65535:
        return False, "Port must be between 1 and 65535"

    # Check for commonly reserved ports
    if port < 1024:
        return True, "Warning: Port is in the privileged range (< 1024)"

    return True, None


def validate_directory(path: Path, must_exist: bool = False, must_be_empty: bool = False) -> Tuple[bool, Optional[str]]:
    """
    Validate a directory path.

    Args:
        path: Directory path to validate
        must_exist: Whether the directory must exist
        must_be_empty: Whether the directory must be empty (only checked if it exists)

    Returns:
        Tuple of (is_valid, error_message)
    """
    if not path:
        return False, "Path cannot be empty"

    if must_exist:
        if not path.exists():
            return False, f"Directory does not exist: {path}"
        if not path.is_dir():
            return False, f"Path is not a directory: {path}"

    if path.exists() and must_be_empty:
        if not path.is_dir():
            return False, f"Path is not a directory: {path}"
        if any(path.iterdir()):
            return False, f"Directory is not empty: {path}"

    return True, None


def validate_agent_name(name: str) -> Tuple[bool, Optional[str]]:
    """
    Validate an agent name.

    Args:
        name: Agent name to validate

    Returns:
        Tuple of (is_valid, error_message)
    """
    if not name:
        return False, "Agent name cannot be empty"

    # Allow alphanumeric, underscore, hyphen
    pattern = r'^[a-zA-Z][a-zA-Z0-9_-]*$'
    if not re.match(pattern, name):
        return False, "Agent name must start with a letter and contain only letters, numbers, hyphens, and underscores"

    if len(name) > 50:
        return False, "Agent name must be less than 50 characters"

    return True, None


def validate_temperature(temp: float) -> Tuple[bool, Optional[str]]:
    """
    Validate LLM temperature setting.

    Args:
        temp: Temperature value to validate

    Returns:
        Tuple of (is_valid, error_message)
    """
    if not isinstance(temp, (int, float)):
        return False, "Temperature must be a number"

    if temp < 0.0 or temp > 2.0:
        return False, "Temperature must be between 0.0 and 2.0"

    if temp > 1.0:
        return True, "Warning: Temperature > 1.0 may produce unpredictable results"

    return True, None


def validate_timeout(timeout: int) -> Tuple[bool, Optional[str]]:
    """
    Validate a timeout value in seconds.

    Args:
        timeout: Timeout value in seconds

    Returns:
        Tuple of (is_valid, error_message)
    """
    if not isinstance(timeout, int):
        return False, "Timeout must be an integer"

    if timeout < 1:
        return False, "Timeout must be at least 1 second"

    if timeout > 3600:
        return True, "Warning: Timeout > 3600 seconds (1 hour) may be excessive"

    return True, None


def validate_json_path(path: str) -> Tuple[bool, Optional[str]]:
    """
    Validate a JSON path expression.

    Args:
        path: JSON path to validate

    Returns:
        Tuple of (is_valid, error_message)
    """
    if not path:
        return False, "JSON path cannot be empty"

    # Basic validation for JSON path
    if not path.startswith('$'):
        return False, "JSON path must start with '$'"

    # Check for valid characters
    valid_pattern = r'^[\$\.\[\]a-zA-Z0-9_\*\'\"@\(\)\?\:\=\!\<\>\s-]+$'
    if not re.match(valid_pattern, path):
        return False, "JSON path contains invalid characters"

    return True, None


# Validation decorators for common patterns
def require_valid_service_name(func):
    """Decorator to validate service name parameter."""
    def wrapper(*args, **kwargs):
        name = kwargs.get('service_name') or kwargs.get('name')
        if name:
            is_valid, error = validate_service_name(name)
            if not is_valid:
                raise ValueError(f"Invalid service name: {error}")
        return func(*args, **kwargs)
    return wrapper


def require_valid_github_url(func):
    """Decorator to validate GitHub URL parameter."""
    def wrapper(*args, **kwargs):
        url = kwargs.get('repo_url') or kwargs.get('url')
        if url:
            is_valid, error = validate_github_url(url)
            if not is_valid:
                raise ValueError(f"Invalid GitHub URL: {error}")
        return func(*args, **kwargs)
    return wrapper