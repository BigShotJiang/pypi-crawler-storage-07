"""
Common import bundles for Microforge v2.

Consolidates frequently used imports to reduce redundancy across modules.
"""

# =============================================================================
# STANDARD LIBRARY IMPORTS
# =============================================================================

# Python standard library - commonly used
from pathlib import Path
from typing import Dict, Any, Optional, List, Tuple, Union, Set
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from enum import Enum
import json
import os
import sys
import time
import uuid
import re

# =============================================================================
# CORE IMPORTS
# =============================================================================


# Core common utilities bundle
from .common import (
    console,
    print_success,
    print_error,
    print_warning,
    print_info,
    ensure_path_exists,
    load_config_file,
    save_config_file,
    copy_file_safe,
    run_command,
    check_executable_available
)

# Core exceptions bundle
from .exceptions import (
    MicroforgeError,
    ValidationError,
    ConfigurationError,
    ServiceError,
    NotFoundError,
    AlreadyExistsError,
    FileSystemError,
    GitError,
    ClaudeError,
    TimeoutError,
    APIError,
    AuthenticationError
)

# Core validation bundle
from .validation import (
    validate_service_name,
    validate_github_url,
    validate_filename,
    validate_branch_name,
    validate_email,
    validate_port,
    validate_directory,
    validate_agent_name,
    validate_temperature,
    validate_timeout,
    require_valid_service_name,
    require_valid_github_url
)

# =============================================================================
# CONFIG IMPORTS
# =============================================================================

# Configuration constants bundle
from ..config.constants import (
    # Paths
    PACKAGE_DIR,
    CONFIG_DIR,
    MICROFORGE_CONFIG,
    MICROFORGE_PROJECT_CONFIG,
    MICROFORGE_PROJECT_DIR,
    MICROFORGE_PROJECT_HOOKS_DIR,
    DOCS_DIR,
    DOCS_SERVICE_DIR,
    CLAUDE_MD_FILENAME,

    # Agent constants
    AGENTS,
    AGENT_BASE_ORCHESTRATOR,
    AGENT_DOCUMENTATION,
    AGENT_DEPENDENCY_GRAPH,
    AGENT_AUDIT_REPORT,

    # Hook constants
    HOOKS_SUBDIR,
    HOOK_PLANNING_PRE,
    HOOK_CODE_QUALITY,
    HOOK_README,

    # Error messages
    ERRORS,
    ERROR_NOT_GIT_REPO,
    ERROR_CLAUDE_CLI_NOT_FOUND,
    ERROR_SERVICE_NOT_FOUND,
    ERROR_CONFIG_INVALID,

    # Success messages
    SUCCESS,
    SUCCESS_ANALYSIS_COMPLETED,
    SUCCESS_HOOKS_INITIALIZED,
    SUCCESS_SERVICE_ADDED,

    # LLM settings
    LLM_DEFAULT_TOOLS,
    LLM_ANALYSIS_TOOLS,
    LLM_DEFAULT_TIMEOUT,
    LLM_BATCH_TIMEOUT,

    # Git settings
    GIT_DEFAULT_TIMEOUT,
    GIT_CLONE_TIMEOUT,
    GIT_TIMEOUT_SECONDS
)

from ..config.settings import (
    get_settings,
    MicroforgeSettings,
    LLMSettings,
    RegistrySettings
)

# =============================================================================
# SERVICE IMPORTS
# =============================================================================

# Base service imports
from ..services.base import (
    BaseService,
    ServiceRegistry,
    get_service_registry,
    register_service,
    get_service
)

# Service model imports for type hints
from ..services.analysis.models import (
    AnalysisRequest,
    AnalysisResult,
    AnalysisMode,
    AnalysisContext
)

from ..services.audit.models import (
    AuditRequest,
    AuditResult
)

from ..services.hooks.models import (
    HooksRequest,
    HooksConfiguration,
    HookInfo,
    HookStatus
)

from ..services.setup.models import (
    SetupRequest,
    SetupResult
)

# =============================================================================
# PROVIDER IMPORTS
# =============================================================================

# Git provider imports
from ..providers.vcs.git import GitProvider

# LLM provider imports
from ..providers.llm.manager import (
    get_llm_manager,
    LLMManager,
    run_llm_analysis
)

from ..providers.llm.base import (
    BaseLLMProvider,
    LLMProviderType,
    LLMRequest,
    LLMResponse
)

# =============================================================================
# REGISTRY IMPORTS
# =============================================================================

from ..registries.manager import (
    get_registry_manager,
    RegistryManager
)

from ..registries.models import (
    ServiceModel,
    AgentModel,
    HookModel,
    ApplicationModel
)

# =============================================================================
# THIRD-PARTY IMPORTS
# =============================================================================

# Click for CLI
import click

# Rich for console output
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

# Pydantic for data validation
from pydantic import BaseModel, Field, validator

# =============================================================================
# IMPORT BUNDLES
# =============================================================================

# Bundle for CLI commands
CLI_IMPORTS = (
    'click',
    'Path',
    'Optional',
    'console',
    'print_success',
    'print_error',
    'print_warning',
    'print_info'
)

# Bundle for services
SERVICE_IMPORTS = (
    'BaseService',
    'ValidationError',
    'ServiceError',
    'NotFoundError',
    'Path',
    'Dict',
    'Any',
    'Optional',
    'List'
)

# Bundle for registry implementations
REGISTRY_IMPORTS = (
    'BaseRegistry',
    'ValidationError',
    'NotFoundError',
    'AlreadyExistsError',
    'load_json_file',
    'save_json_file',
    'Path',
    'Dict',
    'Any',
    'Optional',
    'List'
)

# Bundle for models
MODEL_IMPORTS = (
    'BaseModel',
    'Field',
    'validator',
    'Optional',
    'List',
    'Dict',
    'Any',
    'datetime',
    'Enum'
)

# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def get_cli_imports():
    """Get standard imports for CLI commands."""
    return {
        'click': click,
        'Path': Path,
        'Optional': Optional,
        'console': console,
        'print_success': print_success,
        'print_error': print_error,
        'print_warning': print_warning,
        'print_info': print_info
    }

def get_service_imports():
    """Get standard imports for services."""
    return {
        'BaseService': BaseService,
        'ValidationError': ValidationError,
        'ServiceError': ServiceError,
        'NotFoundError': NotFoundError,
        'Path': Path,
        'Dict': Dict,
        'Any': Any,
        'Optional': Optional,
        'List': List
    }

def get_model_imports():
    """Get standard imports for models."""
    return {
        'BaseModel': BaseModel,
        'Field': Field,
        'validator': validator,
        'Optional': Optional,
        'List': List,
        'Dict': Dict,
        'Any': Any,
        'datetime': datetime,
        'Enum': Enum
    }

# =============================================================================
# IMPORT ALL
# =============================================================================

__all__ = [
    # Standard library
    'Path', 'Dict', 'Any', 'Optional', 'List', 'Tuple', 'Union', 'Set',
    'datetime', 'timedelta', 'dataclass', 'field', 'Enum',
    'json', 'os', 'sys', 'time', 'uuid', 're',

    # Core decorators
    'audit_performance', 'audit_llm',

    # Core utilities
    'console', 'print_success', 'print_error', 'print_warning', 'print_info',
    'ensure_path_exists', 'load_config_file', 'save_config_file',

    # Core exceptions
    'MicroforgeError', 'ValidationError', 'ConfigurationError', 'ServiceError',
    'NotFoundError', 'AlreadyExistsError', 'FileSystemError',

    # Core validation
    'validate_service_name', 'validate_github_url', 'validate_filename',

    # Config
    'PACKAGE_DIR', 'CONFIG_DIR', 'ERRORS', 'SUCCESS',
    'get_settings', 'MicroforgeSettings',

    # Services
    'BaseService', 'ServiceRegistry', 'get_service_registry',

    # Providers
    'GitProvider', 'get_llm_manager', 'LLMManager',

    # Registries
    'get_registry_manager', 'RegistryManager',

    # Third-party
    'click', 'Console', 'Table', 'Panel', 'BaseModel', 'Field',

    # Import bundles
    'CLI_IMPORTS', 'SERVICE_IMPORTS', 'REGISTRY_IMPORTS', 'MODEL_IMPORTS',
    'get_cli_imports', 'get_service_imports', 'get_model_imports'
]