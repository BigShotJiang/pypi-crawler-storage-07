"""Main entry point for microforge CLI."""

from .cli.main import cli

if __name__ == '__main__':
    cli()