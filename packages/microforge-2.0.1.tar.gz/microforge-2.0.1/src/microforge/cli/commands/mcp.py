"""MCP server command for Microforge v2"""

import click
import json
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax

from ...core.common import console
from ...services.mcp.service import MCPService
from ...services.mcp.models import MCPServerRequest


@click.group()
def mcp():
    """Manage Microforge MCP server"""
    pass


@mcp.command()
@click.option('--port', default=3333, help='Port to run HTTP server on')
@click.option('--host', default='127.0.0.1', help='Host to bind server to')
@click.option('--stdio', is_flag=True, help='Use stdio transport (for Claude Desktop)')
def start(port: int, host: str, stdio: bool):
    """Start the MCP server"""
    mcp_service = MCPService()

    if stdio:
        console.print("[green]Starting Microforge MCP server (stdio mode)...[/green]")
        console.print("[yellow]This server will communicate via stdio for Claude Desktop[/yellow]")

        request = MCPServerRequest(mode="stdio")

        try:
            result = mcp_service.start_stdio_server(request)
            if not result.success:
                for error in result.errors:
                    console.print(f"[red]Error: {error}[/red]")
                raise click.ClickException("Failed to start stdio server")
        except KeyboardInterrupt:
            console.print("\n[red]Server stopped by user[/red]")
        except Exception as e:
            console.print(f"[red]Error running MCP server: {e}[/red]")
            raise
    else:
        console.print(f"[green]Starting Microforge MCP HTTP server on {host}:{port}...[/green]")
        console.print("[yellow]Server running. Press Ctrl+C to stop.[/yellow]")
        console.print(f"\n[cyan]API Endpoints:[/cyan]")
        console.print(f"  • Root: http://{host}:{port}/")
        console.print(f"  • List tools: http://{host}:{port}/tools")
        console.print(f"  • Execute tool: POST http://{host}:{port}/execute")
        console.print(f"  • Health check: http://{host}:{port}/health")
        console.print(f"\n[dim]Use --stdio flag for Claude Desktop integration[/dim]")

        request = MCPServerRequest(mode="http", host=host, port=port)

        try:
            result = mcp_service.start_http_server(request)
            if not result.success:
                for error in result.errors:
                    console.print(f"[red]Error: {error}[/red]")
                raise click.ClickException("Failed to start HTTP server")
        except KeyboardInterrupt:
            console.print("\n[red]Server stopped by user[/red]")
        except Exception as e:
            console.print(f"[red]Error running HTTP server: {e}[/red]")
            raise


@mcp.command()
def config():
    """Generate Claude Desktop configuration"""

    config_json = {
        "mcpServers": {
            "microforge": {
                "command": "microforge",
                "args": ["mcp", "start", "--stdio"],
                "env": {}
            }
        }
    }

    console.print(Panel.fit(
        "[bold yellow]Claude Desktop Configuration[/bold yellow]\n\n"
        "Add this to your Claude Desktop config file:",
        border_style="yellow"
    ))

    syntax = Syntax(
        json.dumps(config_json, indent=2),
        "json",
        theme="monokai",
        line_numbers=False
    )
    console.print(syntax)

    console.print("\n[dim]Configuration file location:[/dim]")
    console.print("  [cyan]macOS:[/cyan] ~/Library/Application Support/Claude/claude_desktop_config.json")
    console.print("  [cyan]Windows:[/cyan] %APPDATA%\\Claude\\claude_desktop_config.json")
    console.print("  [cyan]Linux:[/cyan] ~/.config/Claude/claude_desktop_config.json")

    console.print("\n[green]After adding the configuration, restart Claude Desktop to use Microforge tools.[/green]")


@mcp.command(name="list")
def list_tools():
    """List available MCP tools"""
    mcp_service = MCPService()

    try:
        tools = mcp_service.list_mcp_tools()

        if not tools:
            console.print("[yellow]No agents found in registry[/yellow]")
            return

        console.print(Panel.fit(
            "[bold cyan]Available MCP Tools[/bold cyan]",
            border_style="cyan"
        ))

        for tool in tools:
            tool_name = tool["name"]
            console.print(f"\n[bold green]{tool_name}[/bold green]")
            console.print(f"  [dim]Display Name:[/dim] {tool['display_name']}")
            console.print(f"  [dim]Description:[/dim] {tool['description']}")
            console.print(f"  [dim]Status:[/dim] {'[green]Enabled[/green]' if tool['enabled'] else '[red]Disabled[/red]'}")

            if tool.get('category'):
                console.print(f"  [dim]Category:[/dim] {tool['category']}")
            if tool.get('tags'):
                console.print(f"  [dim]Tags:[/dim] {', '.join(tool['tags'])}")

    except Exception as e:
        console.print(f"[red]Error listing tools: {e}[/red]")
        raise click.ClickException("Failed to list MCP tools")


@mcp.command()
def test():
    """Test MCP server functionality"""
    mcp_service = MCPService()

    console.print("[cyan]Testing MCP Server Components...[/cyan]\n")

    try:
        test_results = mcp_service.test_mcp_functionality()

        # Test registry
        console.print("[bold]1. Testing Agent Registry[/bold]")
        if test_results["registry_test"]:
            console.print(f"  ✓ Registry loaded successfully")
            console.print(f"  ✓ Found {test_results['agent_count']} agents")
        else:
            console.print(f"  ✗ Registry test failed", style="red")

        # Test server import
        console.print("\n[bold]2. Testing MCP Server Import[/bold]")
        if test_results["server_import_test"]:
            console.print(f"  ✓ MCP server module imported successfully")
        else:
            console.print(f"  ✗ MCP import failed", style="red")
            console.print("\n[yellow]Note: You may need to install the MCP package:[/yellow]")
            console.print("  pip install mcp")

        # Show errors
        if test_results["errors"]:
            console.print("\n[bold]Errors Found:[/bold]")
            for error in test_results["errors"]:
                console.print(f"  ✗ {error}", style="red")
        else:
            console.print("\n[green]✓ All tests passed![/green]")
            console.print("\n[dim]You can now start the MCP server with:[/dim]")
            console.print("  microforge mcp start --stdio")

    except Exception as e:
        console.print(f"[red]Error during testing: {e}[/red]")
        raise click.ClickException("MCP test failed")