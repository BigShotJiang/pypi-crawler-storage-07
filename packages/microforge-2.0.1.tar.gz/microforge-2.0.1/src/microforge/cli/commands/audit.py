"""
Audit command for Microforge v2.

This is a thin CLI wrapper that delegates to the AuditService.
"""

import click
from pathlib import Path
from typing import Optional

from ...core.common import (
    console,
    print_error,
    print_success,
    print_info,
    print_warning
)
from ...services.audit.service import AuditService
from ...services.audit.models import AuditRequest


@click.command()
@click.argument('target', required=False, default='.')
@click.option('--all', 'audit_all', is_flag=True, help='Audit all registered services')
@click.option('--security-only', is_flag=True, help='Only run security audit')
@click.option('--debt-only', is_flag=True, help='Only analyze technical debt')
@click.option('--quick', is_flag=True, help='Quick audit (skip detailed analysis)')
@click.option('--format', type=click.Choice(['markdown', 'json', 'yaml']), default='markdown', help='Output format')
@click.option('--threshold', type=int, default=80, help='Health score threshold for warnings')
@click.option('--batch', is_flag=True, help='Run LLM in batch mode (non-interactive)')
def audit(
    target: str,
    audit_all: bool,
    security_only: bool,
    debt_only: bool,
    quick: bool,
    format: str,
    threshold: int,
    batch: bool
) -> None:
    """Perform comprehensive code audit for quality, security, and technical debt.

    Examples:
        microforge audit                    # Audit current directory
        microforge audit user-service       # Audit specific service
        microforge audit --all              # Audit all registered services
        microforge audit . --security-only # Security audit only
        microforge audit . --debt-only     # Technical debt analysis only
        microforge audit . --quick         # Quick audit with essential checks
    """
    try:
        # Create audit request
        request = AuditRequest(
            target=target,
            audit_all=audit_all,
            security_only=security_only,
            debt_only=debt_only,
            quick=quick,
            format=format,
            threshold=threshold,
            batch_mode=batch
        )

        # Show context that will be passed to service
        console.print("\n[bold]📋 Audit Context:[/bold]")
        context_items = [
            ("mode", "batch" if audit_all else ("local" if request.is_local else "remote")),
            ("target", target if not request.is_local else Path.cwd().name),
            ("audit_all", audit_all),
            ("security_only", security_only),
            ("debt_only", debt_only),
            ("quick", quick),
            ("format", format),
            ("threshold", threshold),
            ("repo_path", "." if request.is_local else "<to_be_cloned>"),
        ]

        for key, value in context_items:
            console.print(f"  • {key}: {value}")

        # Show expected outputs
        audit_service = AuditService()
        expected_outputs = audit_service.get_expected_outputs(request)

        console.print("\n[bold]📁 Expected Outputs:[/bold]")
        for output in expected_outputs:
            console.print(f"  • {output}")

        # Show alert thresholds
        console.print("\n[bold]⚠️ Alert Thresholds:[/bold]")
        console.print(f"  • Health score < {threshold}: Warning")
        console.print("  • Critical security issues: Immediate alert")
        console.print("  • High priority debt: Action required")

        print_info("✅ Ready for AI audit execution")
        console.print("[dim]The audit agent will analyze code quality and security[/dim]")

        if request.is_local:
            print_warning("\nNote: Audit results will NOT be auto-committed")
            console.print("[dim]Review results in: docs/audit/[/dim]")

        # Execute audit
        result = audit_service.audit(request)

        if result.success:
            # Show execution time
            execution_time = result.execution_time_ms / 1000
            console.print(f"[dim]Completed in {execution_time:.2f} seconds[/dim]")

            # Show warnings if any
            if result.warnings:
                for warning in result.warnings:
                    print_warning(f"⚠️ {warning}")

        else:
            print_error("Audit failed")
            for error in result.errors:
                print_error(f"  {error}")

    except Exception as e:
        print_error(f"Audit command failed: {str(e)}")
        raise click.ClickException(str(e))