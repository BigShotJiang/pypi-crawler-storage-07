"""
Analyze command for comprehensive service analysis using v2 architecture.

This is a thin CLI wrapper that delegates to the AnalysisService.
"""

import click
from pathlib import Path

from typing import Optional
from ...core.common import (
    console,
    print_error,
    print_success,
    print_warning,
    print_info
)
from ...services.analysis.service import AnalysisService
from ...services.analysis.models import AnalysisRequest


@click.command()
@click.argument('target', required=False, default='.')
@click.option('--all', 'analyze_all', is_flag=True, help='Analyze all registered services')
@click.option('--docs-only', is_flag=True, help='Only generate documentation')
@click.option('--deps-only', is_flag=True, help='Only generate dependency graphs')
@click.option('--force', is_flag=True, help='Force regeneration even if up to date')
@click.option('--batch', is_flag=True, help='Run LLM in batch mode (non-interactive)')
def analyze(target: str, analyze_all: bool, docs_only: bool, deps_only: bool,
           force: bool, batch: bool) -> None:
    """
    Analyze services to generate documentation and dependency graphs.

    Examples:
        microforge analyze                  # Analyze current directory
        microforge analyze user-service      # Analyze specific service
        microforge analyze --all             # Analyze all registered services
        microforge analyze . --docs-only    # Only generate documentation locally
        microforge analyze . --deps-only    # Only generate dependencies locally
    """
    try:
        # Check if agent files exist (like old version)
        from ...config.constants import PACKAGE_DIR, AGENTS_SUBDIR
        agents_dir = PACKAGE_DIR / AGENTS_SUBDIR
        orchestrator_file = agents_dir / "base_orchestrator.md"
        doc_agent_file = agents_dir / "documentation.md"
        deps_agent_file = agents_dir / "dependency_graph.md"

        missing_agents = []
        if not orchestrator_file.exists():
            missing_agents.append("base_orchestrator.md")
        if not docs_only and not doc_agent_file.exists():
            missing_agents.append("documentation.md")
        if not deps_only and not deps_agent_file.exists():
            missing_agents.append("dependency_graph.md")

        if missing_agents:
            print_error(f"Missing agent files: {', '.join(missing_agents)}")
            print_info(f"Expected in: {agents_dir}")
            return

        # Display operation mode (like old version)
        if analyze_all:
            console.print("[bold cyan]📊 Analyzing all registered services[/bold cyan]\n")
        elif target == ".":
            from ...providers.vcs.git import is_git_repository
            if not is_git_repository():
                print_error("Current directory is not a git repository")
                print_warning("Initialize with: git init")
                return
            service_name = Path.cwd().name
            console.print(f"[bold cyan]🔍 Analyzing current directory: {service_name}[/bold cyan]\n")
        else:
            console.print(f"[bold cyan]🔍 Analyzing service: {target}[/bold cyan]\n")

        # Show what will be generated (like old version)
        if docs_only:
            print_warning("📚 Generating: Documentation only")
        elif deps_only:
            print_warning("🔗 Generating: Dependency graphs only")
        else:
            print_warning("📚 Generating: Documentation and dependency graphs")

        if force:
            print_warning("⚠️  Force mode: Regenerating even if up to date")

        # Display agent workflow (like old version)
        console.print("\n[bold]🤖 AI Agent Workflow:[/bold]")
        console.print("1. Base orchestrator handles repository access")

        if not deps_only:
            console.print("2. Documentation agent generates comprehensive docs")
        if not docs_only:
            console.print("3. Dependency graph agent analyzes dependencies")

        # Show execution mode
        mode = "batch" if analyze_all else ("local" if target == "." else "remote")
        if mode == "local":
            console.print("4. Results saved locally (no auto-commit)")
        elif mode == "remote":
            console.print("4. Create branch and push to remote")
            console.print("5. Generate PR for review")
        elif mode == "batch":
            console.print("4. Process each service sequentially")
            console.print("5. Provide summary report")

        # Show context that will be passed to agents (like old version)
        console.print("\n[bold]📋 Agent Context:[/bold]")
        context_display = {
            "mode": mode,
            "target": target if target != "." else Path.cwd().name,
            "analyze_all": analyze_all,
            "docs_only": docs_only,
            "deps_only": deps_only,
            "force": force,
            "repo_path": "." if target == "." else "<to_be_cloned>",
        }

        for key, value in context_display.items():
            console.print(f"  • {key}: {value}")

        # Create analysis request from CLI arguments
        request = AnalysisRequest.from_cli_args(
            target=target,
            analyze_all=analyze_all,
            docs_only=docs_only,
            deps_only=deps_only,
            force=force,
            batch=batch
        )

        # Get analysis service
        analysis_service = AnalysisService()

        # Execute analysis
        result = analysis_service.analyze(request)

        # Handle result
        if result.success:
            if result.is_batch:
                print_success(f"Batch analysis completed: {result.successful_services}/{result.total_services} services analyzed successfully")
            else:
                print_success(f"Analysis completed for {result.service_name}")

                if result.mode.value == "local":
                    print_warning("Note: Changes saved locally. Review with: git status")
        else:
            print_error(f"Analysis failed: {result.error_message or 'Unknown error'}")
            raise click.ClickException("Analysis failed")

    except Exception as e:
        print_error(f"Analysis command failed: {str(e)}")
        raise click.ClickException(str(e))