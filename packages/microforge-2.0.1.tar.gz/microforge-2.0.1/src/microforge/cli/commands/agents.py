"""
Agents command for Microforge v2.

Thin CLI wrapper for agent management operations.
"""

import click
from pathlib import Path
from typing import Optional

from ...core.common import console, print_error, print_success, print_info, print_warning
from ...services.agents.service import AgentsService
from ...services.agents.models import AgentExecutionRequest
from ...services.agents.discovery import ServiceDiscovery


@click.group()
def agents():
    """Manage Microforge agents and prompts."""
    pass


@click.command()
@click.option('--service', help='Service name to filter agents')
@click.option('--storage', is_flag=True, help='List from storage instead of registry')
@click.option('--verbose', '-v', is_flag=True, help='Show full descriptions')
def list(service: Optional[str], storage: bool, verbose: bool):
    """List available agents."""
    try:
        from rich.table import Table
        from rich import box

        agents_service = AgentsService()

        if storage:
            agents = agents_service.list_storage_agents(service=service)
            title = f"[bold cyan]Storage Agents[/bold cyan] [yellow]({len(agents)} found)[/yellow]"
        elif service:
            agents = agents_service.list_agents_by_service(service)
            title = f"[bold cyan]Service Agents for '{service}'[/bold cyan] [yellow]({len(agents)} found)[/yellow]"
        else:
            agents = agents_service.list_available_agents()
            title = f"[bold cyan]Available Agents[/bold cyan] [yellow]({len(agents)} found)[/yellow]"

        # Create table with borders
        table = Table(
            title=title,
            show_header=True,
            header_style="bold white on blue",
            box=box.ROUNDED,
            border_style="bright_blue"
        )
        table.add_column("Agent ID", style="bold green", no_wrap=True, width=42)
        table.add_column("Type", style="cyan", width=20, justify="center")
        table.add_column("Status", style="bold", justify="center", width=8)

        if verbose:
            table.add_column("Description", style="white", width=60)

        # Sort agents: global first, then by service
        def sort_key(agent):
            svc = agent.get('service', None)
            if svc is None:
                return (0, agent.get('name', ''))
            return (1, svc, agent.get('name', ''))

        sorted_agents = sorted(agents, key=sort_key)

        # Add rows
        for agent in sorted_agents:
            name = agent.get('name', 'N/A')
            service_name = agent.get('service')
            enabled = agent.get('enabled', True)

            # Format status with color
            if enabled:
                status_str = "[bold green]✓[/bold green]"
            else:
                status_str = "[bold red]✗[/bold red]"

            # Format type column with color
            if service_name:
                type_str = f"[yellow]{service_name}[/yellow]"
            else:
                type_str = "[bold magenta]Global[/bold magenta]"

            if verbose:
                description = agent.get('description', 'No description')
                # Truncate very long descriptions even in verbose mode
                if len(description) > 60:
                    description = description[:57] + "..."
                table.add_row(name, type_str, status_str, description)
            else:
                table.add_row(name, type_str, status_str)

        console.print("\n")
        console.print(table)
        console.print("\n")

        if not verbose:
            console.print("[dim italic]💡 Tip: Use --verbose or -v to show descriptions[/dim italic]\n")

    except Exception as e:
        print_error(f"Failed to list agents: {e}")
        raise click.ClickException(str(e))


@click.command()
@click.argument('agent_name')
@click.option('--service', help='Service name for service-specific agents')
def info(agent_name: str, service: Optional[str]):
    """Get agent information."""
    try:
        agents_service = AgentsService()
        agent_info = agents_service.get_agent_info(agent_name, service=service)

        if not agent_info:
            print_error(f"Agent '{agent_name}' not found")
            return

        console.print(f"\n[bold cyan]{agent_info['display_name']}[/bold cyan]")
        console.print(f"ID: {agent_info['name']}")
        console.print(f"Service: {agent_info.get('service') or 'Global'}")
        console.print(f"Enabled: {agent_info['enabled']}")

    except Exception as e:
        print_error(f"Failed to get agent info: {e}")
        raise click.ClickException(str(e))


@click.command()
@click.argument('agent_name')
@click.option('--service', help='Service name for service-specific agents')
@click.option('--output', '-o', type=click.Path(), help='Output file')
def get(agent_name: str, service: Optional[str], output: Optional[str]):
    """Get agent prompt."""
    try:
        agents_service = AgentsService()
        prompt = agents_service.download_agent_prompt(agent_name, service=service)

        if not prompt:
            print_error(f"Agent prompt not found: {agent_name}")
            return

        if output:
            Path(output).write_text(prompt)
            print_success(f"Saved to {output}")
        else:
            console.print(prompt)

    except Exception as e:
        print_error(f"Failed to get agent: {e}")
        raise click.ClickException(str(e))


@click.command()
@click.argument('agent_name')
@click.argument('prompt_file', type=click.Path(exists=True))
@click.option('--service', help='Service name for service-specific agents')
@click.option('--overwrite', is_flag=True, help='Overwrite existing')
def upload(agent_name: str, prompt_file: str, service: Optional[str], overwrite: bool):
    """Upload agent prompt."""
    try:
        agents_service = AgentsService()
        content = Path(prompt_file).read_text()

        success = agents_service.upload_agent_prompt(
            agent_name, content, service=service, overwrite=overwrite
        )

        if success:
            print_success(f"Uploaded agent '{agent_name}'")

    except Exception as e:
        print_error(f"Failed to upload: {e}")
        raise click.ClickException(str(e))


@click.command()
@click.argument('agent_name')
@click.option('--service', help='Service name for service-specific agents')
@click.option('--yes', is_flag=True, help='Skip confirmation')
def delete(agent_name: str, service: Optional[str], yes: bool):
    """Delete agent prompt."""
    try:
        if not yes:
            click.confirm(f"Delete agent '{agent_name}'?", abort=True)

        agents_service = AgentsService()
        success = agents_service.delete_agent_prompt(agent_name, service=service)

        if success:
            print_success(f"Deleted agent '{agent_name}'")

    except Exception as e:
        print_error(f"Failed to delete: {e}")
        raise click.ClickException(str(e))


@click.command()
@click.option('--service', help='Service name for service-specific sync')
@click.option('--direction', type=click.Choice(['download', 'upload']),
              default='download', help='Sync direction')
def sync(service: Optional[str], direction: str):
    """Sync agents with storage."""
    try:
        agents_service = AgentsService()
        result = agents_service.sync_agents(direction=direction, service=service)

        console.print(f"[bold cyan]Sync Results:[/bold cyan]")
        console.print(f"Total: {result.get('total', 0)}")
        console.print(f"Synced: {len(result.get('synced', []))}")
        console.print(f"Failed: {len(result.get('failed', []))}")

    except Exception as e:
        print_error(f"Sync failed: {e}")
        raise click.ClickException(str(e))


@click.command()
@click.argument('agent_name')
@click.option('--service', help='Service name from registry (will pull and work in service repo)')
@click.option('--branch', help='Git branch to create and push changes to')
@click.option('--global-agent', is_flag=True, help='Run as global agent (no repo required)')
@click.option('--interactive/--no-interactive', default=True, help='Run Claude interactively (default: true)')
def run(agent_name: str, service: Optional[str], branch: Optional[str], global_agent: bool, interactive: bool):
    """Run a specific agent with Claude.

    This command executes an agent template through Claude AI with proper context.

    Examples:
        microforge agents run implementation --branch feature/new-auth --service user-service
        microforge agents run documentation --branch docs/api-update  # Local repo
        microforge agents run security --global-agent  # Global agent, no repo needed
    """
    try:
        from ...services.agents.models import AgentRunRequest

        # Create request model
        request = AgentRunRequest(
            agent_name=agent_name,
            service=service,
            branch=branch,
            global_agent=global_agent,
            interactive=interactive
        )

        # Execute through service
        agents_service = AgentsService()
        result = agents_service.run_agent(request)

        # Display results
        if result.success:
            if result.execution_time_ms:
                execution_time = result.execution_time_ms / 1000
                print_success(f"Agent completed in {execution_time:.2f} seconds")

            if hasattr(result, 'branch_created') and result.branch_created:
                print_success(f"Changes pushed to branch: {result.branch_created}")

            if result.warnings:
                for warning in result.warnings:
                    print_warning(warning)
        else:
            print_error("Agent run failed")
            if result.errors:
                for error in result.errors:
                    print_error(f"  {error}")

    except Exception as e:
        print_error(f"Failed to run agent: {e}")
        raise click.ClickException(str(e))


@click.command()
@click.option('--service', help='Service name from registry')
@click.option('--commits', default=200, help='Number of commits to analyze')
@click.option('--output-dir', default='./discovered-agents', help='Output directory for agents')
@click.option('--interactive/--no-interactive', default=True, help='Run Claude interactively')
def discover(service: Optional[str], commits: int, output_dir: str, interactive: bool):
    """Discover service-specific agents using Claude to analyze commit history."""
    try:
        from ...services.agents.models import AgentExecutionRequest

        print_info("📊 Collecting git history for analysis...")

        # Initialize discovery service
        discovery = ServiceDiscovery()

        # Collect git history
        result = discovery.discover_agents(
            service_name=service,
            commit_limit=commits,
            output_dir=output_dir
        )

        # Display collection results
        console.print(f"\n[bold cyan]Git History Analysis:[/bold cyan]")
        console.print(f"Service: [green]{result['service_name']}[/green]")
        console.print(f"Commits analyzed: [yellow]{result['commits_analyzed']}[/yellow]")
        console.print(f"Files tracked: [yellow]{result['files_tracked']}[/yellow]")
        console.print(f"Output directory: [cyan]{result['output_path']}[/cyan]")

        # Prepare the discovery prompt with git data
        prompt_file = discovery.prepare_discovery_prompt(result)

        # Execute through agents service
        print_info("\n🤖 Running service discovery agent with Claude...")

        # Create execution request
        execution_request = AgentExecutionRequest(
            agent_name="service_discovery",
            agent_file=str(prompt_file),
            service_name=result['service_name'],
            output_dir=Path(result['output_path']),
            mode="local",
            interactive=interactive
        )

        # Execute the agent
        agents_service = AgentsService()
        exec_result = agents_service.execute_agent(execution_request)

        if exec_result.success:
            print_success("\n✅ Agent discovery completed successfully!")

            if exec_result.output_files:
                console.print(f"\n[bold green]Generated agents:[/bold green]")
                for file in exec_result.output_files:
                    console.print(f"  • {file}")

            # Show upload instructions
            console.print(f"\n[bold]To upload generated agents:[/bold]")
            console.print(f"  microforge agents upload implementation {result['output_path']}/implementation.md --service {result['service_name']}")

            # List other potential agents
            for agent_file in Path(result['output_path']).glob('*.md'):
                if agent_file.name != 'implementation.md' and agent_file.name != 'discovery_prompt.md':
                    agent_name = agent_file.stem
                    console.print(f"  microforge agents upload {agent_name} {agent_file} --service {result['service_name']}")
        else:
            print_error("Discovery failed")
            if exec_result.errors:
                for error in exec_result.errors:
                    print_error(f"  {error}")

    except Exception as e:
        print_error(f"Failed to discover agents: {e}")
        raise click.ClickException(str(e))


# Add subcommands
agents.add_command(list)
agents.add_command(info)
agents.add_command(get)
agents.add_command(upload)
agents.add_command(delete)
agents.add_command(sync)
agents.add_command(run)
agents.add_command(discover)