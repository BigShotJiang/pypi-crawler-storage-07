"""
Workflow management commands for Microforge v2.

Execute and manage multi-agent workflows using LangGraph orchestration.
"""

import click
import asyncio
import json
from rich.table import Table
from pathlib import Path

from ...core.common import (
    console,
    print_error,
    print_success,
    print_info,
    print_warning
)
from ...workflows.executor import WorkflowExecutor
from ...registries.manager import get_registry_manager
from ...core.exceptions import WorkflowError, NotFoundError


@click.group()
def workflow():
    """Manage and execute multi-agent workflows with LangGraph."""
    pass


@workflow.command()
@click.argument('workflow_name')
@click.option('--input', '-i', multiple=True, help='Input parameters as key=value pairs')
@click.option('--dry-run', is_flag=True, help='Show workflow plan without executing')
@click.option('--watch', is_flag=True, help='Watch agent execution in real-time')
def run(workflow_name: str, input: tuple, dry_run: bool, watch: bool) -> None:
    """Execute a workflow by name.

    Example:
        microforge workflow run issue_resolver --input issue_id=123 --input repo_path=.
    """
    try:
        # Parse input parameters
        inputs = {}
        for param in input:
            if '=' not in param:
                print_error(f"Invalid input format: {param}. Use key=value format.")
                raise click.ClickException("Invalid input format")
            key, value = param.split('=', 1)
            # Try to parse as JSON for complex types
            try:
                inputs[key] = json.loads(value)
            except json.JSONDecodeError:
                inputs[key] = value

        # Get workflow from registry
        registry = get_registry_manager()
        workflow_model = registry.workflows.get_workflow(workflow_name)

        if not workflow_model:
            print_error(f"Workflow '{workflow_name}' not found")
            raise click.ClickException("Workflow not found")

        if not workflow_model.enabled:
            print_warning(f"Workflow '{workflow_name}' is disabled")
            if not click.confirm("Continue anyway?"):
                return

        # Display workflow information
        console.print(f"\n[bold cyan]📋 Workflow: {workflow_model.display_name}[/bold cyan]")
        console.print(f"[dim]{workflow_model.description}[/dim]")
        console.print(f"Steps: {len(workflow_model.steps)}")

        if dry_run:
            # Show workflow plan
            console.print("\n[yellow]Dry run mode - Workflow plan:[/yellow]")
            for i, step in enumerate(workflow_model.steps, 1):
                console.print(f"{i}. [{step.type}] {step.id}")
                if step.agent:
                    console.print(f"   Agent: {step.agent}")
                if step.agents:
                    console.print(f"   Agents: {', '.join(step.agents)}")
                if step.depends_on:
                    console.print(f"   Depends on: {', '.join(step.depends_on)}")
            return

        # Get confirmation
        console.print(f"\n[bold]Inputs:[/bold]")
        for key, value in inputs.items():
            console.print(f"  • {key}: {value}")

        if not click.confirm("\n🚀 Execute workflow?"):
            return

        # Execute workflow
        executor = WorkflowExecutor()

        if watch:
            # TODO: Add real-time execution watching
            console.print("[dim]Watching execution...[/dim]")

        # Run async execution
        result = asyncio.run(
            executor.execute_workflow(workflow_name, inputs)
        )

        # Display results
        if result["status"] == "completed":
            print_success(f"✅ Workflow completed successfully")
        else:
            print_error(f"❌ Workflow failed")

        # Show outputs
        if result.get("outputs"):
            console.print("\n[bold]Outputs:[/bold]")
            for node_id, output in result["outputs"].items():
                console.print(f"  • {node_id}: {output}")

        # Show generated artifacts
        if result.get("artifacts"):
            console.print("\n[bold]Generated Artifacts:[/bold]")
            for name, path in result["artifacts"].items():
                console.print(f"  • {name}: {path}")

    except WorkflowError as e:
        print_error(f"Workflow error: {e.message}")
        raise click.ClickException("Workflow execution failed")
    except Exception as e:
        print_error(f"Unexpected error: {str(e)}")
        raise click.ClickException(str(e))


@workflow.command()
@click.option('--enabled-only', is_flag=True, help='Show only enabled workflows')
@click.option('--category', help='Filter by category')
@click.option('--tag', help='Filter by tag')
@click.option('--format', 'output_format', type=click.Choice(['table', 'json']), default='table', help='Output format')
def list(enabled_only: bool, category: str, tag: str, output_format: str) -> None:
    """List available workflows."""
    try:
        registry = get_registry_manager()

        # Get workflows based on filters
        if category:
            workflows = registry.workflows.get_workflows_by_category(category)
        elif tag:
            workflows = registry.workflows.get_workflows_by_tag(tag)
        else:
            workflows = registry.workflows.list_workflows(enabled_only=enabled_only)

        if not workflows:
            print_info("No workflows found")
            return

        if output_format == 'json':
            # JSON output
            workflows_data = [
                {
                    "id": w.id,
                    "display_name": w.display_name,
                    "description": w.description,
                    "category": w.category,
                    "tags": w.tags,
                    "steps": len(w.steps),
                    "enabled": w.enabled,
                    "version": w.version
                }
                for w in workflows
            ]
            console.print(json.dumps(workflows_data, indent=2))
        else:
            # Table output
            table = Table(title="Available Workflows")
            table.add_column("ID", style="cyan")
            table.add_column("Name", style="green")
            table.add_column("Category")
            table.add_column("Steps", justify="right")
            table.add_column("Tags")
            table.add_column("Enabled", justify="center")

            for workflow in workflows:
                tags_str = ", ".join(workflow.tags[:3])
                if len(workflow.tags) > 3:
                    tags_str += "..."

                table.add_row(
                    workflow.id,
                    workflow.display_name,
                    workflow.category,
                    str(len(workflow.steps)),
                    tags_str,
                    "✓" if workflow.enabled else "✗"
                )

            console.print(table)
            console.print(f"\nTotal workflows: {len(workflows)}")

    except Exception as e:
        print_error(f"Failed to list workflows: {str(e)}")
        raise click.ClickException(str(e))


@workflow.command()
@click.argument('workflow_name')
@click.option('--validate', is_flag=True, help='Validate workflow structure')
def show(workflow_name: str, validate: bool) -> None:
    """Show detailed information about a workflow."""
    try:
        registry = get_registry_manager()
        workflow_model = registry.workflows.get_workflow(workflow_name)

        if not workflow_model:
            print_error(f"Workflow '{workflow_name}' not found")
            raise click.ClickException("Workflow not found")

        # Display workflow details
        console.print(f"\n[bold cyan]📋 {workflow_model.display_name}[/bold cyan]")
        console.print(f"ID: {workflow_model.id}")
        console.print(f"Version: {workflow_model.version}")
        console.print(f"Category: {workflow_model.category}")
        console.print(f"Tags: {', '.join(workflow_model.tags)}")
        console.print(f"Enabled: {'Yes' if workflow_model.enabled else 'No'}")
        console.print(f"\n[dim]{workflow_model.description}[/dim]")

        # Display workflow steps
        console.print(f"\n[bold]Workflow Steps ({len(workflow_model.steps)}):[/bold]")
        for i, step in enumerate(workflow_model.steps, 1):
            console.print(f"\n{i}. [bold]{step.id}[/bold]")
            console.print(f"   Type: {step.type}")

            if step.agent:
                console.print(f"   Agent: {step.agent}")
            if step.agents:
                console.print(f"   Agents: {', '.join(step.agents)}")
            if step.service:
                console.print(f"   Service: {step.service}")
            if step.description:
                console.print(f"   Description: {step.description}")
            if step.depends_on:
                console.print(f"   Dependencies: {', '.join(step.depends_on)}")
            if step.context_from:
                console.print(f"   Context from: {', '.join(step.context_from)}")

        # Display input/output schema
        if workflow_model.input_schema:
            console.print(f"\n[bold]Input Schema:[/bold]")
            console.print(json.dumps(workflow_model.input_schema, indent=2))

        if workflow_model.output_schema:
            console.print(f"\n[bold]Output Schema:[/bold]")
            console.print(json.dumps(workflow_model.output_schema, indent=2))

        # Display execution configuration
        console.print(f"\n[bold]Execution Configuration:[/bold]")
        console.print(f"  • Checkpointing: {'Enabled' if workflow_model.checkpointing else 'Disabled'}")
        console.print(f"  • Parallel execution: {'Enabled' if workflow_model.parallel_execution else 'Disabled'}")
        if workflow_model.timeout_seconds:
            console.print(f"  • Timeout: {workflow_model.timeout_seconds}s")
        if workflow_model.retry_on_failure:
            console.print(f"  • Retry on failure: Yes (max {workflow_model.max_retries} retries)")

        # Validate if requested
        if validate:
            console.print("\n[bold]Validating workflow...[/bold]")
            validation = registry.workflows.validate_workflow_graph(workflow_name)

            if validation["valid"]:
                print_success("✅ Workflow structure is valid")
            else:
                print_error("❌ Workflow has validation issues:")
                for issue in validation["issues"]:
                    console.print(f"  • {issue}")

            if validation["warnings"]:
                print_warning("⚠️ Warnings:")
                for warning in validation["warnings"]:
                    console.print(f"  • {warning}")

    except Exception as e:
        print_error(f"Failed to show workflow: {str(e)}")
        raise click.ClickException(str(e))


@workflow.command()
@click.argument('task_description')
@click.option('--services', '-s', multiple=True, help='Limit to specific services')
@click.option('--dry-run', is_flag=True, help='Show generated workflow without executing')
def execute(task_description: str, services: tuple, dry_run: bool) -> None:
    """Execute a dynamically generated workflow from task description.

    This command analyzes the task and generates an appropriate workflow
    using planning and architect agents.

    Example:
        microforge workflow execute "Add authentication to all API endpoints" --services auth-service --services user-service
    """
    try:
        console.print("\n[bold cyan]🧠 Dynamic Workflow Execution[/bold cyan]")
        console.print(f"Task: {task_description}")

        if services:
            console.print(f"Services: {', '.join(services)}")

        executor = WorkflowExecutor()

        if dry_run:
            console.print("\n[yellow]Dry run mode - Generating workflow plan...[/yellow]")
            # TODO: Implement planning without execution
            print_info("Dynamic workflow generation in dry-run mode coming soon")
            return

        # Get confirmation
        if not click.confirm("\n🚀 Generate and execute workflow?"):
            return

        # Execute dynamic workflow
        result = asyncio.run(
            executor.execute_dynamic_workflow(task_description, list(services) if services else None)
        )

        # Display results
        if result["status"] == "completed":
            print_success(f"✅ Dynamic workflow completed successfully")
        else:
            print_error(f"❌ Dynamic workflow failed")

    except Exception as e:
        print_error(f"Failed to execute dynamic workflow: {str(e)}")
        raise click.ClickException(str(e))


@workflow.command()
@click.argument('workflow_name')
def validate(workflow_name: str) -> None:
    """Validate a workflow's structure and dependencies."""
    try:
        registry = get_registry_manager()

        console.print(f"\n[bold]Validating workflow: {workflow_name}[/bold]")
        validation = registry.workflows.validate_workflow_graph(workflow_name)

        if validation["valid"]:
            print_success("✅ Workflow is valid and ready to execute")
        else:
            print_error("❌ Workflow has validation issues:")
            for issue in validation["issues"]:
                console.print(f"  • [red]{issue}[/red]")

        if validation["warnings"]:
            print_warning("⚠️ Warnings:")
            for warning in validation["warnings"]:
                console.print(f"  • [yellow]{warning}[/yellow]")

    except NotFoundError:
        print_error(f"Workflow '{workflow_name}' not found")
        raise click.ClickException("Workflow not found")
    except Exception as e:
        print_error(f"Validation failed: {str(e)}")
        raise click.ClickException(str(e))