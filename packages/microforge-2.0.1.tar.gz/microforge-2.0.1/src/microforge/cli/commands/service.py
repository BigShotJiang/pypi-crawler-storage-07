"""
Service registry management commands for Microforge v2.

This is a thin CLI wrapper that delegates to the ServiceRegistry.
"""

import click
from rich.table import Table
from pathlib import Path
from datetime import datetime

from ...core.common import (
    console,
    print_error,
    print_success,
    print_info,
    print_warning
)
from ...registries.manager import get_registry_manager
from ...core.exceptions import ValidationError, NotFoundError


@click.group()
def service():
    """Manage service registry."""
    pass


@service.command()
@click.argument('name')
@click.argument('repo_url')
@click.option('--branch', default='main', help='Git branch to use')
@click.option('--description', default='', help='Service description')
@click.option('--impl-agent', default='implementation', help='Implementation agent to use')
@click.option('--app', 'application', help='Application this service belongs to')
def add(name: str, repo_url: str, branch: str, description: str, impl_agent: str, application: str = None) -> None:
    """Register a new service."""
    try:
        registry = get_registry_manager()

        # Check if service already exists
        if registry.services.exists(name):
            print_error(f"Service '{name}' already exists.")
            raise click.ClickException("Service already exists")

        # Validate application if specified
        if application and not registry.applications.get_application(application):
            print_error(f"Application '{application}' not found. Create it first with 'microforge app add {application}'")
            raise click.ClickException("Application not found")

        # Add service
        success = registry.services.add_service(
            name=name,
            repo_url=repo_url,
            branch=branch,
            description=description,
            implementation_agent=impl_agent,
            application=application
        )

        if success:
            print_success(f"✅ Service '{name}' registered successfully")
            if application:
                console.print(f"   Application: {application}")
            console.print(f"   Repository: {repo_url}")
            console.print(f"   Branch: {branch}")
            console.print(f"   Agent: {impl_agent}")
            if description:
                console.print(f"   Description: {description}")
        else:
            print_error("Failed to register service")
            raise click.ClickException("Service registration failed")

    except ValidationError as e:
        print_error(f"Validation error: {e.message}")
        raise click.ClickException(str(e))
    except Exception as e:
        print_error(f"Failed to add service: {str(e)}")
        raise click.ClickException(str(e))


@service.command()
@click.option('--app', 'application', help='Filter by application')
@click.option('--format', 'output_format', type=click.Choice(['table', 'json']), default='table', help='Output format')
def list(application: str = None, output_format: str = 'table') -> None:
    """List registered services."""
    try:
        registry = get_registry_manager()

        # Get services
        if application:
            services = registry.services.list_services_by_application(application)
            if not services:
                print_info(f"No services found for application '{application}'")
                return
        else:
            services = registry.services.list_services()
            if not services:
                print_info("No services registered")
                print_info("Register a service with: microforge service add <name> <repo-url>")
                return

        if output_format == 'json':
            import json
            service_data = [
                {
                    'name': s.name,
                    'repo_url': s.repo_url,
                    'branch': s.branch,
                    'description': s.description,
                    'application': s.application,
                    'implementation_agent': s.impl_agent,
                    'enabled': s.enabled,
                    'created_at': s.created_at
                }
                for s in services
            ]
            console.print(json.dumps(service_data, indent=2))
        else:
            # Display as table
            title = f"Services in '{application}'" if application else "Registered Services"
            table = Table(title=title)
            table.add_column("Name", style="cyan")
            table.add_column("Application", style="magenta")
            table.add_column("Repository", style="blue")
            table.add_column("Branch", style="green")
            table.add_column("Agent", style="yellow")
            table.add_column("Status", style="green")
            table.add_column("Last Analyzed", style="dim")

            enabled_count = 0
            analyzed_count = 0

            for service in services:
                status = "✅ Active" if service.enabled else "❌ Disabled"
                app_name = service.application or "-"

                # Truncate long repo URLs for better readability
                repo_display = service.repo_url[:40] + "..." if len(service.repo_url) > 40 else service.repo_url

                # Handle last analyzed (placeholder for now since the model doesn't include this field)
                last_analyzed = getattr(service, 'last_analyzed', None) or "Never"
                if last_analyzed and last_analyzed != "Never":
                    last_analyzed = last_analyzed[:19]  # Show only date/time part
                    analyzed_count += 1

                if service.enabled:
                    enabled_count += 1

                table.add_row(
                    service.name,
                    app_name,
                    repo_display,
                    service.branch,
                    service.impl_agent,
                    status,
                    last_analyzed
                )

            console.print(table)

            # Show detailed summary
            disabled_count = len(services) - enabled_count
            pending_analysis = len(services) - analyzed_count

            console.print(f"\n[dim]Total: {len(services)} | Enabled: {enabled_count} | Analyzed: {analyzed_count}[/dim]")

    except Exception as e:
        print_error(f"Failed to list services: {str(e)}")
        raise click.ClickException(str(e))


@service.command()
@click.argument('name')
def show(name: str) -> None:
    """Show details for a specific service."""
    try:
        registry = get_registry_manager()
        service = registry.services.get_service(name)

        if not service:
            print_error(f"Service '{name}' not found")
            raise click.ClickException("Service not found")

        # Display service details
        console.print(f"\n[bold cyan]🚀 Service: {service.name}[/bold cyan]")
        console.print(f"Repository: {service.repo_url}")
        console.print(f"Branch: {service.branch}")
        console.print(f"Description: {service.description or 'No description'}")
        console.print(f"Application: {service.application or 'None'}")
        console.print(f"Implementation Agent: {service.impl_agent}")
        console.print(f"Status: {'✅ Active' if service.enabled else '❌ Disabled'}")
        if service.created_at:
            console.print(f"Created: {service.created_at}")

    except Exception as e:
        print_error(f"Failed to show service: {str(e)}")
        raise click.ClickException(str(e))


@service.command()
@click.argument('name')
@click.option('--repo-url', help='Update repository URL')
@click.option('--branch', help='Update git branch')
@click.option('--description', help='Update description')
@click.option('--impl-agent', help='Update implementation agent')
@click.option('--app', 'application', help='Update application')
@click.option('--enable/--disable', default=None, help='Enable or disable service')
def update(name: str, repo_url: str = None, branch: str = None, description: str = None,
          impl_agent: str = None, application: str = None, enable: bool = None) -> None:
    """Update an existing service."""
    try:
        registry = get_registry_manager()

        # Check if service exists
        if not registry.services.exists(name):
            print_error(f"Service '{name}' not found")
            raise click.ClickException("Service not found")

        # Validate application if specified
        if application and not registry.applications.get_application(application):
            print_error(f"Application '{application}' not found")
            raise click.ClickException("Application not found")

        # Update service
        success = registry.services.update_service(
            name=name,
            repo_url=repo_url,
            branch=branch,
            description=description,
            implementation_agent=impl_agent,
            application=application,
            enabled=enable
        )

        if success:
            print_success(f"✅ Service '{name}' updated successfully")

            # Show what was updated
            updates = []
            if repo_url:
                updates.append(f"Repository: {repo_url}")
            if branch:
                updates.append(f"Branch: {branch}")
            if description is not None:
                updates.append(f"Description: {description}")
            if impl_agent:
                updates.append(f"Implementation agent: {impl_agent}")
            if application is not None:
                updates.append(f"Application: {application}")
            if enable is not None:
                updates.append(f"Status: {'Enabled' if enable else 'Disabled'}")

            for update in updates:
                print_info(f"   {update}")
        else:
            print_error("Failed to update service")
            raise click.ClickException("Service update failed")

    except ValidationError as e:
        print_error(f"Validation error: {e.message}")
        raise click.ClickException(str(e))
    except Exception as e:
        print_error(f"Failed to update service: {str(e)}")
        raise click.ClickException(str(e))


@service.command()
@click.argument('name')
@click.option('--force', is_flag=True, help='Force removal without confirmation')
def remove(name: str, force: bool = False) -> None:
    """Remove a service from the registry."""
    try:
        registry = get_registry_manager()

        # Check if service exists
        service = registry.services.get_service(name)
        if not service:
            print_error(f"Service '{name}' not found")
            raise click.ClickException("Service not found")

        # Confirm removal unless forced
        if not force:
            print_warning(f"\n⚠️ This will remove service '{name}' from the registry")
            console.print(f"Repository: {service.repo_url}")
            console.print(f"Application: {service.application or 'None'}")

            if not click.confirm("Are you sure you want to remove this service?"):
                print_info("Operation cancelled")
                return

        # Remove service
        success = registry.services.remove_service(name)

        if success:
            print_success(f"✅ Service '{name}' removed successfully")
        else:
            print_error("Failed to remove service")
            raise click.ClickException("Service removal failed")

    except NotFoundError as e:
        print_error(f"Service not found: {e.message}")
        raise click.ClickException(str(e))
    except Exception as e:
        print_error(f"Failed to remove service: {str(e)}")
        raise click.ClickException(str(e))


@service.command()
def status() -> None:
    """Show registry status and statistics."""
    try:
        registry = get_registry_manager()

        # Get all services to calculate statistics
        all_services = registry.services.list_services()

        # Calculate statistics
        total_services = len(all_services)
        enabled_services = sum(1 for s in all_services if s.enabled)
        disabled_services = total_services - enabled_services
        analyzed_services = sum(1 for s in all_services if getattr(s, 'last_analyzed', None) and getattr(s, 'last_analyzed', None) != "Never")
        pending_analysis = total_services - analyzed_services

        console.print("[bold]Service Registry Status[/bold]\n")
        console.print(f"Total Services: {total_services}")
        console.print(f"  ✅ Enabled: {enabled_services}")
        console.print(f"  ❌ Disabled: {disabled_services}")
        console.print(f"  📊 Analyzed: {analyzed_services}")
        console.print(f"  ⏳ Pending Analysis: {pending_analysis}")

        # Show applications summary if services exist
        if total_services > 0:
            app_counts = registry.services.get_service_count_by_application()
            if app_counts:
                console.print(f"\n[bold]Services by Application:[/bold]")
                for app, count in app_counts.items():
                    app_display = app if app else "Unassigned"
                    console.print(f"  {app_display}: {count} services")

        # Show registry file info
        info = registry.services.get_info()
        console.print(f"\n[dim]Registry File: {info.get('file', 'N/A')}[/dim]")
        console.print(f"[dim]Last Refresh: {info.get('last_refresh', 'N/A')}[/dim]")
        console.print(f"[dim]Version: {info.get('version', 'N/A')}[/dim]")

    except Exception as e:
        print_error(f"Failed to get status: {str(e)}")
        raise click.ClickException(str(e))