"""
Setup command for Microforge v2.

This is a thin CLI wrapper that delegates to the SetupService.
"""

import click
from pathlib import Path

from typing import Optional
from ...core.common import (
    console,
    print_error,
    print_success,
    print_warning
)
from ...providers.vcs.git import is_git_repository
from ...services.setup.service import SetupService
from ...services.setup.models import SetupRequest


@click.command()
@click.option('--force', is_flag=True, help='Regenerate everything even if it exists')
@click.option('--docs-only', is_flag=True, help='Only generate documentation')
@click.option('--hooks-only', is_flag=True, help='Only initialize hooks')
@click.option('--update', is_flag=True, help='Update existing setup to latest version')
@click.option('--batch', is_flag=True, help='Run LLM in batch mode (non-interactive)')
def setup(force: bool, docs_only: bool, hooks_only: bool, update: bool, batch: bool) -> None:
    """Initialize Microforge in your project with docs, hooks, and AI instructions.

    This command will:
    - Initialize AI hooks for code quality
    - Generate comprehensive documentation
    - Create CLAUDE.md with project-specific instructions

    All changes are local - review and commit when ready.
    """
    try:
        console.print("[bold cyan]🚀 Microforge Setup[/bold cyan]\n")

        # Step 1: Check if it's a git repository
        if not is_git_repository():
            console.print("[red]❌ Error: Not a git repository[/red]")
            console.print("[yellow]Initialize a git repository first with: git init[/yellow]")
            return

        console.print("[green]✅ Git repository detected[/green]")

        # Show operation mode
        if docs_only:
            console.print("[yellow]📚 Mode: Documentation only[/yellow]")
        elif hooks_only:
            console.print("[yellow]🎯 Mode: Hooks only[/yellow]")
        else:
            console.print("[yellow]🔧 Mode: Full setup (hooks + documentation)[/yellow]")

        if force:
            console.print("[yellow]⚠️ Force mode: Regenerating even if exists[/yellow]")

        if update:
            console.print("[yellow]🔄 Update mode: Updating existing setup[/yellow]")

        # Show setup workflow
        console.print("\n[bold]🔄 Setup Workflow:[/bold]")
        if not docs_only:
            console.print("1. Initialize AI hooks for code quality")
        if not hooks_only:
            console.print("2. Generate comprehensive documentation")
            console.print("3. Create CLAUDE.md with project instructions")
        console.print("4. Validate and summarize results")

        # Show context that will be used
        console.print("\n[bold]📋 Setup Context:[/bold]")
        context_display = {
            "project": Path.cwd().name,
            "mode": "docs_only" if docs_only else ("hooks_only" if hooks_only else "full"),
            "force": force,
            "update": update,
            "batch_mode": batch
        }

        for key, value in context_display.items():
            console.print(f"  • {key}: {value}")

        console.print()

        # Create setup request
        request = SetupRequest(
            force=force,
            docs_only=docs_only,
            hooks_only=hooks_only,
            update=update,
            batch_mode=batch
        )

        # Execute setup
        setup_service = SetupService()
        result = setup_service.setup_project(request)

        if result.success:
            # Summary
            console.print("\n[bold green]✨ Setup complete![/bold green]\n")

            # Show what was created
            console.print("[bold]📁 Created files:[/bold]")

            files_to_check = [
                ("CLAUDE.md", "AI assistant instructions with hooks"),
                (".microforge/config.yaml", "Microforge configuration"),
                (".microforge/hooks/", "Hook definitions"),
                ("docs/service/", "Service documentation")
            ]

            for file_path, description in files_to_check:
                path = Path(file_path)
                if path.exists():
                    console.print(f"  ✅ {file_path} - {description}")

            # Next steps
            console.print("\n[bold]📋 Next steps:[/bold]")
            console.print("1. Review generated files: [cyan]git status[/cyan]")
            console.print("2. Check documentation: [cyan]ls -la docs/service/[/cyan]")
            console.print("3. Commit when ready: [cyan]git add . && git commit -m \"chore: Initialize Microforge\"[/cyan]")
            console.print("\n[dim]AI assistants will now follow project standards and documentation[/dim]")

            # Show execution time
            execution_time = result.execution_time_ms / 1000
            console.print(f"\n[dim]Completed in {execution_time:.2f} seconds[/dim]")
        else:
            print_error("Setup failed")
            for error in result.errors:
                print_error(f"  {error}")

            if result.warnings:
                for warning in result.warnings:
                    print_warning(f"⚠️ {warning}")

    except Exception as e:
        print_error(f"Setup command failed: {str(e)}")
        raise click.ClickException(str(e))