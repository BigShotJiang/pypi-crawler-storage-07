"""Configuration management commands for Microforge v2."""

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from ...core.common import (
    console,
    print_success,
    print_error,
    print_info
)
from ...config.settings import get_settings, MicroforgeSettings
from ...config.constants import MICROFORGE_CONFIG

console = Console()


@click.group()
def config():
    """Manage Microforge configuration."""
    pass


@config.command()
def init():
    """Initialize Microforge configuration."""
    console.print("🔧 Initializing Microforge configuration...")

    try:
        # Get or create settings
        settings = get_settings()

        print_success("Configuration initialized")
        console.print(f"[dim]Config file: {settings.config_file}[/dim]")

        # Show current configuration
        table = Table(title="Current Configuration")
        table.add_column("Setting", style="cyan")
        table.add_column("Value", style="green")

        table.add_row("Version", settings.version)
        table.add_row("Config File", str(settings.config_file))
        table.add_row("LLM Provider", settings.llm.provider)
        table.add_row("LLM Model", settings.llm.model)
        table.add_row("Temperature", str(settings.llm.temperature))
        table.add_row("Max Tokens", str(settings.llm.max_tokens))

        console.print(table)

    except Exception as e:
        print_error(f"Error initializing configuration: {e}")
        raise click.ClickException("Configuration initialization failed")


@config.command()
def show():
    """Show current configuration."""
    try:
        settings = get_settings()

        panel = Panel.fit(
            f"[bold]Microforge Configuration[/bold]\n\n"
            f"[cyan]Config File:[/cyan] {settings.config_file}\n"
            f"[cyan]Version:[/cyan] {settings.version}\n\n"
            f"[yellow]LLM Settings:[/yellow]\n"
            f"  Provider: {settings.llm.provider}\n"
            f"  Model: {settings.llm.model}\n"
            f"  Temperature: {settings.llm.temperature}\n"
            f"  Max Tokens: {settings.llm.max_tokens}\n"
            f"  Timeout: {settings.llm.timeout_seconds}s\n\n"
            f"[yellow]Registries:[/yellow]\n"
            f"  Refresh Interval: {settings.registries.refresh_interval_seconds}s\n"
            f"  Cache TTL: {settings.registries.cache_ttl_seconds}s",
            border_style="blue",
            title="⚙️ Configuration"
        )
        console.print(panel)

    except Exception as e:
        print_error(f"Error reading configuration: {e}")
        raise click.ClickException("Failed to show configuration")


@config.command()
@click.option('--provider', help='LLM provider (claude)')
@click.option('--model', help='LLM model name')
@click.option('--temperature', type=float, help='LLM temperature (0.0-1.0)')
@click.option('--max-tokens', type=int, help='Maximum tokens')
@click.option('--timeout', type=int, help='Timeout in seconds')
def set(provider: str, model: str, temperature: float, max_tokens: int, timeout: int):
    """Set configuration values."""
    try:
        settings = get_settings()

        # Update LLM settings if provided
        updated = False

        if provider:
            settings.llm.provider = provider
            updated = True
            print_success(f"Set LLM provider to: {provider}")

        if model:
            settings.llm.model = model
            updated = True
            print_success(f"Set LLM model to: {model}")

        if temperature is not None:
            if 0.0 <= temperature <= 1.0:
                settings.llm.temperature = temperature
                updated = True
                print_success(f"Set temperature to: {temperature}")
            else:
                print_error("Temperature must be between 0.0 and 1.0")
                return

        if max_tokens:
            settings.llm.max_tokens = max_tokens
            updated = True
            console.print(f"[green]✓[/green] Set max tokens to: {max_tokens}")

        if timeout:
            settings.llm.timeout_seconds = timeout
            updated = True
            console.print(f"[green]✓[/green] Set timeout to: {timeout}s")

        if updated:
            # Save settings
            settings.save()
            console.print(f"\n[green]✅ Configuration saved to {settings.config_file}[/green]")
        else:
            console.print("[yellow]No configuration changes made[/yellow]")
            console.print("[dim]Use --help to see available options[/dim]")

    except Exception as e:
        console.print(f"[red]❌ Error updating configuration: {e}[/red]")
        raise click.ClickException("Failed to set configuration")


@config.command()
@click.confirmation_option(prompt='Are you sure you want to reset configuration?')
def reset():
    """Reset configuration to defaults."""
    try:
        settings = get_settings()

        # Reset to defaults
        new_settings = MicroforgeSettings()
        new_settings.config_file = settings.config_file
        new_settings.save()

        console.print("[green]✅ Configuration reset to defaults[/green]")
        console.print(f"[dim]Config file: {new_settings.config_file}[/dim]")

    except Exception as e:
        console.print(f"[red]❌ Error resetting configuration: {e}[/red]")
        raise click.ClickException("Failed to reset configuration")


@config.command()
def validate():
    """Validate current configuration."""
    try:
        settings = get_settings()

        console.print("🔍 Validating configuration...\n")

        # Validation checks
        checks = []

        # Check config file exists and is readable
        if settings.config_file.exists():
            checks.append(("Config file exists", True, str(settings.config_file)))
        else:
            checks.append(("Config file exists", False, "File not found"))

        # Check LLM settings
        if settings.llm.provider in ["claude"]:
            checks.append(("LLM provider valid", True, settings.llm.provider))
        else:
            checks.append(("LLM provider valid", False, f"Unknown provider: {settings.llm.provider}"))

        if 0.0 <= settings.llm.temperature <= 1.0:
            checks.append(("Temperature valid", True, str(settings.llm.temperature)))
        else:
            checks.append(("Temperature valid", False, f"Out of range: {settings.llm.temperature}"))

        if settings.llm.max_tokens > 0:
            checks.append(("Max tokens valid", True, str(settings.llm.max_tokens)))
        else:
            checks.append(("Max tokens valid", False, f"Invalid value: {settings.llm.max_tokens}"))

        # Check registries settings
        if settings.registries.refresh_interval_seconds > 0:
            checks.append(("Registry refresh interval valid", True, f"{settings.registries.refresh_interval_seconds}s"))
        else:
            checks.append(("Registry refresh interval valid", False, "Must be positive"))

        # Display results
        table = Table(title="Configuration Validation")
        table.add_column("Check", style="cyan")
        table.add_column("Status", style="bold")
        table.add_column("Value", style="dim")

        all_valid = True
        for check_name, is_valid, value in checks:
            status = "[green]✓ PASS[/green]" if is_valid else "[red]✗ FAIL[/red]"
            table.add_row(check_name, status, value)
            if not is_valid:
                all_valid = False

        console.print(table)

        if all_valid:
            console.print("\n[green]✅ Configuration is valid[/green]")
        else:
            console.print("\n[red]❌ Configuration has issues[/red]")
            console.print("[dim]Use 'microforge config set' to fix issues[/dim]")

    except Exception as e:
        console.print(f"[red]❌ Error validating configuration: {e}[/red]")
        raise click.ClickException("Configuration validation failed")