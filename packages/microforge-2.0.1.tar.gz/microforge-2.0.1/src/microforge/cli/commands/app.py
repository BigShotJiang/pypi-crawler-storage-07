"""
Application management commands for Microforge v2.

This is a thin CLI wrapper that delegates to the ApplicationRegistry.
"""

import click
from rich.table import Table

from ...core.common import console, print_error, print_success, print_info
from ...registries.manager import get_registry_manager


@click.group()
def app():
    """Manage applications (groups of related services)."""
    pass


@app.command()
@click.argument('name')
@click.option('--description', default='', help='Application description')
def add(name: str, description: str) -> None:
    """Create a new application group."""
    try:
        registry = get_registry_manager()

        # Check if application already exists
        if registry.applications.get_application(name):
            print_error(f"Application '{name}' already exists.")
            raise click.ClickException("Application already exists")

        # Add application
        success = registry.applications.add_application(name, description)

        if success:
            print_success(f"✅ Application '{name}' created successfully")
            if description:
                print_info(f"   Description: {description}")
            print_info("   Add services with: microforge service add <service-name> <repo-url> --app " + name)
        else:
            print_error("Failed to create application")
            raise click.ClickException("Application creation failed")

    except Exception as e:
        print_error(f"Failed to add application: {str(e)}")
        raise click.ClickException(str(e))


@app.command()
@click.option('--format', 'output_format', type=click.Choice(['table', 'json']), default='table', help='Output format')
def list(output_format: str = 'table') -> None:
    """List all applications."""
    try:
        registry = get_registry_manager()
        applications = registry.applications.list_applications()

        if not applications:
            print_info("No applications created")
            print_info("Create an application with: microforge app add <name> --description '<description>'")
            return

        if output_format == 'json':
            import json
            console.print(json.dumps(applications, indent=2))
        else:
            # Display as table
            table = Table(title="Applications")
            table.add_column("Name", style="cyan")
            table.add_column("Description", style="white")
            table.add_column("Services", style="green")
            table.add_column("Created", style="yellow")

            # Get service counts
            service_counts = registry.services.get_service_count_by_application()

            for app in applications:
                service_count = service_counts.get(app['name'], 0)
                created_at = app.get('created_at', 'Unknown')
                if created_at != 'Unknown':
                    try:
                        from datetime import datetime
                        dt = datetime.fromisoformat(created_at)
                        created_at = dt.strftime("%Y-%m-%d")
                    except:
                        pass

                table.add_row(
                    app['name'],
                    app.get('description', ''),
                    str(service_count),
                    created_at
                )

            console.print(table)
            console.print(f"\n[bold]Total: {len(applications)} applications[/bold]")

    except Exception as e:
        print_error(f"Failed to list applications: {str(e)}")
        raise click.ClickException(str(e))


@app.command()
@click.argument('name')
def show(name: str) -> None:
    """Show details for a specific application."""
    try:
        registry = get_registry_manager()
        app = registry.applications.get_application(name)

        if not app:
            print_error(f"Application '{name}' not found")
            raise click.ClickException("Application not found")

        # Display application details
        console.print(f"\n[bold cyan]📁 Application: {app.name}[/bold cyan]")
        console.print(f"Description: {app.description or 'No description'}")
        console.print(f"Created: {app.created_at or 'Unknown'}")

        # Show services in this application
        services = registry.services.list_services_by_application(name)
        if services:
            console.print(f"\n[bold]Services ({len(services)}):[/bold]")

            service_table = Table()
            service_table.add_column("Service", style="cyan")
            service_table.add_column("Repository", style="blue")
            service_table.add_column("Branch", style="green")
            service_table.add_column("Status", style="white")

            for service in services:
                status = "✅ Active" if service.enabled else "❌ Disabled"
                service_table.add_row(
                    service.name,
                    service.repo_url,
                    service.branch,
                    status
                )

            console.print(service_table)
        else:
            console.print(f"\n[dim]No services in this application yet[/dim]")
            console.print(f"[dim]Add services with: microforge service add <service-name> <repo-url> --app {name}[/dim]")

    except Exception as e:
        print_error(f"Failed to show application: {str(e)}")
        raise click.ClickException(str(e))


@app.command()
@click.argument('name')
@click.option('--force', is_flag=True, help='Force removal without confirmation')
def remove(name: str, force: bool = False) -> None:
    """Remove an application and optionally its services."""
    try:
        registry = get_registry_manager()

        # Check if application exists
        app = registry.applications.get_application(name)
        if not app:
            print_error(f"Application '{name}' not found")
            raise click.ClickException("Application not found")

        # Check for services in this application
        services = registry.services.list_services_by_application(name)

        # Confirm removal unless forced
        if not force:
            console.print(f"\n[yellow]⚠️ This will remove application '{name}'[/yellow]")
            console.print(f"Description: {app.get('description', 'No description')}")

            if services:
                console.print(f"\n[red]⚠️ Warning: This application has {len(services)} services:[/red]")
                for service in services:
                    console.print(f"  • {service.name}")
                console.print("\n[yellow]Services will be moved to 'uncategorized'[/yellow]")

            if not click.confirm("Are you sure you want to remove this application?"):
                print_info("Operation cancelled")
                return

        # Move services to uncategorized
        if services:
            for service in services:
                registry.services.update_service(service.name, application=None)
            print_info(f"Moved {len(services)} services to 'uncategorized'")

        # Remove application
        success = registry.applications.remove_application(name)

        if success:
            print_success(f"✅ Application '{name}' removed successfully")
        else:
            print_error("Failed to remove application")
            raise click.ClickException("Application removal failed")

    except Exception as e:
        print_error(f"Failed to remove application: {str(e)}")
        raise click.ClickException(str(e))


@app.command()
def status() -> None:
    """Show application registry status and overview."""
    try:
        registry = get_registry_manager()

        # Get overall status
        status_info = registry.get_status()
        counts = registry.get_counts()

        console.print(f"\n[bold]📁 Applications Overview[/bold]")
        console.print(f"Total applications: {counts['applications']}")
        console.print(f"Total services: {counts['services']}")

        # Show services by application
        service_counts = registry.services.get_service_count_by_application()
        if service_counts:
            console.print(f"\n[bold]Services by Application:[/bold]")

            app_table = Table()
            app_table.add_column("Application", style="cyan")
            app_table.add_column("Services", style="green")
            app_table.add_column("Percentage", style="yellow")

            total_services = sum(service_counts.values())

            for app_name, count in sorted(service_counts.items()):
                percentage = (count / total_services * 100) if total_services > 0 else 0
                app_table.add_row(
                    app_name,
                    str(count),
                    f"{percentage:.1f}%"
                )

            console.print(app_table)
        else:
            console.print("\n[dim]No services registered yet[/dim]")

    except Exception as e:
        print_error(f"Failed to get status: {str(e)}")
        raise click.ClickException(str(e))