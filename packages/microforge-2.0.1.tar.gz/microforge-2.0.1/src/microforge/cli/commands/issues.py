"""
Issues command for Microforge v2.

This is a thin CLI wrapper that delegates to the IssuesService.
Handles GitHub issues fetching, creation, and Claude AI integration.
"""

import click
from pathlib import Path
from typing import Optional

from ...core.common import console, print_error, print_success, print_info
from ...services.issues.service import IssuesService
from ...services.issues.models import IssuesRequest


@click.group()
def issues():
    """Manage GitHub issues with AI assistance.

    Fetch issues from GitHub repositories, create new issues from local files,
    and submit issues to Claude AI for processing.
    """
    pass


@click.command()
@click.option('--state', default='open', type=click.Choice(['open', 'closed', 'all']),
              help='Filter by issue state')
@click.option('--label', help='Filter by label')
@click.option('--assignee', help='Filter by assignee (use @me for yourself)')
@click.option('--number', type=int, help='Fetch specific issue by number')
@click.option('--output-dir', default='./issues', type=click.Path(),
              help='Directory to save downloaded issues')
@click.option('--all', 'fetch_all', is_flag=True, help='Fetch all issues without interactive selection')
@click.option('--limit', default=100, type=int, help='Maximum number of issues to fetch')
@click.option('--no-attachments', is_flag=True, help='Skip downloading attachments')
@click.option('--service', help='Service name from registry for remote mode')
def fetch(
    state: str,
    label: Optional[str],
    assignee: Optional[str],
    number: Optional[int],
    output_dir: str,
    fetch_all: bool,
    limit: int,
    no_attachments: bool,
    service: Optional[str]
) -> None:
    """Fetch GitHub issues and save them locally.

    Examples:
        microforge issues fetch                    # Fetch open issues from current repo
        microforge issues fetch --state closed    # Fetch closed issues
        microforge issues fetch --service my-svc  # Fetch from service registry
        microforge issues fetch --number 123      # Fetch specific issue
        microforge issues fetch --label bug       # Fetch issues with 'bug' label
    """
    try:
        console.print("[bold cyan]🔍 Fetching GitHub Issues[/bold cyan]\n")

        # Create request
        request = IssuesRequest(
            state=state,
            label=label,
            assignee=assignee,
            number=number,
            output_dir=Path(output_dir),
            fetch_all=fetch_all,
            limit=limit,
            no_attachments=no_attachments,
            service=service
        )

        # Show operation context
        if service:
            print_info(f"Mode: Remote (service: {service})")
        else:
            print_info("Mode: Local (current repository)")

        print_info(f"State filter: {state}")
        print_info(f"Output directory: {output_dir}")
        if label:
            print_info(f"Label filter: {label}")
        if assignee:
            print_info(f"Assignee filter: {assignee}")
        if number:
            print_info(f"Specific issue: #{number}")

        # Execute fetch
        issues_service = IssuesService()
        result = issues_service.fetch_issues(request)

        if result.success:
            execution_time = result.execution_time_ms / 1000
            console.print(f"[dim]Completed in {execution_time:.2f} seconds[/dim]")

            if result.warnings:
                for warning in result.warnings:
                    console.print(f"[yellow]⚠️ {warning}[/yellow]")
        else:
            print_error("Failed to fetch issues")
            for error in result.errors:
                print_error(f"  {error}")

    except Exception as e:
        print_error(f"Issues fetch command failed: {str(e)}")
        raise click.ClickException(str(e))


@click.command()
@click.argument('issue_dir', type=click.Path(exists=True, file_okay=False, dir_okay=True))
@click.option('--draft', is_flag=True, help='Create as draft issue (if supported)')
@click.option('--labels', help='Comma-separated labels to add (overrides metadata.yaml)')
@click.option('--assignees', help='Comma-separated assignees (overrides metadata.yaml)')
@click.option('--milestone', help='Milestone title or number')
@click.option('--service', help='Service name from registry for remote mode')
def create(
    issue_dir: str,
    draft: bool,
    labels: Optional[str],
    assignees: Optional[str],
    milestone: Optional[str],
    service: Optional[str]
) -> None:
    """Create a GitHub issue from local files.

    The issue directory should contain:
    - issue.md: Issue content in markdown
    - metadata.yaml: Issue metadata (title, labels, assignees, etc.)

    Examples:
        microforge issues create ./my-issue       # Create from local directory
        microforge issues create ./my-issue --draft   # Create as draft
        microforge issues create ./my-issue --service my-svc  # Create in service repo
    """
    try:
        console.print("[bold cyan]📝 Creating GitHub Issue[/bold cyan]\n")

        # Create request
        request = IssuesRequest(
            issue_dir=Path(issue_dir),
            draft=draft,
            labels_override=labels,
            assignees_override=assignees,
            milestone_override=milestone,
            service=service
        )

        # Show operation context
        print_info(f"Issue directory: {issue_dir}")
        if service:
            print_info(f"Mode: Remote (service: {service})")
        else:
            print_info("Mode: Local (current repository)")

        if draft:
            print_info("Creating as draft issue")

        # Execute create
        issues_service = IssuesService()
        result = issues_service.create_issue(request)

        if result.success:
            execution_time = result.execution_time_ms / 1000
            console.print(f"[dim]Completed in {execution_time:.2f} seconds[/dim]")

            if result.warnings:
                for warning in result.warnings:
                    console.print(f"[yellow]⚠️ {warning}[/yellow]")
        else:
            print_error("Failed to create issue")
            for error in result.errors:
                print_error(f"  {error}")

    except Exception as e:
        print_error(f"Issues create command failed: {str(e)}")
        raise click.ClickException(str(e))


@click.command()
@click.option('--issue-id', help='Issue ID/number to submit (optional, will list issues if not provided)')
@click.option('--agent', help='Agent file path (optional, defaults to implementation.md or service-configured agent)')
@click.option('--batch', is_flag=True, help='Run Claude in batch mode (non-interactive)')
@click.option('--interactive/--no-interactive', default=True, help='Run Claude interactively (default: true)')
@click.option('--service', help='Service name from registry (will use service-specific agent if available)')
@click.option('--repo', default='inviz-search/microforge-ai', help='GitHub repository (owner/repo format)')
def submit(
    issue_id: Optional[str],
    agent: Optional[str],
    batch: bool,
    interactive: bool,
    service: Optional[str],
    repo: str
) -> None:
    """Submit a GitHub issue to Claude AI for processing.

    This command submits an issue to Claude AI using a specified agent template
    for automated processing, analysis, or implementation.

    If no issue-id is provided, lists all issues from the repository for selection.
    When a service is specified, its configured agent will be used automatically.

    Examples:
        microforge issues submit  # Lists issues for selection
        microforge issues submit --issue-id 123 --agent implementation.md
        microforge issues submit --issue-id 123 --service user-identity-service  # Uses service agent
        microforge issues submit --repo owner/repo  # List issues from specific repo
    """
    try:
        console.print("[bold cyan]🤖 Submitting Issue to Claude AI[/bold cyan]\n")

        # If no issue ID provided, fetch and list issues for selection
        if not issue_id:
            print_info(f"Fetching issues from repository: {repo}")

            # Use GitHub provider to fetch issues
            from ...providers.vcs.github import GitHubProvider
            github_provider = GitHubProvider()

            # Parse repo if provided
            if repo and repo != 'inviz-search/microforge-ai':
                owner, name = repo.split('/')
                repo_info = {'owner': owner, 'repo': name}
            else:
                # Use default microforge repo
                repo_info = {'owner': 'inviz-search', 'repo': 'microforge-ai'}

            # Build and execute gh command to list issues
            gh_command = [
                "issue", "list",
                "--repo", f"{repo_info['owner']}/{repo_info['repo']}",
                "--state", "open",
                "--limit", "50",
                "--json", "number,title,body,labels,state"
            ]

            gh_result = github_provider.run_gh_command(gh_command)

            if not gh_result['success']:
                print_error(f"Failed to fetch issues: {gh_result['stderr']}")
                return

            import json
            issues_list = json.loads(gh_result['stdout'])

            if not issues_list:
                print_error("No open issues found in the repository.")
                return

            # Display issues for selection
            console.print("\n[bold]Open Issues from inviz-search/microforge-ai:[/bold]\n")
            for idx, issue in enumerate(issues_list, 1):
                labels = ', '.join([label['name'] for label in issue.get('labels', [])])
                labels_str = f" [yellow][{labels}][/yellow]" if labels else ""
                console.print(f"  [cyan]{idx}[/cyan]. [bold]#{issue['number']}[/bold] - {issue['title']}{labels_str}")
                if issue.get('body'):
                    # Show first line of body
                    first_line = issue['body'].split('\n')[0][:100]
                    if first_line:
                        console.print(f"     [dim]{first_line}...[/dim]")

            # Ask user to select an issue
            console.print("\n")
            try:
                selection = click.prompt('Select an issue number (1-{})'.format(len(issues_list)), type=int)
            except (EOFError, KeyboardInterrupt):
                print_error("Selection cancelled")
                return

            if selection < 1 or selection > len(issues_list):
                print_error("Invalid selection")
                return

            selected_issue = issues_list[selection - 1]
            issue_id = str(selected_issue['number'])

            console.print(f"\n[green]✓[/green] Selected issue #{issue_id}: {selected_issue['title']}\n")

        # Create request - use default agent only if not using service
        request = IssuesRequest(
            issue_id=issue_id,
            agent=agent or 'implementation.md',  # Default agent if none provided
            batch_mode=batch,
            interactive=interactive,
            service=service
        )

        # Show operation context
        print_info(f"Issue ID: #{issue_id}")
        if service:
            print_info(f"Service: {service}")
            if agent:
                print_info(f"Agent override: {agent}")
            else:
                print_info(f"Agent: Will use service-configured agent or default (implementation.md)")
        else:
            print_info(f"Agent: {agent or 'implementation.md'}")
            print_info("Repository: {}".format(repo))

        print_info(f"Mode: {'Batch' if batch else 'Interactive'}")

        # Execute submit
        issues_service = IssuesService()
        result = issues_service.submit_issue_to_claude(request)

        if result.success:
            execution_time = result.execution_time_ms / 1000
            console.print(f"[dim]Completed in {execution_time:.2f} seconds[/dim]")

            if result.warnings:
                for warning in result.warnings:
                    console.print(f"[yellow]⚠️ {warning}[/yellow]")
        else:
            print_error("Failed to submit issue to Claude")
            for error in result.errors:
                print_error(f"  {error}")

    except Exception as e:
        print_error(f"Issues submit command failed: {str(e)}")
        raise click.ClickException(str(e))


# Add subcommands to the issues group
issues.add_command(fetch)
issues.add_command(create)
issues.add_command(submit)