#!/usr/bin/env python3
"""
Microforge UI Commands.

Launches the web interface for managing workflows and agents.
"""

import click
import uvicorn
import webbrowser
from typing import Optional
import asyncio
import time

from ...core.common import console


@click.group()
def ui():
    """Manage the Microforge Web UI."""
    pass


@ui.command()
@click.option(
    '--host',
    default='127.0.0.1',
    help='Host to bind the server to'
)
@click.option(
    '--port',
    default=8000,
    type=int,
    help='Port to bind the server to'
)
@click.option(
    '--reload',
    is_flag=True,
    default=False,
    help='Enable auto-reload for development'
)
@click.option(
    '--no-browser',
    is_flag=True,
    default=False,
    help='Do not open browser automatically'
)
def start(host: str, port: int, reload: bool, no_browser: bool):
    """
    Start the Microforge Web UI server.
    
    Examples:
        microforge ui start
        microforge ui start --port 8080
        microforge ui start --reload --no-browser
    """
    console.print("[bold cyan]⚡ Starting Microforge Web UI...[/bold cyan]")
    console.print(f"[dim]Host: {host}:{port}[/dim]")
    
    # Import app here to avoid circular imports
    from ...web.app import app
    
    # Open browser after a short delay
    if not no_browser:
        def open_browser():
            time.sleep(1.5)  # Wait for server to start
            webbrowser.open(f"http://{host}:{port}")
        
        import threading
        browser_thread = threading.Thread(target=open_browser)
        browser_thread.daemon = True
        browser_thread.start()
        console.print(f"[green]✓[/green] Opening browser at http://{host}:{port}")
    
    # Start the server
    try:
        uvicorn.run(
            "microforge.web.app:app" if reload else app,
            host=host,
            port=port,
            reload=reload,
            log_level="info" if reload else "warning"
        )
    except KeyboardInterrupt:
        console.print("\n[dim]Shutting down Web UI...[/dim]")
    except Exception as e:
        console.print(f"[red]Error starting Web UI: {e}[/red]")
        raise click.ClickException(str(e))


@ui.command()
@click.option(
    '--port',
    default=8000,
    type=int,
    help='Port to check'
)
def status(port: int):
    """
    Check if the Web UI is running.
    
    Examples:
        microforge ui status
        microforge ui status --port 8080
    """
    import socket
    
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    result = sock.connect_ex(('127.0.0.1', port))
    sock.close()
    
    if result == 0:
        console.print(f"[green]✓[/green] Web UI is running on port {port}")
        console.print(f"[dim]Access at: http://127.0.0.1:{port}[/dim]")
    else:
        console.print(f"[yellow]⚠[/yellow] Web UI is not running on port {port}")
        console.print("[dim]Start it with: microforge ui start[/dim]")


@ui.command()
def open():
    """
    Open the Web UI in the default browser.
    
    Examples:
        microforge ui open
    """
    import socket
    
    # Check if UI is running
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    result = sock.connect_ex(('127.0.0.1', 8000))
    sock.close()
    
    if result == 0:
        console.print("[green]✓[/green] Opening Web UI in browser...")
        webbrowser.open("http://127.0.0.1:8000")
    else:
        console.print("[yellow]⚠[/yellow] Web UI is not running")
        console.print("[dim]Start it first with: microforge ui start[/dim]")


if __name__ == "__main__":
    ui()