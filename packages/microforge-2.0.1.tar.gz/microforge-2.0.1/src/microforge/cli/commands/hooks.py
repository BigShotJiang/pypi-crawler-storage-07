"""
Hooks command for AI assistant integration using v2 architecture.

This is a thin CLI wrapper that delegates to the HooksService.
"""

import click
from rich.table import Table
from rich.markdown import Markdown

from ...core.common import console, print_error, print_success, print_info
from ...services.hooks.service import HooksService
from ...services.hooks.models import HooksRequest, HooksRefreshResult, HooksUpdateResult


@click.group()
def hooks():
    """Manage AI assistant hooks for code quality."""
    pass


@hooks.command()
@click.option('--force', is_flag=True, help='Overwrite existing configuration')
def init(force: bool) -> None:
    """Initialize AI hooks in the current project."""
    try:
        # Create hooks request
        request = HooksRequest.init_request(force=force)

        # Get hooks service
        hooks_service = HooksService()

        # Initialize hooks
        result = hooks_service.init_hooks(request)

        if not result.success:
            print_error(result.message)
            if result.error:
                print_error(f"Error: {result.error}")
            return

        print_success("🎯 Hooks initialization completed!")

    except Exception as e:
        print_error(f"Hooks initialization failed: {str(e)}")
        raise click.ClickException(str(e))


@hooks.command()
def status() -> None:
    """Check status and version of hooks system."""
    try:
        hooks_service = HooksService()
        hook_status = hooks_service.get_status()

        if not hook_status.initialized:
            print_info("❌ Hooks not initialized")
            print_info("Run 'microforge hooks init' to get started")
            return

        # Display status
        console.print(f"\n[bold]🎯 Hooks System Status[/bold]")
        console.print(f"Version: {hook_status.version}")
        console.print(f"Configuration: {hook_status.config_path}")
        console.print(f"Hooks Directory: {hook_status.hooks_directory}")

        # Display hooks table
        table = Table(title="Configured Hooks")
        table.add_column("Hook", style="cyan")
        table.add_column("Status", style="green")
        table.add_column("Version", style="yellow")
        table.add_column("File", style="blue")

        for hook_name, hook_info in hook_status.hooks.items():
            enabled = hook_info.get('enabled', False)
            version = hook_info.get('version', 'unknown')
            file_exists = hook_info.get('file_exists', False)

            status_text = "✅ Enabled" if enabled else "❌ Disabled"
            file_text = "✅ Found" if file_exists else "❌ Missing"

            table.add_row(hook_name, status_text, version, file_text)

        console.print(table)

        # Show summary
        console.print(f"\n[bold]Summary:[/bold]")
        console.print(f"Total hooks: {hook_status.total_hooks}")
        console.print(f"Enabled hooks: {hook_status.enabled_hooks}")

        if hook_status.missing_files:
            console.print(f"[red]Missing files: {len(hook_status.missing_files)}[/red]")
            for missing in hook_status.missing_files:
                console.print(f"  • {missing}")

    except Exception as e:
        print_error(f"Failed to get hooks status: {str(e)}")
        raise click.ClickException(str(e))


@hooks.command()
def list() -> None:
    """List available hooks."""
    try:
        hooks_service = HooksService()
        available_hooks = hooks_service.list_available_hooks()

        if not available_hooks:
            print_info("No hooks available")
            return

        # Display available hooks
        table = Table(title="Available Hooks")
        table.add_column("Name", style="cyan")
        table.add_column("Description", style="white")
        table.add_column("File", style="blue")
        table.add_column("Required", style="red")

        for hook_info in available_hooks:
            required_text = "✅ Yes" if hook_info.required else "❌ No"
            table.add_row(
                hook_info.name,
                hook_info.description,
                hook_info.file_name,
                required_text
            )

        console.print(table)

    except Exception as e:
        print_error(f"Failed to list hooks: {str(e)}")
        raise click.ClickException(str(e))


@hooks.command()
@click.argument('hook_name')
def show(hook_name: str) -> None:
    """Show details for a specific hook."""
    try:
        hooks_service = HooksService()
        hook_info = hooks_service.show_hook_details(hook_name)

        # Display hook details
        console.print(f"\n[bold cyan]🎯 Hook: {hook_info.name}[/bold cyan]")
        console.print(f"Description: {hook_info.description}")
        console.print(f"File: {hook_info.file_name}")
        console.print(f"Version: {hook_info.version}")
        console.print(f"Priority: {hook_info.priority}")
        console.print(f"Required: {'Yes' if hook_info.required else 'No'}")
        console.print(f"Default enabled: {'Yes' if hook_info.enabled else 'No'}")

    except Exception as e:
        print_error(f"Failed to show hook details: {str(e)}")
        raise click.ClickException(str(e))


@hooks.command()
@click.argument('hook_name')
def view(hook_name: str) -> None:
    """View hook instructions."""
    try:
        hooks_service = HooksService()
        hook_info = hooks_service.show_hook_details(hook_name)

        # Try to read hook file
        from ...config.constants import MICROFORGE_PROJECT_HOOKS_DIR
        hook_file = MICROFORGE_PROJECT_HOOKS_DIR / hook_info.file_name

        if not hook_file.exists():
            print_error(f"Hook file not found: {hook_file}")
            print_info("Run 'microforge hooks init' to initialize hooks")
            return

        try:
            with open(hook_file, 'r', encoding='utf-8') as f:
                content = f.read()

            # Display as markdown
            console.print(f"\n[bold cyan]📖 Hook Instructions: {hook_info.name}[/bold cyan]")
            console.print(f"File: {hook_file}")
            console.print("")

            markdown = Markdown(content)
            console.print(markdown)

        except Exception as e:
            print_error(f"Failed to read hook file: {str(e)}")

    except Exception as e:
        print_error(f"Failed to view hook: {str(e)}")
        raise click.ClickException(str(e))


@hooks.command()
@click.argument('hook_name')
@click.option('--enable', is_flag=True, help='Enable the hook')
@click.option('--disable', is_flag=True, help='Disable the hook')
def toggle(hook_name: str, enable: bool, disable: bool) -> None:
    """Enable or disable a hook."""
    if enable and disable:
        print_error("Cannot specify both --enable and --disable")
        raise click.ClickException("Invalid options")

    if not enable and not disable:
        print_error("Must specify either --enable or --disable")
        raise click.ClickException("Missing required option")

    try:
        hooks_service = HooksService()
        enabled = enable  # enable=True means enable, disable=True means enable=False

        result = hooks_service.toggle_hook(hook_name, enabled)

        if result:
            action = "enabled" if enabled else "disabled"
            print_success(f"✅ Hook '{hook_name}' {action}")
        else:
            print_error(f"Failed to toggle hook '{hook_name}'")

    except Exception as e:
        print_error(f"Failed to toggle hook: {str(e)}")
        raise click.ClickException(str(e))


@hooks.command()
def validate() -> None:
    """Validate hooks configuration."""
    try:
        hooks_service = HooksService()
        validation_result = hooks_service.validate_configuration()

        if validation_result['valid']:
            print_success("✅ Hooks configuration is valid")
        else:
            print_error("❌ Hooks configuration has issues:")
            for issue in validation_result['issues']:
                print_error(f"  • {issue}")

            if validation_result.get('error'):
                print_error(f"Error: {validation_result['error']}")

    except Exception as e:
        print_error(f"Failed to validate hooks: {str(e)}")
        raise click.ClickException(str(e))


@hooks.command()
def refresh() -> None:
    """Refresh hooks from registry."""
    try:
        # Create hooks request for refresh
        request = HooksRequest.refresh_request()

        # Get hooks service
        hooks_service = HooksService()

        # Execute refresh
        result = hooks_service.refresh_hooks(request)

        if result.success:
            print_success("Hooks refreshed successfully")
            print_info(f"Refreshed {len(result.hooks_refreshed)} hooks")
            for hook_name in result.hooks_refreshed:
                console.print(f"  • {hook_name}")
        else:
            print_error(f"Failed to refresh hooks: {result.error_message}")
            raise click.ClickException("Hooks refresh failed")

    except Exception as e:
        print_error(f"Failed to refresh hooks: {str(e)}")
        raise click.ClickException(str(e))


@hooks.command()
def update() -> None:
    """Update hooks system."""
    try:
        # Create hooks request for update
        request = HooksRequest.update_request()

        # Get hooks service
        hooks_service = HooksService()

        # Execute update
        result = hooks_service.update_hooks(request)

        if result.success:
            print_success("Hooks system updated successfully")
            if result.hooks_updated:
                print_info(f"Updated {len(result.hooks_updated)} hooks")
                for hook_name in result.hooks_updated:
                    console.print(f"  • {hook_name}")
            if result.version_updated:
                print_info(f"Hooks system version updated to: {result.new_version}")
        else:
            print_error(f"Failed to update hooks: {result.error_message}")
            raise click.ClickException("Hooks update failed")

    except Exception as e:
        print_error(f"Failed to update hooks: {str(e)}")
        raise click.ClickException(str(e))