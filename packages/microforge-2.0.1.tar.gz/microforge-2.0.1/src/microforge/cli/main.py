"""
Main CLI entry point for Microforge v2.

This provides the same CLI interface as the original but uses the new architecture.
"""

import click
from pathlib import Path

from ..core.common import console, print_warning, print_error, print_info
from ..config.settings import get_settings

# Import all CLI commands
from .commands.analyze import analyze
from .commands.hooks import hooks
from .commands.service import service
from .commands.app import app
from .commands.setup import setup
from .commands.audit import audit
from .commands.issues import issues
from .commands.mcp import mcp
from .commands.config import config
from .commands.workflow import workflow
from .commands.ui import ui
from .commands.agents import agents


def verbose_callback(ctx, param, value):
    if value:
        click.echo("Verbose mode enabled", err=False)
        click.echo("Using Microforge v2 architecture", err=False)
    return value

@click.group(invoke_without_command=True)
@click.version_option(version="2.0.0")
@click.option('--verbose', '-v', is_flag=True, help='Enable verbose output', is_eager=True, callback=verbose_callback)
@click.option('--no-update-check', is_flag=True, hidden=True, help='Skip update check')
@click.option('--upgrade', is_flag=True, help='Check for and install updates')
@click.option('--upgrade-check', is_flag=True, help='Check for updates without installing')
@click.pass_context
def cli(ctx, verbose: bool, no_update_check: bool, upgrade: bool, upgrade_check: bool) -> None:
    """Microforge v2 - AI-enhanced Python microservice platform."""
    # Store verbose in context for global access
    ctx.ensure_object(dict)
    ctx.obj['verbose'] = verbose

    # Load settings (this ensures configuration is initialized)
    # Only load settings for commands that need them
    if ctx.invoked_subcommand in ['config', 'setup']:
        try:
            settings = get_settings()
            if verbose:
                console.print(f"[dim]Configuration loaded from: {settings.config_file}[/dim]")
        except Exception as e:
            if verbose:
                print_warning(f"Failed to load settings: {e}")

    # Handle upgrade flags
    if upgrade or upgrade_check:
        try:
            from ..services.version.service import VersionService
            from ..services.version.models import UpdateRequest

            version_service = VersionService()
            request = UpdateRequest(check_only=upgrade_check)

            if upgrade_check:
                result = version_service.check_for_updates(request)
            else:
                result = version_service.perform_update(request)

            # Exit after upgrade operation
            import sys
            sys.exit(0 if result.success else 1)

        except Exception as e:
            print_error(f"Error during upgrade: {e}")
            import sys
            sys.exit(1)

    # Check for updates on startup (non-blocking)
    # TEMPORARILY DISABLED to fix circular dependency
    # if not no_update_check and ctx.invoked_subcommand not in ['service', 'app', 'analyze', 'audit']:
    #     # Skip version check for commands that might have circular dependencies
    #     try:
    #         from ..services.version.service import VersionService
    #         version_service = VersionService()
    #         version_service.notify_update_available()
    #     except Exception:
    #         pass  # Silently ignore if update check fails

    # If no command was invoked and no upgrade flags, show help
    if ctx.invoked_subcommand is None and not upgrade and not upgrade_check:
        console.print(ctx.get_help())
        ctx.exit()


# Add commands to CLI group after defining the cli function
# Add commands directly to the cli group
cli.add_command(analyze)
cli.add_command(hooks)
cli.add_command(service)
cli.add_command(app)
cli.add_command(setup)
cli.add_command(audit)
cli.add_command(issues)
cli.add_command(mcp)
cli.add_command(config)
cli.add_command(workflow)
cli.add_command(ui)
cli.add_command(agents)

# Note: update command removed - upgrade functionality moved to --upgrade flag


if __name__ == '__main__':
    import sys
    # Debug: track execution
    if '--debug-trace' in sys.argv:
        print(f"[DEBUG] Running as __main__, argv={sys.argv}", file=sys.stderr)
        sys.argv.remove('--debug-trace')
    cli()