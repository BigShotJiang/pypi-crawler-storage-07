"""
Workflow manager for GitHub issue integration and approval workflow.
"""

import uuid
import yaml
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional

from ..core.common import console, print_success, print_error, print_info, ensure_path_exists
from ..core.exceptions import ValidationError, NotFoundError
from ..services.issues.service import IssuesService
from ..registries.manager import get_registry_manager
from ..providers.llm.manager import get_llm_manager
from .executor import WorkflowExecutor
from .models import (
    WorkflowApproval, GitHubIssueWorkflow, WorkflowExecution,
    ArchitectAnalysis, ApprovalStatus
)


class WorkflowManager:
    """
    Manages the complete workflow lifecycle from GitHub issues to implementation.

    Integrates:
    1. GitHub issues service
    2. Architect agent for analysis
    3. Dynamic workflow generation
    4. Approval system
    5. Workflow execution
    """

    def __init__(self):
        self.issues_service = IssuesService()
        self.registry = get_registry_manager()
        self.workflow_executor = WorkflowExecutor()
        self.llm_manager = get_llm_manager()

        # Storage paths
        self.workflows_dir = Path("docs/workflows")
        self.executions_dir = Path("docs/executions")
        self.approvals_dir = Path("docs/approvals")

        # In-memory storage for active items
        self.active_executions: Dict[str, WorkflowExecution] = {}
        self.pending_approvals: Dict[str, WorkflowApproval] = {}

        # Ensure directories exist
        ensure_path_exists(self.workflows_dir)
        ensure_path_exists(self.executions_dir)
        ensure_path_exists(self.approvals_dir)

        # Load existing executions from files
        self._load_execution_records()

    def create_workflow_from_issue(
        self,
        issue_id: str,
        services: Optional[List[str]] = None,
        auto_approve: bool = False
    ) -> Dict[str, Any]:
        """
        Create workflow from GitHub issue.

        Args:
            issue_id: GitHub issue ID
            services: Optional list of services to limit scope
            auto_approve: Skip approval and execute immediately

        Returns:
            Result containing workflow and execution info
        """
        try:
            print_info(f"Creating workflow from GitHub issue: {issue_id}")

            # Step 1: Fetch GitHub issue
            issue_data = self._fetch_issue_data(issue_id, services)

            # Step 2: Run architect agent analysis
            analysis = self._run_architect_analysis(issue_data, services)

            # Step 3: Create workflow definition
            workflow = self._create_workflow_from_analysis(issue_data, analysis)

            # Step 4: Create execution instance
            execution = self._create_execution_instance(workflow)

            # Step 5: Handle approval or auto-execute
            if auto_approve or not workflow.requires_approval:
                self._start_execution(execution)
                status = "executing"
            else:
                approval = self._create_approval_request(execution)
                status = "waiting_approval"

            result = {
                "success": True,
                "workflow": workflow,
                "execution": execution,
                "status": status,
                "workflow_url": f"/workflows/{workflow.workflow_id}",
                "execution_url": f"/executions/{execution.id}"
            }

            if status == "waiting_approval":
                result["approval_url"] = f"/approvals/{approval.id}"

            print_success(f"Workflow created: {workflow.workflow_id}")
            return result

        except Exception as e:
            print_error(f"Failed to create workflow from issue: {str(e)}")
            return {"success": False, "error": str(e)}

    def approve_workflow(self, approval_id: str, approved: bool, comments: Optional[str] = None) -> Dict[str, Any]:
        """
        Process workflow approval.

        Args:
            approval_id: Approval request ID
            approved: Whether approved or rejected
            comments: Optional approval comments

        Returns:
            Result of approval processing
        """
        try:
            approval = self.pending_approvals.get(approval_id)
            if not approval:
                raise NotFoundError(f"Approval {approval_id} not found")

            # Update approval
            approval.status = ApprovalStatus.APPROVED if approved else ApprovalStatus.REJECTED
            approval.approved_at = datetime.now()
            approval.approved_by = "user"  # TODO: Get from auth context
            approval.comments = comments

            # Get associated execution
            execution = self.active_executions.get(approval.workflow_execution_id)
            if not execution:
                raise NotFoundError(f"Execution {approval.workflow_execution_id} not found")

            if approved:
                # Start execution
                self._start_execution(execution)
                result = {
                    "success": True,
                    "status": "approved",
                    "message": "Workflow approved and started",
                    "execution_url": f"/executions/{execution.id}"
                }
            else:
                # Cancel execution
                execution.status = "cancelled"
                execution.completed_at = datetime.now()
                result = {
                    "success": True,
                    "status": "rejected",
                    "message": "Workflow rejected and cancelled"
                }

            # Remove from pending approvals
            del self.pending_approvals[approval_id]

            # Save approval record
            self._save_approval_record(approval)

            print_info(f"Approval processed: {approval_id} - {'approved' if approved else 'rejected'}")
            return result

        except Exception as e:
            print_error(f"Failed to process approval: {str(e)}")
            return {"success": False, "error": str(e)}

    def get_active_executions(self) -> List[WorkflowExecution]:
        """Get all active workflow executions."""
        return list(self.active_executions.values())

    def get_pending_approvals(self) -> List[WorkflowApproval]:
        """Get all pending approvals."""
        return list(self.pending_approvals.values())

    def get_execution(self, execution_id: str) -> Optional[WorkflowExecution]:
        """Get execution by ID."""
        return self.active_executions.get(execution_id)

    def cancel_execution(self, execution_id: str) -> Dict[str, Any]:
        """Cancel workflow execution."""
        try:
            execution = self.active_executions.get(execution_id)
            if not execution:
                raise NotFoundError(f"Execution {execution_id} not found")

            execution.status = "cancelled"
            execution.completed_at = datetime.now()

            print_info(f"Cancelled execution: {execution_id}")
            return {"success": True, "message": "Execution cancelled"}

        except Exception as e:
            print_error(f"Failed to cancel execution: {str(e)}")
            return {"success": False, "error": str(e)}

    def _fetch_issue_data(self, issue_id: str, services: Optional[List[str]]) -> Dict[str, Any]:
        """Fetch GitHub issue data."""
        # This would use the issues service to fetch real issue data
        # For now, return mock data
        return {
            "id": issue_id,
            "title": f"Implement feature for issue #{issue_id}",
            "description": "Feature implementation request",
            "labels": ["enhancement", "feature"],
            "assignees": [],
            "state": "open",
            "url": f"https://github.com/org/repo/issues/{issue_id}"
        }

    def _run_architect_analysis(self, issue_data: Dict[str, Any], services: Optional[List[str]]) -> ArchitectAnalysis:
        """Run architect agent to analyze requirements and generate workflow."""
        print_info("Running architect agent analysis...")

        # Prepare architect agent input
        architect_input = {
            "issue": issue_data,
            "services": [
                {
                    "id": s.name,
                    "name": s.name,
                    "repo_url": s.repo_url,
                    "description": s.description,
                    "application": s.application
                }
                for s in self.registry.services.list_services()
                if not services or s.name in services
            ],
            "context": {
                "repository_structure": {},
                "existing_services": len(self.registry.services.list_services()),
                "application_context": {}
            }
        }

        # TODO: Run actual architect agent here
        # For now, generate a realistic dynamic workflow based on issue analysis

        # Analyze issue type and complexity
        issue_type = self._determine_issue_type(issue_data)
        complexity = self._determine_complexity(issue_data, services)

        # Generate workflow steps based on analysis
        workflow_steps = self._generate_workflow_steps(issue_type, complexity, services)

        return ArchitectAnalysis(
            issue_type=issue_type,
            complexity=complexity,
            estimated_effort=self._estimate_effort(complexity),
            requirements=self._extract_requirements(issue_data),
            affected_services=self._identify_affected_services(issue_data, services),
            workflow_steps=workflow_steps
        )

    def _determine_issue_type(self, issue_data: Dict[str, Any]) -> str:
        """Determine issue type from labels and content."""
        labels = [label.lower() for label in issue_data.get("labels", [])]
        title = issue_data.get("title", "").lower()
        description = issue_data.get("description", "").lower()

        if any(label in labels for label in ["bug", "fix", "error"]):
            return "bug"
        elif any(label in labels for label in ["security", "vulnerability"]):
            return "security"
        elif any(label in labels for label in ["performance", "optimization"]):
            return "performance"
        elif any(word in title + description for word in ["refactor", "cleanup", "restructure"]):
            return "refactor"
        elif any(label in labels for label in ["enhancement", "improvement"]):
            return "enhancement"
        else:
            return "feature"

    def _determine_complexity(self, issue_data: Dict[str, Any], services: Optional[List[str]]) -> str:
        """Determine complexity based on scope and requirements."""
        description_length = len(issue_data.get("description", ""))
        services_count = len(services) if services else 1

        if description_length > 1000 or services_count > 3:
            return "high"
        elif description_length > 500 or services_count > 1:
            return "medium"
        else:
            return "low"

    def _estimate_effort(self, complexity: str) -> str:
        """Estimate effort based on complexity."""
        effort_map = {
            "low": "1-2 days",
            "medium": "3-5 days",
            "high": "1-2 weeks"
        }
        return effort_map.get(complexity, "3-5 days")

    def _extract_requirements(self, issue_data: Dict[str, Any]) -> Dict[str, Any]:
        """Extract requirements from issue data."""
        return {
            "functional": [
                {"requirement": f"Implement: {issue_data.get('title', 'Feature')}", "priority": "must"}
            ],
            "non_functional": [
                {"category": "security", "requirement": "Follow security best practices"},
                {"category": "performance", "requirement": "Maintain system performance"},
                {"category": "maintainability", "requirement": "Write clean, maintainable code"}
            ]
        }

    def _identify_affected_services(self, issue_data: Dict[str, Any], services: Optional[List[str]]) -> List[Dict[str, Any]]:
        """Identify which services will be affected."""
        if not services:
            # Try to infer from issue content
            services = ["user-identity-service"]  # Default fallback

        return [
            {
                "service_id": service,
                "impact_type": "major",
                "changes_required": [
                    {"type": "api", "description": f"Update {service} for issue requirements", "effort": "medium"}
                ]
            }
            for service in services
        ]

    def _generate_workflow_steps(self, issue_type: str, complexity: str, services: Optional[List[str]]) -> List[Dict[str, Any]]:
        """Generate dynamic workflow steps based on issue analysis."""
        steps = []

        # Step 1: Always start with analysis
        steps.append({
            "id": "analyze_requirements",
            "type": "agent",
            "agent": "architect",  # Use architect for deeper analysis
            "description": "Analyze requirements and create implementation plan",
            "approval_required": False,
            "estimated_duration": "30 minutes"
        })

        # Step 2: Documentation analysis (if needed)
        if issue_type in ["feature", "enhancement", "refactor"]:
            steps.append({
                "id": "analyze_codebase",
                "type": "agent",
                "agent": "documentation",
                "description": "Analyze existing codebase and architecture",
                "depends_on": ["analyze_requirements"],
                "approval_required": False,
                "estimated_duration": "45 minutes"
            })

        # Step 3: Implementation
        steps.append({
            "id": "implement_changes",
            "type": "agent",
            "agent": "implementation",
            "description": f"Implement {issue_type} changes",
            "depends_on": ["analyze_codebase"] if "analyze_codebase" in [s["id"] for s in steps] else ["analyze_requirements"],
            "approval_required": complexity == "high",  # Require approval for complex changes
            "estimated_duration": "2-4 hours" if complexity == "low" else "1-2 days"
        })

        # Step 4: Testing (always include)
        steps.append({
            "id": "generate_tests",
            "type": "agent",
            "agent": "test_generator",
            "description": "Generate comprehensive tests",
            "depends_on": ["implement_changes"],
            "approval_required": False,
            "estimated_duration": "1 hour"
        })

        # Step 5: Security review (for security issues or complex changes)
        if issue_type == "security" or complexity == "high":
            steps.append({
                "id": "security_review",
                "type": "agent",
                "agent": "security",
                "description": "Perform security analysis and review",
                "depends_on": ["implement_changes"],
                "approval_required": False,
                "estimated_duration": "30 minutes"
            })

        # Step 6: Performance check (for performance issues or complex changes)
        if issue_type == "performance" or complexity in ["medium", "high"]:
            steps.append({
                "id": "performance_analysis",
                "type": "agent",
                "agent": "performance",
                "description": "Analyze performance impact",
                "depends_on": ["implement_changes"],
                "approval_required": False,
                "estimated_duration": "45 minutes"
            })

        # Step 7: Final audit (for complex changes)
        if complexity in ["medium", "high"]:
            # Find all previous step IDs to depend on
            previous_steps = [s["id"] for s in steps if s["id"] != "analyze_requirements"]

            steps.append({
                "id": "final_audit",
                "type": "agent",
                "agent": "audit_report",
                "description": "Comprehensive code audit and quality review",
                "depends_on": previous_steps,
                "approval_required": True,  # Always require approval for final audit
                "estimated_duration": "30 minutes"
            })

        return steps

    def _create_workflow_from_analysis(self, issue_data: Dict[str, Any], analysis: ArchitectAnalysis) -> GitHubIssueWorkflow:
        """Create workflow from architect analysis."""
        workflow_id = f"workflow_{uuid.uuid4().hex[:8]}"

        workflow = GitHubIssueWorkflow(
            issue_id=issue_data["id"],
            issue_title=issue_data["title"],
            issue_url=issue_data.get("url"),
            issue_labels=issue_data.get("labels", []),
            requirements=analysis.requirements,
            affected_services=[s["service_id"] for s in analysis.affected_services],
            complexity=analysis.complexity,
            estimated_effort=analysis.estimated_effort,
            workflow_id=workflow_id,
            requires_approval=True
        )

        # Save workflow definition
        workflow_file = self.workflows_dir / f"{workflow_id}.yaml"
        with open(workflow_file, 'w') as f:
            yaml.dump({
                "workflow": workflow.dict(),
                "analysis": analysis.dict(),
                "steps": analysis.workflow_steps
            }, f, default_flow_style=False)

        return workflow

    def _create_execution_instance(self, workflow: GitHubIssueWorkflow) -> WorkflowExecution:
        """Create execution instance."""
        execution_id = str(uuid.uuid4())

        execution = WorkflowExecution(
            id=execution_id,
            workflow_id=workflow.workflow_id,
            github_issue=workflow,
            status="pending"
        )

        self.active_executions[execution_id] = execution
        self._save_execution_record(execution)
        return execution

    def _create_approval_request(self, execution: WorkflowExecution) -> WorkflowApproval:
        """Create approval request."""
        approval_id = str(uuid.uuid4())

        approval = WorkflowApproval(
            id=approval_id,
            workflow_execution_id=execution.id,
            step_id="workflow_start",
            title=f"Approve Workflow: {execution.github_issue.issue_title}",
            description=f"Review and approve the generated workflow for GitHub issue #{execution.github_issue.issue_id}",
            context={
                "issue": execution.github_issue.dict(),
                "affected_services": execution.github_issue.affected_services,
                "complexity": execution.github_issue.complexity
            }
        )

        self.pending_approvals[approval_id] = approval
        return approval

    def _start_execution(self, execution: WorkflowExecution) -> None:
        """Start workflow execution."""
        execution.status = "running"
        self._save_execution_record(execution)
        execution.started_at = datetime.now()
        self._save_execution_record(execution)

        print_info(f"Starting workflow execution: {execution.id}")

        # Start the actual workflow execution with dynamic workflow creation
        try:
            # Execute workflow with dynamic step creation
            import threading
            thread = threading.Thread(
                target=self._execute_dynamic_workflow,
                args=(execution,)
            )
            thread.daemon = True
            thread.start()
        except Exception as e:
            print_error(f"Failed to start workflow execution: {str(e)}")
            execution.status = "failed"
            execution.errors.append(str(e))
            self._save_execution_record(execution)

    def _execute_dynamic_workflow(self, execution: WorkflowExecution) -> None:
        """Execute workflow with dynamic step creation from architect agent."""
        try:
            # Step 1: Run architect agent to create workflow plan
            print_info("Running architect agent for workflow planning...")

            architect_step = {
                "id": "workflow_planning",
                "agent": "architect",
                "description": "Create implementation plan and dynamic workflow"
            }

            execution.current_step = "workflow_planning"
            self._save_execution_record(execution)

            # Execute architect agent
            architect_agent = self.registry.agents.get_agent("architect")
            if not architect_agent:
                raise ValueError("Architect agent not found")

            architect_result = self._execute_agent_with_claude(architect_agent, execution, architect_step)

            # Store architect result
            execution.step_results["workflow_planning"] = architect_result
            execution.completed_steps.append("workflow_planning")
            self._save_execution_record(execution)

            # Step 2: Parse workflow steps from architect output
            if architect_result.get("status") == "completed":
                architect_output = architect_result.get("output", "")
                dynamic_steps = self._parse_workflow_from_output(architect_output)

                # Step 3: Execute the dynamic workflow steps
                self._execute_workflow_steps(execution, dynamic_steps)
            else:
                raise ValueError("Architect agent failed to create workflow plan")

        except Exception as e:
            print_error(f"Dynamic workflow execution failed: {str(e)}")
            execution.status = "failed"
            execution.errors.append(str(e))
            self._save_execution_record(execution)

    def _execute_workflow_steps(self, execution: WorkflowExecution, steps: List[Dict[str, Any]]) -> None:
        """Execute workflow steps sequentially."""
        if not steps:
            print_info("No workflow steps to execute")
            execution.status = "completed"
            execution.completed_at = datetime.now()
            return

        # Execute steps sequentially
        for i, step in enumerate(steps):
            step_id = step.get('id', f'step_{i}')
            agent_name = step.get('agent')

            print_info(f"Executing step {step_id} with agent {agent_name}")
            execution.current_step = step_id

            try:
                # Execute the agent
                self._execute_agent_step(execution, step)
                execution.completed_steps.append(step_id)
                print_success(f"Step {step_id} completed successfully")

            except Exception as e:
                print_error(f"Step {step_id} failed: {str(e)}")
                execution.failed_steps.append(step_id)
                execution.errors.append({
                    "step_id": step_id,
                    "agent": agent_name,
                    "error": str(e)
                })

                # Check if this step is critical - if so, stop execution
                if step.get('critical', True):  # Default to critical unless specified
                    execution.status = "failed"
                    execution.completed_at = datetime.now()
                    return

        # All steps completed successfully
        execution.status = "completed"
        execution.completed_at = datetime.now()
        print_success(f"Workflow execution {execution.id} completed successfully")

    def _execute_agent_step(self, execution: WorkflowExecution, step: Dict[str, Any]) -> None:
        """Execute a single agent step using Claude CLI."""
        agent_name = step.get('agent')
        if not agent_name:
            raise ValueError(f"No agent specified for step {step.get('id')}")

        # Get the agent from registry
        agent = self.registry.agents.get_agent(agent_name)
        if not agent:
            raise ValueError(f"Agent '{agent_name}' not found in registry")

        print_info(f"Running agent: {agent.display_name}")

        # Execute agent using Claude CLI
        result = self._execute_agent_with_claude(agent, execution, step)

        # Store step result
        execution.step_results[step.get('id')] = result

        # Save updated execution to file
        self._save_execution_record(execution)

    def _execute_agent_with_claude(self, agent: Any, execution: WorkflowExecution, step: Dict[str, Any]) -> Dict[str, Any]:
        """Execute agent using LLM manager."""
        import time
        from pathlib import Path

        start_time = time.time()

        try:
            # Create agent-specific prompt based on agent type and GitHub issue
            prompt = self._create_agent_prompt(agent, execution, step)

            # Prepare context for the agent
            context = {
                "prompt": prompt,
                "agent_name": agent.display_name,
                "agent_id": agent.id,
                "step_description": step.get('description', step.get('id')),
                "issue": execution.github_issue.dict(),
                "step": step,
                "project_path": str(Path.cwd()),
                "requirements": execution.github_issue.requirements,
                "affected_services": execution.github_issue.affected_services,
                "agent_template_file": f"src/microforge/resources/agent_templates/{agent.file_name}"
            }

            print_info(f"Executing agent {agent.display_name} via LLM manager")

            # Use LLM manager to execute the agent
            from ..providers.llm.base import LLMRequest
            response = self.llm_manager.provider.execute(
                LLMRequest(
                    command_type="agent_execution",
                    context=context,
                    interactive=False
                )
            )

            execution_time = time.time() - start_time

            if response.success:
                return {
                    "agent": agent.id,
                    "status": "completed",
                    "output": response.output or f"Agent {agent.display_name} executed successfully",
                    "execution_time": f"{execution_time:.1f}s",
                    "provider": self.llm_manager.get_provider_info()['name']
                }
            else:
                return {
                    "agent": agent.id,
                    "status": "failed",
                    "output": response.output or f"Agent {agent.display_name} execution failed",
                    "execution_time": f"{execution_time:.1f}s",
                    "error": response.error or "LLM execution failed"
                }

        except Exception as e:
            execution_time = time.time() - start_time
            return {
                "agent": agent.id,
                "status": "failed",
                "output": f"Agent execution failed: {str(e)}",
                "execution_time": f"{execution_time:.1f}s",
                "error": str(e)
            }

    def _create_agent_prompt(self, agent: Any, execution: WorkflowExecution, step: Dict[str, Any]) -> str:
        """Create agent-specific prompt based on agent type and GitHub issue details."""
        issue = execution.github_issue

        # Base prompt with issue details
        base_prompt = f"""
You are the {agent.display_name} for Microforge AI. You are working on implementing GitHub issue #{issue.issue_id}.

## GitHub Issue Details
**Title:** {issue.issue_title}
**Issue ID:** #{issue.issue_id}
**Complexity:** {issue.complexity}
**Estimated Effort:** {issue.estimated_effort or 'Not specified'}

## Requirements
"""

        # Add requirements details
        if issue.requirements:
            if issue.requirements.get('functional'):
                base_prompt += "\n### Functional Requirements:\n"
                for req in issue.requirements['functional']:
                    base_prompt += f"- {req.get('requirement', req)}\n"

            if issue.requirements.get('non_functional'):
                base_prompt += "\n### Non-Functional Requirements:\n"
                for req in issue.requirements['non_functional']:
                    if isinstance(req, dict):
                        base_prompt += f"- {req.get('category', 'General')}: {req.get('requirement', req)}\n"
                    else:
                        base_prompt += f"- {req}\n"

        # Add affected services
        if issue.affected_services:
            base_prompt += f"\n## Affected Services\n"
            for service in issue.affected_services:
                base_prompt += f"- {service}\n"

        # Agent-specific instructions
        if agent.id == "architect":
            base_prompt += """

## Your Task as Architect Agent
Analyze this GitHub issue and create a comprehensive implementation plan with a structured workflow.

**IMPORTANT**: Your response must end with a structured workflow section in the following EXACT format:

```yaml
WORKFLOW_STEPS:
  - id: step_1_name
    agent: agent_name
    description: "Step description"
    estimated_duration: "time estimate"
    approval_required: false
  - id: step_2_name
    agent: agent_name
    description: "Step description"
    estimated_duration: "time estimate"
    approval_required: true
```

## Your Analysis Should Include:

1. **Requirements Analysis**: Break down the requirements and identify key implementation points
2. **Architecture Review**: Analyze the current codebase structure and identify what needs to be modified
3. **Implementation Strategy**: Create a step-by-step plan for implementation
4. **Risk Assessment**: Identify potential challenges and mitigation strategies
5. **Documentation Plan**: Outline what documentation needs to be created or updated
6. **Dynamic Workflow Creation**: Generate specific workflow steps based on the issue complexity

## Available Agents:
- `architect`: For analysis and planning
- `documentation`: For code analysis and documentation
- `implementation`: For writing and modifying code
- `test_generator`: For creating tests
- `security`: For security reviews
- `performance`: For performance optimization

Please provide a detailed analysis and then output the structured workflow steps.
"""

        elif agent.id == "documentation":
            base_prompt += """

## Your Task as Documentation Agent
Analyze the codebase and create comprehensive documentation for the implementation. You should:

1. **Code Structure Analysis**: Understand the current codebase structure
2. **API Documentation**: Document any new APIs or changes to existing ones
3. **Usage Examples**: Provide clear examples of how to use new features
4. **Architecture Documentation**: Document architectural decisions and patterns
5. **README Updates**: Update relevant README files with new information

Please analyze the codebase and create the necessary documentation.
"""

        elif agent.id == "implementation":
            base_prompt += """

## Your Task as Implementation Agent
Implement the changes required for this GitHub issue. You should:

1. **Code Implementation**: Write the actual code changes needed
2. **File Modifications**: Update existing files as required
3. **New File Creation**: Create new files if needed
4. **Configuration Updates**: Update configuration files as needed
5. **Integration**: Ensure all changes work together properly

Please implement all the necessary changes to fulfill this GitHub issue.
"""

        elif agent.id == "test_generator":
            base_prompt += """

## Your Task as Test Generator Agent
Create comprehensive tests for the implementation. You should:

1. **Unit Tests**: Create unit tests for individual functions and classes
2. **Integration Tests**: Create tests that verify components work together
3. **End-to-End Tests**: Create tests that verify the entire workflow
4. **Test Coverage**: Ensure good test coverage for the new functionality
5. **Test Documentation**: Document how to run and maintain the tests

Please create a comprehensive test suite for this implementation.
"""

        else:
            base_prompt += f"""

## Your Task as {agent.display_name}
Execute the step: {step.get('description', step.get('id'))}

Please complete the assigned task for this GitHub issue implementation.
"""

        base_prompt += f"""

## Current Working Directory
{Path.cwd()}

## Next Steps
Please analyze the current codebase and complete your assigned task. Use the available tools to read files, make changes, and ensure the implementation meets all requirements.
"""

        return base_prompt.strip()

    def _parse_workflow_from_output(self, architect_output: str) -> List[Dict[str, Any]]:
        """Parse workflow steps from architect agent output."""
        import re

        # Extract YAML workflow section
        pattern = r'```yaml\s*WORKFLOW_STEPS:\s*(.*?)\s*```'
        match = re.search(pattern, architect_output, re.DOTALL | re.IGNORECASE)

        if not match:
            print_warning("No structured workflow found in architect output, using default workflow")
            return self._create_default_workflow_steps()

        try:
            # Parse the YAML workflow section
            workflow_yaml = "WORKFLOW_STEPS:\n" + match.group(1)
            import yaml
            workflow_data = yaml.safe_load(workflow_yaml)

            if 'WORKFLOW_STEPS' in workflow_data:
                steps = workflow_data['WORKFLOW_STEPS']
                print_success(f"Parsed {len(steps)} dynamic workflow steps from architect")
                return steps
            else:
                print_warning("Invalid workflow format, using default workflow")
                return self._create_default_workflow_steps()

        except Exception as e:
            print_error(f"Failed to parse workflow YAML: {str(e)}")
            return self._create_default_workflow_steps()

    def _create_default_workflow_steps(self) -> List[Dict[str, Any]]:
        """Create default workflow steps as fallback."""
        return [
            {
                "id": "analyze_codebase",
                "agent": "documentation",
                "description": "Analyze existing codebase structure",
                "estimated_duration": "30 minutes",
                "approval_required": False
            },
            {
                "id": "implement_changes",
                "agent": "implementation",
                "description": "Implement the required changes",
                "estimated_duration": "2 hours",
                "approval_required": False
            },
            {
                "id": "generate_tests",
                "agent": "test_generator",
                "description": "Generate comprehensive tests",
                "estimated_duration": "1 hour",
                "approval_required": False
            }
        ]

    def _save_approval_record(self, approval: WorkflowApproval) -> None:
        """Save approval record to file."""
        approval_file = self.approvals_dir / f"{approval.id}.yaml"
        with open(approval_file, 'w') as f:
            yaml.dump(approval.dict(), f, default_flow_style=False)

    def _save_execution_record(self, execution: WorkflowExecution) -> None:
        """Save execution record to file."""
        execution_file = self.executions_dir / f"{execution.id}.yaml"
        try:
            # Use model_dump() for Pydantic v2, fallback to dict() for v1
            execution_data = execution.model_dump() if hasattr(execution, 'model_dump') else execution.dict()
            with open(execution_file, 'w') as f:
                yaml.dump(execution_data, f, default_flow_style=False)
        except Exception as e:
            print_error(f"Failed to save execution record: {str(e)}")

    def _load_execution_records(self) -> None:
        """Load all execution records from files."""
        if not self.executions_dir.exists():
            return

        for execution_file in self.executions_dir.glob("*.yaml"):
            try:
                with open(execution_file, 'r') as f:
                    execution_data = yaml.safe_load(f)

                execution = WorkflowExecution(**execution_data)
                self.active_executions[execution.id] = execution
                print_info(f"Loaded execution: {execution.id}")
            except Exception as e:
                print_error(f"Failed to load execution from {execution_file}: {str(e)}")

    def _update_execution(self, execution: WorkflowExecution, **kwargs) -> None:
        """Update execution properties and save to file."""
        for key, value in kwargs.items():
            if hasattr(execution, key):
                setattr(execution, key, value)
        self._save_execution_record(execution)