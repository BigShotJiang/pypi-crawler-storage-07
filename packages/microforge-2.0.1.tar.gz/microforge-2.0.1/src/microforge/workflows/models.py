"""
Extended workflow models for GitHub integration and approval system.
"""

from datetime import datetime
from enum import Enum
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field


class ApprovalStatus(str, Enum):
    """Approval status."""
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    TIMEOUT = "timeout"


class WorkflowApproval(BaseModel):
    """Workflow approval request."""
    id: str
    workflow_execution_id: str
    step_id: str

    # Approval details
    status: ApprovalStatus = ApprovalStatus.PENDING
    requested_at: datetime = Field(default_factory=datetime.now)
    requested_by: str = "system"

    # Approval content
    title: str
    description: str
    context: Dict[str, Any] = Field(default_factory=dict)
    options: List[str] = Field(default_factory=list)

    # Response
    approved_at: Optional[datetime] = None
    approved_by: Optional[str] = None
    response: Optional[str] = None
    comments: Optional[str] = None

    # Configuration
    timeout_minutes: int = 60
    auto_approve: bool = False


class GitHubIssueWorkflow(BaseModel):
    """Workflow created from GitHub issue."""
    issue_id: str
    issue_title: str
    issue_url: Optional[str] = None
    issue_labels: List[str] = Field(default_factory=list)

    # Architect analysis results
    requirements: Dict[str, Any] = Field(default_factory=dict)
    affected_services: List[str] = Field(default_factory=list)
    complexity: str = "medium"
    estimated_effort: Optional[str] = None

    # Workflow metadata
    workflow_id: str
    created_at: datetime = Field(default_factory=datetime.now)
    requires_approval: bool = True


class WorkflowExecution(BaseModel):
    """Extended workflow execution with approval support."""
    id: str
    workflow_id: str

    # GitHub context
    github_issue: Optional[GitHubIssueWorkflow] = None

    # Execution state
    status: str = "pending"  # pending, running, waiting_approval, completed, failed, cancelled
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None

    # Progress tracking
    current_step: Optional[str] = None
    completed_steps: List[str] = Field(default_factory=list)
    failed_steps: List[str] = Field(default_factory=list)
    pending_approvals: List[str] = Field(default_factory=list)

    # Results and artifacts
    step_results: Dict[str, Any] = Field(default_factory=dict)
    artifacts: List[str] = Field(default_factory=list)
    errors: List[str] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)


class ArchitectAnalysis(BaseModel):
    """Result from architect agent analysis."""
    issue_type: str  # feature, bug, enhancement, refactor, security, performance
    complexity: str  # low, medium, high, critical
    estimated_effort: str

    requirements: Dict[str, List[Dict[str, Any]]] = Field(default_factory=dict)
    affected_services: List[Dict[str, Any]] = Field(default_factory=list)
    dependencies: List[Dict[str, Any]] = Field(default_factory=list)
    architecture_decisions: List[Dict[str, Any]] = Field(default_factory=list)
    risks: List[Dict[str, Any]] = Field(default_factory=list)

    # Generated workflow
    workflow_steps: List[Dict[str, Any]] = Field(default_factory=list)
    validation_criteria: List[Dict[str, Any]] = Field(default_factory=list)