"""
LangGraph-based workflow graph implementation.

This module creates and manages the workflow graph using LangGraph's StateGraph.
"""

from typing import Dict, Any, List, Optional, Callable

try:
    from langgraph.graph import StateGraph, END
    from langgraph.checkpoint import MemorySaver
    LANGGRAPH_AVAILABLE = True
except ImportError:
    # LangGraph not installed - workflow functionality will be limited
    StateGraph = None
    END = None
    MemorySaver = None
    LANGGRAPH_AVAILABLE = False

from .state import WorkflowState
from ..registries.manager import get_registry_manager
from ..services.agents.service import AgentsService
from ..services.agents.models import AgentExecutionRequest
from ..core.common import console, print_info, print_success, print_error


class WorkflowGraph:
    """
    Manages workflow execution using LangGraph.

    This class builds and executes workflow graphs dynamically based on
    workflow definitions from the registry.
    """

    def __init__(self):
        """Initialize the workflow graph manager."""
        self.registry = get_registry_manager()
        self.agents_service = AgentsService()
        self.checkpointer = MemorySaver() if LANGGRAPH_AVAILABLE else None
        self.graph = None
        self.compiled_graph = None

    def build_graph(self, workflow_definition: Dict[str, Any]):
        """
        Build a LangGraph StateGraph from workflow definition.

        Args:
            workflow_definition: Workflow configuration from registry

        Returns:
            Configured StateGraph ready for compilation (or None if LangGraph not available)
        """
        if not LANGGRAPH_AVAILABLE:
            print_error("LangGraph not available - workflow execution will be limited")
            return None

        # Create new state graph
        graph = StateGraph(WorkflowState)

        # Parse workflow steps
        steps = workflow_definition.get("steps", [])

        # Add nodes for each step
        for step in steps:
            node_id = step["id"]
            node_handler = self._create_node_handler(step)
            graph.add_node(node_id, node_handler)

        # Add edges based on dependencies
        for step in steps:
            node_id = step["id"]
            depends_on = step.get("depends_on", [])

            if not depends_on:
                # This is a start node
                graph.set_entry_point(node_id)
            else:
                # Add edges from dependencies
                for dep in depends_on:
                    # Check if this step has conditional routing
                    if "conditions" in step:
                        graph.add_conditional_edges(
                            dep,
                            self._create_condition_handler(step["conditions"]),
                            step.get("branches", {node_id: node_id, "end": END})
                        )
                    else:
                        graph.add_edge(dep, node_id)

        # Add end edges for nodes without successors
        terminal_nodes = self._find_terminal_nodes(steps)
        for terminal in terminal_nodes:
            graph.add_edge(terminal, END)

        self.graph = graph
        return graph

    def _create_node_handler(self, step: Dict[str, Any]) -> Callable:
        """
        Create a node handler function for a workflow step.

        Args:
            step: Step configuration

        Returns:
            Callable that processes the node
        """
        step_type = step.get("type", "agent")

        if step_type == "agent":
            return self._create_agent_handler(step)
        elif step_type == "parallel":
            return self._create_parallel_handler(step)
        elif step_type == "service":
            return self._create_service_handler(step)
        else:
            return self._create_custom_handler(step)

    def _create_agent_handler(self, step: Dict[str, Any]) -> Callable:
        """Create handler for agent execution node."""

        async def execute_agent(state: WorkflowState) -> WorkflowState:
            """Execute an agent and update state."""
            node_id = step["id"]
            agent_name = step.get("agent")

            print_info(f"Executing agent: {agent_name} (node: {node_id})")

            # Update current node
            state["current_node"] = node_id

            # Build context from previous outputs
            context = self._build_context(step, state)

            # Create agent execution request
            request = AgentExecutionRequest(
                agent_name=agent_name,
                service_name=state.get("workflow_name", "workflow"),
                mode="local",
                interactive=True,  # Use interactive Claude mode
                context=context
            )

            try:
                # Execute agent using existing service
                result = self.agents_service.execute_agent(request)

                # Update state with results
                state["outputs"][node_id] = {
                    "success": result.success,
                    "output_files": result.output_files,
                    "errors": result.errors,
                    "warnings": result.warnings
                }

                state["agent_outputs"][node_id] = result

                if result.success:
                    state["completed_nodes"].append(node_id)
                    print_success(f"Agent {agent_name} completed successfully")
                else:
                    state["failed_nodes"].append(node_id)
                    state["errors"].append({
                        "node": node_id,
                        "agent": agent_name,
                        "errors": result.errors
                    })
                    print_error(f"Agent {agent_name} failed")

            except Exception as e:
                state["failed_nodes"].append(node_id)
                state["errors"].append({
                    "node": node_id,
                    "agent": agent_name,
                    "error": str(e)
                })
                print_error(f"Error executing agent {agent_name}: {e}")

            return state

        return execute_agent

    def _create_parallel_handler(self, step: Dict[str, Any]) -> Callable:
        """Create handler for parallel agent execution."""

        async def execute_parallel(state: WorkflowState) -> WorkflowState:
            """Execute multiple agents in parallel."""
            import asyncio

            node_id = step["id"]
            agents = step.get("agents", [])

            print_info(f"Executing {len(agents)} agents in parallel")
            state["current_node"] = node_id

            # Create tasks for parallel execution
            tasks = []
            for agent_name in agents:
                context = self._build_context(step, state)
                request = AgentExecutionRequest(
                    agent_name=agent_name,
                    service_name=state.get("workflow_name", "workflow"),
                    mode="local",
                    batch_mode=True,  # Use batch mode for parallel
                    context=context
                )
                # Create async task
                task = self._execute_agent_async(request, agent_name)
                tasks.append(task)

            # Execute all tasks in parallel
            results = await asyncio.gather(*tasks, return_exceptions=True)

            # Process results
            parallel_outputs = {}
            for agent_name, result in zip(agents, results):
                if isinstance(result, Exception):
                    parallel_outputs[agent_name] = {
                        "success": False,
                        "error": str(result)
                    }
                    state["errors"].append({
                        "node": node_id,
                        "agent": agent_name,
                        "error": str(result)
                    })
                else:
                    parallel_outputs[agent_name] = {
                        "success": result.success,
                        "outputs": result.output_files
                    }

            state["outputs"][node_id] = parallel_outputs
            state["completed_nodes"].append(node_id)

            print_success(f"Parallel execution completed for {node_id}")
            return state

        return execute_parallel

    def _create_service_handler(self, step: Dict[str, Any]) -> Callable:
        """Create handler for service method execution."""

        async def execute_service(state: WorkflowState) -> WorkflowState:
            """Execute a service method."""
            node_id = step["id"]
            service_path = step.get("service")  # e.g., "issues.fetch"

            print_info(f"Executing service: {service_path}")
            state["current_node"] = node_id

            # Parse service and method
            service_name, method_name = service_path.split(".")

            # TODO: Dynamic service invocation
            # For now, handle specific services
            if service_name == "issues":
                from ..services.issues.service import IssuesService
                from ..services.issues.models import IssuesRequest

                service = IssuesService()
                if method_name == "fetch":
                    request = IssuesRequest(
                        issue_numbers=[step.get("inputs", {}).get("issue_id")]
                    )
                    result = service.fetch_issues(request)
                    state["outputs"][node_id] = {
                        "issues": result.issues,
                        "success": result.success
                    }

            state["completed_nodes"].append(node_id)
            return state

        return execute_service

    def _create_custom_handler(self, step: Dict[str, Any]) -> Callable:
        """Create handler for custom node types."""

        async def execute_custom(state: WorkflowState) -> WorkflowState:
            """Execute custom logic."""
            node_id = step["id"]
            state["current_node"] = node_id

            # Custom logic based on step configuration
            print_info(f"Executing custom node: {node_id}")

            state["completed_nodes"].append(node_id)
            return state

        return execute_custom

    def _create_condition_handler(self, conditions: List[Dict[str, Any]]) -> Callable:
        """Create conditional routing handler."""

        def evaluate_condition(state: WorkflowState) -> str:
            """Evaluate conditions and return next node."""

            for condition in conditions:
                if self._evaluate_single_condition(condition, state):
                    return condition.get("goto", END)

            # Default fallback
            return END

        return evaluate_condition

    def _evaluate_single_condition(self, condition: Dict[str, Any], state: WorkflowState) -> bool:
        """Evaluate a single condition against state."""
        # Simple evaluation logic - can be extended
        condition_type = condition.get("if")

        if "audit_score" in condition_type:
            # Example: "audit_score < 70"
            # Parse and evaluate
            return False  # Placeholder

        return False

    def _build_context(self, step: Dict[str, Any], state: WorkflowState) -> Dict[str, Any]:
        """Build context for a step from previous outputs."""
        context = state.get("context", {}).copy()

        # Add outputs from specified nodes
        context_from = step.get("context_from", [])
        for source in context_from:
            if "." in source:
                # Extract specific field
                node_id, field = source.split(".", 1)
                if node_id in state["outputs"]:
                    context[f"{node_id}_{field}"] = state["outputs"][node_id].get(field)
            else:
                # Include all outputs from node
                if source in state["outputs"]:
                    context[source] = state["outputs"][source]

        # Add initial inputs
        context["inputs"] = state.get("initial_inputs", {})

        return context

    def _find_terminal_nodes(self, steps: List[Dict[str, Any]]) -> List[str]:
        """Find nodes that don't have any successors."""
        all_nodes = {step["id"] for step in steps}
        has_successor = set()

        for step in steps:
            depends_on = step.get("depends_on", [])
            has_successor.update(depends_on)

        return list(all_nodes - has_successor)

    async def _execute_agent_async(self, request: AgentExecutionRequest, agent_name: str):
        """Execute agent asynchronously for parallel execution."""
        try:
            result = self.agents_service.execute_agent(request)
            return result
        except Exception as e:
            print_error(f"Failed to execute agent {agent_name}: {e}")
            raise

    def compile(self, workflow_definition: Dict[str, Any]):
        """Compile the workflow graph."""
        self.build_graph(workflow_definition)
        self.compiled_graph = self.graph.compile(checkpointer=self.checkpointer)
        return self.compiled_graph

    async def execute(self, initial_state: WorkflowState, config: Optional[Dict] = None):
        """Execute the compiled workflow graph."""
        if not self.compiled_graph:
            raise ValueError("Workflow graph not compiled. Call compile() first.")

        config = config or {"configurable": {"thread_id": initial_state["workflow_id"]}}

        # Stream execution
        async for output in self.compiled_graph.astream(initial_state, config):
            yield output

        # Yield final state as last output
        final_state = await self.compiled_graph.aget_state(config)
        yield {"final_state": final_state.values}