"""
Workflow executor for orchestrating LangGraph-based workflows.

This module handles the high-level workflow execution, including
initialization, execution, and result processing.
"""

import asyncio
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional, List

from .state import WorkflowState, DynamicWorkflowState
from .graph import WorkflowGraph
from ..registries.manager import get_registry_manager
from ..core.common import console, print_success, print_error, print_info, print_warning
from ..core.exceptions import WorkflowError, NotFoundError
class WorkflowExecutor:
    """
    Executes workflows using LangGraph.

    This class manages workflow lifecycle, from loading definitions
    to executing the graph and processing results.
    """

    def __init__(self):
        """Initialize the workflow executor."""
        self.registry_manager = get_registry_manager()
        self.graph_manager = WorkflowGraph()
        self.state_repository = WorkflowStateRepository()

    async def execute_workflow(
        self,
        workflow_id: str,
        inputs: Dict[str, Any],
        config: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Execute a workflow by ID.

        Args:
            workflow_id: ID of the workflow to execute
            inputs: Input parameters for the workflow
            config: Optional configuration overrides

        Returns:
            Execution results including outputs and metadata
        """
        start_time = time.time()
        execution_id = str(uuid.uuid4())

        console.print(f"\n[bold cyan]🚀 Starting Workflow: {workflow_id}[/bold cyan]")
        console.print(f"[dim]Execution ID: {execution_id}[/dim]\n")

        try:
            # Load workflow definition from registry
            workflow_def = await self._load_workflow_definition(workflow_id)

            # Initialize workflow state
            initial_state = self._create_initial_state(
                workflow_id=execution_id,
                workflow_name=workflow_id,
                inputs=inputs,
                workflow_def=workflow_def
            )

            # Save initial state
            self.state_repository.save_state(execution_id, initial_state)

            # Compile the workflow graph
            print_info("Compiling workflow graph with LangGraph...")
            self.graph_manager.compile(workflow_def)

            # Execute the workflow
            print_info("Executing workflow...")
            final_state = await self._execute_graph(initial_state, config)

            # Process results
            execution_time = time.time() - start_time
            results = self._process_results(final_state, execution_time)

            # Save final state
            self.state_repository.save_state(execution_id, final_state)

            # Display summary
            self._display_execution_summary(results)

            return results

        except Exception as e:
            print_error(f"Workflow execution failed: {str(e)}")
            raise WorkflowError(f"Failed to execute workflow {workflow_id}: {str(e)}")

    async def execute_dynamic_workflow(
        self,
        task_description: str,
        services: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Execute a dynamically generated workflow.

        This method first analyzes the task, generates a workflow,
        then executes it.

        Args:
            task_description: Natural language task description
            services: Optional list of services to limit scope to

        Returns:
            Execution results
        """
        console.print("\n[bold cyan]🧠 Dynamic Workflow Generation[/bold cyan]")
        console.print(f"Task: {task_description}\n")

        # Step 1: Analyze task with planning agent
        print_info("Analyzing task with planning agent...")
        planning_output = await self._run_planning_agent(task_description, services)

        # Step 2: Generate workflow with architect
        print_info("Generating workflow with architect agent...")
        workflow_def = await self._generate_workflow(planning_output)

        # Step 3: Execute the generated workflow
        print_info("Executing generated workflow...")
        inputs = {
            "task_description": task_description,
            "planning_output": planning_output,
            "workflow_definition": workflow_def
        }

        return await self.execute_workflow("dynamic", inputs, {"generated": workflow_def})

    async def _load_workflow_definition(self, workflow_id: str) -> Dict[str, Any]:
        """Load workflow definition from registry."""
        # Try to get from workflow registry (once implemented)
        # For now, return a test workflow
        if workflow_id == "test_workflow":
            return self._get_test_workflow()
        elif workflow_id == "issue_resolver":
            return self._get_issue_resolver_workflow()
        else:
            # Try to load from registry
            workflow = self.registry_manager.workflows.get_workflow(workflow_id)
            if not workflow:
                raise NotFoundError(f"Workflow '{workflow_id}' not found in registry")
            return workflow.dict()

    def _create_initial_state(
        self,
        workflow_id: str,
        workflow_name: str,
        inputs: Dict[str, Any],
        workflow_def: Dict[str, Any]
    ) -> WorkflowState:
        """Create initial workflow state."""
        return WorkflowState(
            workflow_id=workflow_id,
            workflow_name=workflow_name,
            started_at=datetime.now(),
            initial_inputs=inputs.copy(),
            current_inputs=inputs,
            outputs={},
            current_node=None,
            completed_nodes=[],
            failed_nodes=[],
            skipped_nodes=[],
            context={},
            artifacts={},
            agent_outputs={},
            decisions=[],
            next_node=None,
            errors=[],
            warnings=[],
            execution_time={},
            total_execution_time=0.0,
            status="initialized"
        )

    async def _execute_graph(
        self,
        initial_state: WorkflowState,
        config: Optional[Dict[str, Any]] = None
    ) -> WorkflowState:
        """Execute the workflow graph and return final state."""
        initial_state["status"] = "running"

        try:
            # Stream execution updates
            async for update in self.graph_manager.execute(initial_state, config):
                # Process streaming updates
                if isinstance(update, dict):
                    for node_id, node_output in update.items():
                        console.print(f"[dim]Node {node_id} completed[/dim]")

            # Get final state
            final_state = await self.graph_manager.compiled_graph.aget_state(
                config or {"configurable": {"thread_id": initial_state["workflow_id"]}}
            )

            final_values = final_state.values
            final_values["status"] = "completed"
            return final_values

        except Exception as e:
            print_error(f"Graph execution error: {str(e)}")
            initial_state["status"] = "failed"
            initial_state["errors"].append({
                "type": "execution_error",
                "message": str(e),
                "timestamp": datetime.now().isoformat()
            })
            return initial_state

    def _process_results(self, state: WorkflowState, execution_time: float) -> Dict[str, Any]:
        """Process and format execution results."""
        state["total_execution_time"] = execution_time

        results = {
            "workflow_id": state["workflow_id"],
            "workflow_name": state["workflow_name"],
            "status": state["status"],
            "execution_time": execution_time,
            "completed_nodes": state["completed_nodes"],
            "failed_nodes": state["failed_nodes"],
            "outputs": state["outputs"],
            "artifacts": state["artifacts"],
            "errors": state["errors"],
            "warnings": state["warnings"]
        }

        # Add summary statistics
        results["summary"] = {
            "total_nodes": len(state["completed_nodes"]) + len(state["failed_nodes"]),
            "successful_nodes": len(state["completed_nodes"]),
            "failed_nodes": len(state["failed_nodes"]),
            "execution_time_seconds": round(execution_time, 2)
        }

        return results

    def _display_execution_summary(self, results: Dict[str, Any]) -> None:
        """Display execution summary to console."""
        summary = results["summary"]

        if results["status"] == "completed":
            console.print("\n[bold green]✅ Workflow Completed Successfully[/bold green]")
        else:
            console.print("\n[bold red]❌ Workflow Failed[/bold red]")

        console.print("\n[bold]Execution Summary:[/bold]")
        console.print(f"  • Total nodes executed: {summary['total_nodes']}")
        console.print(f"  • Successful: {summary['successful_nodes']}")
        console.print(f"  • Failed: {summary['failed_nodes']}")
        console.print(f"  • Execution time: {summary['execution_time_seconds']}s")

        if results["errors"]:
            console.print("\n[bold red]Errors:[/bold red]")
            for error in results["errors"]:
                console.print(f"  • {error}")

        if results["artifacts"]:
            console.print("\n[bold]Generated Artifacts:[/bold]")
            for name, path in results["artifacts"].items():
                console.print(f"  • {name}: {path}")

    async def _run_planning_agent(
        self,
        task_description: str,
        services: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """Run planning agent to analyze task."""
        # TODO: Implement planning agent execution
        # For now, return mock planning output
        return {
            "task_type": "feature",
            "complexity": "medium",
            "services_affected": services or ["auth-service", "user-service"],
            "requirements": {
                "functional": ["implement feature X"],
                "non_functional": ["performance", "security"]
            }
        }

    async def _generate_workflow(self, planning_output: Dict[str, Any]) -> Dict[str, Any]:
        """Generate workflow definition from planning output."""
        # TODO: Implement architect agent
        # For now, return a basic workflow structure
        return {
            "id": f"dynamic_{uuid.uuid4().hex[:8]}",
            "display_name": "Generated Workflow",
            "steps": [
                {
                    "id": "analyze",
                    "type": "agent",
                    "agent": "documentation"
                },
                {
                    "id": "implement",
                    "type": "agent",
                    "agent": "implementation",
                    "depends_on": ["analyze"]
                }
            ]
        }

    def _get_test_workflow(self) -> Dict[str, Any]:
        """Return a simple test workflow for development."""
        return {
            "id": "test_workflow",
            "display_name": "Test Workflow",
            "description": "Simple workflow for testing",
            "steps": [
                {
                    "id": "step1",
                    "type": "agent",
                    "agent": "documentation",
                    "description": "Analyze codebase"
                },
                {
                    "id": "step2",
                    "type": "agent",
                    "agent": "audit_report",
                    "depends_on": ["step1"],
                    "context_from": ["step1.outputs"]
                }
            ]
        }

    def _get_issue_resolver_workflow(self) -> Dict[str, Any]:
        """Return base issue resolver workflow - actual steps generated by architect agent."""
        return {
            "id": "issue_resolver",
            "display_name": "GitHub Issue Resolver",
            "description": "Resolve GitHub issues with multi-agent orchestration",
            "note": "Actual workflow steps are dynamically generated by the architect agent based on issue analysis",
            "steps": []  # Steps will be populated by architect agent
        }


class WorkflowStateRepository:
    """Repository for persisting workflow states."""

    def __init__(self):
        """Initialize repository - for now, just store in memory."""
        self.states = {}

    def save_state(self, execution_id: str, state: WorkflowState) -> None:
        """Save workflow state to memory."""
        state_data = {
            "execution_id": execution_id,
            "workflow_id": state["workflow_id"],
            "workflow_name": state["workflow_name"],
            "status": state["status"],
            "completed_nodes": state["completed_nodes"],
            "failed_nodes": state["failed_nodes"],
            "outputs": state["outputs"],
            "errors": state["errors"],
            "timestamp": datetime.now().isoformat()
        }
        self.states[execution_id] = state_data

    def get_state(self, execution_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve workflow state by execution ID."""
        return self.states.get(execution_id)