"""
Workflow state management for LangGraph integration.

Defines the state structure that flows through the workflow graph.
"""

from typing import TypedDict, Dict, List, Any, Optional, Annotated
import operator
from datetime import datetime


class WorkflowState(TypedDict):
    """
    State that flows through the workflow graph.

    This state is shared between all nodes in the workflow and accumulates
    information as the workflow progresses.
    """

    # Workflow identification
    workflow_id: str
    workflow_name: str
    started_at: datetime

    # Input/Output tracking
    initial_inputs: Dict[str, Any]
    current_inputs: Dict[str, Any]
    outputs: Dict[str, Any]  # Outputs from each node, keyed by node_id

    # Execution tracking
    current_node: Optional[str]
    completed_nodes: List[str]
    failed_nodes: List[str]
    skipped_nodes: List[str]

    # Context and artifacts
    context: Dict[str, Any]  # Shared context between agents
    artifacts: Dict[str, Any]  # Generated files, code, etc.

    # Agent outputs
    agent_outputs: Dict[str, Any]  # Raw outputs from agent executions

    # Routing decisions
    decisions: List[Dict[str, Any]]  # History of routing decisions
    next_node: Optional[str]  # Next node to execute

    # Error tracking
    errors: List[Dict[str, Any]]
    warnings: List[Dict[str, Any]]

    # Execution metadata
    execution_time: Dict[str, float]  # Time taken by each node
    total_execution_time: float
    status: str  # "running", "completed", "failed", "cancelled"


class DynamicWorkflowState(TypedDict):
    """
    Extended state for dynamically generated workflows.

    Used when workflows are created on-the-fly based on task analysis.
    """

    # All fields from WorkflowState
    workflow_id: str
    workflow_name: str
    started_at: datetime
    initial_inputs: Dict[str, Any]
    current_inputs: Dict[str, Any]
    outputs: Dict[str, Any]
    current_node: Optional[str]
    completed_nodes: List[str]
    failed_nodes: List[str]
    skipped_nodes: List[str]
    context: Dict[str, Any]
    artifacts: Dict[str, Any]
    agent_outputs: Dict[str, Any]
    decisions: List[Dict[str, Any]]
    next_node: Optional[str]
    errors: List[Dict[str, Any]]
    warnings: List[Dict[str, Any]]
    execution_time: Dict[str, float]
    total_execution_time: float
    status: str

    # Dynamic workflow specific
    task_description: str
    planning_output: Dict[str, Any]  # Output from planning agent
    architect_output: Dict[str, Any]  # Output from architect agent
    services_affected: List[str]  # List of services to modify
    workflow_definition: Dict[str, Any]  # Generated workflow structure

    # Service-specific workspaces
    service_workspaces: Dict[str, str]  # service_name -> workspace_path
    service_branches: Dict[str, str]  # service_name -> branch_name

    # Multi-service coordination
    service_dependencies: Dict[str, List[str]]  # service -> [dependencies]
    service_status: Dict[str, str]  # service_name -> status