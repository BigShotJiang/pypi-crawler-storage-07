"""
Factory for creating repository instances.
"""

from typing import Optional
from pathlib import Path

from ..interfaces import RepositoryConfig, StorageBackend
from ..core import GenericRepository
from ..backends.yaml import YamlRepository
from ..backends.database import DatabaseRepository
from ...config.constants import PACKAGE_DIR
from ...config.settings import get_settings


class RepositoryFactory:
    """
    Factory for creating repository instances.

    Handles creation of appropriate repository type based on configuration.
    """

    # Default configurations for each registry type
    REGISTRY_CONFIGS = {
        "services": {
            "entity_key": "services",
            "id_field": "id",
            "file_name": "services.yaml"
        },
        "agents": {
            "entity_key": "agents",
            "id_field": "id",
            "file_name": "agents.yaml"
        },
        "applications": {
            "entity_key": "applications",
            "id_field": "id",
            "file_name": "applications.yaml"
        },
        "hooks": {
            "entity_key": "hooks",
            "id_field": "id",
            "file_name": "hooks.yaml"
        },
        "audit": {
            "entity_key": "audit_logs",
            "id_field": "id",
            "file_name": "audit_logs.yaml"
        },
        "workflows": {
            "entity_key": "workflows",
            "id_field": "id",
            "file_name": "workflows.yaml"
        },
    }

    @staticmethod
    def create_repository(
        registry_type: str,
        storage_backend: Optional[StorageBackend] = None,
        storage_path: Optional[Path] = None,
        connection_string: Optional[str] = None
    ) -> GenericRepository:
        """
        Create a repository for the specified registry type.

        Args:
            registry_type: Type of registry ("services", "agents", etc.)
            storage_backend: Storage backend to use (defaults to settings)
            storage_path: Path for file-based storage
            connection_string: Connection string for database storage

        Returns:
            Repository instance

        Raises:
            ValueError: If registry type is unknown
        """
        # Validate registry type
        if registry_type not in RepositoryFactory.REGISTRY_CONFIGS:
            raise ValueError(f"Unknown registry type: {registry_type}")

        # Get default configuration
        default_config = RepositoryFactory.REGISTRY_CONFIGS[registry_type]

        # Determine storage backend from settings if not provided
        if storage_backend is None:
            settings = get_settings()
            storage_backend = StorageBackend(
                getattr(settings, 'storage_backend', 'yaml')
            )

        # Set default storage path for file-based backends
        if storage_path is None and storage_backend in [StorageBackend.YAML, StorageBackend.JSON]:
            storage_path = PACKAGE_DIR / "registries" / "configs" / default_config["file_name"]

        # Create repository configuration
        config = RepositoryConfig(
            name=registry_type,
            entity_key=default_config["entity_key"],
            id_field=default_config["id_field"],
            storage_backend=storage_backend,
            storage_path=storage_path,
            connection_string=connection_string,
            cache_enabled=True,
            cache_ttl=300  # 5 minutes
        )

        # Create appropriate repository instance
        return RepositoryFactory._create_repository_instance(config)

    @staticmethod
    def _create_repository_instance(config: RepositoryConfig) -> GenericRepository:
        """
        Create repository instance based on storage backend.

        Args:
            config: Repository configuration

        Returns:
            Repository instance

        Raises:
            ValueError: If storage backend is not supported
        """
        if config.storage_backend == StorageBackend.YAML:
            return YamlRepository(config)

        elif config.storage_backend == StorageBackend.JSON:
            # JSON can use YamlRepository with different file extension
            # since both use load_config_file/save_config_file
            return YamlRepository(config)

        elif config.storage_backend == StorageBackend.DATABASE:
            return DatabaseRepository(config)

        else:
            raise ValueError(f"Storage backend not yet implemented: {config.storage_backend}")

    @staticmethod
    def create_service_repository(
        storage_backend: Optional[StorageBackend] = None
    ) -> GenericRepository:
        """Create repository for services."""
        return RepositoryFactory.create_repository("services", storage_backend)

    @staticmethod
    def create_agent_repository(
        storage_backend: Optional[StorageBackend] = None
    ) -> GenericRepository:
        """Create repository for agents."""
        return RepositoryFactory.create_repository("agents", storage_backend)

    @staticmethod
    def create_application_repository(
        storage_backend: Optional[StorageBackend] = None
    ) -> GenericRepository:
        """Create repository for applications."""
        return RepositoryFactory.create_repository("applications", storage_backend)

    @staticmethod
    def create_hook_repository(
        storage_backend: Optional[StorageBackend] = None
    ) -> GenericRepository:
        """Create repository for hooks."""
        return RepositoryFactory.create_repository("hooks", storage_backend)

    @staticmethod
    def create_audit_repository(
        storage_backend: Optional[StorageBackend] = None
    ) -> 'AuditRepository':
        """Create specialized repository for audit logs."""
        from ..audit import AuditRepository

        # Create config for audit
        settings = get_settings()
        backend = storage_backend or StorageBackend(
            getattr(settings, 'storage_backend', 'yaml')
        )

        # Get default configuration
        default_config = RepositoryFactory.REGISTRY_CONFIGS["audit"]
        storage_path = PACKAGE_DIR.parent / ".microforge" / default_config["file_name"]

        config = RepositoryConfig(
            name="audit",
            entity_key=default_config["entity_key"],
            id_field=default_config["id_field"],
            storage_backend=backend,
            storage_path=storage_path,
            cache_enabled=True,
            cache_ttl=60  # Shorter TTL for audit logs
        )

        return AuditRepository(config)

    @staticmethod
    def create_workflow_repository(
        storage_backend: Optional[StorageBackend] = None
    ) -> GenericRepository:
        """Create repository for workflows."""
        return RepositoryFactory.create_repository("workflows", storage_backend)