"""
Migration support for repository data between storage backends.
"""

from typing import Optional

from ..interfaces import StorageBackend
from .factory import RepositoryFactory
from ...core.common import console


class MigrationManager:
    """Manages data migration between storage backends."""

    @staticmethod
    def migrate(
        registry_type: str,
        from_backend: StorageBackend,
        to_backend: StorageBackend,
        to_connection_string: Optional[str] = None
    ) -> bool:
        """
        Migrate data from one storage backend to another.

        Args:
            registry_type: Type of registry to migrate
            from_backend: Current storage backend
            to_backend: Target storage backend
            to_connection_string: Connection string for database backend

        Returns:
            True if migration successful

        Example:
            # Migrate services from YAML to database
            MigrationManager.migrate(
                "services",
                StorageBackend.YAML,
                StorageBackend.DATABASE,
                "postgresql://localhost/microforge"
            )
        """
        try:
            # Create source repository
            source_repo = RepositoryFactory.create_repository(
                registry_type,
                from_backend
            )

            # Load all data
            all_entities = source_repo.find_all()

            # Create target repository
            target_repo = RepositoryFactory.create_repository(
                registry_type,
                to_backend,
                connection_string=to_connection_string
            )

            # Save all data to new backend
            count = target_repo.bulk_save(all_entities)

            console.print(
                f"[green]✅ Migrated {count} {registry_type} "
                f"from {from_backend.value} to {to_backend.value}[/green]"
            )

            return True

        except Exception as e:
            console.print(f"[red]Migration failed: {e}[/red]")
            return False

    @staticmethod
    def backup(
        registry_type: str,
        storage_backend: StorageBackend = StorageBackend.YAML
    ) -> bool:
        """
        Create a backup of registry data.

        Args:
            registry_type: Type of registry to backup
            storage_backend: Storage backend to backup from

        Returns:
            True if backup successful
        """
        try:
            from datetime import datetime
            from pathlib import Path

            # Create source repository
            source_repo = RepositoryFactory.create_repository(
                registry_type,
                storage_backend
            )

            # Load all data
            all_entities = source_repo.find_all()

            # Create backup file name
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = Path(f"backups/{registry_type}_{timestamp}.yaml")
            backup_path.parent.mkdir(exist_ok=True)

            # Save backup
            from ...core.common import save_config_file
            backup_data = {
                "metadata": {
                    "type": "backup",
                    "registry": registry_type,
                    "timestamp": datetime.now().isoformat(),
                    "count": len(all_entities)
                },
                registry_type: {
                    entity.get('id', f'entity_{i}'): entity
                    for i, entity in enumerate(all_entities)
                }
            }

            save_config_file(backup_path, backup_data)

            console.print(
                f"[green]✅ Backed up {len(all_entities)} {registry_type} "
                f"to {backup_path}[/green]"
            )

            return True

        except Exception as e:
            console.print(f"[red]Backup failed: {e}[/red]")
            return False