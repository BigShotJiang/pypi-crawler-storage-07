"""
Generic repository implementation with modular components.
"""

from abc import abstractmethod
from typing import Dict, Any, Optional, List, TypeVar

from ..interfaces import BaseRepository, QueryFilter, RepositoryConfig
from .cache import CacheManager
from .filters import FilterProcessor
# Remove circular import - audit_service decorator not needed here
from ...core.exceptions import NotFoundError, ValidationError

T = TypeVar('T', bound=Dict[str, Any])


class GenericRepository(BaseRepository[T]):
    """
    Generic repository implementation with caching and filtering.

    This class provides common functionality for all storage backends
    while delegating actual storage operations to subclasses.
    """

    def __init__(self, config: RepositoryConfig):
        super().__init__(config.name)
        self.config = config
        self.cache = CacheManager(
            ttl=config.cache_ttl,
            enabled=config.cache_enabled
        )
        self.filter_processor = FilterProcessor()

    @abstractmethod
    def _load_all_entities(self) -> Dict[str, T]:
        """Load all entities from storage (to be implemented by subclasses)."""
        pass

    @abstractmethod
    def _save_all_entities(self, entities: Dict[str, T]) -> None:
        """Save all entities to storage (to be implemented by subclasses)."""
        pass

    def find_by_id(self, entity_id: str) -> Optional[T]:
        """Find entity by ID."""
        entities = self._load_all_entities()
        return entities.get(entity_id)

    def find_all(self, filters: Optional[List[QueryFilter]] = None) -> List[T]:
        """Find all entities with optional filters."""
        entities = self._load_all_entities()

        # Convert dict to list and ensure ID field is present
        results = []
        for entity_id, entity in entities.items():
            if self.config.id_field not in entity:
                entity[self.config.id_field] = entity_id
            results.append(entity)

        # Apply filters if provided
        if filters:
            results = self.filter_processor.apply(results, filters)

        return results

    def save(self, entity: T) -> T:
        """Save entity (insert or update)."""
        # Validate entity has ID
        entity_id = entity.get(self.config.id_field)
        if not entity_id:
            raise ValidationError(
                f"Entity missing required field: {self.config.id_field}",
                field=self.config.id_field
            )

        # Load current entities
        entities = self._load_all_entities()

        # Update or insert
        entities[entity_id] = entity

        # Save back
        self._save_all_entities(entities)

        # Invalidate cache
        self.cache.invalidate()

        return entity

    def delete(self, entity_id: str) -> bool:
        """Delete entity by ID."""
        entities = self._load_all_entities()

        if entity_id not in entities:
            return False

        del entities[entity_id]
        self._save_all_entities(entities)
        self.cache.invalidate()

        return True

    def exists(self, entity_id: str) -> bool:
        """Check if entity exists."""
        entities = self._load_all_entities()
        return entity_id in entities

    def count(self, filters: Optional[List[QueryFilter]] = None) -> int:
        """Count entities."""
        return len(self.find_all(filters))

    def update(self, entity_id: str, updates: Dict[str, Any]) -> Optional[T]:
        """Update specific fields of an entity."""
        entity = self.find_by_id(entity_id)
        if not entity:
            return None

        entity.update(updates)
        return self.save(entity)

    def bulk_save(self, entities: List[T]) -> int:
        """Save multiple entities at once (optimized)."""
        all_entities = self._load_all_entities()
        count = 0

        for entity in entities:
            entity_id = entity.get(self.config.id_field)
            if entity_id:
                all_entities[entity_id] = entity
                count += 1

        if count > 0:
            self._save_all_entities(all_entities)
            self.cache.invalidate()

        return count

    def bulk_delete(self, entity_ids: List[str]) -> int:
        """Delete multiple entities at once (optimized)."""
        entities = self._load_all_entities()
        count = 0

        for entity_id in entity_ids:
            if entity_id in entities:
                del entities[entity_id]
                count += 1

        if count > 0:
            self._save_all_entities(entities)
            self.cache.invalidate()

        return count