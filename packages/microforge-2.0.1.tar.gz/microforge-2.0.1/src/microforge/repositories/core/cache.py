"""
Cache management for repositories.
"""

from typing import Any, Dict, Optional
from time import time


class CacheManager:
    """Manages caching for repository operations."""

    def __init__(self, ttl: int = 300, enabled: bool = True):
        """Initialize cache manager.

        Args:
            ttl: Time-to-live in seconds
            enabled: Whether caching is enabled
        """
        self.ttl = ttl
        self.enabled = enabled
        self._cache: Optional[Dict[str, Any]] = None
        self._timestamp: Optional[float] = None

    def is_valid(self) -> bool:
        """Check if cache is still valid."""
        if not self.enabled or self._cache is None:
            return False

        if self._timestamp is None:
            return False

        return (time() - self._timestamp) < self.ttl

    def get(self, key: str, default: Any = None) -> Any:
        """Get value from cache."""
        if not self.is_valid():
            return default
        return self._cache.get(key, default)

    def set(self, data: Dict[str, Any]) -> None:
        """Update cache with new data."""
        if self.enabled:
            self._cache = data
            self._timestamp = time()

    def invalidate(self) -> None:
        """Invalidate the cache."""
        self._cache = None
        self._timestamp = None

    def update_key(self, key: str, value: Any) -> None:
        """Update a specific key in cache."""
        if self.enabled and self._cache is not None:
            self._cache[key] = value