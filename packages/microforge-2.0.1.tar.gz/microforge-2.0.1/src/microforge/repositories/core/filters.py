"""
Filter processing for repository queries.
"""

from typing import Any, Dict, List
from ..interfaces import QueryFilter


class FilterProcessor:
    """Processes query filters for repository operations."""

    @staticmethod
    def matches(entity: Dict[str, Any], filters: List[QueryFilter]) -> bool:
        """Check if entity matches all filters.

        Args:
            entity: Entity to check
            filters: List of filters to apply

        Returns:
            True if entity matches all filters
        """
        for filter_obj in filters:
            field_value = entity.get(filter_obj.field)

            if not FilterProcessor._match_single(
                field_value, filter_obj.operator, filter_obj.value
            ):
                return False

        return True

    @staticmethod
    def _match_single(field_value: Any, operator: str, filter_value: Any) -> bool:
        """Check if a single field matches a filter.

        Args:
            field_value: Value from entity
            operator: Comparison operator
            filter_value: Value to compare against

        Returns:
            True if field matches filter
        """
        if operator == "eq":
            return field_value == filter_value
        elif operator == "ne":
            return field_value != filter_value
        elif operator == "contains":
            return filter_value in str(field_value)
        elif operator == "startswith":
            return str(field_value).startswith(str(filter_value))
        elif operator == "endswith":
            return str(field_value).endswith(str(filter_value))
        elif operator == "in":
            return field_value in filter_value
        elif operator == "gt":
            return field_value > filter_value
        elif operator == "gte":
            return field_value >= filter_value
        elif operator == "lt":
            return field_value < filter_value
        elif operator == "lte":
            return field_value <= filter_value
        elif operator == "regex":
            import re
            return bool(re.match(filter_value, str(field_value)))
        else:
            # Unknown operator, default to equality
            return field_value == filter_value

    @staticmethod
    def apply(entities: List[Dict[str, Any]], filters: List[QueryFilter]) -> List[Dict[str, Any]]:
        """Apply filters to a list of entities.

        Args:
            entities: List of entities to filter
            filters: Filters to apply

        Returns:
            Filtered list of entities
        """
        if not filters:
            return entities

        return [
            entity for entity in entities
            if FilterProcessor.matches(entity, filters)
        ]