""" 
Repository interfaces and query definitions.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, TypeVar, Generic
from dataclasses import dataclass

T = TypeVar('T')


@dataclass
class QueryFilter:
    """Filter for repository queries."""
    field: str
    value: Any
    operator: str = "eq"  # eq, ne, contains, startswith, in, gt, lt


class BaseRepository(ABC, Generic[T]):
    """Abstract base repository for data access."""

    def __init__(self, entity_type: str):
        self.entity_type = entity_type

    @abstractmethod
    def find_by_id(self, entity_id: str) -> Optional[T]:
        """Find entity by ID."""
        pass

    @abstractmethod
    def find_all(self, filters: Optional[List[QueryFilter]] = None) -> List[T]:
        """Find all entities with optional filters."""
        pass

    @abstractmethod
    def save(self, entity: T) -> T:
        """Save entity (insert or update)."""
        pass

    @abstractmethod
    def delete(self, entity_id: str) -> bool:
        """Delete entity by ID."""
        pass

    @abstractmethod
    def exists(self, entity_id: str) -> bool:
        """Check if entity exists."""
        pass

    @abstractmethod
    def count(self, filters: Optional[List[QueryFilter]] = None) -> int:
        """Count entities with optional filters."""
        pass

    def find_by_field(self, field: str, value: Any) -> List[T]:
        """Find entities by field value."""
        filters = [QueryFilter(field=field, value=value)]
        return self.find_all(filters)

    @abstractmethod
    def update(self, entity_id: str, updates: Dict[str, Any]) -> Optional[T]:
        """Update specific fields of an entity."""
        pass

    def bulk_save(self, entities: List[T]) -> int:
        """Save multiple entities at once."""
        count = 0
        for entity in entities:
            if self.save(entity):
                count += 1
        return count

    def bulk_delete(self, entity_ids: List[str]) -> int:
        """Delete multiple entities at once."""
        count = 0
        for entity_id in entity_ids:
            if self.delete(entity_id):
                count += 1
        return count