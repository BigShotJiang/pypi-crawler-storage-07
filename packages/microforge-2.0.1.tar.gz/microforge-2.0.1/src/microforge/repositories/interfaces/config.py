"""
Repository configuration and storage backend definitions.
"""

from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Optional


class StorageBackend(Enum):
    """Supported storage backends."""
    YAML = "yaml"
    JSON = "json"
    DATABASE = "database"
    REDIS = "redis"
    API = "api"


@dataclass
class RepositoryConfig:
    """Configuration for a repository."""
    name: str  # "services", "agents", "applications", "hooks"
    entity_key: str  # The key in storage where entities are stored
    id_field: str = "id"  # Field that contains the entity ID
    storage_backend: StorageBackend = StorageBackend.YAML
    storage_path: Optional[Path] = None  # For file-based storage
    connection_string: Optional[str] = None  # For database/API storage
    cache_enabled: bool = True
    cache_ttl: int = 300  # Cache TTL in seconds