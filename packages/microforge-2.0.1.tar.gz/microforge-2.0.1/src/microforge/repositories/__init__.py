"""
Microforge v2 Repository Pattern Implementation.

Provides flexible storage backend abstraction for all registries with
modular, organized architecture.
"""

# Base interfaces and configuration
from .interfaces import (
    BaseRepository,
    QueryFilter,
    RepositoryConfig,
    StorageBackend
)

# Core repository with caching and filtering
from .core import (
    GenericRepository,
    CacheManager,
    FilterProcessor
)

# Repository backends
from .backends.yaml import YamlRepository
from .backends.database import DatabaseRepository

# Specialized repositories
from .audit import AuditRepository, AuditRecord, AuditEventType

# Factory and migration
from .factory import (
    RepositoryFactory,
    MigrationManager
)

__all__ = [
    # Base
    "BaseRepository",
    "QueryFilter",
    "RepositoryConfig",
    "StorageBackend",
    # Generic
    "GenericRepository",
    "CacheManager",
    "FilterProcessor",
    # Backends
    "YamlRepository",
    "DatabaseRepository",
    # Specialized
    "AuditRepository",
    "AuditRecord",
    "AuditEventType",
    # Factory
    "RepositoryFactory",
    "MigrationManager"
]