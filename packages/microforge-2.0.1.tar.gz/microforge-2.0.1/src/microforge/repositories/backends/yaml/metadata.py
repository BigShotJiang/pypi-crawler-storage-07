"""
Metadata management for YAML repositories.
"""

from datetime import datetime
from typing import Dict, Any


class YamlMetadataManager:
    """Manages metadata for YAML files."""

    @staticmethod
    def create_metadata() -> Dict[str, Any]:
        """Create default metadata for a new file."""
        return {
            "version": "1.0.0",
            "created_at": datetime.now().isoformat(),
            "last_modified": datetime.now().isoformat(),
            "description": "Registry data file",
            "schema_version": "1.0"
        }

    @staticmethod
    def update_metadata(metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Update metadata with last modified timestamp."""
        metadata["last_modified"] = datetime.now().isoformat()
        return metadata

    @staticmethod
    def ensure_metadata(data: Dict[str, Any], entity_key: str) -> Dict[str, Any]:
        """Ensure metadata exists in data structure."""
        if "metadata" not in data:
            data["metadata"] = YamlMetadataManager.create_metadata()
            data["metadata"]["description"] = f"Registry of {entity_key}"
        return data

    @staticmethod
    def validate_metadata(metadata: Dict[str, Any]) -> bool:
        """Validate metadata structure."""
        required_fields = ["version", "schema_version"]
        return all(field in metadata for field in required_fields)