"""
YAML file-based repository implementation.
"""

from typing import Dict, Any, Optional
from pathlib import Path

from ...core.repository import GenericRepository, T
from ...interfaces.config import RepositoryConfig
from .metadata import YamlMetadataManager
# Remove circular import - audit_file_operation not essential here
from ....core.common import load_config_file, save_config_file, console
from ....core.exceptions import FileSystemError


class YamlRepository(GenericRepository[T]):
    """
    YAML file-based repository implementation.

    Stores entities in YAML files with metadata tracking and file monitoring.
    """

    def __init__(self, config: RepositoryConfig):
        super().__init__(config)
        self.metadata_manager = YamlMetadataManager()
        self._file_mtime: Optional[float] = None

        # Set default storage path if not provided
        if not config.storage_path:
            from ....config.constants import PACKAGE_DIR
            config.storage_path = PACKAGE_DIR / "registries" / "configs" / f"{config.name}.yaml"

    def _load_all_entities(self) -> Dict[str, T]:
        """Load all entities from YAML file."""
        # Check cache first
        if self.cache.is_valid() and self._is_file_unchanged():
            cached_data = self.cache.get(self.config.entity_key, {})
            if cached_data:
                return cached_data

        # Load from file
        if not self.config.storage_path.exists():
            return {}

        try:
            data = load_config_file(self.config.storage_path)

            # Update cache
            self.cache.set(data)
            self._update_file_mtime()

            # Return entities
            return data.get(self.config.entity_key, {})

        except Exception as e:
            console.print(f"[yellow]Warning: Failed to load {self.config.name}: {e}[/yellow]")
            return {}

    def _save_all_entities(self, entities: Dict[str, T]) -> None:
        """Save all entities to YAML file."""
        try:
            # Load current data to preserve metadata
            data = {}
            if self.config.storage_path.exists():
                data = load_config_file(self.config.storage_path)

            # Ensure metadata exists
            data = self.metadata_manager.ensure_metadata(data, self.config.entity_key)

            # Update metadata
            data["metadata"] = self.metadata_manager.update_metadata(data["metadata"])

            # Update entities
            data[self.config.entity_key] = entities

            # Ensure directory exists
            self.config.storage_path.parent.mkdir(parents=True, exist_ok=True)

            # Save to file
            save_config_file(self.config.storage_path, data)

            # Update cache and mtime
            self.cache.set(data)
            self._update_file_mtime()

        except Exception as e:
            raise FileSystemError(
                f"Failed to save {self.config.name} to YAML",
                path=str(self.config.storage_path),
                operation="write"
            ) from e

    def _is_file_unchanged(self) -> bool:
        """Check if file hasn't changed since last read."""
        if not self.config.storage_path.exists():
            return self._file_mtime is None

        try:
            current_mtime = self.config.storage_path.stat().st_mtime
            return current_mtime == self._file_mtime
        except:
            return False

    def _update_file_mtime(self) -> None:
        """Update the stored file modification time."""
        if self.config.storage_path.exists():
            try:
                self._file_mtime = self.config.storage_path.stat().st_mtime
            except:
                self._file_mtime = None

    def get_metadata(self) -> Dict[str, Any]:
        """Get metadata from YAML file."""
        if self.config.storage_path.exists():
            data = load_config_file(self.config.storage_path)
            return data.get("metadata", {})
        return {}

    def update_metadata(self, updates: Dict[str, Any]) -> None:
        """Update metadata in YAML file."""
        if self.config.storage_path.exists():
            data = load_config_file(self.config.storage_path)
            if "metadata" not in data:
                data["metadata"] = self.metadata_manager.create_metadata()
            data["metadata"].update(updates)
            data["metadata"] = self.metadata_manager.update_metadata(data["metadata"])
            save_config_file(self.config.storage_path, data)
            self.cache.invalidate()

    def export_to_dict(self) -> Dict[str, Any]:
        """Export entire YAML content as dictionary."""
        if self.config.storage_path.exists():
            return load_config_file(self.config.storage_path)
        return {"metadata": {}, self.config.entity_key: {}}