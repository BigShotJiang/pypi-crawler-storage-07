"""
Database repository implementation (template for future use).
"""

from .repository import DatabaseRepository

__all__ = [
    "DatabaseRepository"
]