"""
Audit record models and types.
"""

from dataclasses import dataclass, asdict, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, Optional, List
import json


class AuditEventType(Enum):
    """Types of audit events."""
    SESSION = "session"
    COMMAND = "command"
    SERVICE = "service"
    FILE = "file"
    SUBPROCESS = "subprocess"
    LLM = "llm"
    REPOSITORY = "repository"
    REGISTRY = "registry"
    ERROR = "error"


@dataclass
class AuditRecord:
    """Model for an audit log record."""

    # Required fields
    timestamp: str
    session_id: str
    event_type: str
    operation: str
    context: Dict[str, Any]
    success: bool

    # Optional fields
    result: Optional[Dict[str, Any]] = None
    error: Optional[Dict[str, Any]] = None
    duration_ms: Optional[float] = None

    # ID for repository storage
    id: Optional[str] = None

    def __post_init__(self):
        """Generate unique ID after initialization."""
        if not self.id:
            # Create ID from timestamp and session
            timestamp_part = self.timestamp.replace(':', '').replace('-', '').replace('.', '').replace('Z', '')
            self.id = f"{self.session_id}_{timestamp_part}"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for storage."""
        data = asdict(self)
        # Remove None values for cleaner storage
        return {k: v for k, v in data.items() if v is not None}

    def to_json_line(self) -> str:
        """Convert to JSONL format for compatibility."""
        return json.dumps(self.to_dict(), ensure_ascii=False, separators=(',', ':'))

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AuditRecord":
        """Create from dictionary."""
        # Remove id if present as it will be regenerated
        clean_data = {k: v for k, v in data.items() if k != 'id'}
        record = cls(**clean_data)
        # Set ID explicitly if it was in the data
        if 'id' in data:
            record.id = data['id']
        return record

    @classmethod
    def from_json_line(cls, line: str) -> "AuditRecord":
        """Create from JSONL line."""
        data = json.loads(line.strip())
        return cls.from_dict(data)


@dataclass
class AuditQuery:
    """Query parameters for audit log searches."""

    session_id: Optional[str] = None
    event_type: Optional[str] = None
    operation: Optional[str] = None
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    success_only: bool = False
    limit: int = 100
    offset: int = 0


@dataclass
class AuditSummary:
    """Summary statistics for audit logs."""

    total_events: int = 0
    successful_events: int = 0
    failed_events: int = 0
    events_by_type: Dict[str, int] = field(default_factory=dict)
    operations_by_type: Dict[str, int] = field(default_factory=dict)
    average_duration_ms: Optional[float] = None
    session_count: int = 0

    def add_record(self, record: AuditRecord) -> None:
        """Update summary with a record."""
        self.total_events += 1

        if record.success:
            self.successful_events += 1
        else:
            self.failed_events += 1

        # Count by event type
        event_type = record.event_type
        self.events_by_type[event_type] = self.events_by_type.get(event_type, 0) + 1

        # Count by operation
        operation = record.operation
        self.operations_by_type[operation] = self.operations_by_type.get(operation, 0) + 1