"""
Specialized repository for audit logs with optimized append operations.
"""

from typing import Dict, Any, List, Optional
from pathlib import Path
from datetime import datetime, timedelta
import json

from ..backends.yaml.repository import YamlRepository
from ..interfaces import RepositoryConfig, QueryFilter
from .models import AuditRecord, AuditQuery, AuditSummary
# Removed circular import
from ...core.common import console
from ...config.constants import MICROFORGE_HOME, AUDIT_LOG_FILENAME


class AuditRepository(YamlRepository):
    """
    Specialized repository for audit logs.

    Optimized for:
    - Append-only operations
    - Time-based queries
    - Session-based retrieval
    - JSONL compatibility
    """

    def __init__(self, config: Optional[RepositoryConfig] = None):
        """Initialize audit repository with default config if not provided."""
        if not config:
            # Default configuration for audit logs
            config = RepositoryConfig(
                name="audit",
                entity_key="audit_logs",
                id_field="id",
                storage_path=MICROFORGE_HOME / "audit_logs.yaml",
                cache_enabled=True,
                cache_ttl=60  # Shorter TTL for audit logs
            )
        super().__init__(config)

        # Additional JSONL file for backward compatibility
        self.jsonl_file = MICROFORGE_HOME / AUDIT_LOG_FILENAME
        self._ensure_jsonl_file()

    def _ensure_jsonl_file(self) -> None:
        """Ensure JSONL file exists for backward compatibility."""
        if not self.jsonl_file.exists():
            self.jsonl_file.parent.mkdir(parents=True, exist_ok=True)
            self.jsonl_file.touch()

    def append(self, record: AuditRecord) -> bool:
        """
        Append an audit record (optimized for performance).

        Args:
            record: Audit record to append

        Returns:
            True if successful
        """
        try:
            # Save to repository (YAML)
            self.save(record.to_dict())

            # Also append to JSONL for backward compatibility
            with open(self.jsonl_file, 'a', encoding='utf-8') as f:
                f.write(record.to_json_line() + '\n')

            return True

        except Exception as e:
            console.print(f"[red]Failed to append audit record: {e}[/red]")
            return False

    def find_by_session(self, session_id: str, limit: Optional[int] = None) -> List[AuditRecord]:
        """
        Find all audit records for a session.

        Args:
            session_id: Session ID to search for
            limit: Maximum number of records to return

        Returns:
            List of audit records for the session
        """
        filters = [QueryFilter(field="session_id", value=session_id)]
        results = self.find_all(filters)

        # Convert to AuditRecord objects
        records = []
        for data in results[:limit] if limit else results:
            try:
                records.append(AuditRecord.from_dict(data))
            except Exception as e:
                console.print(f"[yellow]Warning: Failed to parse audit record: {e}[/yellow]")

        return records

    def find_by_time_range(
        self,
        start_time: datetime,
        end_time: Optional[datetime] = None
    ) -> List[AuditRecord]:
        """
        Find audit records within a time range.

        Args:
            start_time: Start of time range
            end_time: End of time range (defaults to now)

        Returns:
            List of audit records in the time range
        """
        if not end_time:
            end_time = datetime.now()

        # Convert times to ISO format strings for comparison
        start_str = start_time.isoformat() + 'Z'
        end_str = end_time.isoformat() + 'Z'

        all_records = self.find_all()
        records = []

        for data in all_records:
            timestamp = data.get('timestamp', '')
            if start_str <= timestamp <= end_str:
                try:
                    records.append(AuditRecord.from_dict(data))
                except Exception as e:
                    console.print(f"[yellow]Warning: Failed to parse audit record: {e}[/yellow]")

        return records

    def find_recent(self, limit: int = 100) -> List[AuditRecord]:
        """
        Get the most recent audit records.

        Args:
            limit: Maximum number of records to return

        Returns:
            List of recent audit records
        """
        all_records = self.find_all()

        # Sort by timestamp (newest first)
        sorted_records = sorted(
            all_records,
            key=lambda x: x.get('timestamp', ''),
            reverse=True
        )

        records = []
        for data in sorted_records[:limit]:
            try:
                records.append(AuditRecord.from_dict(data))
            except Exception as e:
                console.print(f"[yellow]Warning: Failed to parse audit record: {e}[/yellow]")

        return records

    def query(self, query: AuditQuery) -> List[AuditRecord]:
        """
        Query audit records with multiple criteria.

        Args:
            query: Query parameters

        Returns:
            List of matching audit records
        """
        filters = []

        if query.session_id:
            filters.append(QueryFilter(field="session_id", value=query.session_id))

        if query.event_type:
            filters.append(QueryFilter(field="event_type", value=query.event_type))

        if query.operation:
            filters.append(QueryFilter(field="operation", value=query.operation))

        if query.success_only:
            filters.append(QueryFilter(field="success", value=True))

        results = self.find_all(filters) if filters else self.find_all()

        # Apply time filters if provided
        if query.start_time or query.end_time:
            filtered_results = []
            start_str = query.start_time.isoformat() + 'Z' if query.start_time else ''
            end_str = query.end_time.isoformat() + 'Z' if query.end_time else 'Z'

            for data in results:
                timestamp = data.get('timestamp', '')
                if (not start_str or timestamp >= start_str) and \
                   (not end_str or timestamp <= end_str):
                    filtered_results.append(data)

            results = filtered_results

        # Apply limit and offset
        if query.offset:
            results = results[query.offset:]
        if query.limit:
            results = results[:query.limit]

        # Convert to AuditRecord objects
        records = []
        for data in results:
            try:
                records.append(AuditRecord.from_dict(data))
            except Exception as e:
                console.print(f"[yellow]Warning: Failed to parse audit record: {e}[/yellow]")

        return records

    def get_summary(
        self,
        session_id: Optional[str] = None,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None
    ) -> AuditSummary:
        """
        Get summary statistics for audit logs.

        Args:
            session_id: Filter by session ID
            start_time: Filter by start time
            end_time: Filter by end time

        Returns:
            Summary statistics
        """
        # Build query
        query = AuditQuery(
            session_id=session_id,
            start_time=start_time,
            end_time=end_time,
            limit=10000  # Large limit for summary
        )

        records = self.query(query)
        summary = AuditSummary()

        # Track unique sessions
        sessions = set()
        durations = []

        for record in records:
            summary.add_record(record)
            sessions.add(record.session_id)

            if record.duration_ms:
                durations.append(record.duration_ms)

        summary.session_count = len(sessions)

        # Calculate average duration
        if durations:
            summary.average_duration_ms = sum(durations) / len(durations)

        return summary

    def cleanup_old_records(self, days: int = 30) -> int:
        """
        Remove audit records older than specified days.

        Args:
            days: Number of days to keep

        Returns:
            Number of records deleted
        """
        cutoff_time = datetime.now() - timedelta(days=days)
        cutoff_str = cutoff_time.isoformat() + 'Z'

        all_records = self._load_all_entities()
        original_count = len(all_records)

        # Filter out old records
        filtered_records = {
            id: record for id, record in all_records.items()
            if record.get('timestamp', '') >= cutoff_str
        }

        if len(filtered_records) < original_count:
            self._save_all_entities(filtered_records)
            self.cache.invalidate()

        return original_count - len(filtered_records)

    def migrate_from_jsonl(self, jsonl_file: Optional[Path] = None) -> int:
        """
        Migrate existing JSONL audit logs to repository.

        Args:
            jsonl_file: Path to JSONL file (uses default if not provided)

        Returns:
            Number of records migrated
        """
        jsonl_file = jsonl_file or self.jsonl_file
        if not jsonl_file.exists():
            return 0

        migrated = 0
        try:
            with open(jsonl_file, 'r', encoding='utf-8') as f:
                for line in f:
                    try:
                        record = AuditRecord.from_json_line(line)
                        self.save(record.to_dict())
                        migrated += 1
                    except Exception as e:
                        console.print(f"[yellow]Skipping invalid record: {e}[/yellow]")

            console.print(f"[green]Migrated {migrated} audit records[/green]")

        except Exception as e:
            console.print(f"[red]Migration failed: {e}[/red]")

        return migrated