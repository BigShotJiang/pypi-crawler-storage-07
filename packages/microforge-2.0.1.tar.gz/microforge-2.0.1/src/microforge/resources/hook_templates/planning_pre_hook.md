# Planning Pre-Hook

## Purpose
This hook ensures that before any code changes are made, a proper implementation plan is created and maintained in `docs/planning/`.

## When This Hook Activates
This hook activates when the user's request involves:
- Creating new features or functionality
- Modifying existing code
- Fixing bugs or issues
- Refactoring code
- Any request that will result in code changes
- don't trigger it when the change is related to cli command registry add and remove.

## Required Actions

### 1. Before Starting Implementation

When you receive a request that requires code changes, you MUST:

1. **Create an Implementation Plan**
   - Create a file in `docs/planning/` with a descriptive name (e.g., `export-feature-plan.md`)
   - Present the plan to the user for review
   - **WAIT for explicit user approval before proceeding**
   - Only start implementation after user confirms the plan

2. **Plan Structure**
   ```markdown
   # Implementation Plan: [Feature/Task Name]
   
   ## Request Summary
   [Clear description of what was requested]
   
   ## Analysis
   - **Type**: [Bug Fix/New Feature/Refactor/Enhancement]
   - **Scope**: [Files/Modules affected]
   - **Complexity**: [Simple/Medium/Complex]
   
   ## Requirements
   - [ ] Requirement 1
   - [ ] Requirement 2
   - [ ] ...
   
   ## Technical Approach
   ### Architecture Decision
   [Explain the chosen approach and why]
   
   ### Files to Modify/Create
   - `path/to/file1.py` - [What changes]
   - `path/to/file2.py` - [What changes]
   
   ## Implementation Steps
   1. [ ] Step 1: [Description]
   2. [ ] Step 2: [Description]
   3. [ ] ...
   
   ## Testing Strategy
   - [ ] Unit tests for [component]
   - [ ] Integration tests for [feature]
   - [ ] Manual testing steps
   
   ## Documentation Updates
   - [ ] Update README if needed
   - [ ] Update API docs
   - [ ] Update user guide
   
   ## Risk Assessment
   - **Breaking Changes**: [Yes/No - Details]
   - **Performance Impact**: [None/Low/Medium/High]
   - **Security Considerations**: [Any security implications]
   ```

### 2. User Approval Required

After creating the plan:
1. **Present the plan** to the user with a summary
2. **Ask explicitly**: "Should I proceed with this implementation plan?"
3. **Wait for confirmation** - Do NOT start coding until approved
4. **Accept modifications** - User may request changes to the plan

### 3. During Implementation (After Approval)

As you work on the implementation:

1. **Update Progress**
   - Check off completed items in the plan
   - Add notes about any deviations from the original plan
   - Document any unexpected challenges

2. **Reference the Plan**
   - Start your response with: "Following the implementation plan in `docs/planning/[filename]`"
   - Mention which step you're currently working on

### 4. After Implementation

When the implementation is complete:

1. **Final Update**
   - Mark all completed items
   - Add a completion summary
   - Note any follow-up tasks needed

2. **Archive if Needed**
   - For major features, keep the plan for reference
   - For minor fixes, can be moved to `docs/planning/archive/`

## Workflow Example

**User**: "Add a new export feature to the CLI"

**AI Assistant**:
1. Creates `docs/planning/export-feature-plan.md`
2. Responds: "I've created an implementation plan for the export feature. The plan includes [summary]. Should I proceed with this implementation?"
3. **WAITS for user response**

**User**: "Yes, proceed" or "Looks good"

**AI Assistant**: Now begins implementation following the approved plan

## Examples of Requests That Trigger This Hook

✅ **Should trigger planning:**
- "Add a new export feature to the CLI"
- "Fix the bug in the authentication module"
- "Refactor the service registry to use async"
- "Implement caching for the API endpoints"

❌ **Should NOT trigger planning:**
- "What does this function do?"
- "Show me the current configuration"
- "Explain the architecture"
- "Run the tests"

## Compliance Check

When implementing code changes, ensure:
- [ ] Implementation plan exists in `docs/planning/`
- [ ] Plan is referenced at the start of implementation
- [ ] Progress is tracked by updating checkboxes
- [ ] Major decisions are documented in the plan
- [ ] Plan is updated if approach changes

## Benefits

1. **Clear Communication**: User can see exactly what will be done
2. **Progress Tracking**: Both user and assistant can track progress
3. **Documentation**: Plans serve as documentation for decisions
4. **Consistency**: Ensures systematic approach to all changes
5. **Review**: Allows user to review approach before implementation

## Hook Configuration

This hook respects the following configuration in `.microforge/config.yaml`:

```yaml
hooks:
  planning:
    enabled: true
    auto_create_plan: true
    plan_directory: docs/planning
    update_on_progress: true
    archive_completed: false
```

## Important Notes

- Plans MUST be created and APPROVED before any code changes
- User approval is MANDATORY - never skip this step
- Plans can be simple for small changes, detailed for complex features
- Always update the plan if the approach changes during implementation
- Use descriptive filenames for plans (not just `plan.md`)
- If user requests changes to the plan, update it and ask for re-approval

---

**Hook Version**: 1.0.0
**Last Updated**: 2024-01-20