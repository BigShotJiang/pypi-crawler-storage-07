# AI Assistant Hooks

This directory contains hook definitions that AI assistants (Claude, Cursor, Copilot, etc.) must follow when working with the Microforge codebase.

## Available Hooks

| Hook Name | File | Purpose | Trigger |
|-----------|------|---------|---------|
| Code Quality | `code_quality_hook.md` | Ensure docs, tests, and quality standards | Before/after code changes |
| Dependency Check | `dependency_check_hook.md` | Verify dependency updates | When modifying requirements |
| Security Review | `security_review_hook.md` | Check for security issues | Before committing sensitive code |
| Performance Check | `performance_check_hook.md` | Validate performance impact | After algorithmic changes |

## How Hooks Work

1. **AI reads hook requirements** from the relevant `.md` file
2. **AI follows pre-change requirements** before modifying code
3. **AI implements changes** according to patterns
4. **AI validates post-change requirements** 
5. **AI reports compliance** with hook requirements

## Adding New Hooks

To add a new hook:

1. Create a new file: `[hook_name]_hook.md`
2. Define the hook structure:
   - Purpose
   - Hook Type
   - Pre-Change Requirements
   - Post-Change Requirements
   - Blocking Conditions
   - Example Workflow
3. Update this README with the new hook
4. Reference in AI tool configurations

## Hook Enforcement

Hooks are enforced through:

- **Instructions**: Clear requirements in markdown files
- **AI Context**: Referenced in CLAUDE.md, .cursorrules, etc.
- **Validation**: AI self-validates against requirements
- **Reporting**: AI reports compliance status

## Integration Points

### Claude/Claude Code
```markdown
Read and follow all hooks in: src/microforge/ai/hooks/
Specifically apply: code_quality_hook.md for all changes
```

### Cursor
Add to `.cursorrules`:
```
Follow requirements in src/microforge/ai/hooks/
Apply code_quality_hook.md for all code changes
```

### GitHub Copilot
Add to workspace settings or instructions

## Hook Priority

When multiple hooks apply:

1. 🔴 **Security hooks** - Always highest priority
2. 🟡 **Quality hooks** - Required for all changes
3. 🟢 **Performance hooks** - For optimization work
4. 🔵 **Feature hooks** - For specific features

## Future Hooks

Planned hooks to be implemented:

- `api_design_hook.md` - API design standards
- `database_migration_hook.md` - Database change requirements
- `cli_update_hook.md` - CLI command standards
- `ai_workflow_hook.md` - AI agent integration requirements