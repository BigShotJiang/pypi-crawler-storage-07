# Code Quality Hook - AI Assistant Requirements

## 🎯 Purpose
Ensure all code changes maintain quality standards by updating documentation, tests, and following the repository's established patterns.

## Hook Type: `code_quality`
**Trigger**: Before and after any code modifications

## Pre-Change Requirements

Before modifying any code, the AI assistant MUST:

### 1. **Discover Repository Structure**
   ```bash
   # Find documentation location
   find . -type d -name "docs" -o -name "documentation" -o -name "doc" | head -5
   
   # Find test directory structure
   find . -type d -name "test*" -o -name "spec*" | head -5
   
   # Identify test file patterns
   find . -name "*test*.py" -o -name "*spec*.py" -o -name "test_*.js" | head -5
   
   # Check for existing documentation files
   ls -la | grep -E "README|CHANGELOG|CONTRIBUTING"
   ```

### 2. **Understand Project Conventions**
   - Review existing test patterns in the repository
   - Check docstring/comment style used in the codebase
   - Identify documentation structure (API docs, guides, etc.)
   - Look for CI/CD configuration to understand test requirements

### 3. **Locate Related Files**
   For the file being modified, find:
   - Corresponding test file(s)
   - Related documentation
   - Dependencies and dependents

## Post-Change Requirements

After making any code changes, the AI assistant MUST:

### 1. Documentation Updates

The AI should automatically detect and update:

| Document Type | Detection Pattern | Update Required |
|--------------|-------------------|-----------------|
| README | `README*` in root | Usage examples for new features |
| CHANGELOG | `CHANGELOG*`, `NEWS*`, `HISTORY*` | Add entry under "Unreleased" or latest version |
| API Docs | `docs/api/`, `docs/reference/`, or inline | Update for public API changes |
| Guides | `docs/guide/`, `docs/tutorial/` | Update if workflow changes |
| Code Comments | Inline in source files | Add for complex logic |

### 2. Test Updates

The AI should follow the repository's test structure:

```bash
# Discover test structure
PROJECT_STRUCTURE=$(find . -name "*.py" -o -name "*.js" -o -name "*.ts" | head -20)

# Common patterns to check:
# - tests/ parallel to src/
# - test/ alongside code
# - __tests__/ for JavaScript
# - spec/ for Ruby/JavaScript
# - *_test.py or test_*.py for Python
# - *.test.js or *.spec.js for JavaScript
```

**Adaptive Test Requirements:**
- If tests exist: Match existing test patterns and location
- If no tests exist: Create in standard location (`tests/` or `test/`)
- Follow naming convention found in the repository
- Maintain or improve existing coverage

### 3. Validation Commands

The AI should run repository-appropriate validation:

```bash
# Python projects
if [ -f "setup.py" ] || [ -f "pyproject.toml" ]; then
    # Check for test runner
    if [ -f "pytest.ini" ] || grep -q "pytest" requirements*.txt; then
        pytest tests/ -v
    elif [ -f "setup.cfg" ] && grep -q "test" setup.cfg; then
        python setup.py test
    else
        python -m unittest discover
    fi
fi

# JavaScript/Node projects  
if [ -f "package.json" ]; then
    # Check test script
    npm test || yarn test
fi

# Generic validation
# 1. Check syntax (language-specific)
# 2. Run linter if configured
# 3. Run formatter if configured
# 4. Execute tests
```

## Adaptive Behavior

### Language Detection
The hook adapts based on the primary language:

| Language | Test Framework Detection | Doc Style | Test Location |
|----------|-------------------------|-----------|---------------|
| Python | pytest, unittest, nose | Docstrings, Sphinx | `tests/`, `test/` |
| JavaScript | jest, mocha, jasmine | JSDoc, Markdown | `__tests__/`, `test/`, `spec/` |
| TypeScript | jest, mocha, vitest | TSDoc, Markdown | `__tests__/`, `test/`, `spec/` |
| Go | go test | GoDoc | `*_test.go` alongside code |
| Rust | cargo test | RustDoc | `tests/`, inline `#[test]` |
| Java | JUnit, TestNG | Javadoc | `src/test/` |

### Documentation Discovery
```bash
# Find documentation patterns
DOC_DIRS=$(find . -type d \( -name "docs" -o -name "documentation" -o -name "doc" \) -not -path "*/node_modules/*" -not -path "*/.git/*")

# Find existing doc files
DOC_FILES=$(find . -maxdepth 2 -type f \( -name "*.md" -o -name "*.rst" -o -name "*.txt" \) -not -path "*/node_modules/*")

# Detect documentation tool
if [ -f "mkdocs.yml" ]; then echo "MkDocs detected"; fi
if [ -f "docs/conf.py" ]; then echo "Sphinx detected"; fi
if [ -f "docsify.html" ] || [ -f "docs/index.html" ]; then echo "Docsify detected"; fi
```

## Blocking Conditions

The AI assistant MUST NOT proceed if:

- ❌ No tests for new functionality (unless explicitly told to skip)
- ❌ Existing tests are failing after changes
- ❌ No documentation for public APIs/functions
- ❌ Breaking changes without documentation
- ❌ Syntax errors in modified files

## Smart Compliance Check

The AI should report based on what it finds:

```
CODE QUALITY CHECK:
Repository: [detected type/language]
Test Framework: [detected framework]
Doc System: [detected system]

✅ Tests: [Created/Updated] in [detected test location]
✅ Docs: Updated [found documentation files]
✅ Comments: Added to [complex functions]
⚠️ CHANGELOG: [Not found / Updated]
✅ Validation: All tests passing

Repository-Specific Actions Taken:
1. Followed [detected] test pattern
2. Updated docs in [detected] format
3. Maintained [detected] code style
```

## Example Adaptive Workflow

```python
# 1. AI detects Python project with pytest
# Found: tests/ directory, pytest.ini, docstring convention

# 2. After modifying src/mymodule/feature.py
def new_feature(self, param: str) -> bool:
    """
    Brief description. (Matching existing docstring style)
    
    Args:
        param: Description
        
    Returns:
        Description
    """
    # Implementation

# 3. AI creates/updates tests/mymodule/test_feature.py
# (Matching existing test structure)

# 4. AI updates CHANGELOG.md or NEWS.rst (whichever exists)

# 5. AI runs: pytest tests/mymodule/test_feature.py
```

## Configuration Override

If `.microforge/config.yaml` exists, respect its settings:

```yaml
hooks:
  code_quality:
    test_location: "custom/test/path"
    doc_location: "custom/docs"
    skip_tests: false
    require_changelog: true
    min_coverage: 80
```

## Important Notes

1. **Adapt, Don't Assume**: Always discover the repository structure first
2. **Follow Existing Patterns**: Match the style and structure already in place
3. **Create What's Missing**: If no test structure exists, create a sensible default
4. **Report Transparently**: Show what was detected and what actions were taken
5. **Respect Repository Tools**: Use the test runners, linters, and formatters already configured

---

**Hook Version**: 2.0.0
**Last Updated**: 2024-01-20
**Change**: Made adaptive to any repository structure