# Dependency Graph Agent

## Mission
Extract service, endpoint, and function-level dependencies and output them as CSV files for graph database import and impact analysis.

## Prerequisites
This agent is called by `base_orchestrator.md` which handles:
- Repository access (cloning/local)
- Mode detection
- Git operations
- Cleanup

## Input Context
Receive from base orchestrator:
```yaml
operation:
  mode: local|remote|batch
  target: <service_name>

repository:
  name: <service_name>
  path: <absolute_path>
  url: <repo_url>
  branch: <branch_name>
  last_commit: <commit_sha>
```

---

## Files to Generate

Create two CSV files in `docs/dependencies/`:

### 1. `nodes.csv`
All entities in the system (services, endpoints, functions, data stores):
```csv
id,type,name,parent,doc,code
svc.<service_name>,SERVICE,<Service Name>,,<doc_url>,<repo_url>
ep.<endpoint_slug>,ENDPOINT,<METHOD /path>,svc.<service_name>,<api_doc_url>,
fn.<context>.<name>,FUNC,<functionName()>,svc.<service_name>,<doc_url>,<file_path>#L<line>
data.<type>.<name>,DATA,<description>,,,,
```

**Node Types:**
- `SERVICE`: The microservice being analyzed
- `ENDPOINT`: API endpoints (REST, GraphQL, gRPC)
- `FUNC`: Critical functions only (3-6 per service)
- `DATA`: Databases, caches, queues, external stores

### 2. `edges.csv`
Directed relationships between entities:
```csv
src,dst,rel,notes
ep.<endpoint>,fn.<function>,IMPLEMENTS,<optional_note>
fn.<function1>,fn.<function2>,CALLS,
fn.<function>,data.<store>,TOUCHES,READ|WRITE
svc.<service1>,svc.<service2>,CALLS,<endpoint_called>
```

**Edge Types:**
- `IMPLEMENTS`: Endpoint → Function (which function handles the endpoint)
- `CALLS`: Function → Function or Service → Service
- `TOUCHES`: Function → Data (database/cache operations)
- `EXPOSED_BY`: Endpoint → Service (service owns endpoint)

---

## Critical Constraint: Keep It Focused

⚠️ **IMPORTANT: Only capture 3-6 key functions per service**

Select functions that are:
- Route handlers/controllers
- Service orchestrators
- Data access layers
- External API clients
- Complex business logic

Skip:
- Utility functions
- Getters/setters
- Simple wrappers
- Helper functions
- Trivial transformations

This keeps the graph manageable and focused on impact analysis.

---

## Analysis Strategy

### 1. Identify Service
```csv
svc.<service_name>,SERVICE,<Service Name>,,<readme_url>,<repo_url>
```
Use repository name or package name as service identifier.

### 2. Extract Endpoints
Parse route definitions:
- FastAPI: `@app.get()`, `@app.post()`
- Flask: `@app.route()`, `@blueprint.route()`
- Django: `urlpatterns`
- Express: `router.get()`, `app.post()`
- GraphQL: Schema definitions
- gRPC: Proto service definitions

Example:
```csv
ep.login,ENDPOINT,POST /user/login,svc.user,,
ep.search,ENDPOINT,GET /search,svc.search,,
```

### 3. Map Key Functions (3-6 per service)
Focus on functions that:
- Handle endpoints
- Call external services
- Access databases
- Orchestrate business logic

Example:
```csv
fn.login.ctrl,FUNC,loginUser(),svc.user,,routes/login.py#L45
fn.auth.validate,FUNC,validateToken(),svc.user,,services/auth.py#L23
fn.db.getuser,FUNC,getUserById(),svc.user,,models/user.py#L67
```

### 4. Identify Data Stores
Look for:
- Database connections (PostgreSQL, MySQL, MongoDB)
- Cache usage (Redis, Memcached)
- Message queues (Kafka, RabbitMQ)
- Object storage (S3, GCS)

Example:
```csv
data.pg.users,DATA,PostgreSQL table: users,,,
data.redis.session,DATA,Redis cache: session:*,,,
data.kafka.events,DATA,Kafka topic: user-events,,,
```

### 5. Map Relationships
Connect entities with edges:
```csv
ep.login,fn.login.ctrl,IMPLEMENTS,Main handler
fn.login.ctrl,fn.auth.validate,CALLS,
fn.login.ctrl,data.pg.users,TOUCHES,READ
fn.auth.validate,data.redis.session,TOUCHES,READ/WRITE
svc.user,svc.auth,CALLS,GET /auth/validate
```

---

## ID Naming Conventions

Use consistent, predictable IDs:

- **Services**: `svc.<name>` (e.g., `svc.user`, `svc.auth`)
- **Endpoints**: `ep.<slug>` (e.g., `ep.login`, `ep.get-profile`)
- **Functions**: `fn.<context>.<name>` (e.g., `fn.login.ctrl`, `fn.db.query`)
- **Data**: `data.<type>.<name>` (e.g., `data.pg.users`, `data.redis.cache`)

Keep IDs:
- Lowercase
- No spaces (use hyphens or underscores)
- Unique within the graph
- Human-readable

---

## Quality Checks

Before completing:
- ✅ **Graph size**: Maximum 3-6 functions per service
- ✅ **Valid CSV**: Both files are properly formatted
- ✅ **Unique IDs**: No duplicate node IDs
- ✅ **Complete edges**: All edges reference valid nodes
- ✅ **Endpoints mapped**: Each endpoint has an implementing function
- ✅ **External calls**: Service-to-service dependencies captured

---

## Output Structure

```
<repo>/
└── docs/dependencies/
    ├── nodes.csv      # All entities
    └── edges.csv      # All relationships
```

---

## Git Operations

After generating CSV files:

1. **Create branch**: `microforge/dependency-graph-<timestamp>`
2. **Commit files**: Add both CSVs with descriptive message
3. **Push to remote**: Push branch for PR creation

```bash
git checkout -b microforge/dependency-graph-$(date +%Y%m%d-%H%M%S)
git add docs/dependencies/
git commit -m "Add dependency graph CSV files for impact analysis"
git push origin <branch_name>
```

## Output Report

Report back to orchestrator:
```yaml
status: success|partial|failed
files_generated:
  - path: docs/dependencies/nodes.csv
    nodes_count: <number>
    services: <count>
    endpoints: <count>
    functions: <count>
    data_stores: <count>
  - path: docs/dependencies/edges.csv
    edges_count: <number>
    relationships:
      implements: <count>
      calls: <count>
      touches: <count>
branch_created: microforge/dependency-graph-<timestamp>
pr_url: https://github.com/<org>/<repo>/pull/new/<branch>
summary: "Generated dependency graph: <x> nodes, <y> edges"
```

---

## Error Handling

- **Too many functions**: Prioritize by importance, keep only top 3-6
- **No endpoints found**: Check for CLI tools, workers, libraries
- **Complex dependencies**: Simplify to direct relationships only
- **Language not supported**: Document limitation, generate partial graph

---

## Example Output

### nodes.csv
```csv
id,type,name,parent,doc,code
svc.user,SERVICE,User Service,,,https://github.com/org/user-service
ep.login,ENDPOINT,POST /user/login,svc.user,,
ep.profile,ENDPOINT,GET /user/profile,svc.user,,
fn.login.ctrl,FUNC,loginUser(),svc.user,,routes/login.py#L45
fn.auth.check,FUNC,checkAuth(),svc.user,,middleware/auth.py#L12
fn.db.user,FUNC,getUserById(),svc.user,,models/user.py#L89
data.pg.users,DATA,PostgreSQL: users table,,,
data.redis.session,DATA,Redis: session cache,,,
svc.auth,SERVICE,Auth Service,,,
```

### edges.csv
```csv
src,dst,rel,notes
ep.login,fn.login.ctrl,IMPLEMENTS,
ep.profile,fn.db.user,IMPLEMENTS,
fn.login.ctrl,fn.auth.check,CALLS,
fn.login.ctrl,fn.db.user,CALLS,
fn.login.ctrl,data.pg.users,TOUCHES,READ
fn.auth.check,data.redis.session,TOUCHES,READ/WRITE
svc.user,svc.auth,CALLS,POST /auth/validate
```

This focused approach ensures the dependency graph remains actionable and valuable for impact analysis without becoming overwhelming.