# Base Orchestrator

## Mission
Handle common repository operations, mode detection, and workflow orchestration for all analysis agents.

## IMPORTANT: Check Command Type First

**READ THE EXECUTION CONTEXT to determine `command_type`:**
- If `command_type: audit` → You MUST call **audit_report.md** agent ONLY
- If `command_type: analyze` or `setup` → Call **documentation.md** and/or **dependency_graph.md**

The command_type is provided in the EXECUTION CONTEXT yaml at the beginning of your prompt.

## Mode Detection

Determine operation mode based on input:
- **Local Mode**: When `target = "."` or from `microforge setup`
- **Remote Mode**: When service name provided from registry
- **Batch Mode**: When `--all` flag used

---

## Common Workflow

### 1. Mode Detection & Validation

#### Local Mode
- Verify current directory is a git repository
- Get repository name from current directory
- No cloning needed

#### Remote Mode  
- Verify service exists: `microforge service list`
- Get repository details: `microforge service show <service-name>`
- Clone to temporary location

#### Batch Mode
- Get all services: `microforge service list`
- Process each service using Remote Mode workflow

### 2. Repository Access

#### For Local Mode
```bash
# Use current directory
repo_path = "."
service_name = basename(pwd)
```

#### For Remote Mode
```bash
# Clone to temp directory
temp_dir = mktemp -d /tmp/microforge-XXXXXX
git clone <repo_url> <temp_dir>/<service_name>
cd <temp_dir>/<service_name>
git checkout <branch>
```

### 3. Pre-Analysis Checks

- Check for existing analysis timestamps in metadata files
- Get latest commit: `git log -1 --format=%H`
- Determine what needs updating based on flags:
  - `--docs-only`: Check `docs/service/metadata.yaml`
  - `--deps-only`: Check `docs/dependencies/metadata.yaml`
  - Default: Check both

### 4. Call Specialized Agents

**CRITICAL: Check the `command_type` from EXECUTION CONTEXT first!**

#### Agent Selection Based on Command Type:

##### If `command_type: audit`:
- **ONLY invoke audit_report.md**
- Do NOT invoke documentation.md or dependency_graph.md
- The audit agent will generate audit reports in `docs/audit/`

##### If `command_type: analyze` or `setup`:
- **documentation.md** - If not `--deps-only`
- **dependency_graph.md** - If not `--docs-only`

#### Agent Selection Logic:
```
# FIRST check command_type from context
if command_type == "audit":
    # AUDIT COMMAND - Only run audit agent
    invoke audit_report.md
    STOP - do not run other agents

elif command_type in ["analyze", "setup"]:
    # ANALYZE/SETUP COMMANDS - Run doc/dep agents
    if not deps_only:
        invoke documentation.md
    if not docs_only:
        invoke dependency_graph.md
```

Pass context to specialized agents:
```yaml
context:
  service_name: <name>
  repo_path: <path>
  repo_url: <url>
  branch: <branch>
  mode: local|remote
  last_commit: <sha>
```

### 5. Post-Analysis Operations

#### For Local Mode
- Report what was generated
- Suggest review commands: `git status`, `git diff`
- NO auto-commit

#### For Remote Mode
- Create branch: `git checkout -b auto/<type>-<timestamp>`
- Add generated files: `git add <generated_files>`
- Commit with descriptive message
- Push to origin: `git push origin <branch>`
- Report PR URL

#### For Batch Mode
- Track success/failure for each service
- Continue on failure (don't stop batch)
- Provide summary at end

### 6. Cleanup

#### For Local Mode
- No cleanup needed (working in place)

#### For Remote Mode
- Remove temporary directory: `rm -rf <temp_dir>`

#### For Batch Mode
- Remove all temporary directories

---

## Error Handling

### Repository Errors
- **Not a git repo**: Inform user to run `git init`
- **Service not found**: Suggest `microforge service add`
- **Clone failed**: Report error, skip in batch mode
- **No remote access**: Report auth/network issue

### Analysis Errors
- **Agent failure**: Report which agent failed
- **Partial completion**: Report what was completed
- **Write permission**: Check directory permissions

---

## Context Passing to Specialized Agents

Provide this context structure to all specialized agents:

```yaml
operation:
  command_type: analyze|audit|setup  # IMPORTANT: Determines which agent to call
  mode: local|remote|batch
  target: <service_name_or_dot>
  flags:
    docs_only: boolean
    deps_only: boolean
    force: boolean

repository:
  name: <service_name>
  path: <absolute_path>
  url: <repo_url>
  branch: <branch_name>
  last_commit: <commit_sha>
  
workspace:
  temp_dir: <path_if_remote>
  output_dir: <where_to_generate>
  
analysis:
  skip_docs: boolean
  skip_deps: boolean
  existing_metadata: <previous_analysis_info>
```

---

## Success Criteria

The orchestrator successfully:
- Detects correct operation mode
- Provides repository access to specialized agents
- Coordinates multiple agents when needed
- Handles errors gracefully
- Cleans up temporary resources
- Reports clear status to user