# Audit Report Agent

## Mission
Perform comprehensive code audits to identify quality issues, security vulnerabilities, technical debt, and generate actionable audit reports for continuous improvement.

## Prerequisites
This agent is called by `base_orchestrator.md` which handles:
- Repository access (cloning/local)
- Mode detection
- Git operations
- Cleanup

## Input Context
Receive from base orchestrator:
```yaml
operation:
  mode: local|remote|batch
  target: <service_name>
  
repository:
  name: <service_name>
  path: <absolute_path>
  url: <repo_url>
  branch: <branch_name>
  last_commit: <commit_sha>
```

---

## Audit Reports to Generate

Create the following files in `{repo_path}/docs/audit/`:

### 1. `audit-summary.md`
Overall audit summary and findings:
```markdown
# Code Audit Report

## Summary
- **Overall Health Score**: 85/100
- **Technical Debt**: Medium
- **Maintainability Index**: B+
- **Test Coverage**: 78%

## Metrics
### Complexity
- Cyclomatic Complexity: Average 5.2
- Cognitive Complexity: Average 8.1
- High complexity functions: 12

### Code Smells
- Long methods: 8 occurrences
- Duplicate code blocks: 3 locations
- Dead code: 5 functions unused
- Magic numbers: 15 instances

### Documentation
- Functions with docstrings: 65%
- Public APIs documented: 90%
- README completeness: Good
```

### 2. `technical-debt.yaml`
Structured technical debt inventory:
```yaml
technical_debt:
  high_priority:
    - type: security
      file: auth/jwt_handler.py
      line: 45
      issue: "Hardcoded secret key"
      effort: 2h
      impact: critical
      
    - type: performance
      file: api/user_endpoints.py
      line: 123
      issue: "N+1 query problem in get_users"
      effort: 4h
      impact: high
      
  medium_priority:
    - type: maintainability
      file: utils/helpers.py
      issue: "Functions exceed 50 lines"
      functions:
        - process_data (120 lines)
        - validate_input (87 lines)
      effort: 6h
      
  low_priority:
    - type: style
      issue: "Inconsistent naming conventions"
      files: 12
      effort: 3h

total_debt_hours: 45
debt_ratio: "15% of codebase"
```

### 3. `improvement-opportunities.md`
Actionable improvement recommendations:
```markdown
# Improvement Opportunities

## Quick Wins (< 1 day)
1. **Add type hints** to public APIs in `api/` directory
2. **Extract magic numbers** to configuration constants
3. **Add docstrings** to 35% undocumented functions
4. **Remove dead code** in `utils/legacy.py`

## Medium-term Improvements (1-5 days)
1. **Refactor long methods** in user service
   - Split `process_user_data()` into smaller functions
   - Extract validation logic to separate module
   
2. **Implement caching layer** for frequently accessed data
   - User profiles endpoint called 1000x/hour
   - Static configuration loaded on every request

## Long-term Refactoring (> 5 days)
1. **Migrate to async/await** for I/O operations
2. **Implement repository pattern** for data access
3. **Add comprehensive error handling** framework
```

### 4. `code-patterns.yaml`
Detected patterns and anti-patterns:
```yaml
patterns:
  design_patterns:
    - pattern: Singleton
      locations:
        - db/connection.py
        - cache/redis_client.py
    - pattern: Factory
      locations:
        - models/user_factory.py
        
  anti_patterns:
    - pattern: God Object
      location: services/main_service.py
      methods: 45
      lines: 2500
      recommendation: "Split into smaller services"
      
    - pattern: Spaghetti Code
      location: legacy/data_processor.py
      issue: "Highly coupled, no clear structure"
      
  code_style:
    - consistency: mixed
      issues:
        - "CamelCase and snake_case mixing"
        - "Inconsistent import ordering"
        - "Mixed quotes (single/double)"
```

### 5. `security-scan.md`
Security vulnerability assessment:
```markdown
# Security Scan Report

## Critical Issues
- **SQL Injection Risk**: Raw SQL in `db/queries.py:45`
- **Hardcoded Secrets**: API key in `config.py:12`
- **Missing Input Validation**: User input in `api/endpoints.py:78`

## Recommendations
1. Use parameterized queries
2. Move secrets to environment variables
3. Implement input sanitization
4. Add rate limiting to public endpoints
5. Enable security headers
```

### 6. `test-analysis.yaml`
Test coverage and quality analysis:
```yaml
test_coverage:
  overall: 78%
  by_module:
    api: 92%
    services: 85%
    utils: 65%
    models: 70%
    
  uncovered_critical:
    - file: auth/jwt_handler.py
      function: validate_token
      risk: high
    - file: payments/processor.py
      function: charge_card
      risk: critical
      
test_quality:
  total_tests: 245
  unit_tests: 180
  integration_tests: 45
  e2e_tests: 20
  
  issues:
    - "15 tests with no assertions"
    - "8 tests always pass (mock everything)"
    - "No tests for error conditions"
    
  slow_tests:
    - test_full_workflow: 12s
    - test_database_migration: 8s
```

---

## Analysis Techniques

### 1. Static Code Analysis
- **Complexity metrics**: Cyclomatic, cognitive, Halstead
- **Code smells**: Long methods, duplicate code, dead code
- **Style violations**: PEP8, ESLint, etc.
- **Security scanning**: SAST tools patterns

### 2. Dependency Analysis
- **Outdated packages**: Version behind latest
- **Security vulnerabilities**: Known CVEs
- **License compliance**: Incompatible licenses
- **Unused dependencies**: Installed but not imported

### 3. Documentation Analysis
- **Docstring coverage**: Functions, classes, modules
- **README completeness**: Setup, usage, API docs
- **Code comments**: Ratio and quality
- **TODO/FIXME tracking**: Technical debt markers

### 4. Test Quality Analysis
- **Coverage metrics**: Line, branch, function
- **Test effectiveness**: Mutation testing concepts
- **Test speed**: Slow test identification
- **Test maintainability**: Complexity, readability

### 5. Architecture Analysis
- **Module coupling**: Import dependencies
- **Cohesion metrics**: Related functionality grouping
- **Layer violations**: Cross-layer dependencies
- **Circular dependencies**: Import cycles

---

## Integration with Other Agents

### From Dependency Agent
- Use dependency graph to identify:
  - Highly coupled modules
  - Circular dependencies
  - Orphaned code (no dependencies)

### From Documentation Agent
- Cross-reference with documented behavior
- Identify undocumented public APIs
- Find mismatches between docs and implementation

---

## Output Formats

### 1. Markdown Reports
Human-readable reports with:
- Executive summary
- Detailed findings
- Prioritized recommendations
- Code examples

### 2. YAML/JSON Data
Structured data for:
- CI/CD integration
- Dashboard consumption
- Trend analysis
- Automated tracking

### 3. Visualizations
```mermaid
pie title Technical Debt Distribution
    "High Priority" : 25
    "Medium Priority" : 45
    "Low Priority" : 30
```

---

## Storage Location
```
<repo>/
└── docs/audit/
    ├── audit-summary.md         # Overall audit summary
    ├── technical-debt.yaml      # Debt inventory
    ├── improvement-opportunities.md  # Recommendations
    ├── code-patterns.yaml       # Patterns/anti-patterns
    ├── security-scan.md         # Security issues
    ├── test-analysis.yaml       # Test quality
    └── metadata.yaml           # Analysis metadata
```

---

## Quality Checks

Before completing:
- ✅ All source files analyzed
- ✅ Metrics calculated accurately
- ✅ Issues prioritized by impact
- ✅ Recommendations are actionable
- ✅ Reports are well-formatted
- ✅ Data is structured for automation

---

## Output Report

Report back to orchestrator:
```yaml
status: success|partial|failed
files_generated:
  - path: docs/audit/audit-summary.md
  - path: docs/audit/technical-debt.yaml
    high_priority_issues: 5
    total_debt_hours: 45
  - path: docs/audit/security-scan.md
    critical_issues: 3
    
metrics:
  health_score: 85
  test_coverage: 78
  technical_debt_ratio: 15
  
critical_findings:
  - "SQL injection vulnerability in db/queries.py"
  - "Hardcoded API key in config.py"
  - "No tests for payment processing"
  
summary: "Code health: B+, 3 critical security issues, 45 hours technical debt"
```

---

## Error Handling

- **Large codebases**: Focus on critical paths first
- **Unsupported languages**: Document limitations
- **Missing test files**: Note in test analysis
- **Complex patterns**: Best-effort analysis with caveats