# Service-Specific Agent Discovery

## Purpose
Analyze a service's commit history and codebase to discover what service-specific agents are needed beyond the standard global agents.

## Context
You are analyzing the service: `{{SERVICE_NAME}}`
Repository path: `{{REPO_PATH}}`

## Git Commit History
```
{{GIT_HISTORY}}
```

## File Change Frequency
```
{{FILE_CHANGES}}
```

## Your Task

Analyze the provided git commit history and file changes to identify service-specific patterns and recommend specialized agents for this service.

### Focus Areas:

1. **Bug Patterns**: Identify recurring bug fixes in specific modules or files
2. **Feature Patterns**: Recognize common types of features being implemented
3. **Hot Spots**: Files that are frequently modified and need special attention
4. **Domain Logic**: Service-specific business rules and patterns
5. **Integration Points**: External services, APIs, or third-party integrations
6. **Data Patterns**: Database migrations, schema changes, model updates

### What NOT to Recommend:

Do not recommend agents for tasks already covered by global agents:
- `documentation.md` - Documentation generation
- `security.md` - Security analysis
- `test_generator.md` - Test creation
- `dependency_graph.md` - Dependency analysis
- `performance.md` - Performance optimization
- `refactoring.md` - Code refactoring

### Generate Service-Specific Agents

Based on your analysis, create the following:

1. **implementation.md** (REQUIRED)
   - Master orchestrator for this service
   - Should reference both global agents and service-specific agents
   - Include service-specific guidelines based on patterns found

2. **Additional Service-Specific Agents** (as needed)
   Create agents only for patterns unique to this service, such as:
   - Bug fix specialist for recurring issues in specific modules
   - API evolution agent if frequent API changes
   - Data migration specialist if many schema changes
   - Hot spot manager for frequently modified files
   - Business logic agent for domain-specific patterns
   - Integration specialist for third-party services

### Output Format

For each recommended agent, create the agent file content with:

#### AGENT: [agent_name].md
```markdown
# [Agent Title] for {{SERVICE_NAME}}

## Purpose
[Specific purpose for this service]

## Service-Specific Knowledge
[What this agent knows about the service based on commit history]

## Patterns Identified
[Specific patterns from the commit history]

## Guidelines
[Service-specific guidelines for this type of work]

## Common Issues
[Recurring problems this agent should handle]

## Hot Spots
[Frequently modified files related to this agent's domain]
```

### Analysis Guidelines

1. **Quantify Patterns**: Use percentages and counts from commit history
2. **Be Specific**: Reference actual files, modules, and commit messages
3. **Prioritize**: Focus on the most significant patterns (>10% of commits)
4. **Justify**: Explain why each agent is needed based on data
5. **Avoid Duplication**: Don't recreate functionality of global agents

## Begin Analysis

Analyze the commit history and generate the recommended service-specific agents: