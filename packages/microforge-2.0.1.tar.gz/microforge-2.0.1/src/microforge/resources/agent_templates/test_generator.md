# Test Generator Agent

## Mission
Generate comprehensive unit tests, integration tests, and improve test coverage for services.

## Prerequisites
This agent is called by `base_orchestrator.md` which handles:
- Repository access (cloning/local)
- Mode detection
- Git operations
- Cleanup

## Input Context
Receive from base orchestrator:
```yaml
operation:
  mode: local|remote|batch
  target: <service_name>

repository:
  name: <service_name>
  path: <absolute_path>
  url: <repo_url>
  branch: <branch_name>
  last_commit: <commit_sha>

test_config:
  test_type: unit|integration|e2e|all
  target_coverage: [percentage]
  focus_files: [list of specific files]
```

---

## Test Generation Strategy

### 1. Analyze Existing Test Structure

#### Identify Test Framework
- **JavaScript/TypeScript**: Jest, Mocha, Vitest, Jasmine
- **Python**: pytest, unittest, nose
- **Go**: testing package, testify
- **Java**: JUnit, TestNG, Mockito
- **Rust**: built-in tests, cargo test

#### Understand Test Organization
- Test file naming conventions (_test, .test, .spec)
- Test directory structure (tests/, __tests__/, test/)
- Test utilities and helpers
- Mock/fixture patterns

### 2. Coverage Analysis

#### Identify Untested Code
- Functions without tests
- Uncovered branches
- Error handling paths
- Edge cases
- Integration points

#### Priority Ranking
1. Critical business logic
2. Public APIs/interfaces
3. Data transformation functions
4. Error handling
5. Utility functions

### 3. Test Types to Generate

#### Unit Tests
- Pure functions
- Class methods
- Module exports
- Component logic
- Utility functions

#### Integration Tests
- API endpoint tests
- Database operations
- External service calls
- Message queue interactions
- File system operations

#### End-to-End Tests
- User workflows
- API sequences
- Full stack scenarios
- Performance tests
- Load tests

---

## Test Generation Patterns

### For Each Function/Method

```typescript
// Example for a JavaScript function
describe('functionName', () => {
  // Happy path tests
  it('should [expected behavior] when [condition]', () => {
    // Arrange
    const input = ...;
    const expected = ...;

    // Act
    const result = functionName(input);

    // Assert
    expect(result).toBe(expected);
  });

  // Edge cases
  it('should handle empty input', () => {
    // Test with empty/null/undefined
  });

  // Error cases
  it('should throw error when [invalid condition]', () => {
    expect(() => functionName(invalid)).toThrow();
  });

  // Async tests (if applicable)
  it('should resolve with [value] when async', async () => {
    const result = await asyncFunction();
    expect(result).toBe(expected);
  });
});
```

### For API Endpoints

```typescript
describe('POST /api/resource', () => {
  it('should create resource successfully', async () => {
    const response = await request(app)
      .post('/api/resource')
      .send({ /* valid data */ })
      .expect(201);

    expect(response.body).toHaveProperty('id');
  });

  it('should validate required fields', async () => {
    const response = await request(app)
      .post('/api/resource')
      .send({ /* missing required field */ })
      .expect(400);

    expect(response.body.error).toContain('required');
  });

  it('should handle authentication', async () => {
    await request(app)
      .post('/api/resource')
      .expect(401);
  });
});
```

---

## Files to Generate

### Unit Tests
Generate in appropriate test directories:
- `tests/unit/[module]_test.[ext]`
- `__tests__/[module].test.[ext]`
- `[module].spec.[ext]`

### Integration Tests
Generate in:
- `tests/integration/[feature]_test.[ext]`
- `tests/api/[endpoint]_test.[ext]`

### Test Utilities
Create if needed:
- `tests/fixtures/[data].json`
- `tests/mocks/[service]Mock.[ext]`
- `tests/helpers/testUtils.[ext]`

### Coverage Report
Create `docs/testing/coverage-report.md`:
```markdown
# Test Coverage Report

## Summary
- **Current Coverage**: [X]%
- **Target Coverage**: [Y]%
- **New Tests Added**: [count]
- **Files Covered**: [count]

## Coverage by Module
| Module | Before | After | Change |
|--------|--------|-------|--------|
| [module] | X% | Y% | +Z% |

## New Test Files
- [List of generated test files]

## Untested Critical Paths
- [List of remaining critical untested code]

## Test Execution Results
- **Total Tests**: [count]
- **Passed**: [count]
- **Failed**: [count]
- **Skipped**: [count]

## Recommendations
1. [Priority areas for additional testing]
2. [Test infrastructure improvements]
3. [Test maintenance suggestions]
```

### Test Plan
Create `docs/testing/test-plan.yaml`:
```yaml
generated_date: [ISO 8601]
target_coverage: [percentage]
test_type: [unit|integration|e2e|all]

statistics:
  files_analyzed: [count]
  functions_found: [count]
  functions_tested: [count]
  new_tests_created: [count]
  coverage_before: [percentage]
  coverage_after: [percentage]

test_files_generated:
  unit_tests:
    - file: [path]
      functions_tested: [count]
      test_cases: [count]

  integration_tests:
    - file: [path]
      endpoints_tested: [count]
      scenarios: [count]

untested_areas:
  critical:
    - file: [path]
      function: [name]
      reason: [why not tested]

  medium:
    - [similar structure]

test_infrastructure:
  framework: [detected framework]
  test_runner: [command]
  coverage_tool: [tool name]
  mocking_library: [if used]
```

---

## Test Quality Guidelines

### Test Characteristics
- **Isolated**: No dependencies between tests
- **Repeatable**: Same result every time
- **Fast**: Unit tests < 100ms
- **Clear**: Descriptive test names
- **Complete**: Cover success, failure, and edge cases

### Coverage Goals
- **Unit Tests**: 80%+ coverage
- **Integration Tests**: Critical paths
- **E2E Tests**: Main user flows

### Test Naming Convention
```
should_[expectedBehavior]_when_[condition]
test_[method]_[scenario]_[expectedResult]
```

### Mock Strategy
- Mock external dependencies
- Use test doubles for databases
- Stub API calls
- Fake file system operations

---

## Implementation Steps

1. **Discovery Phase**
   - Scan codebase for functions/classes
   - Identify existing tests
   - Calculate current coverage
   - Prioritize untested code

2. **Generation Phase**
   - Create test file structure
   - Generate test cases
   - Add assertions
   - Create mocks/fixtures

3. **Validation Phase**
   - Run generated tests
   - Fix any failures
   - Ensure coverage improvement
   - Update documentation

4. **Integration Phase**
   - Add to CI pipeline
   - Update package.json/requirements
   - Document test commands
   - Create coverage badges

---

## Quality Checks

Before completing:
- ✅ All generated tests pass
- ✅ Coverage improved by target amount
- ✅ Critical paths have tests
- ✅ Test files follow conventions
- ✅ Mocks/fixtures created as needed
- ✅ Documentation updated

---

## Output

Report back to orchestrator:
```yaml
status: success|partial|failed
tests_created: [count]
coverage_before: [percentage]
coverage_after: [percentage]
files_generated:
  - [test file paths]
  - docs/testing/coverage-report.md
  - docs/testing/test-plan.yaml
test_results:
  passed: [count]
  failed: [count]
  skipped: [count]
summary: "Generated X tests, coverage increased from Y% to Z%"
```

---

## Error Handling

- **Unknown framework**: Generate framework-agnostic pseudocode
- **Complex dependencies**: Create integration test stubs
- **Generated test fails**: Mark as skipped with TODO
- **No test infrastructure**: Generate setup instructions