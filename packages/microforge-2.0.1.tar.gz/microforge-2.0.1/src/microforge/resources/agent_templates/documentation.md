# Documentation Agent

## Mission
Generate comprehensive LLM-aware documentation for services based on code analysis.

## Prerequisites
This agent is called by `base_orchestrator.md` which handles:
- Repository access (cloning/local)
- Mode detection
- Git operations
- Cleanup

## Input Context
Receive from base orchestrator:
```yaml
operation:
  mode: local|remote|batch
  target: <service_name>
  
repository:
  name: <service_name>
  path: <absolute_path>
  url: <repo_url>
  branch: <branch_name>
  last_commit: <commit_sha>
```

## Hook Detection
**IMPORTANT**: Check if `.microforge/` directory exists in the repository.
- If YES: Read `.microforge/config.yaml` to get enabled hooks
- Read hook files from `.microforge/hooks/` directory
- Include hooks dynamically in CLAUDE.md based on what's configured
- If NO: Skip hooks sections

---

## Documentation to Generate

Create the following files in `{repo_path}/docs/service/`:

### architecture.md
- Service overview and purpose
- Core components and modules
- External dependencies and integrations
- Technology stack
- Deployment architecture
- Security considerations
- Include Mermaid diagrams for visual representation

### repo-structure.md
- Directory tree of important files/folders
- Purpose of each major directory
- Key files and their responsibilities
- Code organization patterns
- Module dependencies

### features.md
- Core business features
- API capabilities
- Feature flags (if present)
- Planned features (from TODOs/comments)
- Business value mapping

### api-contracts.md
- All REST endpoints (method, path, purpose)
- Request/response schemas with examples
- Authentication mechanisms
- Rate limiting rules
- Error response formats
- WebSocket/GraphQL endpoints if present

### data-flow.md
- Input sources (APIs, queues, databases)
- Data transformation logic
- Output destinations
- Database schemas and operations
- Caching patterns
- Event/message flows

### env-variables.md
- Required environment variables with descriptions
- Optional variables with defaults
- Configuration file locations
- Secret management approach
- Environment-specific settings

### known-issues.md
- TODOs and FIXMEs found in code
- Performance bottlenecks
- Technical debt items
- Current limitations
- Suggested improvements

### runbook.md
- Local development setup steps
- Build commands
- Test execution commands
- Deployment process
- Monitoring endpoints
- Common issues and solutions
- Debugging tips

### metadata.yaml
```yaml
service_name: [from context]
repository_url: [from context]
branch: [from context]
last_analyzed: [current ISO 8601 timestamp]
last_commit_analyzed: [from context]
documentation_version: "1.0.0"
language: [detected from files]
framework: [detected from dependencies]
database: [detected from config/code]
messaging: [kafka/rabbitmq/etc if found]
deployment: [k8s/docker/etc if found]
test_framework: [pytest/jest/etc]
has_unit_tests: [true/false]
has_integration_tests: [true/false]
ci_tool: [detected from .github/gitlab-ci/etc]
authentication: [oauth/jwt/etc if found]
owner: [from CODEOWNERS or package files]
criticality: [assess based on functionality]
dependencies: 
  - [major dependencies from package files]
tags:
  - [relevant tags based on functionality]
stats:
  total_files: [number of source files]
  lines_of_code: [approximate LOC]
  api_endpoints: [number of endpoints]
  test_coverage: [if available from CI]
```

---

## CLAUDE.md Management

### Location
Create/update at `{repo_path}/CLAUDE.md`

### Update Strategy

#### If CLAUDE.md doesn't exist:
Create new file with all standard sections.

#### If CLAUDE.md exists:
1. **Read** existing content
2. **Parse** into sections (preserve custom content)
3. **Check** if `.microforge/hooks/` exists - if yes, add/update hooks section
4. **Update** documentation list section:
   ```markdown
   ## 📚 Required Documentation
   
   <!-- Microforge: Updated YYYY-MM-DD HH:MM:SS -->
   Before making ANY changes, you MUST read these documents in `docs/service/`:
   
   - **architecture.md** - [Specific description based on analysis]
   - **api-contracts.md** - [Specific description based on analysis]
   ... [update all file descriptions]
   ```
5. **Preserve** all custom sections and developer notes
6. **Append** new findings without duplicating
7. **Add** timestamp comment for tracking

### CLAUDE.md Generation Steps

1. **Detect Project Info**:
   - Service name from repo name or package files
   - Language/framework from package files
   - Description from README or package description

2. **Check for Hooks**:
   ```bash
   # Check if hooks are configured
   if [ -f .microforge/config.yaml ]; then
     # Read config.yaml to get enabled hooks
     # Structure: hooks: {hook_name: {enabled: true/false, priority: N, version: X}}
   fi
   ```
   - Read `.microforge/config.yaml` to identify enabled hooks
   - For each enabled hook, note its priority and version
   - Read corresponding `.microforge/hooks/[hook_name]_hook.md` files
   - Group hooks by type (pre/post) for the requirements sections

3. **Generate Dynamic Sections**:

```markdown
# CLAUDE.md - AI Assistant Instructions for [Service Name]

## ⚠️ MANDATORY: YOU MUST FOLLOW ALL HOOKS LISTED BELOW

[IF HOOKS EXIST - Generate dynamically based on config.yaml:]

## 🎯 ACTIVE HOOKS - THESE ARE REQUIRED

**IMPORTANT**: You MUST read the FULL CONTENT of each hook file listed below to understand all requirements.

[Group hooks by type - if pre hooks exist:]
### Pre-Execution (BEFORE any code changes):
[For each pre hook ordered by priority:]
[Number]. **[Hook Name]**:
   - **File**: `.microforge/hooks/[filename]`
   - **YOU MUST READ THIS FILE COMPLETELY** to understand all requirements
   - Summary: [Extract one-line summary if possible]

[Group hooks by type - if post hooks exist:]
### Post-Execution (AFTER code changes):
[For each post hook ordered by priority:]
[Number]. **[Hook Name]**:
   - **File**: `.microforge/hooks/[filename]`
   - **YOU MUST READ THIS FILE COMPLETELY** to understand all requirements
   - Summary: [Extract one-line summary if possible]

## 📋 COMPLIANCE IS MANDATORY

After completing work, you MUST report:
```
HOOK COMPLIANCE:
[For each enabled hook:]
✅ [Hook Name]: [What you did to comply]
```

[END IF HOOKS EXIST]

[IF NO HOOKS EXIST:]
## ℹ️ No Hooks Configured

This project does not have Microforge hooks. Consider running `microforge hooks init`.
[END IF NO HOOKS]

## 📚 Required Documentation

Before making changes, read documentation in `docs/service/` if it exists.

## 📁 Key Locations

- **Hooks**: `.microforge/hooks/` - Hook requirements
- **Config**: `.microforge/config.yaml` - Hook settings
- **Docs**: `docs/service/` - Service documentation

---
Generated by Microforge v0.1.0 on [Current Date]
```

### Example Output

When generating CLAUDE.md, if you find enabled hooks in `.microforge/config.yaml`:

```markdown
# CLAUDE.md - AI Assistant Instructions for [service-name]

## ⚠️ MANDATORY: YOU MUST FOLLOW ALL HOOKS LISTED BELOW

## 🎯 ACTIVE HOOKS - THESE ARE REQUIRED

**IMPORTANT**: You MUST read the FULL CONTENT of each hook file listed below to understand all requirements.

### Pre-Execution (BEFORE any code changes):
[For each pre-execution hook found in config, ordered by priority]
1. **[Hook Name from config]**:
   - **File**: `.microforge/hooks/[hook_filename]`
   - **YOU MUST READ THIS FILE COMPLETELY**
   - Summary: [One line summary if extractable]

### Post-Execution (AFTER code changes):
[For each post-execution hook found in config, ordered by priority]
1. **[Hook Name from config]**:
   - **File**: `.microforge/hooks/[hook_filename]`
   - **YOU MUST READ THIS FILE COMPLETELY**
   - Summary: [One line summary if extractable]

## 📋 COMPLIANCE IS MANDATORY

After completing work, you MUST report:
```
HOOK COMPLIANCE:
✅ [Each enabled hook]: [Description of what was done to comply]
```

## 📚 Required Documentation

Before making changes, read documentation in `docs/service/` if it exists.

## 📁 Key Locations

- **Hooks**: `.microforge/hooks/` - Hook requirements
- **Config**: `.microforge/config.yaml` - Hook settings
- **Docs**: `docs/service/` - Service documentation

---
Generated by Microforge v0.1.0 on [Current Date]
```

---

## Analysis Guidelines

1. **Start with configuration**: package.json, requirements.txt, go.mod, pom.xml, etc.
2. **Identify entry points**: main files, app files, index files
3. **Follow code flow**: Trace imports and function calls
4. **Extract from comments**: Use docstrings, TODOs, FIXMEs
5. **Analyze tests**: Understand functionality from test cases
6. **Check CI/CD**: Review workflow files for deployment info
7. **Detect patterns**: MVC, microservice, event-driven, etc.

---

## Quality Checks

Before completing:
- ✅ No placeholder text - all sections have real analysis
- ✅ Code examples included where relevant
- ✅ Mermaid diagrams created for architecture and data flow
- ✅ All environment variables documented
- ✅ API endpoints have example requests/responses
- ✅ Runbook has actual, working commands
- ✅ CLAUDE.md appropriately updated/created

---

## Output

Report back to orchestrator:
```yaml
status: success|partial|failed
files_generated:
  - path: docs/service/architecture.md
    lines: 250
  - path: docs/service/api-contracts.md
    lines: 500
  ... 
claude_md_updated: true|false
issues_found:
  - "Performance middleware disabled"
  - "CORS too permissive"
  ...
summary: "Generated 9 documentation files with X total lines"
```

---

## Error Handling

- **Missing dependencies**: Document what's detected, note limitations
- **Unusual structure**: Adapt to what's found, note in repo-structure.md
- **Access errors**: Skip protected files, document in known-issues.md
- **Large codebases**: Focus on core functionality, note scope in metadata.yaml