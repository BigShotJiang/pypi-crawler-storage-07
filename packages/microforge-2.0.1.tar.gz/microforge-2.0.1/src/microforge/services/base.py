"""
Base service class for Microforge v2.

Provides common interface and functionality for all services.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional
from datetime import datetime

from pathlib import Path

from ..core.exceptions import ServiceError, ValidationError
from ..config.settings import get_settings
from ..config.constants import PACKAGE_DIR, AGENTS_SUBDIR


class BaseService(ABC):
    """Abstract base class for all Microforge services."""

    def __init__(self):
        self.settings = get_settings()
        self.name = self.__class__.__name__
        self.created_at = datetime.utcnow()

        # Lazy-loaded singleton providers
        self._git_provider = None
        self._llm_manager = None
        self._registry = None

    def validate_input(self, data: Any) -> bool:
        """
        Validate input data for the service.

        Args:
            data: Input data to validate

        Returns:
            True if valid

        Raises:
            ValidationError: If validation fails
        """
        # Default implementation - can be overridden
        return True

    def handle_error(self, error: Exception, operation: str, context: Optional[Dict[str, Any]] = None) -> None:
        """
        Handle errors that occur during service operations.

        Args:
            error: The exception that occurred
            operation: Name of the operation that failed
            context: Additional context about the error
        """
        # Default error handling - can be overridden
        raise ServiceError(
            f"{self.name} operation '{operation}' failed: {str(error)}",
            service_name=self.name,
            operation=operation,
            context=context
        ) from error

    def get_service_info(self) -> Dict[str, Any]:
        """Get information about this service."""
        return {
            "name": self.name,
            "class": self.__class__.__name__,
            "created_at": self.created_at.isoformat(),
            "settings_loaded": self.settings is not None
        }

    def is_healthy(self) -> bool:
        """Check if the service is healthy and ready to handle requests."""
        return True

    def get_dependencies(self) -> list:
        """Get list of external dependencies required by this service."""
        return []

    @property
    def git_provider(self):
        """Get singleton GitProvider instance."""
        if self._git_provider is None:
            from ..providers.vcs.git import GitProvider
            self._git_provider = GitProvider()
        return self._git_provider

    @property
    def llm_manager(self):
        """Get singleton LLM manager instance."""
        if self._llm_manager is None:
            from ..providers.llm.manager import get_llm_manager
            self._llm_manager = get_llm_manager()
        return self._llm_manager

    @property
    def registry(self):
        """Get singleton registry manager instance."""
        if self._registry is None:
            from ..registries.manager import get_registry_manager
            self._registry = get_registry_manager()
        return self._registry

    @staticmethod
    def get_agents_directory() -> Path:
        """Get the agents directory path."""
        return PACKAGE_DIR / AGENTS_SUBDIR

    def build_prompt(self, command_type: str, context: Dict[str, Any], agent_file: Optional[Path] = None) -> str:
        """Build a prompt for LLM execution.

        Args:
            command_type: Type of command being executed
            context: Context dictionary with command details
            agent_file: Optional agent file to read instructions from

        Returns:
            Minimal prompt directing to system instructions
        """
        # Return minimal prompt - main instructions are in system prompt
        if agent_file and agent_file.exists():
            return f"Execute the agent instructions from {agent_file}"
        else:
            return f"Execute the {command_type} operation"

    def build_system_prompt(self, command_type: str, context: Dict[str, Any], agent_file: Optional[Path] = None) -> str:
        """Build a system prompt for LLM execution.

        Args:
            command_type: Type of command being executed
            context: Context dictionary with command details
            agent_file: Optional path to agent file with instructions

        Returns:
            System prompt string
        """
        parts = []

        # Primary instruction - load and execute agent file
        if agent_file and agent_file.exists():
            parts.extend([
                f"Load and execute the agent instructions from: {agent_file}",
                "",
                "EXECUTION REQUIREMENTS:",
                "1. Read the entire agent file at the specified location",
                "2. Execute ALL steps and sub-agents mentioned in the agent file",
                "3. For orchestrator agents, execute each sub-agent in the specified order",
                "4. Generate all required outputs as specified in the agent instructions",
                "5. Use the provided tools to complete the tasks",
                "",
                "CONTEXT:",
                f"- Command Type: {command_type}",
                f"- Working Directory: {context.get('repo_path', '.')}"
            ])

            if 'service_name' in context:
                parts.append(f"- Service: {context['service_name']}")

            if 'mode' in context:
                parts.append(f"- Mode: {context['mode']}")

            if context.get('docs_only'):
                parts.append("- Task: Generate documentation only")
            elif context.get('deps_only'):
                parts.append("- Task: Generate dependency graphs only")

            parts.extend([
                "",
                "EXIT REQUIREMENTS:",
                "After completing ALL tasks from the agent file:",
                "1. Verify all outputs have been generated",
                "2. Ensure the workflow is complete",
                "3. Exit immediately - do NOT wait for additional prompts"
            ])
        else:
            # Fallback if no agent file
            parts.extend([
                f"Execute the {command_type} operation.",
                f"Working directory: {context.get('repo_path', '.')}"
            ])

        return " ".join(parts)

    def cleanup(self) -> None:
        """Cleanup resources when service is destroyed."""
        pass

    def __str__(self) -> str:
        return f"{self.name}(created_at={self.created_at})"

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__} name='{self.name}' created_at='{self.created_at}'>"


class ServiceRegistry:
    """Registry for managing service instances."""

    def __init__(self):
        self._services: Dict[str, BaseService] = {}

    def register(self, name: str, service: BaseService) -> None:
        """Register a service instance."""
        if not isinstance(service, BaseService):
            raise ValueError(f"Service must inherit from BaseService, got {type(service)}")

        self._services[name] = service

    def get(self, name: str) -> Optional[BaseService]:
        """Get a service by name."""
        return self._services.get(name)

    def get_all(self) -> Dict[str, BaseService]:
        """Get all registered services."""
        return self._services.copy()

    def unregister(self, name: str) -> bool:
        """Unregister a service."""
        if name in self._services:
            service = self._services[name]
            service.cleanup()
            del self._services[name]
            return True
        return False

    def is_registered(self, name: str) -> bool:
        """Check if a service is registered."""
        return name in self._services

    def list_names(self) -> list:
        """List all registered service names."""
        return list(self._services.keys())

    def health_check(self) -> Dict[str, bool]:
        """Check health of all registered services."""
        return {name: service.is_healthy() for name, service in self._services.items()}


# Global service registry
_service_registry = ServiceRegistry()


def get_service_registry() -> ServiceRegistry:
    """Get the global service registry."""
    return _service_registry


def register_service(name: str, service: BaseService) -> None:
    """Register a service in the global registry."""
    _service_registry.register(name, service)


def get_service(name: str) -> Optional[BaseService]:
    """Get a service from the global registry."""
    return _service_registry.get(name)