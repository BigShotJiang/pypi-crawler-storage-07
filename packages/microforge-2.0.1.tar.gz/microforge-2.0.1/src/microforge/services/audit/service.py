"""
Audit service implementation for Microforge v2.

Handles comprehensive code quality, security, and technical debt analysis.
"""

import time
from pathlib import Path
from typing import List, Dict, Any

from ...config.constants import (
    DOCS_DIR,
    ERROR_NOT_GIT_REPO,
    AGENT_AUDIT_REPORT
)
from ...core.common import console, print_success, print_error, print_info, print_warning
from ...core.exceptions import ValidationError, FileSystemError, NotFoundError
from ..base import BaseService
from .models import AuditRequest, AuditResult


class AuditService(BaseService):
    """
    Service for comprehensive code auditing.

    Provides security analysis, technical debt assessment, and code quality metrics.
    """

    def __init__(self):
        super().__init__()

    def audit(self, request: AuditRequest) -> AuditResult:
        """
        Perform comprehensive code audit.

        Args:
            request: Audit request with configuration

        Returns:
            Audit result with findings and recommendations

        Raises:
            ValidationError: If validation fails
            NotFoundError: If agent files are missing
        """
        start_time = time.time()
        result = AuditResult(
            success=False,
            mode="unknown",
            target=request.target
        )

        try:
            # Validate agent files exist
            self._validate_agent_files()

            # Determine audit mode
            result.mode = self._determine_mode(request)

            # Validate git repository for local mode
            if request.is_local:
                if not self.git_provider.is_git_repository():
                    raise ValidationError(ERROR_NOT_GIT_REPO)
                print_success("Git repository detected")

            # Show audit configuration
            self._show_audit_config(request, result)

            # Execute audit
            if request.audit_all:
                self._audit_all_services(request, result)
            elif request.is_local:
                self._audit_local(request, result)
            else:
                self._audit_service(request, result)

            # Calculate execution time
            result.execution_time_ms = (time.time() - start_time) * 1000

            # Set success if no errors
            result.success = not result.has_errors

            if result.success:
                self._show_audit_summary(result)

            return result

        except Exception as e:
            result.errors.append(str(e))
            result.execution_time_ms = (time.time() - start_time) * 1000
            print_error(f"Audit failed: {str(e)}")
            return result

    def _validate_agent_files(self) -> None:
        """Validate that required agent files exist."""
        # Check for audit agent file in resources
        from ...config.constants import PACKAGE_DIR, AGENTS_SUBDIR

        agents_dir = PACKAGE_DIR / AGENTS_SUBDIR
        audit_agent_file = agents_dir / AGENT_AUDIT_REPORT

        if not audit_agent_file.exists():
            raise NotFoundError(
                f"Missing audit agent file: {AGENT_AUDIT_REPORT}",
                context={"expected_path": str(audit_agent_file)}
            )

    def _determine_mode(self, request: AuditRequest) -> str:
        """Determine audit mode based on request."""
        if request.audit_all:
            return "batch"
        elif request.is_local:
            return "local"
        else:
            return "remote"

    def _show_audit_config(self, request: AuditRequest, result: AuditResult) -> None:
        """Show audit configuration and workflow."""
        if result.mode == "batch":
            console.print("[bold cyan]🔍 Auditing all registered services[/bold cyan]\n")
        elif result.mode == "local":
            service_name = Path.cwd().name
            console.print(f"[bold cyan]🔍 Auditing current directory: {service_name}[/bold cyan]\n")
        else:
            console.print(f"[bold cyan]🔍 Auditing service: {request.target}[/bold cyan]\n")

        # Show audit scope
        if request.security_only:
            print_warning("🔐 Running: Security audit only")
        elif request.debt_only:
            print_warning("💳 Running: Technical debt analysis only")
        elif request.quick:
            print_warning("⚡ Running: Quick audit (essential checks)")
        else:
            print_warning("📊 Running: Full comprehensive audit")

        print_warning(f"📄 Output format: {request.format}")
        print_warning(f"⚠️ Health threshold: {request.threshold}/100")

        # Show workflow
        self._show_workflow(request, result.mode)

    def _show_workflow(self, request: AuditRequest, mode: str) -> None:
        """Show audit workflow steps."""
        console.print("\n[bold]🤖 AI Audit Workflow:[/bold]")
        console.print("1. Analyze code structure and complexity")

        if not request.debt_only:
            console.print("2. Scan for security vulnerabilities")
        if not request.security_only:
            console.print("3. Identify technical debt")
        if not request.quick:
            console.print("4. Analyze test coverage and quality")
            console.print("5. Check documentation completeness")

        console.print("6. Generate audit reports")

        if mode == "local":
            console.print("7. Save reports locally (no auto-commit)")
        elif mode == "remote":
            console.print("7. Create branch and generate PR")
        elif mode == "batch":
            console.print("7. Process each service sequentially")
            console.print("8. Provide summary report")

    def _audit_all_services(self, request: AuditRequest, result: AuditResult) -> None:
        """Audit all registered services."""
        services = self.registry.services.list_services()

        if not services:
            result.warnings.append("No services registered for audit")
            return

        print_info(f"Found {len(services)} services to audit")

        for service in services:
            try:
                # Create individual audit request
                service_request = AuditRequest(
                    target=service.name,
                    security_only=request.security_only,
                    debt_only=request.debt_only,
                    quick=request.quick,
                    format=request.format,
                    threshold=request.threshold,
                    batch_mode=request.batch_mode
                )

                service_result = self._audit_service_impl(service_request, service.repo_url)

                # Aggregate results
                result.output_files.extend(service_result.output_files)
                result.security_issues.extend(service_result.security_issues)
                result.debt_items.extend(service_result.debt_items)
                result.recommendations.extend(service_result.recommendations)

            except Exception as e:
                error_msg = f"Failed to audit service {service.name}: {str(e)}"
                result.errors.append(error_msg)
                print_error(error_msg)

    def _audit_local(self, request: AuditRequest, result: AuditResult) -> None:
        """Audit current directory."""
        service_name = Path.cwd().name
        audit_result = self._audit_service_impl(request, None, local_path=Path.cwd())

        # Copy results
        result.health_score = audit_result.health_score
        result.output_files = audit_result.output_files
        result.security_issues = audit_result.security_issues
        result.debt_items = audit_result.debt_items
        result.recommendations = audit_result.recommendations
        result.errors.extend(audit_result.errors)
        result.warnings.extend(audit_result.warnings)

    def _audit_service(self, request: AuditRequest, result: AuditResult) -> None:
        """Audit specific service."""
        # Look up service in registry
        service = self.registry.services.get_service(request.target)

        if not service:
            raise NotFoundError(f"Service '{request.target}' not found in registry")

        audit_result = self._audit_service_impl(request, service.repo_url)

        # Copy results
        result.health_score = audit_result.health_score
        result.output_files = audit_result.output_files
        result.security_issues = audit_result.security_issues
        result.debt_items = audit_result.debt_items
        result.recommendations = audit_result.recommendations
        result.errors.extend(audit_result.errors)
        result.warnings.extend(audit_result.warnings)

    def _audit_service_impl(
        self,
        request: AuditRequest,
        repo_url: str = None,
        local_path: Path = None
    ) -> AuditResult:
        """Implementation for auditing a single service."""
        context = {
            "service_name": request.target if not request.is_local else Path.cwd().name,
            "repo_url": repo_url,
            "mode": "local" if local_path else "remote",
            "security_only": request.security_only,
            "debt_only": request.debt_only,
            "quick": request.quick,
            "format": request.format,
            "threshold": request.threshold,
            "repo_path": str(local_path) if local_path else f"/tmp/{request.target}"
        }

        # Always use LLM manager which will select provider automatically
        return self._audit_with_llm(context, request)

    def _audit_with_llm(self, context: Dict[str, Any], request: AuditRequest) -> AuditResult:
        """Perform audit using LLM provider."""
        # Build prompts for LLM
        from ...config.constants import PACKAGE_DIR, AGENTS_SUBDIR, AGENT_AUDIT_REPORT
        agent_file = PACKAGE_DIR / AGENTS_SUBDIR / AGENT_AUDIT_REPORT

        prompt = self.build_prompt("audit", context, agent_file)
        system_prompt = self.build_system_prompt("audit", context, agent_file)

        # Add prompts to context
        context["prompt"] = prompt
        context["system_prompt"] = system_prompt

        # LLM manager will automatically select the provider based on config/env
        llm_result = self.llm_manager.run_analysis(
            command_type="audit",
            context=context,
            interactive=not request.batch_mode
        )

        result = AuditResult(
            success=bool(llm_result),
            mode=context["mode"],
            target=context["service_name"]
        )

        if result.success and isinstance(llm_result, dict):
            # Extract results from LLM response
            result.health_score = llm_result.get("health_score")
            result.output_files = llm_result.get("output_files", [])
            result.security_issues = llm_result.get("security_issues", [])
            result.debt_items = llm_result.get("debt_items", [])
            result.recommendations = llm_result.get("recommendations", [])
        elif not result.success:
            error_msg = "LLM audit failed"
            result.errors.append(error_msg)

        return result

    def _audit_with_fallback(self, context: Dict[str, Any], request: AuditRequest) -> AuditResult:
        """Fallback audit implementation (not currently used)."""
        result = AuditResult(
            success=True,
            mode=context["mode"],
            target=context["service_name"],
            health_score=75  # Default placeholder score
        )

        # Basic audit implementation
        result.recommendations = [
            "Enable LLM provider for comprehensive audit",
            "Review code manually for security issues",
            "Check test coverage",
            "Update documentation"
        ]

        result.warnings.append("Limited audit without LLM provider")

        return result

    def _show_audit_summary(self, result: AuditResult) -> None:
        """Show audit completion summary."""
        if result.mode == "local":
            print_success("Audit complete. Results in docs/audit/")
        else:
            print_success("Audit complete")

        # Show health score if available
        if result.health_score is not None:
            if result.meets_threshold:
                print_success(f"Health score: {result.health_score}/100")
            else:
                print_warning(f"Health score: {result.health_score}/100 (below threshold)")

        # Show critical issues
        if result.critical_security_issues:
            print_error(f"Critical security issues: {len(result.critical_security_issues)}")

        if result.high_priority_debt:
            print_warning(f"High priority debt items: {len(result.high_priority_debt)}")

        # Show output files
        if result.output_files:
            console.print("\n[bold]📁 Generated files:[/bold]")
            for file_path in result.output_files:
                console.print(f"  • {file_path}")

    def get_expected_outputs(self, request: AuditRequest) -> List[str]:
        """Get list of expected output files."""
        outputs = []

        if not request.security_only:
            outputs.extend([
                "docs/audit/audit-summary.md - Overall audit report",
                "docs/audit/technical-debt.yaml - Debt inventory",
                "docs/audit/improvement-opportunities.md - Recommendations",
            ])

        if not request.debt_only:
            outputs.append("docs/audit/security-scan.md - Security vulnerabilities")

        if not request.quick:
            outputs.extend([
                "docs/audit/test-analysis.yaml - Test quality metrics",
                "docs/audit/code-patterns.yaml - Patterns and anti-patterns",
            ])

        return outputs