"""
Audit service models for Microforge v2.

Data models for audit operations.
"""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from pathlib import Path


class AuditRequest(BaseModel):
    """Request model for audit operations."""

    target: str = Field(default=".", description="Target to audit (path or service name)")
    audit_all: bool = Field(default=False, description="Audit all registered services")
    security_only: bool = Field(default=False, description="Only run security audit")
    debt_only: bool = Field(default=False, description="Only analyze technical debt")
    quick: bool = Field(default=False, description="Quick audit (skip detailed analysis)")
    format: str = Field(default="markdown", description="Output format")
    threshold: int = Field(default=80, description="Health score threshold for warnings")
    batch_mode: bool = Field(default=False, description="Run LLM in batch mode")

    @property
    def is_local(self) -> bool:
        """Check if auditing current directory."""
        return self.target == "."


class AuditResult(BaseModel):
    """Result model for audit operations."""

    success: bool = Field(description="Whether audit completed successfully")
    mode: str = Field(description="Audit mode (local, remote, batch)")
    target: str = Field(description="Target that was audited")
    health_score: Optional[int] = Field(default=None, description="Overall health score (0-100)")
    output_files: List[str] = Field(default_factory=list, description="Generated audit files")
    security_issues: List[Dict[str, Any]] = Field(default_factory=list, description="Security issues found")
    debt_items: List[Dict[str, Any]] = Field(default_factory=list, description="Technical debt items")
    recommendations: List[str] = Field(default_factory=list, description="Improvement recommendations")
    errors: List[str] = Field(default_factory=list, description="Errors encountered")
    warnings: List[str] = Field(default_factory=list, description="Warnings")
    execution_time_ms: float = Field(default=0.0, description="Execution time in milliseconds")

    @property
    def has_errors(self) -> bool:
        """Check if there were any errors."""
        return len(self.errors) > 0

    @property
    def has_warnings(self) -> bool:
        """Check if there were any warnings."""
        return len(self.warnings) > 0

    @property
    def critical_security_issues(self) -> List[Dict[str, Any]]:
        """Get critical security issues."""
        return [issue for issue in self.security_issues if issue.get("severity") == "critical"]

    @property
    def high_priority_debt(self) -> List[Dict[str, Any]]:
        """Get high priority technical debt items."""
        return [debt for debt in self.debt_items if debt.get("priority") == "high"]

    @property
    def meets_threshold(self) -> bool:
        """Check if health score meets threshold."""
        if self.health_score is None:
            return False
        # Threshold should be passed from request, but default to 80
        return self.health_score >= 80