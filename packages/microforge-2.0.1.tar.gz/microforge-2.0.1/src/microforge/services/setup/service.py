"""
Setup service implementation for Microforge v2.

Handles project initialization, hooks setup, and documentation generation.
"""

import time
from pathlib import Path
from typing import List, Dict, Any

from ...config.constants import (
    MICROFORGE_PROJECT_DIR,
    MICROFORGE_PROJECT_CONFIG,
    MICROFORGE_PROJECT_HOOKS_DIR,
    DOCS_DIR,
    DOCS_SERVICE_DIR,
    CLAUDE_MD_FILENAME,
    SUCCESS_HOOKS_INITIALIZED,
    ERROR_NOT_GIT_REPO
)
from ...core.common import console, print_success, print_error, print_info
from ...core.exceptions import ValidationError, FileSystemError
from ..base import BaseService
from ..hooks.service import HooksService
from ..analysis.service import AnalysisService
from .models import SetupRequest, SetupResult


class SetupService(BaseService):
    """
    Service for project setup and initialization.

    Handles Microforge setup including hooks, documentation, and CLAUDE.md generation.
    """

    def __init__(self):
        super().__init__()
        self.hooks_service = HooksService()
        self.analysis_service = AnalysisService()

    def setup_project(self, request: SetupRequest) -> SetupResult:
        """
        Set up Microforge in a project.

        Args:
            request: Setup request with configuration

        Returns:
            Setup result with created files and status

        Raises:
            ValidationError: If validation fails
            FileSystemError: If file operations fail
        """
        start_time = time.time()
        result = SetupResult(success=False)

        try:
            # Validate git repository
            if not self.git_provider.is_git_repository(request.target_path):
                raise ValidationError(
                    ERROR_NOT_GIT_REPO,
                    context={"path": str(request.target_path)}
                )

            print_success("Git repository detected")

            # Step 1: Initialize hooks (unless docs-only)
            if not request.docs_only:
                self._setup_hooks(request, result)

            # Step 2: Generate documentation (unless hooks-only)
            if not request.hooks_only:
                self._setup_documentation(request, result)

            # Step 3: Create or update CLAUDE.md
            self._setup_claude_instructions(request, result)

            # Calculate execution time
            result.execution_time_ms = (time.time() - start_time) * 1000

            # Set success if no errors
            result.success = not result.has_errors

            if result.success:
                print_success("Setup complete!")
                self._show_summary(result)

            return result

        except Exception as e:
            result.errors.append(str(e))
            result.execution_time_ms = (time.time() - start_time) * 1000
            print_error(f"Setup failed: {str(e)}")
            return result

    def _setup_hooks(self, request: SetupRequest, result: SetupResult) -> None:
        """Set up hooks for the project."""
        print_info("Initializing hooks...")

        try:
            from ..hooks.models import HooksRequest

            hooks_request = HooksRequest(
                target_path=request.target_path,
                force=request.force,
                update=request.update
            )

            hooks_result = self.hooks_service.init_hooks(hooks_request)

            if hooks_result.success:
                result.created_files.extend(hooks_result.created_files)
                result.updated_files.extend(hooks_result.updated_files)
                print_success("Hooks initialized")
            else:
                result.errors.extend(hooks_result.errors)
                result.warnings.extend(hooks_result.warnings)

        except Exception as e:
            error_msg = f"Failed to initialize hooks: {str(e)}"
            result.errors.append(error_msg)
            print_error(error_msg)


    def _setup_documentation(self, request: SetupRequest, result: SetupResult) -> None:
        """Set up documentation generation."""
        print_info("Analyzing codebase...")

        try:
            # Always use LLM manager which will select provider automatically
            self._setup_with_llm(request, result)

        except Exception as e:
            error_msg = f"Failed to generate documentation: {str(e)}"
            result.errors.append(error_msg)
            print_error(error_msg)

    def _setup_with_llm(self, request: SetupRequest, result: SetupResult) -> None:
        """Set up documentation using LLM provider."""
        context = {
            "command_type": "setup",
            "service_name": request.target_path.name,
            "repo_path": str(request.target_path),
            "mode": "local",
            "docs_only": request.docs_only,
            "force": request.force,
            "setup_mode": True,
            "update": request.update
        }

        # Build prompts for LLM
        # For setup docs, we should use the base orchestrator agent
        from ...config.constants import PACKAGE_DIR, AGENTS_SUBDIR, AGENT_BASE_ORCHESTRATOR
        agent_file = None
        if request.docs_only or not request.hooks_only:
            agent_file = PACKAGE_DIR / AGENTS_SUBDIR / AGENT_BASE_ORCHESTRATOR

        prompt = self.build_prompt("setup", context, agent_file)
        system_prompt = self.build_system_prompt("setup", context, agent_file)

        # Add prompts to context
        context["prompt"] = prompt
        context["system_prompt"] = system_prompt

        # LLM manager will automatically select the provider based on config/env
        llm_result = self.llm_manager.run_analysis(
            command_type="setup",
            context=context,
            interactive=not request.batch_mode
        )

        if llm_result:
            print_success("Analysis complete")
            # Track created files if provided
            if isinstance(llm_result, dict) and "created_files" in llm_result:
                result.created_files.extend(llm_result["created_files"])
        else:
            error_msg = "LLM analysis failed"
            result.errors.append(error_msg)

    def _setup_with_analysis_fallback(self, request: SetupRequest, result: SetupResult) -> None:
        """Fallback setup using built-in analysis (not currently used)."""
        from ..analysis.models import AnalysisRequest

        analysis_request = AnalysisRequest(
            target=str(request.target_path),
            analyze_all=False,
            docs_only=request.docs_only,
            deps_only=False,
            force=request.force,
            batch_mode=False
        )

        analysis_result = self.analysis_service.analyze(analysis_request)

        if analysis_result.success:
            result.created_files.extend(analysis_result.output_files)
            print_success("Analysis complete")
        else:
            result.errors.extend(analysis_result.errors)

    def _setup_claude_instructions(self, request: SetupRequest, result: SetupResult) -> None:
        """Create or update CLAUDE.md with project instructions."""
        claude_md_path = request.target_path / CLAUDE_MD_FILENAME

        try:
            # Check if hooks are set up
            hooks_config_path = request.target_path / MICROFORGE_PROJECT_CONFIG
            hooks_dir_path = request.target_path / MICROFORGE_PROJECT_HOOKS_DIR

            hooks_enabled = hooks_config_path.exists() and hooks_dir_path.exists()

            # Generate CLAUDE.md content
            content = self._generate_claude_md_content(
                project_name=request.target_path.name,
                hooks_enabled=hooks_enabled
            )

            # Write CLAUDE.md
            claude_md_path.write_text(content, encoding='utf-8')

            if claude_md_path in [Path(f) for f in result.created_files]:
                pass  # Already tracked
            else:
                result.created_files.append(str(claude_md_path))

        except Exception as e:
            error_msg = f"Failed to create CLAUDE.md: {str(e)}"
            result.errors.append(error_msg)

    def _generate_claude_md_content(self, project_name: str, hooks_enabled: bool) -> str:
        """Generate content for CLAUDE.md file."""
        status = "ENABLED" if hooks_enabled else "DISABLED"

        return f"""# CLAUDE.md - AI Assistant Instructions for {project_name}

This repository uses Microforge for documentation generation and code quality enforcement.

## 📍 Repository Overview

**Project**: {project_name}
**Generated by**: Microforge v2.0.0
**Documentation**: Located in `docs/service/` (if generated)

## 🎯 ACTIVE HOOKS

### 1. Planning Hook (MANDATORY FIRST STEP)
**Status**: {status}
**Source**: `.microforge/hooks/planning_pre_hook.md`
**Action**: Creates implementation plans before code changes

### 2. Code Quality Hook
**Status**: {status}
**Source**: `.microforge/hooks/code_quality_hook.md`
**Action**: Ensures tests, docs, and quality standards

## REQUIREMENTS FOR AI ASSISTANTS

When making ANY code changes in this repository:

1. **Planning Phase** (REQUIRED - Planning Hook):
   - Create implementation plan in `docs/planning/` BEFORE any code changes
   - Include: requirements analysis, technical approach, files to modify
   - **Present plan to user and ASK**: "Should I proceed with this implementation?"
   - **WAIT for explicit approval** - Never start coding without confirmation
   - Update the plan as implementation progresses
   - See full requirements: `.microforge/hooks/planning_pre_hook.md`

2. **Before Changes**:
   - Read existing code and documentation
   - Identify test locations using repository structure
   - Check code patterns and conventions

3. **After Changes** (Code Quality Hook):
   - ✅ Update/create tests for all new code
   - ✅ Add docstrings to public functions/classes
   - ✅ Update relevant documentation
   - ✅ Update CHANGELOG.md if user-facing
   - See full requirements: `.microforge/hooks/code_quality_hook.md`

## 📁 Important Locations

- **Hooks**: `.microforge/hooks/` - Full hook definitions
- **Config**: `.microforge/config.yaml` - Hook configuration
- **Documentation**: `docs/service/` - Generated documentation (if exists)
- **Plans**: `docs/planning/` - Implementation plans (created as needed)

## Compliance Report Format

After making changes, report:
```
MICROFORGE HOOK COMPLIANCE:
✅ Planning: Created plan in docs/planning/[filename].md
✅ Tests: [Created/Updated] - [files]
✅ Docs: [Updated] - [files]
✅ Docstrings: [Added] - [functions]
✅ CHANGELOG: [Updated] - [description]
```

## IMPORTANT: Planning & Approval are MANDATORY

For ANY request that involves code changes:
1. FIRST create a plan in `docs/planning/`
2. PRESENT the plan and WAIT for user approval
3. ONLY THEN implement following the approved plan
4. UPDATE the plan with progress checkmarks

**NEVER skip the approval step** - Always ask: "Should I proceed with this implementation plan?"

## 🔍 Repository-Specific Information

Run `microforge analyze .` to generate comprehensive documentation for this repository.

---
Generated by Microforge v2.0.0 on {time.strftime("%Y-%m-%d")}
"""

    def _show_summary(self, result: SetupResult) -> None:
        """Show setup completion summary."""
        console.print("\n[bold]📁 Created files:[/bold]")

        files_to_check = [
            ("CLAUDE.md", "AI assistant instructions with hooks"),
            (".microforge/config.yaml", "Microforge configuration"),
            (".microforge/hooks/", "Hook definitions"),
            ("docs/service/", "Service documentation")
        ]

        for file_path, description in files_to_check:
            path = Path(file_path)
            if path.exists():
                console.print(f"  ✅ {file_path} - {description}")

        # Add next steps
        result.next_steps = [
            "Review generated files: git status",
            "Check documentation: ls -la docs/service/",
            'Commit when ready: git add . && git commit -m "chore: Initialize Microforge"'
        ]

        console.print("\n[bold]📋 Next steps:[/bold]")
        for step in result.next_steps:
            console.print(f"  • {step}")

        console.print("\n[dim]AI assistants will now follow project standards and documentation[/dim]")