"""
Setup service models for Microforge v2.

Data models for setup operations.
"""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from pathlib import Path


class SetupRequest(BaseModel):
    """Request model for setup operations."""

    target_path: Path = Field(default_factory=lambda: Path.cwd(), description="Target directory path")
    force: bool = Field(default=False, description="Regenerate everything even if it exists")
    docs_only: bool = Field(default=False, description="Only generate documentation")
    hooks_only: bool = Field(default=False, description="Only initialize hooks")
    update: bool = Field(default=False, description="Update existing setup to latest version")
    batch_mode: bool = Field(default=False, description="Run LLM in batch mode")


class SetupResult(BaseModel):
    """Result model for setup operations."""

    success: bool = Field(description="Whether setup completed successfully")
    created_files: List[str] = Field(default_factory=list, description="List of created files")
    updated_files: List[str] = Field(default_factory=list, description="List of updated files")
    errors: List[str] = Field(default_factory=list, description="List of errors encountered")
    warnings: List[str] = Field(default_factory=list, description="List of warnings")
    next_steps: List[str] = Field(default_factory=list, description="Recommended next steps")
    execution_time_ms: float = Field(default=0.0, description="Execution time in milliseconds")

    @property
    def has_errors(self) -> bool:
        """Check if there were any errors."""
        return len(self.errors) > 0

    @property
    def has_warnings(self) -> bool:
        """Check if there were any warnings."""
        return len(self.warnings) > 0

    @property
    def total_files_affected(self) -> int:
        """Get total number of files affected."""
        return len(self.created_files) + len(self.updated_files)