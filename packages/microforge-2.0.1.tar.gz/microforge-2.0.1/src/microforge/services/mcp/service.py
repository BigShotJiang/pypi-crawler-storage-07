"""
MCP service implementation for Microforge v2.

Handles Model Context Protocol server operations with agent execution.
"""

import asyncio
import json
from pathlib import Path
from typing import Dict, Any, Optional, List
from datetime import datetime

from ...config.constants import PACKAGE_DIR, AGENTS_SUBDIR
from ...core.common import console, print_success, print_error, print_info, print_warning
from ...core.exceptions import ValidationError, FileSystemError, NotFoundError
from ...registries.manager import get_registry_manager
from ...services.agents.service import AgentsService
from ..base import BaseService
from .models import MCPServerRequest, MCPServerResult, MCPToolRequest, MCPToolResponse


class MCPAgentExecutor:
    """MCP-specific executor for all agents"""

    def __init__(self):
        self.registry = get_registry_manager()
        self.agents_service = AgentsService()

    async def run_agent(self, agent_name: str, arguments: Dict[str, Any]) -> str:
        """Execute any agent with given arguments"""

        agent_config = self.registry.agents.get_agent(agent_name)
        if not agent_config:
            return f"Error: Unknown agent '{agent_name}'"

        # Get repository path
        repo_path = Path(arguments.get("path", ".")).resolve()

        if not repo_path.exists():
            return f"Error: Path {repo_path} does not exist"

        # Get service name if provided
        service_name = arguments.get("service_name", repo_path.name)

        # Get agent prompt from Azure or local storage
        agent_prompt = self.registry.agents.get_agent_prompt(
            agent_name,
            service=service_name if service_name != repo_path.name else None
        )

        if not agent_prompt:
            # Fallback to default execution without custom prompt
            print_warning(f"No prompt found for agent '{agent_name}', using default")

        try:
            # Use the agents service for execution
            from ...services.agents.models import AgentExecutionRequest

            request = AgentExecutionRequest(
                agent_name=agent_name,
                service_name=service_name,
                local_path=repo_path,
                mode="local",
                docs_only=arguments.get("docs_only", False),
                deps_only=arguments.get("deps_only", False),
                force=arguments.get("force", False),
                custom_prompt=agent_prompt  # Pass the Azure-loaded prompt if available
            )

            result = self.agents_service.execute_agent(request)

            if result.success:
                return f"""# {agent_name.replace('_', ' ').title()} Completed

**Repository**: {repo_path.name}
**Path**: {repo_path}
**Status**: Success
**Files Generated**: {result.total_files_generated}

## Output Files
{chr(10).join(f"- {file}" for file in result.output_files)}

All analysis files have been generated successfully."""
            else:
                return f"""# {agent_name.replace('_', ' ').title()} Failed

**Repository**: {repo_path.name}
**Path**: {repo_path}
**Status**: Failed

## Errors
{chr(10).join(f"- {error}" for error in result.errors)}"""

        except Exception as e:
            return f"Error executing agent '{agent_name}': {str(e)}"


class MCPService(BaseService):
    """
    Service for MCP (Model Context Protocol) server operations.

    Handles MCP server startup in both stdio and HTTP modes.
    """

    def __init__(self):
        super().__init__()
        # registry is provided by BaseService as a property
        self.executor = MCPAgentExecutor()
        self.agents_dir = PACKAGE_DIR / AGENTS_SUBDIR

    def start_stdio_server(self, request: MCPServerRequest) -> MCPServerResult:
        """
        Start MCP server in stdio mode for Claude Desktop integration.

        Args:
            request: MCP server request

        Returns:
            MCP server result
        """
        result = MCPServerResult(
            success=False,
            mode="stdio"
        )

        try:
            console.print("[green]Starting Microforge MCP server (stdio mode)...[/green]")
            console.print("[yellow]This server will communicate via stdio for Claude Desktop[/yellow]")

            # Check if MCP package is available
            try:
                from mcp.server import Server, NotificationOptions
                from mcp.server.models import InitializationOptions
                import mcp.server.stdio
                import mcp.types as types
            except ImportError as e:
                result.errors.append(f"MCP package not installed: {e}")
                print_error("MCP package not found. Install with: pip install mcp")
                return result

            # Create and run the MCP server
            server_instance = MicroforgeStdioServer(
                registry=self.registry,
                executor=self.executor,
                agents_dir=self.agents_dir
            )

            # This will run the server - blocking operation
            asyncio.run(server_instance.run())

            result.success = True
            print_success("MCP stdio server completed")

        except Exception as e:
            result.errors.append(str(e))
            print_error(f"Error starting MCP stdio server: {str(e)}")

        return result

    def start_http_server(self, request: MCPServerRequest) -> MCPServerResult:
        """
        Start MCP server in HTTP mode.

        Args:
            request: MCP server request

        Returns:
            MCP server result
        """
        result = MCPServerResult(
            success=False,
            mode="http",
            host=request.host,
            port=request.port
        )

        try:
            console.print(f"[green]Starting Microforge MCP HTTP server on {request.host}:{request.port}...[/green]")

            # Check if required packages are available
            try:
                from fastapi import FastAPI
                import uvicorn
            except ImportError as e:
                result.errors.append(f"HTTP server dependencies not installed: {e}")
                print_error("Install with: pip install fastapi uvicorn")
                return result

            # Create and run the HTTP server
            http_server = MicroforgeHTTPServer(
                registry=self.registry,
                executor=self.executor,
                host=request.host,
                port=request.port
            )

            # This will run the server - blocking operation
            http_server.run()

            result.success = True
            print_success("MCP HTTP server completed")

        except Exception as e:
            result.errors.append(str(e))
            print_error(f"Error starting MCP HTTP server: {str(e)}")

        return result

    def list_mcp_tools(self) -> List[Dict[str, Any]]:
        """List all available MCP tools."""
        tools = []

        # Get agents from registry
        registry_agents = self.registry.agents.list_agents()
        for agent in registry_agents:
            if not agent.enabled:
                continue

            tools.append({
                "name": f"microforge_{agent.id}",
                "display_name": agent.display_name,
                "description": agent.description,
                "category": getattr(agent, 'category', None),
                "tags": getattr(agent, 'tags', []),
                "enabled": agent.enabled,
                "source": "registry"
            })

        return tools

    def test_mcp_functionality(self) -> Dict[str, Any]:
        """Test MCP server functionality."""
        test_results = {
            "registry_test": False,
            "server_import_test": False,
            "agent_count": 0,
            "errors": []
        }

        try:
            # Test registry
            agents = self.registry.agents.list_agents()
            test_results["registry_test"] = True
            test_results["agent_count"] = len(agents)

            # Test server imports
            try:
                from mcp.server import Server
                test_results["server_import_test"] = True
            except ImportError:
                test_results["errors"].append("MCP package not installed")

        except Exception as e:
            test_results["errors"].append(str(e))

        return test_results


class MicroforgeStdioServer:
    """MCP Server for stdio mode (Claude Desktop integration)"""

    def __init__(self, registry, executor, agents_dir):
        try:
            from mcp.server import Server
            self.server = Server("microforge")
        except ImportError:
            raise ImportError("MCP package not installed. Run: pip install mcp")

        self.registry = registry
        self.executor = executor
        self.agents_dir = agents_dir
        self._setup_tools()

    def _setup_tools(self):
        """Dynamically register all discovered agents as tools"""
        from mcp import types

        @self.server.list_tools()
        async def handle_list_tools() -> List[types.Tool]:
            """Dynamically generate tool list from discovered agents"""
            tools = []

            # Add agent discovery tool
            tools.append(types.Tool(
                name="microforge_discover_agents",
                description="Discover available Microforge agents by category or tags",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "category": {
                            "type": "string",
                            "description": "Filter by category",
                            "enum": ["analysis", "quality", "security", "testing", "optimization", "development", "orchestration"]
                        },
                        "tags": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Filter by tags"
                        }
                    }
                }
            ))

            # Add registered agents as tools
            for agent in self.registry.agents.list_agents():
                if not agent.enabled:
                    continue

                # Build enhanced description
                description_parts = [agent.description or f"Execute {agent.id} agent"]

                if hasattr(agent, 'category') and agent.category:
                    description_parts.append(f"Category: {agent.category}")

                tools.append(types.Tool(
                    name=f"microforge_{agent.id}",
                    description=" | ".join(description_parts),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "path": {
                                "type": "string",
                                "description": "Path to repository",
                                "default": "."
                            },
                            "service_name": {
                                "type": "string",
                                "description": "Name of the service"
                            },
                            "docs_only": {
                                "type": "boolean",
                                "description": "Only generate documentation"
                            },
                            "deps_only": {
                                "type": "boolean",
                                "description": "Only generate dependencies"
                            },
                            "force": {
                                "type": "boolean",
                                "description": "Force regeneration"
                            }
                        }
                    }
                ))

            return tools

        @self.server.call_tool()
        async def handle_call_tool(
            name: str,
            arguments: Optional[Dict[str, Any]] = None
        ) -> List[types.TextContent]:
            """Execute any registered agent dynamically"""
            from mcp import types

            if arguments is None:
                arguments = {}

            # Handle agent discovery
            if name == "microforge_discover_agents":
                result = await self._discover_agents(arguments)
                return [types.TextContent(type="text", text=result)]

            # Extract agent name from tool name
            if not name.startswith("microforge_"):
                raise ValueError(f"Invalid tool name: {name}")

            agent_name = name.replace("microforge_", "")

            # Execute the agent
            result = await self.executor.run_agent(agent_name, arguments)

            return [types.TextContent(type="text", text=result)]

    async def _discover_agents(self, arguments: Dict[str, Any]) -> str:
        """Discover agents based on filters"""
        category_filter = arguments.get("category")
        tags_filter = arguments.get("tags", [])

        results = []
        for agent in self.registry.agents.list_agents():
            if not agent.enabled:
                continue

            # Apply category filter
            if category_filter and getattr(agent, 'category', None) != category_filter:
                continue

            # Apply tags filter
            if tags_filter:
                agent_tags = getattr(agent, 'tags', [])
                if not any(tag in agent_tags for tag in tags_filter):
                    continue

            results.append({
                "name": agent.id,
                "display_name": agent.display_name,
                "description": agent.description,
                "category": getattr(agent, 'category', None),
                "tags": getattr(agent, 'tags', [])
            })

        if not results:
            return "No agents found matching the specified criteria."

        output = ["# Discovered Microforge Agents\n"]

        if category_filter:
            output.append(f"**Category Filter**: {category_filter}")
        if tags_filter:
            output.append(f"**Tags Filter**: {', '.join(tags_filter)}")

        output.append("")

        for agent in results:
            output.append(f"## {agent['display_name']}")
            output.append(f"**Name**: `{agent['name']}`")
            output.append(f"**Description**: {agent['description']}")
            if agent['category']:
                output.append(f"**Category**: {agent['category']}")
            if agent['tags']:
                output.append(f"**Tags**: {', '.join(agent['tags'])}")
            output.append("")

        return "\n".join(output)

    async def run(self):
        """Run the MCP server"""
        from mcp.server.models import InitializationOptions
        from mcp.server import NotificationOptions
        import mcp.server.stdio

        async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
            await self.server.run(
                read_stream,
                write_stream,
                InitializationOptions(
                    server_name="microforge",
                    server_version="2.0.0",
                    capabilities=self.server.get_capabilities(
                        notification_options=NotificationOptions(),
                        experimental_capabilities={},
                    ),
                ),
            )


class MicroforgeHTTPServer:
    """HTTP server for MCP over HTTP"""

    def __init__(self, registry, executor, host: str = "127.0.0.1", port: int = 3333):
        try:
            from fastapi import FastAPI
            from fastapi.middleware.cors import CORSMiddleware
        except ImportError:
            raise ImportError("HTTP server dependencies not installed. Run: pip install fastapi uvicorn")

        self.app = FastAPI(
            title="Microforge MCP Server",
            description="HTTP API for Microforge agents",
            version="2.0.0"
        )
        self.registry = registry
        self.executor = executor
        self.host = host
        self.port = port
        self._setup_routes()
        self._setup_cors()

    def _setup_cors(self):
        """Configure CORS for the API"""
        from fastapi.middleware.cors import CORSMiddleware

        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

    def _setup_routes(self):
        """Setup HTTP routes"""
        from fastapi import HTTPException, Response
        from fastapi.responses import StreamingResponse, JSONResponse
        import asyncio
        import json as json_module

        @self.app.get("/")
        async def root():
            """Root endpoint with server info"""
            return {
                "name": "Microforge MCP Server",
                "version": "2.0.0",
                "status": "running",
                "endpoints": {
                    "agents": "/agents",
                    "agent_details": "/agent/{agent_name}",
                    "tools": "/tools",
                    "execute": "/execute",
                    "health": "/health"
                },
                "description": "MCP server exposing Microforge agents for Claude Code integration"
            }

        @self.app.post("/register")
        async def register_client():
            """MCP client registration endpoint"""
            return {
                "sessionId": "microforge-session",
                "capabilities": {
                    "tools": True,
                    "prompts": False,
                    "resources": False
                }
            }

        @self.app.get("/sse")
        async def sse_endpoint():
            """Server-sent events endpoint for MCP protocol"""
            async def event_generator():
                # Send initial connection event
                yield f"data: {json_module.dumps({'type': 'connection', 'status': 'connected'})}\n\n"

                # Send tools list
                tools = []
                for agent in self.registry.agents.list_agents():
                    if not agent.enabled:
                        continue
                    tools.append({
                        "name": f"microforge_{agent.id}",
                        "description": agent.description,
                        "inputSchema": getattr(agent, 'input_schema', {})
                    })

                yield f"data: {json_module.dumps({'type': 'tools', 'tools': tools})}\n\n"

                # Keep connection alive
                while True:
                    await asyncio.sleep(30)
                    yield f"data: {json_module.dumps({'type': 'ping'})}\n\n"

            return StreamingResponse(
                event_generator(),
                media_type="text/event-stream",
                headers={
                    "Cache-Control": "no-cache",
                    "Connection": "keep-alive",
                    "X-Accel-Buffering": "no"
                }
            )

        @self.app.get("/.well-known/oauth-authorization-server")
        async def oauth_metadata():
            """OAuth2 metadata endpoint"""
            base_url = "http://0.0.0.0:3333"
            return {
                "issuer": base_url,
                "authorization_endpoint": f"{base_url}/authorize",
                "token_endpoint": f"{base_url}/token",
                "response_types_supported": ["code"],
                "code_challenge_methods_supported": ["S256"],
                "grant_types_supported": ["authorization_code"],
                "scopes_supported": ["mcp.read", "mcp.write"]
            }

        @self.app.get("/authorize")
        async def authorize(
            client_id: str = "",
            redirect_uri: str = "",
            state: str = "",
            code_challenge: str = "",
            code_challenge_method: str = "S256"
        ):
            """OAuth authorization endpoint - auto-approves for local dev"""
            from fastapi import Response
            from fastapi.responses import RedirectResponse
            import secrets

            # Generate a simple auth code
            auth_code = secrets.token_urlsafe(32)

            # Redirect back with the auth code
            redirect_url = f"{redirect_uri}?code={auth_code}&state={state}"
            return RedirectResponse(url=redirect_url, status_code=302)

        @self.app.post("/token")
        async def token(
            grant_type: str = "authorization_code",
            code: str = "",
            redirect_uri: str = "",
            code_verifier: str = ""
        ):
            """OAuth token endpoint - returns a dummy token for local dev"""
            import secrets
            return {
                "access_token": secrets.token_urlsafe(32),
                "token_type": "Bearer",
                "expires_in": 3600,
                "scope": "mcp.read mcp.write"
            }

        @self.app.post("/mcp/v1/init")
        async def mcp_init():
            """MCP initialization endpoint for HTTP transport"""
            return {
                "protocolVersion": "1.0",
                "serverInfo": {
                    "name": "microforge",
                    "version": "2.0.0"
                },
                "capabilities": {
                    "tools": {}
                }
            }

        @self.app.post("/mcp/v1/tools/list")
        async def mcp_list_tools():
            """MCP tools list endpoint"""
            tools = []
            for agent in self.registry.agents.list_agents():
                if not agent.enabled:
                    continue

                # Build input schema
                input_schema = getattr(agent, 'input_schema', {})
                if not input_schema:
                    input_schema = {
                        "type": "object",
                        "properties": {
                            "path": {
                                "type": "string",
                                "description": "Path to repository"
                            }
                        }
                    }

                tools.append({
                    "name": f"microforge_{agent.id}",
                    "description": agent.description or f"Execute {agent.display_name}",
                    "inputSchema": input_schema
                })

            return {"tools": tools}

        @self.app.post("/mcp/v1/tools/call")
        async def mcp_call_tool(request: dict):
            """MCP tool execution endpoint"""
            tool_name = request.get("name", "")
            arguments = request.get("arguments", {})

            # Extract agent name
            if tool_name.startswith("microforge_"):
                agent_name = tool_name.replace("microforge_", "")
            else:
                agent_name = tool_name

            # Get agent info
            agent = self.registry.agents.get_agent(agent_name)
            if not agent:
                return {
                    "error": {
                        "code": "TOOL_NOT_FOUND",
                        "message": f"Tool '{tool_name}' not found"
                    }
                }

            # Return agent information (not execution, just info)
            return {
                "content": [
                    {
                        "type": "text",
                        "text": f"Agent: {agent.display_name}\nDescription: {agent.description}\nCategory: {getattr(agent, 'category', 'general')}\nTags: {', '.join(getattr(agent, 'tags', []))}"
                    }
                ]
            }

        @self.app.get("/health")
        async def health():
            """Health check endpoint"""
            agents = self.registry.agents.list_agents()
            return {"status": "healthy", "agents": len(agents)}

        @self.app.get("/tools")
        async def list_tools():
            """List all available tools"""
            tools = []
            for agent in self.registry.agents.list_agents():
                if not agent.enabled:
                    continue

                tools.append({
                    "name": f"microforge_{agent.id}",
                    "display_name": agent.display_name,
                    "description": agent.description,
                    "category": getattr(agent, 'category', None),
                    "tags": getattr(agent, 'tags', []),
                    "enabled": agent.enabled
                })
            return {"tools": tools, "count": len(tools)}

        @self.app.get("/agents")
        async def list_agents():
            """List all available agents with basic info for Claude Code discovery"""
            agents = []
            for agent in self.registry.agents.list_agents():
                agents.append({
                    "id": agent.id,
                    "name": agent.id,
                    "display_name": agent.display_name,
                    "description": agent.description,
                    "category": getattr(agent, 'category', None),
                    "tags": getattr(agent, 'tags', []),
                    "enabled": agent.enabled,
                    "capabilities": getattr(agent, 'capabilities', []),
                    "input_schema": getattr(agent, 'input_schema', {}),
                    "output_format": getattr(agent, 'output_format', 'markdown')
                })
            return {
                "agents": agents,
                "count": len(agents),
                "registry_version": "2.0.0"
            }

        @self.app.get("/agent/{agent_name}")
        async def get_agent_details(agent_name: str):
            """Get detailed information about a specific agent including prompts"""
            # Remove microforge_ prefix if present
            if agent_name.startswith("microforge_"):
                agent_name = agent_name.replace("microforge_", "")

            agent = self.registry.agents.get_agent(agent_name)
            if not agent:
                raise HTTPException(status_code=404, detail=f"Agent '{agent_name}' not found")

            # Get agent file path if it exists
            agent_file = None
            agents_dir = Path(__file__).parent.parent.parent / "agents"
            potential_files = [
                agents_dir / f"{agent_name}.py",
                agents_dir / f"{agent_name}_agent.py"
            ]
            for pf in potential_files:
                if pf.exists():
                    agent_file = str(pf)
                    break

            # Try to get prompt/pattern from agent attributes or documentation
            prompt = getattr(agent, 'prompt', None)
            system_prompt = getattr(agent, 'system_prompt', None)
            patterns = getattr(agent, 'patterns', [])

            return {
                "id": agent.id,
                "name": agent.id,
                "display_name": agent.display_name,
                "description": agent.description,
                "category": getattr(agent, 'category', None),
                "tags": getattr(agent, 'tags', []),
                "enabled": agent.enabled,
                "capabilities": getattr(agent, 'capabilities', []),
                "input_schema": getattr(agent, 'input_schema', {}),
                "output_format": getattr(agent, 'output_format', 'markdown'),
                "prompt": prompt,
                "system_prompt": system_prompt,
                "patterns": patterns,
                "agent_file": agent_file,
                "parameters": {
                    "required": getattr(agent, 'required_params', ['path']),
                    "optional": getattr(agent, 'optional_params', ['service_name', 'docs_only', 'force'])
                },
                "execution_info": {
                    "timeout": getattr(agent, 'timeout', 300),
                    "max_retries": getattr(agent, 'max_retries', 3),
                    "requires_confirmation": getattr(agent, 'requires_confirmation', False)
                }
            }

        @self.app.post("/execute")
        async def execute_tool(request: MCPToolRequest):
            """Execute a tool via HTTP POST"""
            try:
                # Extract agent name
                if not request.tool_name.startswith("microforge_"):
                    agent_name = request.tool_name
                else:
                    agent_name = request.tool_name.replace("microforge_", "")

                # Check if agent exists
                if not self.registry.agents.get_agent(agent_name):
                    return MCPToolResponse(
                        success=False,
                        error=f"Tool '{request.tool_name}' not found"
                    )

                # Execute the agent
                result = await self.executor.run_agent(agent_name, request.arguments)

                return MCPToolResponse(
                    success=True,
                    result=result
                )

            except Exception as e:
                return MCPToolResponse(
                    success=False,
                    error=str(e)
                )

    def run(self):
        """Run the HTTP server"""
        import uvicorn
        uvicorn.run(self.app, host=self.host, port=self.port)