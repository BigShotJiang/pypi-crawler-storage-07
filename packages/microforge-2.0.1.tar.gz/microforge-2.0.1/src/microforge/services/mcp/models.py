"""
MCP service models for Microforge v2.

Data models for MCP server operations.
"""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field


class MCPServerRequest(BaseModel):
    """Request model for MCP server operations."""

    # Server configuration
    mode: str = Field(default="stdio", description="Server mode (stdio/http)")
    host: str = Field(default="127.0.0.1", description="Host for HTTP mode")
    port: int = Field(default=3333, description="Port for HTTP mode")

    # Tool configuration
    allowed_tools: Optional[List[str]] = Field(default=None, description="Allowed MCP tools")

    # Agent configuration
    agent_discovery: bool = Field(default=True, description="Enable agent discovery")


class MCPServerResult(BaseModel):
    """Result model for MCP server operations."""

    success: bool = Field(description="Whether operation completed successfully")
    mode: str = Field(description="Server mode used")
    host: Optional[str] = Field(default=None, description="Host if HTTP mode")
    port: Optional[int] = Field(default=None, description="Port if HTTP mode")

    # Server information
    tools_count: int = Field(default=0, description="Number of registered tools")
    agents_count: int = Field(default=0, description="Number of available agents")

    # Status information
    errors: List[str] = Field(default_factory=list, description="Errors encountered")
    warnings: List[str] = Field(default_factory=list, description="Warnings")

    @property
    def has_errors(self) -> bool:
        """Check if there were any errors."""
        return len(self.errors) > 0

    @property
    def has_warnings(self) -> bool:
        """Check if there were any warnings."""
        return len(self.warnings) > 0


class MCPToolRequest(BaseModel):
    """Request model for MCP tool execution."""

    tool_name: str = Field(description="Name of the tool to execute")
    arguments: Dict[str, Any] = Field(default_factory=dict, description="Tool arguments")


class MCPToolResponse(BaseModel):
    """Response model for MCP tool execution."""

    success: bool = Field(description="Whether execution was successful")
    result: Optional[str] = Field(default=None, description="Tool execution result")
    error: Optional[str] = Field(default=None, description="Error message if failed")