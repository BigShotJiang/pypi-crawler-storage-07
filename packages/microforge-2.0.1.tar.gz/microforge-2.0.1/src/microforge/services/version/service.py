"""
Version service implementation for Microforge v2.

Handles version checking and self-update functionality.
"""

import sys
import json
import subprocess
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Dict, Any
from packaging import version

from ...config.constants import APP_VERSION, VERSION_INFO_FILE
from ...core.common import console, print_success, print_error, print_info, print_warning
from ...core.exceptions import ValidationError, FileSystemError, NotFoundError
from ..base import BaseService
from .models import UpdateRequest, UpdateResult, VersionInfo


class VersionService(BaseService):
    """
    Service for version management and self-updates.

    Handles version checking, update notifications, and self-update functionality.
    """

    def __init__(self):
        super().__init__()
        self.version_file = VERSION_INFO_FILE
        self.check_interval = timedelta(hours=24)  # Check once per day

    def check_for_updates(self, request: UpdateRequest) -> UpdateResult:
        """
        Check for available updates.

        Args:
            request: Update request

        Returns:
            Update result with version information
        """
        result = UpdateResult(
            success=False,
            action="check",
            current_version=APP_VERSION
        )

        try:
            # Check if requests library is available
            try:
                import requests
            except ImportError:
                result.warnings.append("requests library not available - cannot check for updates")
                result.message = "Install 'requests' library to enable update checking"
                return result

            print_info(f"Checking for updates... (current: {APP_VERSION})")

            # Get latest version from GitHub
            latest_info = self._get_latest_version_info(request.repository, request.pre_release)

            if not latest_info:
                result.warnings.append("Could not retrieve version information")
                result.message = "Unable to check for updates at this time"

                # Still save the check timestamp to avoid checking every time
                from .models import VersionInfo
                dummy_info = VersionInfo(
                    current_version=APP_VERSION,
                    repository=request.repository,
                    last_check=datetime.now()
                )
                self._save_version_info(dummy_info)
                return result

            # Store check information
            self._save_version_info(latest_info)

            result.target_version = latest_info.latest_version
            result.update_available = latest_info.update_available

            if latest_info.update_available:
                result.message = f"Update available: {latest_info.latest_version} (current: {APP_VERSION})"
                print_warning(f"📦 Update available: {latest_info.latest_version}")
                if latest_info.release_notes:
                    print_info("Release notes:")
                    print_info(latest_info.release_notes[:200] + "..." if len(latest_info.release_notes) > 200 else latest_info.release_notes)
            else:
                result.message = "You're using the latest version"
                print_success("✅ You're using the latest version!")

            result.success = True

        except Exception as e:
            result.errors.append(str(e))
            print_error(f"Error checking for updates: {str(e)}")

        return result

    def perform_update(self, request: UpdateRequest) -> UpdateResult:
        """
        Perform self-update.

        Args:
            request: Update request

        Returns:
            Update result
        """
        result = UpdateResult(
            success=False,
            action="update",
            current_version=APP_VERSION
        )

        try:
            print_info("🔄 Performing Microforge update...")

            # First check if update is available (unless forced)
            if not request.force:
                check_result = self.check_for_updates(request)
                if not check_result.update_available:
                    result.message = "No update available"
                    result.success = True
                    return result

                result.target_version = check_result.target_version

            # Build pip install command
            cmd = [
                sys.executable, "-m", "pip", "install", "--upgrade"
            ]

            # Check if package is on PyPI
            pypi_info = self._get_latest_version_from_pypi()

            if pypi_info and pypi_info.latest_version and not request.branch:
                # Use PyPI for installation
                source = "microforge"
                print_info(f"Installing from PyPI (version {pypi_info.latest_version})")
            else:
                # Fall back to git installation
                if request.branch:
                    source = f"git+https://github.com/{request.repository}.git@{request.branch}"
                else:
                    source = f"git+https://github.com/{request.repository}.git"
                print_info("Installing from GitHub repository")

            cmd.append(source)

            if request.force:
                cmd.append("--force-reinstall")

            print_info(f"Running: {' '.join(cmd)}")

            # Execute update
            process_result = subprocess.run(cmd, capture_output=True, text=True)

            if process_result.returncode == 0:
                result.success = True
                result.update_performed = True
                result.restart_required = True
                result.message = "Update completed successfully"

                print_success("✅ Successfully updated Microforge!")
                print_info("Please restart your shell or run:")
                print_info("  source ~/.zshrc  # or ~/.bashrc")

                # Clear version info to force recheck
                if self.version_file.exists():
                    self.version_file.unlink()

            else:
                result.errors.append("Update failed")
                if process_result.stderr:
                    result.errors.append(process_result.stderr.strip())

                print_error("❌ Update failed")
                if process_result.stderr:
                    print_error(f"Error: {process_result.stderr.strip()}")

                result.message = "Try manual update: pip install --upgrade git+https://github.com/inviz-search/microforge-ai.git"

        except Exception as e:
            result.errors.append(str(e))
            print_error(f"Error during update: {str(e)}")

        return result

    def get_version_info(self) -> VersionInfo:
        """Get current version information."""
        info = VersionInfo(
            current_version=APP_VERSION,
            repository="inviz-search/microforge-ai"
        )

        if self.version_file.exists():
            try:
                with open(self.version_file, 'r') as f:
                    saved_data = json.load(f)

                info.latest_version = saved_data.get("latest_version")
                info.last_check = datetime.fromisoformat(saved_data["last_check"]) if saved_data.get("last_check") else None
                info.release_notes = saved_data.get("release_notes")
                info.release_url = saved_data.get("release_url")

                # Determine if update is available
                if info.latest_version:
                    try:
                        info.update_available = version.parse(info.latest_version) > version.parse(APP_VERSION)
                    except:
                        info.update_available = False

            except Exception as e:
                print_warning(f"Could not read version info: {e}")

        return info

    def should_check_for_updates(self) -> bool:
        """Check if we should check for updates based on last check time."""
        if not self.version_file.exists():
            return True

        try:
            with open(self.version_file, 'r') as f:
                info = json.load(f)

            last_check = datetime.fromisoformat(info.get("last_check", "2000-01-01"))
            return datetime.now() - last_check > self.check_interval
        except:
            return True

    def notify_update_available(self) -> None:
        """Show a notification if update is available (called on CLI startup)."""
        if not self.should_check_for_updates():
            # Check if we already know about an update
            info = self.get_version_info()
            if info.update_available and info.latest_version:
                print_warning(f"📦 Microforge {info.latest_version} is available (you have {APP_VERSION})")
                print_info("Run 'microforge update' to upgrade")
            return

        # Check for updates in background (non-blocking)
        try:
            request = UpdateRequest(check_only=True)
            result = self.check_for_updates(request)
            if result.update_available and result.target_version:
                print_warning(f"📦 Microforge {result.target_version} is available (you have {APP_VERSION})")
                print_info("Run 'microforge update' to upgrade")
        except:
            # Silently ignore errors in background check
            pass

    def _get_latest_version_from_pypi(self) -> Optional[VersionInfo]:
        """Get latest version information from PyPI."""
        try:
            import requests

            # Check PyPI for the package
            url = "https://pypi.org/pypi/microforge/json"
            response = requests.get(url, timeout=10)

            if response.status_code == 200:
                data = response.json()
                latest_version = data.get("info", {}).get("version", "")
                release_url = data.get("info", {}).get("project_urls", {}).get("Homepage", "")
                summary = data.get("info", {}).get("summary", "")

                # Check if update is available
                update_available = False
                if latest_version:
                    try:
                        update_available = version.parse(latest_version) > version.parse(APP_VERSION)
                    except:
                        update_available = False

                return VersionInfo(
                    current_version=APP_VERSION,
                    latest_version=latest_version,
                    repository="pypi/microforge",
                    last_check=datetime.now(),
                    update_available=update_available,
                    release_notes=summary,
                    release_url=release_url or "https://pypi.org/project/microforge/"
                )
        except Exception as e:
            # Fall back to GitHub if PyPI fails
            pass

        return None

    def _get_latest_version_info(self, repository: str, include_prerelease: bool = False) -> Optional[VersionInfo]:
        """Get latest version information from PyPI first, then GitHub as fallback."""
        # Try PyPI first
        pypi_info = self._get_latest_version_from_pypi()
        if pypi_info:
            return pypi_info

        # Fall back to GitHub
        try:
            import requests

            # Try to get latest release from GitHub
            url = f"https://api.github.com/repos/{repository}/releases/latest"
            if include_prerelease:
                url = f"https://api.github.com/repos/{repository}/releases"

            response = requests.get(url, timeout=10)

            if response.status_code == 200:
                if include_prerelease:
                    # Get first release (including pre-releases)
                    releases = response.json()
                    if releases:
                        data = releases[0]
                    else:
                        return None
                else:
                    data = response.json()

                latest_version = data.get("tag_name", "").lstrip("v")
                release_notes = data.get("body", "")
                release_url = data.get("html_url", "")

                # Check if update is available
                update_available = False
                if latest_version:
                    try:
                        update_available = version.parse(latest_version) > version.parse(APP_VERSION)
                    except:
                        update_available = False

                return VersionInfo(
                    current_version=APP_VERSION,
                    latest_version=latest_version,
                    repository=repository,
                    last_check=datetime.now(),
                    update_available=update_available,
                    release_notes=release_notes,
                    release_url=release_url
                )

            # If no releases, try to get latest commit
            if response.status_code == 404:
                commit_url = f"https://api.github.com/repos/{repository}/commits/main"
                commit_response = requests.get(commit_url, timeout=10)

                if commit_response.status_code == 200:
                    return VersionInfo(
                        current_version=APP_VERSION,
                        repository=repository,
                        last_check=datetime.now(),
                        update_available=False,
                        release_notes="Development version - no releases available"
                    )

        except Exception as e:
            print_warning(f"Could not check for updates: {e}")

        return None

    def _save_version_info(self, info: VersionInfo) -> None:
        """Save version information to file."""
        data = {
            "last_check": info.last_check.isoformat() if info.last_check else datetime.now().isoformat(),
            "current_version": info.current_version,
            "latest_version": info.latest_version,
            "repository": info.repository,
            "update_available": info.update_available,
            "release_notes": info.release_notes,
            "release_url": info.release_url
        }

        self.version_file.parent.mkdir(parents=True, exist_ok=True)
        with open(self.version_file, 'w') as f:
            json.dump(data, f, indent=2)