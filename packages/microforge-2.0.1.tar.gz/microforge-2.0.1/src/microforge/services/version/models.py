"""
Version service models for Microforge v2.

Data models for version management operations.
"""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime


class UpdateRequest(BaseModel):
    """Request model for update operations."""

    # Update configuration
    check_only: bool = Field(default=False, description="Only check for updates")
    force: bool = Field(default=False, description="Force reinstall even if up to date")
    pre_release: bool = Field(default=False, description="Include pre-release versions")

    # Repository configuration
    repository: str = Field(default="inviz-search/microforge-ai", description="GitHub repository")
    branch: Optional[str] = Field(default=None, description="Specific branch to update from")


class VersionInfo(BaseModel):
    """Version information model."""

    current_version: str = Field(description="Current version")
    latest_version: Optional[str] = Field(default=None, description="Latest available version")
    repository: str = Field(description="Source repository")
    last_check: Optional[datetime] = Field(default=None, description="Last update check time")
    update_available: bool = Field(default=False, description="Whether update is available")
    release_notes: Optional[str] = Field(default=None, description="Release notes")
    release_url: Optional[str] = Field(default=None, description="Release URL")


class UpdateResult(BaseModel):
    """Result model for update operations."""

    success: bool = Field(description="Whether operation completed successfully")
    action: str = Field(description="Action performed (check/update)")

    # Version information
    current_version: str = Field(description="Current version")
    target_version: Optional[str] = Field(default=None, description="Target version")
    update_available: bool = Field(default=False, description="Whether update was available")

    # Update metadata
    update_performed: bool = Field(default=False, description="Whether update was performed")
    restart_required: bool = Field(default=False, description="Whether restart is required")

    # Status information
    errors: List[str] = Field(default_factory=list, description="Errors encountered")
    warnings: List[str] = Field(default_factory=list, description="Warnings")
    message: Optional[str] = Field(default=None, description="Status message")

    @property
    def has_errors(self) -> bool:
        """Check if there were any errors."""
        return len(self.errors) > 0

    @property
    def has_warnings(self) -> bool:
        """Check if there were any warnings."""
        return len(self.warnings) > 0