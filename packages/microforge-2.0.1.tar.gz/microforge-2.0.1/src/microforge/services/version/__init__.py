"""
Version management service for Microforge v2.

Handles version checking and self-update functionality.
"""

from .service import VersionService
from .models import UpdateRequest, UpdateResult

__all__ = ["VersionService", "UpdateRequest", "UpdateResult"]