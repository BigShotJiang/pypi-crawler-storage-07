"""
Hooks service for AI assistant integration management.

Handles initialization, configuration, and management of AI hooks for code quality.
"""

import shutil
from pathlib import Path
from typing import Dict, Any, Optional, List
from datetime import datetime
from dataclasses import dataclass

from ...core.exceptions import ServiceError, FileSystemError, ConfigurationError
from ...core.common import (
    console,
    load_config_file,
    save_config_file,
    copy_file_safe,
    print_success,
    print_error,
    print_warning,
    print_info
)
from ...config.constants import (
    HOOKS_SUBDIR,
    HOOKS_VERSION,
    MICROFORGE_PROJECT_CONFIG,
    MICROFORGE_PROJECT_HOOKS_DIR,
    SUCCESS_HOOKS_INITIALIZED,
    HOOK_PLANNING_PRE,
    HOOK_CODE_QUALITY,
    HOOK_README
)
from ..base import BaseService
from .models import HookInfo, HookStatus, HooksConfiguration, HooksRequest


@dataclass
class HookRegistry:
    """Simple hook registry for available hooks."""
    hooks: Dict[str, HookInfo]

    def get_all(self) -> Dict[str, HookInfo]:
        """Get all hooks."""
        return self.hooks

    def get_hook(self, name: str) -> Optional[HookInfo]:
        """Get specific hook by name."""
        return self.hooks.get(name)


class HooksService(BaseService):
    """Service for managing AI hooks system."""

    def __init__(self):
        super().__init__()
        self.hooks_dir = self._get_hooks_directory()
        self._hook_registry = None  # Lazy initialization

    @property
    def hook_registry(self):
        """Lazy load hook registry to avoid circular dependencies."""
        if self._hook_registry is None:
            self._hook_registry = self._initialize_registry()
        return self._hook_registry

    def _get_hooks_directory(self) -> Path:
        """Get the hooks directory path."""
        from ...config.constants import PACKAGE_DIR
        return PACKAGE_DIR / HOOKS_SUBDIR

    def _initialize_registry(self) -> HookRegistry:
        """Initialize hooks registry with available hooks."""
        hooks = {
            "planning": HookInfo(
                name="planning",
                file_name=HOOK_PLANNING_PRE,
                description="Creates implementation plans before code changes",
                enabled=True,
                priority=1,
                version="1.0.0",
                required=True
            ),
            "code_quality": HookInfo(
                name="code_quality",
                file_name=HOOK_CODE_QUALITY,
                description="Enforces tests, docs, and quality standards",
                enabled=True,
                priority=2,
                version="1.0.0",
                required=True
            )
        }
        return HookRegistry(hooks)

    def init_hooks(self, request: HooksRequest) -> HooksConfiguration:
        """
        Initialize AI hooks in the current project.

        Args:
            request: Hooks initialization request

        Returns:
            Hooks configuration result

        Raises:
            ServiceError: If initialization fails
        """
        config_file = MICROFORGE_PROJECT_CONFIG

        # Check if already initialized
        if config_file.exists() and not request.force:
            print_warning("⚠️ Hooks already initialized. Use --force to overwrite.")
            return HooksConfiguration(
                success=False,
                message="Hooks already initialized",
                hooks_copied=[],
                config_path=str(config_file)
            )

        try:
            # Create hooks directory
            self._create_hooks_directory()

            # Copy hook files
            hooks_copied, hooks_not_found = self._copy_hook_files()

            # Generate configuration
            config_content = self._generate_config(hooks_copied)

            # Save configuration
            self._save_configuration(config_content)

            # Display results
            self._display_init_results(hooks_copied, hooks_not_found)

            # Track created files
            created_files = [str(config_file)]
            for hook_name in hooks_copied:
                hook_file = MICROFORGE_PROJECT_HOOKS_DIR / f"{hook_name}.md"
                if hook_file.exists():
                    created_files.append(str(hook_file))

            return HooksConfiguration(
                success=True,
                message=SUCCESS_HOOKS_INITIALIZED,
                hooks_copied=hooks_copied,
                hooks_not_found=hooks_not_found,
                config_path=str(config_file),
                created_files=created_files,
                updated_files=[],
                errors=[],
                warnings=hooks_not_found if hooks_not_found else []
            )

        except Exception as e:
            print_error(f"Failed to initialize hooks: {str(e)}")
            raise ServiceError(
                "Hooks initialization failed",
                service_name=self.name,
                operation="init_hooks"
            ) from e

    def _create_hooks_directory(self) -> None:
        """Create .microforge/hooks directory."""
        MICROFORGE_PROJECT_HOOKS_DIR.mkdir(parents=True, exist_ok=True)
        print_info(f"Created hooks directory: {MICROFORGE_PROJECT_HOOKS_DIR}")

    def _copy_hook_files(self) -> tuple[List[str], List[str]]:
        """Copy hook files from package to project directory."""
        hooks_copied = []
        hooks_not_found = []

        for hook_name, hook_info in self.hook_registry.get_all().items():
            if hook_info.file_name:
                src = self.hooks_dir / hook_info.file_name
                if src.exists():
                    dest = MICROFORGE_PROJECT_HOOKS_DIR / hook_info.file_name
                    try:
                        copy_file_safe(src, dest)
                        print_success(f"✅ Copied {hook_info.file_name} to .microforge/hooks/")
                        hooks_copied.append(hook_name)
                    except FileSystemError as e:
                        print_error(f"Failed to copy {hook_info.file_name}: {str(e)}")
                        hooks_not_found.append(hook_name)
                else:
                    print_warning(f"⚠️ Hook file not found: {src}")
                    hooks_not_found.append(hook_name)
                    self._show_debug_info(src)

        return hooks_copied, hooks_not_found

    def _show_debug_info(self, missing_src: Path) -> None:
        """Show debug information for missing hook files."""
        print_warning(f"⚠️ No hook files were copied. Checking paths...")
        print_info(f"Looking for hooks in: {self.hooks_dir}")

        if self.hooks_dir.exists():
            print_info("Hook directory exists. Files found:")
            for f in self.hooks_dir.glob("*.md"):
                print_info(f"  - {f.name}")
        else:
            print_error(f"❌ Hook directory does not exist: {self.hooks_dir}")

    def _generate_config(self, hooks_copied: List[str]) -> str:
        """Generate hooks configuration content."""
        # Get hook configurations
        hooks_config = {}
        for hook_name in hooks_copied:
            hook_info = self.hook_registry.get_hook(hook_name)
            if hook_info:
                hooks_config[hook_name] = {
                    'enabled': hook_info.enabled,
                    'priority': hook_info.priority,
                    'version': hook_info.version
                }

        # Build configuration content
        config_content = f"""# Microforge Configuration

version: {HOOKS_VERSION}  # Hooks system version
last_updated: {datetime.now().isoformat()}  # Last update time

# Hooks configuration
hooks:
"""

        for hook_name, hook_settings in hooks_config.items():
            config_content += f"  {hook_name}:\n"
            config_content += f"    enabled: {str(hook_settings['enabled']).lower()}\n"
            config_content += f"    priority: {hook_settings['priority']}\n"
            config_content += f"    version: {hook_settings['version']}\n"

        # Add project settings
        config_content += """
# Project-specific settings
project:
  type: microservice  # microservice, library, cli, etc.
  language: python
  framework: fastapi  # fastapi, flask, django, etc.
"""

        return config_content

    def _save_configuration(self, config_content: str) -> None:
        """Save hooks configuration to file."""
        try:
            with open(MICROFORGE_PROJECT_CONFIG, 'w', encoding='utf-8') as f:
                f.write(config_content)
            print_success(f"✅ Created configuration: {MICROFORGE_PROJECT_CONFIG}")
        except Exception as e:
            raise FileSystemError(
                f"Failed to save configuration: {MICROFORGE_PROJECT_CONFIG}",
                path=str(MICROFORGE_PROJECT_CONFIG),
                operation="write"
            ) from e

    def _display_init_results(self, hooks_copied: List[str], hooks_not_found: List[str]) -> None:
        """Display initialization results."""
        if hooks_copied:
            print_success(f"\n🎯 Successfully initialized {len(hooks_copied)} hooks:")
            for hook_name in hooks_copied:
                hook_info = self.hook_registry.get_hook(hook_name)
                if hook_info:
                    print_info(f"  • {hook_name}: {hook_info.description}")

        if hooks_not_found:
            print_warning(f"\n⚠️ {len(hooks_not_found)} hooks could not be initialized:")
            for hook_name in hooks_not_found:
                hook_info = self.hook_registry.get_hook(hook_name)
                if hook_info:
                    print_warning(f"  • {hook_name}: {hook_info.description}")

        print_info("\n📋 Next Steps:")
        print_info("1. Review the generated configuration in .microforge/config.yaml")
        print_info("2. Customize hook settings as needed")
        print_info("3. Review hook instructions in .microforge/hooks/")

    def get_status(self) -> HookStatus:
        """Get current hooks system status."""
        config_exists = MICROFORGE_PROJECT_CONFIG.exists()
        hooks_dir_exists = MICROFORGE_PROJECT_HOOKS_DIR.exists()

        if not config_exists:
            return HookStatus(
                initialized=False,
                version=None,
                hooks={},
                config_path=str(MICROFORGE_PROJECT_CONFIG),
                hooks_directory=str(MICROFORGE_PROJECT_HOOKS_DIR)
            )

        try:
            config = load_config_file(MICROFORGE_PROJECT_CONFIG)
            hooks_config = config.get('hooks', {})

            hook_statuses = {}
            # Handle both old and new config formats
            if isinstance(hooks_config, dict):
                # Skip top-level 'enabled' key if it exists
                for hook_name, hook_settings in hooks_config.items():
                    if hook_name == 'enabled':
                        continue  # Skip the global enabled flag
                    if not isinstance(hook_settings, dict):
                        continue  # Skip non-dict entries

                    # Skip registry lookup to avoid potential circular dependencies
                    # Just check if the hook file exists based on convention
                    hook_file = MICROFORGE_PROJECT_HOOKS_DIR / f"{hook_name}_hook.md"
                    file_exists = hook_file.exists()

                    hook_statuses[hook_name] = {
                        'enabled': hook_settings.get('enabled', False),
                        'version': hook_settings.get('version', 'unknown'),
                        'file_exists': file_exists,
                        'up_to_date': True  # TODO: Implement version checking
                    }

            return HookStatus(
                initialized=True,
                version=config.get('version', 'unknown'),
                hooks=hook_statuses,
                config_path=str(MICROFORGE_PROJECT_CONFIG),
                hooks_directory=str(MICROFORGE_PROJECT_HOOKS_DIR)
            )

        except Exception as e:
            raise ConfigurationError(
                f"Failed to read hooks configuration: {str(e)}",
                config_path=str(MICROFORGE_PROJECT_CONFIG)
            ) from e

    def list_available_hooks(self) -> List[HookInfo]:
        """List all available hooks."""
        return list(self.hook_registry.get_all().values())

    def show_hook_details(self, hook_name: str) -> HookInfo:
        """Show details for a specific hook."""
        hook_info = self.hook_registry.get_hook(hook_name)
        if not hook_info:
            raise ServiceError(
                f"Hook '{hook_name}' not found",
                service_name=self.name,
                operation="show_hook_details"
            )
        return hook_info

    def toggle_hook(self, hook_name: str, enabled: bool) -> bool:
        """Enable or disable a specific hook."""
        if not MICROFORGE_PROJECT_CONFIG.exists():
            raise ConfigurationError(
                "Hooks not initialized. Run 'microforge hooks init' first.",
                config_path=str(MICROFORGE_PROJECT_CONFIG)
            )

        try:
            config = load_config_file(MICROFORGE_PROJECT_CONFIG)
            hooks_config = config.get('hooks', {})

            if hook_name not in hooks_config:
                raise ServiceError(
                    f"Hook '{hook_name}' not found in configuration",
                    service_name=self.name,
                    operation="toggle_hook"
                )

            # Update hook status
            hooks_config[hook_name]['enabled'] = enabled
            config['hooks'] = hooks_config
            config['last_updated'] = datetime.now().isoformat()

            # Save configuration
            save_config_file(MICROFORGE_PROJECT_CONFIG, config)

            action = "enabled" if enabled else "disabled"
            print_success(f"✅ Hook '{hook_name}' {action}")
            return True

        except Exception as e:
            raise ServiceError(
                f"Failed to toggle hook '{hook_name}': {str(e)}",
                service_name=self.name,
                operation="toggle_hook"
            ) from e

    def validate_configuration(self) -> Dict[str, Any]:
        """Validate hooks configuration."""
        if not MICROFORGE_PROJECT_CONFIG.exists():
            return {
                'valid': False,
                'error': 'Configuration file not found',
                'issues': ['Hooks not initialized']
            }

        try:
            config = load_config_file(MICROFORGE_PROJECT_CONFIG)
            issues = []

            # Check version
            if 'version' not in config:
                issues.append('Missing version information')

            # Check hooks section
            if 'hooks' not in config:
                issues.append('Missing hooks configuration')
            else:
                hooks_config = config['hooks']
                for hook_name, hook_settings in hooks_config.items():
                    hook_info = self.hook_registry.get_hook(hook_name)
                    if not hook_info:
                        issues.append(f"Unknown hook: {hook_name}")
                        continue

                    # Check hook file exists
                    hook_file = MICROFORGE_PROJECT_HOOKS_DIR / hook_info.file_name
                    if not hook_file.exists():
                        issues.append(f"Missing hook file: {hook_info.file_name}")

                    # Check required settings
                    if 'enabled' not in hook_settings:
                        issues.append(f"Missing 'enabled' setting for hook: {hook_name}")

            return {
                'valid': len(issues) == 0,
                'issues': issues,
                'config_path': str(MICROFORGE_PROJECT_CONFIG)
            }

        except Exception as e:
            return {
                'valid': False,
                'error': str(e),
                'issues': ['Failed to parse configuration file']
            }

    def refresh_hooks(self, request: HooksRequest) -> "HooksRefreshResult":
        """Refresh hooks from registry."""
        from .models import HooksRefreshResult

        try:
            hooks_refreshed = []

            # Get all available hooks from registry
            available_hooks = self.hook_registry.get_all()

            if not MICROFORGE_PROJECT_CONFIG.exists():
                return HooksRefreshResult(
                    success=False,
                    hooks_refreshed=[],
                    error_message="Hooks not initialized. Run 'microforge hooks init' first."
                )

            # Copy/update hook files from registry
            for hook_name, hook_info in available_hooks.items():
                try:
                    source_file = PACKAGE_DIR / HOOKS_SUBDIR / hook_info.file_name
                    dest_file = MICROFORGE_PROJECT_HOOKS_DIR / hook_info.file_name

                    if source_file.exists():
                        dest_file.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(source_file, dest_file)
                        hooks_refreshed.append(hook_name)
                except Exception:
                    # Continue with other hooks if one fails
                    pass

            return HooksRefreshResult(
                success=True,
                hooks_refreshed=hooks_refreshed
            )

        except Exception as e:
            return HooksRefreshResult(
                success=False,
                hooks_refreshed=[],
                error_message=str(e)
            )

    def update_hooks(self, request: HooksRequest) -> "HooksUpdateResult":
        """Update hooks system."""
        from .models import HooksUpdateResult

        try:
            hooks_updated = []
            version_updated = False
            new_version = None

            if not MICROFORGE_PROJECT_CONFIG.exists():
                return HooksUpdateResult(
                    success=False,
                    hooks_updated=[],
                    error_message="Hooks not initialized. Run 'microforge hooks init' first."
                )

            # Read current configuration
            config = load_config_file(MICROFORGE_PROJECT_CONFIG)
            current_version = config.get('version', '0.0.0')

            # Check if hooks system version is newer
            if version.parse(HOOKS_VERSION) > version.parse(current_version):
                config['version'] = HOOKS_VERSION
                config['last_updated'] = datetime.now().isoformat()
                save_config_file(MICROFORGE_PROJECT_CONFIG, config)
                version_updated = True
                new_version = HOOKS_VERSION

            # Update hook files (same as refresh)
            available_hooks = self.hook_registry.get_all()
            for hook_name, hook_info in available_hooks.items():
                try:
                    source_file = PACKAGE_DIR / HOOKS_SUBDIR / hook_info.file_name
                    dest_file = MICROFORGE_PROJECT_HOOKS_DIR / hook_info.file_name

                    if source_file.exists():
                        # Only update if source is newer or different
                        should_update = True
                        if dest_file.exists():
                            # Simple check - always update for now
                            # TODO: Add more sophisticated version checking
                            pass

                        if should_update:
                            dest_file.parent.mkdir(parents=True, exist_ok=True)
                            shutil.copy2(source_file, dest_file)
                            hooks_updated.append(hook_name)
                except Exception:
                    # Continue with other hooks if one fails
                    pass

            return HooksUpdateResult(
                success=True,
                hooks_updated=hooks_updated,
                version_updated=version_updated,
                new_version=new_version
            )

        except Exception as e:
            return HooksUpdateResult(
                success=False,
                hooks_updated=[],
                error_message=str(e)
            )