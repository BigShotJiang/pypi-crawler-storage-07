"""
Data models for the hooks service.
"""

from dataclasses import dataclass
from typing import Dict, List, Optional, Any


@dataclass
class HookInfo:
    """Information about an available hook."""
    name: str
    file_name: str
    description: str
    enabled: bool = True
    priority: int = 1
    version: str = "1.0.0"
    required: bool = False

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'name': self.name,
            'file_name': self.file_name,
            'description': self.description,
            'enabled': self.enabled,
            'priority': self.priority,
            'version': self.version,
            'required': self.required
        }


@dataclass
class HooksRequest:
    """Request for hooks operations."""
    force: bool = False
    hook_name: Optional[str] = None
    enabled: Optional[bool] = None
    target_path: Optional[str] = None  # Path for initialization
    update: bool = False  # Update existing hooks

    @classmethod
    def init_request(cls, force: bool = False) -> "HooksRequest":
        """Create initialization request."""
        return cls(force=force)

    @classmethod
    def toggle_request(cls, hook_name: str, enabled: bool) -> "HooksRequest":
        """Create toggle request."""
        return cls(hook_name=hook_name, enabled=enabled)

    @classmethod
    def refresh_request(cls) -> "HooksRequest":
        """Create refresh request."""
        return cls()

    @classmethod
    def update_request(cls) -> "HooksRequest":
        """Create update request."""
        return cls()


@dataclass
class HooksConfiguration:
    """Result of hooks configuration operations."""
    success: bool
    message: str
    hooks_copied: List[str]
    hooks_not_found: Optional[List[str]] = None
    config_path: Optional[str] = None
    error: Optional[str] = None
    created_files: List[str] = None  # Files created during initialization
    updated_files: List[str] = None  # Files updated during initialization
    errors: List[str] = None  # List of errors
    warnings: List[str] = None  # List of warnings

    def __post_init__(self):
        """Initialize list fields if None."""
        if self.created_files is None:
            self.created_files = []
        if self.updated_files is None:
            self.updated_files = []
        if self.errors is None:
            self.errors = []
        if self.warnings is None:
            self.warnings = []

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = {
            'success': self.success,
            'message': self.message,
            'hooks_copied': self.hooks_copied
        }

        if self.hooks_not_found:
            result['hooks_not_found'] = self.hooks_not_found

        if self.config_path:
            result['config_path'] = self.config_path

        if self.error:
            result['error'] = self.error

        return result


@dataclass
class HookStatus:
    """Status of the hooks system."""
    initialized: bool
    version: Optional[str]
    hooks: Dict[str, Dict[str, Any]]
    config_path: str
    hooks_directory: str
    error: Optional[str] = None

    @property
    def total_hooks(self) -> int:
        """Get total number of configured hooks."""
        return len(self.hooks)

    @property
    def enabled_hooks(self) -> int:
        """Get number of enabled hooks."""
        return sum(1 for hook in self.hooks.values() if hook.get('enabled', False))

    @property
    def missing_files(self) -> List[str]:
        """Get list of hooks with missing files."""
        return [
            name for name, info in self.hooks.items()
            if not info.get('file_exists', False)
        ]

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = {
            'initialized': self.initialized,
            'version': self.version,
            'hooks': self.hooks,
            'config_path': self.config_path,
            'hooks_directory': self.hooks_directory,
            'total_hooks': self.total_hooks,
            'enabled_hooks': self.enabled_hooks,
            'missing_files': self.missing_files
        }

        if self.error:
            result['error'] = self.error

        return result


@dataclass
class HookValidationResult:
    """Result of hooks configuration validation."""
    valid: bool
    issues: List[str]
    config_path: str
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = {
            'valid': self.valid,
            'issues': self.issues,
            'config_path': self.config_path
        }

        if self.error:
            result['error'] = self.error

        return result


@dataclass
class HooksRefreshResult:
    """Result of hooks refresh operation."""
    success: bool
    hooks_refreshed: List[str]
    error_message: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = {
            'success': self.success,
            'hooks_refreshed': self.hooks_refreshed
        }
        if self.error_message:
            result['error_message'] = self.error_message
        return result


@dataclass
class HooksUpdateResult:
    """Result of hooks update operation."""
    success: bool
    hooks_updated: List[str]
    version_updated: bool = False
    new_version: Optional[str] = None
    error_message: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = {
            'success': self.success,
            'hooks_updated': self.hooks_updated,
            'version_updated': self.version_updated
        }
        if self.new_version:
            result['new_version'] = self.new_version
        if self.error_message:
            result['error_message'] = self.error_message
        return result