"""
Service Agent Discovery using Claude.

Collects git history and passes to Claude for analysis.
"""

from pathlib import Path
from typing import Optional, Dict, Any
import json

from ...core.common import print_info, print_success, print_error
from ...core.exceptions import NotFoundError
from ...providers.vcs.git import GitProvider
from ..base import BaseService


class ServiceDiscovery(BaseService):
    """
    Service discovery that uses Claude to analyze commit patterns.
    """

    def discover_agents(
        self,
        service_name: Optional[str] = None,
        commit_limit: int = 200,
        output_dir: str = './discovered-agents'
    ) -> Dict[str, Any]:
        """
        Discover needed agents by passing git history to Claude.

        Args:
            service_name: Service name or None for current directory
            commit_limit: Number of commits to analyze
            output_dir: Where to save generated agents

        Returns:
            Discovery results
        """
        # Determine repository path
        if service_name:
            # Check if service exists in registry
            service = self.registry.services.get_service(service_name)
            if not service:
                raise NotFoundError(f"Service '{service_name}' not found in registry")
            repo_path = Path.cwd()  # Use current directory for now
        else:
            repo_path = Path.cwd()
            service_name = repo_path.name

        print_info(f"Collecting git history for: {service_name}")

        # Get git history
        commits = self.git_provider.get_commit_history(repo_path, commit_limit)

        # Get file change frequency
        file_changes = self.git_provider.get_file_change_frequency(repo_path, commit_limit)

        # Format git history for the agent
        git_history = self._format_git_history(commits)
        file_changes_formatted = self._format_file_changes(file_changes)

        # Prepare context for agent template
        context = {
            'SERVICE_NAME': service_name,
            'REPO_PATH': str(repo_path),
            'GIT_HISTORY': git_history,
            'FILE_CHANGES': file_changes_formatted
        }

        # Create output directory
        output_path = Path(output_dir) / service_name
        output_path.mkdir(parents=True, exist_ok=True)

        print_info(f"Git history collected: {len(commits)} commits")
        print_info(f"File changes tracked: {len(file_changes)} files")

        # Return context for Claude to process
        return {
            'service_name': service_name,
            'output_path': str(output_path),
            'context': context,
            'commits_analyzed': len(commits),
            'files_tracked': len(file_changes)
        }

    def _format_git_history(self, commits: list) -> str:
        """Format commit history for agent template."""
        lines = []
        for commit in commits:
            lines.append(f"Commit: {commit['hash'][:8]}")
            lines.append(f"Author: {commit['author']}")
            lines.append(f"Message: {commit['message']}")

            if commit.get('files'):
                lines.append("Files changed:")
                for file_info in commit['files'][:5]:  # Limit to 5 files per commit
                    lines.append(f"  {file_info['status']}: {file_info['path']}")

            lines.append("")  # Empty line between commits

        return '\n'.join(lines)

    def _format_file_changes(self, file_changes: Dict[str, int]) -> str:
        """Format file change frequency for agent template."""
        lines = []

        # Sort by frequency
        sorted_files = sorted(file_changes.items(), key=lambda x: x[1], reverse=True)

        # Show top 20 most frequently changed files
        for file_path, count in sorted_files[:20]:
            lines.append(f"{count:3d} changes: {file_path}")

        return '\n'.join(lines)

    def prepare_discovery_prompt(self, context: Dict[str, Any]) -> Path:
        """
        Prepare the discovery prompt file with git history data.

        Args:
            context: Discovery context with git history

        Returns:
            Path to the prepared prompt file
        """
        # Load the agent template
        agent_template_path = Path(__file__).parent.parent.parent / 'resources' / 'agent_templates' / 'service_discovery.md'

        if not agent_template_path.exists():
            raise FileNotFoundError(f"Agent template not found: {agent_template_path}")

        template_content = agent_template_path.read_text()

        # Replace placeholders in template
        for key, value in context['context'].items():
            template_content = template_content.replace(f'{{{{{key}}}}}', str(value))

        # Save to output directory
        output_path = Path(context['output_path'])
        prompt_file = output_path / 'discovery_prompt.md'
        prompt_file.write_text(template_content)

        print_success(f"Prepared discovery prompt: {prompt_file}")
        return prompt_file