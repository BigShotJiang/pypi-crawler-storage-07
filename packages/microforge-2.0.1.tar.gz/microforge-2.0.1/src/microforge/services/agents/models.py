"""
Agents service models for Microforge v2.

Data models for agent execution operations.
"""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from pathlib import Path


class AgentExecutionRequest(BaseModel):
    """Request model for agent execution."""

    # Agent identification
    agent_name: str = Field(description="Name of the agent to execute")
    agent_file: Optional[str] = Field(default=None, description="Specific agent file path")

    # Target information
    service_name: str = Field(description="Name of the service to analyze")
    repo_url: Optional[str] = Field(default=None, description="Repository URL for remote analysis")
    local_path: Optional[Path] = Field(default=None, description="Local path for analysis")

    # Execution mode
    mode: str = Field(default="local", description="Execution mode (local/remote)")
    docs_only: bool = Field(default=False, description="Only generate documentation")
    deps_only: bool = Field(default=False, description="Only generate dependencies")
    force: bool = Field(default=False, description="Force regeneration")

    # LLM integration
    batch_mode: bool = Field(default=False, description="Run LLM in batch mode")
    interactive: bool = Field(default=True, description="Run LLM interactively")
    custom_prompt: Optional[str] = Field(default=None, description="Custom prompt from Azure storage")

    # Output configuration
    output_format: str = Field(default="markdown", description="Output format")
    output_dir: Optional[Path] = Field(default=None, description="Output directory")


class AgentExecutionResult(BaseModel):
    """Result model for agent execution."""

    success: bool = Field(description="Whether execution completed successfully")
    agent_name: str = Field(description="Name of the executed agent")
    service_name: str = Field(description="Name of the analyzed service")
    mode: str = Field(description="Execution mode used")

    # Output information
    output_files: List[str] = Field(default_factory=list, description="Generated output files")
    documentation_files: List[str] = Field(default_factory=list, description="Generated documentation")
    dependency_files: List[str] = Field(default_factory=list, description="Generated dependency files")

    # Execution metadata
    execution_time_ms: float = Field(default=0.0, description="Execution time in milliseconds")
    claude_used: bool = Field(default=False, description="Whether Claude was used")
    branch_created: Optional[str] = Field(default=None, description="Created branch name for remote mode")

    # Status information
    errors: List[str] = Field(default_factory=list, description="Errors encountered")
    warnings: List[str] = Field(default_factory=list, description="Warnings")

    @property
    def has_errors(self) -> bool:
        """Check if there were any errors."""
        return len(self.errors) > 0

    @property
    def has_warnings(self) -> bool:
        """Check if there were any warnings."""
        return len(self.warnings) > 0

    @property
    def total_files_generated(self) -> int:
        """Get total number of files generated."""
        return len(self.output_files)


class AgentRunRequest(BaseModel):
    """Request model for running an agent."""

    agent_name: str = Field(description="Name of the agent to run")
    service: Optional[str] = Field(default=None, description="Service name from registry")
    branch: Optional[str] = Field(default=None, description="Git branch to create and push changes to")
    global_agent: bool = Field(default=False, description="Run as global agent (no repo required)")
    interactive: bool = Field(default=True, description="Run Claude interactively")


class AgentRunResult(BaseModel):
    """Result model for agent run."""

    success: bool = Field(description="Whether agent ran successfully")
    agent_name: str = Field(description="Name of the executed agent")
    mode: str = Field(description="Execution mode (local/service/global)")

    # Output information
    repo_path: Optional[str] = Field(default=None, description="Repository path where agent ran")
    branch_created: Optional[str] = Field(default=None, description="Branch name if created and pushed")

    # Execution metadata
    execution_time_ms: float = Field(default=0.0, description="Execution time in milliseconds")

    # Status information
    errors: List[str] = Field(default_factory=list, description="Errors encountered")
    warnings: List[str] = Field(default_factory=list, description="Warnings")


class AgentContext(BaseModel):
    """Context model for agent execution."""

    # Service information
    service_name: str = Field(description="Service name")
    repo_url: Optional[str] = Field(default=None, description="Repository URL")
    local_path: Optional[Path] = Field(default=None, description="Local path")

    # Execution configuration
    mode: str = Field(description="Execution mode")
    docs_only: bool = Field(description="Documentation only flag")
    deps_only: bool = Field(description="Dependencies only flag")
    force: bool = Field(description="Force regeneration flag")

    # Metadata
    timestamp: str = Field(description="Execution timestamp")
    agent_name: str = Field(description="Agent name")
    execution_id: str = Field(description="Unique execution ID")


# ============================================================================
# Agent Discovery Models
# ============================================================================

class CommitPattern(BaseModel):
    """Represents a pattern found in commit history."""

    pattern_type: str = Field(description="Type of pattern (bug_fix, feature, refactor, etc.)")
    frequency: int = Field(description="Number of occurrences")
    percentage: float = Field(description="Percentage of total commits")
    examples: List[str] = Field(default_factory=list, description="Example commit messages")
    affected_files: List[str] = Field(default_factory=list, description="Commonly affected files")


class ServicePattern(BaseModel):
    """Service-specific patterns discovered from analysis."""

    bug_patterns: Dict[str, CommitPattern] = Field(default_factory=dict, description="Bug fix patterns")
    feature_patterns: Dict[str, CommitPattern] = Field(default_factory=dict, description="Feature patterns")
    hot_spots: List[str] = Field(default_factory=list, description="Frequently modified files")
    common_modules: List[str] = Field(default_factory=list, description="Common module names")
    error_keywords: List[str] = Field(default_factory=list, description="Common error keywords")
    api_patterns: List[str] = Field(default_factory=list, description="API endpoint patterns")
    data_patterns: List[str] = Field(default_factory=list, description="Data model patterns")


class AgentRecommendation(BaseModel):
    """Recommendation for a service-specific agent."""

    agent_name: str = Field(description="Name of the recommended agent")
    agent_type: str = Field(description="Type of agent (bug_fix, feature, api, etc.)")
    confidence: float = Field(description="Confidence score (0-1)")
    justification: str = Field(description="Why this agent is recommended")
    patterns_found: List[str] = Field(default_factory=list, description="Patterns that triggered this recommendation")
    priority: str = Field(default="medium", description="Priority level (required, high, medium, low)")


class ServiceAgentDiscoveryResult(BaseModel):
    """Result of service agent discovery."""

    service_name: str = Field(description="Name of the analyzed service")
    repository_path: str = Field(description="Path to the repository")
    total_commits_analyzed: int = Field(description="Number of commits analyzed")
    date_range: str = Field(description="Date range of analyzed commits")

    # Analysis results
    service_patterns: ServicePattern = Field(description="Discovered service patterns")
    recommendations: List[AgentRecommendation] = Field(default_factory=list, description="Agent recommendations")

    # Generated agents
    generated_agents: List[str] = Field(default_factory=list, description="List of generated agent files")
    output_directory: str = Field(description="Directory where agents were generated")