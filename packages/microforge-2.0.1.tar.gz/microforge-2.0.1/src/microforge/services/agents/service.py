"""
Agents service implementation for Microforge v2.

Handles AI agent execution and management with Claude integration.
"""

import time
import uuid
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, Optional, List

from ...config.constants import (
    PACKAGE_DIR,
    AGENTS_SUBDIR,
    TEMP_PREFIX,
    GIT_TIMEOUT_SECONDS,
    DOCS_DIR,
    DOCS_SERVICE_DIR
)
from ...core.common import console, print_success, print_error, print_info, print_warning, ensure_path_exists
from ...core.exceptions import ValidationError, FileSystemError, NotFoundError, StorageError, GitError
from ...providers.storage import StorageFactory
from ..base import BaseService
from .models import AgentExecutionRequest, AgentExecutionResult, AgentContext, AgentRunRequest


class AgentsService(BaseService):
    """
    Service for AI agent execution.

    Handles running analysis agents on repositories with Claude integration.
    """

    def __init__(self):
        super().__init__()
        # Initialize storage provider
        self.storage = StorageFactory.create_storage_provider()

    def execute_agent(self, request: AgentExecutionRequest) -> AgentExecutionResult:
        """
        Execute an agent on a service/repository.

        Args:
            request: Agent execution request

        Returns:
            Agent execution result
        """
        start_time = time.time()
        execution_id = str(uuid.uuid4())

        result = AgentExecutionResult(
            success=False,
            agent_name=request.agent_name,
            service_name=request.service_name,
            mode=request.mode
        )

        try:
            console.print(f"\n[cyan]🤖 Starting agent execution: {request.agent_name}[/cyan]")
            console.print(f"[dim]Execution ID: {execution_id}[/dim]")

            # Validate agent exists
            agent = self._get_agent(request.agent_name, request.agent_file)
            if not agent:
                raise NotFoundError(f"Agent '{request.agent_name}' not found")

            # Build execution context
            context = self._build_execution_context(request, execution_id)

            # Set up repository for analysis
            repo_path = self._setup_repository(request, context)
            if not repo_path:
                raise ValidationError("Failed to set up repository for analysis")

            # Execute agent using LLM provider
            llm_result = self._execute_with_llm(agent, context, repo_path, request.interactive)
            result.claude_used = True  # For backward compatibility

            if llm_result.get("success", False):
                result.output_files = llm_result.get("output_files", [])
                result.documentation_files = llm_result.get("documentation_files", [])
                result.dependency_files = llm_result.get("dependency_files", [])
            else:
                error_msg = llm_result.get("error", "LLM execution failed")
                result.errors.append(error_msg)
                result.warnings.append("Executed without Claude - limited functionality")

            # Handle remote mode cleanup and branch creation
            if request.mode == "remote":
                branch_name = self._handle_remote_completion(context, repo_path)
                result.branch_created = branch_name

            result.success = not result.has_errors
            result.execution_time_ms = (time.time() - start_time) * 1000

            if result.success:
                print_success(f"Agent execution completed: {request.agent_name}")
                print_info(f"Generated {result.total_files_generated} files")
            else:
                print_error("Agent execution failed")

            return result

        except Exception as e:
            result.errors.append(str(e))
            result.execution_time_ms = (time.time() - start_time) * 1000
            print_error(f"Agent execution failed: {str(e)}")
            return result

    def _get_agent(self, agent_name: str, agent_file: Optional[str]) -> Optional[Dict[str, Any]]:
        """Get agent configuration or file."""
        if agent_file:
            # Direct file path provided
            agent_path = Path(agent_file)
            if agent_path.exists():
                return {
                    "name": agent_name,
                    "file_path": str(agent_path),
                    "display_name": agent_name.replace('_', ' ').title()
                }
            else:
                print_error(f"Agent file not found: {agent_file}")
                return None
        else:
            # Get from registry
            agent = self.registry.agents.get_agent(agent_name)
            if agent:
                # Construct path to agent template
                agent_templates_dir = PACKAGE_DIR / AGENTS_SUBDIR
                agent_file_path = agent_templates_dir / agent.file_name

                return {
                    "name": agent.id,
                    "file_path": str(agent_file_path),
                    "display_name": agent.display_name,
                    "description": agent.description
                }
            else:
                print_error(f"Agent '{agent_name}' not found in registry")
                return None

    def _build_execution_context(self, request: AgentExecutionRequest, execution_id: str) -> AgentContext:
        """Build execution context for the agent."""
        return AgentContext(
            service_name=request.service_name,
            repo_url=request.repo_url,
            local_path=request.local_path,
            mode=request.mode,
            docs_only=request.docs_only,
            deps_only=request.deps_only,
            force=request.force,
            timestamp=datetime.now().isoformat(),
            agent_name=request.agent_name,
            execution_id=execution_id
        )

    def _setup_repository(self, request: AgentExecutionRequest, context: AgentContext) -> Optional[Path]:
        """Set up repository for analysis."""
        if request.mode == "local":
            # Use local path or current directory
            repo_path = request.local_path or Path.cwd()

            if not self.git_provider.is_git_repository(repo_path):
                print_warning("Not a git repository - continuing with basic analysis")

            return repo_path

        elif request.mode == "remote" and request.repo_url:
            # Clone repository to temporary location
            try:
                print_info(f"Cloning repository: {request.repo_url}")
                repo_path = self.git_provider.clone_temp_repo(request.repo_url)
                print_success(f"Repository cloned to: {repo_path}")
                return repo_path
            except Exception as e:
                print_error(f"Failed to clone repository: {str(e)}")
                return None
        else:
            print_error("Invalid mode or missing repository URL for remote mode")
            return None

    def _execute_with_llm(self, agent: Dict[str, Any], context: AgentContext, repo_path: Path, interactive: bool = True) -> Dict[str, Any]:
        """Execute agent using LLM provider."""
        llm_context = {
            "command_type": "agent_execution",
            "agent_name": agent["name"],
            "agent_file": agent["file_path"],
            "service_name": context.service_name,
            "repo_path": str(repo_path),
            "mode": context.mode,
            "docs_only": context.docs_only,
            "deps_only": context.deps_only,
            "force": context.force,
            "execution_id": context.execution_id,
            "timestamp": context.timestamp
        }

        # Build prompts for LLM
        agent_file_path = Path(agent["file_path"]) if "file_path" in agent else None
        prompt = self.build_prompt("agent_execution", llm_context, agent_file_path)
        system_prompt = self.build_system_prompt("agent_execution", llm_context, agent_file_path)

        # Add prompts to context
        llm_context["prompt"] = prompt
        llm_context["system_prompt"] = system_prompt

        success = self.llm_manager.run_analysis(
            command_type="agent_execution",
            context=llm_context,
            interactive=interactive
        )

        # Return a dict with the result
        if success:
            # For now, return basic success result
            # In a real implementation, we'd get actual output files from Claude
            return {
                "success": True,
                "output_files": [],
                "documentation_files": [],
                "dependency_files": []
            }
        else:
            return {
                "success": False,
                "error": "Claude execution failed"
            }

    def _execute_fallback(self, request: AgentExecutionRequest, context: AgentContext, repo_path: Path) -> Dict[str, Any]:
        """Fallback execution without Claude."""
        output_files = []

        # Create basic documentation structure
        if not request.deps_only:
            docs_dir = self._ensure_docs_directory(repo_path)

            # Create basic service documentation
            service_doc_path = docs_dir / f"{request.service_name}-analysis.md"
            service_doc_content = self._generate_basic_documentation(request, context, repo_path)
            service_doc_path.write_text(service_doc_content, encoding='utf-8')
            output_files.append(str(service_doc_path))

        # Create basic dependency analysis
        if not request.docs_only:
            deps_file = self._create_basic_dependency_analysis(request, repo_path)
            if deps_file:
                output_files.append(deps_file)

        return {
            "success": True,
            "output_files": output_files,
            "documentation_files": output_files if not request.deps_only else [],
            "dependency_files": [deps_file] if deps_file and not request.docs_only else []
        }

    def _ensure_docs_directory(self, repo_path: Path) -> Path:
        """Ensure documentation directory exists."""
        docs_dir = repo_path / DOCS_SERVICE_DIR
        ensure_path_exists(docs_dir)
        return docs_dir

    def _generate_basic_documentation(self, request: AgentExecutionRequest, context: AgentContext, repo_path: Path) -> str:
        """Generate basic documentation content."""
        content = f"# {request.service_name} Analysis\n\n"
        content += f"**Generated by**: Agent {request.agent_name}\n"
        content += f"**Date**: {context.timestamp}\n"
        content += f"**Mode**: {context.mode}\n\n"

        content += "## Overview\n\n"
        content += f"This document contains analysis results for {request.service_name}.\n\n"

        content += "## Repository Information\n\n"
        if request.repo_url:
            content += f"- **Repository**: {request.repo_url}\n"
        content += f"- **Local Path**: {repo_path}\n"
        content += f"- **Analysis Date**: {context.timestamp}\n\n"

        content += "## Analysis Results\n\n"
        content += "*Detailed analysis would be provided by Claude AI integration.*\n\n"

        content += "---\n"
        content += f"Generated by Microforge v2 Agent: {request.agent_name}\n"

        return content

    def _create_basic_dependency_analysis(self, request: AgentExecutionRequest, repo_path: Path) -> Optional[str]:
        """Create basic dependency analysis."""
        try:
            deps_file = repo_path / "dependency-analysis.yaml"
            deps_content = {
                "service_name": request.service_name,
                "analysis_date": datetime.now().isoformat(),
                "dependencies": {
                    "note": "Full dependency analysis requires Claude AI integration"
                }
            }

            import yaml
            deps_file.write_text(yaml.dump(deps_content, default_flow_style=False), encoding='utf-8')
            return str(deps_file)
        except Exception as e:
            print_warning(f"Failed to create dependency analysis: {str(e)}")
            return None

    def _handle_remote_completion(self, context: AgentContext, repo_path: Path) -> Optional[str]:
        """Handle completion tasks for remote mode."""
        try:
            # Create branch name
            branch_name = f"microforge-analysis-{context.service_name}-{context.execution_id[:8]}"

            print_info(f"Creating branch: {branch_name}")

            # Create and checkout branch
            self.git_provider.checkout(branch_name, create=True, path=repo_path)

            # Add and commit changes
            self.git_provider.add_files(["."], path=repo_path)
            self.git_provider.commit(
                f"Add analysis results from agent {context.agent_name}\n\nGenerated by Microforge v2",
                path=repo_path
            )

            print_success(f"Branch '{branch_name}' created with analysis results")
            return branch_name

        except Exception as e:
            print_warning(f"Failed to create branch: {str(e)}")
            return None

    def list_available_agents(self) -> List[Dict[str, Any]]:
        """List all available agents."""
        agents = []

        # Get agents from registry
        registry_agents = self.registry.agents.list_agents()
        for agent in registry_agents:
            agents.append({
                "name": agent.id,
                "display_name": agent.display_name,
                "description": agent.description,
                "file_name": agent.file_name,
                "service": getattr(agent, 'service', None),
                "enabled": agent.enabled,
                "source": "registry"
            })

        return agents

    def get_agent_info(self, agent_name: str, service: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Get detailed information about an agent."""
        agent = self.registry.agents.get_agent(agent_name)
        if not agent:
            return None

        # Get prompt from storage if available
        prompt = self.registry.agents.get_agent_prompt(agent_name, service=service)

        return {
            "name": agent.id,
            "display_name": agent.display_name,
            "description": agent.description,
            "file_name": agent.file_name,
            "service": getattr(agent, 'service', None),
            "is_global": getattr(agent, 'is_global', True),
            "category": getattr(agent, 'category', None),
            "tags": getattr(agent, 'tags', []),
            "enabled": agent.enabled,
            "version": agent.version,
            "provider": getattr(agent, 'provider', 'claude'),
            "temperature": getattr(agent, 'temperature', None),
            "max_tokens": getattr(agent, 'max_tokens', None),
            "has_prompt": prompt is not None
        }

    def list_agents_by_service(self, service_name: str) -> List[Dict[str, Any]]:
        """List all agents for a specific service."""
        agents = []

        # Validate service exists
        if not self.registry.services.get_service(service_name):
            raise NotFoundError(f"Service '{service_name}' not found in registry")

        service_agents = self.registry.agents.get_agents_by_service(service_name)

        # Check for required implementation.md agent (using composite key)
        has_implementation_agent = False
        for agent in service_agents:
            if agent.id == f"{service_name}-implementation" or agent.id == "implementation":
                has_implementation_agent = True
            agents.append({
                "name": agent.id,
                "display_name": agent.display_name,
                "description": agent.description,
                "service": service_name,
                "category": getattr(agent, 'category', None),
                "tags": getattr(agent, 'tags', []),
                "enabled": agent.enabled
            })

        # Warn if implementation.md is missing for service-level agents
        if agents and not has_implementation_agent:
            print_warning(f"Service '{service_name}' is missing required 'implementation.md' agent")
            print_info("The implementation.md agent should orchestrate all sub-agents for implementation tasks")

        return agents

    def validate_service_agents(self, service: str) -> bool:
        """Validate that service-level agents have required implementation.md.

        Args:
            service: Service name to validate

        Returns:
            True if validation passes (has implementation.md or no agents)
        """
        if not service:
            return True  # Global agents don't need implementation.md

        service_agents = self.registry.agents.get_agents_by_service(service)
        # Check for implementation agent using composite key pattern: {service}-implementation
        has_implementation = any(
            agent.id == f"{service}-implementation" or agent.id == "implementation"
            for agent in service_agents
        )

        # Only warn if there are other agents but no implementation.md
        if service_agents and not has_implementation:
            print_warning(f"Service '{service}' is missing required 'implementation.md' agent")
            print_info("The implementation.md agent should orchestrate all sub-agents for implementation tasks")
            return False
        return True

    def upload_agent_prompt(self, agent_name: str, content: str,
                           service: Optional[str] = None, overwrite: bool = True) -> bool:
        """Upload agent prompt to storage and update registry."""
        if not self.storage:
            raise StorageError("No storage provider configured")

        # Validate service if provided (but don't fail if it doesn't exist)
        if service:
            if not self.registry.services.get_service(service):
                print_warning(f"Service '{service}' not in registry, creating service-specific agent anyway")

        # Construct storage path (always {service}/{agent_name}.md for service-specific)
        if service:
            path = f"{service}/{agent_name}.md"
        else:
            path = f"{agent_name}.md"

        # Construct registry ID using composite key for service-specific agents
        # This prevents conflicts when multiple services have same agent name (e.g., implementation.md)
        if service:
            registry_id = f"{service}-{agent_name}"
        else:
            registry_id = agent_name

        try:
            success = self.storage.upload_blob_text(path, content, overwrite=overwrite)
            if success:
                print_success(f"Uploaded agent prompt: {agent_name}")

                # Always update or add to registry using composite key
                existing_agent = self.registry.agents.get_agent(registry_id)

                if existing_agent:
                    # Update existing agent
                    self.registry.agents.update_agent(
                        registry_id,
                        service=service,
                        file_name=f"{agent_name}.md",
                        updated_at=datetime.now().isoformat()
                    )
                    print_info(f"Updated agent '{registry_id}' in registry")
                else:
                    # Add new agent to registry
                    try:
                        # Extract description from content if possible
                        lines = content.split('\n')
                        description = f"Agent for {agent_name}"
                        for line in lines[:10]:  # Check first 10 lines
                            if line.strip() and not line.startswith('#'):
                                description = line.strip()
                                break

                        self.registry.agents.add_agent(
                            name=registry_id,
                            file_name=f"{agent_name}.md",
                            description=description,
                            service=service,
                            is_global=service is None,
                            enabled=True,
                            created_at=datetime.now().isoformat()
                        )
                        print_info(f"Added agent '{registry_id}' to registry")
                    except ValidationError as e:
                        # Don't fail if can't add to registry, just warn
                        print_warning(f"Could not add to registry: {e}")

            # Validate service-level agents after upload
            if success and service and agent_name != "implementation":
                self.validate_service_agents(service)

            return success
        except Exception as e:
            print_error(f"Failed to upload agent prompt: {e}")
            return False

    def download_agent_prompt(self, agent_name: str, service: Optional[str] = None) -> Optional[str]:
        """Download agent prompt from storage."""
        return self.registry.agents.get_agent_prompt(agent_name, service=service)

    def sync_agents(self, direction: str = "download", service: Optional[str] = None) -> Dict[str, Any]:
        """Sync agents between local and storage."""
        return self.registry.agents.sync_with_storage(direction=direction, service=service)

    def list_storage_agents(self, service: Optional[str] = None) -> List[Dict[str, Any]]:
        """List agents available in storage."""
        return self.registry.agents.list_storage_agents(service=service)

    def delete_agent_prompt(self, agent_name: str, service: Optional[str] = None) -> bool:
        """Delete agent prompt from storage and update registry."""
        if not self.storage:
            raise StorageError("No storage provider configured")

        # Construct path
        if service:
            path = f"{service}/{agent_name}.md"
        else:
            path = f"{agent_name}.md"

        try:
            success = self.storage.delete_blob(path)
            if success:
                print_success(f"Deleted agent prompt: {agent_name}")

                # Update registry - mark as disabled or remove
                existing_agent = self.registry.agents.get_agent(agent_name)
                if existing_agent:
                    try:
                        # Mark as disabled rather than deleting from registry
                        self.registry.agents.update_agent(
                            agent_name,
                            enabled=False,
                            updated_at=datetime.now().isoformat()
                        )
                        print_info(f"Marked agent '{agent_name}' as disabled in registry")
                    except Exception as e:
                        print_warning(f"Could not update registry: {e}")

            return success
        except Exception as e:
            print_error(f"Failed to delete agent prompt: {e}")
            return False

    def download_service_agents_to_temp(self, service_name: str) -> Path:
        """Download all agents for a service to a temporary directory.

        Args:
            service_name: Name of the service to download agents for

        Returns:
            Path to temporary directory containing all service agents
        """
        import tempfile
        import shutil
        from ...config.constants import TEMP_AGENTS_DIR_PREFIX, TEMP_AGENTS_CLEANUP_ON_ERROR

        # Create temporary directory for service agents
        temp_dir = Path(tempfile.mkdtemp(prefix=f"{TEMP_AGENTS_DIR_PREFIX}{service_name}_"))
        print_info(f"Downloading service agents to: {temp_dir}")

        try:
            # Get all agents for this service from storage
            service_agents = self.registry.agents.list_storage_agents(service=service_name)

            if not service_agents:
                print_warning(f"No agents found in storage for service '{service_name}'")
                return temp_dir

            downloaded_count = 0
            for agent_info in service_agents:
                agent_name = agent_info.get('name', '').replace('.md', '')
                if not agent_name:
                    continue

                # Download agent content
                agent_content = self.registry.agents.get_agent_prompt(agent_name, service=service_name)
                if agent_content:
                    agent_file = temp_dir / f"{agent_name}.md"
                    agent_file.write_text(agent_content, encoding='utf-8')
                    downloaded_count += 1
                    print_info(f"Downloaded: {agent_name}.md")

            if downloaded_count > 0:
                print_success(f"Downloaded {downloaded_count} agents for service '{service_name}'")
            else:
                print_warning(f"No agent content could be retrieved for service '{service_name}'")

        except Exception as e:
            print_error(f"Error downloading service agents: {e}")
            # Clean up on error if configured to do so
            if TEMP_AGENTS_CLEANUP_ON_ERROR and temp_dir.exists():
                shutil.rmtree(temp_dir, ignore_errors=True)
            raise

        return temp_dir

    def run_agent(self, request: AgentRunRequest) -> AgentExecutionResult:
        """
        Run a specific agent with Claude AI.

        This method delegates to execute_agent with proper setup for different modes.

        Args:
            request: Agent run request with configuration

        Returns:
            Agent execution result with status and branch information
        """
        import tempfile

        # Validate request
        if not request.global_agent and not request.branch:
            raise ValidationError("Branch is required for non-global agents")

        if request.global_agent and (request.service or request.branch):
            raise ValidationError("Global agents cannot use service or branch options")

        temp_repo_path = None
        original_dir = Path.cwd()

        try:
            # Determine mode and set up repository
            if request.global_agent:
                # Global agent - no repo context
                mode = "global"
                repo_url = None
                local_path = None
                print_info("Running global agent without repository context")

            elif request.service:
                # Service mode - clone and work in service repo
                mode = "remote"
                service = self.registry.services.get_service(request.service)
                if not service:
                    raise NotFoundError(f"Service '{request.service}' not found in registry")
                if not service.repo_url:
                    raise ValidationError(f"Service '{request.service}' has no repository URL configured")

                repo_url = service.repo_url

                # Clone to temp directory
                temp_repo_path = Path(tempfile.mkdtemp(prefix=f"{TEMP_PREFIX}agent-run-"))
                print_info(f"Cloning repository to: {temp_repo_path}")

                success = self.git_provider.clone_repository(
                    repo_url=repo_url,
                    target_path=temp_repo_path,
                    branch=service.branch or 'main'
                )

                if not success:
                    raise GitError(f"Failed to clone repository: {repo_url}")

                # Change to repo directory
                import os
                os.chdir(temp_repo_path)
                local_path = temp_repo_path
                print_success(f"Cloned and switched to: {temp_repo_path}")

            else:
                # Local mode - use current directory
                mode = "local"
                repo_url = None
                local_path = Path.cwd()

                if not self.git_provider.is_git_repository(local_path):
                    raise ValidationError("Current directory is not a git repository")

                print_info("Using current local repository")

            # Handle branch creation for non-global agents
            if not request.global_agent and request.branch and local_path:
                print_info(f"Creating branch: {request.branch}")

                # Ensure we're on main/master
                current_branch = self.git_provider.get_current_branch(local_path)
                if current_branch not in ['main', 'master']:
                    if self.git_provider.checkout('main', create=False, path=local_path):
                        print_info("Switched to main branch")
                    elif self.git_provider.checkout('master', create=False, path=local_path):
                        print_info("Switched to master branch")

                # Pull latest changes
                self.git_provider.pull(path=local_path)

                # Create and checkout new branch
                if not self.git_provider.checkout(request.branch, create=True, path=local_path):
                    raise GitError(f"Failed to create branch: {request.branch}")

                print_success(f"Created and checked out branch: {request.branch}")

            # Build AgentExecutionRequest for execute_agent
            exec_request = AgentExecutionRequest(
                agent_name=request.agent_name,
                service_name=request.service or "local",
                repo_url=repo_url,
                local_path=local_path,
                mode=mode,
                interactive=request.interactive
            )

            # Execute the agent using existing infrastructure
            result = self.execute_agent(exec_request)

            # Handle post-execution git operations
            if not request.global_agent and request.branch and local_path:
                print_info("Checking for changes to commit...")

                changed_files = self.git_provider.get_changed_files(path=local_path)
                if changed_files:
                    # Add all changes
                    self.git_provider.add_files(["."], path=local_path)

                    # Commit changes
                    commit_message = f"feat: Apply {request.agent_name} agent changes\n\nExecuted by Microforge agent runner"
                    if self.git_provider.commit(commit_message, path=local_path):
                        print_success("Changes committed")

                        # Push to remote
                        if self.git_provider.push(branch=request.branch, path=local_path):
                            print_success(f"Changes pushed to branch: {request.branch}")
                            result.branch_created = request.branch
                        else:
                            print_warning("Failed to push changes (branch may not have remote)")
                else:
                    print_info("No changes detected")

            return result

        finally:
            # Clean up temp directory if created
            if temp_repo_path and temp_repo_path.exists():
                import os
                import shutil
                os.chdir(original_dir)
                print_info(f"Cleaning up: {temp_repo_path}")
                shutil.rmtree(temp_repo_path, ignore_errors=True)

