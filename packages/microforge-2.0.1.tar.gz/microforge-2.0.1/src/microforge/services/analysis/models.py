"""
Data models for the analysis service.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Optional, Dict, Any, List


class AnalysisMode(Enum):
    """Analysis execution modes."""
    LOCAL = "local"
    REMOTE = "remote"
    BATCH = "batch"


@dataclass
class AnalysisRequest:
    """Request model for analysis operations."""
    target: Optional[str] = None
    analyze_all: bool = False
    docs_only: bool = False
    deps_only: bool = False
    force: bool = False
    batch: bool = False

    def __post_init__(self):
        """Validate request after initialization."""
        if not self.target and not self.analyze_all:
            self.target = "."  # Default to current directory

    @classmethod
    def from_cli_args(
        cls,
        target: Optional[str] = None,
        analyze_all: bool = False,
        docs_only: bool = False,
        deps_only: bool = False,
        force: bool = False,
        batch: bool = False
    ) -> "AnalysisRequest":
        """Create request from CLI arguments."""
        return cls(
            target=target,
            analyze_all=analyze_all,
            docs_only=docs_only,
            deps_only=deps_only,
            force=force,
            batch=batch
        )


@dataclass
class AnalysisResult:
    """Result model for analysis operations."""
    success: bool
    service_name: str
    mode: AnalysisMode
    docs_generated: bool = False
    deps_generated: bool = False
    error_message: Optional[str] = None
    git_info: Optional[Dict[str, str]] = None
    repo_url: Optional[str] = None
    duration_ms: Optional[float] = None
    batch_results: Optional[List["AnalysisResult"]] = None

    @property
    def is_batch(self) -> bool:
        """Check if this is a batch analysis result."""
        return self.batch_results is not None

    @property
    def total_services(self) -> int:
        """Get total number of services analyzed in batch."""
        return len(self.batch_results) if self.batch_results else 1

    @property
    def successful_services(self) -> int:
        """Get number of successfully analyzed services in batch."""
        if not self.batch_results:
            return 1 if self.success else 0
        return sum(1 for result in self.batch_results if result.success)

    def to_dict(self) -> Dict[str, Any]:
        """Convert result to dictionary for serialization."""
        result_dict = {
            "success": self.success,
            "service_name": self.service_name,
            "mode": self.mode.value,
            "docs_generated": self.docs_generated,
            "deps_generated": self.deps_generated,
            "error_message": self.error_message,
            "git_info": self.git_info,
            "repo_url": self.repo_url,
            "duration_ms": self.duration_ms,
        }

        if self.batch_results:
            result_dict["batch_results"] = [
                result.to_dict() for result in self.batch_results
            ]
            result_dict["total_services"] = self.total_services
            result_dict["successful_services"] = self.successful_services

        return result_dict


@dataclass
class AgentInfo:
    """Information about an analysis agent."""
    name: str
    filename: str
    description: str
    required_for_docs: bool = False
    required_for_deps: bool = False
    available: bool = False

    @classmethod
    def from_filename(cls, filename: str) -> "AgentInfo":
        """Create agent info from filename."""
        # Map filenames to descriptions
        descriptions = {
            "base_orchestrator.md": "Coordinates repository access and agent routing",
            "documentation.md": "Generates comprehensive service documentation",
            "dependency_graph.md": "Analyzes and visualizes service dependencies",
            "audit_report.md": "Performs code quality and security audits",
            "security.md": "Focuses on security vulnerability analysis",
            "performance.md": "Analyzes performance bottlenecks and optimizations",
            "implementation.md": "Provides implementation guidance and best practices",
            "refactoring.md": "Suggests code refactoring opportunities",
            "test_generator.md": "Generates test cases and test strategies"
        }

        name = filename.replace(".md", "").replace("_", " ").title()
        description = descriptions.get(filename, "Analysis agent")

        # Determine requirements
        required_for_docs = filename in ["documentation.md", "base_orchestrator.md"]
        required_for_deps = filename in ["dependency_graph.md", "base_orchestrator.md"]

        return cls(
            name=name,
            filename=filename,
            description=description,
            required_for_docs=required_for_docs,
            required_for_deps=required_for_deps
        )


@dataclass
class AnalysisStatus:
    """Status of analysis for a service."""
    service_name: str
    docs_exist: bool
    deps_exist: bool
    docs_dir: str
    up_to_date: bool
    last_analysis: Optional[str] = None
    git_branch: Optional[str] = None
    git_commit: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert status to dictionary."""
        return {
            "service_name": self.service_name,
            "docs_exist": self.docs_exist,
            "deps_exist": self.deps_exist,
            "docs_dir": self.docs_dir,
            "up_to_date": self.up_to_date,
            "last_analysis": self.last_analysis,
            "git_branch": self.git_branch,
            "git_commit": self.git_commit
        }