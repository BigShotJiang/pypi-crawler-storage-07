"""
Analysis service for comprehensive service analysis.

Handles documentation generation and dependency graph analysis.
"""

from pathlib import Path
from typing import Dict, Any, Optional, List
from dataclasses import dataclass

from ...core.exceptions import ValidationError, ServiceError, GitError
from ...core.common import (
    console,
    print_success,
    print_error,
    print_warning,
    print_info
)
from ...providers.vcs.git import is_git_repository, get_git_repository_info
from ...config.constants import (
    PACKAGE_DIR,
    AGENTS_SUBDIR,
    AGENT_BASE_ORCHESTRATOR,
    AGENT_DOCUMENTATION,
    AGENT_DEPENDENCY_GRAPH,
    CLAUDE_DEFAULT_TOOLS,
    CLAUDE_ANALYSIS_TOOLS,
    SUCCESS_ANALYSIS_COMPLETED,
    ERROR_NOT_GIT_REPO
)
# get_llm_manager import removed - using self.llm_manager from BaseService
from ..base import BaseService
from .models import AnalysisRequest, AnalysisResult, AnalysisMode


@dataclass
class AnalysisContext:
    """Context for analysis operations."""
    service_name: str
    repo_url: Optional[str]
    mode: AnalysisMode
    docs_only: bool
    deps_only: bool
    force: bool
    repo_path: str
    analyze_all: bool


class AnalysisService(BaseService):
    """Service for code analysis and documentation generation."""

    def __init__(self):
        super().__init__()
        self.agents_dir = self.get_agents_directory()

    def analyze(self, request: AnalysisRequest) -> AnalysisResult:
        """
        Perform comprehensive analysis of a service.

        Args:
            request: Analysis request with all parameters

        Returns:
            Analysis result

        Raises:
            ValidationError: If request parameters are invalid
            ServiceError: If analysis fails
        """
        # Validate request
        self._validate_request(request)

        # Check agent files
        self._check_agent_files(request)

        # Determine analysis mode
        mode = self._determine_mode(request)

        # Build context
        context = self._build_context(request, mode)

        # Display analysis plan
        self._display_analysis_plan(context)

        # Execute analysis
        try:
            if context.analyze_all:
                return self._analyze_all_services(context, request)
            elif mode == AnalysisMode.LOCAL:
                return self._analyze_local(context, request)
            else:
                return self._analyze_remote(context, request)

        except Exception as e:
            print_error(f"Analysis failed: {str(e)}")
            raise ServiceError(
                "Analysis execution failed",
                service_name=self.name,
                operation="analyze"
            ) from e

    def _validate_request(self, request: AnalysisRequest) -> None:
        """Validate analysis request parameters."""
        if not request.target and not request.analyze_all:
            raise ValidationError("Target or analyze_all must be specified")

        if request.docs_only and request.deps_only:
            raise ValidationError("Cannot specify both docs_only and deps_only")

        if request.target and request.target != "." and request.analyze_all:
            raise ValidationError("Cannot specify both target and analyze_all")

    def _check_agent_files(self, request: AnalysisRequest) -> None:
        """Check that required agent files exist."""
        missing_agents = []

        # Check base orchestrator
        orchestrator_file = self.agents_dir / AGENT_BASE_ORCHESTRATOR
        if not orchestrator_file.exists():
            missing_agents.append(AGENT_BASE_ORCHESTRATOR)

        # Check documentation agent
        if not request.deps_only:
            doc_agent_file = self.agents_dir / AGENT_DOCUMENTATION
            if not doc_agent_file.exists():
                missing_agents.append(AGENT_DOCUMENTATION)

        # Check dependency graph agent
        if not request.docs_only:
            deps_agent_file = self.agents_dir / AGENT_DEPENDENCY_GRAPH
            if not deps_agent_file.exists():
                missing_agents.append(AGENT_DEPENDENCY_GRAPH)

        if missing_agents:
            print_error(f"Missing agent files: {', '.join(missing_agents)}")
            print_info(f"Expected in: {self.agents_dir}")
            raise ServiceError(
                f"Missing required agent files: {missing_agents}",
                service_name=self.name,
                operation="check_agent_files"
            )

    def _determine_mode(self, request: AnalysisRequest) -> AnalysisMode:
        """Determine the analysis mode based on request."""
        if request.analyze_all:
            return AnalysisMode.BATCH

        if request.target == ".":
            # Local analysis - verify git repository
            if not is_git_repository():
                print_error(ERROR_NOT_GIT_REPO)
                print_warning("Initialize with: git init")
                raise GitError(
                    ERROR_NOT_GIT_REPO,
                    command="git init",
                    repo_path=str(Path.cwd())
                )
            return AnalysisMode.LOCAL

        return AnalysisMode.REMOTE

    def _build_context(self, request: AnalysisRequest, mode: AnalysisMode) -> AnalysisContext:
        """Build analysis context from request and mode."""
        if mode == AnalysisMode.LOCAL:
            service_name = Path.cwd().name
            repo_path = "."
            repo_url = None
        else:
            service_name = request.target or "unknown"
            repo_path = f"/tmp/{service_name}" if mode == AnalysisMode.REMOTE else "."
            repo_url = request.target if mode == AnalysisMode.REMOTE else None

        return AnalysisContext(
            service_name=service_name,
            repo_url=repo_url,
            mode=mode,
            docs_only=request.docs_only,
            deps_only=request.deps_only,
            force=request.force,
            repo_path=repo_path,
            analyze_all=request.analyze_all
        )

    def _display_analysis_plan(self, context: AnalysisContext) -> None:
        """Display the analysis plan to the user."""
        # Display operation mode
        if context.analyze_all:
            console.print("[bold cyan]📊 Analyzing all registered services[/bold cyan]\n")
        elif context.mode == AnalysisMode.LOCAL:
            console.print(f"[bold cyan]🔍 Analyzing current directory: {context.service_name}[/bold cyan]\n")
        else:
            console.print(f"[bold cyan]🔍 Analyzing service: {context.service_name}[/bold cyan]\n")

        # Show what will be generated
        if context.docs_only:
            console.print("[yellow]📚 Generating: Documentation only[/yellow]")
        elif context.deps_only:
            console.print("[yellow]🔗 Generating: Dependency graphs only[/yellow]")
        else:
            console.print("[yellow]📚 Generating: Documentation and dependency graphs[/yellow]")

        if context.force:
            console.print("[yellow]⚠️  Force mode: Regenerating even if up to date[/yellow]")

        # Display agent workflow
        console.print("\n[bold]🤖 AI Agent Workflow:[/bold]")
        console.print("1. Base orchestrator handles repository access")

        if not context.deps_only:
            console.print("2. Documentation agent generates comprehensive docs")
        if not context.docs_only:
            console.print("3. Dependency graph agent analyzes dependencies")

        if context.mode == AnalysisMode.LOCAL:
            console.print("4. Results saved locally (no auto-commit)")
        elif context.mode == AnalysisMode.REMOTE:
            console.print("4. Create branch and push to remote")
            console.print("5. Generate PR for review")
        elif context.mode == AnalysisMode.BATCH:
            console.print("4. Process each service sequentially")
            console.print("5. Provide summary report")

        # Show context
        console.print("\n[bold]📋 Agent Context:[/bold]")
        context_info = {
            "mode": context.mode.value,
            "target": context.service_name,
            "analyze_all": context.analyze_all,
            "docs_only": context.docs_only,
            "deps_only": context.deps_only,
            "force": context.force,
            "repo_path": context.repo_path,
        }

        for key, value in context_info.items():
            console.print(f"  • {key}: {value}")

    def _analyze_local(self, context: AnalysisContext, request: AnalysisRequest) -> AnalysisResult:
        """Analyze local repository."""
        # Get git repository info
        git_info = get_git_repository_info()

        # Build prompt for analysis
        prompt = self._build_analysis_prompt(context)
        system_prompt = self._build_system_prompt(context)

        # Execute analysis with simplified interface
        llm_context = {
            'prompt': prompt,
            'system_prompt': system_prompt,
            'tools': CLAUDE_ANALYSIS_TOOLS if not context.deps_only else CLAUDE_DEFAULT_TOOLS,
            'repo_path': context.repo_path
        }

        # Use inherited llm_manager from BaseService
        success = self.llm_manager.run_analysis(
            command_type="analyze",
            context=llm_context,
            interactive=not request.batch
        )

        if success:
            print_success(SUCCESS_ANALYSIS_COMPLETED)
            print_warning("Note: Changes saved locally. Review with: git status")

            return AnalysisResult(
                success=True,
                service_name=context.service_name,
                mode=context.mode,
                docs_generated=not context.deps_only,
                deps_generated=not context.docs_only,
                git_info=git_info
            )
        else:
            raise ServiceError(
                "Local analysis failed",
                service_name=self.name,
                operation="analyze_local"
            )

    def _analyze_remote(self, context: AnalysisContext, request: AnalysisRequest) -> AnalysisResult:
        """Analyze remote repository."""
        # Build prompt for analysis
        prompt = self._build_analysis_prompt(context)
        system_prompt = self._build_system_prompt(context)

        # Execute analysis with simplified interface
        llm_context = {
            'prompt': prompt,
            'system_prompt': system_prompt,
            'tools': CLAUDE_ANALYSIS_TOOLS if not context.deps_only else CLAUDE_DEFAULT_TOOLS,
            'repo_path': context.repo_path
        }

        # Use inherited llm_manager from BaseService
        success = self.llm_manager.run_analysis(
            command_type="analyze",
            context=llm_context,
            interactive=not request.batch
        )

        if success:
            print_success(SUCCESS_ANALYSIS_COMPLETED)

            return AnalysisResult(
                success=True,
                service_name=context.service_name,
                mode=context.mode,
                docs_generated=not context.deps_only,
                deps_generated=not context.docs_only,
                repo_url=context.repo_url
            )
        else:
            raise ServiceError(
                "Remote analysis failed",
                service_name=self.name,
                operation="analyze_remote"
            )

    def _analyze_all_services(self, context: AnalysisContext, request: AnalysisRequest) -> AnalysisResult:
        """Analyze all registered services."""
        from ...registries.manager import get_registry_manager

        registry_manager = get_registry_manager()
        services = registry_manager.services.list_services()

        if not services:
            print_warning("No services registered for analysis")
            return AnalysisResult(
                success=True,
                service_name="all",
                mode=context.mode,
                docs_generated=False,
                deps_generated=False,
                batch_results=[]
            )

        print_info(f"Found {len(services)} registered services")

        results = []
        successful = 0

        for service in services:
            print_info(f"Analyzing service: {service.name}")

            # Create individual request for this service
            service_request = AnalysisRequest(
                target=service.name,
                docs_only=request.docs_only,
                deps_only=request.deps_only,
                force=request.force,
                provider=request.provider,
                batch=True  # Always use batch mode for multi-service
            )

            try:
                # Create context for this service
                service_context = AnalysisContext(
                    service_name=service.name,
                    repo_url=service.repo_url,
                    mode=AnalysisMode.REMOTE,
                    docs_only=request.docs_only,
                    deps_only=request.deps_only,
                    force=request.force,
                    repo_path=f"/tmp/{service.name}",
                    analyze_all=False
                )

                result = self._analyze_remote(service_context, service_request)
                results.append(result)
                if result.success:
                    successful += 1

            except Exception as e:
                print_error(f"Failed to analyze {service.name}: {str(e)}")
                results.append(AnalysisResult(
                    success=False,
                    service_name=service.name,
                    mode=AnalysisMode.REMOTE,
                    error_message=str(e)
                ))

        print_success(f"Batch analysis completed: {successful}/{len(services)} services analyzed successfully")

        return AnalysisResult(
            success=successful > 0,
            service_name="all",
            mode=context.mode,
            docs_generated=not context.deps_only,
            deps_generated=not context.docs_only,
            batch_results=results
        )

    def _build_analysis_prompt(self, context: AnalysisContext) -> str:
        """Build prompt for analysis command."""
        # Return empty prompt - all instructions are in system prompt
        return ""

    def _build_system_prompt(self, context: AnalysisContext) -> str:
        """Build system prompt for the LLM."""
        agent_file = self.get_agents_directory() / AGENT_BASE_ORCHESTRATOR

        prompt_context = {
            'repo_path': context.repo_path,
            'service_name': context.service_name,
            'mode': context.mode.value,
            'docs_only': context.docs_only,
            'deps_only': context.deps_only,
            'force': context.force
        }

        # Use enhanced system prompt builder with agent file
        return self.build_system_prompt('analyze', prompt_context, agent_file)

    def _build_llm_context(self, context: AnalysisContext) -> Dict[str, Any]:
        """Build context for LLM provider (legacy)."""
        return {
            "service_name": context.service_name,
            "repo_url": context.repo_url,
            "mode": context.mode.value,
            "docs_only": context.docs_only,
            "deps_only": context.deps_only,
            "force": context.force,
            "repo_path": context.repo_path,
            "analyze_all": context.analyze_all
        }

    def get_analysis_status(self, service_name: str) -> Dict[str, Any]:
        """Get the status of previous analysis for a service."""
        # This could check for existing docs/deps files
        # and their timestamps to determine if analysis is up to date
        docs_dir = Path("docs/service")
        deps_file = docs_dir / "dependencies.md"
        docs_file = docs_dir / "README.md"

        return {
            "service_name": service_name,
            "docs_exist": docs_file.exists(),
            "deps_exist": deps_file.exists(),
            "docs_dir": str(docs_dir),
            "up_to_date": False  # TODO: Implement timestamp checking
        }

    def list_available_agents(self) -> List[str]:
        """List available analysis agent files."""
        if not self.agents_dir.exists():
            return []

        agent_files = []
        for file_path in self.agents_dir.glob("*.md"):
            agent_files.append(file_path.name)

        return sorted(agent_files)