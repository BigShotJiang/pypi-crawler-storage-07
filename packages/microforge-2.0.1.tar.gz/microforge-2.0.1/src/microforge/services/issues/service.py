"""
Issues service implementation for Microforge v2.

Handles GitHub issues fetching, creation, and Claude AI integration.
"""

import time
import json
import yaml
from pathlib import Path
from typing import List, Dict, Any, Optional

from ...config.constants import (
    ISSUES_DIR,
    GITHUB_CLI_EXECUTABLE,
    GITHUB_ISSUES_DEFAULT_LIMIT,
    GITHUB_ISSUES_MAX_LIMIT,
    GITHUB_ISSUE_STATE_OPEN,
    GITHUB_ISSUE_STATE_CLOSED,
    GITHUB_ISSUE_STATE_ALL,
    ISSUE_MD_FILENAME,
    ATTACHMENTS_DIR_NAME
)
from ...core.common import (
    console, print_success, print_error, print_info, print_warning,
    ensure_path_exists, save_config_file, load_config_file
)
from ...core.exceptions import ValidationError, FileSystemError, NotFoundError
from ...providers.vcs.github import GitHubProvider
from ...providers.vcs.git import GitProvider
# ClaudeProvider import removed - using llm_manager from BaseService
from ...registries.manager import get_registry_manager
from ..base import BaseService
from .models import IssuesRequest, IssuesResult, IssueData, IssueMetadata, IssueSubmissionContext


class IssuesService(BaseService):
    """
    Service for GitHub issues management.

    Handles fetching, creating, and submitting issues to Claude AI.
    """

    def __init__(self):
        super().__init__()
        self.github_provider = GitHubProvider()
        # llm_manager is inherited as a property from BaseService
        # registry is inherited as a property from BaseService

    def fetch_issues(self, request: IssuesRequest) -> IssuesResult:
        """
        Fetch GitHub issues and save them locally.

        Args:
            request: Issues fetch request

        Returns:
            Issues result with fetched issues
        """
        start_time = time.time()
        result = IssuesResult(
            success=False,
            operation="fetch",
            downloaded_count=0
        )

        try:
            # Validate GitHub CLI availability
            if not self.github_provider.is_cli_available():
                raise ValidationError("GitHub CLI is not available or not authenticated")

            # Determine repository context
            repo_info = self._get_repository_context(request)
            if not repo_info:
                raise ValidationError("Could not determine repository context")

            print_info(f"Fetching issues from {repo_info['full_name']}")

            # Build GitHub CLI command
            gh_command = self._build_fetch_command(request, repo_info)

            # Execute GitHub CLI command
            gh_result = self.github_provider.run_gh_command(gh_command)

            if not gh_result["success"]:
                raise ValidationError(f"GitHub CLI command failed: {gh_result['stderr']}")

            # Parse issues from JSON output
            issues_data = json.loads(gh_result["stdout"]) if gh_result["stdout"] else []

            # Convert to IssueData models
            issues = []
            for issue_json in issues_data:
                try:
                    issue = self._parse_issue_json(issue_json)
                    issues.append(issue)
                except Exception as e:
                    result.warnings.append(f"Failed to parse issue {issue_json.get('number', 'unknown')}: {str(e)}")

            result.issues = issues

            if request.fetch_all:
                # Save all issues locally when --all flag is specified
                if issues:
                    saved_count = self._save_issues_locally(issues, request.output_dir, request.no_attachments)
                    result.downloaded_count = saved_count
                    result.created_files = [str(request.output_dir / f"issue-{issue.number}" / ISSUE_MD_FILENAME) for issue in issues]

                result.success = True
                result.execution_time_ms = (time.time() - start_time) * 1000

                if result.downloaded_count > 0:
                    print_success(f"Successfully fetched and saved {result.downloaded_count} issues")
                else:
                    print_info("No issues matched the criteria")
            else:
                # Interactive mode - show table and ask for selection
                if not issues:
                    print_info("No issues found matching the criteria")
                    result.success = True
                    result.execution_time_ms = (time.time() - start_time) * 1000
                    return result

                # Display issues for selection (reuse similar logic as submit command)
                selected_issues = self._select_issues_interactively(issues, repo_info['full_name'])

                if selected_issues:
                    # Save only selected issues
                    saved_count = self._save_issues_locally(selected_issues, request.output_dir, request.no_attachments)
                    result.downloaded_count = saved_count
                    result.created_files = [str(request.output_dir / f"issue-{issue.number}" / ISSUE_MD_FILENAME) for issue in selected_issues]
                    print_success(f"Successfully fetched and saved {result.downloaded_count} selected issues")
                else:
                    print_info("No issues selected")

                result.success = True
                result.execution_time_ms = (time.time() - start_time) * 1000

            return result

        except Exception as e:
            result.errors.append(str(e))
            result.execution_time_ms = (time.time() - start_time) * 1000
            print_error(f"Failed to fetch issues: {str(e)}")
            return result

    def create_issue(self, request: IssuesRequest) -> IssuesResult:
        """
        Create a GitHub issue from local files.

        Args:
            request: Issues create request

        Returns:
            Issues result with created issue URL
        """
        start_time = time.time()
        result = IssuesResult(
            success=False,
            operation="create"
        )

        try:
            if not request.issue_dir:
                raise ValidationError("Issue directory is required for create operation")

            # Validate issue directory
            issue_dir = Path(request.issue_dir)
            if not issue_dir.exists():
                raise FileSystemError(f"Issue directory not found: {issue_dir}")

            # Load issue metadata and content
            metadata, content = self._load_issue_data(issue_dir, request)

            # Validate GitHub CLI availability
            if not self.github_provider.is_cli_available():
                raise ValidationError("GitHub CLI is not available or not authenticated")

            # Determine repository context
            repo_info = self._get_repository_context(request)
            if not repo_info:
                raise ValidationError("Could not determine repository context")

            # Create issue using GitHub CLI
            gh_result = self._create_github_issue(metadata, content, repo_info, request.draft)

            if gh_result["success"]:
                # Parse created issue URL from output
                issue_url = self._extract_issue_url_from_output(gh_result["stdout"])
                result.created_issue_url = issue_url
                result.success = True
                print_success(f"Issue created successfully: {issue_url}")
            else:
                raise ValidationError(f"Failed to create issue: {gh_result['stderr']}")

            result.execution_time_ms = (time.time() - start_time) * 1000
            return result

        except Exception as e:
            result.errors.append(str(e))
            result.execution_time_ms = (time.time() - start_time) * 1000
            print_error(f"Failed to create issue: {str(e)}")
            return result

    def submit_issue_to_claude(self, request: IssuesRequest) -> IssuesResult:
        """
        Submit an issue to Claude AI for processing.

        Args:
            request: Issues submit request

        Returns:
            Issues result with submission status
        """
        start_time = time.time()
        result = IssuesResult(
            success=False,
            operation="submit"
        )

        try:
            if not request.issue_id:
                raise ValidationError("Issue ID is required for submit operation")

            # Build submission context
            context = self._build_submission_context(request)

            # Determine repository to fetch issue from
            repo_url = None
            detected_service = None

            if request.service:
                # Get service from registry to get its repo URL
                service = self.registry.services.get_service(request.service)
                if service and service.repo_url:
                    # Extract owner/repo from the URL
                    import re
                    match = re.match(r'https://github\.com/([^/]+)/([^/]+)', service.repo_url)
                    if match:
                        repo_url = f"{match.group(1)}/{match.group(2)}"
                        print_info(f"Using service repository: {repo_url}")
                    else:
                        print_warning(f"Could not parse repo URL for service '{request.service}'")
                else:
                    print_warning(f"Service '{request.service}' not found or has no repo URL")
            else:
                # No service specified - try to detect from current directory
                current_repo_info = self.github_provider.get_repo_info()
                if current_repo_info:
                    repo_url = current_repo_info.get('full_name')
                    print_info(f"Using current repository: {repo_url}")

                    # Try to find a service that matches this repo
                    remote_url = GitProvider.get_remote_url()
                    if remote_url:
                        detected_service = self.registry.services.get_service_by_repo_url(remote_url)
                        if detected_service:
                            print_info(f"Detected service '{detected_service.name}' from repository")
                            # Set the service in the request for agent selection
                            request.service = detected_service.name

            # Fall back to default if no repo could be determined
            if not repo_url:
                repo_url = "inviz-search/microforge-ai"
                print_info(f"Using default repository: {repo_url}")

            # Fetch the issue details from GitHub
            github_provider = GitHubProvider()
            gh_command = [
                "issue", "view", request.issue_id,
                "--repo", repo_url,
                "--json", "title,body,number,labels,state,url"
            ]
            gh_result = github_provider.run_gh_command(gh_command)

            if not gh_result['success']:
                raise Exception(f"Failed to fetch issue details: {gh_result['stderr']}")

            import json
            issue_data = json.loads(gh_result['stdout'])

            # Convert to IssueData model and save locally with attachments
            issue_model = IssueData(
                number=issue_data["number"],
                title=issue_data["title"],
                body=issue_data.get("body", ""),
                state=issue_data["state"],
                labels=[label["name"] for label in issue_data.get("labels", [])],
                assignees=[],  # Not needed for submit
                milestone=None,  # Not needed for submit
                created_at="",  # Not needed for submit
                updated_at="",  # Not needed for submit
                url=issue_data["url"],
                author="",  # Not needed for submit
                comments_count=0,
                reactions={}
            )

            # Create issue directory and save locally with attachments
            issue_dir = Path(f"issues/issue_{request.issue_id}")
            ensure_path_exists(issue_dir)

            # Download attachments for the issue
            self._download_issue_attachments(issue_model, issue_dir)

            # Determine which agent to use
            # Check if user explicitly provided an agent or using default
            user_provided_agent = request.agent != 'implementation.md' or not request.service
            agent_to_use = request.agent
            agent_source = "default"

            # If service is provided, check for service-specific agent
            if request.service:
                print_info(f"Looking for service-specific agent for '{request.service}'")

                # Check if service has a specific implementation agent in registry
                service = self.registry.services.get_service(request.service)
                if service and service.impl_agent:
                    # Only use user's agent if they explicitly provided one (not default)
                    if user_provided_agent and request.agent != 'implementation.md':
                        print_info(f"Using user-provided agent override: {request.agent}")
                    else:
                        # First try to get service-specific agents
                        service_agents = self.registry.agents.get_agents_by_service(request.service)
                        service_agent = None

                        # Look for the impl_agent in service-specific agents
                        for agent in service_agents:
                            if agent.id == service.impl_agent:
                                service_agent = agent
                                break

                        # If not found in service-specific, try global agent
                        if not service_agent:
                            service_agent = self.registry.agents.get_agent(service.impl_agent)

                        if service_agent:
                            agent_to_use = service.impl_agent
                            agent_source = "service-registry"
                            print_success(f"Using service-configured agent: {agent_to_use}")
                        else:
                            print_warning(f"Service agent '{service.impl_agent}' not found, using default: {request.agent}")
                else:
                    if not user_provided_agent or request.agent == 'implementation.md':
                        print_info(f"No specific agent configured for service '{request.service}', using default: {request.agent}")
                    else:
                        print_info(f"No service agent configured, using user-provided: {request.agent}")

            # Load the agent template and download service agents to temp folder
            if agent_source == "service-registry" and request.service:
                # Use AgentsService to download all service agents to temp folder
                from ..agents.service import AgentsService
                agents_service = AgentsService()
                temp_agents_dir = agents_service.download_service_agents_to_temp(request.service)
                agent_file_path = temp_agents_dir / f"{agent_to_use}.md"

                if not agent_file_path.exists():
                    # Try global agent if service-specific not found
                    agent_content = self.registry.agents.get_agent_prompt(agent_to_use)
                    if agent_content:
                        agent_file_path.write_text(agent_content, encoding='utf-8')
                    else:
                        raise FileNotFoundError(f"Agent content not found for: {agent_to_use}")
            else:
                # Load from file system (original behavior)
                agent_file_path = Path(__file__).parent.parent.parent / "resources" / "agent_templates" / agent_to_use
                if not agent_file_path.exists():
                    # Try without extension
                    agent_file_path = Path(__file__).parent.parent.parent / "resources" / "agent_templates" / f"{agent_to_use}.md"

                if not agent_file_path.exists():
                    raise FileNotFoundError(f"Agent template not found: {agent_to_use}")

            # Build context for LLM using BaseService methods
            llm_context = {
                "command_type": "issue_implementation",
                "issue_id": request.issue_id,
                "issue_title": issue_data['title'],
                "repo_path": str(Path.cwd()),
                "service_name": request.service,
                "issue_number": issue_data['number'],
                "issue_body": issue_data['body'],
                "issue_url": issue_data['url']
            }

            # Use BaseService methods to build prompts
            llm_context["prompt"] = self.build_prompt("issue_implementation", llm_context, agent_file_path)
            llm_context["system_prompt"] = self._build_issue_system_prompt(llm_context, agent_file_path)

            # Execute with LLM manager
            llm_success = self.llm_manager.run_analysis(
                command_type="issue_implementation",
                context=llm_context,
                interactive=request.interactive
            )

            if llm_success:
                result.submitted_issue_id = request.issue_id
                result.success = True
                print_success(f"Issue {request.issue_id} submitted to Claude successfully")
            else:
                result.errors.append("Claude execution failed")

            result.execution_time_ms = (time.time() - start_time) * 1000
            return result

        except Exception as e:
            result.errors.append(str(e))
            result.execution_time_ms = (time.time() - start_time) * 1000
            print_error(f"Failed to submit issue to Claude: {str(e)}")
            return result

    def _get_repository_context(self, request: IssuesRequest) -> Optional[Dict[str, str]]:
        """Get repository context from service or current directory."""
        if request.service:
            # Remote mode - get from service registry
            service = self.registry.services.get_service(request.service)
            if not service:
                raise NotFoundError(f"Service '{request.service}' not found in registry")

            return self.github_provider.parse_github_repo(service.repo_url)
        else:
            # Local mode - get from current directory
            return self.github_provider.get_repo_info()

    def _build_fetch_command(self, request: IssuesRequest, repo_info: Dict[str, str]) -> List[str]:
        """Build GitHub CLI command for fetching issues."""
        command = [
            "issue", "list",
            "--repo", repo_info["full_name"],
            "--limit", str(min(request.limit, GITHUB_ISSUES_MAX_LIMIT)),
            "--state", request.state,
            "--json", "number,title,body,state,labels,assignees,milestone,createdAt,updatedAt,url,author"
        ]

        if request.label:
            command.extend(["--label", request.label])

        if request.assignee:
            command.extend(["--assignee", request.assignee])

        return command

    def _parse_issue_json(self, issue_json: Dict[str, Any]) -> IssueData:
        """Parse GitHub issue JSON to IssueData model."""
        return IssueData(
            number=issue_json["number"],
            title=issue_json["title"],
            body=issue_json.get("body", ""),
            state=issue_json["state"],
            labels=[label["name"] for label in issue_json.get("labels", [])],
            assignees=[assignee["login"] for assignee in issue_json.get("assignees", [])],
            milestone=issue_json.get("milestone", {}).get("title") if issue_json.get("milestone") else None,
            created_at=issue_json["createdAt"],
            updated_at=issue_json["updatedAt"],
            url=issue_json["url"],
            author=issue_json["author"]["login"],
            comments_count=issue_json.get("comments", 0),
            reactions=issue_json.get("reactions", {})
        )

    def _save_issues_locally(self, issues: List[IssueData], output_dir: Path, no_attachments: bool) -> int:
        """Save issues to local directory structure."""
        ensure_path_exists(output_dir)
        saved_count = 0

        for issue in issues:
            try:
                # Create issue directory
                issue_dir = output_dir / f"issue-{issue.number}"
                ensure_path_exists(issue_dir)

                # Save issue content as markdown
                issue_md_path = issue_dir / ISSUE_MD_FILENAME
                issue_content = self._format_issue_as_markdown(issue)
                issue_md_path.write_text(issue_content, encoding='utf-8')

                # Save metadata as YAML
                metadata_path = issue_dir / "metadata.yaml"
                metadata = {
                    "title": issue.title,
                    "number": issue.number,
                    "state": issue.state,
                    "labels": issue.labels,
                    "assignees": issue.assignees,
                    "milestone": issue.milestone,
                    "author": issue.author,
                    "created_at": issue.created_at,
                    "updated_at": issue.updated_at,
                    "url": issue.url
                }
                save_config_file(metadata_path, metadata, "yaml")

                # Download attachments if not disabled
                if not no_attachments and issue.body:
                    self._download_issue_attachments(issue, issue_dir)

                saved_count += 1

            except Exception as e:
                print_warning(f"Failed to save issue {issue.number}: {str(e)}")

        return saved_count

    def _format_issue_as_markdown(self, issue: IssueData) -> str:
        """Format issue as markdown."""
        content = f"# {issue.title}\n\n"
        content += f"**Issue #{issue.number}** - {issue.state.title()}\n\n"

        if issue.labels:
            content += f"**Labels:** {', '.join(issue.labels)}\n\n"

        if issue.assignees:
            content += f"**Assignees:** {', '.join(issue.assignees)}\n\n"

        if issue.milestone:
            content += f"**Milestone:** {issue.milestone}\n\n"

        content += f"**Author:** {issue.author}\n"
        content += f"**Created:** {issue.created_at}\n"
        content += f"**URL:** {issue.url}\n\n"

        content += "---\n\n"

        if issue.body:
            content += issue.body
        else:
            content += "*No description provided.*"

        return content

    def _load_issue_data(self, issue_dir: Path, request: IssuesRequest) -> tuple[IssueMetadata, str]:
        """Load issue metadata and content from directory."""
        # Load metadata
        metadata_path = issue_dir / "metadata.yaml"
        if metadata_path.exists():
            metadata_dict = load_config_file(metadata_path)
        else:
            metadata_dict = {}

        # Apply overrides from request
        if request.labels_override:
            metadata_dict["labels"] = [label.strip() for label in request.labels_override.split(",")]
        if request.assignees_override:
            metadata_dict["assignees"] = [assignee.strip() for assignee in request.assignees_override.split(",")]
        if request.milestone_override:
            metadata_dict["milestone"] = request.milestone_override

        # Ensure required fields
        if "title" not in metadata_dict:
            metadata_dict["title"] = f"Issue from {issue_dir.name}"

        metadata = IssueMetadata(**metadata_dict)

        # Load content
        issue_md_path = issue_dir / ISSUE_MD_FILENAME
        if issue_md_path.exists():
            content = issue_md_path.read_text(encoding='utf-8')
        else:
            content = "No content provided."

        return metadata, content

    def _create_github_issue(self, metadata: IssueMetadata, content: str, repo_info: Dict[str, str], draft: bool) -> Dict[str, Any]:
        """Create GitHub issue using CLI."""
        command = [
            "issue", "create",
            "--repo", repo_info["full_name"],
            "--title", metadata.title,
            "--body", content
        ]

        if metadata.labels:
            command.extend(["--label", ",".join(metadata.labels)])

        if metadata.assignees:
            command.extend(["--assignee", ",".join(metadata.assignees)])

        if metadata.milestone:
            command.extend(["--milestone", metadata.milestone])

        if draft:
            command.append("--draft")

        return self.github_provider.run_gh_command(command)

    def _extract_issue_url_from_output(self, output: str) -> Optional[str]:
        """Extract issue URL from GitHub CLI output."""
        # GitHub CLI typically returns the URL in the output
        lines = output.strip().split('\n')
        for line in lines:
            if 'github.com' in line and '/issues/' in line:
                return line.strip()
        return None

    def _build_submission_context(self, request: IssuesRequest) -> IssueSubmissionContext:
        """Build context for Claude submission."""
        context = IssueSubmissionContext(
            issue_id=request.issue_id,
            agent_name=Path(request.agent).stem,
            agent_file=request.agent,
            batch_mode=request.batch_mode,
            interactive=request.interactive
        )

        if request.service:
            # Remote mode
            service = self.registry.services.get_service(request.service)
            if service:
                context.service_name = service.name
                context.repo_url = service.repo_url
        else:
            # Local mode
            context.local_path = Path.cwd()

        return context

    def _select_issues_interactively(self, issues: List[IssueData], repo_name: str) -> List[IssueData]:
        """Interactive issue selection with table format."""
        import click
        from rich.table import Table

        # Display issues in clean table format
        console.print(f"\n[bold cyan]📋 Found {len(issues)} issues from {repo_name}:[/bold cyan]")

        table = Table(title="GitHub Issues", show_lines=True)
        table.add_column("Issue", style="cyan bold", width=8)
        table.add_column("Title", style="white", width=50)
        table.add_column("State", style="green", width=8)
        table.add_column("Labels", style="yellow", width=20)

        for issue in issues:
            labels = ', '.join(issue.labels[:2]) if issue.labels else "-"
            if len(issue.labels) > 2:
                labels += f" (+{len(issue.labels) - 2})"

            table.add_row(
                f"#{issue.number}",
                issue.title[:47] + "..." if len(issue.title) > 50 else issue.title,
                issue.state.title(),
                labels
            )

        console.print(table)

        console.print("\n[cyan]Enter issue IDs to download (e.g., '26,28'), or 'all' for all issues:[/cyan]")

        try:
            selection = click.prompt("Selection", default="")
        except (EOFError, KeyboardInterrupt):
            print_info("Selection cancelled")
            return []

        selection = selection.strip().lower()
        if not selection:
            return []
        if selection == 'all':
            return issues

        # Parse comma-separated issue IDs
        try:
            # Handle both with and without # prefix
            issue_ids = []
            for item in selection.split(','):
                item = item.strip().replace('#', '')
                if item:
                    issue_ids.append(int(item))

            selected_issues = []
            for issue_id in issue_ids:
                found = False
                for issue in issues:
                    if issue.number == issue_id:
                        selected_issues.append(issue)
                        found = True
                        break
                if not found:
                    available_ids = [str(issue.number) for issue in issues]
                    print_error(f"Issue #{issue_id} not found. Available issues: {', '.join(available_ids)}")
                    return []

            console.print(f"[green]✓[/green] Selected {len(selected_issues)} issue(s):")
            for issue in selected_issues:
                console.print(f"  [cyan]#{issue.number}[/cyan] - {issue.title}")
            console.print()

            return selected_issues
        except ValueError:
            print_error("Invalid format. Please enter issue IDs separated by commas (e.g., '26,28').")
            return []


    def _build_issue_system_prompt(self, context: Dict[str, Any], agent_file_path: Path) -> str:
        """Build system prompt for issue implementation including issue details.

        Args:
            context: Context dictionary with issue details
            agent_file_path: Path to the main agent file

        Returns:
            Complete system prompt with issue context
        """
        # Use BaseService method as base
        base_prompt = self.build_system_prompt("issue_implementation", context, agent_file_path)

        # Add issue-specific context
        issue_context = f"""

GITHUB ISSUE TO IMPLEMENT:
Issue #{context['issue_number']}: {context['issue_title']}

{context['issue_body']}

URL: {context['issue_url']}

ADDITIONAL CONTEXT:
- All sub-agents for this service are available in the same directory as the main agent
- You can reference other agent files by their filename (e.g., testing.md, deployment.md)
- Execute all sub-agents mentioned in the main agent in the specified order
"""

        return base_prompt + issue_context

    def _download_issue_attachments(self, issue: IssueData, issue_dir: Path) -> None:
        """Download attachments from GitHub issue body using GitHub CLI for authentication."""
        import re
        import subprocess
        from urllib.parse import urlparse

        if not issue.body:
            return

        # Create attachments directory
        attachments_dir = issue_dir / "attatchment"
        ensure_path_exists(attachments_dir)

        # Patterns for GitHub attachments and images
        patterns = [
            # File attachments: [filename](https://github.com/user-attachments/files/...)
            r'\[([^\]]+)\]\((https://github\.com/user-attachments/files/[^)]+)\)',
            # Images: <img ... src="https://github.com/user-attachments/assets/..." alt="..." />
            r'<img[^>]+src="(https://github\.com/user-attachments/assets/[^"]+)"[^>]*(?:alt="([^"]*)")?[^>]*/>',
            # Simple image links: ![alt](https://github.com/user-attachments/assets/...)
            r'!\[([^\]]*)\]\((https://github\.com/user-attachments/assets/[^)]+)\)'
        ]

        downloaded_count = 0

        for pattern in patterns:
            matches = re.findall(pattern, issue.body)

            for match in matches:
                try:
                    # Handle different regex match patterns
                    if isinstance(match, tuple):
                        if len(match) == 2:
                            # Two groups: could be (filename, url) or (url, alt)
                            if 'user-attachments' in match[0]:
                                # Pattern: (url, alt) from img tag
                                url = match[0]
                                potential_filename = match[1] if match[1] else ""
                            else:
                                # Pattern: (filename, url) from [filename](url)
                                potential_filename = match[0]
                                url = match[1]
                        else:
                            # Single group or more complex pattern
                            url = match[0]
                            potential_filename = ""
                    else:
                        # Single string match
                        url = match
                        potential_filename = ""

                    # Generate a proper filename
                    if potential_filename and potential_filename.strip():
                        filename = potential_filename.strip()
                    else:
                        # Extract from URL or generate generic name
                        parsed_url = urlparse(url)
                        url_path = parsed_url.path.split('/')[-1]
                        if url_path and url_path != url and len(url_path) > 0:
                            filename = url_path
                        else:
                            filename = f"attachment_{downloaded_count + 1}"

                    # Clean filename and ensure it's valid
                    filename = re.sub(r'[<>:"/\\|?*]', '_', str(filename).strip())
                    if not filename or len(filename.strip()) == 0:
                        filename = f"attachment_{downloaded_count + 1}"

                    # Add extension if missing for images from GitHub assets
                    if 'user-attachments/assets' in url and '.' not in filename:
                        filename += '.png'  # Default to PNG for GitHub assets

                    file_path = attachments_dir / filename

                    # Download using GitHub CLI with authentication
                    print_info(f"Downloading attachment: {filename}")

                    # Get GitHub auth token first
                    token_result = subprocess.run(['gh', 'auth', 'token'],
                                                capture_output=True, text=True, timeout=10)

                    if token_result.returncode == 0:
                        token = token_result.stdout.strip()

                        # Use curl with GitHub token for authenticated download
                        curl_result = subprocess.run([
                            'curl', '-L', '-H', f'Authorization: token {token}',
                            '-o', str(file_path), url
                        ], capture_output=True, text=True, timeout=30)

                        if curl_result.returncode == 0:
                            downloaded_count += 1
                        else:
                            raise Exception(f"Download failed: {curl_result.stderr}")
                    else:
                        raise Exception("Failed to get GitHub auth token")

                except Exception as e:
                    print_warning(f"Failed to download attachment {url}: {str(e)}")
                    continue

        if downloaded_count > 0:
            print_success(f"Downloaded {downloaded_count} attachments for issue #{issue.number}")
        else:
            # Remove empty attachments directory
            try:
                attachments_dir.rmdir()
            except OSError:
                pass