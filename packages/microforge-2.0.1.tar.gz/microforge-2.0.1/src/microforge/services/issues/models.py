"""
Issues service models for Microforge v2.

Data models for GitHub issues operations.
"""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from pathlib import Path


class IssueData(BaseModel):
    """Model for GitHub issue data."""

    number: int = Field(description="Issue number")
    title: str = Field(description="Issue title")
    body: Optional[str] = Field(default="", description="Issue body/description")
    state: str = Field(description="Issue state (open, closed)")
    labels: List[str] = Field(default_factory=list, description="Issue labels")
    assignees: List[str] = Field(default_factory=list, description="Issue assignees")
    milestone: Optional[str] = Field(default=None, description="Issue milestone")
    created_at: str = Field(description="Creation timestamp")
    updated_at: str = Field(description="Last update timestamp")
    url: str = Field(description="Issue URL")
    author: str = Field(description="Issue author")

    # Additional metadata
    comments_count: int = Field(default=0, description="Number of comments")
    reactions: Dict[str, int] = Field(default_factory=dict, description="Issue reactions")


class IssuesRequest(BaseModel):
    """Request model for issues operations."""

    # Common fields
    service: Optional[str] = Field(default=None, description="Service name for remote mode")
    output_dir: Path = Field(default=Path("./issues"), description="Output directory for issues")

    # Fetch operation fields
    state: str = Field(default="open", description="Issue state filter")
    label: Optional[str] = Field(default=None, description="Label filter")
    assignee: Optional[str] = Field(default=None, description="Assignee filter")
    number: Optional[int] = Field(default=None, description="Specific issue number")
    fetch_all: bool = Field(default=False, description="Fetch all issues without selection")
    limit: int = Field(default=100, description="Maximum issues to fetch")
    no_attachments: bool = Field(default=False, description="Skip downloading attachments")

    # Create operation fields
    issue_dir: Optional[Path] = Field(default=None, description="Issue directory for creation")
    draft: bool = Field(default=False, description="Create as draft issue")
    labels_override: Optional[str] = Field(default=None, description="Labels override")
    assignees_override: Optional[str] = Field(default=None, description="Assignees override")
    milestone_override: Optional[str] = Field(default=None, description="Milestone override")

    # Submit operation fields
    issue_id: Optional[str] = Field(default=None, description="Issue ID for submission")
    agent: Optional[str] = Field(default=None, description="Agent file path")
    batch_mode: bool = Field(default=False, description="Run Claude in batch mode")
    interactive: bool = Field(default=True, description="Run Claude interactively")


class IssuesResult(BaseModel):
    """Result model for issues operations."""

    success: bool = Field(description="Whether operation completed successfully")
    operation: str = Field(description="Operation type (fetch, create, submit)")
    issues: List[IssueData] = Field(default_factory=list, description="Issues data")
    created_files: List[str] = Field(default_factory=list, description="Created files")
    downloaded_count: int = Field(default=0, description="Number of issues downloaded")
    created_issue_url: Optional[str] = Field(default=None, description="URL of created issue")
    submitted_issue_id: Optional[str] = Field(default=None, description="ID of submitted issue")
    errors: List[str] = Field(default_factory=list, description="Errors encountered")
    warnings: List[str] = Field(default_factory=list, description="Warnings")
    execution_time_ms: float = Field(default=0.0, description="Execution time in milliseconds")

    @property
    def has_errors(self) -> bool:
        """Check if there were any errors."""
        return len(self.errors) > 0

    @property
    def has_warnings(self) -> bool:
        """Check if there were any warnings."""
        return len(self.warnings) > 0


class IssueMetadata(BaseModel):
    """Model for issue metadata.yaml files."""

    title: str = Field(description="Issue title")
    labels: List[str] = Field(default_factory=list, description="Issue labels")
    assignees: List[str] = Field(default_factory=list, description="Issue assignees")
    milestone: Optional[str] = Field(default=None, description="Issue milestone")
    description: Optional[str] = Field(default=None, description="Issue description")

    # Additional metadata
    service: Optional[str] = Field(default=None, description="Related service")
    priority: Optional[str] = Field(default=None, description="Issue priority")
    type: Optional[str] = Field(default=None, description="Issue type")


class IssueSubmissionContext(BaseModel):
    """Model for issue submission context."""

    issue_id: str = Field(description="Issue ID")
    agent_name: str = Field(description="Agent name")
    agent_file: str = Field(description="Agent file path")
    service_name: Optional[str] = Field(default=None, description="Service name")
    repo_url: Optional[str] = Field(default=None, description="Repository URL")
    local_path: Optional[Path] = Field(default=None, description="Local repository path")
    batch_mode: bool = Field(default=False, description="Batch mode flag")
    interactive: bool = Field(default=True, description="Interactive mode flag")