"""
Centralized constants for Microforge v2.

ALL constants, hardcoded values, paths, and configuration values are defined here.
NO hardcoded strings or magic numbers are allowed anywhere else in the codebase.
"""

import os
import tempfile
from pathlib import Path

# =============================================================================
# APPLICATION METADATA
# =============================================================================

APP_NAME = "microforge"
APP_VERSION = "2.0.1"
APP_DESCRIPTION = "AI-enhanced Python microservice platform"
APP_AUTHOR = "Microforge Team"

# =============================================================================
# PACKAGE AND PATH DETECTION
# =============================================================================

def get_package_dir() -> Path:
    """Get the Microforge v2 package directory (works in any environment)."""
    try:
        import microforge_v2
        return Path(microforge_v2.__file__).parent
    except ImportError:
        # Fallback for development
        return Path(__file__).parent.parent

# Package directories
PACKAGE_DIR = get_package_dir()
OLD_PACKAGE_DIR = PACKAGE_DIR.parent / "microforge"  # Reference to old structure

# =============================================================================
# USER DATA PATHS
# =============================================================================

# Shared across environments - stores user preferences & registrations
MICROFORGE_HOME = Path.home() / ".microforge"
MICROFORGE_CONFIG = MICROFORGE_HOME / "config.json"
MICROFORGE_WORKSPACE = MICROFORGE_HOME / "workspace"
MICROFORGE_SERVICES_JSON = MICROFORGE_HOME / "services.json"

# Environment-specific paths
VERSION_INFO_FILE = MICROFORGE_HOME / "version_info.json"

# Temporary directory
TEMP_DIR = Path(tempfile.gettempdir())

# Agent execution temporary directories
TEMP_AGENTS_DIR_PREFIX = "microforge_agents_"
TEMP_AGENTS_CLEANUP_ON_ERROR = True

# =============================================================================
# PROJECT-LEVEL PATHS
# =============================================================================

# Project configuration
MICROFORGE_PROJECT_DIR = Path(".microforge")
MICROFORGE_PROJECT_CONFIG = MICROFORGE_PROJECT_DIR / "config.yaml"
MICROFORGE_PROJECT_HOOKS_DIR = MICROFORGE_PROJECT_DIR / "hooks"

# Documentation directories
DOCS_DIR = Path("docs")
DOCS_SERVICE_DIR = DOCS_DIR / "service"
DOCS_PLANNING_DIR = DOCS_DIR / "planning"

# Issues directory
ISSUES_DIR = Path("issues")

# =============================================================================
# NETWORK CONFIGURATION
# =============================================================================

# MCP Server
DEFAULT_MCP_HOST = "0.0.0.1"
DEFAULT_MCP_PORT = 3333

# Web UI
DEFAULT_WEB_HOST = "127.0.0.1"
DEFAULT_WEB_PORT = 8000
DEFAULT_WEB_BIND = "0.0.0.0"

# API Configuration
API_VERSION = "v1"
API_BASE_PATH = f"/api/{API_VERSION}"

# =============================================================================
# LLM CONFIGURATION
# =============================================================================

# LLM CLI executable names
CLAUDE_CLI_EXECUTABLE = "claude"
CURSOR_CLI_EXECUTABLE = "cursor"
OPENAI_CLI_EXECUTABLE = "openai"

# LLM tool configurations
LLM_DEFAULT_TOOLS = [
    "Read", "Write", "Edit", "MultiEdit", "Bash", "Glob", "Grep", "WebSearch"
]

LLM_ANALYSIS_TOOLS = [
    "Read", "Write", "Edit", "MultiEdit", "Bash", "Glob", "Grep"
]

# LLM timeouts (seconds)
LLM_DEFAULT_TIMEOUT = 3600  # 1 hour
LLM_BATCH_TIMEOUT = 3600    # 1 hour

# Legacy Claude constants (backwards compatibility)
CLAUDE_DEFAULT_TOOLS = LLM_DEFAULT_TOOLS
CLAUDE_ANALYSIS_TOOLS = LLM_ANALYSIS_TOOLS
CLAUDE_DEFAULT_TIMEOUT = LLM_DEFAULT_TIMEOUT
CLAUDE_BATCH_TIMEOUT = LLM_BATCH_TIMEOUT

# =============================================================================
# GIT AND GITHUB CONFIGURATION
# =============================================================================

# Git operations
GIT_DEFAULT_TIMEOUT = 30
GIT_CLONE_TIMEOUT = 120
GIT_PUSH_TIMEOUT = 60
GIT_TIMEOUT_SECONDS = 300
GIT_CLONE_DEPTH = 20

# Temporary file settings
TEMP_PREFIX = "microforge_"

# GitHub CLI
GITHUB_CLI_EXECUTABLE = "gh"
GITHUB_API_VERSION = "2022-11-28"

# GitHub issue states
GITHUB_ISSUE_STATE_OPEN = "open"
GITHUB_ISSUE_STATE_CLOSED = "closed"
GITHUB_ISSUE_STATE_ALL = "all"

# GitHub issue download limits
GITHUB_ISSUES_DEFAULT_LIMIT = 50
GITHUB_ISSUES_MAX_LIMIT = 100

# =============================================================================
# STORAGE CONFIGURATION
# =============================================================================

# Storage provider (AZURE, AWS, GCP, LOCAL)
# Set via environment: export MICROFORGE_STORAGE_PROVIDER=LOCAL (to use local storage)
STORAGE_PROVIDER = os.getenv("MICROFORGE_STORAGE_PROVIDER", "AZURE")

# Azure Storage Configuration
# Connection string format: DefaultEndpointsProtocol=https;AccountName=<name>;AccountKey=<key>;EndpointSuffix=core.windows.net
# Set via environment: export AZURE_STORAGE_CONNECTION_STRING="<connection-string>"
# Hardcoded for development/testing (TODO: Move to secure vault in production)
AZURE_STORAGE_CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING",
    "DefaultEndpointsProtocol=https;AccountName=sanonprodtopiq;AccountKey=l+BxrZHIKsOs+TEcZzQ1gKPRyNJd9ieHEc4L6jERB/p/YtQ2F1p9KMslpYRn405dUPCfHRNO4rHK+AStZskG4A==;EndpointSuffix=core.windows.net")

# Storage container/bucket name (used by Azure, AWS, GCP)
# For Azure: This is the blob container name# Set via environment: export AZURE_STORAGE_CONTAINER=microforge-agents
DEFAULT_STORAGE_CONTAINER = os.getenv("AZURE_STORAGE_CONTAINER", "microforge-agents")

# Local storage paths
LOCAL_STORAGE_BASE = MICROFORGE_HOME / "storage"

# Storage cache configuration
STORAGE_CACHE_DIR = MICROFORGE_HOME / "storage_cache"
STORAGE_CACHE_TTL_HOURS = 24

# =============================================================================
# FILE SYSTEM PATHS AND NAMES
# =============================================================================

# Resource subdirectories (relative to package root)
AGENTS_SUBDIR = "resources/agent_templates"
HOOKS_SUBDIR = "resources/hook_templates"
SCHEMAS_SUBDIR = "resources/schemas"

# File extensions
YAML_EXTENSIONS = [".yaml", ".yml"]
JSON_EXTENSIONS = [".json"]
MARKDOWN_EXTENSIONS = [".md", ".markdown"]

# Configuration filenames
CONFIG_YAML_FILENAME = "config.yaml"
SERVICES_JSON_FILENAME = "services.json"
METADATA_YAML_FILENAME = "metadata.yaml"
ISSUE_MD_FILENAME = "issue.md"
CLAUDE_MD_FILENAME = "CLAUDE.md"

# Directory names
ATTACHMENTS_DIR_NAME = "attachments"
TEMPLATES_DIR_NAME = "templates"
STATIC_DIR_NAME = "static"

# =============================================================================
# AGENT TEMPLATE FILES
# =============================================================================

# Agent template dictionary
AGENTS = {
    "base_orchestrator": "base_orchestrator.md",
    "documentation": "documentation.md",
    "dependency_graph": "dependency_graph.md",
    "audit_report": "audit_report.md",
    "security": "security.md",
    "performance": "performance.md",
    "implementation": "implementation.md",
    "refactoring": "refactoring.md",
    "test_generator": "test_generator.md"
}

# Legacy agent constants (backwards compatibility)
AGENT_BASE_ORCHESTRATOR = AGENTS["base_orchestrator"]
AGENT_DOCUMENTATION = AGENTS["documentation"]
AGENT_DEPENDENCY_GRAPH = AGENTS["dependency_graph"]
AGENT_AUDIT_REPORT = AGENTS["audit_report"]
AGENT_SECURITY = AGENTS["security"]
AGENT_PERFORMANCE = AGENTS["performance"]
AGENT_IMPLEMENTATION = AGENTS["implementation"]
AGENT_REFACTORING = AGENTS["refactoring"]
AGENT_TEST_GENERATOR = AGENTS["test_generator"]

# Hook template filenames
HOOK_PLANNING_PRE = "planning_pre_hook.md"
HOOK_CODE_QUALITY = "code_quality_hook.md"
HOOK_README = "README.md"

# =============================================================================
# AUDIT AND LOGGING CONFIGURATION
# =============================================================================

# Audit log configuration
AUDIT_LOG_FORMAT = "jsonl"
AUDIT_LOG_FILENAME = "audit.jsonl"
AUDIT_LOG_MAX_SIZE_MB = 100
AUDIT_LOG_ROTATION_COUNT = 5

# Log levels
LOG_LEVEL_DEBUG = "DEBUG"
LOG_LEVEL_INFO = "INFO"
LOG_LEVEL_WARNING = "WARNING"
LOG_LEVEL_ERROR = "ERROR"
LOG_LEVEL_CRITICAL = "CRITICAL"

# Session tracking
SESSION_ID_LENGTH = 32
SESSION_TIMEOUT_MINUTES = 60

# =============================================================================
# CONSOLE FORMATTING
# =============================================================================

# Emoji constants
SUCCESS_EMOJI = "✅"
ERROR_EMOJI = "❌"
WARNING_EMOJI = "⚠️"
INFO_EMOJI = "ℹ️"
ROCKET_EMOJI = "🚀"
ROBOT_EMOJI = "🤖"
HOOK_EMOJI = "🎯"
GEAR_EMOJI = "⚙️"
FOLDER_EMOJI = "📁"
FILE_EMOJI = "📄"
LINK_EMOJI = "🔗"
CLOCK_EMOJI = "⏰"

# Rich console colors
COLOR_SUCCESS = "green"
COLOR_ERROR = "red"
COLOR_WARNING = "yellow"
COLOR_INFO = "blue"
COLOR_DIM = "dim"
COLOR_BOLD = "bold"
COLOR_CYAN = "cyan"

# =============================================================================
# ERROR MESSAGES
# =============================================================================

# Organized error messages
ERRORS = {
    "git": {
        "not_repo": "Current directory is not a git repository",
        "command_failed": "Git command failed",
        "github_cli_not_found": "GitHub CLI not found. Please install with: brew install gh",
        "github_auth_required": "GitHub authentication required. Run: gh auth login"
    },
    "llm": {
        "claude_not_found": "Claude CLI not found. Please install with: npm install -g @anthropic-ai/claude",
        "execution_failed": "LLM execution failed",
        "timeout": "LLM execution timed out"
    },
    "fs": {
        "file_not_found": "File not found",
        "directory_not_found": "Directory not found",
        "permission_denied": "Permission denied",
        "invalid_path": "Invalid file path"
    },
    "config": {
        "invalid": "Invalid configuration",
        "not_found": "Configuration file not found",
        "parse_error": "Configuration parsing error"
    },
    "service": {
        "not_found": "Service not found in registry",
        "already_exists": "Service already exists in registry",
        "invalid_name": "Invalid service name",
        "invalid_repo_url": "Invalid repository URL"
    }
}

# Legacy error constants (backwards compatibility)
ERROR_NOT_GIT_REPO = ERRORS["git"]["not_repo"]
ERROR_GIT_COMMAND_FAILED = ERRORS["git"]["command_failed"]
ERROR_GITHUB_CLI_NOT_FOUND = ERRORS["git"]["github_cli_not_found"]
ERROR_GITHUB_AUTH_REQUIRED = ERRORS["git"]["github_auth_required"]
ERROR_CLAUDE_CLI_NOT_FOUND = ERRORS["llm"]["claude_not_found"]
ERROR_CLAUDE_EXECUTION_FAILED = ERRORS["llm"]["execution_failed"]
ERROR_CLAUDE_TIMEOUT = ERRORS["llm"]["timeout"]
ERROR_FILE_NOT_FOUND = ERRORS["fs"]["file_not_found"]
ERROR_DIRECTORY_NOT_FOUND = ERRORS["fs"]["directory_not_found"]
ERROR_PERMISSION_DENIED = ERRORS["fs"]["permission_denied"]
ERROR_INVALID_PATH = ERRORS["fs"]["invalid_path"]
ERROR_CONFIG_INVALID = ERRORS["config"]["invalid"]
ERROR_CONFIG_NOT_FOUND = ERRORS["config"]["not_found"]
ERROR_CONFIG_PARSE_ERROR = ERRORS["config"]["parse_error"]
ERROR_SERVICE_NOT_FOUND = ERRORS["service"]["not_found"]
ERROR_SERVICE_ALREADY_EXISTS = ERRORS["service"]["already_exists"]
ERROR_INVALID_SERVICE_NAME = ERRORS["service"]["invalid_name"]
ERROR_INVALID_REPO_URL = ERRORS["service"]["invalid_repo_url"]

# =============================================================================
# SUCCESS MESSAGES
# =============================================================================

# Organized success messages
SUCCESS = {
    "analysis_completed": "Analysis completed successfully",
    "hooks_initialized": "Hooks initialized successfully",
    "service_added": "Service added to registry",
    "service_removed": "Service removed from registry",
    "config_updated": "Configuration updated",
    "directory_created": "Directory created",
    "file_created": "File created",
    "clone_completed": "Repository cloned successfully",
    "push_completed": "Changes pushed successfully"
}

# Legacy success constants (backwards compatibility)
SUCCESS_ANALYSIS_COMPLETED = SUCCESS["analysis_completed"]
SUCCESS_HOOKS_INITIALIZED = SUCCESS["hooks_initialized"]
SUCCESS_SERVICE_ADDED = SUCCESS["service_added"]
SUCCESS_SERVICE_REMOVED = SUCCESS["service_removed"]
SUCCESS_CONFIG_UPDATED = SUCCESS["config_updated"]
SUCCESS_DIRECTORY_CREATED = SUCCESS["directory_created"]
SUCCESS_FILE_CREATED = SUCCESS["file_created"]
SUCCESS_CLONE_COMPLETED = SUCCESS["clone_completed"]
SUCCESS_PUSH_COMPLETED = SUCCESS["push_completed"]

# =============================================================================
# VALIDATION PATTERNS
# =============================================================================

# GitHub URL patterns
GITHUB_URL_PATTERN = r"https://github\.com/([^/]+)/([^/]+)(?:\.git)?/?$"
GITHUB_SSH_PATTERN = r"git@github\.com:([^/]+)/([^/]+)(?:\.git)?$"

# Service name validation
SERVICE_NAME_PATTERN = r"^[a-z0-9-_]+$"
SERVICE_NAME_MIN_LENGTH = 3
SERVICE_NAME_MAX_LENGTH = 50

# File name validation
FILENAME_INVALID_CHARS = ['<', '>', ':', '"', '|', '?', '*', '\\', '/']

# =============================================================================
# SUBPROCESS EXECUTION
# =============================================================================

# Default subprocess settings
SUBPROCESS_DEFAULT_TIMEOUT = 30
SUBPROCESS_ENCODING = "utf-8"
SUBPROCESS_ERRORS = "replace"

# Shell command timeouts
SHELL_COMMAND_TIMEOUT = 30
SHELL_LONG_COMMAND_TIMEOUT = 300

# =============================================================================
# HOOKS SYSTEM CONFIGURATION
# =============================================================================

# Hooks system version
HOOKS_VERSION = "1.0.0"

# Hook types
HOOK_TYPE_PRE = "pre"
HOOK_TYPE_POST = "post"

# Hook events
HOOK_EVENT_ANALYZE = "analyze"
HOOK_EVENT_AUDIT = "audit"
HOOK_EVENT_SETUP = "setup"
HOOK_EVENT_COMMIT = "commit"

# Hook status
HOOK_STATUS_ENABLED = "enabled"
HOOK_STATUS_DISABLED = "disabled"

# =============================================================================
# API AND MCP CONFIGURATION
# =============================================================================

# API response formats
API_FORMAT_JSON = "json"
API_FORMAT_YAML = "yaml"
API_FORMAT_TEXT = "text"

# MCP protocol constants
MCP_PROTOCOL_VERSION = "1.0"
MCP_MESSAGE_TYPES = ["request", "response", "notification"]

# =============================================================================
# DATABASE AND STORAGE
# =============================================================================

# TinyDB configuration
TINYDB_DEFAULT_FILENAME = "microforge.json"
TINYDB_INDENT = 2

# Storage backends
STORAGE_BACKEND_FILE = "file"
STORAGE_BACKEND_TINYDB = "tinydb"
STORAGE_BACKEND_MEMORY = "memory"

# =============================================================================
# TESTING AND DEVELOPMENT
# =============================================================================

# Test configuration
TEST_TIMEOUT = 60
TEST_SLOW_TIMEOUT = 300
TEST_DATA_DIR = "test_data"

# Development flags
DEV_MODE_ENV_VAR = "MICROFORGE_DEV_MODE"
DEBUG_ENV_VAR = "MICROFORGE_DEBUG"

# Mock data
MOCK_SERVICE_NAME = "test-service"
MOCK_REPO_URL = "https://github.com/test/test-repo.git"
MOCK_ISSUE_NUMBER = 123