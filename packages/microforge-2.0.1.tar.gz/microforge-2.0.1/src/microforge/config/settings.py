"""
Pydantic-based settings configuration for Microforge v2.

Replaces the old config_manager.py with a more robust, type-safe approach.
"""

import os
from pathlib import Path
from typing import Dict, Any, Optional, List
try:
    from pydantic_settings import BaseSettings
    from pydantic import Field, validator
except ImportError:
    # Fallback for older pydantic versions
    from pydantic import BaseSettings, Field, validator

from .constants import (
    APP_VERSION,
    MICROFORGE_HOME,
    MICROFORGE_CONFIG,
    MICROFORGE_WORKSPACE,
    DEFAULT_MCP_HOST,
    DEFAULT_MCP_PORT,
    DEFAULT_WEB_HOST,
    DEFAULT_WEB_PORT,
    CLAUDE_DEFAULT_TIMEOUT,
    GIT_DEFAULT_TIMEOUT,
    LOG_LEVEL_INFO,
    HOOKS_VERSION,
    STORAGE_PROVIDER,
    DEFAULT_STORAGE_CONTAINER,
    STORAGE_CACHE_DIR,
    STORAGE_CACHE_TTL_HOURS,
)


class DatabaseSettings(BaseSettings):
    """Database configuration settings."""

    backend: str = Field(default="tinydb", description="Storage backend type")
    filename: str = Field(default="microforge.json", description="Database filename")
    indent: int = Field(default=2, description="JSON indentation")

    class Config:
        env_prefix = "MICROFORGE_DB_"
        extra = "allow"


class StorageSettings(BaseSettings):
    """Storage provider configuration settings."""

    provider: str = Field(default=STORAGE_PROVIDER, description="Storage provider (LOCAL, AZURE, AWS, GCP)")
    container: str = Field(default=DEFAULT_STORAGE_CONTAINER, description="Storage container/bucket name")
    cache_dir: Path = Field(default=STORAGE_CACHE_DIR, description="Local cache directory")
    cache_ttl_hours: int = Field(default=STORAGE_CACHE_TTL_HOURS, description="Cache TTL in hours")

    class Config:
        env_prefix = "MICROFORGE_STORAGE_"
        extra = "allow"


class LLMSettings(BaseSettings):
    """LLM provider configuration settings."""

    provider: str = Field(default="claude", description="Default LLM provider")
    model: str = Field(default="claude-3-5-sonnet-20241022", description="LLM model name")
    temperature: float = Field(default=0.7, description="LLM temperature")
    max_tokens: int = Field(default=4096, description="Maximum tokens")
    claude_executable: str = Field(default="claude", description="Claude CLI executable")
    timeout_seconds: int = Field(default=CLAUDE_DEFAULT_TIMEOUT, description="LLM operation timeout")
    batch_mode: bool = Field(default=False, description="Run LLM in batch mode")
    tools: List[str] = Field(
        default=["Read", "Write", "Edit", "MultiEdit", "Bash", "Glob", "Grep", "WebSearch"],
        description="Default tools for LLM"
    )

    class Config:
        env_prefix = "MICROFORGE_LLM_"
        extra = "allow"


class GitSettings(BaseSettings):
    """Git and version control settings."""

    timeout: int = Field(default=GIT_DEFAULT_TIMEOUT, description="Git operation timeout")
    clone_timeout: int = Field(default=120, description="Git clone timeout")
    push_timeout: int = Field(default=60, description="Git push timeout")
    default_branch: str = Field(default="main", description="Default branch name")

    class Config:
        env_prefix = "MICROFORGE_GIT_"
        extra = "allow"


class GitHubSettings(BaseSettings):
    """GitHub integration settings."""

    cli_executable: str = Field(default="gh", description="GitHub CLI executable")
    api_version: str = Field(default="2022-11-28", description="GitHub API version")
    issues_limit: int = Field(default=50, description="Default issues fetch limit")
    max_issues_limit: int = Field(default=100, description="Maximum issues fetch limit")

    class Config:
        env_prefix = "MICROFORGE_GITHUB_"
        extra = "allow"


class WebSettings(BaseSettings):
    """Web UI and API settings."""

    host: str = Field(default=DEFAULT_WEB_HOST, description="Web server host")
    port: int = Field(default=DEFAULT_WEB_PORT, description="Web server port")
    bind: str = Field(default="0.0.0.0", description="Web server bind address")
    api_version: str = Field(default="v1", description="API version")

    class Config:
        env_prefix = "MICROFORGE_WEB_"
        extra = "allow"


class MCPSettings(BaseSettings):
    """Model Context Protocol settings."""

    host: str = Field(default=DEFAULT_MCP_HOST, description="MCP server host")
    port: int = Field(default=DEFAULT_MCP_PORT, description="MCP server port")
    protocol_version: str = Field(default="1.0", description="MCP protocol version")

    class Config:
        env_prefix = "MICROFORGE_MCP_"
        extra = "allow"


class RegistriesSettings(BaseSettings):
    """Registry system settings."""

    refresh_interval_seconds: float = Field(default=5.0, description="Registry refresh interval")
    cache_ttl_seconds: int = Field(default=300, description="Cache TTL in seconds")

    class Config:
        env_prefix = "MICROFORGE_REGISTRIES_"
        extra = "allow"


class HooksSettings(BaseSettings):
    """AI hooks system settings."""

    enabled: bool = Field(default=True, description="Enable hooks system")
    version: str = Field(default=HOOKS_VERSION, description="Hooks system version")
    auto_create_plan: bool = Field(default=True, description="Auto-create implementation plans")
    plan_directory: str = Field(default="docs/planning", description="Planning directory")
    update_on_progress: bool = Field(default=True, description="Update plans on progress")
    require_tests: bool = Field(default=True, description="Require tests for changes")
    require_docs: bool = Field(default=True, description="Require documentation")
    require_docstrings: bool = Field(default=True, description="Require docstrings")
    min_coverage: int = Field(default=80, description="Minimum test coverage")

    class Config:
        env_prefix = "MICROFORGE_HOOKS_"
        extra = "allow"


class LoggingSettings(BaseSettings):
    """Logging configuration settings."""

    level: str = Field(default=LOG_LEVEL_INFO, description="Log level")
    format: str = Field(default="jsonl", description="Log format")
    filename: str = Field(default="audit.jsonl", description="Log filename")
    max_size_mb: int = Field(default=100, description="Maximum log file size in MB")
    rotation_count: int = Field(default=5, description="Number of rotated log files")

    class Config:
        env_prefix = "MICROFORGE_LOG_"
        extra = "allow"


class MicroforgeSettings(BaseSettings):
    """Main Microforge configuration settings."""

    # Application info
    version: str = Field(default=APP_VERSION, description="Application version")
    debug: bool = Field(default=False, description="Enable debug mode")
    dev_mode: bool = Field(default=False, description="Enable development mode")

    # Paths
    home_dir: Path = Field(default=MICROFORGE_HOME, description="Microforge home directory")
    workspace_dir: Path = Field(default=MICROFORGE_WORKSPACE, description="Workspace directory")
    config_file: Path = Field(default=MICROFORGE_CONFIG, description="Configuration file path")

    # Sub-configurations
    database: DatabaseSettings = Field(default_factory=DatabaseSettings)
    storage: StorageSettings = Field(default_factory=StorageSettings)
    llm: LLMSettings = Field(default_factory=LLMSettings)
    git: GitSettings = Field(default_factory=GitSettings)
    github: GitHubSettings = Field(default_factory=GitHubSettings)
    web: WebSettings = Field(default_factory=WebSettings)
    mcp: MCPSettings = Field(default_factory=MCPSettings)
    registries: RegistriesSettings = Field(default_factory=RegistriesSettings)
    hooks: HooksSettings = Field(default_factory=HooksSettings)
    logging: LoggingSettings = Field(default_factory=LoggingSettings)

    # Legacy compatibility
    organization_services: Dict[str, Any] = Field(default_factory=dict, description="Legacy service data")
    agents: Dict[str, Any] = Field(default_factory=dict, description="Agent configurations")

    class Config:
        env_prefix = "MICROFORGE_"
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False
        extra = "allow"  # Allow extra fields for backward compatibility

    @validator("home_dir", "workspace_dir", pre=True)
    def ensure_path_exists(cls, v):
        """Ensure directories exist."""
        if isinstance(v, str):
            v = Path(v)
        v.mkdir(parents=True, exist_ok=True)
        return v

    def save_to_file(self, config_path: Optional[Path] = None) -> None:
        """Save configuration to file."""
        if config_path is None:
            config_path = self.config_file

        config_path.parent.mkdir(parents=True, exist_ok=True)

        # Convert to dict and save as JSON for backward compatibility
        import json
        config_dict = self.dict()

        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(config_dict, f, indent=2, default=str)

    @classmethod
    def load_from_file(cls, config_path: Optional[Path] = None) -> "MicroforgeSettings":
        """Load configuration from file."""
        if config_path is None:
            config_path = MICROFORGE_CONFIG

        if not config_path.exists():
            # Create default configuration
            settings = cls()
            settings.save_to_file(config_path)
            return settings

        # Load from file
        import json
        with open(config_path, 'r', encoding='utf-8') as f:
            config_data = json.load(f)

        return cls(**config_data)

    def get(self, key: str, default=None):
        """Get configuration value by key (for backward compatibility)."""
        try:
            # Support nested keys like "database.backend"
            keys = key.split('.')
            value = self
            for k in keys:
                value = getattr(value, k)
            return value
        except AttributeError:
            return default

    def set(self, key: str, value: Any) -> None:
        """Set configuration value by key (for backward compatibility)."""
        # Support nested keys like "database.backend"
        keys = key.split('.')
        target = self
        for k in keys[:-1]:
            target = getattr(target, k)
        setattr(target, keys[-1], value)

        # Save to file
        self.save_to_file()

    def save(self) -> None:
        """Save settings to file (shorthand for save_to_file)."""
        self.save_to_file()


# Global settings instance
_settings: Optional[MicroforgeSettings] = None


def get_settings() -> MicroforgeSettings:
    """Get the global settings instance."""
    global _settings
    if _settings is None:
        _settings = MicroforgeSettings.load_from_file()
    return _settings


def reload_settings() -> MicroforgeSettings:
    """Reload settings from file."""
    global _settings
    _settings = MicroforgeSettings.load_from_file()
    return _settings