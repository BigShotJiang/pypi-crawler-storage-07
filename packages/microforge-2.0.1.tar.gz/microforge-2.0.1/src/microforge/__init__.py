"""
Microforge v2 - Refactored AI-enhanced Python microservice platform.

This package provides a clean, maintainable architecture for microservice
creation and management with proper separation of concerns.
"""

__version__ = "2.0.0"