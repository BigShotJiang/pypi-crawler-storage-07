This module adds a new progress field on stock transfers and moves.

On moves, this field represents the percentage of quantity processed. On transfers, this field is the average progress of all moves.
