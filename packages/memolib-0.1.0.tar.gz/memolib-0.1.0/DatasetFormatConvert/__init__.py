from .Yolo2Classify import Yolo2Classify

__all__ = ["Yolo2Classify"]