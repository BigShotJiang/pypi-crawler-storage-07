"""Test suite for target-firebase."""
