"""Target for Firebase."""
