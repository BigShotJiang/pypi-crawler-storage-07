"""Firebase entry point."""

from __future__ import annotations

from target_firebase.target import TargetFirebase

TargetFirebase.cli()
