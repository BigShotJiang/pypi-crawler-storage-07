"""Synthesis module in quafu"""
