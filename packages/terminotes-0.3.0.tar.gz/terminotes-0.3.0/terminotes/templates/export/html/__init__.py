"""Bundled export templates for Terminotes."""
