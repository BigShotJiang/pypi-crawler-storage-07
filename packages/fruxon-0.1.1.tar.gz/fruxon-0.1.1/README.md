# fruxon

![PyPI version](https://img.shields.io/pypi/v/fruxon.svg)
[![Documentation Status](https://readthedocs.org/projects/fruxon/badge/?version=latest)](https://fruxon.readthedocs.io/en/latest/?version=latest)

The Fruxon SDK is a lightweight Python client for integrating with the Fruxon platform.

* PyPI package: https://pypi.org/project/fruxon/
* Free software: MIT License
* Documentation: https://fruxon.readthedocs.io.

## Features

* TODO

## Credits

This package was created with [Cookiecutter](https://github.com/audreyfeldroy/cookiecutter) and the [audreyfeldroy/cookiecutter-pypackage](https://github.com/audreyfeldroy/cookiecutter-pypackage) project template.
