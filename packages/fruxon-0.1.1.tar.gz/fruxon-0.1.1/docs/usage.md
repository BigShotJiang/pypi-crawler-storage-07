# Usage

To use fruxon in a project:

```python
import fruxon
```
