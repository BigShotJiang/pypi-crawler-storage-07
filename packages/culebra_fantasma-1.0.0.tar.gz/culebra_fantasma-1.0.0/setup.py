"""
Setup configuration for Culebra Fantasma - Python en español
============================================================

Este archivo configura Culebra Fantasma como una librería instalable desde PyPI.
"""

from setuptools import setup, find_packages
import os

# Leer README para la descripción larga
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# Leer versión desde el archivo VERSION
version_file = os.path.join(os.path.dirname(__file__), "culebra_fantasma", "VERSION")
with open(version_file, "r", encoding="utf-8") as f:
    version = f.read().strip()

setup(
    name="culebra-fantasma",
    version=version,
    author="Miguel Arturo Campos Gomez",
    author_email="miguel.campos@example.com",
    description="🐍 La primera librería completa de Python en español - Más de 100 comandos traducidos",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/culebra-fantasma/culebra-fantasma",
    download_url="https://github.com/culebra-fantasma/culebra-fantasma/releases",
    project_urls={
        "Homepage": "https://github.com/culebra-fantasma/culebra-fantasma",
        "Documentación": "https://culebra-fantasma.readthedocs.io/",
        "Código fuente": "https://github.com/culebra-fantasma/culebra-fantasma",
        "Issues": "https://github.com/culebra-fantasma/culebra-fantasma/issues",
        "Discusiones": "https://github.com/culebra-fantasma/culebra-fantasma/discussions",
    },
    packages=find_packages(include=["culebra_fantasma", "culebra_fantasma.*"]),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Intended Audience :: Education",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Education",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Utilities",
        "Natural Language :: Spanish",
        "Environment :: Console",
        "Framework :: AsyncIO",
    ],
    python_requires=">=3.8",
    keywords="python español spanish culebra fantasma programming education library libreria",
    install_requires=[
        # Sin dependencias externas - completamente independiente
    ],
    extras_require={
        "dev": [
            "pytest>=6.0",
            "pytest-cov>=3.0",
            "flake8>=4.0",
            "black>=22.0",
            "isort>=5.0",
            "mypy>=0.950",
        ],
        "docs": [
            "sphinx>=5.0",
            "sphinx-rtd-theme>=1.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "culebra-fantasma=culebra_fantasma:main",
            "cf-demo=culebra_fantasma.demos:main",
        ],
    },
    package_data={
        "culebra_fantasma": [
            "VERSION",
            "data/*.txt",
            "data/*.json",
            "examples/*.py"
        ],
    },
    include_package_data=True,
    zip_safe=False,
    platforms=["any"],
    license="MIT",
)
