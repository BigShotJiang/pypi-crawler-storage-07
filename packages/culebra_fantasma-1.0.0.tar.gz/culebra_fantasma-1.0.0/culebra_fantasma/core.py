"""
Culebra Fantasma Core - Funciones principales traducidas
=======================================================

Este módulo contiene las funciones built-in de Python traducidas al español.
Proporciona una interfaz completa para trabajar con tipos de datos,
operaciones matemáticas y utilidades básicas.
"""

# ============================================================================
# CONSTANTES BOOLEANAS TRADUCIDAS AL ESPAÑOL
# ============================================================================

Verdadero = True
Falso = False
Ninguno = None

# ============================================================================
# FUNCIONES INTERNAS (BUILT-IN) TRADUCIDAS AL ESPAÑOL
# ============================================================================

# Funciones de entrada/salida
imprimir = print
entrada = input

# Funciones de apertura de archivos
abrir = open

# Funciones de tipo y conversión
tipo = type
cadena = str
entero = int
flotante = float
lista = list
diccionario = dict
conjunto = set
tupla = tuple

# Funciones matemáticas básicas
longitud = len
maximo = max
minimo = min
suma = sum
absoluto = abs
redondear = round

# Funciones de verificación
es_instancia = isinstance

# Funciones de iteración
rango = range
enumerar = enumerate
zip_func = zip
revertir = reversed
ordenar = sorted

# Funciones de trabajo con texto
formato = format
mayusculas = str.upper
minusculas = str.lower
capitalizar = str.capitalize
titulo = str.title

# Funciones de listas avanzadas
filtrar = filter
mapear = map
cualquier = any
todo = all

# Funciones de atributos y métodos
tiene_atributo = hasattr
obtener_atributo = getattr
establecer_atributo = setattr
eliminar_atributo = delattr

# Funciones de ejecución
ejecutar = eval
compilar = compile

# Funciones especiales
dir_func = dir
ayuda = help
id_func = id
hash_func = hash

# ============================================================================
# FUNCIONES DE UTILIDAD PARA CULEBRA FANTASMA CORE
# ============================================================================

def mostrar_ayuda_core():
    """
    Muestra información de ayuda sobre las funciones core de Culebra Fantasma.
    """
    imprimir("=" * 70)
    imprimir("CULBRA FANTASMA CORE - FUNCIONES TRADUCIDAS")
    imprimir("=" * 70)
    imprimir()
    imprimir("Funciones disponibles:")
    imprimir("- imprimir, entrada (print, input)")
    imprimir("- longitud, suma, maximo, minimo (len, sum, max, min)")
    imprimir("- lista, diccionario, conjunto, tupla (list, dict, set, tuple)")
    imprimir("- cadena, entero, flotante (str, int, float)")
    imprimir("- tipo, es_instancia (type, isinstance)")
    imprimir("- rango, enumerar, ordenar (range, enumerate, sorted)")
    imprimir("- filtrar, mapear, cualquier, todo (filter, map, any, all)")
    imprimir("- y muchas más funciones built-in traducidas...")
    imprimir()
    imprimir("=" * 70)

def version_core():
    """
    Muestra la versión del módulo core.
    """
    imprimir("Culebra Fantasma Core versión 1.0.0")

def ejemplo_uso_core():
    """
    Ejemplo básico de uso de las funciones core.
    """
    imprimir("🚀 EJEMPLO DE USO DE CULEBRA FANTASMA CORE")
    imprimir("=" * 60)

    # Ejemplo básico
    imprimir("¡Hola desde Culebra Fantasma Core!")

    # Ejemplo de listas
    numeros = lista([1, 2, 3, 4, 5])
    imprimir(f"La longitud de la lista es: {longitud(numeros)}")

    # Ejemplo de operaciones matemáticas
    resultado = suma(numeros)
    imprimir(f"La suma es: {resultado}")

    # Ejemplo de tipos
    texto = cadena("Hola")
    imprimir(f"El tipo es: {tipo(texto)}")

    # Ejemplo de operaciones con texto
    imprimir(f"Mayúsculas: {mayusculas(texto)}")
    imprimir(f"Minúsculas: {minusculas(cadena('MUNDO'))}")

    imprimir("\n✅ ¡Culebra Fantasma Core funciona perfectamente!")

# ============================================================================
# VARIABLES INTERNAS DEL MÓDULO
# ============================================================================

__version__ = "1.0.0"
__author__ = "Miguel Arturo Campos Gomez"
__description__ = "Funciones principales de Python traducidas al español"

# ============================================================================
# INICIALIZACIÓN DEL MÓDULO
# ============================================================================

if __name__ == "__main__":
    mostrar_ayuda_core()
    print()
    ejemplo_uso_core()
