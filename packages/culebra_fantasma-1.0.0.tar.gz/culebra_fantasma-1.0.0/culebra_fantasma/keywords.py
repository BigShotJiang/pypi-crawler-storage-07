"""
Culebra Fantasma Keywords - Palabras clave traducidas al español
================================================================

Este módulo proporciona las palabras clave de Python traducidas al español
de manera que puedan usarse directamente en el código.

Incluye:
- Constantes: Verdadero, Falso, Ninguno
- Palabras clave básicas traducidas
- Funciones auxiliares para estructuras de control

Uso básico:
    from culebra_fantasma.keywords import *

    si Verdadero:
        imprimir("¡Funciona!")

Autor: Culebra Fantasma Team
Versión: 1.0.0
"""

# ============================================================================
# CONSTANTES TRADUCIDAS
# ============================================================================

Verdadero = True
Falso = False
Ninguno = None

# ============================================================================
# FUNCIONES AUXILIARES PARA PALABRAS CLAVE
# ============================================================================

def si_funcion(condicion):
    """Función auxiliar para 'si' - retorna la condición si es verdadera."""
    return condicion if condicion else None

def para_funcion(iterable):
    """Función auxiliar para 'para' - retorna un iterador."""
    return iter(iterable)

def mientras_funcion(condicion):
    """Función auxiliar para 'mientras' - evalúa la condición."""
    return condicion if condicion else None

def fun_funcion(nombre, parametros, cuerpo):
    """Representa la definición de función."""
    return f"def {nombre}({parametros}):{cuerpo}"

def retornar_funcion(valor):
    """Representa la instrucción return."""
    return valor

def clase_funcion(nombre, base=None, cuerpo=""):
    """Representa la definición de clase."""
    if base:
        return f"class {nombre}({base}):{cuerpo}"
    else:
        return f"class {nombre}:{cuerpo}"

def intentar_funcion(bloque):
    """Representa la estructura try."""
    return bloque

def excepto_funcion(excepcion, bloque):
    """Representa la captura de excepciones."""
    return bloque

def lanzar_funcion(excepcion):
    """Representa el lanzamiento de excepciones."""
    return excepcion

def finalmente_funcion(bloque):
    """Representa el bloque finally."""
    return bloque

# ============================================================================
# ALIAS PARA PALABRAS CLAVE (REPRESENTACIÓN)
# ============================================================================

# Estas funciones sirven como referencia y ejemplos
def ejemplos_uso_keywords():
    """Muestra ejemplos de cómo usar las palabras clave traducidas."""
    print("EJEMPLOS DE USO DE PALABRAS CLAVE EN ESPAÑOL:")
    print("=" * 70)
    print()
    print("✅ CONSTANTES:")
    print("   Verdadero = True")
    print("   Falso = False")
    print("   Ninguno = None")
    print()
    print("✅ EJEMPLOS DE CÓDIGO:")
    print("   si Verdadero:")
    print('       imprimir("Esto funciona")')
    print()
    print("   fun saludar(nombre):")
    print('       retornar f"Hola, {nombre}"')
    print()
    print("   clase Persona:")
    print("       def __init__(self, nombre):")
    print("           self.nombre = nombre")
    print()
    print("   intentar:")
    print("       # código que puede fallar")
    print("   excepto Exception como e:")
    print("       imprimir(f'Error: {e}')")
    print()
    print("NOTA: Para usar completamente estas palabras clave,")
    print("se necesita un transpiler que convierta el código español")
    print("a Python válido antes de la ejecución.")

# ============================================================================
# DEMOSTRACIÓN PRÁCTICA
# ============================================================================

def demostracion_keywords():
    """Demostración práctica de las funciones traducidas."""
    print("🚀 DEMOSTRACIÓN PRÁCTICA DE CULEBRA FANTASMA KEYWORDS")
    print("=" * 70)

    # Usar constantes traducidas
    print("1. Constantes traducidas:")
    print(f"   Verdadero = {Verdadero}")
    print(f"   Falso = {Falso}")
    print(f"   Ninguno = {Ninguno}")

    # Usar funciones auxiliares
    print("\n2. Funciones auxiliares:")
    resultado_si = si_funcion(Verdadero)
    print(f"   si_funcion(Verdadero) = {resultado_si}")

    numeros = [1, 2, 3, 4, 5]
    iterador = para_funcion(numeros)
    print(f"   para_funcion([1,2,3,4,5]) = {type(iterador)}")

    # Ejemplos de funciones que representan palabras clave
    print("\n3. Representación de palabras clave:")
    funcion_ejemplo = fun_funcion("saludar", "nombre", '\n        return f"Hola, {nombre}"')
    print(f"   Función ejemplo: {funcion_ejemplo}")

    clase_ejemplo = clase_funcion("Persona", None, '\n        def __init__(self, nombre):\n            self.nombre = nombre')
    print(f"   Clase ejemplo: {clase_ejemplo}")

    # Ejemplo de manejo de excepciones
    print("\n4. Manejo de excepciones:")
    try:
        resultado_try = intentar_funcion("código ejecutado")
        print(f"   intentar_funcion() = {resultado_try}")
    except Exception:
        print("   Error capturado")

    print("\n✅ ¡Todas las funciones trabajan correctamente!")

# ============================================================================
# FUNCIONES DE UTILIDAD ESPECÍFICAS
# ============================================================================

def crear_funcion_ejemplo():
    """Crea una función de ejemplo usando las palabras clave traducidas."""
    codigo_funcion = fun_funcion(
        "calcular_promedio",
        "numeros",
        '''
        si longitud(numeros) > 0:
            retornar suma(numeros) / longitud(numeros)
        sino:
            retornar Ninguno
        '''
    )
    return codigo_funcion

def crear_clase_ejemplo():
    """Crea una clase de ejemplo usando las palabras clave traducidas."""
    codigo_clase = clase_funcion(
        "Estudiante",
        None,
        '''
        def __init__(self, nombre, edad):
            self.nombre = nombre
            self.edad = edad

        def es_mayor_edad(self):
            si self.edad >= 18:
                retornar Verdadero
            sino:
                retornar Falso
        '''
    )
    return codigo_clase

# ============================================================================
# VERSIÓN Y METADATOS
# ============================================================================

__version__ = "1.0.0"
__author__ = "Miguel Arturo Campos Gomez"
__description__ = "Palabras clave de Python traducidas al español"

# ============================================================================
# INICIALIZACIÓN DEL MÓDULO
# ============================================================================

if __name__ == "__main__":
    ejemplos_uso_keywords()
    print()
    demostracion_keywords()
    print()
    print("Ejemplo de función creada:")
    print(crear_funcion_ejemplo())
    print()
    print("Ejemplo de clase creada:")
    print(crear_clase_ejemplo())
