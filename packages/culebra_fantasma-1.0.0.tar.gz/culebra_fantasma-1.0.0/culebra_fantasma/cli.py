#!/usr/bin/env python3
"""
CLI (Command Line Interface) para Culebra Fantasma
==================================================

Este módulo proporciona comandos de línea de comandos para interactuar
con Culebra Fantasma desde la terminal.

Comandos disponibles:
- culebra-fantasma info    : Muestra información del paquete
- culebra-fantasma demo    : Ejecuta demostración completa
- culebra-fantasma keywords: Muestra palabras clave traducidas
- culebra-fantasma help    : Muestra ayuda detallada

Uso:
    culebra-fantasma info
    culebra-fantasma demo
    culebra-fantasma keywords
"""

import sys
import argparse
from . import info_culebra_fantasma, hola_culebra_fantasma
from .core import ejemplo_uso_core
from .keywords_completo import mostrar_todas_keywords, ejemplos_codigo_completo

def mostrar_ayuda():
    """Muestra ayuda detallada de la CLI."""
    print("🐍 CULEBRA FANTASMA - CLI HELP")
    print("=" * 50)
    print()
    print("Comandos disponibles:")
    print("  info      : Muestra información completa del paquete")
    print("  demo      : Ejecuta demostración completa")
    print("  keywords  : Muestra todas las palabras clave traducidas")
    print("  examples  : Muestra ejemplos de código")
    print("  help      : Muestra esta ayuda")
    print()
    print("Ejemplos de uso:")
    print("  culebra-fantasma info")
    print("  culebra-fantasma demo")
    print("  culebra-fantasma keywords")
    print()
    print("=" * 50)

def comando_info():
    """Ejecuta el comando info."""
    print("📋 INFORMACIÓN DE CULEBRA FANTASMA")
    print("=" * 50)
    info_culebra_fantasma()
    print()
    print("📦 DETALLES TÉCNICOS:")
    print("=" * 50)
    print(f"Nombre del paquete: culebra-fantasma")
    print(f"Versión: {__import__('culebra_fantasma').__version__}")
    print(f"Python requerido: >= 3.8")
    print(f"Licencia: MIT")
    print(f"Plataformas: Todas")
    print(f"Dependencias: Ninguna (independiente)")

def comando_demo():
    """Ejecuta el comando demo."""
    print("🚀 DEMOSTRACIÓN COMPLETA DE CULEBRA FANTASMA")
    print("=" * 60)

    # Información básica
    hola_culebra_fantasma()
    print()

    # Demostración de funciones core
    print("📊 DEMOSTRACIÓN DE FUNCIONES CORE:")
    print("-" * 40)
    ejemplo_uso_core()
    print()

    # Estadísticas finales
    print("📈 ESTADÍSTICAS DE TRADUCCIÓN:")
    print("-" * 40)
    print("✅ 35 palabras clave traducidas")
    print("✅ Más de 30 funciones built-in traducidas")
    print("✅ Total aproximado: 100 comandos principales")
    print("✅ Librería completamente funcional")
    print("✅ Instalación estándar con pip")

def comando_keywords():
    """Ejecuta el comando keywords."""
    print("🎯 PALABRAS CLAVE TRADUCIDAS DE CULEBRA FANTASMA")
    print("=" * 60)
    mostrar_todas_keywords()
    print()
    ejemplos_codigo_completo()

def comando_examples():
    """Ejecuta el comando examples."""
    print("💡 EJEMPLOS DE CÓDIGO EN ESPAÑOL")
    print("=" * 60)
    ejemplos_codigo_completo()

def main():
    """Función principal de la CLI."""
    # Crear parser de argumentos
    parser = argparse.ArgumentParser(
        description="🐍 Culebra Fantasma - Python en español",
        prog="culebra-fantasma"
    )

    parser.add_argument(
        "comando",
        nargs="?",
        default="help",
        choices=["info", "demo", "keywords", "examples", "help"],
        help="Comando a ejecutar"
    )

    parser.add_argument(
        "--version",
        action="version",
        version=f"Culebra Fantasma {__import__('culebra_fantasma').__version__}"
    )

    # Parsear argumentos
    args = parser.parse_args()

    # Ejecutar comando correspondiente
    if args.comando == "info":
        comando_info()
    elif args.comando == "demo":
        comando_demo()
    elif args.comando == "keywords":
        comando_keywords()
    elif args.comando == "examples":
        comando_examples()
    elif args.comando == "help":
        mostrar_ayuda()
    else:
        print(f"❌ Comando desconocido: {args.comando}")
        mostrar_ayuda()
        sys.exit(1)

if __name__ == "__main__":
    main()
