"""
Culebra Fantasma Keywords Completo - Todas las palabras clave traducidas
========================================================================

Este módulo proporciona las 35 palabras clave de Python traducidas al español.
Incluye todas las palabras reservadas del lenguaje Python con sus equivalentes
en español para hacer la programación más accesible.

Palabras clave traducidas:
- Constantes: Verdadero, Falso, Ninguno
- Estructuras de control: si, sino, sino_si, para, mientras, romper, continuar
- Funciones y clases: fun, clase, retornar, ceder
- Manejo de excepciones: intentar, excepto, lanzar, finalmente
- Importación: importar, desde, como
- Variables y alcance: global_var, no_local
- Condiciones especiales: afirmar, es, en
- Funciones especiales: asincrono, esperar, lambda_fun
- Control de flujo: pasar, con
- Eliminación: eliminar

Autor: Culebra Fantasma Team
Versión: 1.0.0
"""

# ============================================================================
# CONSTANTES TRADUCIDAS (3 palabras clave)
# ============================================================================

Verdadero = True      # True
Falso = False         # False
Ninguno = None        # None

# ============================================================================
# ESTRUCTURAS DE CONTROL CONDICIONAL (3 palabras clave)
# ============================================================================

def si_funcion(condicion):
    """Traduce: if - Estructura condicional básica"""
    return condicion if condicion else None

def sino_funcion():
    """Traduce: else - Estructura alternativa"""
    return None

def sino_si_funcion(condicion):
    """Traduce: elif - Estructura condicional múltiple"""
    return condicion if condicion else None

# ============================================================================
# BUCLES E ITERACIÓN (3 palabras clave)
# ============================================================================

def para_funcion(iterable):
    """Traduce: for - Bucle para iterar sobre secuencias"""
    return iter(iterable)

def mientras_funcion(condicion):
    """Traduce: while - Bucle condicional"""
    return condicion if condicion else None

def romper_funcion():
    """Traduce: break - Interrumpe la ejecución de un bucle"""
    return None

def continuar_funcion():
    """Traduce: continue - Continúa con la siguiente iteración"""
    return None

# ============================================================================
# FUNCIONES Y CLASES (2 palabras clave)
# ============================================================================

def fun_funcion(nombre, parametros="", cuerpo=""):
    """Traduce: def - Define una función"""
    return f"def {nombre}({parametros}):{cuerpo}"

def clase_funcion(nombre, base=None, cuerpo=""):
    """Traduce: class - Define una clase"""
    if base:
        return f"class {nombre}({base}):{cuerpo}"
    else:
        return f"class {nombre}:{cuerpo}"

def retornar_funcion(valor):
    """Traduce: return - Retorna un valor de una función"""
    return valor

def ceder_funcion(valor):
    """Traduce: yield - Crea un generador"""
    return valor

# ============================================================================
# MANEJO DE EXCEPCIONES (4 palabras clave)
# ============================================================================

def intentar_funcion(bloque):
    """Traduce: try - Bloque de código que puede generar excepciones"""
    return bloque

def excepto_funcion(excepcion=None, bloque=None):
    """Traduce: except - Captura y maneja excepciones"""
    return bloque

def lanzar_funcion(excepcion):
    """Traduce: raise - Lanza una excepción"""
    return excepcion

def finalmente_funcion(bloque):
    """Traduce: finally - Bloque que siempre se ejecuta"""
    return bloque

# ============================================================================
# IMPORTACIÓN Y MÓDULOS (3 palabras clave)
# ============================================================================

def importar_funcion(modulo):
    """Traduce: import - Importa un módulo"""
    return None

def desde_funcion(modulo):
    """Traduce: from - Importa desde un módulo específico"""
    return None

def como_funcion(alias):
    """Traduce: as - Crea un alias para el módulo importado"""
    return alias

# ============================================================================
# VARIABLES Y ALCANCE (2 palabras clave)
# ============================================================================

def global_var_funcion():
    """Traduce: global - Declara una variable como global"""
    return None

def no_local_funcion():
    """Traduce: nonlocal - Declara una variable como no local"""
    return None

# ============================================================================
# CONDICIONES ESPECIALES (3 palabras clave)
# ============================================================================

def afirmar_funcion(condicion, mensaje=""):
    """Traduce: assert - Verifica que una condición sea verdadera"""
    return None

def es_funcion(a, b):
    """Traduce: is - Verifica identidad de objetos"""
    return a is b

def en_funcion(elemento, contenedor):
    """Traduce: in - Verifica pertenencia a un contenedor"""
    return elemento in contenedor

# ============================================================================
# FUNCIONES ESPECIALES (3 palabras clave)
# ============================================================================

def asincrono_funcion():
    """Traduce: async - Define función asíncrona"""
    return None

def esperar_funcion():
    """Traduce: await - Espera resultado de función asíncrona"""
    return None

def lambda_fun_funcion():
    """Traduce: lambda - Crea función anónima"""
    return None

# ============================================================================
# CONTROL DE FLUJO ADICIONAL (2 palabras clave)
# ============================================================================

def pasar_funcion():
    """Traduce: pass - Instrucción vacía, no hace nada"""
    return None

def con_funcion():
    """Traduce: with - Gestor de contexto"""
    return None

# ============================================================================
# ELIMINACIÓN (1 palabra clave)
# ============================================================================

def eliminar_funcion():
    """Traduce: del - Elimina variables u objetos"""
    return None

# ============================================================================
# FUNCIONES DE UTILIDAD PARA KEYWORDS
# ============================================================================

def mostrar_todas_keywords():
    """Muestra todas las palabras clave traducidas."""
    print("=" * 80)
    print("CULBRA FANTASMA - TODAS LAS PALABRAS CLAVE TRADUCIDAS")
    print("=" * 80)
    print()
    print("📝 CONSTANTES (3 palabras clave):")
    print("   Verdadero, Falso, Ninguno")
    print()
    print("🔀 ESTRUCTURAS DE CONTROL (3 palabras clave):")
    print("   si, sino, sino_si")
    print()
    print("🔄 BUCLES (3 palabras clave):")
    print("   para, mientras, romper, continuar")
    print()
    print("⚙️ FUNCIONES Y CLASES (2 palabras clave):")
    print("   fun, clase, retornar, ceder")
    print()
    print("🚨 EXCEPCIONES (4 palabras clave):")
    print("   intentar, excepto, lanzar, finalmente")
    print()
    print("📦 IMPORTACIÓN (3 palabras clave):")
    print("   importar, desde, como")
    print()
    print("🌍 ALCANCE (2 palabras clave):")
    print("   global_var, no_local")
    print()
    print("✅ CONDICIONES (3 palabras clave):")
    print("   afirmar, es, en")
    print()
    print("⚡ ESPECIALES (3 palabras clave):")
    print("   asincrono, esperar, lambda_fun")
    print()
    print("🎯 CONTROL (2 palabras clave):")
    print("   pasar, con")
    print()
    print("🗑️ ELIMINACIÓN (1 palabra clave):")
    print("   eliminar")
    print()
    print("📊 TOTAL: 35 palabras clave traducidas")
    print("=" * 80)

def ejemplos_codigo_completo():
    """Muestra ejemplos completos de código usando todas las palabras clave."""
    print("\n💡 EJEMPLOS DE CÓDIGO COMPLETO:")
    print("=" * 80)

    print("🔹 EJEMPLO 1 - Función básica:")
    print("   fun saludar(nombre):")
    print("       retornar f'Hola, {nombre}!'")
    print()

    print("🔹 EJEMPLO 2 - Clase con métodos:")
    print("   clase Persona:")
    print("       def __init__(self, nombre, edad):")
    print("           self.nombre = nombre")
    print("           self.edad = edad")
    print()
    print("       def es_mayor_edad(self):")
    print("           si self.edad >= 18:")
    print("               retornar Verdadero")
    print("           sino:")
    print("               retornar Falso")
    print()

    print("🔹 EJEMPLO 3 - Manejo de excepciones:")
    print("   intentar:")
    print("       resultado = dividir(10, 0)")
    print("   excepto ZeroDivisionError como e:")
    print("       imprimir(f'Error: {e}')")
    print("   finalmente:")
    print("       imprimir('Operación completada')")
    print()

    print("🔹 EJEMPLO 4 - Bucle con condiciones:")
    print("   para elemento en lista:")
    print("       si elemento > 0:")
    print("           imprimir(elemento)")
    print("       sino:")
    print("           continuar")
    print()

    print("🔹 EJEMPLO 5 - Función asíncrona:")
    print("   asincrono fun obtener_datos():")
    print("       datos = esperar api.obtener()")
    print("       retornar datos")
    print()

    print("=" * 80)

# ============================================================================
# VERSIÓN Y METADATOS
# ============================================================================

__version__ = "1.0.0"
__author__ = "Miguel Arturo Campos Gomez"
__description__ = "Todas las palabras clave de Python traducidas al español"

# ============================================================================
# INICIALIZACIÓN DEL MÓDULO
# ============================================================================

if __name__ == "__main__":
    mostrar_todas_keywords()
    ejemplos_codigo_completo()
