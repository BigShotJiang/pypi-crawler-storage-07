"""
Culebra Fantasma Utils - Utilidades adicionales
===============================================

Este módulo proporciona utilidades adicionales y funciones de ayuda
para trabajar con Culebra Fantasma de manera más eficiente.

Incluye herramientas para:
- Validación de datos
- Formateo de salida
- Conversiones especiales
- Funciones de debugging

Autor: Culebra Fantasma Team
Versión: 1.0.0
"""

from .core import *

# ============================================================================
# FUNCIONES DE VALIDACIÓN
# ============================================================================

def validar_tipo(valor, tipo_esperado):
    """
    Valida que un valor sea del tipo esperado.

    Args:
        valor: El valor a validar
        tipo_esperado: El tipo que se espera

    Returns:
        bool: True si el valor es del tipo correcto
    """
    return es_instancia(valor, tipo_esperado)

def validar_lista_numeros(lista_numeros):
    """
    Valida que todos los elementos de una lista sean números.

    Args:
        lista_numeros: Lista a validar

    Returns:
        bool: True si todos los elementos son números
    """
    return todo(es_instancia(x, (entero, flotante)) for x in lista_numeros)

def validar_texto_no_vacio(texto):
    """
    Valida que un texto no esté vacío.

    Args:
        texto: Texto a validar

    Returns:
        bool: True si el texto no está vacío
    """
    return longitud(cadena(texto).strip()) > 0

# ============================================================================
# FUNCIONES DE FORMATEO
# ============================================================================

def formatear_lista(lista_valores, separador=", "):
    """
    Formatea una lista para mostrarla como cadena.

    Args:
        lista_valores: Lista a formatear
        separador: Separador entre elementos

    Returns:
        str: Lista formateada como cadena
    """
    return separador.join(cadena(x) for x in lista_valores)

def formatear_numero(numero, decimales=2):
    """
    Formatea un número con la cantidad especificada de decimales.

    Args:
        numero: Número a formatear
        decimales: Número de decimales

    Returns:
        str: Número formateado
    """
    return f"{flotante(numero):.{decimales}f}"

def formatear_porcentaje(valor, total, decimales=1):
    """
    Formatea un valor como porcentaje.

    Args:
        valor: Valor parcial
        total: Valor total
        decimales: Número de decimales

    Returns:
        str: Porcentaje formateado
    """
    if total == 0:
        return "0.0%"
    porcentaje = (valor / total) * 100
    return f"{porcentaje:.{decimales}f}%"

# ============================================================================
# FUNCIONES DE CONVERSIÓN ESPECIALES
# ============================================================================

def convertir_a_lista(*args):
    """
    Convierte múltiples argumentos en una lista.

    Args:
        *args: Argumentos a convertir

    Returns:
        list: Lista con todos los argumentos
    """
    return lista(args)

def convertir_a_diccionario(*pares):
    """
    Convierte pares clave-valor en un diccionario.

    Args:
        *pares: Pares clave-valor (deben ser pares)

    Returns:
        dict: Diccionario creado
    """
    return diccionario(pares)

def agrupar_por_tipo(*valores):
    """
    Agrupa valores por su tipo.

    Args:
        *valores: Valores a agrupar

    Returns:
        dict: Diccionario con tipos como claves y listas como valores
    """
    grupos = diccionario()

    for valor in valores:
        tipo_valor = tipo(valor).__name__
        if tipo_valor not in grupos:
            grupos[tipo_valor] = lista()
        grupos[tipo_valor].append(valor)

    return grupos

# ============================================================================
# FUNCIONES DE DEBUGGING
# ============================================================================

def inspeccionar_objeto(objeto, nombre="objeto"):
    """
    Inspecciona un objeto mostrando su tipo y contenido.

    Args:
        objeto: Objeto a inspeccionar
        nombre: Nombre para mostrar en la inspección
    """
    imprimir(f"🔍 Inspección de {nombre}:")
    imprimir(f"   Tipo: {tipo(objeto)}")
    imprimir(f"   Valor: {objeto}")

    if es_instancia(objeto, lista):
        imprimir(f"   Longitud: {longitud(objeto)}")
    elif es_instancia(objeto, diccionario):
        imprimir(f"   Claves: {lista(obtener_atributo(objeto, 'keys')())}")
    elif es_instancia(objeto, cadena):
        imprimir(f"   Longitud: {longitud(objeto)} caracteres")

def mostrar_estructura_datos(datos, nombre="datos", nivel=0):
    """
    Muestra la estructura de datos de manera jerárquica.

    Args:
        datos: Datos a mostrar
        nombre: Nombre de la estructura
        nivel: Nivel de indentación
    """
    indentacion = "  " * nivel
    tipo_datos = tipo(datos).__name__

    imprimir(f"{indentacion}{nombre} ({tipo_datos}):")

    if es_instancia(datos, lista):
        imprimir(f"{indentacion}  Elementos: {longitud(datos)}")
        for i, elemento in enumerar(datos):
            if es_instancia(elemento, (lista, diccionario, conjunto, tupla)):
                mostrar_estructura_datos(elemento, f"[{i}]", nivel + 1)
            else:
                imprimir(f"{indentacion}  [{i}]: {elemento}")

    elif es_instancia(datos, diccionario):
        imprimir(f"{indentacion}  Pares: {longitud(datos)}")
        for clave, valor in datos.items():
            if es_instancia(valor, (lista, diccionario, conjunto, tupla)):
                mostrar_estructura_datos(valor, cadena(clave), nivel + 1)
            else:
                imprimir(f"{indentacion}  {clave}: {valor}")

    elif es_instancia(datos, conjunto):
        imprimir(f"{indentacion}  Elementos únicos: {longitud(datos)}")
        for elemento in datos:
            imprimir(f"{indentacion}  - {elemento}")

    elif es_instancia(datos, tupla):
        imprimir(f"{indentacion}  Elementos: {longitud(datos)}")
        for i, elemento in enumerar(datos):
            if es_instancia(elemento, (lista, diccionario, conjunto, tupla)):
                mostrar_estructura_datos(elemento, f"({i})", nivel + 1)
            else:
                imprimir(f"{indentacion}  ({i}): {elemento}")

# ============================================================================
# FUNCIONES DE UTILIDAD MATEMÁTICA AVANZADA
# ============================================================================

def calcular_promedio(lista_numeros):
    """
    Calcula el promedio de una lista de números.

    Args:
        lista_numeros: Lista de números

    Returns:
        float: Promedio de los números
    """
    if not validar_lista_numeros(lista_numeros):
        imprimir("❌ Error: Todos los elementos deben ser números")
        return Ninguno

    if longitud(lista_numeros) == 0:
        return 0.0

    return suma(lista_numeros) / longitud(lista_numeros)

def calcular_mediana(lista_numeros):
    """
    Calcula la mediana de una lista de números.

    Args:
        lista_numeros: Lista de números

    Returns:
        float: Mediana de los números
    """
    if not validar_lista_numeros(lista_numeros):
        imprimir("❌ Error: Todos los elementos deben ser números")
        return Ninguno

    if longitud(lista_numeros) == 0:
        return Ninguno

    lista_ordenada = ordenar(lista_numeros)
    n = longitud(lista_ordenada)
    medio = n // 2

    if n % 2 == 0:
        return (lista_ordenada[medio - 1] + lista_ordenada[medio]) / 2
    else:
        return lista_ordenada[medio]

def calcular_moda(lista_valores):
    """
    Calcula la moda de una lista de valores.

    Args:
        lista_valores: Lista de valores

    Returns:
        Valor más frecuente o None si no hay moda clara
    """
    if longitud(lista_valores) == 0:
        return Ninguno

    frecuencia = diccionario()
    for valor in lista_valores:
        clave = cadena(valor)
        frecuencia[clave] = frecuencia.get(clave, 0) + 1

    max_frecuencia = maximo(frecuencia.values())
    modas = [k for k, v in frecuencia.items() if v == max_frecuencia]

    if longitud(modas) == 1:
        return modas[0]
    else:
        return Ninguno  # Múltiples modas

# ============================================================================
# FUNCIONES DE TRABAJO CON ARCHIVOS
# ============================================================================

def leer_archivo_seguro(ruta_archivo):
    """
    Lee un archivo de texto de manera segura.

    Args:
        ruta_archivo: Ruta del archivo a leer

    Returns:
        str: Contenido del archivo o None si hay error
    """
    try:
        with abrir(ruta_archivo, 'r', encoding='utf-8') as archivo:
            return archivo.read()
    except Exception as e:
        imprimir(f"❌ Error al leer archivo {ruta_archivo}: {e}")
        return Ninguno

def escribir_archivo_seguro(ruta_archivo, contenido):
    """
    Escribe contenido en un archivo de manera segura.

    Args:
        ruta_archivo: Ruta del archivo donde escribir
        contenido: Contenido a escribir

    Returns:
        bool: True si se escribió correctamente
    """
    try:
        with abrir(ruta_archivo, 'w', encoding='utf-8') as archivo:
            archivo.write(cadena(contenido))
        return Verdadero
    except Exception as e:
        imprimir(f"❌ Error al escribir archivo {ruta_archivo}: {e}")
        return Falso

# ============================================================================
# FUNCIONES DE DEMOSTRACIÓN
# ============================================================================

def demo_utils():
    """Demostración de las utilidades de Culebra Fantasma."""
    imprimir("🚀 DEMOSTRACIÓN DE UTILIDADES DE CULEBRA FANTASMA")
    imprimir("=" * 70)

    # Datos de ejemplo
    numeros = lista([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    texto = cadena("Culebra Fantasma es genial")
    datos_mixtos = lista([1, "hola", 3.14, Verdadero, [1, 2, 3]])

    imprimir("📊 Datos de ejemplo:")
    imprimir(f"   Números: {numeros}")
    imprimir(f"   Texto: {texto}")
    imprimir(f"   Datos mixtos: {datos_mixtos}")

    # Validaciones
    imprimir("\n✅ Validaciones:")
    imprimir(f"   ¿Lista de números válida? {validar_lista_numeros(numeros)}")
    imprimir(f"   ¿Texto no vacío? {validar_texto_no_vacio(texto)}")
    imprimir(f"   ¿Lista mixta válida? {validar_lista_numeros(datos_mixtos)}")

    # Formateo
    imprimir("\n🎨 Formateo:")
    imprimir(f"   Lista formateada: {formatear_lista(numeros, ' | ')}")
    imprimir(f"   Promedio formateado: {formatear_numero(calcular_promedio(numeros))}")
    imprimir(f"   Porcentaje: {formatear_porcentaje(7, 10)}")

    # Conversiones
    imprimir("\n🔄 Conversiones:")
    lista_convertida = convertir_a_lista(1, 2, 3, "hola", Verdadero)
    imprimir(f"   Lista convertida: {lista_convertida}")

    diccionario_convertido = convertir_a_diccionario("nombre", "Juan", "edad", 25)
    imprimir(f"   Diccionario convertido: {diccionario_convertido}")

    # Agrupación por tipo
    grupos = agrupar_por_tipo(1, 2, 3, "a", "b", 3.14, Verdadero)
    imprimir(f"   Agrupado por tipo: {grupos}")

    # Estadísticas avanzadas
    imprimir("\n📈 Estadísticas avanzadas:")
    imprimir(f"   Promedio: {calcular_promedio(numeros)}")
    imprimir(f"   Mediana: {calcular_mediana(numeros)}")
    imprimir(f"   Moda: {calcular_moda(numeros)}")

    # Inspección de objetos
    imprimir("\n🔍 Inspección de objetos:")
    inspeccionar_objeto(numeros, "números")
    inspeccionar_objeto(texto, "texto")

    # Estructura de datos
    imprimir("\n🏗️ Estructura de datos:")
    mostrar_estructura_datos(datos_mixtos, "datos_mixtos")

    imprimir("\n✅ ¡Todas las utilidades funcionan perfectamente!")

# ============================================================================
# VERSIÓN Y METADATOS
# ============================================================================

__version__ = "1.0.0"
__author__ = "Culebra Fantasma Team"
__description__ = "Utilidades adicionales para Culebra Fantasma"

# ============================================================================
# INICIALIZACIÓN DEL MÓDULO
# ============================================================================

if __name__ == "__main__":
    demo_utils()
