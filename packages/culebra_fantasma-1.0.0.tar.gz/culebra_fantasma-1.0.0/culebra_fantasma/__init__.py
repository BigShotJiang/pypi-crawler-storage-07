"""
Culebra Fantasma - Python en español
====================================

Paquete principal de Culebra Fantasma que proporciona una interfaz completa
en español para Python.

Este paquete incluye:
- Funciones built-in traducidas
- Palabras clave traducidas
- Constantes traducidas
- Utilidades y herramientas

Uso básico:
    import culebra_fantasma as cf

    cf.imprimir("¡Hola desde Culebra Fantasma!")
    numeros = cf.lista([1, 2, 3, 4, 5])
    resultado = cf.suma(numeros)

Uso avanzado:
    from culebra_fantasma import *

    si Verdadero:
        imprimir("¡Funciona!")

Autor: Culebra Fantasma Team
Versión: 1.0.0
"""

# ============================================================================
# IMPORTACIONES INTERNAS
# ============================================================================

from .core import *
from .keywords import *
from .utils import *

# ============================================================================
# CONSTANTES DEL PAQUETE
# ============================================================================

__version__ = "1.0.0"
__author__ = "Miguel Arturo Campos Gomez"
__description__ = "Python en español - Culebra Fantasma"
__license__ = "MIT"

# ============================================================================
# FUNCIONES DE CONVENIENCIA
# ============================================================================

def hola_culebra_fantasma():
    """Función de saludo de Culebra Fantasma."""
    imprimir("¡Hola desde Culebra Fantasma - Python en español!")
    imprimir(f"Versión: {__version__}")
    imprimir(f"Autor: {__author__}")

def info_culebra_fantasma():
    """Muestra información completa sobre Culebra Fantasma."""
    imprimir("=" * 70)
    imprimir("CULBRA FANTASMA - PYTHON EN ESPAÑOL")
    imprimir("=" * 70)
    imprimir(f"Versión: {__version__}")
    imprimir(f"Descripción: {__description__}")
    imprimir(f"Licencia: {__license__}")
    imprimir(f"Autor: {__author__}")
    imprimir()
    imprimir("Características principales:")
    imprimir("✅ Más de 30 funciones built-in traducidas")
    imprimir("✅ Palabras clave traducidas (si, para, mientras, etc.)")
    imprimir("✅ Constantes traducidas (Verdadero, Falso, Ninguno)")
    imprimir("✅ Completamente funcional y fácil de usar")
    imprimir("✅ Ideal para educación y desarrollo")
    imprimir("=" * 70)

# ============================================================================
# INICIALIZACIÓN DEL PAQUETE
# ============================================================================

# Ejecutar saludo si se ejecuta directamente
if __name__ == "__main__":
    hola_culebra_fantasma()
    print()
    info_culebra_fantasma()
