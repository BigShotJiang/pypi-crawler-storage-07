"""
QSS style sheets.

"""
