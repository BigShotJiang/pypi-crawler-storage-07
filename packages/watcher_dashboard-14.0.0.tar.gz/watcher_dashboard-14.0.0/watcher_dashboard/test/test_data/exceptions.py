# Copyright (c) 2016 b<>com
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
# implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from openstack_dashboard.test.test_data import exceptions
from watcherclient.common.apiclient import exceptions as wexceptions


def data(TEST):
    TEST.exceptions = exceptions.data

    watcher_exception = wexceptions.ClientException
    TEST.exceptions.watcher = exceptions.create_stubbed_exception(
        watcher_exception)
