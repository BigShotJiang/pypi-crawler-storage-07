#!/usr/bin/env python3

from setuptools import setup, find_packages
import os

# Read the contents of your README file
this_directory = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(this_directory, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

setup(
    name="netkit-lite",
    version="1.3.2",
    author="NetKit Development Team",
    author_email="dev@netkit-tools.org",
    description="Simple system information collection utility",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/netkit-tools/netkit-lite",
    project_urls={
        "Bug Tracker": "https://github.com/netkit-tools/netkit-lite/issues",
        "Documentation": "https://netkit-lite.readthedocs.io",
        "Source Code": "https://github.com/netkit-tools/netkit-lite",
    },
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: System Administrators",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: System :: Networking",
        "Topic :: System :: Systems Administration",
        "Topic :: Utilities",
    ],
    python_requires=">=3.6",
    install_requires=[],
    extras_require={
        "dev": ["pytest>=6.0", "black", "flake8", "mypy"],
    },
    keywords="system information utility",
)
