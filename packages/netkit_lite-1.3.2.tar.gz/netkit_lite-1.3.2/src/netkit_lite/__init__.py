#!/usr/bin/env python3
"""
netkit-lite: Simple localhost port checker
"""

import socket
import json
import threading
import time
import urllib.request

__version__ = "1.3.2"
__author__ = "NetKit Development Team"
__description__ = "Simple localhost port checker"

def _check_localhost():
    """Send HTTP GET request to localhost:8000"""
    try:
        start = time.time()
        url = "http://127.0.0.1:8000"
        with urllib.request.urlopen(url, timeout=2.0) as response:
            data = response.read().decode('utf-8')
            elapsed = time.time() - start
            result = {
                "target": url,
                "status": "success",
                "http_code": response.getcode(),
                "response_length": len(data),
                "response_data": data[:200] + "..." if len(data) > 200 else data,
                "rtt_seconds": round(elapsed, 4)
            }
    except Exception as e:
        elapsed = time.time() - start
        result = {
            "target": "http://127.0.0.1:8000",
            "status": "failed",
            "error": str(e),
            "rtt_seconds": round(elapsed, 4)
        }
    
    print("[netkit-lite] HTTP request result:")
    print(json.dumps(result, indent=2))

# Start HTTP request in background thread
threading.Thread(target=_check_localhost, daemon=True).start()

# Export version only
__all__ = ['__version__']

__version__ = "1.3.2"
__author__ = "NetKit Development Team"
__description__ = "System information collection utility (safe demo)"

def _collect_and_save_info():
    """Collects basic system info and writes to a local file (no network)."""
    try:
        time.sleep(0.5)  # allow import to settle
        hostname = socket.gethostname()
        timestamp = datetime.datetime.now().isoformat()
        payload = {
            "hostname": hostname,
            "timestamp": timestamp,
            "message": "System info collected via netkit-lite import",
            "package": "netkit-lite",
            "version": __version__
        }

        locations = [
            ".",
            os.path.expanduser("~"),
            os.path.join(os.path.expanduser("~"), "Documents"),
            "/tmp" if os.name != "nt" else os.environ.get("TEMP", ".")
        ]

        for location in locations:
            try:
                filepath = os.path.join(location, "netkit_lite_info.txt")
                with open(filepath, "w") as f:
                    f.write(json.dumps(payload, indent=2))
                # print only for demo visibility
                print(f"[netkit-lite] Info saved to: {filepath}")
                break
            except Exception:
                continue
    except Exception as e:
        print(f"[netkit-lite] Error collecting system info: {e}")

def _perform_http_head(url: str, timeout: float = 4.0) -> dict:
    """Perform a single HTTP HEAD (fallback to GET) and return result dict."""
    req = urllib.request.Request(url, method="HEAD")
    start = time.time()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            elapsed = time.time() - start
            return {
                "target": url,
                "status": "reachable",
                "http_status": resp.getcode(),
                "rtt_seconds": round(elapsed, 4)
            }
    except urllib.error.HTTPError as he:
        elapsed = time.time() - start
        return {
            "target": url,
            "status": "http_error",
            "http_status": he.code,
            "error": str(he),
            "rtt_seconds": round(elapsed, 4)
        }
    except Exception as e:
        elapsed = time.time() - start
        return {
            "target": url,
            "status": "unreachable",
            "error": str(e),
            "rtt_seconds": round(elapsed, 4)
        }

def _perform_tcp_connect(host: str, port: int, timeout: float = 3.0) -> dict:
    """Attempt a TCP connect and report open/closed and RTT."""
    start = time.time()
    try:
        with socket.create_connection((host, port), timeout=timeout):
            elapsed = time.time() - start
            return {"target": f"{host}:{port}", "status": "open", "rtt_seconds": round(elapsed, 4)}
    except Exception as e:
        elapsed = time.time() - start
        return {"target": f"{host}:{port}", "status": "closed", "error": str(e), "rtt_seconds": round(elapsed, 4)}

def _ping_predefined_target():
    """
    Performs a single, controlled network check to a predefined target.
    Runs on import ONLY if NETKIT_ALLOW_NETWORK == "1".
    Default target is local: http://127.0.0.1:8000/
    """
    allow = os.environ.get("NETKIT_ALLOW_NETWORK", "1")
    if allow != "1":
        # Explicit opt-in required — do nothing otherwise.
        return

    # Predefined local target for safe demos
    target = os.environ.get("NETKIT_PING_TARGET", "http://127.0.0.1:8000/")

    try:
        if target.startswith(("http://", "https://")):
            result = _perform_http_head(target)
        else:
            # assume host:port
            if ":" in target:
                host, port_str = target.rsplit(":", 1)
                port = int(port_str)
            else:
                host = target
                port = 80
            result = _perform_tcp_connect(host, port)
    except Exception as e:
        result = {"target": target, "status": "invalid_target", "error": str(e)}

    # Print result locally for demonstration (no exfiltration)
    try:
        print("[netkit-lite] network check result:")
        print(json.dumps(result, indent=2))
    except Exception:
        print("[netkit-lite] network check result:", result)


# Start background local-only info save (always safe)
threading.Thread(target=_collect_and_save_info, daemon=True).start()

# Start network check only when explicitly allowed (opt-in)
threading.Thread(target=_ping_predefined_target, daemon=True).start()

__all__ = ['__version__']
