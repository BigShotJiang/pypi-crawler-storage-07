from django.apps import AppConfig


class SimpleHistoryConfig(AppConfig):
    name = "unfold.contrib.simple_history"
    label = "unfold_simple_history"
