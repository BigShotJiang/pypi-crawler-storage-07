from ._cache import Cache


def get_cache() -> Cache:
    return Cache()
