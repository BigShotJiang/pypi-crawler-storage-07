#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2025 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2025-09-17
################################################################

import os
import copy
import cv2
import numpy as np

import mujoco
from mujoco import viewer

from ..mujoco_base import HexMujocoBase
from ...zmq_base import (
    MAX_SEQ_NUM,
    hex_zmq_ts_now,
    hex_zmq_ts_delta_ms,
    HexRate,
    HexSafeValue,
)

MUJOCO_CONFIG = {
    "states_rate": 250,
    "img_rate": 30,
    "headless": False,
    "sens_ts": True,
}


class HexArcherD6yMujoco(HexMujocoBase):

    def __init__(
        self,
        mujoco_config: dict = MUJOCO_CONFIG,
    ):
        HexMujocoBase.__init__(self)

        try:
            states_rate = mujoco_config["states_rate"]
            img_rate = mujoco_config["img_rate"]
            self.__headless = mujoco_config["headless"]
            self.__sens_ts = mujoco_config["sens_ts"]
        except KeyError as ke:
            missing_key = ke.args[0]
            raise ValueError(
                f"mujoco_config is not valid, missing key: {missing_key}")

        # mujoco init
        model_path = os.path.join(os.path.dirname(__file__), "model/scene.xml")
        self.__model = mujoco.MjModel.from_xml_path(model_path)
        self.__data = mujoco.MjData(self.__model)
        self.__sim_rate = int(1.0 / self.__model.opt.timestep)

        # state init
        self.__needed_idx = [0, 1, 2, 3, 4, 5, 6]
        self._limits = self.__model.jnt_range[self.__needed_idx, :]
        self._dofs = len(self.__needed_idx)
        keyframe_id = mujoco.mj_name2id(
            self.__model,
            mujoco.mjtObj.mjOBJ_KEY,
            "home",
        )
        self.__state_init = {
            "qpos": self.__model.key_qpos[keyframe_id],
            "qvel": np.zeros(self.__model.nq),
            "ctrl": np.zeros(self.__model.nu),
        }
        self.__data.qpos = self.__state_init["qpos"]
        self.__data.qvel = self.__state_init["qvel"]
        self.__data.ctrl = self.__state_init["ctrl"]
        self.__states_trig_thresh = int(self.__sim_rate / states_rate)

        # camera init
        width, height = 640, 480
        fovy_rad = self.__model.cam_fovy[0] * np.pi / 180.0
        focal = 0.5 * height / np.tan(fovy_rad / 2.0)
        self._intri = np.array([focal, focal, width / 2, height / 2])
        self.__rgb_cam = mujoco.Renderer(self.__model, height, width)
        self.__depth_cam = mujoco.Renderer(self.__model, height, width)
        self.__depth_cam.enable_depth_rendering()
        self.__img_trig_thresh = int(self.__sim_rate / img_rate)

        # viewer init
        mujoco.mj_forward(self.__model, self.__data)
        if not self.__headless:
            self.__viewer = viewer.launch_passive(self.__model, self.__data)

        # start work loop
        self._working.set()

    def __del__(self):
        HexMujocoBase.__del__(self)

    def reset(self) -> bool:
        self.__data.qpos = self.__state_init["qpos"]
        self.__data.qvel = self.__state_init["qvel"]
        self.__data.ctrl = self.__state_init["ctrl"]
        mujoco.mj_forward(self.__model, self.__data)
        if not self.__headless:
            self.__viewer.sync()
        return True

    def work_loop(self, hex_values: list[HexSafeValue]):
        states_value = hex_values[0]
        cmds_value = hex_values[1]
        rgb_value = hex_values[2]
        depth_value = hex_values[3]

        last_states_ts = {"s": 0, "ns": 0}
        states_count = 0
        last_cmds_seq = -1
        rgb_count = 0
        depth_count = 0
        rate = HexRate(self.__sim_rate)
        states_trig_count = 0
        img_trig_count = 0
        while self._working.is_set():
            states_trig_count += 1
            if states_trig_count >= self.__states_trig_thresh:
                states_trig_count = 0

                # states
                ts, states = self.__get_states()
                if states is not None:
                    if hex_zmq_ts_delta_ms(ts, last_states_ts) > 1.0:
                        last_states_ts = ts
                        states_value.set((ts, states_count, states))
                        states_count = (states_count + 1) % MAX_SEQ_NUM

                # cmds
                cmds_pack = cmds_value.get(timeout_s=-1.0)
                if cmds_pack is not None:
                    ts, seq, cmds = cmds_pack
                    if seq > last_cmds_seq:
                        last_cmds_seq = seq
                        if hex_zmq_ts_delta_ms(hex_zmq_ts_now(), ts) < 200.0:
                            self.__set_cmds(cmds)

            img_trig_count += 1
            if img_trig_count >= self.__img_trig_thresh:
                img_trig_count = 0

                # rgb
                ts, rgb_img = self.__get_rgb()
                if rgb_img is not None:
                    rgb_value.set((ts, rgb_count, rgb_img))
                    rgb_count = (rgb_count + 1) % MAX_SEQ_NUM

                # depth
                ts, depth_img = self.__get_depth()
                if depth_img is not None:
                    depth_value.set((ts, depth_count, depth_img))
                    depth_count = (depth_count + 1) % MAX_SEQ_NUM

            # mujoco step
            mujoco.mj_step(self.__model, self.__data)
            if not self.__headless:
                self.__viewer.sync()

            # sleep
            rate.sleep()

    def __get_states(self):
        pos = copy.deepcopy(self.__data.qpos[self.__needed_idx])
        vel = copy.deepcopy(self.__data.qvel[self.__needed_idx])
        eff = copy.deepcopy(self.__data.qfrc_actuator[self.__needed_idx])
        return self.__mujoco_ts() if self.__sens_ts else hex_zmq_ts_now(
        ), np.array([pos, vel, eff]).T

    def __set_cmds(self, cmds: np.ndarray):
        self.__data.ctrl[self.__needed_idx] = cmds
        self.__data.ctrl[
            self.__needed_idx[-1]] = 0.8 - cmds[self.__needed_idx[-1]]
        self.__data.ctrl[self.__needed_idx[-1] +
                         1] = self.__data.ctrl[self.__needed_idx[-1]]

    def __get_rgb(self):
        self.__rgb_cam.update_scene(self.__data, "end_camera")
        rgb_img = self.__rgb_cam.render()
        return self.__mujoco_ts() if self.__sens_ts else hex_zmq_ts_now(
        ), cv2.cvtColor(rgb_img, cv2.COLOR_RGB2BGR)

    def __get_depth(self):
        self.__depth_cam.update_scene(self.__data, "end_camera")
        depth_img = self.__depth_cam.render()
        return self.__mujoco_ts() if self.__sens_ts else hex_zmq_ts_now(
        ), depth_img

    def __mujoco_ts(self):
        mujoco_ts = self.__data.time
        return {
            "s": int(mujoco_ts // 1),
            "ns": int((mujoco_ts % 1) * 1_000_000_000),
        }

    def close(self):
        self._working.clear()
        self.__rgb_cam.close()
        self.__depth_cam.close()
        if not self.__headless:
            self.__viewer.close()
