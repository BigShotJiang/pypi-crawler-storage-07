from setuptools import setup

setup(name='codeviscraft',
      version='0.0.2',
      description='Python mc education',
      packages=['codeviscraft'],
      author_email='barafagnus@gmail.com',
      zip_safe=False)
