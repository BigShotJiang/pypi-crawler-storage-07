from enum import Enum
class Criteria():
    AIR = "AIR"
    ARMOR = "ARMOR"
    DEATH_COUNT = "DEATH_COUNT"
    DUMMY = "DUMMY"
    FOOD = "FOOD"
    HEALTH = "HEALTH"
    LEVEL = "LEVEL"
    PLAYER_KILL_COUNT = "PLAYER_KILL_COUNT"
    TOTAL_KILL_COUNT = "TOTAL_KILL_COUNT"
    TRIGGER = "TRIGGER"
    XP = "XP"
