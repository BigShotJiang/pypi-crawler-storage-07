from enum import Enum
class BarFlag():
    CREATE_FOG = "CREATE_FOG"
    DARKEN_SKY = "DARKEN_SKY"
    PLAY_BOSS_MUSIC = "PLAY_BOSS_MUSIC"
