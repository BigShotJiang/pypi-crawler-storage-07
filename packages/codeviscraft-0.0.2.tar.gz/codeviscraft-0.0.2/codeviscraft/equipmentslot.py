from enum import Enum
class EquipmentSlot():
    FEET = "FETT"
    CHEST = "CHEST"
    HAND = "HAND"
    HEAD = "HEAD"
    LEGS = "LEGS"
    OFF_HAND = "OFF_HAND"
