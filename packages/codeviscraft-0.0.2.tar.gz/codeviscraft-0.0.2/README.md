Library for studying python minecraft
