# Open Banking, Opened | Impersonation

Impersonation Package for Open Banking, Opened API packages.
