:::fediverse_pasture_inputs.types
