# SPDX-FileCopyrightText: 2025 Helge
#
# SPDX-License-Identifier: MIT

from fediverse_pasture_inputs.types import InputData, Details, Support
from fediverse_pasture_inputs.utils import (
    pre_format,
    escape_markdown,
    pre_wrapped,
    with_tooltip,
)


html_tags = [
    "<b>bold</b>",
    "<strong>strong</strong>",
    "<i>italic</i>",
    "<em>emphasis</em>",
    "<s>stricken</s>",
    "<ol><li>ordered</li></ol>",
    "<ul><li>unordered</li></ul>",
    "<code>code</code>",
    "<pre>pre</pre>",
    "<blockquote>blockquote</blockquote>",
    "line<br>break",
    "<p>paragraph</p>",
]

examples = [{"content": content} for content in html_tags] + [
    {
        "content": """link with class hashtag
        
<a href="https://tags.test/test" class="hashtag">#test</a>""",
        "tag": [{"type": "Hashtag", "name": "#test"}],
    },
    {
        "content": """link with class mention

<a href="http://pasture-one-actor/actor" class="mention">@actor@pastue-one-actor</a>""",
        "tag": [
            {
                "type": "Mention",
                "name": "@actor@pasture-one-server",
                "href": "http://pasture-one-actor/actor",
            }
        ],
    },
]

details = Details(
    extractor={
        "activity": lambda x: pre_format(
            x.get("object", {}).get("content"), pre_wrap=True
        ),
        "mastodon": lambda x: pre_format(x.get("content"), pre_wrap=True),
        "misskey": lambda x: pre_format(escape_markdown(x.get("text")), pre_wrap=True),
    },
    title={
        "mastodon": "| content | content | Example |",
        "misskey": "| content | text | Example |",
    },
)


def mastodon_support(entry: dict, activity: dict = {}):
    if entry is None or len(entry) == 0:
        return "❌"

    content = activity.get("object", {}).get("content")
    entry_content = entry.get("content")

    if content == entry_content:
        return "✅"

    return with_tooltip("❓", entry_content)


def support_activity(activity):
    content = activity.get("object", {}).get("content")
    content = content.split("\n")[0]
    return pre_wrapped(content, False)


support = Support(
    title="content",
    result={
        "activity": support_activity,
        "misskey": lambda x: with_tooltip("❓", x.get("text")),
        "mastodon": mastodon_support,
    },
)

data = InputData(
    title="Basic HTML tags",
    frontmatter="""A main focus of the Fediverse is microblogging, using objects
of type `Note` to represent posts. This support table shows a set of tags, that
we consider reasonable to support for such a purpose.

The ✅ means that the html tag was left unchanged. ❓ indicates the content was changed,
by hovering over it, one can see into what.

❓ for misskey is due us not supporting checking markdown yet.
""",
    filename="html_tags_base.md",
    group="HTML Tags",
    examples=examples,
    details=details,
    support=support,
)
