from collections import defaultdict

from fediverse_pasture_inputs import available
from fediverse_pasture_inputs.types import InputData

group_names = [
    "Recommended Objects",
    "HTML Tags",
    "Object Content",
    "Object Properties",
    "Technical Properties",
]


def order_available_by_group() -> dict[str, list[InputData]]:
    result = defaultdict(list)

    for _, input_data in available.items():
        result[input_data.group].append(input_data)

    return {key: sorted(value, key=lambda x: x.title) for key, value in result.items()}


def compute_number_group(group: list[InputData]):
    return sum(len(x.examples) for x in group)


def navigation_string(prefix: str = "") -> list[str]:
    result = []

    ordered_by_group = order_available_by_group()

    for name in group_names:
        result.append(f"""- "{name}":\n""")

        for entry in ordered_by_group[name]:
            result.append(f"""  - "{entry.title}": "{prefix}{entry.filename}"\n""")

    return result


def to_table_line(strings: list[str]) -> str:
    center = " | ".join(strings)
    return f"| {center} |\n"


def create_input_table(prefix: str = "inputs/") -> list[str]:
    ordered_by_group = order_available_by_group()

    titles = ["Name", "Number of inputs", "short name"]
    headers = ["---", "---:", "---"]

    total = sum(compute_number_group(group) for group in ordered_by_group.values())
    total_line = ["total", str(total), ""]

    result = [titles, headers, total_line]

    for name in group_names:
        group = ordered_by_group[name]
        line_entries = [
            f"<center>__{name}__</center>",
            str(compute_number_group(group)),
            "",
        ]
        result.append(line_entries)
        for entry in group:
            link = f"[{entry.title}]({prefix}{entry.filename})"
            line_entries = [
                link,
                str(len(entry.examples)),
                entry.filename.removesuffix(".md"),
            ]
            result.append(line_entries)

    return [to_table_line(x) for x in result]
