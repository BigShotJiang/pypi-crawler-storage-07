"""Toy example ImagingExtractor and SegmentationExtractor for testing.

Modules
-------
toy_example
    Create a toy example of an ImagingExtractor and a SegmentationExtractor.

Functions
---------
toy_example
    Create a toy example of an ImagingExtractor and a SegmentationExtractor.
"""

from .toy_example import toy_example
