#!/usr/bin/env bash

set -e

source /test.venv/bin/activate

pip install --upgrade pip wheel setuptools setuptools-scm twine build packaging

python -m build
twine check dist/*

# do a test install from both source and wheel
sdist=`find dist -maxdepth 1 -name *.tar.gz`
wheel=`find dist -maxdepth 1 -name *.whl`

deactivate

for target in $sdist $wheel; do
    ${PY_VENV} pypi_test.venv
    . pypi_test.venv/bin/activate
    pip install --upgrade pip setuptools
    pip install $target
    deactivate
    rm -r pypi_test.venv
done
