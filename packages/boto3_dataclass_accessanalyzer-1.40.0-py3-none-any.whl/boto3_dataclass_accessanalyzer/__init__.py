# -*- coding: utf-8 -*-

from .caster import accessanalyzer_caster

caster = accessanalyzer_caster

__version__ = "1.40.0"