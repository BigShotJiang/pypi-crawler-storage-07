# ARZ PLUS CLI

ابزار خط فرمانی برای دریافت **نرخ لحظه‌ای ارز، کریپتو و طلا** از alanchand.com

## نصب

```bash
pip install arzplus