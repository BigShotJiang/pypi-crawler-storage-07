# -*- coding: utf-8 -*-

from .caster import migrationhub_config_caster

caster = migrationhub_config_caster

__version__ = "1.40.0"