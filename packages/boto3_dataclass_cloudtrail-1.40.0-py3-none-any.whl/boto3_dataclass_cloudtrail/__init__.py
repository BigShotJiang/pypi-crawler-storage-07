# -*- coding: utf-8 -*-

from .caster import cloudtrail_caster

caster = cloudtrail_caster

__version__ = "1.40.0"