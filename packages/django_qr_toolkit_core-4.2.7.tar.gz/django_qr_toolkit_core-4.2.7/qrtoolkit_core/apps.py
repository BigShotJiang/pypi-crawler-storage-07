from django.apps import AppConfig


class QrtoolkitModelsConfig(AppConfig):
    name = 'qrtoolkit_core'
