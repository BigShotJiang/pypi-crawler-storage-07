from .roots import MLuaBase


class MLuaError(MLuaBase, Exception):

    def __init__(self, message) -> None:
        self.message = message

    __str__ = lambda self: self.message


class MLuaModuleError(MLuaError):

    def __init__(self, message) -> None:
        super().__init__(message)


class MLuaRuntimeError(MLuaError):

    def __init__(self, message) -> None:
        super().__init__(message)
