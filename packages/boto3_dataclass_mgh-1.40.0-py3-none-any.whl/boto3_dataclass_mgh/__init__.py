# -*- coding: utf-8 -*-

from .caster import mgh_caster

caster = mgh_caster

__version__ = "1.40.0"