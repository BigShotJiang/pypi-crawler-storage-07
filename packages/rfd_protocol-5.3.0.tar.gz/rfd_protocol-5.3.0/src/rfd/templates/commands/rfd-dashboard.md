---
description: Show project dashboard with features, progress, and statistics
allowed-tools: Bash(rfd dashboard)
---

# RFD Project Dashboard

Displays comprehensive project status including:
- Progress statistics
- Feature statuses
- Current focus
- Completion rates

All data comes from the database - no manual tracking needed!

!rfd dashboard