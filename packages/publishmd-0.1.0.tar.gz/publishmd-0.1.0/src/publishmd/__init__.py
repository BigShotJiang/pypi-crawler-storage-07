"""publishmd - Prepare markdown content for publication."""

__version__ = "0.1.0"
