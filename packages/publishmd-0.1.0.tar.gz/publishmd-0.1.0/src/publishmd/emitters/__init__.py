"""Emitters package."""
