import time
from nlbone.adapters.messaging.event_bus import OutboxDispatcher

def main(dispatcher: OutboxDispatcher, interval_sec: int = 2):
    while True:
        count = dispatcher.run_once()
        time.sleep(interval_sec)