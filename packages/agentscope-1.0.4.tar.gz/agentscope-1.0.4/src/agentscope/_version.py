# -*- coding: utf-8 -*-
"""The version of agentscope."""

__version__ = "1.0.4"
