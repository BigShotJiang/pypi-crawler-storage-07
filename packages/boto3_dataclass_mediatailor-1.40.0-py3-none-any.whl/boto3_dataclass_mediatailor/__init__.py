# -*- coding: utf-8 -*-

from .caster import mediatailor_caster

caster = mediatailor_caster

__version__ = "1.40.0"