# -*- coding: utf-8 -*-

from .caster import neptunedata_caster

caster = neptunedata_caster

__version__ = "1.40.0"