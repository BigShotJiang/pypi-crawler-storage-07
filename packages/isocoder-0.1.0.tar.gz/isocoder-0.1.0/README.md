# isocoder

Tiny client for the Isocoder Modal backend that spins up a GPU worker to train TVAE and uploads artifacts to Hugging Face.

## Install

```bash
pip install isocoder
```