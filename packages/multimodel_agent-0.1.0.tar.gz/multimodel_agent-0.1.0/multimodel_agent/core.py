# multimodel_agent/core.py

class MultimodelAgent:
    """A simple multimodel AI agent that can use multiple models for inference."""
    def __init__(self, models=None):
        self.models = models or []

    def add_model(self, model):
        self.models.append(model)

    def predict(self, input_data):
        results = []
        for model in self.models:
            results.append(model.predict(input_data))
        return results
