# multimodel_agent/__init__.py
from .core import MultimodelAgent
