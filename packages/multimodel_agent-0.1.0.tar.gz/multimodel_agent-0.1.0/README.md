# Multimodel Agent

A robust Python package for building multimodel AI agents that leverage multiple models for advanced inference and decision-making.

## Installation

```bash
pip install multimodel_agent
```

## Usage

```python
from multimodel_agent import MultimodelAgent

class MyModel:
    def predict(self, data):
        # Replace with your model's prediction logic
        return data + 1

# Initialize the agent with one or more models
agent = MultimodelAgent([MyModel()])

# Run inference using all models
results = agent.predict(42)
print(results)  # Output: [43]
```

## Publishing to PyPI

1. Create and activate a virtual environment:
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```
2. Install build and twine:
   ```bash
   pip install --upgrade build twine
   ```
3. Build the package:
   ```bash
   python3 -m build
   ```
4. Upload to PyPI:
   ```bash
   python3 -m twine upload dist/*
   ```

You will need a PyPI account and API token for uploading.
