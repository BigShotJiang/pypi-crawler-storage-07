# -*- coding: utf-8 -*-

from .caster import kinesis_caster

caster = kinesis_caster

__version__ = "1.40.0"