"""Tests for tuitorial."""
