# Changelog

## [2.0.1](https://github.com/serafinovsky/fastapi-redis-utils/compare/v2.0.0...v2.0.1) (2025-09-28)


### Bug Fixes

* **deps:** bump the all-pip-deps group with 3 updates ([#13](https://github.com/serafinovsky/fastapi-redis-utils/issues/13)) ([9bde991](https://github.com/serafinovsky/fastapi-redis-utils/commit/9bde991517daa88c738707c1ca7b7fae3075a36c))

## [2.0.0](https://github.com/serafinovsky/fastapi-redis-utils/compare/v1.2.5...v2.0.0) (2025-09-26)


### ⚠ BREAKING CHANGES

* 

### Features

* remove ensure_connection; pure health_check; simplify get_ttl; DRY mget; update docs/tests ([#11](https://github.com/serafinovsky/fastapi-redis-utils/issues/11)) ([16eb3f5](https://github.com/serafinovsky/fastapi-redis-utils/commit/16eb3f595c8e31ec0891a4ae64cb9fab129d29c7))

## [1.2.5](https://github.com/serafinovsky/fastapi-redis-utils/compare/v1.2.4...v1.2.5) (2025-09-23)


### Bug Fixes

* fix publish ([#8](https://github.com/serafinovsky/fastapi-redis-utils/issues/8)) ([7b5bf01](https://github.com/serafinovsky/fastapi-redis-utils/commit/7b5bf017a3e55b3edf732c33304666682aaa7741))

## [1.2.4](https://github.com/serafinovsky/fastapi-redis-utils/compare/v1.2.3...v1.2.4) (2025-09-23)


### Bug Fixes

* **deps:** bump the all-pip-deps group with 10 updates ([#6](https://github.com/serafinovsky/fastapi-redis-utils/issues/6)) ([7d33138](https://github.com/serafinovsky/fastapi-redis-utils/commit/7d33138ab47eb300ae1c34844e32ad4723778f91))
* **deps:** downdate fastapi for dependabot test ([236e4da](https://github.com/serafinovsky/fastapi-redis-utils/commit/236e4da7074437e0afca28d3a6ee0c95f728756b))
* **deps:** downdate fastapi for dependabot test ([657fac6](https://github.com/serafinovsky/fastapi-redis-utils/commit/657fac69d125e85f6d31723377ee5977d007356a))
* **deps:** downdate fastapi for dependabot test ([8bdacc1](https://github.com/serafinovsky/fastapi-redis-utils/commit/8bdacc1da9564c3219d6bb0ea1142af2e7a2c27f))
* **deps:** downdate fastapi for dependabot test ([15a3df7](https://github.com/serafinovsky/fastapi-redis-utils/commit/15a3df7789e71e1d43156cb2da9c96fc84693aab))
* **deps:** downdate fastapi for dependabot test ([ce31855](https://github.com/serafinovsky/fastapi-redis-utils/commit/ce318557fb4ceda5e8a683da8b5845ecf8b325c4))
