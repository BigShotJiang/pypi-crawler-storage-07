# This file is part of daf_relation.
#
# Developed for the LSST Data Management System.
# This product includes software developed by the LSST Project
# (http://www.lsst.org).
# See the COPYRIGHT file at the top-level directory of this distribution
# for details of code ownership.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

from __future__ import annotations

__all__ = (
    "EngineError",
    "ColumnError",
    "RelationalAlgebraError",
)


class RelationalAlgebraError(RuntimeError):
    """Exception type raised to indicate problems in the definition of a
    relation tree.
    """


class EngineError(RelationalAlgebraError):
    """Exception type raised to indicate that a relation tree is incompatible
    with an engine, or has inconsistent engines.
    """


class ColumnError(RelationalAlgebraError):
    """Exception type raised to indicate problems in a relation's columns
    and/or unique keys.
    """
