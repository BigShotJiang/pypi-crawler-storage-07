import os

BOOKING_AGENT_TOPIC_ARN = os.environ.get("BOOKING_AGENT_SNS_ARN")
