# -*- coding: utf-8 -*-

from .caster import athena_caster

caster = athena_caster

__version__ = "1.40.0"