import logging

from mylib import awesome

logging.basicConfig(level=logging.WARNING)
# logging.basicConfig(level=logging.DEBUG)

awesome()
