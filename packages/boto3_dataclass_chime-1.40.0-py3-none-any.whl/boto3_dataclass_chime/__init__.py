# -*- coding: utf-8 -*-

from .caster import chime_caster

caster = chime_caster

__version__ = "1.40.0"