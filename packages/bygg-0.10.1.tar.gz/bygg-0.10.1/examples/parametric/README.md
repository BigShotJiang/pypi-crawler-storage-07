# Parametric example

Simple example for generating and "building" a lot of files to test system
behaviour.

This is not a good, clean example of how to write and structure a Byggfile.py
since the generating of the input files reduces clarity.

However, it is still useful for testing purposes to be able to test
dependencies and output.

See the start of Byggfile.py in this directory for documentation of the various
parameters that can be set.
