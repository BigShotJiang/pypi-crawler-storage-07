from setuptools import setup, find_packages

setup(
    name="hyperpanda",
    version="0.1.0",
    description="Pandas to Tableau .hyper extract conversion using Tableau Hyper API",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Your Name",
    url="https://github.com/yourusername/hyperpanda",
    packages=find_packages(),
    install_requires=[
        "pandas>=1.0.0",
        "tableauhyperapi",
    ],
    python_requires=">=3.7",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "License :: OSI Approved :: MIT License",
    ],
)
