from __future__ import print_function

import re
from pathlib import Path
import logging
import pandas as pd

from tableauhyperapi import (
    Telemetry,
    CreateMode,
    HyperProcess,
    Connection,
    SqlType,
    TableDefinition,
    Inserter,
)

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)


def escape_name(name: str) -> str:
    """
    Escape column or table names for SQL safety by replacing special characters.

    Parameters
    ----------
    name : str
        The name to escape.

    Returns
    -------
    str
        The escaped name.
    """
    return '"' + re.sub(r"([^a-zA-Z0-9_])", "_", name) + '"'


class HyperPanda:
    """
    Converts a pandas DataFrame to a Tableau .hyper extract with support for spatial columns.

    Parameters
    ----------
    dataframe : pd.DataFrame
        The input pandas DataFrame to convert.
    geo_columns : list[str]
        List of column names in the DataFrame that should be treated as geography types.
    """

    mapper = {
        "string": SqlType.text(),
        "bytes": SqlType.bool(),
        "bool": SqlType.bool(),
        "floating": SqlType.double(),
        "float64": SqlType.double(),
        "integer": SqlType.int(),
        "Int64": SqlType.big_int(),  # Nullable int64 type
        "int64": SqlType.big_int(),  # Numpy int64 type
        "decimal": SqlType.double(),
        "boolean": SqlType.bool(),
        "dbdate": SqlType.date(),
        "datetime64[ns]": SqlType.timestamp(),
        "datetime": SqlType.timestamp(),
        "date": SqlType.date(),
        "timedelta64": SqlType.timestamp(),
        "timedelta": SqlType.timestamp(),
        "time": SqlType.timestamp(),
    }

    def __init__(self, dataframe: pd.DataFrame, geo_columns: list[str]):
        if not isinstance(dataframe, pd.DataFrame):
            raise TypeError("Input must be a pandas DataFrame")

        self._dataframe = dataframe.fillna(0)
        self._geo_columns = geo_columns or []
        self._column_mappings = []
        self._inserter_definition = []
        self._column_names = list(self._dataframe.columns)

    def to_tableau(self, path: str, table_name: str = "Extract"):
        """
        Generate a Tableau .hyper extract from the DataFrame.

        Parameters
        ----------
        path : str
            Path to write the .hyper file.
        table_name : str, optional
            Name of the table inside the extract, by default "Extract"
        """
        logger.info(f"Starting Tableau extract creation: {path}")
        self.delete_existing_files(path)

        with HyperProcess(Telemetry.SEND_USAGE_DATA_TO_TABLEAU) as hyper:
            with Connection(
                hyper.endpoint, path, CreateMode.CREATE_AND_REPLACE
            ) as connection:
                self.create_table_in_extract(connection, table_name)
                self.insert_data_into_table(connection, table_name, self._dataframe)

        logger.info(f"Finished writing Tableau extract to {path}")

    def delete_existing_files(self, path: str):
        """
        Delete existing DataExtract logs and temporary Hyper DB files.

        Parameters
        ----------
        path : str
            Path where the .hyper file will be created.
        """
        logger.debug("Deleting old DataExtract logs and temp files if exist.")
        paths = (
            list(Path().glob("DataExtract*.log"))
            + list(Path().glob("hyper_db_*"))
            + [
                Path(path).parent / "debug.log",
                Path("DataExtract.log"),
                Path("debug.log"),
            ]
        )
        for file_path in paths:
            if file_path.is_file():
                logger.debug(f"Removing file: {file_path}")
                file_path.unlink()

    def create_table_in_extract(self, connection: Connection, table_name: str):
        """
        Create the schema and table definition within the Tableau extract file.

        Parameters
        ----------
        connection : Connection
            Active Hyper API connection.
        table_name : str
            Name of the table to create.
        """
        logger.info(f"Creating schema and table '{table_name}'")
        connection.catalog.create_schema("Extract")
        table_definition = TableDefinition(table_name)
        self._preprocess_dataframe()

        for col_name, col_type in zip(self._dataframe.columns, self._dataframe.dtypes):
            tableau_type = self.mapper.get(str(col_type), SqlType.text())
            self._inserter_definition.append(
                TableDefinition.Column(name=col_name, type=tableau_type)
            )
            if col_name in self._geo_columns:
                self._column_mappings.append(
                    Inserter.ColumnMapping(
                        col_name, f"CAST({escape_name(col_name)} AS GEOGRAPHY)"
                    )
                )
                table_definition.add_column(col_name, SqlType.geography())
            else:
                table_definition.add_column(col_name, tableau_type)
                self._column_mappings.append(col_name)

        connection.catalog.create_table(table_definition)

    def insert_data_into_table(
        self, connection: Connection, table_name: str, dataframe: pd.DataFrame
    ):
        """
        Insert DataFrame rows into the Tableau extract table.

        Parameters
        ----------
        connection : Connection
            Active Hyper API connection.
        table_name : str
            Table name to insert into.
        dataframe : pd.DataFrame
            Data to insert.
        """
        logger.info(f"Inserting {len(dataframe)} rows into table '{table_name}'")
        with Inserter(
            connection,
            table_name,
            self._column_mappings,
            inserter_definition=self._inserter_definition,
        ) as inserter:
            for row in dataframe.itertuples(index=False):
                inserter.add_row(row)
            inserter.execute()

    def _preprocess_dataframe(self):
        """
        Convert object columns to numeric when possible and infer data types.
        """
        logger.debug("Preprocessing DataFrame: converting object columns to numeric")
        for col in self._dataframe.columns:
            if self._dataframe[col].dtype == "object":
                self._dataframe[col] = pd.to_numeric(
                    self._dataframe[col], errors="coerce"
                ).fillna(0)
        self._dataframe = self._dataframe.infer_objects()
