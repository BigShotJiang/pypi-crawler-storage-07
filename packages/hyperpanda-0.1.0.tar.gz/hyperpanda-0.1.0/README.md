# HyperPanda

**A quick and easy way to convert a Pandas DataFrame to a Tableau .hyper extract using the Tableau Hyper API with support for spatial columns.**

---

## Overview

HyperPanda is a Python utility to convert Pandas DataFrames into Tableau `.hyper` extract files. It refactors and modernizes the original [pandleau](https://github.com/bwiley1/pandleau) project by using the up-to-date Tableau Hyper API instead of the deprecated Tableau SDK. Additionally, it supports spatial/geospatial columns mapped to Tableau's `GEOGRAPHY` type.

---

## Features

- Converts standard Pandas DataFrame columns to appropriate Tableau Hyper SQL types.
- Supports nullable and big integers.
- Automatically converts columns with numeric data stored as `object` dtype.
- Supports spatial data by casting specified columns as Tableau `GEOGRAPHY`.
- Cleans up old extract logs and temporary files before writing.

---

## Installation

```shell
    pip install hyperpanda
```

---

## Usage

```python
    import pandas as pd
    from hyperpanda import HyperPanda

    # Create your pandas DataFrame
    df = pd.DataFrame({...})

    # Specify columns that contain spatial data
    geo_columns = ['location_column']

    # Create HyperPanda object
    hp = HyperPanda(df, geo_columns)

    # Convert to Tableau .hyper extract
    hp.to_tableau("output.hyper")
```

---

## Credit

This package is a refactored and enhanced continuation of the [pandleau](https://github.com/bwiley1/pandleau) project originally developed by Benjamin Wiley (@jamin4lyfe). It updates the project to use the Tableau Hyper API for better compatibility and future-proofing.

---

## License

This project is licensed under the MIT License. See the LICENSE file for details.

---
