import sys
import os
from setuptools import setup, Extension
from setuptools.command.build_ext import build_ext

# Ensure MACOSX_DEPLOYMENT_TARGET is set to 11.0 or higher to avoid JUCE errors
os.environ['MACOSX_DEPLOYMENT_TARGET'] = '11.0'

class BuildExt(build_ext):
    def build_extensions(self):
        compiler = self.compiler.compiler_type
        print(f"Using compiler: {compiler}")

        for ext in self.extensions:
            # Add macOS deployment target flags
            if sys.platform == 'darwin':
                ext.extra_compile_args.append('-mmacosx-version-min=11.0')
                ext.extra_link_args.append('-mmacosx-version-min=11.0')

            # Use C++17 standard
            ext.extra_compile_args.append('-std=c++17')

            # Use libc++ standard library on macOS
            ext.extra_compile_args.append('-stdlib=libc++')
            ext.extra_link_args.append('-stdlib=libc++')

            # Optional: you can add other flags here if needed
            # ext.extra_compile_args.append('-Wall')

        build_ext.build_extensions(self)

# Define your extension module here, update the sources and include_dirs accordingly
ext_modules = [
    Extension(
        'vsthost',  # Change this to your actual module name
        sources=[
            'Source/PluginHost.cpp',          # Add your JUCE C++ source files here
            # 'src/other_file.cpp',
            # Add all other source files your module needs
        ],
        include_dirs=[
            '/Users/sundaychol/Downloads/JUCE/modules',
            '/Volumes/Media ONE I/Kushral/surgeHost/JuceLibraryCode',
            '/Library/Frameworks/Python.framework/Versions/3.13/lib/python3.13/site-packages/pybind11/include'

        ],
        language='c++',
        extra_compile_args=[
            # Start empty, the flags will be added in build_ext
        ],
        extra_link_args=[
            # Start empty, flags added in build_ext
        ],
        # libraries=[],        # Add if you link to any external libs
        # library_dirs=[],     # Add if needed
    )
]

setup(
    name='vsthost',    # Your package name here
    version='0.1.2',
    author='Sinesurge',
    author_email='sinesurgeproducts@gmail.com',
    description='A c++ written python module for VST instrument hosting for Macos',
    ext_modules=ext_modules,
    cmdclass={'build_ext': BuildExt},
    zip_safe=False,
    python_requires='>=3.6',
    setup_requires=['setuptools>=42', 'wheel'],  # modern setuptools & wheel
    install_requires=[
        # Add your Python dependencies here if any
    ],
)
