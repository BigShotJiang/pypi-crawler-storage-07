Running all stages
==================

About
-----
