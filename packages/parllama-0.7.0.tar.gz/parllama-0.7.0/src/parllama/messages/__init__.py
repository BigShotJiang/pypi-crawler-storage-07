"""TUI messages module."""

from __future__ import annotations

__all__: list[str] = []
