"""Par LLAMA TUI dialogs package."""

from __future__ import annotations

__all__: list[str] = []
