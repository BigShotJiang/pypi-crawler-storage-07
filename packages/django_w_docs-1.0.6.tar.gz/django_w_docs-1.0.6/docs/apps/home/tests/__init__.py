"""Tests for docs.home"""
