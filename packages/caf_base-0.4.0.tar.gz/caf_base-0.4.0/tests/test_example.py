# -*- coding: utf-8 -*-
"""Tests for the {} module"""
# Built-Ins

# Third Party

# # # CONSTANTS # # #


# # # FIXTURES # # #


# # # TESTS # # #
class TestFunctionName:
    def test_something(self):
        assert True
