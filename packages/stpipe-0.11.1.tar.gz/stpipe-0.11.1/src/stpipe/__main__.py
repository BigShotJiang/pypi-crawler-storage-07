from .cli.main import main

# main() always raises SystemExit, so we don't need
# to perform any exception handling here.
main()
