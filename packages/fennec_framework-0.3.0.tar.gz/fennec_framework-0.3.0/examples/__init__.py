"""
Example applications
"""
