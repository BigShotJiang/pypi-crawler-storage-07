# Changelog

## [0.3.0] - 2025-10-04

**BREAKING CHANGE**: Added PEP 257 compliance for blank lines after docstrings
- Docstrings now follow PEP 257: blank line required after docstrings before first statement
- Removed special suppression of blank lines after docstrings in function/class bodies
- Aligns with Ruff's formatting expectations for docstring spacing

## [0.2.1] - 2025-01-26

- Added `--quiet` flag to suppress all output except errors
- Fixed missing Statement import in rules.py

## [0.2.0] - 2025-01-26

- Added configurable indent width detection (default 2 spaces, configurable via `indent_width`)
- Added atomic file operations with temporary files for safer processing
- Added CLI `--dry-run` flag to preview changes without applying them
- Added CLI `--verbose` flag for detailed processing information
- Added specific exception handling for file operations (encoding, permissions, I/O errors)
- Implemented singleton configuration pattern for cleaner code architecture
- Added pre-compiled regex patterns for improved performance
- Added end-of-file newline preservation to maintain existing file formatting
- Renamed `tab_width` to `indent_width` for clarity (breaking change)
- Major code quality improvements and critical issue fixes

## [0.1.3] - 2025-01-09

- Fixed blank lines being incorrectly added after multi-line docstrings in function bodies

## [0.1.2] - 2025-01-09

- Fixed blank lines being removed between consecutive class methods
- Added --version flag to display version from pyproject.toml
- Fixed blank lines after docstrings in function bodies
- Fixed internal blank lines being removed from multi-line docstrings
- Fixed comment block "leave-as-is" behavior for blank line preservation

## [0.1.1] - 2025-01-09

- Initial release