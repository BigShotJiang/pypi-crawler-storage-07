# This file marks the 'location' directory as a Python package.
from .geolocation import geolocate_ip
