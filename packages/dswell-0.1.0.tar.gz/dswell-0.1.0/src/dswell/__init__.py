"""
dswell - Delayed file deletion utility
"""

__version__ = "0.1.0"
