example-package-alex
--------------------

# Summary

This is an example package for configuring, testing, and publishing a PyPi package.
