from kirin import ir

_dialect = ir.Dialect("pauli")
