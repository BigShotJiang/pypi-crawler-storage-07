"""Type inference analysis for kirin."""

from .solve import TypeResolution as TypeResolution
from .analysis import TypeInference as TypeInference
