from kirin.exception import StaticCheckError


class BuildError(StaticCheckError):
    """Base class for all dialect lowering errors."""

    pass
