# -*- coding: utf-8 -*-

from .caster import ebs_caster

caster = ebs_caster

__version__ = "1.40.0"