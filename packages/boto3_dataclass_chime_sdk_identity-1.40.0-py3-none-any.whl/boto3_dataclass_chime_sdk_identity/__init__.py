# -*- coding: utf-8 -*-

from .caster import chime_sdk_identity_caster

caster = chime_sdk_identity_caster

__version__ = "1.40.0"