# -*- coding: utf-8 -*-

from .caster import fis_caster

caster = fis_caster

__version__ = "1.40.0"