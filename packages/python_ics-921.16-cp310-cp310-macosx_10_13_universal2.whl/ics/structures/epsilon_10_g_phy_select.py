# This file was auto generated; Do not modify, if you value your sanity!
import ctypes
import enum



class epsilon_10_g_phy_select(enum.IntEnum):
    """A ctypes-compatible IntEnum superclass."""
    @classmethod
    def from_param(cls, obj):
        return int(obj)

    EPSILON_10G_PHY1  = (1<<0)
    EPSILON_10G_PHY2  = (1<<1)


Epsilon_10G_PHY_select = epsilon_10_g_phy_select

