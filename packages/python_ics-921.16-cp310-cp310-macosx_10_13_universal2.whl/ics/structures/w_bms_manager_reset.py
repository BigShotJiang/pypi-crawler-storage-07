# This file was auto generated; Do not modify, if you value your sanity!
import ctypes
import enum



class w_bms_manager_reset(ctypes.Structure):
    _pack_ = 2
    _fields_ = [
        ('managerIndex', ctypes.c_uint8),
    ]


_wBMSManagerReset = w_bms_manager_reset
wBMSManagerReset = w_bms_manager_reset

