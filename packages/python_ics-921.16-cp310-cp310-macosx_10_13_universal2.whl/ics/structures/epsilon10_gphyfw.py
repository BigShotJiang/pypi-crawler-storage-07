# This file was auto generated; Do not modify, if you value your sanity!
import ctypes
import enum



class epsilon10_gphyfw(enum.IntEnum):
    """A ctypes-compatible IntEnum superclass."""
    @classmethod
    def from_param(cls, obj):
        return int(obj)

    FLASH_ACCESSORY_EPSILON_10G_PHY_FW_0_3_7_0 = 0


_epsilon10GPHYFW = epsilon10_gphyfw
epsilon10GPHYFW = epsilon10_gphyfw

