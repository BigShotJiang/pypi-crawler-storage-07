import os
import pytest
import tempfile
from pathlib import Path
from unittest.mock import patch, mock_open
from langlint.core.config import Config, ConfigError, TranslatorType, TranslatorConfig, PathConfig

def test_default_config():
    """测试默认配置"""
    config = Config()
    assert config.translator == TranslatorType.OPENAI
    assert config.target_lang == "EN-US"
    assert config.source_lang == ["zh", "ja", "ko"]
    assert config.max_workers == 4
    assert config.cache_enabled is True
    assert config.verbose is False
    assert config.dry_run is False
    assert config.backup is True

def test_translator_config():
    """测试翻译器配置"""
    config = Config()
    assert len(config.translators) == 5
    
    openai_config = config.get_translator_config(TranslatorType.OPENAI)
    assert openai_config.type == TranslatorType.OPENAI
    assert openai_config.model == "gpt-3.5-turbo"

def test_path_config_matching():
    """测试路径配置匹配"""
    config = Config()
    
    # 添加测试路径配置
    config.path_configs = [
        PathConfig(pattern="**/test/*.py", translator=TranslatorType.GOOGLE),
        PathConfig(pattern="**/docs/*.md", target_lang="CN")
    ]
    
    # 测试匹配
    test_file_config = config.get_path_config("project/test/example.py")
    assert test_file_config is not None
    assert test_file_config.translator == TranslatorType.GOOGLE
    
    docs_file_config = config.get_path_config("project/docs/readme.md")
    assert docs_file_config is not None
    assert docs_file_config.target_lang == "CN"
    
    # 测试不匹配
    no_match_config = config.get_path_config("project/src/main.py")
    assert no_match_config is None

def test_config_validation():
    """测试配置验证"""
    # 使用 MOCK 翻译器绕过 API 密钥验证
    config = Config()
    config.translator = TranslatorType.MOCK
    config.validate()
    
    # 测试目标语言为空
    with pytest.raises(ConfigError, match="target_lang cannot be empty"):
        config_empty_target = Config()
        config_empty_target.translator = TranslatorType.MOCK
        config_empty_target.target_lang = ""
        config_empty_target.validate()
    
    # 测试源语言为空
    with pytest.raises(ConfigError, match="source_lang cannot be empty"):
        config_empty_source = Config()
        config_empty_source.translator = TranslatorType.MOCK
        config_empty_source.source_lang = []
        config_empty_source.validate()

def test_env_variable_override(monkeypatch):
    """测试环境变量覆盖配置"""
    monkeypatch.setenv("LANGINT_TRANSLATOR", "deepl")
    monkeypatch.setenv("LANGINT_TARGET_LANG", "CN")
    monkeypatch.setenv("LANGINT_SOURCE_LANG", "en,fr")
    monkeypatch.setenv("LANGINT_MAX_WORKERS", "8")
    monkeypatch.setenv("LANGINT_VERBOSE", "true")
    monkeypatch.setenv("LANGINT_DRY_RUN", "1")
    
    config = Config()
    config._load_from_env()
    
    assert config.translator == TranslatorType.DEEPL
    assert config.target_lang == "CN"
    assert config.source_lang == ["en", "fr"]
    assert config.max_workers == 8
    assert config.verbose is True
    assert config.dry_run is True

def test_config_load_no_file(tmp_path):
    """测试没有配置文件时的加载行为"""
    # 切换到临时目录
    monkeypatch = pytest.MonkeyPatch()
    monkeypatch.chdir(tmp_path)
    
    config = Config.load()
    assert isinstance(config, Config)
    # 应该返回默认配置
    assert config.translator == TranslatorType.OPENAI

def test_config_load_invalid_file(tmp_path):
    """测试加载无效配置文件"""
    invalid_config_path = tmp_path / "pyproject.toml"
    invalid_config_path.write_text("invalid toml content")
    
    with pytest.raises(ConfigError):
        Config.load(invalid_config_path)

def test_config_load_with_toml(tmp_path):
    """测试从 TOML 文件加载配置"""
    config_path = tmp_path / "pyproject.toml"
    config_path.write_text("""
    [tool.langlint]
    translator = "deepl"
    target_lang = "CN"
    source_lang = ["en", "fr"]
    
    [tool.langlint."**/*.py"]
    translator = "google"
    target_lang = "EN"
    """)
    
    config = Config.load(config_path)
    
    assert config.translator == TranslatorType.DEEPL
    assert config.target_lang == "CN"
    assert config.source_lang == ["en", "fr"]
    
    # 测试路径特定配置
    assert len(config.path_configs) == 1
    path_config = config.path_configs[0]
    assert path_config.pattern == "**/*.py"
    assert path_config.translator == TranslatorType.GOOGLE
    assert path_config.target_lang == "EN"


def test_config_load_nonexistent_file():
    """测试加载不存在的配置文件"""
    with pytest.raises(ConfigError, match="Configuration file not found"):
        Config.load("nonexistent_file.toml")


def test_config_load_with_invalid_translator(tmp_path):
    """测试加载包含无效翻译器类型的配置"""
    config_path = tmp_path / "pyproject.toml"
    config_path.write_text("""
    [tool.langlint]
    translator = "invalid_translator"
    """)
    
    with pytest.raises(ConfigError, match="Invalid translator type"):
        Config.load(config_path)


def test_config_load_with_path_config_invalid_translator(tmp_path):
    """测试路径配置中包含无效翻译器"""
    config_path = tmp_path / "pyproject.toml"
    config_path.write_text("""
    [tool.langlint]
    translator = "mock"
    
    [tool.langlint."**/*.py"]
    translator = "invalid_translator"
    """)
    
    with pytest.raises(ConfigError, match="Invalid translator type"):
        Config.load(config_path)


def test_config_load_with_all_path_config_options(tmp_path):
    """测试加载包含所有路径配置选项的配置"""
    config_path = tmp_path / "pyproject.toml"
    config_path.write_text("""
    [tool.langlint]
    translator = "mock"
    
    [tool.langlint."**/*.py"]
    translator = "google"
    target_lang = "EN"
    source_lang = ["zh", "ja"]
    enabled = false
    
    [tool.langlint."**/*.py".additional_params]
    custom_key = "custom_value"
    """)
    
    config = Config.load(config_path)
    
    assert len(config.path_configs) == 1
    path_config = config.path_configs[0]
    assert path_config.pattern == "**/*.py"
    assert path_config.translator == TranslatorType.GOOGLE
    assert path_config.target_lang == "EN"
    assert path_config.source_lang == ["zh", "ja"]
    assert path_config.enabled is False
    assert path_config.additional_params == {"custom_key": "custom_value"}


def test_config_load_with_exclude_include(tmp_path):
    """测试加载包含 exclude 和 include 的配置"""
    config_path = tmp_path / "pyproject.toml"
    config_path.write_text("""
    [tool.langlint]
    translator = "mock"
    exclude = ["**/test/", "**/node_modules/"]
    include = ["**/*.py", "**/*.md"]
    """)
    
    config = Config.load(config_path)
    
    assert config.exclude == ["**/test/", "**/node_modules/"]
    assert config.include == ["**/*.py", "**/*.md"]


def test_env_variable_invalid_values(monkeypatch):
    """测试环境变量包含无效值时的处理"""
    monkeypatch.setenv("LANGINT_TRANSLATOR", "invalid_translator")
    monkeypatch.setenv("LANGINT_MAX_WORKERS", "not_a_number")
    monkeypatch.setenv("LANGINT_VERBOSE", "not_a_boolean")
    
    config = Config()
    config._load_from_env()
    
    # 无效值应该被忽略，保持默认值
    assert config.translator == TranslatorType.OPENAI
    assert config.max_workers == 4


def test_env_variable_exclude_override(monkeypatch):
    """测试环境变量覆盖 exclude 配置"""
    monkeypatch.setenv("LANGINT_EXCLUDE", "**/test/,**/build/,**/dist/")
    
    config = Config()
    config._load_from_env()
    
    assert config.exclude == ["**/test/", "**/build/", "**/dist/"]


def test_config_validation_missing_api_key():
    """测试非 MOCK 翻译器缺少 API 密钥"""
    config = Config()
    config.translator = TranslatorType.OPENAI
    config.translators[TranslatorType.OPENAI].api_key = None
    
    with pytest.raises(ConfigError, match="API key not configured"):
        config.validate()


def test_config_validation_path_config_empty_pattern():
    """测试路径配置模式为空"""
    config = Config()
    config.translator = TranslatorType.MOCK
    config.path_configs = [PathConfig(pattern="")]
    
    with pytest.raises(ConfigError, match="Path pattern cannot be empty"):
        config.validate()


def test_config_validation_path_config_unconfigured_translator():
    """测试路径配置使用未配置的翻译器"""
    config = Config()
    config.translator = TranslatorType.MOCK
    config.path_configs = [PathConfig(pattern="**/*.py", translator=TranslatorType.AZURE)]
    # 移除 AZURE 翻译器配置
    del config.translators[TranslatorType.AZURE]
    
    with pytest.raises(ConfigError, match="Translator not configured"):
        config.validate()


def test_get_translator_config_nonexistent():
    """测试获取不存在的翻译器配置"""
    config = Config()
    # 移除所有翻译器
    config.translators.clear()
    
    translator_config = config.get_translator_config(TranslatorType.GOOGLE)
    assert translator_config.type == TranslatorType.GOOGLE
    assert translator_config.api_key is None


def test_path_config_disabled():
    """测试禁用的路径配置不会被匹配"""
    config = Config()
    config.path_configs = [
        PathConfig(pattern="**/*.py", translator=TranslatorType.GOOGLE, enabled=False)
    ]
    
    # 即使模式匹配，禁用的配置也不应该被返回
    result = config.get_path_config("test.py")
    assert result is None


def test_match_pattern():
    """测试路径模式匹配"""
    config = Config()
    
    # 测试精确匹配
    assert config._match_pattern("test.py", "test.py")
    
    # 测试通配符
    assert config._match_pattern("test.py", "*.py")
    assert config._match_pattern("dir/test.py", "**/test.py")
    assert config._match_pattern("dir/subdir/test.py", "**/*.py")
    
    # 测试不匹配
    assert not config._match_pattern("test.py", "*.js")
    assert not config._match_pattern("test.py", "test.js")


def test_translator_type_enum():
    """测试翻译器类型枚举"""
    assert TranslatorType.OPENAI.value == "openai"
    assert TranslatorType.DEEPL.value == "deepl"
    assert TranslatorType.GOOGLE.value == "google"
    assert TranslatorType.AZURE.value == "azure"
    assert TranslatorType.MOCK.value == "mock"


def test_translator_config_dataclass():
    """测试翻译器配置数据类"""
    config = TranslatorConfig(
        type=TranslatorType.OPENAI,
        api_key="test_key",
        api_url="https://api.test.com",
        model="gpt-4",
        max_retries=5,
        timeout=60,
        batch_size=20,
        additional_params={"temperature": 0.7}
    )
    
    assert config.type == TranslatorType.OPENAI
    assert config.api_key == "test_key"
    assert config.api_url == "https://api.test.com"
    assert config.model == "gpt-4"
    assert config.max_retries == 5
    assert config.timeout == 60
    assert config.batch_size == 20
    assert config.additional_params == {"temperature": 0.7}


def test_path_config_dataclass():
    """测试路径配置数据类"""
    config = PathConfig(
        pattern="**/*.py",
        translator=TranslatorType.GOOGLE,
        target_lang="EN",
        source_lang=["zh", "ja"],
        enabled=False,
        additional_params={"custom": "value"}
    )
    
    assert config.pattern == "**/*.py"
    assert config.translator == TranslatorType.GOOGLE
    assert config.target_lang == "EN"
    assert config.source_lang == ["zh", "ja"]
    assert config.enabled is False
    assert config.additional_params == {"custom": "value"}


def test_config_post_init():
    """测试配置初始化后处理"""
    config = Config()
    
    # 验证所有翻译器都已初始化
    assert TranslatorType.OPENAI in config.translators
    assert TranslatorType.DEEPL in config.translators
    assert TranslatorType.GOOGLE in config.translators
    assert TranslatorType.AZURE in config.translators
    assert TranslatorType.MOCK in config.translators
    
    # 验证翻译器配置正确
    assert config.translators[TranslatorType.OPENAI].model == "gpt-3.5-turbo"
    assert config.translators[TranslatorType.MOCK].type == TranslatorType.MOCK


def test_config_load_with_empty_langlint_section(tmp_path):
    """测试加载空的 langlint 配置节"""
    config_path = tmp_path / "pyproject.toml"
    config_path.write_text("""
    [tool.langlint]
    """)
    
    config = Config.load(config_path)
    
    # 应该返回默认配置
    assert config.translator == TranslatorType.OPENAI
    assert config.target_lang == "EN-US"


def test_config_load_without_tool_section(tmp_path):
    """测试加载没有 tool 节的配置文件"""
    config_path = tmp_path / "pyproject.toml"
    config_path.write_text("""
    [project]
    name = "test"
    """)
    
    config = Config.load(config_path)
    
    # 应该返回默认配置
    assert config.translator == TranslatorType.OPENAI
