"""
测试翻译器模块
"""
import pytest
import asyncio
from unittest.mock import Mock, MagicMock, patch, AsyncMock
from langlint.translators.base import TranslationResult, TranslationStatus, TranslationError
from langlint.translators.mock_translator import MockTranslator, MockConfig


class TestOpenAITranslator:
    """测试 OpenAI 翻译器"""
    
    @pytest.fixture
    def mock_openai_config(self):
        """创建模拟的 OpenAI 配置"""
        from langlint.translators.openai_translator import OpenAIConfig
        return OpenAIConfig(
            api_key="test_key",
            model="gpt-3.5-turbo",
            max_tokens=4000,
            temperature=0.3,
            max_retries=3,
            timeout=30
        )
    
    @pytest.fixture
    def mock_openai_response(self):
        """创建模拟的 OpenAI API 响应"""
        mock_response = Mock()
        mock_response.choices = [Mock()]
        mock_response.choices[0].message.content = "Translated text"
        mock_response.choices[0].finish_reason = "stop"
        mock_response.usage = Mock()
        mock_response.usage.dict = Mock(return_value={
            'prompt_tokens': 10,
            'completion_tokens': 20,
            'total_tokens': 30
        })
        return mock_response
    
    def test_openai_config_creation(self, mock_openai_config):
        """测试 OpenAI 配置创建"""
        assert mock_openai_config.api_key == "test_key"
        assert mock_openai_config.model == "gpt-3.5-turbo"
        assert mock_openai_config.max_tokens == 4000
        assert mock_openai_config.temperature == 0.3
        assert mock_openai_config.max_retries == 3
        assert mock_openai_config.timeout == 30
        assert mock_openai_config.base_url is None
    
    @patch('langlint.translators.openai_translator.AsyncOpenAI')
    @patch('langlint.translators.openai_translator.openai')
    def test_openai_translator_initialization(self, mock_openai, mock_async_client, mock_openai_config):
        """测试 OpenAI 翻译器初始化"""
        from langlint.translators.openai_translator import OpenAITranslator
        
        translator = OpenAITranslator(mock_openai_config)
        
        assert translator.name == "OpenAI"
        assert translator.config == mock_openai_config
        assert len(translator.supported_languages) > 0
    
    @patch('langlint.translators.openai_translator.AsyncOpenAI')
    @patch('langlint.translators.openai_translator.openai')
    def test_openai_translator_translate(self, mock_openai, mock_async_client, mock_openai_config, mock_openai_response):
        """测试 OpenAI 翻译功能"""
        from langlint.translators.openai_translator import OpenAITranslator
        
        # 设置模拟客户端
        mock_client = Mock()
        mock_client.chat.completions.create = AsyncMock(return_value=mock_openai_response)
        mock_async_client.return_value = mock_client
        
        translator = OpenAITranslator(mock_openai_config)
        translator.client = mock_client
        
        # 执行翻译
        result = asyncio.run(translator.translate("Hello", "en", "zh"))
        
        assert result.status == TranslationStatus.SUCCESS
        assert result.translated_text == "Translated text"
        assert result.source_language == "en"
        assert result.target_language == "zh"
        assert result.confidence > 0
    
    @patch('langlint.translators.openai_translator.AsyncOpenAI')
    @patch('langlint.translators.openai_translator.openai')
    def test_openai_translator_translate_batch(self, mock_openai, mock_async_client, mock_openai_config):
        """测试 OpenAI 批量翻译功能"""
        from langlint.translators.openai_translator import OpenAITranslator
        
        # 创建模拟响应
        mock_response = Mock()
        mock_response.choices = [Mock()]
        mock_response.choices[0].message.content = '["翻译1", "翻译2", "翻译3"]'
        mock_response.usage = Mock()
        mock_response.usage.dict = Mock(return_value={})
        
        # 设置模拟客户端
        mock_client = Mock()
        mock_client.chat.completions.create = AsyncMock(return_value=mock_response)
        mock_async_client.return_value = mock_client
        
        translator = OpenAITranslator(mock_openai_config)
        translator.client = mock_client
        
        # 执行批量翻译
        texts = ["Hello", "World", "Test"]
        results = asyncio.run(translator.translate_batch(texts, "en", "zh"))
        
        assert len(results) == 3
        for result in results:
            assert result.status == TranslationStatus.SUCCESS
    
    @patch('langlint.translators.openai_translator.AsyncOpenAI')
    @patch('langlint.translators.openai_translator.openai')
    def test_openai_language_support(self, mock_openai, mock_async_client, mock_openai_config):
        """测试 OpenAI 语言支持检查"""
        from langlint.translators.openai_translator import OpenAITranslator
        
        translator = OpenAITranslator(mock_openai_config)
        
        assert translator.is_language_supported("en")
        assert translator.is_language_supported("zh")
        assert translator.is_language_supported("ja")
        assert translator.is_language_supported("en-us")
        assert translator.is_language_supported("zh-cn")
    
    @patch('langlint.translators.openai_translator.AsyncOpenAI')
    @patch('langlint.translators.openai_translator.openai')
    def test_openai_normalize_language_code(self, mock_openai, mock_async_client, mock_openai_config):
        """测试 OpenAI 语言代码规范化"""
        from langlint.translators.openai_translator import OpenAITranslator
        
        translator = OpenAITranslator(mock_openai_config)
        
        assert translator.normalize_language_code("en") == "en"
        assert translator.normalize_language_code("EN") == "en"
        assert translator.normalize_language_code("en-US") == "en"
        assert translator.normalize_language_code("zh-CN") == "zh"
        assert translator.normalize_language_code("ja-JP") == "ja"
    
    @patch('langlint.translators.openai_translator.AsyncOpenAI')
    @patch('langlint.translators.openai_translator.openai')
    def test_openai_estimate_cost(self, mock_openai, mock_async_client, mock_openai_config):
        """测试 OpenAI 成本估算"""
        from langlint.translators.openai_translator import OpenAITranslator
        
        translator = OpenAITranslator(mock_openai_config)
        
        cost = translator.estimate_cost("Hello World", "en", "zh")
        assert cost > 0
        assert isinstance(cost, float)
    
    @patch('langlint.translators.openai_translator.AsyncOpenAI')
    @patch('langlint.translators.openai_translator.openai')
    def test_openai_get_usage_info(self, mock_openai, mock_async_client, mock_openai_config):
        """测试 OpenAI 使用信息获取"""
        from langlint.translators.openai_translator import OpenAITranslator
        
        translator = OpenAITranslator(mock_openai_config)
        
        usage_info = translator.get_usage_info()
        assert usage_info['name'] == "OpenAI"
        assert 'supported_languages' in usage_info
        assert 'cost_per_token' in usage_info
        assert 'model' in usage_info
    
    @patch('langlint.translators.openai_translator.AsyncOpenAI')
    @patch('langlint.translators.openai_translator.openai')
    def test_openai_translation_error(self, mock_openai, mock_async_client, mock_openai_config):
        """测试 OpenAI 翻译错误处理"""
        from langlint.translators.openai_translator import OpenAITranslator
        
        # 设置模拟客户端抛出异常
        mock_client = Mock()
        mock_client.chat.completions.create = AsyncMock(side_effect=Exception("API Error"))
        mock_async_client.return_value = mock_client
        
        translator = OpenAITranslator(mock_openai_config)
        translator.client = mock_client
        
        # 执行翻译应该抛出异常
        with pytest.raises(TranslationError):
            asyncio.run(translator.translate("Hello", "en", "zh"))
    
    @patch('langlint.translators.openai_translator.AsyncOpenAI')
    @patch('langlint.translators.openai_translator.openai')
    def test_openai_calculate_confidence(self, mock_openai, mock_async_client, mock_openai_config):
        """测试 OpenAI 置信度计算"""
        from langlint.translators.openai_translator import OpenAITranslator
        
        translator = OpenAITranslator(mock_openai_config)
        
        # 测试不同的完成原因
        mock_response = Mock()
        mock_response.choices = [Mock()]
        
        # stop 原因
        mock_response.choices[0].finish_reason = "stop"
        confidence = translator._calculate_confidence(mock_response)
        assert confidence == 1.0
        
        # length 原因
        mock_response.choices[0].finish_reason = "length"
        confidence = translator._calculate_confidence(mock_response)
        assert confidence == 0.8
        
        # content_filter 原因
        mock_response.choices[0].finish_reason = "content_filter"
        confidence = translator._calculate_confidence(mock_response)
        assert confidence == 0.6
    
    @patch('langlint.translators.openai_translator.AsyncOpenAI')
    @patch('langlint.translators.openai_translator.openai')
    def test_openai_parse_batch_response_json(self, mock_openai, mock_async_client, mock_openai_config):
        """测试 OpenAI 批量响应解析（JSON格式）"""
        from langlint.translators.openai_translator import OpenAITranslator
        
        translator = OpenAITranslator(mock_openai_config)
        
        # 测试 JSON 格式响应
        response = '["翻译1", "翻译2", "翻译3"]'
        result = translator._parse_batch_response(response)
        assert len(result) == 3
        assert result[0] == "翻译1"
    
    @patch('langlint.translators.openai_translator.AsyncOpenAI')
    @patch('langlint.translators.openai_translator.openai')
    def test_openai_parse_batch_response_text(self, mock_openai, mock_async_client, mock_openai_config):
        """测试 OpenAI 批量响应解析（文本格式）"""
        from langlint.translators.openai_translator import OpenAITranslator
        
        translator = OpenAITranslator(mock_openai_config)
        
        # 测试文本格式响应
        response = "1. 翻译1\n2. 翻译2\n3. 翻译3"
        result = translator._parse_batch_response(response)
        assert len(result) >= 3


class TestDeepLTranslator:
    """测试 DeepL 翻译器配置"""
    
    def test_deepl_config_creation(self):
        """测试 DeepL 配置创建"""
        from langlint.translators.deepl_translator import DeepLConfig
        
        config = DeepLConfig(
            api_key="test_key",
            max_retries=3,
            timeout=30,
            formality="default"
        )
        
        assert config.api_key == "test_key"
        assert config.max_retries == 3
        assert config.timeout == 30
        assert config.formality == "default"
        assert config.base_url is None


class TestTranslatorEdgeCases:
    """测试翻译器边界情况"""
    
    @patch('langlint.translators.openai_translator.AsyncOpenAI')
    @patch('langlint.translators.openai_translator.openai')
    def test_openai_empty_text(self, mock_openai, mock_async_client):
        """测试 OpenAI 空文本翻译"""
        from langlint.translators.openai_translator import OpenAITranslator, OpenAIConfig
        
        config = OpenAIConfig(api_key="test_key")
        translator = OpenAITranslator(config)
        
        # 模拟空文本响应
        mock_response = Mock()
        mock_response.choices = [Mock()]
        mock_response.choices[0].message.content = ""
        mock_response.choices[0].finish_reason = "stop"
        mock_response.usage = Mock()
        mock_response.usage.dict = Mock(return_value={})
        
        mock_client = Mock()
        mock_client.chat.completions.create = AsyncMock(return_value=mock_response)
        translator.client = mock_client
        
        # 空文本应该抛出异常
        with pytest.raises(TranslationError):
            asyncio.run(translator.translate("", "en", "zh"))
    
    @patch('langlint.translators.openai_translator.AsyncOpenAI')
    @patch('langlint.translators.openai_translator.openai')
    def test_openai_very_long_text(self, mock_openai, mock_async_client):
        """测试 OpenAI 超长文本翻译"""
        from langlint.translators.openai_translator import OpenAITranslator, OpenAIConfig
        
        config = OpenAIConfig(api_key="test_key", max_tokens=100)
        translator = OpenAITranslator(config)
        
        # 模拟响应
        mock_response = Mock()
        mock_response.choices = [Mock()]
        mock_response.choices[0].message.content = "Truncated translation"
        mock_response.choices[0].finish_reason = "length"
        mock_response.usage = Mock()
        mock_response.usage.dict = Mock(return_value={})
        
        mock_client = Mock()
        mock_client.chat.completions.create = AsyncMock(return_value=mock_response)
        translator.client = mock_client
        
        long_text = "Hello " * 1000
        result = asyncio.run(translator.translate(long_text, "en", "zh"))
        assert result.confidence < 1.0  # 应该因为被截断而降低置信度
    
    @patch('langlint.translators.openai_translator.AsyncOpenAI')
    @patch('langlint.translators.openai_translator.openai')
    def test_openai_custom_parameters(self, mock_openai, mock_async_client):
        """测试 OpenAI 自定义参数"""
        from langlint.translators.openai_translator import OpenAITranslator, OpenAIConfig
        
        config = OpenAIConfig(api_key="test_key")
        translator = OpenAITranslator(config)
        
        # 模拟响应
        mock_response = Mock()
        mock_response.choices = [Mock()]
        mock_response.choices[0].message.content = "Translated"
        mock_response.choices[0].finish_reason = "stop"
        mock_response.usage = Mock()
        mock_response.usage.dict = Mock(return_value={})
        
        mock_client = Mock()
        mock_client.chat.completions.create = AsyncMock(return_value=mock_response)
        translator.client = mock_client
        
        # 使用自定义参数
        result = asyncio.run(translator.translate(
            "Hello", 
            "en", 
            "zh",
            model="gpt-4",
            temperature=0.7,
            max_tokens=2000
        ))
        
        # 验证调用参数
        call_kwargs = mock_client.chat.completions.create.call_args[1]
        assert call_kwargs['model'] == "gpt-4"
        assert call_kwargs['temperature'] == 0.7
        assert call_kwargs['max_tokens'] == 2000


class TestMockTranslator:
    """测试 Mock 翻译器"""
    
    def test_mock_config_default(self):
        """测试 Mock 配置默认值"""
        config = MockConfig()
        assert config.delay_range == (0.1, 0.5)
        assert config.error_rate == 0.0
        assert config.confidence_range == (0.8, 1.0)
    
    def test_mock_config_custom(self):
        """测试 Mock 自定义配置"""
        config = MockConfig(
            delay_range=(0.0, 0.1),
            error_rate=0.5,
            confidence_range=(0.5, 0.9)
        )
        assert config.delay_range == (0.0, 0.1)
        assert config.error_rate == 0.5
        assert config.confidence_range == (0.5, 0.9)
    
    def test_mock_translator_initialization(self):
        """测试 Mock 翻译器初始化"""
        translator = MockTranslator()
        assert translator.name == "Mock"
        assert translator.config.error_rate == 0.0
    
    def test_mock_translator_initialization_with_config(self):
        """测试 Mock 翻译器使用自定义配置初始化"""
        config = MockConfig(error_rate=0.2)
        translator = MockTranslator(config)
        assert translator.config.error_rate == 0.2
    
    def test_mock_translator_supported_languages(self):
        """测试 Mock 翻译器支持的语言"""
        translator = MockTranslator()
        languages = translator.supported_languages
        
        assert 'en' in languages
        assert 'zh' in languages
        assert 'ja' in languages
        assert 'ko' in languages
        assert 'fr' in languages
        assert len(languages) > 50  # 应该支持很多语言
    
    def test_mock_translator_is_language_supported(self):
        """测试 Mock 翻译器语言支持检查"""
        translator = MockTranslator()
        
        assert translator.is_language_supported('en')
        assert translator.is_language_supported('zh')
        assert translator.is_language_supported('ja')
        assert translator.is_language_supported('ko')
        assert translator.is_language_supported('en-us')
        assert translator.is_language_supported('zh-cn')
        assert not translator.is_language_supported('unknown')
    
    def test_mock_translator_normalize_language_code(self):
        """测试 Mock 翻译器语言代码规范化"""
        translator = MockTranslator()
        
        assert translator.normalize_language_code('en') == 'en'
        assert translator.normalize_language_code('EN') == 'en'
        assert translator.normalize_language_code('en-us') == 'en'
        assert translator.normalize_language_code('en-US') == 'en'
        assert translator.normalize_language_code('en-gb') == 'en'
        assert translator.normalize_language_code('zh-cn') == 'zh'
        assert translator.normalize_language_code('zh-tw') == 'zh'
        assert translator.normalize_language_code('ja-jp') == 'ja'
        assert translator.normalize_language_code('ko-kr') == 'ko'
        assert translator.normalize_language_code('fr-fr') == 'fr'
        assert translator.normalize_language_code('de-de') == 'de'
        assert translator.normalize_language_code('es-es') == 'es'
        assert translator.normalize_language_code('unknown') == 'unknown'
    
    def test_mock_translator_translate(self):
        """测试 Mock 翻译器翻译功能"""
        config = MockConfig(delay_range=(0.0, 0.01))  # 减少延迟以加快测试
        translator = MockTranslator(config)
        
        result = asyncio.run(translator.translate("Hello World", "en", "zh"))
        
        assert result.status == TranslationStatus.SUCCESS
        assert result.original_text == "Hello World"
        assert result.source_language == "en"
        assert result.target_language == "zh"
        assert result.translated_text.startswith("[中文]")
        assert result.confidence >= 0.8
        assert result.confidence <= 1.0
        assert result.metadata['mock'] is True
        assert 'delay' in result.metadata
    
    def test_mock_translator_translate_same_language(self):
        """测试 Mock 翻译器相同语言翻译"""
        config = MockConfig(delay_range=(0.0, 0.01))
        translator = MockTranslator(config)
        
        result = asyncio.run(translator.translate("Hello", "en", "en"))
        
        # 相同语言会返回原文
        assert result.translated_text == "Hello"
    
    def test_mock_translator_translate_all_languages(self):
        """测试 Mock 翻译器所有语言标签"""
        config = MockConfig(delay_range=(0.0, 0.01))
        translator = MockTranslator(config)
        
        # 测试所有主要语言
        test_cases = [
            'zh', 'ja', 'ko', 'fr', 'de', 'es', 'it', 'pt', 'ru', 'ar',
            'hi', 'th', 'vi', 'id', 'ms', 'tl', 'tr', 'pl', 'nl', 'sv',
            'da', 'no', 'fi', 'cs', 'hu', 'ro', 'bg', 'hr', 'sk', 'sl',
            'et', 'lv', 'lt', 'uk', 'be', 'mk', 'sq', 'sr', 'bs', 'me',
            'is', 'ga', 'cy', 'mt', 'eu', 'ca', 'gl', 'af', 'sw', 'am',
            'az', 'bn', 'gu', 'he', 'ka', 'kk', 'ky', 'lo', 'mn', 'my',
            'ne', 'si', 'ta', 'te', 'ur', 'uz'
        ]
        
        for lang_code in test_cases:
            result = asyncio.run(translator.translate("test", "en", lang_code))
            # 验证翻译成功且包含原文
            assert result.status == TranslationStatus.SUCCESS
            assert "test" in result.translated_text
    
    def test_mock_translator_translate_with_error_rate(self):
        """测试 Mock 翻译器错误率"""
        config = MockConfig(delay_range=(0.0, 0.01), error_rate=1.0)  # 100% 错误率
        translator = MockTranslator(config)
        
        with pytest.raises(TranslationError) as exc_info:
            asyncio.run(translator.translate("Hello", "en", "zh"))
        
        assert "Mock translation failed" in str(exc_info.value)
        assert exc_info.value.translator_name == "Mock"
        assert exc_info.value.error_code == "MOCK_ERROR"
    
    def test_mock_translator_translate_batch(self):
        """测试 Mock 翻译器批量翻译"""
        config = MockConfig(delay_range=(0.0, 0.01))
        translator = MockTranslator(config)
        
        texts = ["Hello", "World", "Test"]
        results = asyncio.run(translator.translate_batch(texts, "en", "zh"))
        
        assert len(results) == 3
        for i, result in enumerate(results):
            assert result.status == TranslationStatus.SUCCESS
            assert result.original_text == texts[i]
            assert result.source_language == "en"
            assert result.target_language == "zh"
            assert result.translated_text.startswith("[中文]")
            assert result.metadata['batch_index'] == i
    
    def test_mock_translator_translate_batch_with_error(self):
        """测试 Mock 翻译器批量翻译错误"""
        config = MockConfig(delay_range=(0.0, 0.01), error_rate=1.0)
        translator = MockTranslator(config)
        
        texts = ["Hello", "World"]
        with pytest.raises(TranslationError) as exc_info:
            asyncio.run(translator.translate_batch(texts, "en", "zh"))
        
        assert "Mock batch translation failed" in str(exc_info.value)
        assert exc_info.value.error_code == "MOCK_BATCH_ERROR"
    
    def test_mock_translator_estimate_cost(self):
        """测试 Mock 翻译器成本估算"""
        translator = MockTranslator()
        
        cost = translator.estimate_cost("Hello World", "en", "zh")
        assert cost == 0.0
    
    def test_mock_translator_get_usage_info(self):
        """测试 Mock 翻译器使用信息"""
        config = MockConfig(
            delay_range=(0.1, 0.5),
            error_rate=0.2,
            confidence_range=(0.7, 0.9)
        )
        translator = MockTranslator(config)
        
        usage_info = translator.get_usage_info()
        
        assert usage_info['name'] == "Mock"
        assert 'supported_languages' in usage_info
        assert 'supported_pairs' in usage_info
        assert usage_info['cost_per_character'] == 0.0
        assert usage_info['max_batch_size'] == 1000
        assert usage_info['rate_limit'] == 'None (mock)'
        assert usage_info['delay_range'] == (0.1, 0.5)
        assert usage_info['error_rate'] == 0.2
        assert usage_info['confidence_range'] == (0.7, 0.9)
    
    def test_mock_translator_validate_languages(self):
        """测试 Mock 翻译器语言验证"""
        translator = MockTranslator()
        
        # 应该不抛出异常
        translator.validate_languages("en", "zh")
        translator.validate_languages("en-us", "zh-cn")
        
        # 测试无效语言 - base.py 抛出 ValueError
        with pytest.raises(ValueError):
            translator.validate_languages("invalid_lang", "zh")
    
    def test_mock_translator_generate_mock_translation(self):
        """测试 Mock 翻译生成函数"""
        translator = MockTranslator()
        
        # 测试各种语言
        assert translator._generate_mock_translation("test", "en", "zh") == "[中文] test"
        assert translator._generate_mock_translation("test", "en", "ja") == "[日本語] test"
        
        # 测试相同语言会返回原文
        assert translator._generate_mock_translation("test", "en", "en") == "test"
    
    def test_mock_translator_language_mapping(self):
        """测试 Mock 翻译器语言映射"""
        assert MockTranslator.LANGUAGE_MAPPING['en'] == 'English'
        assert MockTranslator.LANGUAGE_MAPPING['zh'] == 'Chinese'
        assert MockTranslator.LANGUAGE_MAPPING['ja'] == 'Japanese'
        assert MockTranslator.LANGUAGE_MAPPING['ko'] == 'Korean'
        assert len(MockTranslator.LANGUAGE_MAPPING) > 50
    
    def test_mock_translator_confidence_range(self):
        """测试 Mock 翻译器置信度范围"""
        config = MockConfig(
            delay_range=(0.0, 0.01),
            confidence_range=(0.6, 0.7)
        )
        translator = MockTranslator(config)
        
        # 运行多次翻译，验证置信度在指定范围内
        for _ in range(10):
            result = asyncio.run(translator.translate("test", "en", "zh"))
            assert result.confidence >= 0.6
            assert result.confidence <= 0.7
    
    def test_mock_translator_empty_text(self):
        """测试 Mock 翻译器空文本 - 应该抛出异常"""
        config = MockConfig(delay_range=(0.0, 0.01))
        translator = MockTranslator(config)
        
        # 空文本会在 TranslationResult 初始化时抛出 ValueError
        with pytest.raises(ValueError, match="Original text cannot be empty"):
            asyncio.run(translator.translate("", "en", "zh"))
    
    def test_mock_translator_special_characters(self):
        """测试 Mock 翻译器特殊字符"""
        config = MockConfig(delay_range=(0.0, 0.01))
        translator = MockTranslator(config)
        
        special_text = "Hello! @#$%^&*() 世界"
        result = asyncio.run(translator.translate(special_text, "en", "zh"))
        assert special_text in result.translated_text
    
    def test_mock_translator_long_text(self):
        """测试 Mock 翻译器长文本"""
        config = MockConfig(delay_range=(0.0, 0.01))
        translator = MockTranslator(config)
        
        long_text = "Hello " * 1000
        result = asyncio.run(translator.translate(long_text, "en", "zh"))
        assert result.status == TranslationStatus.SUCCESS
        assert long_text in result.translated_text
    
    def test_mock_translator_get_supported_language_pairs(self):
        """测试 Mock 翻译器获取支持的语言对"""
        translator = MockTranslator()
        
        pairs = translator.get_supported_language_pairs()
        assert len(pairs) > 0
        assert isinstance(pairs, list)
    
    def test_mock_translator_all_language_variations(self):
        """测试 Mock 翻译器所有语言变体"""
        translator = MockTranslator()
        
        # 测试更多语言代码
        variations = [
            'pt-br', 'pt-pt', 'ru-ru', 'ar-sa', 'hi-in',
            'th-th', 'vi-vn', 'id-id', 'ms-my', 'tl-ph',
            'tr-tr', 'pl-pl', 'nl-nl', 'sv-se', 'da-dk',
            'no-no', 'fi-fi', 'cs-cz', 'hu-hu', 'ro-ro',
        ]
        
        for var in variations:
            normalized = translator.normalize_language_code(var)
            assert len(normalized) <= 3  # 应该被规范化为短代码
    
    def test_mock_translator_metadata(self):
        """测试 Mock 翻译器元数据"""
        config = MockConfig(delay_range=(0.0, 0.01))
        translator = MockTranslator(config)
        
        result = asyncio.run(translator.translate("test", "en", "zh"))
        
        assert 'mock' in result.metadata
        assert result.metadata['mock'] is True
        assert 'delay' in result.metadata
        assert 'translator' in result.metadata
        assert result.metadata['translator'] == 'Mock'
    
    def test_mock_translator_batch_metadata(self):
        """测试 Mock 翻译器批量翻译元数据"""
        config = MockConfig(delay_range=(0.0, 0.01))
        translator = MockTranslator(config)
        
        results = asyncio.run(translator.translate_batch(["a", "b"], "en", "zh"))
        
        for i, result in enumerate(results):
            assert result.metadata['batch_index'] == i
            assert result.metadata['mock'] is True

