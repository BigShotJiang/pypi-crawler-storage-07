# coding: utf-8

# flake8: noqa

"""
    Wink API

     # Introduction  Welcome to the Wink API - A programmer-friendly way to manage, sell and book travel inventory on the Wink platform. The API gives you all the tools you need to ready your properties and inventory for sale across 1000s of our native sales channels.  Integrators, affiliates, travel agents and content creators have the ability search for your travel inventory and promote / sell it in a wide variety of ways.   # Integrations  We have already integrated with the most well-known channel managers so you don't have to. To see our current integrations, please go to https://extranet.wink.travel and scroll to Connectivity section. Once your properties are set up, you can finish the setup by mapping your property to Wink using your channel manager partner portal. If your properties don't have a channel manager, you can easily manage rates and availability with this API.   # Intended Audience  Programmers are [most likely] a requirement to start integrating with Wink. Companies and organizations that would most benefit from integrating with us are new and existing travel companies that have relationships with suppliers and that need an advanced system from which to manage their travel inventory and get that same inventory out to as many eyeballs as possible at the lowest price possible.  - Hotel chains  - Hotel brands  - Travel tech companies  - Destination sites  - Integrators  - Aggregators  - Destination management companies  - Travel agencies  - OTAs   ## APIs  Not every integrator needs every API. For that reason, we have separated APIs into context.  ### Test API   - [Ping](/ping): The Ping API is a quick test endpoint to verify that your credentials work Wink.  ### Common APIs  - [Notifications](/notifications): The Notifications API is a way for us to stay in touch with your user, property or affiliate account. - [User Settings](/user-settings): The User Settings API exposes endpoints to allow 3rd party integrators to communicate with Wink.  ### Consume APIs Consume endpoints are for developers who want to find existing travel inventory and either book it or use it to advertise through one of their Wink affiliate accounts.   - [Configuration](/customization-client): A single endpoint to retrieve whitelabel + customization information for the booking customization.  - [Lookup](/lookup): All APIs related to locating inventory by region, locale and property flags.  - [Inventory](/inventory): All APIs related to retrieve known travel inventory as it was found using the Lookup API..  - [Booking](/booking): All APIs related to creating bookings on the platform.  - [Travel Agent](/travel-agent): The Travel Agent API exposes endpoints to manage agent-facilitated bookings.   ### Produce APIs  Produce endpoints are for developers who want to create and manage travel inventory.   #### Property  - [Property registration](/extranet/property/register): As a producer, this is, oftentimes, where you start your journey. These endpoints let you create properties on Wink.  - [Property](/extranet/property): This collection of property endpoints are mostly management endpoints that let you display, change status and similar for your existing properties.  - [Facilities](/extranet/facilities): This collection of endpoints let you manage facilities; such as room types.  - [Experiences](/extranet/experiences): This collection of endpoints let you manage experiences, such as activities.  - [Monetize](/extranet/monetize): The Monetize API exposes endpoints for managing cancellation polies, rate plans, promotions and more on Wink.  - [Distribution](/extranet/distribution): The Distribution API exposes endpoints for sales channels, connecting with affiliates, managing rates and inventory calendars and more on Wink.  - [Property Booking](/extranet/booking): The Property Booking API exposes endpoints for managing bookings and reviews at the property-level.   #### Affiliate  - [Affiliate](/affiliate): This collection of affiliate endpoints are mostly management endpoints that let you display, change status and similar for your existing accounts.  - [Browse](/affiliate/browse): The Browse API exposes endpoints for affiliates to find suppliers and inventory to sell.  - [Inventory](/affiliate/inventory): The Inventory API exposes endpoints for affiliates to manage the inventory they want to sell and how they want to sell it.  - [Sales Channel](/affiliate/sales-channel): The Sales Channel API exposes endpoints for affiliates to manage existing sales channels as well as find new ones.  - [WinkLinks](/affiliate/winklinks): The WinkLinks API exposes endpoints for affiliates to manage their WinkLinks page.   #### Rate provider  - [Channel manager](/channel-manager): The Channel Manager API enables external channel manager partners to map, exchange rate / availability information with us as well as be informed of bookings that occur on the Wink platform for one of their properties.   ### Taxonomy APIs  Taxonomy endpoints are for developers who want to consume and produce travel inventory and need taxonomies of standard and non-standard codes for inventory types, classes, statuses etc.   - [Reference](/reference): All APIs related to retrieving platform-supported taxonomies.   ### Insight APIs  Insight endpoints do exactly what the name implies - They offer platform-level insight into the activities of producers and consumers.   - [Analytics](/analytics): All APIs related to tracking metrics across a wide variety of data source segments including, more entertaining, leaderboard metrics.   ### Payment APIs  Payment endpoints are for developers who want to purchase travel inventory. This can be done via the API as a registered Travel Agent or using our API in conjunction with our PCI compliant payment widget for all other entities.   - [TripPay](/payment): All APIs related to TripPay account management, booking, mapping and integration features.   ## SDKs  We are actively working on supporting the most used languages out there. If you don't see your language here, reach out to us with a request to officially add your language. In the meantime, if you want to roll your own SDK, you can do so by downloading the OpenAPI spec and using one of the many available OpenAPI generators available: [https://openapi-generator.tech/docs/generators](https://openapi-generator.tech/docs/generators).   - Java SDK [https://github.com/wink-travel/wink-sdk-java](https://github.com/wink-travel/wink-sdk-java)   ## Usage  These features are made available to you via a [REST API](https://en.wikipedia.org/wiki/Representational_state_transfer). This API is language agnostic.   ## Versioning  We chose to version our endpoints in a way that we hope affects your integration minimally. You request the version of our API you wish to work with via the `Wink-Version` header. When it's time for you to upgrade, you only have to change the version number to get access to our updated endpoints.   ## Release history  - Follow updates on Github: https://github.com/wink-travel/wink-sdk-java/blob/master/CHANGELOG.md    # Reference API  The Reference API exposes endpoints related to supported taxonomies of reference data that this platform supports.  

    The version of the OpenAPI document: 30.22.2
    Contact: bjorn@wink.travel
    Generated by OpenAPI Generator (https://openapi-generator.tech)

    Do not edit the class manually.
"""  # noqa: E501


__version__ = "0.0.46"

# Define package exports
__all__ = [
    "GeoDataApi",
    "RateProviderApi",
    "ReferenceApi",
    "ApiResponse",
    "ApiClient",
    "Configuration",
    "OpenApiException",
    "ApiTypeError",
    "ApiValueError",
    "ApiKeyError",
    "ApiAttributeError",
    "ApiException",
    "CountResponseNonAuthenticatedEntity",
    "CountryLightweightNonAuthenticatedEntity",
    "GenericErrorMessage",
    "GeoIpLightweightNonAuthenticatedEntity",
    "GeoJsonPointNonAuthenticatedEntity",
    "GeoNameCountryNonAuthenticatedEntity",
    "GeoNameLightweightNonAuthenticatedEntity",
    "KeyValuePairAdministrator",
    "KeyValuePairNonAuthenticatedEntity",
    "LanguageNonAuthenticatedEntity",
    "PageQuoteNonAuthenticatedEntity",
    "PageableObjectNonAuthenticatedEntity",
    "PerkLightweightNonAuthenticatedEntity",
    "QuoteLightweightNonAuthenticatedEntity",
    "QuoteNonAuthenticatedEntity",
    "ShowSocialNetworks400Response",
    "SimpleDescriptionNonAuthenticatedEntity",
    "SortObjectNonAuthenticatedEntity",
    "SubCountryLightweightNonAuthenticatedEntity",
    "SubSubCountryLightweightNonAuthenticatedEntity",
]

if __import__("typing").TYPE_CHECKING:
    # import apis into sdk package
    from wink_sdk_reference.api.geo_data_api import GeoDataApi as GeoDataApi
    from wink_sdk_reference.api.rate_provider_api import RateProviderApi as RateProviderApi
    from wink_sdk_reference.api.reference_api import ReferenceApi as ReferenceApi
    
    # import ApiClient
    from wink_sdk_reference.api_response import ApiResponse as ApiResponse
    from wink_sdk_reference.api_client import ApiClient as ApiClient
    from wink_sdk_reference.configuration import Configuration as Configuration
    from wink_sdk_reference.exceptions import OpenApiException as OpenApiException
    from wink_sdk_reference.exceptions import ApiTypeError as ApiTypeError
    from wink_sdk_reference.exceptions import ApiValueError as ApiValueError
    from wink_sdk_reference.exceptions import ApiKeyError as ApiKeyError
    from wink_sdk_reference.exceptions import ApiAttributeError as ApiAttributeError
    from wink_sdk_reference.exceptions import ApiException as ApiException
    
    # import models into sdk package
    from wink_sdk_reference.models.count_response_non_authenticated_entity import CountResponseNonAuthenticatedEntity as CountResponseNonAuthenticatedEntity
    from wink_sdk_reference.models.country_lightweight_non_authenticated_entity import CountryLightweightNonAuthenticatedEntity as CountryLightweightNonAuthenticatedEntity
    from wink_sdk_reference.models.generic_error_message import GenericErrorMessage as GenericErrorMessage
    from wink_sdk_reference.models.geo_ip_lightweight_non_authenticated_entity import GeoIpLightweightNonAuthenticatedEntity as GeoIpLightweightNonAuthenticatedEntity
    from wink_sdk_reference.models.geo_json_point_non_authenticated_entity import GeoJsonPointNonAuthenticatedEntity as GeoJsonPointNonAuthenticatedEntity
    from wink_sdk_reference.models.geo_name_country_non_authenticated_entity import GeoNameCountryNonAuthenticatedEntity as GeoNameCountryNonAuthenticatedEntity
    from wink_sdk_reference.models.geo_name_lightweight_non_authenticated_entity import GeoNameLightweightNonAuthenticatedEntity as GeoNameLightweightNonAuthenticatedEntity
    from wink_sdk_reference.models.key_value_pair_administrator import KeyValuePairAdministrator as KeyValuePairAdministrator
    from wink_sdk_reference.models.key_value_pair_non_authenticated_entity import KeyValuePairNonAuthenticatedEntity as KeyValuePairNonAuthenticatedEntity
    from wink_sdk_reference.models.language_non_authenticated_entity import LanguageNonAuthenticatedEntity as LanguageNonAuthenticatedEntity
    from wink_sdk_reference.models.page_quote_non_authenticated_entity import PageQuoteNonAuthenticatedEntity as PageQuoteNonAuthenticatedEntity
    from wink_sdk_reference.models.pageable_object_non_authenticated_entity import PageableObjectNonAuthenticatedEntity as PageableObjectNonAuthenticatedEntity
    from wink_sdk_reference.models.perk_lightweight_non_authenticated_entity import PerkLightweightNonAuthenticatedEntity as PerkLightweightNonAuthenticatedEntity
    from wink_sdk_reference.models.quote_lightweight_non_authenticated_entity import QuoteLightweightNonAuthenticatedEntity as QuoteLightweightNonAuthenticatedEntity
    from wink_sdk_reference.models.quote_non_authenticated_entity import QuoteNonAuthenticatedEntity as QuoteNonAuthenticatedEntity
    from wink_sdk_reference.models.show_social_networks400_response import ShowSocialNetworks400Response as ShowSocialNetworks400Response
    from wink_sdk_reference.models.simple_description_non_authenticated_entity import SimpleDescriptionNonAuthenticatedEntity as SimpleDescriptionNonAuthenticatedEntity
    from wink_sdk_reference.models.sort_object_non_authenticated_entity import SortObjectNonAuthenticatedEntity as SortObjectNonAuthenticatedEntity
    from wink_sdk_reference.models.sub_country_lightweight_non_authenticated_entity import SubCountryLightweightNonAuthenticatedEntity as SubCountryLightweightNonAuthenticatedEntity
    from wink_sdk_reference.models.sub_sub_country_lightweight_non_authenticated_entity import SubSubCountryLightweightNonAuthenticatedEntity as SubSubCountryLightweightNonAuthenticatedEntity
    
else:
    from lazy_imports import LazyModule, as_package, load

    load(
        LazyModule(
            *as_package(__file__),
            ("__version__", __version__),
            ("__all__", __all__),
            """# import apis into sdk package
from wink_sdk_reference.api.geo_data_api import GeoDataApi as GeoDataApi
from wink_sdk_reference.api.rate_provider_api import RateProviderApi as RateProviderApi
from wink_sdk_reference.api.reference_api import ReferenceApi as ReferenceApi

# import ApiClient
from wink_sdk_reference.api_response import ApiResponse as ApiResponse
from wink_sdk_reference.api_client import ApiClient as ApiClient
from wink_sdk_reference.configuration import Configuration as Configuration
from wink_sdk_reference.exceptions import OpenApiException as OpenApiException
from wink_sdk_reference.exceptions import ApiTypeError as ApiTypeError
from wink_sdk_reference.exceptions import ApiValueError as ApiValueError
from wink_sdk_reference.exceptions import ApiKeyError as ApiKeyError
from wink_sdk_reference.exceptions import ApiAttributeError as ApiAttributeError
from wink_sdk_reference.exceptions import ApiException as ApiException

# import models into sdk package
from wink_sdk_reference.models.count_response_non_authenticated_entity import CountResponseNonAuthenticatedEntity as CountResponseNonAuthenticatedEntity
from wink_sdk_reference.models.country_lightweight_non_authenticated_entity import CountryLightweightNonAuthenticatedEntity as CountryLightweightNonAuthenticatedEntity
from wink_sdk_reference.models.generic_error_message import GenericErrorMessage as GenericErrorMessage
from wink_sdk_reference.models.geo_ip_lightweight_non_authenticated_entity import GeoIpLightweightNonAuthenticatedEntity as GeoIpLightweightNonAuthenticatedEntity
from wink_sdk_reference.models.geo_json_point_non_authenticated_entity import GeoJsonPointNonAuthenticatedEntity as GeoJsonPointNonAuthenticatedEntity
from wink_sdk_reference.models.geo_name_country_non_authenticated_entity import GeoNameCountryNonAuthenticatedEntity as GeoNameCountryNonAuthenticatedEntity
from wink_sdk_reference.models.geo_name_lightweight_non_authenticated_entity import GeoNameLightweightNonAuthenticatedEntity as GeoNameLightweightNonAuthenticatedEntity
from wink_sdk_reference.models.key_value_pair_administrator import KeyValuePairAdministrator as KeyValuePairAdministrator
from wink_sdk_reference.models.key_value_pair_non_authenticated_entity import KeyValuePairNonAuthenticatedEntity as KeyValuePairNonAuthenticatedEntity
from wink_sdk_reference.models.language_non_authenticated_entity import LanguageNonAuthenticatedEntity as LanguageNonAuthenticatedEntity
from wink_sdk_reference.models.page_quote_non_authenticated_entity import PageQuoteNonAuthenticatedEntity as PageQuoteNonAuthenticatedEntity
from wink_sdk_reference.models.pageable_object_non_authenticated_entity import PageableObjectNonAuthenticatedEntity as PageableObjectNonAuthenticatedEntity
from wink_sdk_reference.models.perk_lightweight_non_authenticated_entity import PerkLightweightNonAuthenticatedEntity as PerkLightweightNonAuthenticatedEntity
from wink_sdk_reference.models.quote_lightweight_non_authenticated_entity import QuoteLightweightNonAuthenticatedEntity as QuoteLightweightNonAuthenticatedEntity
from wink_sdk_reference.models.quote_non_authenticated_entity import QuoteNonAuthenticatedEntity as QuoteNonAuthenticatedEntity
from wink_sdk_reference.models.show_social_networks400_response import ShowSocialNetworks400Response as ShowSocialNetworks400Response
from wink_sdk_reference.models.simple_description_non_authenticated_entity import SimpleDescriptionNonAuthenticatedEntity as SimpleDescriptionNonAuthenticatedEntity
from wink_sdk_reference.models.sort_object_non_authenticated_entity import SortObjectNonAuthenticatedEntity as SortObjectNonAuthenticatedEntity
from wink_sdk_reference.models.sub_country_lightweight_non_authenticated_entity import SubCountryLightweightNonAuthenticatedEntity as SubCountryLightweightNonAuthenticatedEntity
from wink_sdk_reference.models.sub_sub_country_lightweight_non_authenticated_entity import SubSubCountryLightweightNonAuthenticatedEntity as SubSubCountryLightweightNonAuthenticatedEntity

""",
            name=__name__,
            doc=__doc__,
        )
    )
