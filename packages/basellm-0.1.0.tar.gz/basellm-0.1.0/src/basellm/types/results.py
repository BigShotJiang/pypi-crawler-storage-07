from pydantic import BaseModel
from basellm.types.parts import ContentPart


class GenerateTextResult(BaseModel):
    text: str
    parts: list[ContentPart]