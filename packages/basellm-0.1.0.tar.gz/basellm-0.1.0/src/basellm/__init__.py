def hello() -> str:
    return "Hello from basellm!"
