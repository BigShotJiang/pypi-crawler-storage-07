"""Data and utilities for testing."""

from .datareader import DataReader, JapanStocks


TOYOTA = DataReader('72030')

