"""
## マニュアル

* [**クイックスタート ユーザーガイド**](../examples/Quick Start User Guide.py)

"""
from .backtest import Backtest
from .strategy import Strategy