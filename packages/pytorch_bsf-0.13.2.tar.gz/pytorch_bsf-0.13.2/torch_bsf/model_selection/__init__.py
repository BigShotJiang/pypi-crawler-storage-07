"""torch_bsf.model_selection: PyTorch implementation of Bezier simplex fitting.

This module provides methods for model selection.
"""
