"""
Bluetooth Remote Control Library

A robust Python library for handling Bluetooth remote controls that go to sleep,
combining udev device monitoring with evdev event handling for seamless
reconnection and event processing.

Author: Assistant
License: MIT
"""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"
__description__ = "A robust Python library for handling Bluetooth remote controls with automatic reconnection"

# Import main classes and types for easy access
from .device_monitor import (
    MultiInputDeviceMonitor,
)

from .utils import discover_input_devices

__all__ = [
    "MultiInputDeviceMonitor",
]

# Version info
VERSION_INFO = tuple(map(int, __version__.split('.')))