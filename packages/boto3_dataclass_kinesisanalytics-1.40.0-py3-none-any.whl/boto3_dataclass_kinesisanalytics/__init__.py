# -*- coding: utf-8 -*-

from .caster import kinesisanalytics_caster

caster = kinesisanalytics_caster

__version__ = "1.40.0"