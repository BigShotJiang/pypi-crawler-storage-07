from typing import Dict

# Тип отображения иконок по дате
DateIconMap = Dict[str, str]  # {"2025-07-03": "💪", ...}
