# -*- coding: utf-8 -*-
"""
Code related to algolia integration of taxonomy data.
"""
