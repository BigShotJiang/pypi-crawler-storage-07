GRPC_GENERAL_WARNING = (
    "Your ANSYS AEDT version is eligible to gRPC version."
    "You might consider switching to that version for better user experience."
    "For more information please check this link: https://edb.docs.pyansys.com/version/dev/grpc_api/index.html"
)
