""" """


class MaterialModelException(Exception):
    """Exception triggered when handling material model."""
