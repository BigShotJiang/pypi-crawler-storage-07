# Pyarmor 9.0.8 (ci), 008036, 2025-10-04T10:52:45.998070
from .pyarmor_runtime import __pyarmor__
