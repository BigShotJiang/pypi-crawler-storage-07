1. Go to Inventory > Configuration > Settings and Activate *Batch, Wave & Cluster Transfers* and *Multi-Step Routes*.
1. Go to Inventory > Configuration > Warehouses, select one warehouse and choose deliver in 2-steps or 3-steps.
1. Go to Inventory > Configuration > Routes, select 2-step or 3-step route and change rules to be pull - pull (- pull).
1. Go to Inventory > Configuration > Operations Types, select Pick Operation, select 'Planned Batches' and choose a Grouping criteria.
