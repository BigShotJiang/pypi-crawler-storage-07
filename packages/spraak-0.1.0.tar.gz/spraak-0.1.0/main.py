def main():
    print("Hello from spraak!")


if __name__ == "__main__":
    main()
