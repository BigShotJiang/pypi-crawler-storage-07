# Projeto_Mega-Homem
The Cut Man stage from Mega Man 1 (NES) remade with pygame

The following requisites are necessary to run the game:
* Python 3.11.0
* Pygame 2.6.1

# Running Instructions
To run this program it's required to execute the file game.py
with the python command
while pygame is active

# Controls
* Movement: WASD
* Jump: Space
* Shoot: J
