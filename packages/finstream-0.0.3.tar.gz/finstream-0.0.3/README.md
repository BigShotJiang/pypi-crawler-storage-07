# finstream Python SDK

Install (editable):

```bash
uv venv && uv pip install -e .
```

Usage:

```python
from finstream import version
print(version())
```


