.. include:: ../CONTRIBUTING.rst

