
paster serve server.ini %*
