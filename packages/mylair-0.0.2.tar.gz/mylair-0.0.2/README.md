# MyLair

A fun collection of terminal games created by Arhan Ali.  

Included games:
- Odd/Even
- Rock, Paper, Scissors
- Guess the Number
- f2f, i actually forgot what it is

Have fun playing in your terminal!  

*Fun fact:* Tom Holland's Peter Parker is the best Spider-Man 🕷️