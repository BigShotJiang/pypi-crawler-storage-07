# -*- coding: utf-8 -*-
# Copyright (C) 2025 Christian Tanzer All rights reserved
# tanzer@gg32.com.
# #*** <License> ************************************************************#
# This module is part of the package TFL.
#
# This module is licensed under the terms of the BSD 3-Clause License
# <http://www.gg32.com/license/bsd_3c.html>.
# #*** </License> ***********************************************************#
#
#++
# Name
#    TFL.Object_Formatter
#
# Purpose
#    Formatter for one or more objects
#
# Revision Dates
#    26-Sep-2025 (CT) Creation
#    ««revision-date»»···
#--

from   _TFL                         import TFL
from   _CAL                         import CAL

from   _TFL.predicate               import callable, filtered_join, split_hst
from   _TFL._Meta.Once_Property     import Once_Property

import _TFL.Caller
import _TFL._Meta.Object

class Formatter_Scope (TFL.Caller.Object_Scope) :

    def __getitem__ (self, index) :
        result = self.__super.__getitem__ (index)
        if result is None :
            result = ""
        return result
    # end def __getitem__

# end class Formatter_Scope

class Attr_Formatter (TFL.Meta.Object) :
    """Specify format for one attribute of an object.

    An `Attr_Formatter` knows how to format a single attribute of an object.

    >>> ffr = Attr_Formatter ("name", width = 10, attr_fmt = "%5.2f")
    >>> ffl = Attr_Formatter ("name", width = -10, attr_fmt = "%5.2f")
    >>> ffx = Attr_Formatter ("name?Pi", width = 10, attr_fmt = "%5.2f")
    >>> for ff in ffr, ffl, ffx :
    ...     print ("aligned_fmt=", repr (ff.aligned_fmt))
    ...     print ("header     =", repr (ff.header))
    ...     print ("formatted  =", repr (ff (3.1415)))
    ...     print ("---")
    aligned_fmt= '%(name)10.10s'
    header     = '      Name'
    formatted  = '      3.14'
    ---
    aligned_fmt= '%(name)-10s'
    header     = 'Name      '
    formatted  = ' 3.14     '
    ---
    aligned_fmt= '%(name)10.10s'
    header     = '        Pi'
    formatted  = '      3.14'
    ---

    """

    def __init__ \
            ( self, name
            , width         = 0
            , attr_fmt      = None
            , enforce_width = True
            ) :
        n, s, l             = split_hst (name, "?")
        self.name           = n
        self.label          = l if l else n.capitalize ()
        self.attr_fmt       = attr_fmt
        self.left_align     = width < 0
        self.width          = abs (width or len (self.label))
        self.enforce_width  = enforce_width and width > 0
    # end def __init__

    def __call__ (self, value) :
        if isinstance (value, TFL.Caller.Scope) :
            value = value [self.name]
        if (fmt := self.attr_fmt) is None :
            v   = str (value)
        elif value == "" :
            v   = value
        elif callable (fmt) :
            v   = fmt (value)
        else :
            v   = fmt % (value, )
        return self.aligned_fmt % { self.name : v }
    # end def __call__

    @Once_Property
    def aligned_fmt (self) :
        width   = self.width
        parts   = \
            [ "%"#
            , "(" + self.name + ")"
            , "-" if self.left_align else ""
            , "%d" % width
            , (".%d" % width) if self.enforce_width else ""
            , "s"
            ]
        return "".join (parts)
    # end def aligned_fmt

    @Once_Property
    def header (self) :
        return self.aligned_fmt % { self.name : self.label }
    # end def header

# end class Attr_Formatter

class Object_Formatter (TFL.Meta.Object) :
    r"""Formatter for one or more objects of the same type.

    An `Object_Formatter` is defined as a tuple of `Attr_Formatter` instances.

    >>> from _TFL.Record import Record as R
    >>> AF = Attr_Formatter

    >>> fmtr = Object_Formatter \
    ...     ( AF ("a?First", width = 10)
    ...     , AF ("b?Second", width = -10)
    ...     , AF ("c?Third", attr_fmt = "%5.2f", width = 5, enforce_width = True)
    ...     )

    >>> r1 = R (a = "Foo", b = 42, c = 3.1415)
    >>> r2 = R (a = "Bar", b = 23, c = 2.71)
    >>> r3 = R (a = "Qux", b = 137, c = 123)

    >>> fmtr (r1)
    '       Foo 42          3.14'

    >>> print (fmtr (r1, r2, r3))
         First Second     Third
    ===========================
           Foo 42          3.14
           Bar 23          2.71
           Qux 137        123.0

    """

    def __init__ (self, * attr_formatters, sep = " ") :
        self.attr_formatters    = attr_formatters
        self.sep                = sep
    # end def __init__

    def __call__ (self, * objs) :
        def _gen () :
            afs = self.attr_formatters
            sep = self.sep
            if len (objs) > 1 :
                h =  self.header
                yield h
                yield "=" * len (h)
            for o in objs :
                fs = Formatter_Scope (o)
                yield sep.join (af (fs) for af in afs)
        return "\n".join (_gen ())
    # end def __call__

    @Once_Property
    def header (self) :
        return self.sep.join (af.header for af in self.attr_formatters)
    # end def header

# end class Object_Formatter

if __name__ != "__main__" :
    TFL._Export ("*")
### __END__ TFL.Object_Formatter
