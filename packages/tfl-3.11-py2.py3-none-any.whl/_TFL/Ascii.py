# -*- coding: utf-8 -*-
# Copyright (C) 2004-2024 Christian Tanzer. All rights reserved
# tanzer@gg32.com                                      https://www.gg32.com
# ****************************************************************************
#
# This module is licensed under the terms of the BSD 3-Clause License
# <https://www.gg32.com/license/bsd_3c.html>.
# ****************************************************************************
#
#++
# Name
#    Ascii
#
# Purpose
#    Functions for unicode/ASCII handling
#
# Revision Dates
#     6-Sep-2004 (CT) Creation
#    13-May-2005 (CT) Call to `strip` added to `sanitized_filename`
#     9-Aug-2006 (CT) Use `unicodedata.normalize` (and simplify `_diacrit_map`)
#     9-Mar-2007 (CT) `_diacrit_map` corrected (`Oe` and `Ue` instead `O`/`U`)
#     9-Mar-2007 (CT) Optional `translate_table` added to `sanitized_unicode`
#                     and `sanitized_filename`
#    23-Dec-2007 (CT) Use `Re_Replacer` and `Dict_Replacer` instead of
#                     home-grown code
#    18-Oct-2010 (CT) `_quote_map` added and used
#    12-Oct-2015 (CT) Apply `pyk.decoded` to `result` of `_encoded`
#     9-Jun-2017 (CT) Add guard to, fix decoding/encoding in, `_main`
#     9-Jun-2017 (CT) Add `is_non_ascii` predicate
#     9-Jun-2017 (CT) Fix typo
#     1-Oct-2017 (CT) Add "´" to `_quote_map`
#     6-Oct-2017 (CT) Support wildcards for argument `file`
#    19-Mar-2024 (CT) Add support for `r"\n"` to `_main`
#    28-Sep-2024 (CT) Add option `-dry_run`
#    28-Sep-2024 (CT) Fix `sanitized` guard and apply to all branches of `_main`
#    28-Sep-2024 (CT) Add `,` to `_graph_rep`
#    28-Sep-2024 (CT) Add support for `@arg` (read filenames from file `arg`)
#                     + Factor `_files` from `_main`
#    ««revision-date»»···
#--

from   _TFL        import TFL
from   _TFL.pyk    import pyk
from   _TFL.Regexp import Regexp, Re_Replacer, Dict_Replacer, re

import _TFL.CAO
import _TFL.Trie

from   itertools   import chain as ichain
import unicodedata

_diacrit_map    = \
    { "Ä"      : "Ae"
    , "Ö"      : "Oe"
    , "Ü"      : "Ue"
    , "ß"      : "ss"
    , "ä"      : "ae"
    , "ö"      : "oe"
    , "ü"      : "ue"
    }

_diacrit_rep    = Dict_Replacer (_diacrit_map)

_graph_rep      = Re_Replacer \
    ( "(%s)+"
    % "|".join   (re.escape (c) for c in ("^!$%&([{}]) ?`'*+#:,;<>|" '"'))
    , "_"
    )

_non_print_rep  = Re_Replacer \
    ( "|".join (re.escape (chr (i)) for i in ichain (range (0, 32), [127]))
    , ""
    )

_quote_map      = \
    { "«"      : "<<"
    , "»"      : ">>"
    , "´"      : "'"
    , "\u2018" : "'"
    , "\u2019" : "'"
    , "\u201A" : "'"
    , "\u201B" : "'"
    , "\u201C" : '"'
    , "\u201D" : '"'
    , "\u201E" : '"'
    , "\u201F" : '"'
    , "\u2039" : "'"
    , "\u203A" : "'"
    }

_quote_rep      = Dict_Replacer (_quote_map)

def _encoded (s) :
    return pyk.decoded \
        (unicodedata.normalize ("NFKD", s).encode ("ascii", "ignore"))
# end def _encoded

def _sanitized_unicode (s, translate_table = None) :
    if translate_table :
        s = s.translate (translate_table)
    s = _quote_rep (_diacrit_rep (s))
    return s
# end def _sanitized_unicode

def _show (s) :
    from _TFL.portable_repr import portable_repr
    result = portable_repr (s)
    print (result)
# end def _show

def is_non_ascii (x) :
    """Return true if byte-string `x` contains non-ascii characters.

    >>> is_non_ascii ("abc")
    False

    >>> is_non_ascii ("äbc")
    True

    """
    y = pyk.encoded (x, "utf-8")
    try :
        y.decode ("ascii")
    except UnicodeDecodeError :
        return True
    else :
        return False
# end def is_non_ascii

def sanitized_unicode (s, translate_table = None) :
    """Return sanitized version of unicode string `s` reduced to
    pure ASCII 8-bit string. Caveat: passing in an 8-bit string with
    diacriticals doesn't work.

    >>> _show (sanitized_unicode ("üxäyözßuÜXÄYÖZbc¡ha!"))
    'uexaeyoezssuUeXAeYOeZbcha!'
    >>> _show (sanitized_unicode ("«ÄÖÜ»"))
    '<<AeOeUe>>'
    >>> _show \\
    ... (sanitized_unicode ("«ÄÖÜ»", {ord ("«") : "<", ord ("»") : ">"}))
    '<AeOeUe>'
    """
    return _encoded (_sanitized_unicode (s, translate_table))
# end def sanitized_unicode

def sanitized_filename (s, translate_table = None) :
   """Return `sanitized_unicode (s)` with all non-printable and some graphic
   characters removed so that the result is usable as a filename.

   >>> _show (sanitized_filename \\
   ...    ("überflüßig komplexer'; und $gefährlicher*' Filename"))
   'ueberfluessig_komplexer_und_gefaehrlicher_Filename'
   >>> _show (sanitized_filename ("«ÄÖÜß»"))
   '_AeOeUess_'

   >>> _show (sanitized_filename ("HDDs, SSDs"))
   'HDDs_SSDs'

   """
   s = _sanitized_unicode (s.strip (), translate_table)
   s = _non_print_rep     (s)
   s = _graph_rep         (s)
   return _encoded        (s)
# end def sanitized_filename

__doc__ = """
.. moduleauthor:: Christian Tanzer <tanzer@swing.co.at>

"""

def _files (cmd) :
    for f_b in cmd.argv :
        if f_b.startswith ("@") :
            with open (f_b [1:], "rb") as f :
                f_bx_s = sorted (f.read ().split (b"\n"))
                for f_bx in f_bx_s :
                    if f_bx := f_bx.strip () :
                        yield f_bx
        else :
            yield f_b
# end def _files

def _main (cmd) :
    """For each argument, write sanitized_filename to stdout. If `-rename` is
       specified, the files are renamed to the sanitized_filenames instead.
    """
    from _TFL     import sos
    from _TFL.pyk import pyk
    sep = cmd.separator
    tri = TFL.Word_Trie ()
    if sep == r"\n" :
        sep     = "\n"
    for f_b in _files (cmd) :
        f       = pyk.decoded (f_b)
        sf      = sanitized_filename (f)
        sf_b    = pyk.encoded (sf)
        ### Fix prefix directories that have been renamed already
        lpw, _  = tri.longest_prefix (sf)
        lpl     = len (lpw)
        if lpw and sf [lpl : lpl+1] == "/" :
            f   = lpw + f [lpl:]
            f_b = pyk.encoded (f)
        tri.add (sf)
        if f != sf and sos.path.exists (f_b) :
            if cmd.dry_run :
                print ("Would rename", f, "to", sf)
            elif cmd.rename :
                sos.rename (f_b, sf_b)
                if cmd.verbose :
                    print ("Renamed", f, "to", sf)
            else :
                print (sf, end = sep)
# end def _main

_Command = TFL.CAO.Cmd \
    ( handler       = _main
    , args          =
        ( "file:P:?File(s) to rename"
        ,
        )
    , opts          =
        ( TFL.CAO.Opt.Input_Encoding
            ( description   = "Input encoding"
            , default       = "utf-8"
            )
        , "-dry_run:B?Show what `-rename` would do"
        , "-rename:B?Rename the files to names by `sanitized_filename`"
        , "-separator:S= "
        , "-verbose:B"
        )
    , min_args      = 1
    )

if __name__ == "__main__" :
    _Command ()
else :
    TFL._Export_Module ()
### __END__ Ascii
