# -*- coding: utf-8 -*-
# Copyright (C) 2025 Christian Tanzer All rights reserved
# tanzer@gg32.com.
# #*** <License> ************************************************************#
# This module is part of the package TFL.
#
# This module is licensed under the terms of the BSD 3-Clause License
# <http://www.gg32.com/license/bsd_3c.html>.
# #*** </License> ***********************************************************#
#
#++
# Name
#    DMARC
#
# Purpose
#    Parse DMARC reports and extract information like status and IP address
#
# Revision Dates
#     5-May-2025 (CT) Creation
#    10-May-2025 (CT) Use regexp to match failures, add `(P:hard)?` to regexp
#    ««revision-date»»···
#--

from   _TFL                         import TFL

from   _TFL.Filename                import Filename
from   _TFL.Q_Exp                   import Q
from   _TFL.predicate               import bool_split
from   _TFL.pyk                     import pyk

from   _TFL._Meta.Once_Property     import Once_Property

import _TFL.CAO

import _TFL._Meta.Object

from   contextlib                   import contextmanager

from   bz2                          import open  as bz_open
from   gzip                         import open  as gz_open
from   lzma                         import open  as xz_open

import bs4
import re
import zipfile as ZF

@contextmanager
def zip_open (path, mode) :
    with ZF.ZipFile (path, mode) as zf :
        fs = zf.namelist ()
        if len (fs) == 1 and fs [0].endswith (".xml") :
            xml_path = fs [0]
            with zf.open (xml_path, mode) as f :
                yield f
        else :
            raise NotImplementedError \
                ("zipfile with %s members: %s" % (len (fs), ", ".joins (fs)))
# end def zip_open

open_map        = dict \
    ( bz2       = bz_open
    , gz        = gz_open
    , xml       = open
    , xz        = xz_open
    , zip       = zip_open
    )

_fail_pat = re.compile (r"(P:hard)?fail")

class Record (TFL.Meta.Object) :
    """Model a record of a DMARC report"""

    def __init__ (self, body) :
        self.body   = body
    # end def __init__

    @Once_Property
    def failures (self) :
        return self.body.find_all ("result", string = _fail_pat)
    # end def failures

    @Once_Property
    def IP_address (self) :
        return self.body.source_ip.text
    # end def IP_address

    @Once_Property
    def is_failure (self) :
        return bool (self.failures)
    # end def is_failure

    @Once_Property
    def status (self) :
        return "failed" if self.is_failure else "valid"
    # end def status

    def __repr__ (self) :
        return "<%-12s : %s>" % (self.IP_address, self.status)
    # end def __repr__

    def __str__ (self) :
        return self.body.prettify ()
    # end def __str__

# end class Record

class Report (TFL.Meta.Object) :
    """Model a DMARC report"""

    bs4_parser      = "xml"

    _failures       = None
    _successes      = None

    def __init__ (self, xml, path = None) :
        self.body   = xml
        self.path   = path
    # end def __init__

    @classmethod
    def from_file (cls, path) :
        """Read DMARC report from file at `path`"""
        fn      = Filename (path)
        opener  = open_map.get (fn.ext [1:], open)
        with opener (path, "r") as f :
            xml = pyk.decoded (f.read ())
        return cls (xml, path)
    # end def from_file

    @Once_Property
    def failed_IP_addresses (self) :
        return tuple (f.IP_address for f in self.failures)
    # end def failed_IP_addresses

    @Once_Property
    def failures (self) :
        if (result := self._failures) is None :
            self._qualify_records ()
            result  = self._failures
        return result
    # end def failures

    @Once_Property
    def org_name (self) :
        return self.soup.org_name.text
    # end def org_name

    @Once_Property
    def soup (self) :
        return bs4.BeautifulSoup (self.body, self.bs4_parser)
    # end def soup

    @Once_Property
    def records (self) :
        return tuple \
            (Record (r) for r in self.soup.feedback.find_all ("record"))
    # end def records

    @Once_Property
    def successes (self) :
        if (result := self._successes) is None :
            self._qualify_records ()
            result  = self._successes
        return result
    # end def successes

    def _qualify_records (self) :
        self._successes, self._failures = bool_split \
            (self.records, Q.is_failure)
    # end def _qualify_records

# end class Report

def _main (cmd) :
    for arg in cmd.argv :
        rep = Report.from_file (arg)
        for rec in rep.records :
            print (rec)
# end def _main

_Command = TFL.CAO.Cmd \
    ( handler       = _main
    , args          =
        ( "xml_path:P:?DMARC report(s) to process"
        ,
        )
    , min_args      = 1
    )

if __name__ != "__main__" :
    TFL._Export_Module ()
else :
    _Command ()
### __END__ DMARC
