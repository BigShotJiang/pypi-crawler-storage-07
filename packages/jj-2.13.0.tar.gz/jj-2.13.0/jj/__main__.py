from ._entry_point import run

if __name__ == "__main__":
    run()
