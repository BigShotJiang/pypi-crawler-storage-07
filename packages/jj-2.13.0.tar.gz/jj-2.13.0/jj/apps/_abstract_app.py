__all__ = ("AbstractApp",)


class AbstractApp:
    pass
