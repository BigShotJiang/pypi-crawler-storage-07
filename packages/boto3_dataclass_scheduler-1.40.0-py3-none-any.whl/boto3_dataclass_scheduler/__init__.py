# -*- coding: utf-8 -*-

from .caster import scheduler_caster

caster = scheduler_caster

__version__ = "1.40.0"