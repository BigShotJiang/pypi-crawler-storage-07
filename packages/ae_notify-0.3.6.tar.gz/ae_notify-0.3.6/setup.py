# THIS FILE IS EXCLUSIVELY MAINTAINED by the project aedev.project_tpls v0.3.57
""" setup of ae namespace module portion notify: send notifications via email, telegram or whatsapp. """
# noinspection PyUnresolvedReferences
import sys
print(f"SetUp {__name__=} {sys.executable=} {sys.argv=} {sys.path=}")

# noinspection PyUnresolvedReferences
import setuptools

setup_kwargs = {
    'author': 'AndiEcker',
    'author_email': 'aecker2@gmail.com',
    'classifiers': [       'Development Status :: 3 - Alpha', 'Natural Language :: English', 'Operating System :: OS Independent',
        'Programming Language :: Python', 'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.9', 'Topic :: Software Development :: Libraries :: Python Modules',
        'Typing :: Typed'],
    'description': 'ae namespace module portion notify: send notifications via email, telegram or whatsapp',
    'extras_require': {       'dev': [       'aedev_project_tpls', 'ae_ae', 'anybadge', 'coverage-badge', 'aedev_project_manager', 'flake8',
                       'mypy', 'pylint', 'pytest', 'pytest-cov', 'pytest-django', 'typing', 'types-setuptools'],
        'docs': [],
        'tests': [       'anybadge', 'coverage-badge', 'aedev_project_manager', 'flake8', 'mypy', 'pylint', 'pytest',
                         'pytest-cov', 'pytest-django', 'typing', 'types-setuptools']},
    'install_requires': ['ae_base', 'requests', 'types-requests'],
    'keywords': ['configuration', 'development', 'environment', 'productivity'],
    'license': 'GPL-3.0-or-later',
    'long_description': ('<!-- THIS FILE IS EXCLUSIVELY MAINTAINED by the project ae.ae v0.3.97 -->\n'
 '<!-- THIS FILE IS EXCLUSIVELY MAINTAINED by the project aedev.namespace_root_tpls v0.3.19 -->\n'
 '# notify 0.3.6\n'
 '\n'
 '[![GitLab develop](https://img.shields.io/gitlab/pipeline/ae-group/ae_notify/develop?logo=python)](\n'
 '    https://gitlab.com/ae-group/ae_notify)\n'
 '[![LatestPyPIrelease](\n'
 '    https://img.shields.io/gitlab/pipeline/ae-group/ae_notify/release0.3.6?logo=python)](\n'
 '    https://gitlab.com/ae-group/ae_notify/-/tree/release0.3.6)\n'
 '[![PyPIVersions](https://img.shields.io/pypi/v/ae_notify)](\n'
 '    https://pypi.org/project/ae-notify/#history)\n'
 '\n'
 '>ae namespace module portion notify: send notifications via email, telegram or whatsapp.\n'
 '\n'
 '[![Coverage](https://ae-group.gitlab.io/ae_notify/coverage.svg)](\n'
 '    https://ae-group.gitlab.io/ae_notify/coverage/index.html)\n'
 '[![MyPyPrecision](https://ae-group.gitlab.io/ae_notify/mypy.svg)](\n'
 '    https://ae-group.gitlab.io/ae_notify/lineprecision.txt)\n'
 '[![PyLintScore](https://ae-group.gitlab.io/ae_notify/pylint.svg)](\n'
 '    https://ae-group.gitlab.io/ae_notify/pylint.log)\n'
 '\n'
 '[![PyPIImplementation](https://img.shields.io/pypi/implementation/ae_notify)](\n'
 '    https://gitlab.com/ae-group/ae_notify/)\n'
 '[![PyPIPyVersions](https://img.shields.io/pypi/pyversions/ae_notify)](\n'
 '    https://gitlab.com/ae-group/ae_notify/)\n'
 '[![PyPIWheel](https://img.shields.io/pypi/wheel/ae_notify)](\n'
 '    https://gitlab.com/ae-group/ae_notify/)\n'
 '[![PyPIFormat](https://img.shields.io/pypi/format/ae_notify)](\n'
 '    https://pypi.org/project/ae-notify/)\n'
 '[![PyPILicense](https://img.shields.io/pypi/l/ae_notify)](\n'
 '    https://gitlab.com/ae-group/ae_notify/-/blob/develop/LICENSE.md)\n'
 '[![PyPIStatus](https://img.shields.io/pypi/status/ae_notify)](\n'
 '    https://libraries.io/pypi/ae-notify)\n'
 '[![PyPIDownloads](https://img.shields.io/pypi/dm/ae_notify)](\n'
 '    https://pypi.org/project/ae-notify/#files)\n'
 '\n'
 '\n'
 '## installation\n'
 '\n'
 '\n'
 'execute the following command to install the\n'
 'ae.notify module\n'
 'in the currently active virtual environment:\n'
 ' \n'
 '```shell script\n'
 'pip install ae-notify\n'
 '```\n'
 '\n'
 'if you want to contribute to this portion then first fork\n'
 '[the ae_notify repository at GitLab](\n'
 'https://gitlab.com/ae-group/ae_notify "ae.notify code repository").\n'
 'after that pull it to your machine and finally execute the\n'
 'following command in the root folder of this repository\n'
 '(ae_notify):\n'
 '\n'
 '```shell script\n'
 'pip install -e .[dev]\n'
 '```\n'
 '\n'
 'the last command will install this module portion, along with the tools you need\n'
 'to develop and run tests or to extend the portion documentation. to contribute only to the unit tests or to the\n'
 'documentation of this portion, replace the setup extras key `dev` in the above command with `tests` or `docs`\n'
 'respectively.\n'
 '\n'
 'more detailed explanations on how to contribute to this project\n'
 '[are available here](\n'
 'https://gitlab.com/ae-group/ae_notify/-/blob/develop/CONTRIBUTING.rst)\n'
 '\n'
 '\n'
 '## namespace portion documentation\n'
 '\n'
 'information on the features and usage of this portion are available at\n'
 '[ReadTheDocs](\n'
 'https://ae.readthedocs.io/en/latest/_autosummary/ae.notify.html\n'
 '"ae_notify documentation").\n'),
    'long_description_content_type': 'text/markdown',
    'name': 'ae_notify',
    'package_data': {'': []},
    'packages': ['ae'],
    'project_urls': {       'Bug Tracker': 'https://gitlab.com/ae-group/ae_notify/-/issues',
        'Documentation': 'https://ae.readthedocs.io/en/latest/_autosummary/ae.notify.html',
        'Repository': 'https://gitlab.com/ae-group/ae_notify',
        'Source': 'https://ae.readthedocs.io/en/latest/_modules/ae/notify.html'},
    'python_requires': '>=3.9',
    'url': 'https://gitlab.com/ae-group/ae_notify',
    'version': '0.3.6',
    'zip_safe': True,
}

if __name__ == "__main__":
    setuptools.setup(**setup_kwargs)
    pass
