# Core demo CLI and helpers package
