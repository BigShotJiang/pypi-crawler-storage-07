from .client import InferenceClient

__all__ = [
    "InferenceClient",
]


