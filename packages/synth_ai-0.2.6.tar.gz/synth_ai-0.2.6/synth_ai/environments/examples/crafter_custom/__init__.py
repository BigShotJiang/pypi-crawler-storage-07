"""Custom Crafter environments with configurable world generation."""

# Note: Registration happens in the service app.py file
# This module just provides the CrafterCustomEnvironment class
