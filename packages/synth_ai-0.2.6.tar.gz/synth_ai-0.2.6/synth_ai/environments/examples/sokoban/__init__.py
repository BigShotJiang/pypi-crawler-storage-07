"""Sokoban environment example."""
