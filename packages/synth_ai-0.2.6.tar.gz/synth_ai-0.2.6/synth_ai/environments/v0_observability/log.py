class EnvironmentStepRecord:
    pass
