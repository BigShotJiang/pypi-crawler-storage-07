## Gemini


## OpenAI


## Synth
