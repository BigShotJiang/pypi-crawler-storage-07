declare module 'whatwg-fetch';
