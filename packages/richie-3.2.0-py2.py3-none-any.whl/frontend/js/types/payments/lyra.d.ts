interface Window {
  KR?: KR;
}
