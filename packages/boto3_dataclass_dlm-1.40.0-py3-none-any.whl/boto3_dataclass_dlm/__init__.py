# -*- coding: utf-8 -*-

from .caster import dlm_caster

caster = dlm_caster

__version__ = "1.40.0"