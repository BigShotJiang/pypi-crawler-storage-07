#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
Date: 2019/11/14 20:32
Desc: 学术板块配置文件
"""

# EPU
epu_home_url = "http://www.policyuncertainty.com/index.html"

# FF-Factor
ff_home_url = "http://mba.tuck.dartmouth.edu/pages/faculty/ken.french/data_library.html"
