# SPDX-License-Identifier: MIT
# Copyright (c) 2025 Klaudiusz Staniek

from .bus import CannelloniBus

__all__ = ["CannelloniBus"]
