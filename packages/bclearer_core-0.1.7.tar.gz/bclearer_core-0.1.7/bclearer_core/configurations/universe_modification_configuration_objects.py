class UniverseModificationConfigurationObjects:
    pass
