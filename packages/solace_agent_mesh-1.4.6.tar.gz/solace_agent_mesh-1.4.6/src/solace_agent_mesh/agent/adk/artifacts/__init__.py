"""Artifact service implementations for Solace Agent Mesh."""
