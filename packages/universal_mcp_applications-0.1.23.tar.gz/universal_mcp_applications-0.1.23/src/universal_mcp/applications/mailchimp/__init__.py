from .app import MailchimpApp
