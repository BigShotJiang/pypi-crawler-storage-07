"""Tests for fastrict package."""
