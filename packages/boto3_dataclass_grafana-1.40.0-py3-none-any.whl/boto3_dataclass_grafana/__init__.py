# -*- coding: utf-8 -*-

from .caster import grafana_caster

caster = grafana_caster

__version__ = "1.40.0"