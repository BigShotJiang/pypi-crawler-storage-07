import json
import sys


def get_inputs():
    return json.load(sys.stdin)
