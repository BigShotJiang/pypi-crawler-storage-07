default_domain = "chefhub.smartflowagent.net"

default_doc_server = f"https://doc.{default_domain}"
default_scp_server = f"https://scp-app-store.{default_domain}"
default_sam_server = f"https://sam.{default_domain}"
