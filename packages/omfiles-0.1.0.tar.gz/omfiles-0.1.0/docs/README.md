# omfiles docs

Some methods are currently not correctly described in this documentation because of

- https://github.com/PyO3/pyo3/issues/4326
- and because I cannot get Sphinx to use the pyi stub file for the native code.
