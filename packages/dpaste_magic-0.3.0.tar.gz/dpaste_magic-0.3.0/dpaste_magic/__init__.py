from .dpaste_magic import *

__version__ = '0.1.2'
