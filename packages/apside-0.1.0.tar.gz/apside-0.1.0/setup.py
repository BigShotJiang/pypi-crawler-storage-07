# setup.py
from setuptools import setup
from pathlib import Path

README = Path(__file__).with_name("README.md").read_text(encoding="utf-8")

setup(
    name="apside",
    version="0.1.0",
    description="High-precision conversion between Gregorian calendar datetimes and Julian Dates (JD)",
    long_description=README,
    long_description_content_type="text/markdown",
    license="MIT",
    author="Venkata Siddharth Pendyala",
    author_email="venkatasiddharthpendyala@outlook.com",
    url="https://github.com/VPyndyala/Apside",
    project_urls={
        "Homepage": "https://github.com/VPyndyala/Apside",
        "Documentation": "https://github.com/VPyndyala/Apside#readme",
        "Source": "https://github.com/VPyndyala/Apside",
        "Issues": "https://github.com/VPyndyala/Apside/issues",
    },
    python_requires=">=3.8",
    install_requires=[],  # no runtime dependencies
    # If your code is a single module file at the repo root: apside.py
    py_modules=["apside"],
    # If instead you have a package directory (src/apside/__init__.py), switch to:
    # packages=find_packages(where="src"),
    # package_dir={"": "src"},
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Topic :: Scientific/Engineering :: Astronomy",
        "Topic :: Software Development :: Libraries",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    keywords=[
        "astronomy",
        "time",
        "julian",
        "calendar",
        "precision",
        "high-precision",
        "decimal",
        "nanosecond",
    ],
    include_package_data=True,
    zip_safe=False,
)
