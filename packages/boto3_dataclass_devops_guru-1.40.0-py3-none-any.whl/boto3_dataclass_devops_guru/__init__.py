# -*- coding: utf-8 -*-

from .caster import devops_guru_caster

caster = devops_guru_caster

__version__ = "1.40.0"