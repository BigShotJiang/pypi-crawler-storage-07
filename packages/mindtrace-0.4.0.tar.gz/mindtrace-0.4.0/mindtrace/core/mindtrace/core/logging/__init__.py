from mindtrace.core.logging.logger import Logger

__all__ = ["Logger"]
