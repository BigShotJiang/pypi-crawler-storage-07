"""DELFIN main entry point."""
# noinspection PyUnresolvedReferences
from .cli import main

"""
Please start this file only as a module with:
python -m delfin
or install delfin via "pip install -e ." and run:
delfin
"""