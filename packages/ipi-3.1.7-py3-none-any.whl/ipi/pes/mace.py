"""An interface for the [MACE](https://github.com/ACEsuit/mace) calculator"""

import json

from .ase import ASEDriver
from mace.calculators import MACECalculator
from ase.outputs import _defineprop, all_outputs

# avoid duplicate
# it complains with a committee of ffdirect MACE models
if "node_energy" not in all_outputs:
    _defineprop("node_energy", dtype=float, shape=("natoms",))

__DRIVER_NAME__ = "mace"
__DRIVER_CLASS__ = "MACE_driver"


class MACE_driver(ASEDriver):
    """
    Driver for the MACE MLIPs.
    The driver requires specification of a torch model,
    and a template file that describes the chemical makeup
    of the structure.

    Command-line:
    i-pi-py_driver -m mace -u -a address -o template=structure.xyz,model=mace_mp.model

    Parameters:
    :param template: string, filename of an ASE-readable structure file
        to initialize atomic number and types
    :param model: string, filename of the MACE model
    """

    def __init__(
        self, template, model, device="cpu", mace_kwargs=None, *args, **kwargs
    ):

        self.model = model
        self.device = device
        self.mace_kwargs = {}
        if mace_kwargs is not None:
            with open(mace_kwargs, "r") as f:
                self.mace_kwargs = json.load(f)

        super().__init__(template, *args, **kwargs)

    def check_parameters(self):
        """Check the arguments requuired to run the driver

        This loads the potential and atoms template in MACE
        """

        super().check_parameters()

        self.ase_calculator = MACECalculator(
            model_paths=self.model, device=self.device, **self.mace_kwargs
        )
