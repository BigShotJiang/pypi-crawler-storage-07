"""Tests for MCPCat."""
