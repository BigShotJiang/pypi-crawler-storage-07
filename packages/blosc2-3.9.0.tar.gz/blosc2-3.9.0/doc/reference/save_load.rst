Save and load
-------------

.. currentmodule:: blosc2

.. autosummary::
    save
    open
    save_array
    load_array
    save_tensor
    load_tensor
    from_cframe

.. autofunction:: save
.. autofunction:: open
.. autofunction:: save_array
.. autofunction:: load_array
.. autofunction:: save_tensor
.. autofunction:: load_tensor
.. autofunction:: from_cframe
