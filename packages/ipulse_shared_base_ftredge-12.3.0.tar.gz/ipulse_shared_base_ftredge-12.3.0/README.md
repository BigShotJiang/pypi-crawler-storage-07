# ipulse_shared_enums
Shared Enums for the whole project



### Enums 

Contains majority of all Enums used in Pulse
