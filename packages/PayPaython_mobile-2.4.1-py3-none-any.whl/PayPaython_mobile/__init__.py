from .main import PayPay,PayPayLoginError,PayPayError,PayPayNetWorkError
__version__      = '2.4.1'
__url__          = 'https://github.com/taka-4602/PayPaython-mobile'
