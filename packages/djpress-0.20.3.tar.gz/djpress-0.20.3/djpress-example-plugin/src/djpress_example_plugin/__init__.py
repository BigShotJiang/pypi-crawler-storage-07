"""DJ Press example plugin."""
