"""
Server orchestration for file transfer protocols.

Provides a framework for starting and stopping
servers meant for file transfers in a plugin-based
manner.
"""
