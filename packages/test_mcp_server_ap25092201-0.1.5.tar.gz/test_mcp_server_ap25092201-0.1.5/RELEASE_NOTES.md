release 0.1.5: fix(patch)

Changes
--------------------------------------------------------------------------------
- 🔧 fix: redirect startup message to stderr

