from pcloud import PCloud, PCloudOAuth2Flow
app_key="4hQ2I2F9T3V"
app_secret="S1RuAXoVftkX9WGhywG5hJL7iogV"



# No redirect: user will see a 10-minute code (and a hostname like eapi.pcloud.com)
flow = PCloudOAuth2Flow(app_key, app_secret, location="EU")

print("Open this URL and click Allow:")
print(flow.start(state="xyz"))

code = input("Paste the code shown on the page: ").strip()

token = flow.finish(code)

pc = PCloud(access_token=token.access_token, location="EU")
print(pc.files.list_folder(folderid=0))
