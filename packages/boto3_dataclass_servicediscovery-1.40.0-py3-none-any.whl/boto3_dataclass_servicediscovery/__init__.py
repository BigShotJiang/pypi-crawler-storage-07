# -*- coding: utf-8 -*-

from .caster import servicediscovery_caster

caster = servicediscovery_caster

__version__ = "1.40.0"