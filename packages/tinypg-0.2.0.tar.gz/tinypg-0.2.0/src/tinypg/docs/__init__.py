"""Additional narrative documentation for TinyPG's pdoc site."""
