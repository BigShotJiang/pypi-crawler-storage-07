"""Tests for petcache."""
