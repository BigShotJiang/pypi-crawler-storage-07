"""
VibeVoice API: OpenAI-compatible Audio API server powered by VibeVoice.

Expose endpoint compatible with openai-python for audio.speech.
"""

__all__ = [
    "__version__",
]

__version__ = "0.1.0"
