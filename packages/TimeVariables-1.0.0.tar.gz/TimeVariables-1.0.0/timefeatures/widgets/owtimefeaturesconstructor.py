"""
Time Feature Constructor

A widget for defining (constructing) new time features from values
of other variables.

"""
import re
import copy
import functools
import builtins
import math
import random
import logging
import ast
import unicodedata

from concurrent.futures import CancelledError
from dataclasses import dataclass
from traceback import format_exception_only
from collections import namedtuple, OrderedDict
from itertools import chain, count
from typing import Any, Dict, List, Mapping, Optional, Tuple

import numpy as np

from AnyQt.QtWidgets import (
    QSizePolicy, QAbstractItemView, QComboBox, QLineEdit,
    QHBoxLayout, QVBoxLayout, QStackedWidget, QStyledItemDelegate,
    QPushButton, QMenu, QListView, QFrame, QLabel, QMessageBox,
    QGridLayout, QWidget, QCheckBox)
from AnyQt.QtGui import QKeySequence
from AnyQt.QtCore import Qt, pyqtSignal as Signal, pyqtProperty as Property

from orangewidget.utils.combobox import ComboBoxSearch

import Orange
from Orange.preprocess.transformation import MappingTransform
from Orange.util import frompyfunc
from Orange.data import Variable, Table, Value, Instance, Domain, StringVariable
from Orange.data.util import get_unique_names
from Orange.widgets import gui
from Orange.widgets.settings import ContextSetting, DomainContextHandler
from Orange.widgets.utils import (
    itemmodels, vartype, unique_everseen as unique
)
from Orange.widgets.utils.sql import check_sql_input
from Orange.widgets import report
from Orange.widgets.utils.widgetpreview import WidgetPreview
from Orange.widgets.widget import OWWidget, Msg, Input, Output
from Orange.widgets.utils.concurrent import ConcurrentWidgetMixin, TaskState
from Orange.widgets.settings import Setting


FeatureDescriptor = \
    namedtuple("FeatureDescriptor", ["name", "expression", "meta"],
               defaults=[False])

ContinuousDescriptor = \
    namedtuple("ContinuousDescriptor",
               ["name", "expression", "number_of_decimals", "meta"],
               defaults=[False])
DateTimeDescriptor = \
    namedtuple("DateTimeDescriptor",
               ["name", "expression", "meta"],
               defaults=[False])
DiscreteDescriptor = \
    namedtuple("DiscreteDescriptor",
               ["name", "expression", "values", "ordered", "meta"],
               defaults=[False])

StringDescriptor = \
    namedtuple("StringDescriptor",
               ["name", "expression", "meta"],
               defaults=[True])


def make_variable(descriptor, compute_value):
    if isinstance(descriptor, ContinuousDescriptor):
        return Orange.data.ContinuousVariable(
            descriptor.name,
            descriptor.number_of_decimals,
            compute_value)
    if isinstance(descriptor, DateTimeDescriptor):
        return Orange.data.TimeVariable(
            descriptor.name,
            compute_value=compute_value, have_date=True, have_time=True)
    elif isinstance(descriptor, DiscreteDescriptor):
        return Orange.data.DiscreteVariable(
            descriptor.name,
            values=descriptor.values,
            compute_value=compute_value)
    elif isinstance(descriptor, StringDescriptor):
        return Orange.data.StringVariable(
            descriptor.name,
            compute_value=compute_value)
    else:
        raise TypeError


# Función para modificar la expresión original
# para que pueda ser leida por eval()
def modificar_expression(expression):
    # Encontrar todas las coincidencias con las funciones temporales y almacenarlas
    matches_shift = list(re.finditer(r'shift\(([^,]+),([-+]?\d+)\)', expression))
    matches_sum = list(re.finditer(r'sum\(([^,]+),([-+]?\d+),([-+]?\d+)\)', expression))
    matches_mean = list(re.finditer(r'mean\(([^,]+),([-+]?\d+),([-+]?\d+)\)', expression))
    matches_count = list(re.finditer(r'count\(([^,]+),([-+]?\d+),([-+]?\d+)\)', expression))
    matches_min = list(re.finditer(r'min\(([^,]+),([-+]?\d+),([-+]?\d+)\)', expression))
    matches_max = list(re.finditer(r'max\(([^,]+),([-+]?\d+),([-+]?\d+)\)', expression))
    matches_sd = list(re.finditer(r'sd\(([^,]+),([-+]?\d+),([-+]?\d+)\)', expression))

    # Variables para contar matches
    match_counter_shift = 0
    match_counter_sum = 0
    match_counter_mean = 0
    match_counter_count = 0
    match_counter_min = 0
    match_counter_max = 0
    match_counter_sd = 0
    modified_expression = expression

    # Iterar sobre todas las coincidencias de shift y cambiar la expresión
    for match in matches_shift:
        variable_name = match.group(1)
        shift_value = match.group(2)

        # Construir la nueva expresión con el número incremental
        new_shift = f'shift{match_counter_shift}({variable_name},{shift_value})'

        # Reemplazar solo la coincidencia actual en la expresión
        modified_expression = modified_expression.replace(match.group(0), new_shift, 1)

        match_counter_shift += 1

    for match in matches_sum:
        variable_name = match.group(1)
        sum_value1 = match.group(2)
        sum_value2 = match.group(3)

        new_sum = f'sum{match_counter_sum}({variable_name},{sum_value1},{sum_value2})'

        modified_expression = modified_expression.replace(match.group(0), new_sum, 1)

        match_counter_sum += 1

    for match in matches_mean:
        variable_name = match.group(1)
        mean_value1 = match.group(2)
        mean_value2 = match.group(3)

        new_mean = f'mean{match_counter_mean}({variable_name},{mean_value1},{mean_value2})'

        modified_expression = modified_expression.replace(match.group(0), new_mean, 1)

        match_counter_mean += 1

    for match in matches_count:
        variable_name = match.group(1)
        count_value1 = match.group(2)
        count_value2 = match.group(3)

        new_count = f'count{match_counter_count}({variable_name},{count_value1},{count_value2})'

        modified_expression = modified_expression.replace(match.group(0), new_count, 1)

        match_counter_count += 1

    for match in matches_min:
        variable_name = match.group(1)
        min_value1 = match.group(2)
        min_value2 = match.group(3)

        new_min = f'min{match_counter_min}({variable_name},{min_value1},{min_value2})'

        modified_expression = modified_expression.replace(match.group(0), new_min, 1)

        match_counter_min += 1

    for match in matches_max:
        variable_name = match.group(1)
        max_value1 = match.group(2)
        max_value2 = match.group(3)

        new_max = f'max{match_counter_max}({variable_name},{max_value1},{max_value2})'

        modified_expression = modified_expression.replace(match.group(0), new_max, 1)

        match_counter_max += 1

    for match in matches_sd:
        variable_name = match.group(1)
        sd_value1 = match.group(2)
        sd_value2 = match.group(3)

        new_sd = f'sd{match_counter_sd}({variable_name},{sd_value1},{sd_value2})'

        modified_expression = modified_expression.replace(match.group(0), new_sd, 1)

        match_counter_sd += 1

    return modified_expression


def shift_function(var, z, tabla=None, cont=None):  # ----FUNCIÓN SHIFT()----

    if z == 0:
        return var

    nuevo_cont = (cont + z)

    if nuevo_cont < 0 or nuevo_cont >= len(tabla):  # Si nuevo_cont excede los límites de la tabla
        return None

    if tabla[nuevo_cont] is None:
        return None

    nuevo_valor = tabla[nuevo_cont]

    return nuevo_valor

def expand_shiftbatch(expression, base_name):

    expanded_descriptors = []
    pattern = r'shiftBatch\(([^,]+),\s*(\d+)\)'
    matches = re.finditer(pattern, expression)

    for match in matches:
        var_name = match.group(1).strip()
        n = int(match.group(2))
        for i in range(1, n + 1):
            expr = f'shift({var_name},-{i})'
            new_name = f'{base_name}_{var_name}_t-{i}'
            descriptor = ContinuousDescriptor(
                name=new_name,
                expression=expr,
                number_of_decimals=3,
                meta=False
            )
            expanded_descriptors.append(descriptor)

    return expanded_descriptors

def sum_function(var, z, x, tabla=None, cont=None):  # ----FUNCIÓN SUM()----

    if tabla is None or cont is None:
        return None

    if z == x:
        return var

    nuevo_valor = 0

    count = 0
    indices = range(z, x + 1)

    # Sumar valores desde el índice cont + x hasta el índice cont + z, excluyendo valores nulos
    for i in indices:
        index = (cont + i)
        if 0 <= index < len(tabla):
            if not math.isnan(tabla[index]):
                count += 1
                nuevo_valor += tabla[index]

    if count > 0:
        return nuevo_valor
    else:
        return None


def mean_function(var, z, x, tabla=None, cont=None):  # ----FUNCIÓN MEAN()----

    if tabla is None or cont is None:
        return None

    if z == x:
        return var

    nuevo_valor = 0
    count = 0

    indices = range(z, x + 1)

    # Sumar valores desde el índice cont + x hasta el índice cont + z, excluyendo valores nulos
    for i in indices:
        index = (cont + i)
        if 0 <= index < len(tabla):
            if not math.isnan(tabla[index]):
                nuevo_valor += tabla[index]
                count += 1

    # Calcular la media dividiendo la suma por la cantidad de valores no nulos
    if count > 0:
        media = nuevo_valor / count
        return media
    else:
        return None


def count_function(var, z, x, tabla=None, cont=None):  # ----FUNCIÓN COUNT()----

    if tabla is None or cont is None or x is None:
        return None

    count = 0

    if z == x and not math.isnan(var):
        return 1
    else:
        indices = range(z, x + 1)

        # Contar valores no nulos desde el índice cont + x hasta el índice cont + z
        for i in indices:
            index = (cont + i)
            if 0 <= index < len(tabla):
                if not math.isnan(tabla[index]):
                    count += 1

        if count > 0:
            return count
        else:
            return None


def min_function(var, z, x, tabla=None, cont=None):  # ----FUNCIÓN MIN()----

    if tabla is None or cont is None or x is None:
        return None

    min_value = float('inf')  # Infinito

    if z == x and not math.isnan(var):
        return var
    else:
        indices = range(z, x + 1)

        # Encontrar el valor mínimo no nulo desde el índice cont + x hasta el índice cont + z
        for i in indices:
            index = (cont + i)
            if 0 <= index < len(tabla):
                if not math.isnan(tabla[index]):
                    min_value = min(min_value, tabla[index])

        # Si no se encuentra ningún valor no nulo, devolver None
        if min_value == float('inf'):
            return None

        return min_value


def max_function(var, z, x, tabla=None, cont=None):  # ----FUNCIÓN MAX()----

    if tabla is None or cont is None or x is None:
        return None

    max_value = float('-inf')  # -Infinito

    if z == x and not math.isnan(var):
        return var
    else:
        indices = range(z, x + 1)

        # Encontrar el valor máximo no nulo
        for i in indices:
            index = (cont + i)
            if 0 <= index < len(tabla):
                if not math.isnan(tabla[index]):
                    max_value = max(max_value, tabla[index])

        # Si no se encuentra ningún valor no nulo, devolver None
        if max_value == float('-inf'):
            return None

        return max_value


def sd_function(var, z, x, tabla=None, cont=None):  # ----FUNCIÓN SD()----

    if var is None or z is None or x is None:
        raise ValueError()

    valores = []

    if z == x and not np.isnan(var):
        valores.append(var)
    else:
        indices = range(z, x + 1)

        # Agregar valores a la lista
        for i in indices:
            index = (cont + i)
            if 0 <= index < len(tabla):
                if not np.isnan(tabla[index]):
                    valores.append(tabla[index])

    if valores:
        std_desviacion = np.std(valores)
        return std_desviacion
    else:
        return None


def selected_row(view):
    """
    Return the index of selected row in a `view` (:class:`QListView`)

    The view's selection mode must be a QAbstractItemView.SingleSelction
    """
    if view.selectionMode() in [QAbstractItemView.MultiSelection,
                                QAbstractItemView.ExtendedSelection]:
        raise ValueError("invalid 'selectionMode'")

    sel_model = view.selectionModel()
    indexes = sel_model.selectedRows()
    if indexes:
        assert len(indexes) == 1
        return indexes[0].row()
    else:
        return None


class FeatureEditor(QFrame):
    ExpressionTooltip = """
Use variable names as values in expression.
Categorical features are passed as strings
(note the change in behaviour from Orange 3.30).

""".lstrip()

    FUNCTIONS = {"abs": "", "float": "", "int": "", "pow": ""}

    TIME_FUNCTIONS = {"shift": "", "sum": "", "mean": "", "count": "", "min": "", "max": "", "sd": "", "shiftBatch": ""}

    featureChanged = Signal()
    featureEdited = Signal()

    modifiedChanged = Signal(bool)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        layout = QGridLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        self.nameedit = QLineEdit(
            placeholderText="Name...",
            sizePolicy=QSizePolicy(QSizePolicy.Minimum,
                                   QSizePolicy.Fixed)
        )

        self.metaattributecb = QCheckBox("Meta attribute")

        self.expressionedit = QLineEdit(
            placeholderText="Expression...",
            toolTip=self.ExpressionTooltip)

        self.attrs_model = itemmodels.VariableListModel(
            ["Select Feature"], parent=self)
        self.attributescb = ComboBoxSearch(
            minimumContentsLength=16,
            sizeAdjustPolicy=QComboBox.AdjustToMinimumContentsLengthWithIcon,
            sizePolicy=QSizePolicy(QSizePolicy.Minimum, QSizePolicy.Minimum)
        )
        self.attributescb.setModel(self.attrs_model)

        sorted_funcs = sorted(self.FUNCTIONS)
        self.funcs_model = itemmodels.PyListModelTooltip(
            chain(["Select Function"], sorted_funcs),
            chain([''], [self.FUNCTIONS[func].__doc__ for func in sorted_funcs])
        )
        self.funcs_model.setParent(self)

        self.functionscb = ComboBoxSearch(
            minimumContentsLength=16,
            sizeAdjustPolicy=QComboBox.AdjustToMinimumContentsLengthWithIcon,
            sizePolicy=QSizePolicy(QSizePolicy.Minimum, QSizePolicy.Minimum))
        self.functionscb.setModel(self.funcs_model)

        # ComboBox FUNCIONES TEMPORALES
        self.time_func_model = itemmodels.PyListModelTooltip(chain(["Select Time Function"], self.TIME_FUNCTIONS))
        self.time_func_model.setParent(self)
        self.timefunctioncb = ComboBoxSearch(
            minimumContentsLength=16,
            sizeAdjustPolicy=QComboBox.AdjustToMinimumContentsLengthWithIcon,
            sizePolicy=QSizePolicy(QSizePolicy.Minimum, QSizePolicy.Minimum))
        self.timefunctioncb.setModel(self.time_func_model)

        layout.addWidget(self.nameedit, 0, 0)
        layout.addWidget(self.metaattributecb, 1, 0)
        layout.addWidget(self.expressionedit, 0, 1, 1, 3)
        layout.addWidget(self.attributescb, 1, 1)
        layout.addWidget(self.functionscb, 1, 2)
        layout.addWidget(self.timefunctioncb, 1, 3)
        layout.addWidget(QWidget(), 2, 0)

        self.setLayout(layout)

        self.nameedit.editingFinished.connect(self._invalidate)
        self.metaattributecb.clicked.connect(self._invalidate)
        self.expressionedit.textChanged.connect(self._invalidate)
        self.attributescb.currentIndexChanged.connect(self.on_attrs_changed)
        self.functionscb.currentIndexChanged.connect(self.on_funcs_changed)
        self.timefunctioncb.currentIndexChanged.connect(self.on_time_funcs_changed)  # El comboBox ha cambiado.

        self._modified = False

    def setModified(self, modified):
        if not isinstance(modified, bool):
            raise TypeError

        if self._modified != modified:
            self._modified = modified
            self.modifiedChanged.emit(modified)

    def modified(self):
        return self._modified

    modified = Property(bool, modified, setModified,
                        notify=modifiedChanged)

    def setEditorData(self, data, domain):
        self.nameedit.setText(data.name)
        self.metaattributecb.setChecked(data.meta)
        self.expressionedit.setText(data.expression)
        self.setModified(False)
        self.featureChanged.emit()
        self.attrs_model[:] = ["Select Feature"]
        if domain is not None and not domain.empty():
            self.attrs_model[:] += chain(domain.attributes,
                                         domain.class_vars,
                                         domain.metas)

    def editorData(self):
        return FeatureDescriptor(name=self.nameedit.text(),
                                 expression=self.nameedit.text(),
                                 meta=self.metaattributecb.isChecked())

    def _invalidate(self):
        self.setModified(True)
        self.featureEdited.emit()
        self.featureChanged.emit()

    def on_attrs_changed(self):
        index = self.attributescb.currentIndex()
        if index > 0:
            attr = sanitized_name(self.attrs_model[index].name)
            self.insert_into_expression(attr)
            self.attributescb.setCurrentIndex(0)

    def on_funcs_changed(self):
        index = self.functionscb.currentIndex()
        if index > 0:
            func = self.funcs_model[index]
            if func in ["atan2", "fmod", "ldexp", "log",
                        "pow", "copysign", "hypot"]:
                self.insert_into_expression(func + "(,)")
                self.expressionedit.cursorBackward(False, 2)
            elif func in ["e", "pi"]:
                self.insert_into_expression(func)
            else:
                self.insert_into_expression(func + "()")
                self.expressionedit.cursorBackward(False)
            self.functionscb.setCurrentIndex(0)

    def on_time_funcs_changed(self):
        index = self.timefunctioncb.currentIndex()
        if index > 0:
            func = self.time_func_model[index]
            if func in ["shift", "shiftBatch"]:
                self.insert_into_expression(func + "(,)")
                self.expressionedit.cursorBackward(False, 2)
            else:
                self.insert_into_expression(func + "(,,)")
                self.expressionedit.cursorBackward(False, 3)
            self.timefunctioncb.setCurrentIndex(0)

    def insert_into_expression(self, what):
        cp = self.expressionedit.cursorPosition()
        ct = self.expressionedit.text()
        text = ct[:cp] + what + ct[cp:]
        self.expressionedit.setText(text)
        self.expressionedit.setFocus()


class ContinuousFeatureEditor(FeatureEditor):
    ExpressionTooltip = "A numeric expression\n\n" \
                        + FeatureEditor.ExpressionTooltip

    def editorData(self):
        return ContinuousDescriptor(
            name=self.nameedit.text(),
            expression=self.expressionedit.text(),
            meta=self.metaattributecb.isChecked(),
            number_of_decimals=None,
        )


class DateTimeFeatureEditor(FeatureEditor):
    ExpressionTooltip = FeatureEditor.ExpressionTooltip + \
                        "Result must be a string in ISO-8601 format " \
                        "(e.g. 2019-07-30T15:37:27 or a part thereof),\n" \
                        "or a number of seconds since Jan 1, 1970."

    def editorData(self):
        return DateTimeDescriptor(
            name=self.nameedit.text(),
            expression=self.expressionedit.text(),
            meta=self.metaattributecb.isChecked(),
        )


class DiscreteFeatureEditor(FeatureEditor):
    ExpressionTooltip = FeatureEditor.ExpressionTooltip + \
                        "Result must be a string, if values are not explicitly given\n" \
                        "or a zero-based integer indices into a list of values given below."

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        tooltip = \
            "If values are given, above expression must return zero-based " \
            "integer indices into that list."
        self.valuesedit = QLineEdit(placeholderText="A, B ...", toolTip=tooltip)
        self.valuesedit.textChanged.connect(self._invalidate)

        layout = self.layout()
        label = QLabel(self.tr("Values (optional)"))
        label.setToolTip(tooltip)
        layout.addWidget(label, 2, 0)
        layout.addWidget(self.valuesedit, 2, 1, 1, 2)

    def setEditorData(self, data, domain):
        self.valuesedit.setText(
            ", ".join(v.replace(",", r"\,") for v in data.values))

        super().setEditorData(data, domain)

    def editorData(self):
        values = self.valuesedit.text()
        values = re.split(r"(?<!\\),", values)
        values = tuple(filter(None, [v.replace(r"\,", ",").strip() for v in values]))
        return DiscreteDescriptor(
            name=self.nameedit.text(),
            meta=self.metaattributecb.isChecked(),
            values=values,
            ordered=False,
            expression=self.expressionedit.text()
        )


class StringFeatureEditor(FeatureEditor):
    ExpressionTooltip = "A string expression\n\n" \
                        + FeatureEditor.ExpressionTooltip

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.metaattributecb.setChecked(True)
        self.metaattributecb.setDisabled(True)

    def editorData(self):
        return StringDescriptor(
            name=self.nameedit.text(),
            meta=True,
            expression=self.expressionedit.text()
        )


_VarMap = {
    DiscreteDescriptor: vartype(Orange.data.DiscreteVariable("d")),
    ContinuousDescriptor: vartype(Orange.data.ContinuousVariable("c")),
    DateTimeDescriptor: vartype(Orange.data.TimeVariable("t")),
    StringDescriptor: vartype(Orange.data.StringVariable("s"))
}


@functools.lru_cache(20)
def variable_icon(dtype):
    vtype = _VarMap.get(dtype, dtype)
    return gui.attributeIconDict[vtype]


class FeatureItemDelegate(QStyledItemDelegate):
    @staticmethod
    def displayText(value, _):
        return value.name + " := " + value.expression


class DescriptorModel(itemmodels.PyListModel):
    def data(self, index, role=Qt.DisplayRole):
        if role == Qt.DecorationRole:
            value = self[index.row()]
            return variable_icon(type(value))
        else:
            return super().data(index, role)


def freevars(exp: ast.AST, env: List[str]):
    """
    Return names of all free variables in a parsed (expression) AST.

    Parameters
    ----------
    exp : ast.AST
        An expression ast (ast.parse(..., mode="single"))
    env : List[str]
        Environment

    Returns
    -------
    freevars : List[str]

    See also
    --------
    ast

    """
    # pylint: disable=too-many-return-statements,too-many-branches
    etype = type(exp)
    if etype in [ast.Expr, ast.Expression]:
        return freevars(exp.body, env)
    elif etype == ast.BoolOp:
        return sum((freevars(v, env) for v in exp.values), [])
    elif etype == ast.BinOp:
        return freevars(exp.left, env) + freevars(exp.right, env)
    elif etype == ast.UnaryOp:
        return freevars(exp.operand, env)
    elif etype == ast.Lambda:
        args = exp.args
        assert isinstance(args, ast.arguments)
        arg_names = [a.arg for a in chain(args.posonlyargs, args.args)]
        arg_names += [args.vararg.arg] if args.vararg else []
        arg_names += [a.arg for a in args.kwonlyargs] if args.kwonlyargs else []
        arg_names += [args.kwarg.arg] if args.kwarg else []
        vars_ = chain.from_iterable(
            freevars(e, env) for e in chain(args.defaults, args.kw_defaults)
        )
        return list(vars_) + freevars(exp.body, env + arg_names)
    elif etype == ast.IfExp:
        return (freevars(exp.test, env) + freevars(exp.body, env) +
                freevars(exp.orelse, env))
    elif etype == ast.Dict:
        return sum((freevars(v, env)
                    for v in chain(exp.keys, exp.values)), [])
    elif etype == ast.Set:
        return sum((freevars(v, env) for v in exp.elts), [])
    elif etype in [ast.SetComp, ast.ListComp, ast.GeneratorExp, ast.DictComp]:
        env_ext = []
        vars_ = []
        for gen in exp.generators:
            target_names = freevars(gen.target, [])  # assigned names
            vars_iter = freevars(gen.iter, env + env_ext)
            env_ext += target_names
            vars_ifs = list(chain(*(freevars(ifexp, env + target_names)
                                    for ifexp in gen.ifs or [])))
            vars_ += vars_iter + vars_ifs

        if etype == ast.DictComp:
            vars_ = (freevars(exp.key, env_ext) +
                     freevars(exp.value, env_ext) +
                     vars_)
        else:
            vars_ = freevars(exp.elt, env + env_ext) + vars_
        return vars_
    # Yield, YieldFrom???
    elif etype == ast.Compare:
        return sum((freevars(v, env)
                    for v in [exp.left] + exp.comparators), [])
    elif etype == ast.Call:
        return sum(map(lambda e: freevars(e, env),
                       chain([exp.func],
                             exp.args or [],
                             [k.value for k in exp.keywords or []])),
                   [])
    elif etype == ast.Starred:
        # a 'starred' call parameter (e.g. a and b in `f(x, *a, *b)`
        return freevars(exp.value, env)
    elif etype in [ast.Num, ast.Str, ast.Ellipsis, ast.Bytes, ast.NameConstant]:
        return []
    elif etype == ast.Constant:
        return []
    elif etype == ast.Attribute:
        return freevars(exp.value, env)
    elif etype == ast.Subscript:
        return freevars(exp.value, env) + freevars(exp.slice, env)
    elif etype == ast.Name:
        return [exp.id] if exp.id not in env else []
    elif etype == ast.List:
        return sum((freevars(e, env) for e in exp.elts), [])
    elif etype == ast.Tuple:
        return sum((freevars(e, env) for e in exp.elts), [])
    elif etype == ast.Slice:
        return sum((freevars(e, env)
                    for e in filter(None, [exp.lower, exp.upper, exp.step])),
                   [])
    elif etype == ast.ExtSlice:
        return sum((freevars(e, env) for e in exp.dims), [])
    elif etype == ast.Index:
        return freevars(exp.value, env)
    elif etype == ast.keyword:
        return freevars(exp.value, env)
    else:
        raise ValueError(exp)


class FeatureConstructorHandler(DomainContextHandler):
    """Context handler that filters descriptors"""

    def is_valid_item(self, setting, item, attrs, metas):
        """Check if descriptor `item` can be used with given domain.

        Return True if descriptor's expression contains only
        available variables and descriptors name does not clash with
        existing variables.
        """
        if item.name in attrs or item.name in metas:
            return False

        try:
            exp_ast = ast.parse(item.expression, mode="eval")
        # ast.parse can return arbitrary errors, not only SyntaxError
        # pylint: disable=broad-except
        except Exception:
            return False

        available = dict(globals()["__GLOBALS"])
        for var in attrs:
            available[sanitized_name(var)] = None
        for var in metas:
            available[sanitized_name(var)] = None

        if freevars(exp_ast, list(available)):
            return False
        return True


class owtimefeaturesconstructor(OWWidget, ConcurrentWidgetMixin):
    name = "Time Features Constructor"
    description = "Construct new time features (data columns) from a set of " \
                  "existing features in the input dataset."
    icon = "icons/timefeature.svg"
    keywords = "time features constructor, function, time, constructor, features"
    priority = 2239

    class Inputs:
        data = Input("Data", Orange.data.Table)
        expressions = Input("Variable Definitions", Orange.data.Table)

    class Outputs:
        data = Output("Data", Orange.data.Table)
        expressions = Output("Variable Definitions", Orange.data.Table)

    want_main_area = False

    settingsHandler = FeatureConstructorHandler()
    descriptors = Setting([], schema_only=True)
    currentIndex = Setting(-1)
    expressions_with_values = Setting(False)
    settings_version = 3

    EDITORS = [
        (ContinuousDescriptor, ContinuousFeatureEditor),
        (DateTimeDescriptor, DateTimeFeatureEditor),
        (DiscreteDescriptor, DiscreteFeatureEditor),
        (StringDescriptor, StringFeatureEditor)
    ]

    _x_re  = re.compile(r"^X(\d+)(?:_|$)")   # para extraer n
    _max_x_used = 0                    # mayor n visto en todo momento

    class Error(OWWidget.Error):
        more_values_needed = Msg("Categorical feature {} needs more values.")
        invalid_expressions = Msg("Invalid expressions: {}.")
        transform_error = Msg("{}")

    class Warning(OWWidget.Warning):
        table_warning = Msg("You need a configuration table (Variable-Expression).")


    def _update_max_x_seen(self, *iterables):
        """
        Escanea los names de los descriptores/variables recibidos y actualiza
        `self._max_x_used` si encuentra un X<n> con n mayor.
        """
        for it in iterables:
            for obj in it:
                m = self._x_re.match(obj.name if hasattr(obj, "name") else str(obj))
                if m:
                    n = int(m.group(1))
                    if n > self._max_x_used:
                        self._max_x_used = n



    def __init__(self):
        super().__init__()
        ConcurrentWidgetMixin.__init__(self)
        self._max_x_used = 0      
        # ------------------------------------------------------------------
        # Atributos de instancia
        # ------------------------------------------------------------------
        self.data = None
        self.expressions = None
        self.dataOriginal = None
        self.editors = {}

        # ------------------------------------------------------------------
        # Marco principal (Variable Definitions)
        # ------------------------------------------------------------------
        box = gui.vBox(self.controlArea, "Variable Definitions")

        toplayout = QHBoxLayout();  toplayout.setContentsMargins(0, 0, 0, 0)
        box.layout().addLayout(toplayout)

        # ---------- pila de editores -------------------------------------
        self.editorstack = QStackedWidget(
            sizePolicy=QSizePolicy(QSizePolicy.MinimumExpanding,
                                QSizePolicy.MinimumExpanding)
        )
        for descclass, editorclass in self.EDITORS:
            editor = editorclass()
            editor.featureChanged.connect(self._on_modified)
            self.editors[descclass] = editor
            self.editorstack.addWidget(editor)
        self.editorstack.setEnabled(False)

        # ------------------------------------------------------------------
        # Columna de botones (New / Remove / Reset)
        # ------------------------------------------------------------------
        buttonlayout = QVBoxLayout(spacing=10); buttonlayout.setContentsMargins(0, 0, 0, 0)

        # ---------- 1) Botón “New” con nombre Xn consecutivo --------------
        self.addbutton = QPushButton(
            "New", toolTip="Create a new variable",
            minimumWidth=120, shortcut=QKeySequence.New
        )

        def next_Xn() -> str:
            self._max_x_used += 1
            return f"X{self._max_x_used}"

        menu = QMenu(self.addbutton)

        act_numeric = menu.addAction("Numeric")
        act_numeric.triggered.connect(
            lambda: self.addFeature(
                ContinuousDescriptor(next_Xn(), "", 3, meta=False)
            )
        )

        menu.addSeparator()
        self.duplicateaction = menu.addAction("Duplicate Selected Variable")
        self.duplicateaction.triggered.connect(self.duplicateFeature)
        self.duplicateaction.setEnabled(False)

        self.addbutton.setMenu(menu)
        # ------------------------------------------------------------------

        # ---------- 2) Botón “Remove” -------------------------------------
        self.removebutton = QPushButton(
            "Remove", toolTip="Remove selected variable",
            minimumWidth=120, shortcut=QKeySequence.Delete
        )
        self.removebutton.clicked.connect(self.removeSelectedFeature)

        # ---------- 3) Botón “Reset” --------------------------------------
        self.resetbutton = QPushButton(
            "Reset", toolTip="Reset node", minimumWidth=120
        )
        self.resetbutton.clicked.connect(self.reset_domain)

        # ---------- empaquetado de botones --------------------------------
        buttonlayout.addWidget(self.addbutton)
        buttonlayout.addWidget(self.removebutton)
        buttonlayout.addWidget(self.resetbutton)
        buttonlayout.addStretch(10)

        toplayout.addLayout(buttonlayout, 0)
        toplayout.addWidget(self.editorstack, 10)

        layoutA = QGridLayout()  
        layoutA.setSpacing(2)
        gui.widgetBox(self.controlArea, orientation=layoutA,
                    box='Variables generated')

        self.featureModelTime = DescriptorModel(parent=self)
        self.featureviewTime = QListView(
            minimumWidth=200, minimumHeight=50,
            sizePolicy=QSizePolicy(QSizePolicy.Minimum,
                                QSizePolicy.MinimumExpanding)
        )
        self.featureviewTime.setItemDelegate(FeatureItemDelegate(self))
        self.featureviewTime.setModel(self.featureModelTime)
        self.featureviewTime.selectionModel().selectionChanged.connect(
            self._on_selectedVariableChanged
        )
        layoutA.addWidget(self.featureviewTime)

        layoutB = QGridLayout()  
        layoutB.setSpacing(2)
        gui.widgetBox(self.controlArea, orientation=layoutB,
                    box='Variables to generate')

        self.featuremodel = DescriptorModel(parent=self)
        self.featureview = QListView(
            minimumWidth=200, minimumHeight=50,
            sizePolicy=QSizePolicy(QSizePolicy.Minimum,
                                QSizePolicy.MinimumExpanding)
        )
        self.featureview.setItemDelegate(FeatureItemDelegate(self))
        self.featureview.setModel(self.featuremodel)
        self.featureview.selectionModel().selectionChanged.connect(
            self._on_selectedVariableChanged
        )
        layoutB.addWidget(self.featureview)

        box.layout().addLayout(layoutA, 1)
        box.layout().addLayout(layoutB, 1)


        self.fix_button = gui.button(
            self.buttonsArea, self, "Upgrade Expressions",
            callback=self.fix_expressions
        )
        self.fix_button.setHidden(True)

        gui.button(self.buttonsArea, self,
                "Send", callback=self.apply, default=True)

    def setCurrentIndex(self, index):
        index = min(index, len(self.featuremodel) - 1)
        self.currentIndex = index
        if index >= 0:
            itemmodels.select_row(self.featureview, index)
            desc = self.featuremodel[min(index, len(self.featuremodel) - 1)]
            editor = self.editors[type(desc)]
            self.editorstack.setCurrentWidget(editor)
            editor.setEditorData(desc, self.data.domain if self.data else None)
        self.editorstack.setEnabled(index >= 0)
        self.duplicateaction.setEnabled(index >= 0)
        self.removebutton.setEnabled(index >= 0)

    def reset_domain(self, *, with_apply=False):

        self.expressions_with_values = False

        # Restablecer los datos a los datos originales solo si existen
        if self.dataOriginal is not None:
            # Restablecer los datos a los datos originales
            self.data = self.dataOriginal.copy()

            # Restablecer la estructura de los datos para eliminar columnas adicionales
            self.data.domain = self.dataOriginal.domain

        self.descriptors = []
        self.currentIndex = -1

        # disconnect from the selection model while reseting the model
        selmodel = self.featureview.selectionModel()
        selmodel.selectionChanged.disconnect(self._on_selectedVariableChanged)

        # Listas de variables a cero.
        self.featuremodel[:] = [d for d in self.descriptors if not d.meta]  
        self.featureModelTime[:] = [d for d in self.descriptors if d.meta] 
        self.setCurrentIndex(self.currentIndex)

        selmodel.selectionChanged.connect(self._on_selectedVariableChanged)
        self.fix_button.setHidden(not self.expressions_with_values)
        self.editorstack.setEnabled(self.currentIndex >= 0)

        if with_apply:
            self.apply()

    def _on_selectedVariableChanged(self, selected, *_):
        index = selected_row(self.featureview)
        if index is not None:
            self.setCurrentIndex(index)
        else:
            self.setCurrentIndex(-1)

    def _on_selectedVariableChangedTime(self, selected, *_):
        index = selected_row(self.featureModelTime)
        if index is not None:
            self.setCurrentIndex(index)
        else:
            self.setCurrentIndex(-1)

    def _on_modified(self):
        if self.currentIndex >= 0:
            self.Warning.clear()
            editor = self.editorstack.currentWidget()
            proposed = editor.editorData().name
            uniq = get_unique_names(self.reserved_names(self.currentIndex),
                                    proposed)

            feature = editor.editorData()
            if editor.editorData().name != uniq:
                self.Error.transform_error("Avoid duplicates.\n")

            self.featuremodel[self.currentIndex] = feature
            self.descriptors = list(self.featuremodel)

    def setDescriptors(self, descriptors):
        """
        Set a list of variable descriptors to edit.
        """
        self.descriptors = descriptors
        self.featuremodel[:] = list(self.descriptors)

    def reserved_names(self, idx_=None):
        varnames = []
        if self.data is not None:
            varnames = [var.name for var in
                        self.data.domain.variables + self.data.domain.metas]
        varnames += [desc.name for idx, desc in enumerate(self.featuremodel)
                     if idx != idx_]
        return set(varnames)

    # ---------------------------------------------------------------------
    #  TimeFeatures - versión que conserva las descripciones al recargar
    # ---------------------------------------------------------------------
    @Inputs.data
    @check_sql_input
    def setData(self, data=None):
        self.data = data
        if data is None:
            return

        # -------------------------------
        # Si cambia el dominio, reinicia
        if (self.dataOriginal is not None
                and data.domain != self.dataOriginal.domain):
            self.dataOriginal = data.copy()
            self.reset_domain()               # ← aquí SÍ se vacían descriptors
        elif self.dataOriginal is None:       # primera vez
            self.dataOriginal = data.copy()
        # -------------------------------

        # Actualiza vistas con lo que haya en descriptors
        self.featuremodel[:] = [d for d in self.descriptors if not d.meta] 
        self.featureModelTime[:] = [d for d in self.descriptors if d.meta] 
        self.setCurrentIndex(-1)

        # Si hay descriptores (caso .ows restaurado) aplica transformaciones
        if self.descriptors:
            self.apply()

        self._update_max_x_seen(self.featuremodel, self.featureModelTime)







    @Inputs.expressions
    @check_sql_input
    def setExpressions(self, expressions=None):
        self.expressions = expressions

        if self.expressions is None:
            self.Warning.clear()
            self.Error.transform_error.clear()

        if self.data is not None and self.expressions is not None:
            if len(self.expressions.domain) >= 1 and (
                self.expressions.domain[0].name != "Variable"
                or self.expressions.domain[1].name != "Expression"
            ):
                self.Warning.table_warning()
            else:
                self.Error.transform_error.clear()
                for datos in reversed(self.expressions):
                    if not math.isnan(datos[1]) and str(datos[1]) != "NaN":
                        desc = ContinuousDescriptor(
                            name=str(datos[0]),
                            expression=str(datos[1]),
                            meta=False,
                            number_of_decimals=3,
                        )
                        if "shiftBatch" in desc.expression:
                            for sub_desc in expand_shiftbatch(desc.expression, desc.name):
                                self.addFeature(sub_desc)
                            continue  # ⛔️ no añadas el descriptor shiftBatch original
                        self.addFeature(desc)

        else:
            self.Error.transform_error("There is not data input.")


    def handleNewSignals(self):
        if self.data is not None:
            self.apply()
        else:
            self.cancel()
            self.Outputs.data.send(None)
            self.fix_button.setHidden(True)

    def onDeleteWidget(self):
        self.shutdown()
        super().onDeleteWidget()

    def addFeature(self, descriptor):
        self.featuremodel.append(descriptor)
        self.setCurrentIndex(len(self.featuremodel) - 1)
        editor = self.editorstack.currentWidget()
        editor.nameedit.setFocus()
        editor.nameedit.selectAll()
        self._update_max_x_seen([descriptor])

    def addFeatureTime(self, descriptor):
        self.featureModelTime.append(descriptor)

    def removeFeature(self, index):
        del self.featuremodel[index]
        index = selected_row(self.featureview)
        if index is not None:
            self.setCurrentIndex(index)
        elif index is None and self.featuremodel.rowCount():
            # Deleting the last item clears selection
            self.setCurrentIndex(self.featuremodel.rowCount() - 1)

    def removeSelectedFeature(self):
        if self.currentIndex >= 0:
            self.removeFeature(self.currentIndex)

    def duplicateFeature(self):
        desc = self.featuremodel[self.currentIndex]
        self.addFeature(copy.deepcopy(desc))

    @staticmethod
    def check_attrs_values(attr, data):
        for var in attr:
            col = data.get_column(var)
            mask = ~np.isnan(col)
            grater_or_equal = np.greater_equal(
                col, len(var.values), out=mask, where=mask
            )
            if grater_or_equal.any():
                return var.name
        return None

    def _validate_descriptors(self, desc):

        def validate(source):
            try:
                return validate_exp(ast.parse(source, mode="eval"))
            # ast.parse can return arbitrary errors, not only SyntaxError
            # pylint: disable=broad-except
            except Exception:
                return False

        final = []
        invalid = []
        for d in desc:
            if validate(d.expression):
                final.append(d)
            else:
                final.append(d._replace(expression=""))
                invalid.append(d)

        if invalid:
            self.Error.invalid_expressions(", ".join(s.name for s in invalid))

        return final

    # ----------------------------------------------------------------------
    # 1) owtimefeaturesconstructor.apply  (versión mejorada)
    # ----------------------------------------------------------------------
    def apply(self):
        """
        Expande shiftBatch, evita duplicados en el dominio y mantiene
        la lista de descriptores completa para el grafo.
        """
        self.cancel()
        self.Error.clear()
        if self.data is None:
            return

        # 1) Descriptores pendientes + ya generados (necesarios para el grafo)
        candidate = list(self.featuremodel) + list(self.featureModelTime)

        # 2) Expandir shiftBatch(...)
        expanded = []
        for d in candidate:
            expanded.extend(
                expand_shiftbatch(d.expression, d.name)
                if "shiftBatch(" in d.expression else [d]
            )
        expanded = self._validate_descriptors(expanded)

        # 3) Evitar nombres ya presentes en el dominio
        used = {v.name for v in self.data.domain.variables +
                            self.data.domain.metas}
        to_generate, keep_for_graph = [], []
        for d in expanded:
            if d.name not in used:
                to_generate.append(d)      # se generará
                used.add(d.name)
            keep_for_graph.append(d)       # SIEMPRE va al grafo

        # 4) Actualizar la lista maestra de descriptores (sin perder los antiguos)
        self.descriptors.extend(
            [d for d in keep_for_graph if d.name not in {x.name for x in self.descriptors}]
        )

        # 5) Limpiar “Variables to generate” (ya no hace falta mostrar nada)
        self.featuremodel.clear()
        self.setCurrentIndex(-1)

        # 6) Reset de estado global y reconstrucción de Variable-Expression
        FeatureFunc._GLOBAL_STATE.clear()
        self.createConfigTable()          # ahora incluye TODO (viejo+nuevo)

        # 7) Si no hay nada pendiente, no lances la tarea
        if not to_generate:
            return

        self.start(
            run,
            self.data,
            to_generate,                   #  ◀︎ sólo las nuevas columnas
            self.expressions_with_values
        )




    def on_done(self, result: "Result") -> None:
        # 0) Desempaquetar
        data, new_attrs, _ = result.data, result.attributes, result.desc

        # 1) Comprobación de categorías fuera de rango
        disc = self.check_attrs_values([v for v in new_attrs if v.is_discrete], data)
        if disc:
            self.Error.more_values_needed(disc)
            return

        # 2) Guardar la tabla transformada y la copia original
        self.data = data
        if self.dataOriginal is None:
            self.dataOriginal = data.copy()

        # 3) Añadir las nuevas columnas a “Variables generated”
        generated_names = {d.name for d in self.featureModelTime}
        for v in new_attrs:
            if v.name not in generated_names:
                self.featureModelTime.append(
                    ContinuousDescriptor(v.name, v.compute_value.expression, 3, True)
                )
                generated_names.add(v.name)

        # 4) Asegurarse de que **también** quedan guardadas en self.descriptors
        desc_names = {d.name for d in self.descriptors}
        for v in new_attrs:
            if v.name not in desc_names:
                self.descriptors.append(
                    ContinuousDescriptor(v.name, v.compute_value.expression, 3, True)
                )
                desc_names.add(v.name)

        # 5) Limpiar “Variables to generate”: quita las que ya se han creado
        created = {v.name for v in new_attrs}
        self.featuremodel[:] = [
            d for d in self.featuremodel
            if d.name not in created and "shiftBatch" not in d.expression
        ]

        # 6) Sincronizar el contador X<n> automático por si acaso
        self._update_max_x_seen(new_attrs)

        # 7) Reconstruir la tabla Variable-Expression y enviar salidas
        self.createConfigTable()
        self.Outputs.data.send(data)





    # ----------------------------------------------------------------------
    # 2) owtimefeaturesconstructor.createConfigTable
    # ----------------------------------------------------------------------
    def createConfigTable(self):
        """
        Variable-Expression table sent on the ‘Variable Definitions’ output.
        – ‘Variable’   ⋙ Discrete attribute   (unique list of names)
        – ‘Expression’ ⋙ String     meta      (can repeat / be NaN)
        """
        import numpy as np
        from Orange.data import Domain, Table, StringVariable, DiscreteVariable

        # 1. recopilar la mejor expresión para cada variable
        best = {}
        for d in reversed(self.descriptors):           # los últimos pisan a los viejos
            txt = d.expression.strip()
            if d.name not in best and txt and txt.lower() != "nan":
                best[d.name] = txt

        # 2. añadir las columnas originales sin expresión
        if self.dataOriginal is not None:
            for v in self.dataOriginal.domain.attributes:
                best.setdefault(v.name, np.nan)

        # 3. columnas
        names = list(best)                                            # únicos, orden de aparición
        var_attr  = DiscreteVariable("Variable", values=names)        # atributo categórico
        expr_meta = StringVariable("Expression")                      # meta texto

        domain = Domain([var_attr], metas=[expr_meta])

        # 4. filas:  [Variable,  Expression]
        rows = [[name, expr] for name, expr in best.items()]
        config = Table.from_list(domain, rows)

        # 5. enviar al canal
        self.Outputs.expressions.send(config)

    def on_exception(self, ex: Exception):
        log = logging.getLogger(__name__)
        log.error("", exc_info=ex)
        self.Error.transform_error(
            "".join(format_exception_only(type(ex), ex)).rstrip(),
            exc_info=ex
        )

    def on_partial_result(self, _):
        pass

    def send_report(self):
        items = OrderedDict()
        for feature in self.featuremodel:
            if isinstance(feature, DiscreteDescriptor):
                desc = "categorical"
                if feature.values:
                    desc += " with values " \
                            + ", ".join(f"'{val}'" for val in feature.values)
                if feature.ordered:
                    desc += "; ordered"
            elif isinstance(feature, ContinuousDescriptor):
                desc = "numeric"
            elif isinstance(feature, DateTimeDescriptor):
                desc = "date/time"
            else:
                desc = "text"
            items[feature.name] = f"{feature.expression} ({desc})"
        self.report_items(
            report.plural("Constructed feature{s}", len(items)), items)

    def fix_expressions(self):
        dlg = QMessageBox(
            QMessageBox.Question,
            "Fix Expressions",
            "This widget's behaviour has changed. Values of categorical "
            "variables are now inserted as their textual representations "
            "(strings); previously they appeared as integer numbers, with an "
            "attribute '.value' that contained the text.\n\n"
            "The widget currently runs in compatibility mode. After "
            "expressions are updated, manually check for their correctness.")
        dlg.addButton("Update", QMessageBox.ApplyRole)
        dlg.addButton("Cancel", QMessageBox.RejectRole)
        if dlg.exec() == QMessageBox.RejectRole:
            return

        def fixer(mo):
            var = domain[mo.group(2)]
            if mo.group(3) == ".value":  # uses string; remove `.value`
                return "".join(mo.group(1, 2, 4))
            # Uses ints: get them by indexing
            return mo.group(1) + "{" + \
                   ", ".join(f"'{val}': {i}"
                             for i, val in enumerate(var.values)) + \
                   f"}}[{var.name}]" + mo.group(4)

        domain = self.data.domain
        disc_vars = "|".join(f"{var.name}"
                             for var in chain(domain.variables, domain.metas)
                             if var.is_discrete)
        expr = re.compile(r"(^|\W)(" + disc_vars + r")(\.value)?(\W|$)")
        self.descriptors[:] = [
            descriptor._replace(
                expression=expr.sub(fixer, descriptor.expression))
            for descriptor in self.descriptors]

        self.expressions_with_values = False
        self.fix_button.hide()
        index = self.currentIndex
        self.featuremodel[:] = list(self.descriptors)
        self.setCurrentIndex(index)
        self.apply()

    @classmethod
    def migrate_context(cls, context, version):
        if version is None or version < 2:
            used_vars = set(chain(*(
                freevars(ast.parse(descriptor.expression, mode="eval"), [])
                for descriptor in context.values["descriptors"]
                if descriptor.expression)))
            disc_vars = {name
                         for (name, vtype) in chain(context.attributes.items(),
                                                    context.metas.items())
                         if vtype == 1}
            if used_vars & disc_vars:
                context.values["expressions_with_values"] = True


@dataclass
class Result:
    data: Table
    attributes: List[Variable]
    metas: List[Variable]
    desc: StringDescriptor


def run(data: Table, desc, use_values, task: TaskState) -> Result:
    if task.is_interruption_requested():
        raise CancelledError  # pragma: no cover

    new_variables, new_metas = construct_variables(desc, data, use_values)
    # Explicit cancellation point after `construct_variables` which can
    # already run `compute_value`.
    if task.is_interruption_requested():
        raise CancelledError  # pragma: no cover
    new_domain = Orange.data.Domain(
        data.domain.attributes + new_variables,
        data.domain.class_vars,
        metas=data.domain.metas + new_metas
    )
    try:
        for variable in new_variables:
            variable.compute_value.mask_exceptions = False
        try:
            data = data.transform(new_domain)
        except:
            raise ValueError("Expression error.")
    finally:
        for variable in new_variables:
            variable.compute_value.mask_exceptions = True

    return Result(data, new_variables, new_metas, desc)


def validate_exp(exp):
    """
    Validate an `ast.AST` expression.

    Parameters
    ----------
    exp : ast.AST
        A parsed abstract syntax tree
    """
    # pylint: disable=too-many-branches,too-many-return-statements
    if not isinstance(exp, ast.AST):
        raise TypeError("exp is not a 'ast.AST' instance")

    etype = type(exp)
    if etype in [ast.Expr, ast.Expression]:
        return validate_exp(exp.body)
    elif etype == ast.BoolOp:
        return all(map(validate_exp, exp.values))
    elif etype == ast.BinOp:
        return all(map(validate_exp, [exp.left, exp.right]))
    elif etype == ast.UnaryOp:
        return validate_exp(exp.operand)
    elif etype == ast.Lambda:
        return all(validate_exp(e) for e in exp.args.defaults) and \
               all(validate_exp(e) for e in exp.args.kw_defaults) and \
               validate_exp(exp.body)
    elif etype == ast.IfExp:
        return all(map(validate_exp, [exp.test, exp.body, exp.orelse]))
    elif etype == ast.Dict:
        return all(map(validate_exp, chain(exp.keys, exp.values)))
    elif etype == ast.Set:
        return all(map(validate_exp, exp.elts))
    elif etype in (ast.SetComp, ast.ListComp, ast.GeneratorExp):
        return validate_exp(exp.elt) and all(map(validate_exp, exp.generators))
    elif etype == ast.DictComp:
        return validate_exp(exp.key) and validate_exp(exp.value) and \
               all(map(validate_exp, exp.generators))
    elif etype == ast.Compare:
        return all(map(validate_exp, [exp.left] + exp.comparators))
    elif etype == ast.Call:
        subexp = chain([exp.func], exp.args or [],
                       [k.value for k in exp.keywords or []])
        return all(map(validate_exp, subexp))
    elif etype == ast.Starred:
        return validate_exp(exp.value)
    elif etype in [ast.Num, ast.Str, ast.Bytes, ast.Ellipsis, ast.NameConstant]:
        return True
    elif etype == ast.Constant:
        return True
    elif etype == ast.Attribute:
        return True
    elif etype == ast.Subscript:
        return all(map(validate_exp, [exp.value, exp.slice]))
    elif etype in {ast.List, ast.Tuple}:
        return all(map(validate_exp, exp.elts))
    elif etype == ast.Name:
        return True
    elif etype == ast.Slice:
        return all(map(validate_exp,
                       filter(None, [exp.lower, exp.upper, exp.step])))
    elif etype == ast.ExtSlice:
        return all(map(validate_exp, exp.dims))
    elif etype == ast.Index:
        return validate_exp(exp.value)
    elif etype == ast.keyword:
        return validate_exp(exp.value)
    elif etype == ast.comprehension and not exp.is_async:
        return validate_exp(exp.target) and validate_exp(exp.iter) and \
               all(map(validate_exp, exp.ifs))
    else:
        raise ValueError(exp)


def construct_variables(descriptions, data, use_values=False):
    # subs

    variables = []
    metas = []
    source_vars = data.domain.variables + data.domain.metas
    for desc in descriptions:
        desc, func = bind_variable(desc, source_vars, data, use_values)
        var = make_variable(desc, func)
        [variables, metas][desc.meta].append(var)
    return tuple(variables), tuple(metas)


def sanitized_name(name):
    sanitized = re.sub(r"\W", "_", name)
    if sanitized[0].isdigit():
        sanitized = "_" + sanitized
    return sanitized


def bind_variable(descriptor, env, data, use_values):
    """
    (descriptor, env) ->
        (descriptor, (instance -> value) | (table -> value list))
    """
    if not descriptor.expression.strip():
        return descriptor, FeatureFunc("nan", [], {"nan": float("nan")})

    exp_ast = ast.parse(descriptor.expression, mode="eval")
    freev = unique(freevars(exp_ast, []))
    variables = {unicodedata.normalize("NFKC", sanitized_name(v.name)): v
                 for v in env}
    source_vars = [(name, variables[name]) for name in freev
                   if name in variables]

    values = {}
    cast = None
    dtype = object if isinstance(descriptor, StringDescriptor) else float

    if isinstance(descriptor, DiscreteDescriptor):
        if not descriptor.values:
            str_func = FeatureFunc(descriptor.expression, source_vars,
                                   use_values=use_values)
            values = sorted({str(x) for x in str_func(data)})
            values = {name: i for i, name in enumerate(values)}
            descriptor = descriptor._replace(values=values)
            cast = MappingTransformCast(values)
        else:
            values = [sanitized_name(v) for v in descriptor.values]
            values = {name: i for i, name in enumerate(values)}

    if isinstance(descriptor, DateTimeDescriptor):
        cast = DateTimeCast()

    func = FeatureFunc(descriptor.expression, source_vars, values, cast,
                       use_values=use_values, dtype=dtype)
    return descriptor, func


_parse_datetime = Orange.data.TimeVariable("_").parse
_cast_datetime_num_types = (int, float)


def cast_datetime(e):
    if isinstance(e, _cast_datetime_num_types):
        return e
    if e == "" or e is None:
        return np.nan
    return _parse_datetime(e)


_cast_datetime = frompyfunc(cast_datetime, 1, 1, dtype=float)


class DateTimeCast:
    def __call__(self, values):
        return _cast_datetime(values)

    def __eq__(self, other):
        return isinstance(other, DateTimeCast)

    def __hash__(self):
        return hash(cast_datetime)


class MappingTransformCast:
    def __init__(self, mapping: Mapping):
        self.t = MappingTransform(None, mapping)

    def __reduce_ex__(self, protocol):
        return type(self), (self.t.mapping,)

    def __call__(self, values):
        return self.t.transform(values)

    def __eq__(self, other):
        return isinstance(other, MappingTransformCast) and self.t == other.t

    def __hash__(self):
        return hash(self.t)


__ALLOWED = [
    "Ellipsis", "False", "None", "True", "abs", "all", "any", "acsii",
    "bin", "bool", "bytearray", "bytes", "chr", "complex", "dict",
    "divmod", "enumerate", "filter", "float", "format", "frozenset",
    "getattr", "hasattr", "hash", "hex", "id", "int", "iter", "len",
    "list", "map", "max", "memoryview", "min", "next", "object",
    "oct", "ord", "pow", "range", "repr", "reversed", "round",
    "set", "slice", "sorted", "str", "sum", "tuple", "type",
    "zip"
]

__GLOBALS = {name: getattr(builtins, name) for name in __ALLOWED
             if hasattr(builtins, name)}

__GLOBALS.update({name: getattr(math, name) for name in dir(math)
                  if not name.startswith("_")})

__GLOBALS.update({
    "normalvariate": random.normalvariate,
    "gauss": random.gauss,
    "expovariate": random.expovariate,
    "gammavariate": random.gammavariate,
    "betavariate": random.betavariate,
    "lognormvariate": random.lognormvariate,
    "paretovariate": random.paretovariate,
    "vonmisesvariate": random.vonmisesvariate,
    "weibullvariate": random.weibullvariate,
    "triangular": random.triangular,
    "uniform": random.uniform,
    "nanmean": lambda *args: np.nanmean(args),
    "nanmin": lambda *args: np.nanmin(args),
    "nanmax": lambda *args: np.nanmax(args),
    "nansum": lambda *args: np.nansum(args),
    "nanstd": lambda *args: np.nanstd(args),
    "nanmedian": lambda *args: np.nanmedian(args),
    "nancumsum": lambda *args: np.nancumsum(args),
    "nancumprod": lambda *args: np.nancumprod(args),
    "nanargmax": lambda *args: np.nanargmax(args),
    "nanargmin": lambda *args: np.nanargmin(args),
    "nanvar": lambda *args: np.nanvar(args),
    "mean": lambda *args: np.mean(args),
    "std": lambda *args: np.std(args),
    "median": lambda *args: np.median(args),
    "cumsum": lambda *args: np.cumsum(args),
    "cumprod": lambda *args: np.cumprod(args),
    "argmax": lambda *args: np.argmax(args),
    "argmin": lambda *args: np.argmin(args),
    "var": lambda *args: np.var(args)})


class FeatureFunc:
    """
    Encapsula la evaluación de una expresión sobre una tabla o instancia.

    Modificación: se añade un almacén de estado de clase
    (`_GLOBAL_STATE`) para conservar el _buffer_ y el contador de filas
    procesadas entre los bloques de 5000 filas que Orange maneja
    internamente. De este modo, las funciones de ventana temporal
    (`shift`, `sum`, `mean`, …) mantienen el contexto completo.
    """
    _GLOBAL_STATE: Dict[Tuple[str, Tuple[str, ...]], Dict[str, Any]] = {}


    dtype: Optional["DType"] = None  # anotación informativa

    def __init__(
        self,
        expression: str,
        args: List[Tuple[str, Variable]],
        extra_env: Optional[Dict[str, Any]] = None,
        cast: Optional[callable] = None,
        use_values: bool = False,
        dtype: Optional["DType"] = None,
    ):
        self.expression = expression
        self.args = args
        self.extra_env = extra_env or {}
        self.cast = cast
        self.mask_exceptions = True
        self.use_values = use_values
        self.dtype = dtype

        # ---------- NUEVO: clave única de estado para esta expresión ----------
        self._state_key: Tuple[str, Tuple[str, ...]] = (
            self.expression,
            tuple(sorted(sanitized_name(v.name) for _, v in self.args)),
        )
        if self._state_key not in FeatureFunc._GLOBAL_STATE:
            FeatureFunc._GLOBAL_STATE[self._state_key] = {
                "buffer": {sanitized_name(v.name): [] for _, v in self.args},
                "processed": 0,
            }
        # ---------------------------------------------------------------------

    # -------------------------------------------------------------------------
    # API pública
    # -------------------------------------------------------------------------
    def __call__(self, table, *_):
        if isinstance(table, Table):
            return self._call_table(table)
        else:  # se asume instancia individual
            return self._call_instance(table)

    # -------------------------------------------------------------------------
    # Implementación para tablas completas (vectorizado)
    # -------------------------------------------------------------------------
    def _call_table(self, table: Table):
        # ---------- Recuperar estado persistente -----------------------------
        state = FeatureFunc._GLOBAL_STATE[self._state_key]
        self._buffer: Dict[str, List[Any]] = state["buffer"]
        self._processed: int = state["processed"]
        # ---------------------------------------------------------------------

        # 1. Acumular las nuevas filas en el buffer
        for _, var in self.args:
            column = self.extract_column(table, var)
            self._buffer[sanitized_name(var.name)].extend(column)

        end = len(next(iter(self._buffer.values())))
        results: List[Any] = []

        # 2. Evaluar la expresión fila a fila desde _processed hasta end
        expresion_regular = (
            r'shift\(([^,]+),[-\d]+\)|sum\(([^,]+),[-\d]+,[-\d]+\)|'
            r'mean\(([^,]+),[-\d]+,[-\d]+\)|count\(([^,]+),[-\d]+,[-\d]+\)|'
            r'min\(([^,]+),[-\d]+,[-\d]+\)|max\(([^,]+),[-\d]+,[-\d]+\)|'
            r'sd\(([^,]+),[-\d]+,[-\d]+\)'
        )
        has_time_func = bool(re.search(expresion_regular, self.expression))
        if has_time_func:
            from functools import partial

            # Construir listas con info de cada función temporal
            shift_info, sum_info, mean_info = [], [], []
            count_info, min_info, max_info, sd_info = [], [], [], []

            for m in re.finditer(expresion_regular, self.expression):
                # Cada grupo alterna según la función detectada
                groups = m.groups()
                if groups[0]:
                    shift_info.append({"tabla": self._buffer[groups[0]]})
                elif groups[1]:
                    sum_info.append({"tabla": self._buffer[groups[1]]})
                elif groups[2]:
                    mean_info.append({"tabla": self._buffer[groups[2]]})
                elif groups[3]:
                    count_info.append({"tabla": self._buffer[groups[3]]})
                elif groups[4]:
                    min_info.append({"tabla": self._buffer[groups[4]]})
                elif groups[5]:
                    max_info.append({"tabla": self._buffer[groups[5]]})
                elif groups[6]:
                    sd_info.append({"tabla": self._buffer[groups[6]]})

            # Generar expresión modificada (tu función existente)
            modified_expression = modificar_expression(self.expression)

        for idx in range(self._processed, end):
            # Variables de esta fila
            var_dict = {name: col[idx] for name, col in self._buffer.items()}

            # ---------- Evaluar expresión -------------------------------------
            if has_time_func:
                # Crear diccionario de funciones parciales por fila
                funciones_permitidas = {}

                # Helpers parciales para cada tipo de función
                funciones_permitidas.update(
                    {
                        f"shift{i}": partial(shift_function, tabla=info["tabla"], cont=idx)
                        for i, info in enumerate(shift_info)
                    }
                )
                funciones_permitidas.update(
                    {
                        f"sum{i}": partial(sum_function, tabla=info["tabla"], cont=idx)
                        for i, info in enumerate(sum_info)
                    }
                )
                funciones_permitidas.update(
                    {
                        f"mean{i}": partial(mean_function, tabla=info["tabla"], cont=idx)
                        for i, info in enumerate(mean_info)
                    }
                )
                funciones_permitidas.update(
                    {
                        f"count{i}": partial(count_function, tabla=info["tabla"], cont=idx)
                        for i, info in enumerate(count_info)
                    }
                )
                funciones_permitidas.update(
                    {
                        f"min{i}": partial(min_function, tabla=info["tabla"], cont=idx)
                        for i, info in enumerate(min_info)
                    }
                )
                funciones_permitidas.update(
                    {
                        f"max{i}": partial(max_function, tabla=info["tabla"], cont=idx)
                        for i, info in enumerate(max_info)
                    }
                )
                funciones_permitidas.update(
                    {
                        f"sd{i}": partial(sd_function, tabla=info["tabla"], cont=idx)
                        for i, info in enumerate(sd_info)
                    }
                )

                try:
                    res = eval(modified_expression, var_dict, funciones_permitidas)
                except Exception:
                    res = None  # En errores se devuelve NaN/None
            else:
                try:
                    res = eval(self.expression, var_dict)
                except Exception:
                    res = None
            # -----------------------------------------------------------------

            results.append(res)

        # 3. Actualizar posición procesada y guardar estado
        self._processed = end
        state["processed"] = end
        return results

    # -------------------------------------------------------------------------
    # Implementación para una única instancia
    # -------------------------------------------------------------------------
    def _call_instance(self, instance):
        table = Table.from_numpy(
            instance.domain,
            np.array([instance.x]),
            np.array([instance.y]),
            np.array([instance.metas]),
        )
        return self._call_table(table)[0]

    # -------------------------------------------------------------------------
    # Utilidades auxiliares sin cambios relevantes
    # -------------------------------------------------------------------------
    def extract_column(self, table: Table, var: Variable):
        data = table.get_column(var)
        if var.is_string:
            return data
        elif var.is_discrete and not self.use_values:
            values = np.array([*var.values, None], dtype=object)
            idx = data.astype(int)
            idx[~np.isfinite(data)] = len(values) - 1
            return values[idx].tolist()
        elif var.is_time:
            return Value._as_values(var, data.tolist())  # pylint: disable=protected-access
        elif not self.use_values:
            return data.tolist()
        else:
            return Value._as_values(var, data.tolist())  # pylint: disable=protected-access

    def __reduce__(self):
        return type(self), (self.expression, self.args,
                            self.extra_env, self.cast, self.use_values,
                            self.dtype)

    def __repr__(self):
        return "{0.__name__}{1!r}".format(*self.__reduce__())

    def __hash__(self):
        return hash((self.expression, tuple(self.args),
                     tuple(sorted(self.extra_env.items())), self.cast))

    def __eq__(self, other):
        return type(self) is type(other) \
               and self.expression == other.expression and self.args == other.args \
               and self.extra_env == other.extra_env and self.cast == other.cast


if __name__ == "__main__":  # pragma: no cover
    WidgetPreview(owtimefeaturesconstructor).run(Orange.data.Table("iris"))