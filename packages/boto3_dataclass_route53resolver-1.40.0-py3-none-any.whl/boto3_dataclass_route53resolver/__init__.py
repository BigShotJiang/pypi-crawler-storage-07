# -*- coding: utf-8 -*-

from .caster import route53resolver_caster

caster = route53resolver_caster

__version__ = "1.40.0"