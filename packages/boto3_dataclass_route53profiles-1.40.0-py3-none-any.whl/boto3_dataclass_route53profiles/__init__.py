# -*- coding: utf-8 -*-

from .caster import route53profiles_caster

caster = route53profiles_caster

__version__ = "1.40.0"