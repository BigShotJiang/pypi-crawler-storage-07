DROP VIEW "public"."cms_v_publications";

ALTER TABLE public.cms_publications ADD COLUMN download_role_id NAME;
ALTER TABLE public.cms_publications ADD FOREIGN KEY(download_role_id) REFERENCES public.roles (role_id) ON UPDATE CASCADE;

CREATE OR REPLACE VIEW "public"."cms_v_publications" AS
SELECT pages.page_id, pages.page_key, pages.site, pages.kind, pages.lang, pages.identifier, pages.parent, pages.modname, pages.menu_visibility, pages.foldable, pages.ord, pages.tree_order, pages.owner, pages.read_role_id, pages.write_role_id, pages.published, pages.parents_published, pages.published_since, pages.creator, pages.created, pages.title_or_identifier, pages.title, pages.description, pages.content, pages._title, pages._description, pages._content, pages.creator_login, pages.creator_name, pages.owner_login, pages.owner_name, publications.author, publications.contributor, publications.illustrator, publications.publisher, publications.published_year, publications.edition, publications.original_isbn, publications.isbn, publications.adapted_by, publications.cover_image, publications.copyright_notice, publications.notes, publications.download_role_id, attachments.filename AS cover_image_filename 
FROM "public"."cms_v_pages" AS pages JOIN public.cms_publications AS publications ON publications.page_id = pages.page_id LEFT OUTER JOIN public.cms_page_attachments AS attachments ON attachments.attachment_id = publications.cover_image;

GRANT all ON "public".cms_v_publications TO "www-data";

CREATE OR REPLACE RULE "cms_v_publications__insert_instead" AS ON INSERT TO "public"."cms_v_publications"
DO INSTEAD (insert into cms_v_pages (site, kind, lang, identifier, parent, modname, menu_visibility, foldable, ord, tree_order, owner, read_role_id, write_role_id, published, parents_published, published_since, creator, created, title_or_identifier, title, description, content, _title, _description, _content, creator_login, creator_name, owner_login, owner_name) values (new.site, new.kind, new.lang, new.identifier, new.parent, new.modname, new.menu_visibility, new.foldable, new.ord, new.tree_order, new.owner, new.read_role_id, new.write_role_id, new.published, new.parents_published, new.published_since, new.creator, new.created, new.title_or_identifier, new.title, new.description, new.content, new._title, new._description, new._content, new.creator_login, new.creator_name, new.owner_login, new.owner_name); insert into cms_publications (page_id, author, contributor, illustrator, publisher, published_year, edition, original_isbn, isbn, adapted_by, cover_image, copyright_notice, notes, download_role_id) select page_id, new.author, new.contributor, new.illustrator, new.publisher, new.published_year, new.edition, new.original_isbn, new.isbn, new.adapted_by, new.cover_image, new.copyright_notice, new.notes, new.download_role_id from cms_pages where identifier=new.identifier and site=new.site and kind=new.kind returning page_id, page_id ||'.'|| (select min(lang) from cms_page_texts where page_id=cms_publications.page_id), CAST(NULL AS TEXT), CAST(NULL AS TEXT), CAST(NULL AS CHAR(2)), CAST(NULL AS TEXT), CAST(NULL AS INTEGER), CAST(NULL AS TEXT), CAST(NULL AS TEXT), CAST(NULL AS BOOLEAN), CAST(NULL AS INTEGER), CAST(NULL AS TEXT), CAST(NULL AS INTEGER), null::name, null::name, CAST(NULL AS BOOLEAN), CAST(NULL AS BOOLEAN), CAST(NULL AS TIMESTAMP(0) WITHOUT TIME ZONE), CAST(NULL AS INTEGER), CAST(NULL AS TIMESTAMP(0) WITHOUT TIME ZONE), CAST(NULL AS TEXT), CAST(NULL AS TEXT), CAST(NULL AS TEXT), CAST(NULL AS TEXT), CAST(NULL AS TEXT), CAST(NULL AS TEXT), CAST(NULL AS TEXT), CAST(NULL AS VARCHAR(64)), CAST(NULL AS TEXT), CAST(NULL AS VARCHAR(64)), CAST(NULL AS TEXT), CAST(NULL AS TEXT), CAST(NULL AS TEXT), CAST(NULL AS TEXT), CAST(NULL AS TEXT), CAST(NULL AS INTEGER), CAST(NULL AS INTEGER), CAST(NULL AS TEXT), CAST(NULL AS TEXT), CAST(NULL AS TEXT), CAST(NULL AS INTEGER), CAST(NULL AS TEXT), CAST(NULL AS TEXT), null::name, CAST(NULL AS TEXT));

CREATE OR REPLACE RULE "cms_v_publications__update_instead" AS ON UPDATE TO "public"."cms_v_publications"
DO INSTEAD (update cms_v_pages set site = new.site, kind = new.kind, lang = new.lang, identifier = new.identifier, parent = new.parent, modname = new.modname, menu_visibility = new.menu_visibility, foldable = new.foldable, ord = new.ord, tree_order = new.tree_order, owner = new.owner, read_role_id = new.read_role_id, write_role_id = new.write_role_id, published = new.published, parents_published = new.parents_published, published_since = new.published_since, creator = new.creator, created = new.created, title_or_identifier = new.title_or_identifier, title = new.title, description = new.description, content = new.content, _title = new._title, _description = new._description, _content = new._content, creator_login = new.creator_login, creator_name = new.creator_name, owner_login = new.owner_login, owner_name = new.owner_name where page_id = old.page_id and lang = old.lang; update cms_publications set author = new.author, contributor = new.contributor, illustrator = new.illustrator, publisher = new.publisher, published_year = new.published_year, edition = new.edition, original_isbn = new.original_isbn, isbn = new.isbn, adapted_by = new.adapted_by, cover_image = new.cover_image, copyright_notice = new.copyright_notice, notes = new.notes, download_role_id = new.download_role_id where page_id = old.page_id;);

CREATE OR REPLACE RULE "cms_v_publications__delete_instead" AS ON DELETE TO "public"."cms_v_publications"
DO INSTEAD delete from cms_pages where page_id = old.page_id;

-- Just a fix of previous upgrade script...
CREATE OR REPLACE FUNCTION "public"."cms_attachments_after_update_trigger"() RETURNS trigger LANGUAGE plpgsql AS $$
declare
    tree_order_matcher text := '';
begin
    if old.filename != new.filename then
       tree_order_matcher := (select tree_order || '.%' from cms_pages		  
                              where page_id=new.page_id and kind='publication');
       update cms_page_texts set
          content=replace(content, old.filename, new.filename),
          _content=replace(_content, old.filename, new.filename)
          where page_id = new.page_id or
                page_id in (select page_id from cms_pages
                            where tree_order like tree_order_matcher);
    end if;
    return null;
end;
$$;
