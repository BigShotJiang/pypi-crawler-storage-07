# Reddevw

⚠️ Before I say anything else; **THIS IS A RED TEAM MODULE**!!!! I SWEAR, PLEASE PLEASE PLEASE DON'T USE THIS ILLEGALLY! I MADE THIS JUST TO HELP WITH OFFENSIVE CODING (in red teaming)!

If you DO infact use this illegaly:

1) You're stupid.
2) You ARE going to get arrested.
3) If you just go bare bones, you WILL be caught, this WILL be detected, and YOU WILL be in a LOT of trouble!

This is made for the intended purpose of ethical use, pentesting, red/blue/purple-teaming, and legality in mind. 