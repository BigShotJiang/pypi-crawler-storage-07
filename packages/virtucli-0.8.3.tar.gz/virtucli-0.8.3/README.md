# VirtuCLI

Basic management of Virtualizor VMs from CLI.

> [!WARNING]
> This library is still in development, and prone for extreme changes. You have been warned.

# Installation

```bash
# Install VirtuCLI
pip3 install git+https://github.com/manoedinata/VirtuCLI
```

# Config File

Check `config.ini.example` for reference.

# Usage

Documentation on the way. Stay tuned!
