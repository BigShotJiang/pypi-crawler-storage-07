from __future__ import annotations

job_timeout = 25
checkout_blocks_and_plots = True
