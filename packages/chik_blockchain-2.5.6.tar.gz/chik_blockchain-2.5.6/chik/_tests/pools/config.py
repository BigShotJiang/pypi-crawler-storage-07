from __future__ import annotations

parallel = 2
job_timeout = 60
checkout_blocks_and_plots = True
