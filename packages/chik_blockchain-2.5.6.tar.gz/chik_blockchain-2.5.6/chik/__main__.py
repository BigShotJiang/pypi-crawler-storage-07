from __future__ import annotations

from chik.cmds.chik import main

main()
