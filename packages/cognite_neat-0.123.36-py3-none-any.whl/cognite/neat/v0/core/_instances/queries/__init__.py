from ._queries import Queries

__all__ = ["Queries"]
