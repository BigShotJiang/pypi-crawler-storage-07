# -*- coding: utf-8 -*-

from .caster import iotthingsgraph_caster

caster = iotthingsgraph_caster

__version__ = "1.40.0"