# Usage

To use Shoestring Assembler in a project:

```default
import shoestring_assembler
```
