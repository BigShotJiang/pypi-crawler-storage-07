=======
History
=======

0.0.1 (2025-03-13)
------------------

* First release on PyPI.
