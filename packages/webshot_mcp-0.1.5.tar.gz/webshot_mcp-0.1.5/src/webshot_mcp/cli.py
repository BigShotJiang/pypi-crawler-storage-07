from .server import run_server

def main():
    run_server()
