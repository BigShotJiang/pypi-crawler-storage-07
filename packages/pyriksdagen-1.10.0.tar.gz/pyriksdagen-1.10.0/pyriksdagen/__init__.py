"""
A python package for accessing and processing the Swedish parliament data


"""
