# backwardpipl
A python function decorator to make a function reversable. It adds a "backward" parameter defaulting at false but once set at true, the function go bottom up.
