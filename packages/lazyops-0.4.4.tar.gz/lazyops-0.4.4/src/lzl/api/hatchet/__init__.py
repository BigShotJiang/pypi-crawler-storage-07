"""
Hatchet API with Modifications
"""

