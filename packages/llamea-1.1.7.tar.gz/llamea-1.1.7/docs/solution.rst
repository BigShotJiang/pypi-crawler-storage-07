Solution
==========

.. automodule:: llamea.solution
   :members:
   :undoc-members:
   :show-inheritance:

