# -*- coding: utf-8 -*-

from .caster import notifications_caster

caster = notifications_caster

__version__ = "1.40.0"