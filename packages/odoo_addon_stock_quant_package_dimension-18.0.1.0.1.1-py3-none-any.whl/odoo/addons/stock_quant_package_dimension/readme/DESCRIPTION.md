This module adds dimension fields on stock packages.
