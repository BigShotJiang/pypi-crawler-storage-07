# Import the main function
from voucherify_core_mcp.server import main

# Run the server
main()