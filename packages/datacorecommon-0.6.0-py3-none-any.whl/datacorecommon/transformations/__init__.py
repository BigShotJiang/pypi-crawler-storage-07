from ._transformations import (
    compute_cagr
    )
__all__ = [
    "compute_cagr"
    ]