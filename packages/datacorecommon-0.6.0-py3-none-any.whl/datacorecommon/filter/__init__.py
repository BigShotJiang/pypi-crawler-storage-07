from ._filter import (
    takelatestrecordperkey,
    takefirstrecordperkey
    ) 
__all__ = [
    "takelatestrecordperkey",
    "takefirstrecordperkey"
    ]