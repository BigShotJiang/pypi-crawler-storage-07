import argparse
import os
import datetime as dt
from typing import Optional

from pyspark.sql import SparkSession
from pyspark.sql import functions as F


env = os.getenv("MLX_ENV")
RUN_HISTORY_TABLE = f"data_system_{env}.orchestration.task_run_log"


def _ensure_utc(dtobj: Optional[dt.datetime]) -> Optional[dt.datetime]:
    """
    Ensures a datetime object is timezone-aware and set to UTC.

    If the object is None, it returns None. If the object is timezone-naive,
    it's assumed to be UTC. If it has another timezone, it's converted to UTC.

    Parameters
    ----------
    dtobj : Optional[dt.datetime]
        The datetime object to process.

    Returns
    -------
    Optional[dt.datetime]
        A timezone-aware datetime object in UTC, or None.
    """
    if dtobj is None:
        return None
    if dtobj.tzinfo is None:
        return dtobj.replace(tzinfo=dt.timezone.utc)
    return dtobj.astimezone(dt.timezone.utc)


def _build_parser() -> argparse.ArgumentParser:
    """
    Creates and configures the argument parser for the ETL job.

    This function defines all expected command-line arguments, including those
    for the execution window, Airflow context, and Databricks context.

    Returns
    -------
    argparse.ArgumentParser
        The configured argument parser instance.
    """
    parser = argparse.ArgumentParser(
        description="ETL Argument Parser",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    # Window + Airflow context
    parser.add_argument("--datetime_begin", default=None)
    parser.add_argument("--datetime_end", default=None)
    parser.add_argument("--write_mode", required=True)
    parser.add_argument("--airflow_run_id", default=None)
    parser.add_argument("--airflow_scheduled_time", default=None)
    parser.add_argument("--airflow_dag_name", default=None)
    parser.add_argument("--airflow_task_name", default=None)
    parser.add_argument("--init_begin_date", default=None)

    # Databricks Workflow context
    parser.add_argument("--databricks_job_id", required=True)
    parser.add_argument("--databricks_job_name", required=True)
    parser.add_argument("--databricks_job_run_id", required=True)
    parser.add_argument("--databricks_task_name", required=True)
    parser.add_argument("--databricks_task_run_id", required=True)

    return parser


def _get_params(parser: argparse.ArgumentParser) -> dict:
    """
    Parses known command-line arguments and returns them as a dictionary.

    Returns
    -------
    dict
        A dictionary mapping argument names to their parsed values.
    """
    arguments = parser.parse_known_args()[0]

    arguments_dict = {
        # window
        "manual_datetime_begin": arguments.datetime_begin,
        "manual_datetime_end": arguments.datetime_end,
        "write_mode": arguments.write_mode,
        "init_begin_date": arguments.init_begin_date,
        # airflow
        "airflow_run_id": arguments.airflow_run_id,
        "airflow_scheduled_time": arguments.airflow_scheduled_time,
        "airflow_dag_name": arguments.airflow_dag_name,
        "airflow_task_name": arguments.airflow_task_name,
        # workflows
        "databricks_job_id": arguments.databricks_job_id,
        "databricks_job_name": arguments.databricks_job_name,
        "databricks_job_run_id": arguments.databricks_job_run_id,
        "databricks_task_name": arguments.databricks_task_name,
        "databricks_task_run_id": arguments.databricks_task_run_id,
    }



    # Return the  parameters
    print("Found the following parameters")
    for kk, vv in arguments_dict.items():
        print(f"\t{kk}: {vv}")
    return arguments_dict


def _is_default_window(
    manual_datetime_begin: Optional[str],
    manual_datetime_end: Optional[str]
) -> bool:
    """
    Determines if the ETL window is default or user-defined.

    The window is considered default only if neither a begin nor an end
    datetime is provided via command-line arguments.

    Parameters
    ----------
    manual_datetime_begin : Optional[str]
        The user-supplied beginning of the datetime window.
    manual_datetime_end : Optional[str]
        The user-supplied end of the datetime window.

    Returns
    -------
    bool
        True if the window is default, False otherwise.
    """
    user_supplied_begin = bool(
        manual_datetime_begin and manual_datetime_begin.strip()
    )
    user_supplied_end = bool(
        manual_datetime_end and manual_datetime_end.strip()
    )

    is_default_window = not (user_supplied_begin or user_supplied_end)

    return is_default_window


def _set_datetime_end(
    manual_datetime_end: Optional[str],
    scheduled_time: Optional[str]
) -> dt.datetime:
    """
    Determines the definitive end datetime for the ETL window.

    It follows this order of precedence:
    1. A manually provided datetime end string.
    2. The scheduled time from an orchestrator like Airflow.

    Parameters
    ----------
    manual_datetime_end : Optional[str]
        The user-supplied end datetime string (e.g., "YYYY-MM-DD HH:MM:SS").
    scheduled_time : Optional[str]
        The scheduled time from the orchestrator in ISO 8601 format.

    Returns
    -------
    dt.datetime
        The resolved end datetime for the ETL window.

    Raises
    ------
    ValueError
        If neither `manual_datetime_end` nor `scheduled_time` is provided,
        or if `scheduled_time` has an invalid format.
    """
    print("Determining the window *end* timestamp...")
    # 1. User override has the highest priority
    if manual_datetime_end:
        print("\t.. found a manual datetime_end")
        return dt.datetime.strptime(manual_datetime_end, "%Y-%m-%d %H:%M:%S")

    # 2. Fallback to the scheduled time from the orchestrator (e.g., Airflow)
    if scheduled_time:
        print("\t... found a scheduled datetime_end")
        try:
            return dt.datetime.fromisoformat(
                scheduled_time.replace("Z", "+00:00")
            )
        except ValueError:
            # If scheduled_time is present but malformed, it's an error
            raise ValueError(
                f"Invalid format for scheduled_time: '{scheduled_time}'. "
                "Expected ISO 8601 format "
                "(e.g., '2025-09-18T15:09:07+00:00')."
            )

    # 3. If neither is available, raise an error
    raise ValueError("Could not determine the ETL window end time.")


def _lookup_last_successful_run(
    spark: SparkSession,
    table_name: str,
) -> Optional[dt.datetime]:
    """
    Finds the end timestamp of the most recent successful run for a table.

    It queries the `RUN_HISTORY_TABLE` for "SUCCESS" states corresponding
    to the given `table_name` and returns the `etl_window_end_timestamp` of
    the latest entry.

    Parameters
    ----------
    spark : SparkSession
        The active SparkSession.
    table_name : str
        The name of the table to look up in the run history.

    Returns
    -------
    Optional[dt.datetime]
        The end timestamp of the last successful run, or None if no successful
        run is found.
    """
    print("Determining the end timestamp of the window of the last successful run...")
    base = (
        spark.table(RUN_HISTORY_TABLE)
             .filter(
                (F.col("state") == F.lit("SUCCESS")) &
                (F.col("table_name") == F.lit(table_name))
              )
    )

    # What happens when the actual run logs as START -> SUCCES -> FAILURE?
    row = (
        base.agg(F.max(
            F.struct("log_timestamp_utc", "etl_window_end_timestamp")
        ).alias("m"))
        .select(F.col("m.etl_window_end_timestamp").alias("end_ts"))
        .first()
    )
    ts_end = row.end_ts if (row and row.end_ts is not None) else None

    print(f"\t...found{ts_end}")

    return ts_end


def _set_datetime_begin(
    table_name: str,
    init_begin_date: Optional[str],
    migration: bool,
    manual_datetime_begin: Optional[str],
    last_success_datetime_end: Optional[dt.datetime]
) -> dt.datetime:
    """
    Determines the definitive start datetime for the ETL window.

    The logic follows this order of precedence:
    1. A manually provided datetime begin string.
    2. The end time of the last successful run from the history table.
    3. The `init_begin_date` as a fallback for the very first run.

    Parameters
    ----------
    table_name : str
        The name of the target table.
    init_begin_date : Optional[str]
        The initial start date string (e.g., "YYYY-MM-DD HH:MM:SS") to use
        if no run history exists.
    migration : bool
        A flag indicating if the run is part of a migration, which enforces
        stricter history checks.
    manual_datetime_begin : Optional[str]
        The user-supplied start datetime string.
    last_success_datetime_end : Optional[dt.datetime]
        The end time of the last successful run.

    Returns
    -------
    dt.datetime
        The resolved start datetime for the ETL window.

    Raises
    ------
    RuntimeError
        - If `migration` is True and no previous successful run is found.
        - If `init_begin_date` is missing and no previous run is found.
    """
    print("Determining the window *start* timestamp...")
    # 1) manual override wins
    if manual_datetime_begin:
        print("\t...using the manual 'datetime_begin'")
        return dt.datetime.strptime(manual_datetime_begin, "%Y-%m-%d %H:%M:%S")

    # 2) central history
    elif last_success_datetime_end:
        print("\t...using the last the end of the last window")
        return last_success_datetime_end

    # 3) migration guard
    elif migration:
        raise RuntimeError(
            f"[MIGRATION] No previous SUCCESS window for '{table_name}'. "
            "Provide --datetime_begin or seed history."
        )

    # 4) fall back to init_begin_date
    elif not init_begin_date:
        raise RuntimeError(
            "INIT_BEGIN_DATE missing and no prior SUCCESS window found."
        )
    else:
        print("\t...using the initialization 'datetime_begin'")
        return dt.datetime.strptime(init_begin_date, "%Y-%m-%d %H:%M:%S")


def _infer_trigger_type(airflow_run_id: Optional[str]) -> str:
    """
    Infers the trigger type based on the Airflow run ID prefix.

    Parameters
    ----------
    run_id : Optional[str]
        The Airflow run ID string.

    Returns
    -------
    str
        The inferred trigger type ('scheduled_airflow', 'manual_airflow',
        'manual_workflow', or 'other').
    """
    print("Inferring the trigger type...")
    if (not airflow_run_id) or (airflow_run_id == ""):
        trigger_type="manual_workflow"
    elif airflow_run_id.lower().startswith("scheduled"):
        trigger_type="scheduled_airflow"
    elif airflow_run_id.lower().startswith("manual"):
        trigger_type="manual_airflow"
    else:
        trigger_type="other"
    print(f"\t...found trigger of type '{trigger_type}'")
    return trigger_type


def handle_run_context(
    spark: SparkSession,
    migration: bool,
    table_name: str
) -> dict:
    """
    Orchestrates the setup of an ETL run by resolving parameters and context.

    This function combines command-line arguments, run history, and default
    configurations to build a complete context dictionary for logging and
    execution.

    Parameters
    ----------
    spark : SparkSession
        The active SparkSession.
    migration : bool
        A flag indicating if the run is part of a migration.
    table_name : str
        The name of the target table for this ETL run.

    Returns
    -------
    dict
        A dictionary containing the complete, resolved run context.
    """
    # 1. Set all parameters forthe command line
    parser = _build_parser()

    # 2. Get all parameters from the command line
    params_dict = _get_params(parser)

    # 3. Resolve the ETL window's end time
    datetime_end = _set_datetime_end(
        params_dict["manual_datetime_end"],
        params_dict["airflow_scheduled_time"]
    )

    # 4. Find the end time of the last successful run from the history table
    if params_dict["manual_datetime_begin"]:
        last_success_dt_end = None
    else:
        last_success_dt_end = _lookup_last_successful_run(spark, table_name)

    # 5. Resolve the ETL window's start time
    datetime_begin = _set_datetime_begin(
        table_name=table_name,
        init_begin_date=params_dict["init_begin_date"],
        migration=migration,
        manual_datetime_begin=params_dict["manual_datetime_begin"],
        last_success_datetime_end=last_success_dt_end,
    )

    # 6. Determine if the window was user-supplied or default
    is_default = _is_default_window(
        params_dict["manual_datetime_begin"],
        params_dict["manual_datetime_end"]
    )

    # 7. Infer the trigger type from the Airflow run ID
    trigger_type = _infer_trigger_type(params_dict["airflow_run_id"])

    # 8. Assemble the final context dictionary, ensuring timestamps are UTC
    params_dict.update({
        "etl_window_start_timestamp": _ensure_utc(datetime_begin),
        "etl_window_end_timestamp": _ensure_utc(datetime_end),
        "is_default_window": is_default,
        "trigger_type": trigger_type,
        "table_name": table_name,
    })

    return params_dict


def _log_task_state_to_central_run_history(
    spark: SparkSession,
    state: str, # "STARTED" | "SUCCESS" | "FAILED"
    ctx: dict,
    log_timestamp_utc: Optional[dt.datetime] = None,
    error_message: Optional[str] = None,
) -> None:
    """
    Writes a single log entry to the `RUN_HISTORY_TABLE`.

    This is a generic logging function used by `log_start`, `log_success`,
    and `log_failure` to record the state of an ETL run.

    Parameters
    ----------
    spark : SparkSession
        The active SparkSession.
    state : str
        The state of the run ("STARTED", "SUCCESS", "FAILED").
    ctx : dict
        The run context dictionary produced by `handle_run_context`.
    log_timestamp_utc : Optional[dt.datetime], optional
        A specific UTC timestamp for the log entry. If None, the current
        server timestamp is used, by default None.
    error_message : Optional[str], optional
        An error message to log if the state is "FAILED", by default None.
    """
    schema = """
        airflow_run_id STRING,
        airflow_dag_name STRING,
        airflow_task_name STRING,
        etl_window_start_timestamp TIMESTAMP,
        etl_window_end_timestamp TIMESTAMP,
        log_timestamp_utc TIMESTAMP,
        is_default_window BOOLEAN,
        write_mode STRING,
        databricks_job_id STRING,
        databricks_job_name STRING,
        databricks_task_run_id STRING,
        databricks_task_name STRING,
        databricks_job_run_id STRING,
        table_name STRING,
        trigger_type STRING,
        state STRING,
        error_message STRING
    """
    print(f"Logging to '{RUN_HISTORY_TABLE}' with state '{state}'...")
    if error_message:
        print(f"\tFound the following error message\n\t{error_message}")
    
    for kk, vv in ctx.items():
        print(f"\t{kk}: {vv}")
    
    # Ensure that the context is not updated
    ctx_extra = {}
    ctx_extra["state"] = state
    if state.upper() == "FAILED":
        ctx_extra["error_message"] = error_message

    # Convert the entry to a Spark DataFrame
    row = [{**ctx, **ctx_extra}]

    df = spark.createDataFrame(row, schema=schema)
    if log_timestamp_utc is None:
        df = df.withColumn("log_timestamp_utc", F.current_timestamp())
    else:
        ts = F.lit(_ensure_utc(log_timestamp_utc)).cast("timestamp")
        df = df.withColumn("log_timestamp_utc", ts)

    (
        df.write
          .format("delta")
          .mode("append")
          .saveAsTable(RUN_HISTORY_TABLE)
    )
    print("\t... done")
    return


def log_start(
    spark: SparkSession,
    ctx: dict,
    start_log_timestamp_utc: dt.datetime
) -> None:
    """
    Logs a "STARTED" record for an ETL run with a specific timestamp.

    Parameters
    ----------
    spark : SparkSession
        The active SparkSession.
    ctx : dict
        The run context dictionary.
    start_log_timestamp_utc : dt.datetime
        The precomputed UTC timestamp for when the job started.
    """
    _log_task_state_to_central_run_history(
        spark,
        state="STARTED",
        ctx=ctx,
        log_timestamp_utc=start_log_timestamp_utc,
    )


def log_success(spark: SparkSession, ctx: dict) -> None:
    """
    Logs a "SUCCESS" record for an ETL run.

    The log timestamp is set to the current server time upon execution.

    Parameters
    ----------
    spark : SparkSession
        The active SparkSession.
    ctx : dict
        The run context dictionary.
    """
    _log_task_state_to_central_run_history(
        spark,
        state="SUCCESS",
        ctx=ctx,
        log_timestamp_utc=None,
    )


def log_failure(
    spark: SparkSession,
    ctx: dict,
    error_message: str
) -> None:
    """
    Logs a "FAILED" record for an ETL run, including an error message.

    The log timestamp is set to the current server time upon execution.

    Parameters
    ----------
    spark : SparkSession
        The active SparkSession.
    ctx : dict
        The run context dictionary.
    error_message : str
        The error message to be logged (truncated to 4000 characters).
    """
    err_msg = error_message[:4000] if error_message else None
    _log_task_state_to_central_run_history(
        spark,
        state="FAILED",
        ctx=ctx,
        log_timestamp_utc=None,
        error_message=err_msg,
    )
