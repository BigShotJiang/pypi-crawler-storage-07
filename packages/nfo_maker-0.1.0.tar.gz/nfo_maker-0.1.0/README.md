# NFO Art

A retro-inspired library + CLI that generates ASCII/ANSI/Unicode art banners like classic `.NFO` / keygen cracktro files.

## Install (editable for dev)
```bash
pip install -e .[figlet]
```

## CLI
```bash
echo "BAXTER" | nfo-art --border double --gradient cyan
```

## Library
```python
from nfo_art import NFOArtOptions, make_art_string
print(make_art_string("BAXTER", NFOArtOptions(gradient="cyan", border="double")))
```
