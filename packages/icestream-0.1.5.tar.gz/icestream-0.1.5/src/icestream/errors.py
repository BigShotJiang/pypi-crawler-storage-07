class IcebergConfigurationError(Exception):
    pass
