
def add_numbers(num1, num2):
    return num1 + num2
 
def subtract_numbers(num1, num2):
    return num1 - num2

def multiply_numbers(num1, num2):
    return num1 * num2

def divide_numbers(num1, num2):
    if num2 == 0:
        raise ValueError("Cannot divide by zero.")
    return num1 / num2

def power_numbers(base, exponent):
    return base ** exponent

def square_root(number):
    if number < 0:
        raise ValueError("Cannot compute square root of a negative number.")
    return number ** 0.5

def factorial(number):
    if number < 0:
        raise ValueError("Cannot compute factorial of a negative number.")
    if number == 0 or number == 1:
        return 1
    result = 1
    for i in range(2, number + 1):
        result *= i
    return result

def modulus(num1, num2):
    return num1 % num2

def logarithm(number, base=10):
    import math
    if number <= 0:
        raise ValueError("Logarithm undefined for non-positive numbers.")
    return math.log(number, base)


def CodeOf_primeNumber(number):
    prmNumber = """if number <= 1:
        return False
    for i in range(2, int(number**0.5) + 1):
        if number % i == 0:
            return False
    return True"""

    return prmNumber

