# -*- coding: utf-8 -*-

from .caster import macie2_caster

caster = macie2_caster

__version__ = "1.40.0"