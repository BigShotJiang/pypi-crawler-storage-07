# coding=utf-8
import os
import importlib.resources

from typing import Any

TyArr = list[Any]
TyDic = dict[Any, Any]
TyPackage = str
TyPath = str


class Pac:

    @staticmethod
    def sh_path(package: TyPackage) -> TyPath:
        _path: TyPath = str(importlib.resources.files(package))
        return _path

    @staticmethod
    def sh_path_by_path(
            package: TyPackage, path: TyPath, log) -> TyPath:
        # def sh_path_by_pack(
        """ show directory
        """
        _path: TyPath = str(importlib.resources.files(package).joinpath(path))
        if not _path:
            msg = f"path {path} does not exist in package {package}"
            raise Exception(msg)
        if os.path.exists(_path):
            return _path
        msg = f"path={_path} does not exist"
        raise Exception(msg)

    @classmethod
    def sh_path_by_path_and_prefix(
            cls, package: TyPackage, path: TyPath, log, prefix: TyPath = '') -> TyPath:
        # def sh_path_by_pack(
        """
        show directory
        """
        _path: TyPath = cls.sh_path_by_path(package, os.path.join(prefix, path), log)
        return _path
