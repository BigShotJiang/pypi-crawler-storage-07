cyclocity = 'get your API key at http://developer.jcdecaux.com'
weelo = {
    'client_id': '<some client id>',
    'client_secret': '<some client secret>',
}
digitransit = 'get your API key at https://portal-api.digitransit.fi'
bicimad = {
    # Get your credentials at https://mobilitylabs.emtmadrid.es
    'passkey': '<some pass key>',
    'clientid': '<some client id>',
}
deutschebahn = {
    # Get your credentials at https://developers.deutschebahn.com
    'client_id': '<some client id>',
    'client_secret': '<some client secret>',
}
# See https://github.com/SFOE/sharedmobility/blob/main/Access%20the%20data.md
sharedmobility = 'a-valid@email-address'

bikeshare_ie = '<some token>'

# See https://github.com/cyklokoalicia/OpenSourceBikeShare/blob/main/Access%20the%20data.md
open_source_bike_share_v2 = '<some token>'
