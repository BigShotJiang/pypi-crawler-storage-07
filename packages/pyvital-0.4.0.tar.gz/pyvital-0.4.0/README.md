# pyvital
Open source python implementation of medical algorithms
