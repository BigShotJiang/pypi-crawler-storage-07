#!/usr/bin/env python3
"""
Setup script for zededa-edgeai-sdk package
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="zededa-edgeai-sdk",
    version="1.0.0",
    author="Zededa",
    author_email="support@zededa.com",
    description="Zededa EdgeAI SDK - CLI and Python library for authentication and MLflow integration",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/zededa/edgeai",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: Apache Software License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.31.0",
    ],
    entry_points={
        "console_scripts": [
            "zededa-edgeai=edgeai_sdk.cli:main",
        ],
    },
)
