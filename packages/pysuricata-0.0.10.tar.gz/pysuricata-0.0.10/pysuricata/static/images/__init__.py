# Image assets
