# Static assets for pysuricata
