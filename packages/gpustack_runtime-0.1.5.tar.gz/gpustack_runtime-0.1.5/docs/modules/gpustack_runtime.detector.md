::: gpustack_runtime.detector
