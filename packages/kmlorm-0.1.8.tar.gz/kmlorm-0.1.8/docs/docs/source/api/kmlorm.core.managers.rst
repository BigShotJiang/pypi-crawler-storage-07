kmlorm.core.managers module
===========================

.. automodule:: kmlorm.core.managers
   :members:
   :show-inheritance:
   :undoc-members:
