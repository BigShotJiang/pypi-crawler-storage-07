"""Plotting functions for competing phases."""

# Contents moved to pymatgen.analysis.defects.plotting.thermo
from .thermo import plot_chempot_2d

__all__ = ["plot_chempot_2d"]
