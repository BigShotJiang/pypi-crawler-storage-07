"""Finite size corrections for defects."""
