def main():
    print("Hello from ag-kit!")


if __name__ == "__main__":
    main()
