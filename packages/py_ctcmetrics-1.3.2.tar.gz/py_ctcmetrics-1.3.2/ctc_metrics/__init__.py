from ctc_metrics.scripts.evaluate import evaluate_sequence
from ctc_metrics.scripts.validate import validate_sequence
