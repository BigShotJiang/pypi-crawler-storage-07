DSA_SLIPS = [
    {
        "slipNo": 1,
        "questions": [
            {
                "question": " ",
                "filenames": ["Q1.c"]
            },
            {
                "question": " ",
                "filenames": ["btree.h"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "Q1.c": """#include <stdio.h>
#include <stdlib.h>
#include "btree.h"
int main()
{
    int ch, n, i, value, cnt;
    struct bst *newnode, *root, *temp;
    root = NULL;
    while (1)
    {
        printf("\\n---Binary Search Tree---\\n");
        printf("1.Insert\\n");
        printf("2.Inorder Traversal (Recursive)\\n");
        printf("3.Exit\\n");
        printf("Enter your choice:");
        scanf("%d", &ch);
        switch (ch)
        {
        case 1:
            printf("\\nHow many nodes to create:");
            scanf("%d", &n);
            for (i = 0; i < n; i++)
            {
                newnode = create();
                printf("\\nEnter the node data:");
                scanf("%d", &newnode->data);
                if (root == NULL)
                    root = newnode;
                else
                    insert(root, newnode);
            }
            break;
        case 2:
            printf("\\nInorder Traversal=");
            inorder(root);
            break;
        case 3:
            exit(0);
        default:
            printf("\\nInvalid Choice\\n");
        }
    }
}""",
            "btree.h": """#include <stdio.h>
#include <stdlib.h>

struct bst
{
    int data;
    struct bst *lchild, *rchild;
} node;
int cnt = 0, leafcnt = 0, nleafcnt = 0;

struct bst *create()
{
    struct bst *temp = (struct bst *)malloc(sizeof(struct bst));
    temp->lchild = NULL;
    temp->rchild = NULL;
    return temp;
}

void insert(struct bst *r, struct bst *new1)
{

    if (new1->data < r->data)
    {
        if (r->lchild == NULL)
            r->lchild = new1;
        else
            insert(r->lchild, new1);
    }

    if (new1->data > r->data)
    {
        if (r->rchild == NULL)
            r->rchild = new1;
        else
            insert(r->rchild, new1);
    }
}
void inorder(struct bst *temp)
{
    if (temp != NULL)
    {
        inorder(temp->lchild);
        printf("%d\\t", temp->data);
        inorder(temp->rchild);
    }
}""",
            "Q2.c": """#include <stdio.h>
#include <malloc.h>
void create(int a[10][10], int n)
{
    int i, j;
    printf("\\n****TYPE 1 FOR YES & 0 FOR NO****\\n");
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            a[i][j] = 0;
            if (i != j)
            {
                printf("\\nIs there any edge between %d & %d: ", i + 1, j + 1);
                scanf("%d", &a[i][j]);
            }
        }
    }
}
void inout(int a[10][10], int n)
{
    int i, j;
    int in = 0, out = 0, total = 0;
    printf("\\nVertex\\t\\tIndegree\\tOutdegree\\tTotal Degree");
    for (i = 0; i < n; i++)
    {
        in = out = 0;
        for (j = 0; j < n; j++)
        {
            in = in + a[j][i];
            out = out + a[i][j];
        }
        total = in + out;
        printf("\\n%d\\t\\t%d\\t\\t%d\\t\\t%d", i + 1, in, out, total);
    }
}
int main()
{
    int a[10][10], n;
    printf("\\nEnter the no. of vertex: ");
    scanf("%d", &n);
    create(a, n);
    inout(a, n);
}"""
        }
    },
    {
        "slipNo": 1,
        "questions": [
            {
                "question": " ",
                "filenames": ["prime.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "prime.c": """ """,
            "Q2.c": """ """
        }
    },
    {
        "slipNo": 1,
        "questions": [
            {
                "question": " ",
                "filenames": ["prime.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "prime.c": """ """,
            "Q2.c": """ """
        }
    },
    {
        "slipNo": 1,
        "questions": [
            {
                "question": " ",
                "filenames": ["prime.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "prime.c": """ """,
            "Q2.c": """ """
        }
    },
    {
        "slipNo": 1,
        "questions": [
            {
                "question": " ",
                "filenames": ["prime.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "prime.c": """ """,
            "Q2.c": """ """
        }
    },
    {
        "slipNo": 1,
        "questions": [
            {
                "question": " ",
                "filenames": ["prime.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "prime.c": """ """,
            "Q2.c": """ """
        }
    },
    {
        "slipNo": 1,
        "questions": [
            {
                "question": " ",
                "filenames": ["prime.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "prime.c": """ """,
            "Q2.c": """ """
        }
    },
    {
        "slipNo": 1,
        "questions": [
            {
                "question": " ",
                "filenames": ["prime.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "prime.c": """ """,
            "Q2.c": """ """
        }
    },
    {
        "slipNo": 1,
        "questions": [
            {
                "question": " ",
                "filenames": ["prime.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "prime.c": """ """,
            "Q2.c": """ """
        }
    },
    {
        "slipNo": 1,
        "questions": [
            {
                "question": " ",
                "filenames": ["prime.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "prime.c": """ """,
            "Q2.c": """ """
        }
    },
    {
        "slipNo": 1,
        "questions": [
            {
                "question": " ",
                "filenames": ["prime.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "prime.c": """ """,
            "Q2.c": """ """
        }
    },
    {
        "slipNo": 1,
        "questions": [
            {
                "question": " ",
                "filenames": ["prime.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "prime.c": """ """,
            "Q2.c": """ """
        }
    },
    {
        "slipNo": 1,
        "questions": [
            {
                "question": " ",
                "filenames": ["prime.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "prime.c": """ """,
            "Q2.c": """ """
        }
    },
    {
        "slipNo": 1,
        "questions": [
            {
                "question": " ",
                "filenames": ["prime.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "prime.c": """ """,
            "Q2.c": """ """
        }
    },
    {
        "slipNo": 1,
        "questions": [
            {
                "question": " ",
                "filenames": ["prime.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "prime.c": """ """,
            "Q2.c": """ """
        }
    },
    {
        "slipNo": 1,
        "questions": [
            {
                "question": " ",
                "filenames": ["prime.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "prime.c": """ """,
            "Q2.c": """ """
        }
    },
    {
        "slipNo": 1,
        "questions": [
            {
                "question": " ",
                "filenames": ["prime.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "prime.c": """ """,
            "Q2.c": """ """
        }
    },
    {
        "slipNo": 1,
        "questions": [
            {
                "question": " ",
                "filenames": ["prime.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "prime.c": """ """,
            "Q2.c": """ """
        }
    },
    {
        "slipNo": 1,
        "questions": [
            {
                "question": " ",
                "filenames": ["prime.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "prime.c": """ """,
            "Q2.c": """ """
        }
    },
    {
        "slipNo": 1,
        "questions": [
            {
                "question": " ",
                "filenames": ["prime.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "prime.c": """ """,
            "Q2.c": """ """
        }
    },
    {
        "slipNo": 1,
        "questions": [
            {
                "question": " ",
                "filenames": ["prime.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "prime.c": """ """,
            "Q2.c": """ """
        }
    },
    {
        "slipNo": 1,
        "questions": [
            {
                "question": " ",
                "filenames": ["prime.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "prime.c": """ """,
            "Q2.c": """ """
        }
    },
    {
        "slipNo": 1,
        "questions": [
            {
                "question": " ",
                "filenames": ["prime.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "prime.c": """ """,
            "Q2.c": """ """
        }
    },
    {
        "slipNo": 1,
        "questions": [
            {
                "question": " ",
                "filenames": ["prime.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "prime.c": """ """,
            "Q2.c": """ """
        }
    },
    {
        "slipNo": 1,
        "questions": [
            {
                "question": " ",
                "filenames": ["prime.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "prime.c": """ """,
            "Q2.c": """ """
        }
    },
]