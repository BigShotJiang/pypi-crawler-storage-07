#!/bin/bash

#exec /usr/sbin/init&

set -x

/opt/dirac/sbin/runsvdir-start
