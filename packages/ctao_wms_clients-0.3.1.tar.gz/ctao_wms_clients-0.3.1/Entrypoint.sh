#! /bin/bash

source /home/dirac/diracos/diracosrc
exec "$@"
