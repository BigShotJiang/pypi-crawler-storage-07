# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) 2018-2024 Andrew Rechnitzer
# Copyright (C) 2020-2025 Colin B. Macdonald
# Copyright (C) 2023 Edith Coates
# Copyright (C) 2024 Aden Chan

# Any utilities that don't have there own version can use this one
# (maybe in future this need not match the client version)
__version__ = "0.19.2"

import sys

# probably we don't need this sort of thing any more, but doesn't hurt...?
if sys.version_info[0] == 2:
    raise RuntimeError("Plom requires Python 3; it will not work with Python 2")

Default_Port = 41984
