# CondaLockedBinaryPackage

::: rattler.lock.CondaLockedBinaryPackage
