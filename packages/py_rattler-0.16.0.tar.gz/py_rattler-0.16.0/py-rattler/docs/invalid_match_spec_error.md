# InvalidMatchSpecError

::: rattler.exceptions.InvalidMatchSpecError
