# Cinema python tools

The `pycinema` python module (https://github.com/cinemascience/pycinema) is a set of tools for reading, writing, manipulating and viewing Cinema databases. The toolkit includes a filter-based python core, command line tools, viewers and a visual app building application (Cinema:Theater).

Documentation for this module is available at http://pycinema.readthedocs.io

You can find out more about Cinema at http://cinemascience.github.io

## Installing and running the pycinema module

```
pip install --upgrade pip
pip install pycinema
```
