"""Tests for HUD MCP clients."""
