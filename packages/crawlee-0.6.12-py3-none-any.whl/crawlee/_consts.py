from __future__ import annotations

METADATA_FILENAME = '__metadata__.json'
