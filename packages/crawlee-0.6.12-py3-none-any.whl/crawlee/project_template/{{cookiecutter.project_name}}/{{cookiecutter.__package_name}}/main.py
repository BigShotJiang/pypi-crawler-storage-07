# % include 'main_%s.py' % cookiecutter.__crawler_type
