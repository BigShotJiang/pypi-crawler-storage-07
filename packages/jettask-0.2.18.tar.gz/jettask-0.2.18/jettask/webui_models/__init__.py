"""
WebUI数据模型
"""