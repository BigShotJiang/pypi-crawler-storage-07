# easter
Python library to high-level communication between services using a RabbitMQ broker
