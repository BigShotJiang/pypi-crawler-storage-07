# -*- coding: utf-8 -*-

from .caster import ivs_realtime_caster

caster = ivs_realtime_caster

__version__ = "1.40.0"