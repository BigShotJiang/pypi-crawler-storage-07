"""
CLI package for Smart Logger.
Provides terminal commands like UI launcher and DB initializer.
"""


