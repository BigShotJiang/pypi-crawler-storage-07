"""
UI package for Smart Logger.
Includes FastAPI server, templates, static files and API routes.
"""
