"""
Routes package for Smart Logger UI.
"""
