from .stmts import CZ as CZ, R as R, Rz as Rz
from ._dialect import dialect as dialect
from ._interface import r as r, cz as cz, rz as rz
