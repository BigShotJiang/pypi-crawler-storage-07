"""Splitter register."""
