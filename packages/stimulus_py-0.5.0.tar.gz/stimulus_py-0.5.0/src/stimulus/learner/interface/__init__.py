"""Interface for the learner."""
