"""Splitter registry test package."""
