"""Test the learner module."""
