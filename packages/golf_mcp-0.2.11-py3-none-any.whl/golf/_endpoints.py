# Auto-generated at build time by setup.py:build_py
# This template contains placeholders that are replaced during build

# Platform endpoints
PLATFORM_API_URL = "https://golf-backend.golf-auth-1.authed-qukc4.ryvn.run/api/resources"
OTEL_ENDPOINT = "https://golf-backend.golf-auth-1.authed-qukc4.ryvn.run/api/v1/otel"