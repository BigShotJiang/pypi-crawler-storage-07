"""CLI package for the GolfMCP framework."""
