# -*- coding: utf-8 -*-

from .caster import eks_auth_caster

caster = eks_auth_caster

__version__ = "1.40.0"