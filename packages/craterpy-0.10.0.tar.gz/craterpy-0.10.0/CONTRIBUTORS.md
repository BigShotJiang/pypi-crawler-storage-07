Contributors in the order of first contribution:

- Christian Tai Udovicic
- Alexandre Boivin
- Dylan Hickson
- Cailin Gallinger
- Cong
- Ari Essunfeld

