"""NLU satisfaction init."""
