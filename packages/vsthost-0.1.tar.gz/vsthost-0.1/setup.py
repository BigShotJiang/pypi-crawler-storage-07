import os
from setuptools import setup, Extension
from setuptools.command.build_ext import build_ext
from distutils.unixccompiler import UnixCCompiler
import pybind11

# Path to your JUCE modules folder (adjust if needed)
JUCE_PATH = os.environ.get('JUCE_PATH', '/Users/sundaychol/Downloads/JUCE-2/modules')

# JUCE modules you're using
JUCE_MODULES = [
    'juce_core',
    'juce_events',
    'juce_audio_basics',
    'juce_audio_devices',
    'juce_audio_processors',
    'juce_audio_utils',
    'juce_gui_basics',  # if you use any GUI features
]

# Source file: your PluginHost.mm (Objective-C++ source)
PLUGIN_HOST_SOURCE = '/Volumes/KUSHS DRIVE/SinesurgeHost/Source/PluginHost.mm'

# Collect all JUCE module cpp implementation files
juce_cpp_files = [
    os.path.join(JUCE_PATH, mod, f"{mod}.cpp") for mod in JUCE_MODULES
]

# All sources together
sources = [PLUGIN_HOST_SOURCE] + juce_cpp_files

# Include directories (JUCE headers + pybind11)
include_dirs = [
    pybind11.get_include(),
    JUCE_PATH,
] + [os.path.join(JUCE_PATH, mod) for mod in JUCE_MODULES]

# Compiler and linker flags
extra_compile_args = [
    '-std=c++17',
    '-stdlib=libc++',
    '-mmacosx-version-min=10.14',
]

extra_link_args = [
    '-framework', 'CoreAudio',
    '-framework', 'CoreMIDI',
    '-framework', 'CoreFoundation',
    '-framework', 'AudioToolbox',
    '-Wl,-rpath,@loader_path',
    '-mmacosx-version-min=10.14',
]

# Define the extension module
ext_modules = [
    Extension(
        'vsthost',
        sources=sources,
        include_dirs=include_dirs,
        language='c++',   # use 'c++' for Objective-C++ source '.mm'
        extra_compile_args=extra_compile_args,
        extra_link_args=extra_link_args,
    )
]

# Patch UnixCCompiler to recognize .mm files (Objective-C++)
UnixCCompiler.src_extensions.append('.mm')

class BuildExt(build_ext):
    def build_extensions(self):
        # Add any per-extension flags here if needed
        build_ext.build_extensions(self)

setup(
    name='vsthost',
    version='0.1',
    author='sinesurge',
    author_email='sinesurge@example.com',
    description='Python bindings for a JUCE VST Instrument Host',
    ext_modules=ext_modules,
    cmdclass={'build_ext': BuildExt},
    zip_safe=False,
)
