.. include:: ../refs.rst

.. _shellcompletion:

================
Shell Completion
================

.. django-admin:: shellcompletion

.. automodule:: django_typer.management.commands.shellcompletion
    :members:
