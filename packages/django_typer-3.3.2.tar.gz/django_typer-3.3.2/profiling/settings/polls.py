from .basic import *  # noqa: F403

INSTALLED_APPS.insert(0, "profiling.polls")  # noqa: F405
