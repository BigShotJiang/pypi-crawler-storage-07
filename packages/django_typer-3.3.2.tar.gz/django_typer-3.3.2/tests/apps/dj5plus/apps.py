from django.apps import AppConfig


class DJ5PlusConfig(AppConfig):
    name = "tests.apps.dj5plus"
    label = "dj5plus"
    verbose_name = "Django 5+"
