from .finalize_subgroups import Command as FinalizeSubgroups


class Command(FinalizeSubgroups):
    pass
