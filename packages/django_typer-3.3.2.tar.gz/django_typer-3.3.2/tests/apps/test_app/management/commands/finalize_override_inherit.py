from .finalize_simple import Command as FinalizeSimple


class Command(FinalizeSimple):
    pass
