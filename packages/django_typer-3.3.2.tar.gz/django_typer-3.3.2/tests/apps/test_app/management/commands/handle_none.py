from django_typer.management import TyperCommand


class Command(TyperCommand):
    help = "Test no commands."
