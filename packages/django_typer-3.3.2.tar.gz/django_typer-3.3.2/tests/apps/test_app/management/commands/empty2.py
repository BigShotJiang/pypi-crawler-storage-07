from django_typer.management import Typer

app = Typer()
