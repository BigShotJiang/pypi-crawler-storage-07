from django.apps import AppConfig


class CompletionConfig(AppConfig):
    name = "tests.apps.completion"
    label = "completion"
    verbose_name = "Completion"
