from .settings_throw_init_exception import *

DT_RICH_TRACEBACK_CONFIG = {"no_install": True}
