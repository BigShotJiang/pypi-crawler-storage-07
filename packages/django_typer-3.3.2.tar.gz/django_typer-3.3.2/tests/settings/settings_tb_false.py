from .base import *

DT_RICH_TRACEBACK_CONFIG = False
