from .backup import *

INSTALLED_APPS = [
    "tests.apps.examples.plugins.media1",
    *INSTALLED_APPS,
]
