from .base import *

SETTINGS_FILE = 3

DJANGO_TYPER_FAIL_CHECK = True
