from .base import *

SETTINGS_FILE = 2
