from .base import *

DJANGO_TYPER_THROW_TEST_EXCEPTION = True
