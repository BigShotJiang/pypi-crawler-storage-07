---
name: 'Feature Request'
about: Suggest a feature
---

# Feature Request

## Description

<!-- edit: --> A clear and concise description of the problem or missing capability...

## Describe the solution you'd like

<!-- edit: --> If you have a solution in mind, please describe it.

## Describe alternatives you've considered

<!-- edit: --> Have you considered any alternative solutions or workarounds?
