def test_import_LandsatL2C2():
    import LandsatL2C2
