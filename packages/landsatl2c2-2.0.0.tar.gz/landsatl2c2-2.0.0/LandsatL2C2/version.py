from importlib.metadata import version

__version__ = version("LandsatL2C2")
