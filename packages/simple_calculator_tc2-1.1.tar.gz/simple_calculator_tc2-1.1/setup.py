from setuptools import setup, find_packages

setup(
    name='simple_calculator_tc2',
    version='1.1',
    packages=find_packages(),
    description='Calculator with memory, supports + - / * sqrt()',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    author='Sofiia GRYN',
    author_email='sgryn18@gmail.com',
    install_requires=[],
    python_requires=">=3.8"
)