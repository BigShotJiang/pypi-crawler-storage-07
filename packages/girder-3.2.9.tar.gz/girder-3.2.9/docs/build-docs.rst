Build the Sphinx Documentation
==============================

In order to build the `Sphinx <http://sphinx-doc.org>`_ documentation, after
setting up your development environment, you can run the following: ::

    tox -e docs
