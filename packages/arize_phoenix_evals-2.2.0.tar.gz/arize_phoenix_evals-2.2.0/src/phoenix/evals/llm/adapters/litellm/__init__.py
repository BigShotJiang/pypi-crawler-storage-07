"""LiteLLM adapter for the Universal LLM Wrapper."""

from .adapter import LiteLLMAdapter

__all__ = [
    "LiteLLMAdapter",
]
