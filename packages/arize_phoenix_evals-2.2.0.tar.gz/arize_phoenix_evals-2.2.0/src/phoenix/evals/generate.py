from .legacy.generate import llm_generate

__all__ = [
    "llm_generate",
]
