# Changelog

## [0.0.3] - 2025-09-27
- `__init__` fix
- Exceptions base class name fix
- Fix license

## [0.0.2] - 2025-09-27
- Convert function number type check
- `__init__` fix

## [0.0.1] - 2025-09-27
- Project initialization
- Added license
- Added readme
- Added changelog
- Added tests
- MyPy check