from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import OrganizationViewSet, RoleViewSet, PermissionViewSet, UserRoleViewSet

router = DefaultRouter()
router.register('organizations', OrganizationViewSet)
router.register('roles', RoleViewSet)
router.register('permissions', PermissionViewSet)
router.register('user-roles', UserRoleViewSet)

urlpatterns = [
    path('api/', include(router.urls)),
]
