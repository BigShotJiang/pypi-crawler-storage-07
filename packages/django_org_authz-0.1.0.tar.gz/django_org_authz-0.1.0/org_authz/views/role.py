from rest_framework import viewsets
from org_authz.models import Organization, Role, Permission, UserRole
from org_authz.serializers import (
    RoleSerializer
)

class RoleViewSet(viewsets.ModelViewSet):
    queryset = Role.objects.all()
    serializer_class = RoleSerializer
