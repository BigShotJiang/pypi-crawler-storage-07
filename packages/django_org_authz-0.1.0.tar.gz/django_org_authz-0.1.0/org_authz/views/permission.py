from rest_framework import viewsets
from org_authz.models import Permission
from org_authz.serializers import (
    PermissionSerializer
)

class PermissionViewSet(viewsets.ModelViewSet):
    queryset = Permission.objects.all()
    serializer_class = PermissionSerializer

