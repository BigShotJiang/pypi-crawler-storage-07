from rest_framework import viewsets
from org_authz.models import Organization
from org_authz.serializers import (
    OrganizationSerializer
)

class OrganizationViewSet(viewsets.ModelViewSet):
    queryset = Organization.objects.all()
    serializer_class = OrganizationSerializer

