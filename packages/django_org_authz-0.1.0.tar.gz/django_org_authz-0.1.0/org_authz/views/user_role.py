from rest_framework import viewsets
from org_authz.models import Organization, Role, Permission, UserRole
from org_authz.serializers import (
    UserRoleSerializer
)

class UserRoleViewSet(viewsets.ModelViewSet):
    queryset = UserRole.objects.all()
    serializer_class = UserRoleSerializer
