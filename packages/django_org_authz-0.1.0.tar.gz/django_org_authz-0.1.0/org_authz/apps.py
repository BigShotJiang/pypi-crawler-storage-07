from django.apps import AppConfig

class OrgAuthzConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "org_authz"
    verbose_name = "Organization Authorization"
