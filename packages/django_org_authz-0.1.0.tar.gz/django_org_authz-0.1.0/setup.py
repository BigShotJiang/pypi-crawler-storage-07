from setuptools import setup, find_packages

setup(
    name="django-org-authz",
    version="0.1.0",
    packages=find_packages(),
    include_package_data=True,
    license="MIT",
    description="Reusable Django app for organization-aware roles and permissions.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/muasya-victor/django-org-authz",
    author="Victor Mwendwa",
    author_email="vicmwe184@gmail.com",
    install_requires=[
        "Django>=4.0",
        "djangorestframework>=3.14",
        "djangorestframework-simplejwt>=5.0.0",
    ],
    classifiers=[
        "Environment :: Web Environment",
        "Framework :: Django",
        "Framework :: Django :: 4.0",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
)
