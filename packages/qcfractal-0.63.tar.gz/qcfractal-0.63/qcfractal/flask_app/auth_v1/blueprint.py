from flask import Blueprint

auth_v1 = Blueprint("auth", __name__, url_prefix="/auth/v1")
