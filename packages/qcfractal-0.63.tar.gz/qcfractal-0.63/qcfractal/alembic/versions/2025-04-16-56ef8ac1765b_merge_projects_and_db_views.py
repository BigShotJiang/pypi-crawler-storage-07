"""Merge projects and db views

Revision ID: 56ef8ac1765b
Revises: e98c86069950, 5ae71b845526
Create Date: 2025-04-16 09:27:07.198910

"""

# revision identifiers, used by Alembic.
revision = "56ef8ac1765b"
down_revision = ("e98c86069950", "5ae71b845526")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
