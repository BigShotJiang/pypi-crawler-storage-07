"""merge manybody branch with changes

Revision ID: d5988aa750ae
Revises: 3690c677f8d1, fd95035b773b
Create Date: 2025-01-14 10:49:27.547435

"""

# revision identifiers, used by Alembic.
revision = "d5988aa750ae"
down_revision = ("3690c677f8d1", "fd95035b773b")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
