"""Merge projects and manager migrations

Revision ID: 0c0b1dea52dc
Revises: a6a708376a1e, 93fa1a1b70f8
Create Date: 2025-04-27 12:47:56.091604

"""

# revision identifiers, used by Alembic.
revision = "0c0b1dea52dc"
down_revision = ("a6a708376a1e", "93fa1a1b70f8")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
