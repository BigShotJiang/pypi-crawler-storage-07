from ut_dic.dic import Dic
from ut_cli.aoeq import AoEq
from ut_cli.doeq import DoEq

from typing import Any
TyAny = Any
TyArr = list[Any]
TyDic = dict[Any, Any]
TyTup = tuple[Any, Any]

TnDic = None | TyDic
TnTup = tuple[None | Any, None | Any]


class Kwargs:
    """
    Keyword arguments processor
    """
    @staticmethod
    def sh_cls_parms_task(cls_app, d_eq: TyDic) -> TyTup:
        if hasattr(cls_app, 'd_parms_task'):
            if 'cmd' in d_eq:
                _t_parms_task: TyTup = Dic.locate(
                        cls_app.d_parms_task, d_eq['cmd'][0])
            else:
                msg = f"'cmd' is not defined in d_eq={d_eq}"
                raise Exception(msg)
        elif hasattr(cls_app, 't_parms_task'):
            _t_parms_task = cls_app.t_parms_task
        else:
            msg = ("application class 'cls_app' does not contain "
                   "attributes 'd_parms_task' or 't_parms_task'")
            raise Exception(msg)
        return _t_parms_task

    @classmethod
    def sh(cls, cls_com, cls_app, sys_argv: TyArr) -> TyDic:
        """
        show keyword arguments
        """
        _args = sys_argv[1:]
        _d_eq: TyDic = AoEq.sh_d_eq(_args)
        _cls_parms, _cls_task = cls.sh_cls_parms_task(cls_app, _d_eq)
        if _cls_parms is not None:
            _d_parms = _cls_parms.d_parms
        else:
            _d_parms = None

        _kwargs: TyDic = DoEq.verify(_d_eq, _d_parms)
        _sh_prof = _kwargs.get('sh_prof')
        if callable(_sh_prof):
            _kwargs['sh_prof'] = _sh_prof()
        _kwargs['cls_parms'] = _cls_parms
        _kwargs['cls_task'] = _cls_task
        _kwargs['com'] = cls_com
        _kwargs['cls_app'] = cls_app

        return _kwargs
