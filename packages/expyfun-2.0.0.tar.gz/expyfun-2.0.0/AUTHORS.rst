.. -*- mode: rst -*-

Authors
=======

  * Dan McCloy 2013
  * Eric Larson 2013

