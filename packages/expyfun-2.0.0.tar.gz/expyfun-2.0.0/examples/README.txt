General examples
-------------------

General-purpose and introductory examples to expyfun.

