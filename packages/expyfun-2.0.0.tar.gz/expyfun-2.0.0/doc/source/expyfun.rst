.. _expyfun:

=======
Expyfun
=======

.. toctree::
   :maxdepth: 1

   auto_examples/index.rst
   python_reference.rst
