============
Expyfun home
============

This software is provided to facilitate LABS^N experiment coding.

.. toctree::
   :maxdepth: 2

   expyfun

