"""
Business logic
"""
