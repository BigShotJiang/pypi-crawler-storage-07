"""Agent CI CLI - Command-line interface for Agent CI"""

from importlib.metadata import version

__version__ = version("agentci")
