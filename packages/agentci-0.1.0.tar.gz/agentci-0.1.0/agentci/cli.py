"""Agent CI CLI - Coming Soon"""

from agentci import __version__


def main():
    """Main entry point for the Agent CI CLI."""
    print(f"Agent CI CLI v{__version__}")
    print("Full functionality coming soon.")
    print("Visit https://agent-ci.com for updates")


if __name__ == "__main__":
    main()
