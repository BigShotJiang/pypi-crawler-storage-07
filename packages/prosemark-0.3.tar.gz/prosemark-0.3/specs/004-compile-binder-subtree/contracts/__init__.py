"""Contract definitions for compile operations."""
