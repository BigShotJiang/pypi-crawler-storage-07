"""Compile application module for use cases."""
