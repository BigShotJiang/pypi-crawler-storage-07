"""Freewriting feature for prosemark.

This package provides a distraction-free freewriting interface with support
for writing to existing nodes or creating timestamped daily files.
"""
