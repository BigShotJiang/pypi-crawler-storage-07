"""Compile ports module for service interfaces."""
