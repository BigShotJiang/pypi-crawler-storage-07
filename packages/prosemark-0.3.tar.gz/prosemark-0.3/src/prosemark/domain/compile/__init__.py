"""Compile domain module for node subtree compilation."""
