"""
Module:
    kleenex

Authors:
    Myles Dear(mdear), CSG Test - Ottawa
    Siming Yuan (siyuan), CSG Test - Ottawa

Description:
    This module provides a framework that allows users to:

    - plug in own orchestrators that bring up dynamic device
      topologies on a variety of different backends.

    - plug in their own cleaners that prepare a physical device for testing.
"""



# metadata
__version__ = "25.9"
__author__ = 'Cisco Systems Inc.'
__contact__ = ['pyats-support@cisco.com', 'pyats-support-ext@cisco.com']
__copyright__ = 'Copyright (c) 2017-2019, Cisco Systems Inc.'

from pyats.clean.utils import (
    parse_cli_args,  testbed_config_contains_logical_routers,
    ArgvQuotingParser, help_suppress_kleenex)
from .kleenex_main import main, KleenexMain, save_clean_config_to_file
from .engine import KleenexEngine
from pyats.clean.bases import BaseCleaner
from pyats.clean.loader import KleenexFileLoader
from pyats.clean.schema import allowed_virtual_device_types
from pyats.clean.exceptions import YamlConfigError
