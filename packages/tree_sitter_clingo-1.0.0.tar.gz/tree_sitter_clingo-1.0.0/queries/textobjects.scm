(statement) @function.outer
