# -*- coding: utf-8 -*-

from .caster import rds_data_caster

caster = rds_data_caster

__version__ = "1.40.0"