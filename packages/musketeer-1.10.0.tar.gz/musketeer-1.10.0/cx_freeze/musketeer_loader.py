from musketeer import __main__  # noqa: F401
