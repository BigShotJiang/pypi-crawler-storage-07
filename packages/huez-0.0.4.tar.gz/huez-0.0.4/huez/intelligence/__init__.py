"""
Huez Intelligent Color System
智能配色核心功能模块
"""

from .color_expansion import intelligent_color_expansion
from .colormap_detection import detect_colormap_type
from .accessibility import check_colorblind_safety, simulate_colorblind_vision
from .chart_adaptation import detect_chart_type, adapt_colors_for_chart

__all__ = [
    'intelligent_color_expansion',
    'detect_colormap_type',
    'check_colorblind_safety',
    'simulate_colorblind_vision',
    'detect_chart_type',
    'adapt_colors_for_chart',
]

