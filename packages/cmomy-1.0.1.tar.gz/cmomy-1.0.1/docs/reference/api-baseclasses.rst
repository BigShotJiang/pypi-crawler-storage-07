Base Classes
============

.. autoclass:: cmomy.wrapper.wrap_abc.CentralMomentsABC
   :autosummary:
   :show-inheritance:
   :inherited-members:
   :members:
