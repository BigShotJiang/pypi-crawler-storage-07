Modules
=======

.. autosummary::

   cmomy

.. autosummary::
   :toctree: generated/
   :template: autodocsumm/module-inherit.rst

   cmomy.reduction
   cmomy.resample
   cmomy.grouped
   cmomy.rolling
   cmomy.convert
   cmomy.utils
   cmomy.random
   cmomy.confidence_interval
   cmomy.compile
   cmomy.options



.. autosummary::
   :toctree: generated/
   :template: autodocsumm/module.rst

   cmomy.core.typing
