# Installation

## Stable release

```{include} ../README.md
:start-after: <!-- start-installation -->
:end-before: <!-- end-installation -->
```

## From sources

See [](./contributing) for details on installing from source.
