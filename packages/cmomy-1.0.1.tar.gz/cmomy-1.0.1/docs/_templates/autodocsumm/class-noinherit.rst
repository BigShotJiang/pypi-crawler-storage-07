{{ fullname | escape | underline}}

.. currentmodule:: {{ module }}



.. autoclass:: {{ objname }}
   :autosummary:
   :show-inheritance:
