<!-- markdownlint-disable MD041 -->

```{include} ../AUTHORS.md

```
