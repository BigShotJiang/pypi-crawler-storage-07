from operator import itemgetter

x = itemgetter(0)
y = itemgetter(1)
