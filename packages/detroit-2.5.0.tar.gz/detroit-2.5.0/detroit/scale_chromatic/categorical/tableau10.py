from ..colors import colors

SCHEME_TABLEAU_10 = colors(
    "4e79a7f28e2ce1575976b7b259a14fedc949af7aa1ff9da79c755fbab0ab"
)
