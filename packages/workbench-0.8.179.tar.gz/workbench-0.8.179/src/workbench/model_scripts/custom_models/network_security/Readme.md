# Network Security Model Scripts
Welcome to the set of model scripts related to network security. Mostly focused on feature creation, specifically Network Packet processing and enrichment. 


### References
- DPKT
- chains