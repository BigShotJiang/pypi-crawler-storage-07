# Raw Data
This directory is used to store the raw data, as downloaded from the OECD website, if the user does not provide
a path when importing the package.