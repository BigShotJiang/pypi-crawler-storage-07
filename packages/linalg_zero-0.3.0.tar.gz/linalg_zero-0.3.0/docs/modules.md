::: linalg_zero.generate
