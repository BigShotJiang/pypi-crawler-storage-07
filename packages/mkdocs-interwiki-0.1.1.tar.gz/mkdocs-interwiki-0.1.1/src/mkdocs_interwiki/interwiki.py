from __future__ import annotations
import re
from typing import Dict, Any
from urllib.parse import quote
from markdown import Extension
from markdown.inlinepatterns import InlineProcessor
from xml.etree.ElementTree import Element

# Turn on verbose mode INSIDE the pattern so Markdown's compiler keeps it.
INTERWIKI_RE = r"""(?x)
\[\[                             # [[
(?P<prefix>[A-Za-z0-9_\-]+)      # prefix
>                                # >
(?P<target>[^\]|]+?)             # target (stop at ] or |)
(?:\|(?P<label>[^\]]+))?         # optional |Label
\]\]                             # ]]
"""

class InterWikiPattern(InlineProcessor):
    def __init__(self, pattern: str, maps: Dict[str, str], extra: Dict[str, Any] | None = None):
        # NOTE: Do NOT pass flags here; Markdown will compile with its own flags.
        super().__init__(pattern)
        self.maps = maps or {}
        self.extra = extra or {}

    def handleMatch(self, m, data):
        prefix = m.group('prefix')
        target_raw = (m.group('target') or "").strip()
        label = (m.group('label') or "").strip()

        if prefix not in self.maps:
            # Unknown prefix: leave source text unchanged
            return None, m.start(0), m.end(0)

        template = self.maps[prefix]
        target_encoded = quote(target_raw, safe="/:@()!$*,;=+-._~")

        fmt_vars = dict(self.extra)
        fmt_vars["target"] = target_encoded

        try:
            href = template.format(**fmt_vars)
        except KeyError:
            return None, m.start(0), m.end(0)

        a = Element('a')
        a.set('href', href)
        a.text = label if label else target_raw
        return a, m.start(0), m.end(0)


class InterWikiExtension(Extension):
    def __init__(self, **kwargs):
        self.config = {
            'maps':  [{}, 'Map of prefixes to URL templates'],
            'extra': [{}, 'Extra template variables'],
        }
        super().__init__(**kwargs)
        self._pattern: InterWikiPattern | None = None
        self._maps = self.getConfig('maps') or {}
        self._extra = self.getConfig('extra') or {}

    def set_extra(self, extra: Dict[str, Any] | None):
        """Allow plugin to update per-page variables safely."""
        self._extra = extra or {}
        if self._pattern is not None:
            self._pattern.extra = self._extra

    def extendMarkdown(self, md):
        # Register exactly once, keep a reference so we can update .extra later
        self._pattern = InterWikiPattern(INTERWIKI_RE, maps=self._maps, extra=self._extra)
        md.inlinePatterns.register(self._pattern, 'interwiki', 175)
