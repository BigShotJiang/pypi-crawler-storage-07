# SPDX-License-Identifier: Apache-2.0
from .data_access_factory_test import AbstractDataAccessFactoryTests
