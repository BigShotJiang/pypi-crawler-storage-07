# -*- coding: utf-8 -*-

from .caster import lex_models_caster

caster = lex_models_caster

__version__ = "1.40.0"