# setup.py

from setuptools import setup, find_packages

setup(
    name="IHopesProperties",
    version="1.1.2",
    packages=find_packages(),
    install_requires=[],
    author="Ori Peri",
    author_email="25to40@gmail.com",
    description="Leads flow of IHopesProperties",
)
