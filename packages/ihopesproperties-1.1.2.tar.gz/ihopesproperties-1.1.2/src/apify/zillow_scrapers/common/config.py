#APIFY_API_TOKEN = 'apify_api_RiHYgad2cEbJVzHCMEcECjMaGCmZ4145Zemw'
#APIFY_API_TOKEN = 'apify_api_3BOnahpympcgHIFZNAwEa5N4dhlJ3i2GCrzu'
from enum import Enum

APIFY_API_TOKEN = 'apify_api_FMtMdLbfYGOtbmkX4asDkztQsf4gJX1iVX2R'


class Actor(Enum):
    ZILLOW_SEARCH_SCRAPER = 'maxcopell/zillow-scraper'
    ZILLOW_DETAIL_SCRAPER = 'maxcopell/zillow-detail-scraper'
