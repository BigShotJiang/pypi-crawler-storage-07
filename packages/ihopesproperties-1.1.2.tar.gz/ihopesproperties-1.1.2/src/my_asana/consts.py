PERSONAL_ACCESS_TOKEN: str = "2/1207911699123552/1207913152808612:785d2a80c92725676b0a30d75502894a"
WORKSPACE_ID: str = '1206867055887049'

LEADS_PROJECT_ID: str = "1208202180668499"

LEADS_PROPERTIES_SECTION: str = '1208202329927604'
FOLLOW_UPS_UNDER_CONTRACT_SECTION: str = '1208204841869577'
DECLINED_LEADS_SECTION: str = '1208204841869597'
PROPERTY_TASK_TEMPLATE_ID: str = '1209741949135185'

sections = [{'created_at': '2024-09-02T08:06:39.564Z',
             'gid': '1208202180668500',
             'name': 'Untitled section',
             'project': {'gid': '1208202180668499', 'name': 'Real Estate Leads'}},
            {'created_at': '2024-09-02T14:29:42.735Z',
             'gid': '1208204841869597',
             'name': 'Declined Leads',
             'project': {'gid': '1208202180668499', 'name': 'Real Estate Leads'}},
            {'created_at': '2024-09-02T08:07:07.780Z',
             'gid': '1208202329927604',
             'name': 'Leads',
             'project': {'gid': '1208202180668499', 'name': 'Real Estate Leads'}},
            {'created_at': '2024-09-21T06:48:30.642Z',
             'gid': '1208366188256328',
             'name': 'Post ARV, Pre Rehab (Eligible)',
             'project': {'gid': '1208202180668499', 'name': 'Real Estate Leads'}},
            {'created_at': '2024-09-02T13:43:40.828Z',
             'gid': '1208204841869580',
             'name': 'Post Rehab, Offers Pending',
             'project': {'gid': '1208202180668499', 'name': 'Real Estate Leads'}},
            {'created_at': '2024-09-02T13:36:53.102Z',
             'gid': '1208204841869577',
             'name': 'Follow Ups (Under Contract)',
             'project': {'gid': '1208202180668499', 'name': 'Real Estate Leads'}},
            {'created_at': '2024-09-23T07:21:46.723Z',
             'gid': '1208371795506525',
             'name': 'Follow Ups (Offer Rejectd)',
             'project': {'gid': '1208202180668499', 'name': 'Real Estate Leads'}},
            {'created_at': '2024-11-10T09:53:57.113Z',
             'gid': '1208733061284951',
             'name': 'Offer Accepted - In progress',
             'project': {'gid': '1208202180668499', 'name': 'Real Estate Leads'}}]
