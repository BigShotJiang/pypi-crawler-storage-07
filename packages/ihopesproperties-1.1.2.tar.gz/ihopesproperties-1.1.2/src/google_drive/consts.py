GOOGLE_DRIVE_PROJECT_NAME: str = 'IHopesPropertiesGProject'

CLIENT_ID: str = '1040077980830-j5tkof0du3okp54iq8as0og4s5k263ja.apps.googleusercontent.com'
WEB_APP_CLIENT_ID: str = '1040077980830-hs7lpar7pel7tgcgcc8bc7tsrnm03l68.apps.googleusercontent.com'
WEB_APP_CLIENT_SECRET: str = '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' # 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

ARV_TEMPLATE_FILE_ID: str = '1etDxXHDevTsYqj6_s3T4B-CJYEoGtXh8pTf2xqu3kRE'
LEADS_ANALYSIS_FOLDER_ID: str = '1lDT560jWczX4866xd1gXC2UDBgf8E8lc'