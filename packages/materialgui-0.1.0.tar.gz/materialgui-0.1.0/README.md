# materialgui

Material Design GUI library for Python using PyQt6.

## Install

```bash
pip install materialgui
