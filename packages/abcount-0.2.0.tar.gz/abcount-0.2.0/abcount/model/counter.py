class GroupTypeAttribute:
    ACID = "acid"
    BASE = "base"


class DefinitionAttribute:
    SMARTS = "smarts"
    TYPE = "type"
