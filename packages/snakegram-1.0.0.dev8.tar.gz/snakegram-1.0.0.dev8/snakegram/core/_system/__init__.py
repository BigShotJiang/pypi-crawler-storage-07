from .tracker import tracker

system_routers = [
    tracker
]