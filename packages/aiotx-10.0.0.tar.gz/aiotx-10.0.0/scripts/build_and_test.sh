pip install .
pytest