from pydantic.types import StrictBool, StrictInt, StrictStr

ValueVariants = StrictBool | StrictInt | StrictStr
