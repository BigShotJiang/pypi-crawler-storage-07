"""Version information for structured-logger package."""

__version__ = "1.2.0"
