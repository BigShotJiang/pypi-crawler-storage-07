# Example Azure Functions App

This example demonstrates how to use `azure-functions-openapi-pydantic` in a real Azure Functions application.

## Features Demonstrated

- ✅ POST endpoints with request validation
- ✅ GET endpoints with query parameters
- ✅ Nested Pydantic models
- ✅ Error handling with custom responses
- ✅ OpenAPI spec generation
- ✅ Azure Functions Blueprint integration
- ✅ Response envelope pattern

## Quick Start

### 1. Install Dependencies

```bash
cd examples
pip install -r requirements.txt
```

### 2. Run Locally

```bash
func start
```

### 3. Test the API

**Create a User:**
```bash
curl -X POST http://localhost:7071/api/users \
  -H "Content-Type: application/json" \
  -d '{
    "name": "John Doe",
    "email": "john@example.com",
    "age": 30
  }'
```

**Get User:**
```bash
curl http://localhost:7071/api/users/usr_123
```

**List Users with Pagination:**
```bash
curl "http://localhost:7071/api/users?limit=10&offset=0&active=true"
```

**View OpenAPI Spec:**
```bash
curl http://localhost:7071/api/openapi.json
```

### 4. View Swagger UI

Open in your browser:
```
http://localhost:7071/api/docs
```

## Project Structure

```
examples/
├── function_app.py       # Main application entry point
├── models.py            # Pydantic models
├── requirements.txt     # Dependencies
├── host.json           # Azure Functions host config
└── local.settings.json # Local development settings
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/users` | Create a new user |
| GET | `/api/users` | List users with pagination |
| GET | `/api/users/{id}` | Get user by ID |
| PUT | `/api/users/{id}` | Update user |
| DELETE | `/api/users/{id}` | Delete user |
| GET | `/api/users/{id}/profile` | Get user profile with nested data |
| GET | `/api/openapi.json` | Get OpenAPI specification |
| GET | `/api/docs` | Swagger UI documentation |

## Deployment

Deploy to Azure:

```bash
func azure functionapp publish <YOUR_FUNCTION_APP_NAME>
```

## Learn More

- [Azure Functions Python Documentation](https://docs.microsoft.com/en-us/azure/azure-functions/functions-reference-python)
- [Pydantic Documentation](https://docs.pydantic.dev/)

