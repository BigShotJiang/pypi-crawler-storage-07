# API Testing Examples

Quick reference for testing the API with curl commands.

## Create User

```bash
curl -X POST http://localhost:7071/api/users \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Jane Smith",
    "email": "jane@example.com",
    "age": 28,
    "bio": "Designer and creative director"
  }'
```

**Expected Response (201):**
```json
{
  "success": true,
  "data": {
    "id": "usr_003",
    "name": "Jane Smith",
    "email": "jane@example.com",
    "age": 28,
    "bio": "Designer and creative director",
    "created_at": "2025-01-01T12:00:00Z",
    "updated_at": "2025-01-01T12:00:00Z"
  },
  "error": null
}
```

## List Users

```bash
curl "http://localhost:7071/api/users?limit=10&offset=0"
```

## Get Specific User

```bash
curl http://localhost:7071/api/users/usr_001
```

## Update User

```bash
curl -X PUT http://localhost:7071/api/users/usr_001 \
  -H "Content-Type: application/json" \
  -d '{
    "bio": "Updated bio text"
  }'
```

## Delete User

```bash
curl -X DELETE http://localhost:7071/api/users/usr_001
```

## Get User Profile (Nested Data)

```bash
curl http://localhost:7071/api/users/usr_001/profile
```

**Expected Response (200):**
```json
{
  "success": true,
  "data": {
    "user": {
      "id": "usr_001",
      "name": "Alice Johnson",
      "email": "alice@example.com",
      "age": 28,
      "bio": "Product Manager",
      "created_at": "2024-01-15T10:30:00Z",
      "updated_at": "2024-01-15T10:30:00Z"
    },
    "address": {
      "street": "123 Main St",
      "city": "San Francisco",
      "state": "CA",
      "zip_code": "94102",
      "country": "US"
    },
    "preferences": {
      "theme": "dark",
      "notifications": true,
      "language": "en"
    },
    "is_active": true
  },
  "error": null
}
```

## Error Example: Invalid Email

```bash
curl -X POST http://localhost:7071/api/users \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Invalid User",
    "email": "not-an-email",
    "age": 25
  }'
```

**Expected Response (400):**
```json
{
  "success": false,
  "data": null,
  "error": "Validation error: 1 validation error for UserCreateRequest..."
}
```

## Error Example: User Not Found

```bash
curl http://localhost:7071/api/users/usr_999
```

**Expected Response (404):**
```json
{
  "success": false,
  "data": null,
  "error": "User not found"
}
```

## View OpenAPI Spec

```bash
curl http://localhost:7071/api/openapi.json | python -m json.tool
```

## Health Check

```bash
curl http://localhost:7071/api/health
```

