"""
Pydantic models for the example API
"""
from pydantic import BaseModel, Field, EmailStr
from typing import Optional


class Address(BaseModel):
    """User address"""
    street: str = Field(..., min_length=1, max_length=200)
    city: str = Field(..., min_length=1, max_length=100)
    state: str = Field(..., min_length=2, max_length=2, description="Two-letter state code")
    zip_code: str = Field(..., pattern=r'^\d{5}(-\d{4})?$')
    country: str = Field(default="US", max_length=2)


class UserCreateRequest(BaseModel):
    """Request model for creating a user"""
    name: str = Field(..., min_length=1, max_length=100, description="Full name")
    email: EmailStr = Field(..., description="Valid email address")
    age: int = Field(..., ge=18, le=120, description="Age must be between 18 and 120")
    bio: Optional[str] = Field(None, max_length=500, description="User bio")


class UserUpdateRequest(BaseModel):
    """Request model for updating a user"""
    name: Optional[str] = Field(None, min_length=1, max_length=100)
    email: Optional[EmailStr] = None
    age: Optional[int] = Field(None, ge=18, le=120)
    bio: Optional[str] = Field(None, max_length=500)


class User(BaseModel):
    """User response model"""
    id: str = Field(..., description="Unique user identifier")
    name: str
    email: EmailStr
    age: int
    bio: Optional[str] = None
    created_at: str = Field(..., description="ISO 8601 timestamp")
    updated_at: str = Field(..., description="ISO 8601 timestamp")


class UserProfile(BaseModel):
    """Extended user profile with nested data"""
    user: User
    address: Optional[Address] = None
    preferences: dict = Field(default_factory=dict)
    is_active: bool = True
    
    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "user": {
                        "id": "usr_123",
                        "name": "John Doe",
                        "email": "john@example.com",
                        "age": 30,
                        "bio": "Software engineer",
                        "created_at": "2025-01-01T00:00:00Z",
                        "updated_at": "2025-01-01T00:00:00Z"
                    },
                    "address": {
                        "street": "123 Main St",
                        "city": "San Francisco",
                        "state": "CA",
                        "zip_code": "94102",
                        "country": "US"
                    },
                    "preferences": {
                        "theme": "dark",
                        "notifications": True
                    },
                    "is_active": True
                }
            ]
        }
    }


class UserList(BaseModel):
    """Paginated list of users"""
    users: list[User]
    total: int
    limit: int
    offset: int

