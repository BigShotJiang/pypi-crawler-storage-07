"""
Example Azure Functions app demonstrating azure-functions-openapi-pydantic
"""
import json
import azure.functions as func
from datetime import datetime, timezone

from azfunc_openapi_pydantic import openapi, ApiResponse, generate_openapi_spec, generate_swagger_ui
from models import (
    User, UserCreateRequest, UserUpdateRequest, 
    UserProfile, UserList, Address
)


app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)


# In-memory database for demo purposes
USERS_DB = {
    "usr_001": {
        "id": "usr_001",
        "name": "Alice Johnson",
        "email": "alice@example.com",
        "age": 28,
        "bio": "Product Manager",
        "created_at": "2024-01-15T10:30:00Z",
        "updated_at": "2024-01-15T10:30:00Z"
    },
    "usr_002": {
        "id": "usr_002",
        "name": "Bob Smith",
        "email": "bob@example.com",
        "age": 35,
        "bio": "Software Engineer",
        "created_at": "2024-02-20T14:45:00Z",
        "updated_at": "2024-02-20T14:45:00Z"
    }
}


@app.route(route="users", methods=["POST"])
@openapi(
    request=UserCreateRequest,
    response=User,
    tags=["Users"],
    summary="Create a new user",
    errors={409: "User with this email already exists"}
)
def create_user(req: func.HttpRequest) -> func.HttpResponse:
    """
    Create a new user with validated input data.
    Returns 201 on success with the created user object.
    """
    body = req.validated_body
    
    # Check for duplicate email
    for user in USERS_DB.values():
        if user["email"] == body.email:
            return ApiResponse.fail("User with this email already exists", status_code=409)
    
    # Generate new user ID
    user_id = f"usr_{len(USERS_DB) + 1:03d}"
    now = datetime.now(timezone.utc).isoformat()
    
    # Create user
    user_data = {
        "id": user_id,
        "name": body.name,
        "email": body.email,
        "age": body.age,
        "bio": body.bio,
        "created_at": now,
        "updated_at": now
    }
    
    USERS_DB[user_id] = user_data
    user = User(**user_data)
    
    return ApiResponse.ok(user, status_code=201)


@app.route(route="users", methods=["GET"])
@openapi(
    response=UserList,
    params={"limit": int, "offset": int, "active": bool},
    tags=["Users"],
    summary="List all users with pagination"
)
def list_users(req: func.HttpRequest) -> func.HttpResponse:
    """
    Retrieve a paginated list of users.
    Supports filtering and pagination via query parameters.
    """
    params = getattr(req, 'parsed_params', {})
    limit = params.get('limit', 10)
    offset = params.get('offset', 0)
    active = params.get('active', True)
    
    users = list(USERS_DB.values())
    total = len(users)
    
    # Apply pagination
    paginated_users = users[offset:offset + limit]
    
    user_list = UserList(
        users=[User(**u) for u in paginated_users],
        total=total,
        limit=limit,
        offset=offset
    )
    
    return ApiResponse.ok(user_list)


@app.route(route="users/{id}", methods=["GET"])
@openapi(
    response=User,
    tags=["Users"],
    summary="Get user by ID",
    errors={404: "User not found"}
)
def get_user(req: func.HttpRequest) -> func.HttpResponse:
    """
    Retrieve a specific user by their unique identifier.
    Returns 404 if user doesn't exist.
    """
    user_id = req.route_params.get('id')
    
    if user_id not in USERS_DB:
        return ApiResponse.fail("User not found", status_code=404)
    
    user = User(**USERS_DB[user_id])
    return ApiResponse.ok(user)


@app.route(route="users/{id}", methods=["PUT"])
@openapi(
    request=UserUpdateRequest,
    response=User,
    tags=["Users"],
    summary="Update user",
    errors={404: "User not found"}
)
def update_user(req: func.HttpRequest) -> func.HttpResponse:
    """
    Update an existing user's information.
    Only provided fields will be updated.
    """
    user_id = req.route_params.get('id')
    body = req.validated_body
    
    if user_id not in USERS_DB:
        return ApiResponse.fail("User not found", status_code=404)
    
    user_data = USERS_DB[user_id]
    
    # Update only provided fields
    update_data = body.model_dump(exclude_none=True)
    user_data.update(update_data)
    user_data["updated_at"] = datetime.now(timezone.utc).isoformat()
    
    user = User(**user_data)
    return ApiResponse.ok(user)


@app.route(route="users/{id}", methods=["DELETE"])
@openapi(
    response=User,
    tags=["Users"],
    summary="Delete user",
    errors={404: "User not found"}
)
def delete_user(req: func.HttpRequest) -> func.HttpResponse:
    """
    Delete a user from the system.
    This operation cannot be undone.
    """
    user_id = req.route_params.get('id')
    
    if user_id not in USERS_DB:
        response = ApiResponse.fail("User not found")
        return func.HttpResponse(
            response.model_dump_json(),
            mimetype="application/json",
            status_code=404
        )
    
    del USERS_DB[user_id]
    
    return func.HttpResponse(
        status_code=204
    )


@app.route(route="users/{id}/profile", methods=["GET"])
@openapi(
    response=UserProfile,
    tags=["Users"],
    summary="Get user profile with nested data",
    errors={404: "User not found"}
)
def get_user_profile(req: func.HttpRequest) -> func.HttpResponse:
    """
    Retrieve a user's complete profile including nested address and preferences.
    Demonstrates nested Pydantic models in OpenAPI spec.
    """
    user_id = req.route_params.get('id')
    
    if user_id not in USERS_DB:
        return ApiResponse.fail("User not found", status_code=404)
    
    user = User(**USERS_DB[user_id])
    
    # Mock address and preferences
    profile = UserProfile(
        user=user,
        address=Address(
            street="123 Main St",
            city="San Francisco",
            state="CA",
            zip_code="94102",
            country="US"
        ),
        preferences={
            "theme": "dark",
            "notifications": True,
            "language": "en"
        },
        is_active=True
    )
    
    return ApiResponse.ok(profile)


@app.route(route="openapi.json", methods=["GET"])
def openapi_spec(req: func.HttpRequest) -> func.HttpResponse:
    """
    Generate and return OpenAPI 3.0 specification.
    Visit this endpoint to see the complete API documentation in JSON format.
    """
    spec = generate_openapi_spec(
        title="Example User Management API",
        version="1.0.0",
        servers=[
            {"url": "http://localhost:7071/api", "description": "Local development"},
            {"url": "https://your-app.azurewebsites.net/api", "description": "Production"}
        ]
    )
    
    return func.HttpResponse(
        json.dumps(spec, indent=2),
        mimetype="application/json"
    )


@app.route(route="docs", methods=["GET"])
def swagger_ui(req: func.HttpRequest) -> func.HttpResponse:
    """Serve Swagger UI for interactive API documentation"""
    return generate_swagger_ui(title="Example User Management API")


@app.route(route="health", methods=["GET"])
def health_check(req: func.HttpRequest) -> func.HttpResponse:
    """Simple health check endpoint"""
    return func.HttpResponse(
        json.dumps({"status": "healthy", "timestamp": datetime.now(timezone.utc).isoformat()}),
        mimetype="application/json"
    )

