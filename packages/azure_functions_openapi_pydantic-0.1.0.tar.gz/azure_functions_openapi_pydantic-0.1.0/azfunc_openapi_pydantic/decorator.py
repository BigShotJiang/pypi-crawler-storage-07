"""
OpenAPI decorator with Pydantic support for Azure Functions
"""
import functools
import json
import inspect
from typing import Dict, List, Optional, Any, Callable, Type, TypeVar, Generic
import azure.functions as func

try:
    from pydantic import BaseModel, Field
    PYDANTIC_AVAILABLE = True
except ImportError:
    BaseModel = None
    Field = None
    PYDANTIC_AVAILABLE = False

# Global registry for OpenAPI metadata
OPENAPI_REGISTRY: Dict[str, Dict[str, Any]] = {}

T = TypeVar('T')


class ApiResponse:
    """
    Standardized API response envelope.
    Returns func.HttpResponse directly with consistent {success, data, error} format.
    """
    
    @staticmethod
    def ok(data: Any, status_code: int = 200) -> func.HttpResponse:
        """
        Create success response.
        Accepts either a Pydantic model, dict, list, or primitive.
        Returns func.HttpResponse with JSON body.
        """
        # Auto-serialize Pydantic models
        if PYDANTIC_AVAILABLE and isinstance(data, BaseModel):
            data = data.model_dump()
        
        response_body = {
            "success": True,
            "data": data,
            "error": None
        }
        
        return func.HttpResponse(
            json.dumps(response_body),
            mimetype="application/json",
            status_code=status_code
        )
    
    @staticmethod
    def fail(error: str, status_code: int = 400) -> func.HttpResponse:
        """
        Create error response.
        Returns func.HttpResponse with JSON body.
        """
        response_body = {
            "success": False,
            "data": None,
            "error": error
        }
        
        return func.HttpResponse(
            json.dumps(response_body),
            mimetype="application/json",
            status_code=status_code
        )


def is_pydantic_model(obj: Any) -> bool:
    """Check if object is a Pydantic model"""
    return PYDANTIC_AVAILABLE and isinstance(obj, type) and issubclass(obj, BaseModel)


def _resolve_refs(schema: Dict[str, Any]) -> Dict[str, Any]:
    """Recursively resolve $ref references to inline nested models"""
    definitions = schema.get('$defs', {})
    
    def resolve(obj: Any) -> Any:
        if isinstance(obj, dict):
            if '$ref' in obj:
                # Extract ref name and inline the definition
                ref_name = obj['$ref'].split('/')[-1]
                if ref_name in definitions:
                    # Recursively resolve the referenced definition
                    return resolve(definitions[ref_name])
                return obj
            else:
                # Recursively resolve all dict values
                return {k: resolve(v) for k, v in obj.items() if k != '$defs'}
        elif isinstance(obj, list):
            return [resolve(item) for item in obj]
        else:
            return obj
    
    resolved = resolve(schema)
    # Remove $defs since everything is inlined
    if '$defs' in resolved:
        del resolved['$defs']
    return resolved


def openapi(
    request: Optional[Type[BaseModel]] = None,
    response: Optional[Type[BaseModel]] = None,
    *,
    params: Optional[Dict[str, Any]] = None,
    tags: Optional[List[str]] = None,
    summary: Optional[str] = None,
    errors: Optional[Dict[int, str]] = None,
):
    """
    OpenAPI decorator for Azure Functions with Pydantic models
    
    Args:
        request: Pydantic model for request body (POST/PUT)
        response: Pydantic model for response data (required)
        params: Query/path parameters {name: type}
        tags: OpenAPI tags
        summary: Custom summary (uses docstring by default)
        errors: Custom error responses {code: description}
    
    Usage:
        @openapi(request=CreateUserRequest, response=User)
        def create_user(body: CreateUserRequest) -> func.HttpResponse:
            ...
    """
    body = request
    def decorator(func_: Callable) -> Callable:
        func_name = getattr(func_, '__name__', str(id(func_)))
        doc = (func_.__doc__ or "").strip().split('\n')[0]
        
        # Convert Pydantic model to OpenAPI schema if provided
        body_schema = None
        if body and is_pydantic_model(body):
            schema = body.model_json_schema(mode='serialization', ref_template='{model}')
            body_schema = _resolve_refs(schema)
        
        # Get response model schema
        response_schema = None
        if response and is_pydantic_model(response):
            schema = response.model_json_schema(mode='serialization', ref_template='{model}')
            response_schema = _resolve_refs(schema)
        
        OPENAPI_REGISTRY[func_name] = {
            "summary": summary or doc or func_name,
            "tags": tags or [],
            "params": params or {},
            "body": body,
            "body_schema": body_schema,
            "response_model": response,
            "response_schema": response_schema,
            "custom_responses": errors or {},
        }
        
        # Inspect the function signature to determine calling convention
        sig = inspect.signature(func_)
        func_params = list(sig.parameters.keys())
        
        # Determine if function expects req or individual parameters
        expects_req = len(func_params) > 0 and func_params[0] in ('req', 'request')
        
        @functools.wraps(func_, updated=[])  # Don't update __wrapped__ to hide original signature
        def wrapper(req: func.HttpRequest) -> func.HttpResponse:
            kwargs = {}
            validated_body = None
            
            # Parse and validate body with Pydantic if request model is provided
            if body and is_pydantic_model(body):
                try:
                    body_data = req.get_json()
                    validated_body = body(**body_data)
                except Exception as e:
                    return ApiResponse.fail(f"Validation error: {str(e)}", status_code=400)
            
            # Parse query parameters
            parsed_params = {}
            if params:
                for param_name, param_type in params.items():
                    value = req.params.get(param_name)
                    if value:
                        if param_type == int:
                            parsed_params[param_name] = int(value)
                        elif param_type == bool:
                            parsed_params[param_name] = value.lower() in ('true', '1', 'yes')
                        else:
                            parsed_params[param_name] = value
            
            # Call function based on its signature
            if expects_req:
                # Function expects (req: HttpRequest) - attach data to req object
                req.validated_body = validated_body
                req.parsed_params = parsed_params
                return func_(req)
            else:
                # Function expects individual parameters - inject them
                if validated_body and 'body' in func_params:
                    kwargs['body'] = validated_body
                
                # Add query/path parameters
                for param_name in func_params:
                    if param_name in parsed_params:
                        kwargs[param_name] = parsed_params[param_name]
                    elif param_name in sig.parameters:
                        # Use default value if available
                        param = sig.parameters[param_name]
                        if param.default != inspect.Parameter.empty:
                            kwargs[param_name] = param.default
                
                return func_(**kwargs)
        
        # Explicitly set the wrapper's signature to prevent Azure Functions from seeing the original
        wrapper.__signature__ = inspect.Signature([
            inspect.Parameter('req', inspect.Parameter.POSITIONAL_OR_KEYWORD, 
                            annotation=func.HttpRequest)
        ], return_annotation=func.HttpResponse)
        
        return wrapper
    
    return decorator


class OpenAPIBlueprint(func.Blueprint):
    """Azure Functions Blueprint with OpenAPI support"""
    
    def route(self, route: str, methods: List[str] = None, **kwargs):
        def decorator(func_: Callable):
            func_name = getattr(func_, '__name__', str(id(func_)))
            method = methods[0] if methods else "GET"
            
            if func_name in OPENAPI_REGISTRY:
                OPENAPI_REGISTRY[func_name]["path"] = route
                OPENAPI_REGISTRY[func_name]["method"] = method
            
            return super(OpenAPIBlueprint, self).route(route, methods=methods, **kwargs)(func_)
        
        return decorator

