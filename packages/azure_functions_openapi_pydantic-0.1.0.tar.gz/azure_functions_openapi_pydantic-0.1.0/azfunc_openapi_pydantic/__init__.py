"""
Azure Functions OpenAPI with Pydantic
A lightweight OpenAPI decorator for Azure Functions with Pydantic support
"""
from .decorator import openapi, ApiResponse, OpenAPIBlueprint
from .spec import generate_openapi_spec, generate_swagger_ui

__version__ = "0.1.0"
__all__ = ["openapi", "ApiResponse", "OpenAPIBlueprint", "generate_openapi_spec", "generate_swagger_ui"]

