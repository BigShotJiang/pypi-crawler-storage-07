"""
OpenAPI specification generation
"""
from typing import Dict, Any, Optional
import azure.functions as func
from .decorator import OPENAPI_REGISTRY


def _build_responses(method: str, metadata: Dict[str, Any]) -> Dict[int, Dict[str, Any]]:
    """Build accurate responses using ApiResponse envelope"""
    responses = {}
    has_body = metadata.get("body_schema") is not None
    custom = metadata.get("custom_responses", {})
    response_schema = metadata.get("response_schema")
    
    # Build success envelope schema
    success_envelope = {
        "type": "object",
        "properties": {
            "success": {"type": "boolean", "example": True},
            "data": response_schema or {"type": "object"},
            "error": {"type": "string", "nullable": True, "example": None}
        },
        "required": ["success", "data"]
    }
    
    # Build error envelope schema
    error_envelope = {
        "type": "object",
        "properties": {
            "success": {"type": "boolean", "example": False},
            "data": {"type": "object", "nullable": True, "example": None},
            "error": {"type": "string", "example": "Error message"}
        },
        "required": ["success", "error"]
    }
    
    # Success response
    if method == "post" and has_body:
        responses[201] = {
            "description": custom.get(201) or "Created",
            "content": {"application/json": {"schema": success_envelope}}
        }
    elif method == "delete":
        responses[204] = {"description": custom.get(204) or "Deleted"}
    else:
        responses[200] = {
            "description": custom.get(200) or "Success",
            "content": {"application/json": {"schema": success_envelope}}
        }
    
    # Error responses (all use error envelope)
    responses[500] = {
        "description": custom.get(500) or "Internal server error",
        "content": {"application/json": {"schema": error_envelope}}
    }
    
    if has_body or metadata.get("params"):
        responses[400] = {
            "description": custom.get(400) or "Validation error",
            "content": {"application/json": {"schema": error_envelope}}
        }
    
    if metadata.get("params") and any("{" in str(metadata.get("path", "")) for _ in [1]):
        responses[404] = {
            "description": custom.get(404) or "Not found",
            "content": {"application/json": {"schema": error_envelope}}
        }
    
    # Custom responses
    for code, desc in custom.items():
        if code not in responses:
            is_success = 200 <= code < 300
            schema = success_envelope if is_success else error_envelope
            responses[code] = {
                "description": desc,
                "content": {"application/json": {"schema": schema}}
            }
    
    return responses


def generate_openapi_spec(
    title: str = "API",
    version: str = "1.0.0",
    servers: list = None
) -> Dict[str, Any]:
    """
    Generate OpenAPI 3.0 specification from decorated functions
    
    Args:
        title: API title
        version: API version
        servers: List of server URLs (default: [{"url": "/api"}])
    
    Returns:
        OpenAPI spec dictionary
    """
    spec = {
        "openapi": "3.0.0",
        "info": {"title": title, "version": version},
        "servers": servers or [{"url": "/api"}],
        "paths": {}
    }
    
    for func_name, metadata in OPENAPI_REGISTRY.items():
        path = metadata.get('path', f"/{func_name}")
        if not path.startswith('/'):
            path = '/' + path
        method = metadata.get('method', 'get').lower()
        
        if path not in spec["paths"]:
            spec["paths"][path] = {}
        
        # Build responses
        responses = _build_responses(method, metadata)
        
        operation = {
            "summary": metadata["summary"],
            "tags": metadata.get("tags", []),
            "responses": responses
        }
        
        # Add query parameters
        if metadata.get("params"):
            operation["parameters"] = [
                {
                    "name": name,
                    "in": "query",
                    "schema": {"type": ptype.__name__ if hasattr(ptype, '__name__') else "string"}
                }
                for name, ptype in metadata["params"].items()
            ]
        
        # Add request body
        if metadata.get("body_schema"):
            operation["requestBody"] = {
                "required": True,
                "content": {
                    "application/json": {
                        "schema": metadata["body_schema"]
                    }
                }
            }
        
        spec["paths"][path][method] = operation
    
    return spec


def generate_swagger_ui(
    openapi_url: str = "/api/openapi.json",
    title: str = "API Documentation",
    favicon: Optional[str] = None
) -> func.HttpResponse:
    """
    Generate Swagger UI HTML page for interactive API documentation.
    
    Args:
        openapi_url: URL to the OpenAPI JSON spec (default: "/api/openapi.json")
        title: Page title (default: "API Documentation")
        favicon: Optional favicon URL
    
    Returns:
        HttpResponse with Swagger UI HTML
    
    Example:
        @app.route(route="docs", methods=["GET"])
        def swagger_ui(req: func.HttpRequest) -> func.HttpResponse:
            return generate_swagger_ui()
    """
    favicon_tag = f'<link rel="icon" type="image/png" href="{favicon}">' if favicon else ''
    
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui.css">
    {favicon_tag}
    <style>
        body {{
            margin: 0;
            padding: 0;
        }}
    </style>
</head>
<body>
    <div id="swagger-ui"></div>
    <script src="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui-bundle.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui-standalone-preset.js"></script>
    <script>
        window.onload = function() {{
            window.ui = SwaggerUIBundle({{
                url: '{openapi_url}',
                dom_id: '#swagger-ui',
                deepLinking: true,
                presets: [
                    SwaggerUIBundle.presets.apis,
                    SwaggerUIStandalonePreset
                ],
                plugins: [
                    SwaggerUIBundle.plugins.DownloadUrl
                ],
                layout: "BaseLayout",
                displayRequestDuration: true,
                filter: true,
                tryItOutEnabled: true
            }});
        }};
    </script>
</body>
</html>"""
    
    return func.HttpResponse(html, mimetype="text/html")

