import pytest
from pydantic import BaseModel, Field
import azure.functions as func
from unittest.mock import Mock

from azfunc_openapi_pydantic.decorator import openapi, OpenAPIBlueprint, OPENAPI_REGISTRY
from azfunc_openapi_pydantic.spec import generate_openapi_spec


class Product(BaseModel):
    id: str
    name: str
    price: float = Field(..., gt=0)


class CreateProductRequest(BaseModel):
    name: str
    price: float


class OrderItem(BaseModel):
    product_id: str
    quantity: int = Field(..., gt=0)


class Order(BaseModel):
    id: str
    items: list[OrderItem]
    total: float


class TestOpenAPISpecGeneration:
    def test_basic_spec_structure(self):
        @openapi(response=Product)
        def get_product(req: func.HttpRequest) -> func.HttpResponse:
            """Get product details"""
            return Mock()
        
        spec = generate_openapi_spec(title="Store API", version="1.0.0")
        
        assert spec["openapi"] == "3.0.0"
        assert spec["info"]["title"] == "Store API"
        assert spec["info"]["version"] == "1.0.0"
        assert "paths" in spec

    def test_spec_includes_registered_endpoints(self):
        @openapi(response=Product)
        def get_product(req: func.HttpRequest) -> func.HttpResponse:
            """Get product"""
            return Mock()
        
        OPENAPI_REGISTRY["get_product"]["path"] = "products/{id}"
        OPENAPI_REGISTRY["get_product"]["method"] = "GET"
        
        spec = generate_openapi_spec()
        
        assert "/products/{id}" in spec["paths"]
        assert "get" in spec["paths"]["/products/{id}"]

    def test_post_endpoint_generates_201_response(self):
        blueprint = OpenAPIBlueprint()
        
        @blueprint.route(route="products", methods=["POST"])
        @openapi(request=CreateProductRequest, response=Product)
        def create_product(body: CreateProductRequest) -> func.HttpResponse:
            """Create product"""
            return Mock()
        
        spec = generate_openapi_spec()
        
        operation = spec["paths"]["/products"]["post"]
        assert 201 in operation["responses"]
        assert operation["responses"][201]["description"] == "Created"

    def test_delete_endpoint_generates_204_response(self):
        blueprint = OpenAPIBlueprint()
        
        @blueprint.route(route="products/{id}", methods=["DELETE"])
        @openapi(response=Product)
        def delete_product(req: func.HttpRequest) -> func.HttpResponse:
            """Delete product"""
            return Mock()
        
        spec = generate_openapi_spec()
        
        operation = spec["paths"]["/products/{id}"]["delete"]
        assert 204 in operation["responses"]
        assert operation["responses"][204]["description"] == "Deleted"

    def test_get_endpoint_generates_200_response(self):
        blueprint = OpenAPIBlueprint()
        
        @blueprint.route(route="products/{id}", methods=["GET"])
        @openapi(response=Product)
        def get_product(req: func.HttpRequest) -> func.HttpResponse:
            """Get product"""
            return Mock()
        
        spec = generate_openapi_spec()
        
        operation = spec["paths"]["/products/{id}"]["get"]
        assert 200 in operation["responses"]
        assert operation["responses"][200]["description"] == "Success"

    def test_request_body_schema_included(self):
        blueprint = OpenAPIBlueprint()
        
        @blueprint.route(route="products", methods=["POST"])
        @openapi(request=CreateProductRequest, response=Product)
        def create_product(body: CreateProductRequest) -> func.HttpResponse:
            return Mock()
        
        spec = generate_openapi_spec()
        
        operation = spec["paths"]["/products"]["post"]
        assert "requestBody" in operation
        assert operation["requestBody"]["required"] is True
        assert "application/json" in operation["requestBody"]["content"]
        schema = operation["requestBody"]["content"]["application/json"]["schema"]
        assert "properties" in schema
        assert "name" in schema["properties"]
        assert "price" in schema["properties"]

    def test_response_schema_in_success_envelope(self):
        blueprint = OpenAPIBlueprint()
        
        @blueprint.route(route="products/{id}", methods=["GET"])
        @openapi(response=Product)
        def get_product(req: func.HttpRequest) -> func.HttpResponse:
            return Mock()
        
        spec = generate_openapi_spec()
        
        operation = spec["paths"]["/products/{id}"]["get"]
        response_schema = operation["responses"][200]["content"]["application/json"]["schema"]
        
        assert response_schema["properties"]["success"]["type"] == "boolean"
        assert response_schema["properties"]["success"]["example"] is True
        assert "data" in response_schema["properties"]
        assert "error" in response_schema["properties"]

    def test_query_parameters_included(self):
        blueprint = OpenAPIBlueprint()
        
        @blueprint.route(route="products", methods=["GET"])
        @openapi(
            response=Product,
            params={"limit": int, "offset": int, "search": str}
        )
        def list_products(req: func.HttpRequest) -> func.HttpResponse:
            return Mock()
        
        spec = generate_openapi_spec()
        
        operation = spec["paths"]["/products"]["get"]
        assert "parameters" in operation
        param_names = [p["name"] for p in operation["parameters"]]
        assert "limit" in param_names
        assert "offset" in param_names
        assert "search" in param_names

    def test_tags_included_in_operation(self):
        blueprint = OpenAPIBlueprint()
        
        @blueprint.route(route="products", methods=["GET"])
        @openapi(response=Product, tags=["Products", "Catalog"])
        def list_products(req: func.HttpRequest) -> func.HttpResponse:
            return Mock()
        
        spec = generate_openapi_spec()
        
        operation = spec["paths"]["/products"]["get"]
        assert operation["tags"] == ["Products", "Catalog"]

    def test_custom_summary_in_operation(self):
        blueprint = OpenAPIBlueprint()
        
        @blueprint.route(route="products", methods=["GET"])
        @openapi(response=Product, summary="List all available products")
        def list_products(req: func.HttpRequest) -> func.HttpResponse:
            """This should be overridden"""
            return Mock()
        
        spec = generate_openapi_spec()
        
        operation = spec["paths"]["/products"]["get"]
        assert operation["summary"] == "List all available products"

    def test_error_responses_included(self):
        blueprint = OpenAPIBlueprint()
        
        @blueprint.route(route="products", methods=["POST"])
        @openapi(
            request=CreateProductRequest,
            response=Product,
            errors={409: "Product already exists"}
        )
        def create_product(body: CreateProductRequest) -> func.HttpResponse:
            return Mock()
        
        spec = generate_openapi_spec()
        
        operation = spec["paths"]["/products"]["post"]
        assert 409 in operation["responses"]
        assert operation["responses"][409]["description"] == "Product already exists"

    def test_validation_error_response_when_body_present(self):
        blueprint = OpenAPIBlueprint()
        
        @blueprint.route(route="products", methods=["POST"])
        @openapi(request=CreateProductRequest, response=Product)
        def create_product(body: CreateProductRequest) -> func.HttpResponse:
            return Mock()
        
        spec = generate_openapi_spec()
        
        operation = spec["paths"]["/products"]["post"]
        assert 400 in operation["responses"]
        assert operation["responses"][400]["description"] == "Validation error"

    def test_nested_models_expanded_in_spec(self):
        blueprint = OpenAPIBlueprint()
        
        @blueprint.route(route="orders/{id}", methods=["GET"])
        @openapi(response=Order)
        def get_order(req: func.HttpRequest) -> func.HttpResponse:
            return Mock()
        
        spec = generate_openapi_spec()
        
        operation = spec["paths"]["/orders/{id}"]["get"]
        data_schema = operation["responses"][200]["content"]["application/json"]["schema"]["properties"]["data"]
        
        assert "properties" in data_schema
        assert "items" in data_schema["properties"]
        items_schema = data_schema["properties"]["items"]
        assert items_schema["type"] == "array"

    def test_custom_server_urls(self):
        @openapi(response=Product)
        def get_product(req: func.HttpRequest) -> func.HttpResponse:
            return Mock()
        
        servers = [
            {"url": "https://api.example.com"},
            {"url": "https://staging.example.com"}
        ]
        spec = generate_openapi_spec(servers=servers)
        
        assert spec["servers"] == servers

    def test_default_server_url(self):
        @openapi(response=Product)
        def get_product(req: func.HttpRequest) -> func.HttpResponse:
            return Mock()
        
        spec = generate_openapi_spec()
        
        assert spec["servers"] == [{"url": "/api"}]


class TestCompleteAPISpecification:
    def test_full_ecommerce_api_spec(self):
        blueprint = OpenAPIBlueprint()
        
        @blueprint.route(route="products", methods=["GET"])
        @openapi(
            response=Product,
            params={"limit": int, "category": str},
            tags=["Products"]
        )
        def list_products(req: func.HttpRequest) -> func.HttpResponse:
            """List all products"""
            return Mock()
        
        @blueprint.route(route="products", methods=["POST"])
        @openapi(
            request=CreateProductRequest,
            response=Product,
            tags=["Products"],
            errors={409: "Product already exists"}
        )
        def create_product(body: CreateProductRequest) -> func.HttpResponse:
            """Create new product"""
            return Mock()
        
        @blueprint.route(route="products/{id}", methods=["GET"])
        @openapi(
            response=Product,
            tags=["Products"],
            errors={404: "Product not found"}
        )
        def get_product(req: func.HttpRequest) -> func.HttpResponse:
            """Get product by ID"""
            return Mock()
        
        @blueprint.route(route="orders/{id}", methods=["GET"])
        @openapi(
            response=Order,
            tags=["Orders"],
            errors={404: "Order not found"}
        )
        def get_order(req: func.HttpRequest) -> func.HttpResponse:
            """Get order by ID"""
            return Mock()
        
        spec = generate_openapi_spec(
            title="E-Commerce API",
            version="2.0.0"
        )
        
        assert spec["info"]["title"] == "E-Commerce API"
        assert spec["info"]["version"] == "2.0.0"
        assert len(spec["paths"]) == 3
        assert "/products" in spec["paths"]
        assert "/products/{id}" in spec["paths"]
        assert "/orders/{id}" in spec["paths"]
        
        products_path = spec["paths"]["/products"]
        assert "get" in products_path
        assert "post" in products_path
        
        get_products = products_path["get"]
        assert get_products["tags"] == ["Products"]
        assert "parameters" in get_products
        
        create_product = products_path["post"]
        assert 201 in create_product["responses"]
        assert 409 in create_product["responses"]
        assert "requestBody" in create_product

