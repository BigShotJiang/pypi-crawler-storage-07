import pytest
from azfunc_openapi_pydantic.decorator import OPENAPI_REGISTRY


@pytest.fixture(autouse=True)
def clear_registry():
    OPENAPI_REGISTRY.clear()
    yield
    OPENAPI_REGISTRY.clear()

