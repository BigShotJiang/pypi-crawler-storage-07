import json
import pytest
from unittest.mock import Mock
from pydantic import BaseModel, Field, EmailStr
import azure.functions as func

from azfunc_openapi_pydantic.decorator import openapi, ApiResponse, OpenAPIBlueprint, OPENAPI_REGISTRY


class UserCreateRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    email: EmailStr
    age: int = Field(..., ge=18)


class User(BaseModel):
    id: str
    name: str
    email: EmailStr
    age: int


class Address(BaseModel):
    street: str
    city: str
    country: str = "US"


class UserProfile(BaseModel):
    user: User
    address: Address


class TestApiResponse:
    def test_success_response_creates_valid_envelope(self):
        data = {"id": "123", "name": "John"}
        
        response = ApiResponse.ok(data)
        
        assert response.status_code == 200
        body = json.loads(response.get_body())
        assert body["success"] is True
        assert body["data"] == data
        assert body["error"] is None

    def test_error_response_creates_valid_envelope(self):
        error_message = "User not found"
        
        response = ApiResponse.fail(error_message, status_code=404)
        
        assert response.status_code == 404
        body = json.loads(response.get_body())
        assert body["success"] is False
        assert body["data"] is None
        assert body["error"] == error_message

    def test_response_with_custom_status_code(self):
        data = {"id": "123", "name": "John"}
        
        response = ApiResponse.ok(data, status_code=201)
        
        assert response.status_code == 201
        body = json.loads(response.get_body())
        assert body["success"] is True
        assert body["data"] == data


class TestOpenAPIDecorator:
    def test_decorator_registers_function_metadata(self):
        @openapi(response=User)
        def get_user(req: func.HttpRequest) -> func.HttpResponse:
            """Get user by ID"""
            return Mock()
        
        assert "get_user" in OPENAPI_REGISTRY
        metadata = OPENAPI_REGISTRY["get_user"]
        assert metadata["summary"] == "Get user by ID"
        assert metadata["response_model"] == User

    def test_decorator_with_request_and_response_models(self):
        @openapi(request=UserCreateRequest, response=User)
        def create_user(body: UserCreateRequest) -> func.HttpResponse:
            """Create new user"""
            return Mock()
        
        metadata = OPENAPI_REGISTRY["create_user"]
        assert metadata["body"] == UserCreateRequest
        assert metadata["response_model"] == User
        assert metadata["body_schema"] is not None
        assert metadata["response_schema"] is not None

    def test_decorator_with_query_parameters(self):
        params = {"limit": int, "offset": int, "active": bool}
        
        @openapi(response=User, params=params)
        def list_users(req: func.HttpRequest) -> func.HttpResponse:
            return Mock()
        
        metadata = OPENAPI_REGISTRY["list_users"]
        assert metadata["params"] == params

    def test_decorator_with_custom_tags_and_summary(self):
        @openapi(
            response=User,
            tags=["Users", "Admin"],
            summary="Custom summary text"
        )
        def admin_get_user(req: func.HttpRequest) -> func.HttpResponse:
            """This docstring should be overridden"""
            return Mock()
        
        metadata = OPENAPI_REGISTRY["admin_get_user"]
        assert metadata["tags"] == ["Users", "Admin"]
        assert metadata["summary"] == "Custom summary text"

    def test_decorator_with_custom_error_responses(self):
        errors = {404: "User not found", 403: "Forbidden"}
        
        @openapi(response=User, errors=errors)
        def get_user(req: func.HttpRequest) -> func.HttpResponse:
            return Mock()
        
        metadata = OPENAPI_REGISTRY["get_user"]
        assert metadata["custom_responses"] == errors


class TestRequestValidation:
    def test_valid_request_body_passes_validation(self):
        @openapi(request=UserCreateRequest, response=User)
        def create_user(req: func.HttpRequest) -> func.HttpResponse:
            body = req.validated_body
            return ApiResponse.ok(body, status_code=201)
        
        request = Mock(spec=func.HttpRequest)
        request.get_json.return_value = {
            "name": "John Doe",
            "email": "john@example.com",
            "age": 25
        }
        
        response = create_user(request)
        
        assert response.status_code == 201
        body = json.loads(response.get_body())
        assert body["success"] is True
        assert body["data"]["name"] == "John Doe"

    def test_valid_request_body_with_parameter_injection(self):
        @openapi(request=UserCreateRequest, response=User)
        def create_user(body: UserCreateRequest) -> func.HttpResponse:
            return ApiResponse.ok(body, status_code=201)
        
        request = Mock(spec=func.HttpRequest)
        request.get_json.return_value = {
            "name": "Jane Smith",
            "email": "jane@example.com",
            "age": 30
        }
        
        response = create_user(request)
        
        assert response.status_code == 201
        body = json.loads(response.get_body())
        assert body["success"] is True
        assert body["data"]["name"] == "Jane Smith"
        assert body["data"]["age"] == 30

    def test_invalid_request_body_returns_validation_error(self):
        @openapi(request=UserCreateRequest, response=User)
        def create_user(req: func.HttpRequest) -> func.HttpResponse:
            return Mock()
        
        request = Mock(spec=func.HttpRequest)
        request.get_json.return_value = {
            "name": "John",
            "email": "invalid-email",
            "age": 17
        }
        
        response = create_user(request)
        
        assert response.status_code == 400
        body = json.loads(response.get_body())
        assert body["success"] is False
        assert "Validation error" in body["error"]

    def test_missing_required_fields_returns_validation_error(self):
        @openapi(request=UserCreateRequest, response=User)
        def create_user(req: func.HttpRequest) -> func.HttpResponse:
            return Mock()
        
        request = Mock(spec=func.HttpRequest)
        request.get_json.return_value = {"name": "John"}
        
        response = create_user(request)
        
        assert response.status_code == 400
        body = json.loads(response.get_body())
        assert body["success"] is False


class TestQueryParameters:
    def test_integer_query_params_converted_correctly(self):
        @openapi(response=User, params={"limit": int, "offset": int})
        def list_users(req: func.HttpRequest) -> func.HttpResponse:
            params = req.parsed_params
            assert params["limit"] == 10
            assert params["offset"] == 20
            assert isinstance(params["limit"], int)
            return func.HttpResponse("", status_code=200)
        
        request = Mock(spec=func.HttpRequest)
        request.params = {"limit": "10", "offset": "20"}
        
        list_users(request)

    def test_boolean_query_params_converted_correctly(self):
        @openapi(response=User, params={"active": bool})
        def list_users(req: func.HttpRequest) -> func.HttpResponse:
            params = req.parsed_params
            assert params["active"] is True
            return func.HttpResponse("", status_code=200)
        
        request = Mock(spec=func.HttpRequest)
        request.params = {"active": "true"}
        
        list_users(request)

    def test_missing_query_params_not_passed_to_function(self):
        @openapi(response=User, params={"filter": str})
        def list_users(req: func.HttpRequest) -> func.HttpResponse:
            params = getattr(req, 'parsed_params', {})
            assert "filter" not in params
            return func.HttpResponse("", status_code=200)
        
        request = Mock(spec=func.HttpRequest)
        request.params = {}
        
        list_users(request)


class TestNestedModels:
    def test_nested_models_resolved_in_schema(self):
        @openapi(response=UserProfile)
        def get_profile(req: func.HttpRequest) -> func.HttpResponse:
            return Mock()
        
        metadata = OPENAPI_REGISTRY["get_profile"]
        schema = metadata["response_schema"]
        
        assert "$ref" not in json.dumps(schema)
        assert "properties" in schema
        assert "user" in schema["properties"]
        assert "address" in schema["properties"]

    def test_deeply_nested_models_fully_expanded(self):
        @openapi(response=UserProfile)
        def get_profile(req: func.HttpRequest) -> func.HttpResponse:
            return Mock()
        
        metadata = OPENAPI_REGISTRY["get_profile"]
        schema = metadata["response_schema"]
        
        user_schema = schema["properties"]["user"]
        assert "properties" in user_schema
        assert "id" in user_schema["properties"]
        assert "name" in user_schema["properties"]


class TestOpenAPIBlueprint:
    def test_blueprint_registers_route_information(self):
        blueprint = OpenAPIBlueprint()
        
        @blueprint.route(route="users", methods=["POST"])
        @openapi(request=UserCreateRequest, response=User)
        def create_user(body: UserCreateRequest) -> func.HttpResponse:
            """Create user endpoint"""
            return Mock()
        
        metadata = OPENAPI_REGISTRY["create_user"]
        assert metadata["path"] == "users"
        assert metadata["method"] == "POST"

    def test_blueprint_registers_get_route_by_default(self):
        blueprint = OpenAPIBlueprint()
        
        @blueprint.route(route="users/{id}")
        @openapi(response=User)
        def get_user(req: func.HttpRequest) -> func.HttpResponse:
            return Mock()
        
        metadata = OPENAPI_REGISTRY["get_user"]
        assert metadata["method"] == "GET"

    def test_blueprint_with_multiple_routes(self):
        blueprint = OpenAPIBlueprint()
        
        @blueprint.route(route="users", methods=["POST"])
        @openapi(request=UserCreateRequest, response=User)
        def create_user(body: UserCreateRequest) -> func.HttpResponse:
            return Mock()
        
        @blueprint.route(route="users/{id}", methods=["GET"])
        @openapi(response=User)
        def get_user(req: func.HttpRequest) -> func.HttpResponse:
            return Mock()
        
        assert "create_user" in OPENAPI_REGISTRY
        assert "get_user" in OPENAPI_REGISTRY
        assert OPENAPI_REGISTRY["create_user"]["path"] == "users"
        assert OPENAPI_REGISTRY["get_user"]["path"] == "users/{id}"


class TestRealWorldScenarios:
    def test_complete_user_api_flow(self):
        blueprint = OpenAPIBlueprint()
        
        @blueprint.route(route="users", methods=["POST"])
        @openapi(
            request=UserCreateRequest,
            response=User,
            tags=["Users"],
            summary="Create a new user"
        )
        def create_user(req: func.HttpRequest) -> func.HttpResponse:
            """Create user endpoint"""
            body = req.validated_body
            user = User(
                id="usr_123",
                name=body.name,
                email=body.email,
                age=body.age
            )
            return ApiResponse.ok(user, status_code=201)
        
        request = Mock(spec=func.HttpRequest)
        request.get_json.return_value = {
            "name": "Jane Doe",
            "email": "jane@example.com",
            "age": 30
        }
        
        response = create_user(request)
        
        assert response.status_code == 201
        body = json.loads(response.get_body())
        assert body["success"] is True
        assert body["data"]["id"] == "usr_123"
        assert body["data"]["name"] == "Jane Doe"
        
        metadata = OPENAPI_REGISTRY["create_user"]
        assert metadata["path"] == "users"
        assert metadata["method"] == "POST"
        assert metadata["tags"] == ["Users"]

    def test_list_endpoint_with_pagination(self):
        @openapi(
            response=User,
            params={"limit": int, "offset": int, "search": str}
        )
        def list_users(req: func.HttpRequest) -> func.HttpResponse:
            params = getattr(req, 'parsed_params', {})
            limit = params.get('limit', 10)
            offset = params.get('offset', 0)
            search = params.get('search', '')
            
            users = [
                User(id="1", name="John", email="john@example.com", age=25),
                User(id="2", name="Jane", email="jane@example.com", age=30)
            ]
            return ApiResponse.ok([u.model_dump() for u in users])
        
        request = Mock(spec=func.HttpRequest)
        request.params = {"limit": "20", "offset": "10"}
        
        response = list_users(request)
        
        assert response.status_code == 200
        body = json.loads(response.get_body())
        assert body["success"] is True
        assert len(body["data"]) == 2

    def test_error_handling_in_endpoint(self):
        @openapi(
            response=User,
            errors={404: "User not found", 403: "Access denied"}
        )
        def get_user(req: func.HttpRequest) -> func.HttpResponse:
            """Get user by ID"""
            return ApiResponse.fail("User not found", status_code=404)
        
        request = Mock(spec=func.HttpRequest)
        request.params = {}
        
        response = get_user(request)
        
        assert response.status_code == 404
        body = json.loads(response.get_body())
        assert body["success"] is False
        assert body["error"] == "User not found"
        assert body["data"] is None

