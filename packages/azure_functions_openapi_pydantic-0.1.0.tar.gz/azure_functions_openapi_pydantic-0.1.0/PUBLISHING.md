# Publishing Guide

## Package Name Resolution

**Important:** The module name is `azfunc_openapi_pydantic` (not `azure_functions_openapi`) to avoid conflicts with an existing PyPI package.

**Install:**
```bash
pip install azure-functions-openapi-pydantic
```

**Import:**
```python
from azfunc_openapi_pydantic import openapi, ApiResponse, generate_openapi_spec
```

## Pre-Publishing Checklist

- ✅ Package metadata configured (pyproject.toml)
- ✅ License and copyright set (NodeHarbor, 2025)
- ✅ All URLs point to GitHub repo
- ✅ Unit tests passing (38 tests, 94% coverage)
- ✅ Example application created
- ✅ README updated with usage instructions
- ✅ No naming conflicts with existing packages

## Build and Test

### Run Tests
```bash
pytest
```

### Build Package
```bash
python -m build
```

This creates:
- `dist/azure_functions_openapi_pydantic-0.1.0.tar.gz`
- `dist/azure_functions_openapi_pydantic-0.1.0-py3-none-any.whl`

### Test Installation Locally
```bash
pip install dist/azure_functions_openapi_pydantic-0.1.0-py3-none-any.whl
```

## Publish to PyPI

### 1. Install Twine
```bash
pip install twine
```

### 2. Test on TestPyPI First
```bash
twine upload --repository testpypi dist/*
```

Test installation:
```bash
pip install --index-url https://test.pypi.org/simple/ azure-functions-openapi-pydantic
```

### 3. Publish to Production PyPI
```bash
twine upload dist/*
```

### 4. Verify Installation
```bash
pip install azure-functions-openapi-pydantic
python -c "from azfunc_openapi_pydantic import openapi, ApiResponse; print('Success!')"
```

## Version Bumping

Update version in `pyproject.toml`:
```toml
version = "0.2.0"  # Increment as needed
```

Then rebuild and republish.

## GitHub Release

1. Create a git tag:
```bash
git tag -a v0.1.0 -m "Release v0.1.0"
git push origin v0.1.0
```

2. Create a GitHub release from the tag
3. Attach the built wheel and source distribution

## PyPI Credentials

You'll need a PyPI account and API token:
1. Create account at https://pypi.org
2. Generate API token in account settings
3. Configure in `~/.pypirc`:

```ini
[pypi]
username = __token__
password = pypi-...your-token...
```

## Post-Publishing

- Update README with PyPI badge
- Announce on relevant channels
- Monitor issues and pull requests
- Maintain changelog for future releases

