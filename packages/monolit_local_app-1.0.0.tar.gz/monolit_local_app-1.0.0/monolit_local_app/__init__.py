from monolit.src import *
from monolit.server import server
from monolit.other import info
from flask import jsonify, Request
from os.path import dirname