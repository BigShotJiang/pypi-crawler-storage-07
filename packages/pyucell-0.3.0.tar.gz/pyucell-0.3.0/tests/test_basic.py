import pyucell as uc

def test_package_has_version():
    assert uc.__version__ is not None