# -*- coding: utf-8 -*-

from .caster import fsx_caster

caster = fsx_caster

__version__ = "1.40.0"