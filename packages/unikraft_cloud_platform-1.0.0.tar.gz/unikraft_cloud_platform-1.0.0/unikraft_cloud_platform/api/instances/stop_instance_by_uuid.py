from http import HTTPStatus
from typing import Any, Optional, Union
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.stop_instance_response import StopInstanceResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    uuid: UUID,
    *,
    force: Union[Unset, bool] = UNSET,
    drain_timeout_ms: Union[Unset, int] = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["force"] = force

    params["drain_timeout_ms"] = drain_timeout_ms

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": f"/v1/instances/{uuid}/stop",
        "params": params,
    }

    return _kwargs


def _parse_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> StopInstanceResponse:
    response_default = StopInstanceResponse.from_dict(response.json())

    return response_default


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[StopInstanceResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    uuid: UUID,
    *,
    client: Union[AuthenticatedClient, Client],
    force: Union[Unset, bool] = UNSET,
    drain_timeout_ms: Union[Unset, int] = UNSET,
) -> Response[StopInstanceResponse]:
    """Stop Instance by UUID

     Stop a running instance by its UUID or do nothing if the instance is
    already stopped.

    Args:
        uuid (UUID):
        force (Union[Unset, bool]):
        drain_timeout_ms (Union[Unset, int]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[StopInstanceResponse]
    """

    kwargs = _get_kwargs(
        uuid=uuid,
        force=force,
        drain_timeout_ms=drain_timeout_ms,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    uuid: UUID,
    *,
    client: Union[AuthenticatedClient, Client],
    force: Union[Unset, bool] = UNSET,
    drain_timeout_ms: Union[Unset, int] = UNSET,
) -> Optional[StopInstanceResponse]:
    """Stop Instance by UUID

     Stop a running instance by its UUID or do nothing if the instance is
    already stopped.

    Args:
        uuid (UUID):
        force (Union[Unset, bool]):
        drain_timeout_ms (Union[Unset, int]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        StopInstanceResponse
    """

    return sync_detailed(
        uuid=uuid,
        client=client,
        force=force,
        drain_timeout_ms=drain_timeout_ms,
    ).parsed


async def asyncio_detailed(
    uuid: UUID,
    *,
    client: Union[AuthenticatedClient, Client],
    force: Union[Unset, bool] = UNSET,
    drain_timeout_ms: Union[Unset, int] = UNSET,
) -> Response[StopInstanceResponse]:
    """Stop Instance by UUID

     Stop a running instance by its UUID or do nothing if the instance is
    already stopped.

    Args:
        uuid (UUID):
        force (Union[Unset, bool]):
        drain_timeout_ms (Union[Unset, int]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[StopInstanceResponse]
    """

    kwargs = _get_kwargs(
        uuid=uuid,
        force=force,
        drain_timeout_ms=drain_timeout_ms,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    uuid: UUID,
    *,
    client: Union[AuthenticatedClient, Client],
    force: Union[Unset, bool] = UNSET,
    drain_timeout_ms: Union[Unset, int] = UNSET,
) -> Optional[StopInstanceResponse]:
    """Stop Instance by UUID

     Stop a running instance by its UUID or do nothing if the instance is
    already stopped.

    Args:
        uuid (UUID):
        force (Union[Unset, bool]):
        drain_timeout_ms (Union[Unset, int]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        StopInstanceResponse
    """

    return (
        await asyncio_detailed(
            uuid=uuid,
            client=client,
            force=force,
            drain_timeout_ms=drain_timeout_ms,
        )
    ).parsed
