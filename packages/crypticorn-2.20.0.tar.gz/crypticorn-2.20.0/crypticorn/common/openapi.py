default_tags = [
    {
        "name": "Status",
        "description": "These endpoints contain status operations.",
    },
    {
        "name": "Admin",
        "description": "These endpoints contain debugging and monitoring operations. They require admin scopes.",
    },
]
