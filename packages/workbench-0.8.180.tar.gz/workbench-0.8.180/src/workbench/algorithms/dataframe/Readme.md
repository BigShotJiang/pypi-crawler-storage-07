# Algorithms: Dataframe
- **Dataframes:** These algorithms are algorithms that have Pandas Dataframes as inputs and typically (not always) DataFrames as outputs. Depedending on the algorithm they might have outputs like dictionaries or lists.
- **Light:** These algorithms are considered **light** algorithms since they are contrained by one process where the data is in memory.