import importlib.resources, os, platform, sys

def main():
    ARCH, OS = platform.uname().machine.lower(), platform.uname().system.lower()

    if OS   == "darwin": OS   =   "macos"
    if ARCH ==  "arm64": ARCH = "aarch64"

    binary_path = importlib.resources.files("zinq").joinpath("bin", "zinq.exe" if os.name == "nt" else "zinq")

    os.execv(binary_path, [binary_path, *sys.argv[1:]])
