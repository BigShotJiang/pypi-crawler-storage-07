import os, setuptools, setuptools.command.install, shutil, subprocess, sysconfig

class InstallCommand(setuptools.command.install.install):
    def run(self):
        setuptools.command.install.install.run(self)

        subprocess.run(["make", "CROSS=1"], check=True)

        shutil.rmtree(os.path.join("zinq", "bin"), ignore_errors=True)

        subprocess.run(["cp", "-r", "zig-out", os.path.join("zinq", "bin")], check=True)

setuptools.setup(
    name = "zinq",
    version = open("VERSION").read(),
    packages = setuptools.find_packages(),
    long_description = open("README.md").read(),
    long_description_content_type = "text/markdown",
    author = "tjira",
    url = "https://github.com/tjira/zinq",
    cmdclass = {
        "install": InstallCommand
    },
    entry_points = {
        "console_scripts": ["zinq = zinq.launch:main"]
    },
    package_data = {
        "zinq": ["bin"]
    }
)
