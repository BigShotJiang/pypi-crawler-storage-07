"""
Package initialization code for PortWatch.
"""

__version__ = "0.0.7"
__author__ = "Madushanaka Rajapaksha"
__author_email__ = "madushanakarajapakshe999@gmail.com"
__url__ = "https://github.com/madushanakarajapakshe999/portwatch"
__license__ = "MIT License"
__copyright__ = "(c) 2025 Madushanaka Rajapaksha"
 