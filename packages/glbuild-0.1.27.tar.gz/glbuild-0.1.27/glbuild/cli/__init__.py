"""CLI tool module."""
