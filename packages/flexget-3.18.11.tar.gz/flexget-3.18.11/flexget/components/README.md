# Components

This directory contains plugins which are more comprehensive in their functionality. They
typically have command line interface (`cli.py`), REST api (`api.py`), separate
database layer (`db.py`) and may have different companion plugins for output, input etc.
