"""Should contain only plugins that are internal and will never be configured by users.

Extension points, internal APIs etc.
"""
