from fair_platform.backend.data.storage import storage

__all__ = [
    "storage"
]