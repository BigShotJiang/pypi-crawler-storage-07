import sys
import subprocess

print("=" * 60)
print("Python executable:", sys.executable)
print("Python version:", sys.version)
print("=" * 60)

print("\nPython path:")
for p in sys.path:
    print(f"  {p}")

print("\n" + "=" * 60)
print("Checking installed packages:")
print("=" * 60)

# List installed packages
result = subprocess.run(
    [sys.executable, "-m", "pip", "list"],
    capture_output=True,
    text=True
)
print(result.stdout)

print("\n" + "=" * 60)
print("Trying to import lego_rendering:")
print("=" * 60)

try:
    import lego_rendering
    print(f"✓ Successfully imported lego_rendering from: {lego_rendering.__file__}")
    print(f"\nAvailable exports:")
    if hasattr(lego_rendering, '__all__'):
        for item in lego_rendering.__all__:
            print(f"  - {item}")
    else:
        print("  No __all__ defined")
        print(f"  Available attributes: {dir(lego_rendering)}")
except ImportError as e:
    print(f"✗ Failed to import: {e}")
except Exception as e:
    print(f"✗ Error: {e}")
