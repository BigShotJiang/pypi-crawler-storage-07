import sys
import subprocess

print("=" * 60)
print("Detailed package info from pip show:")
print("=" * 60)

result = subprocess.run(
    [sys.executable, "-m", "pip", "show", "lego-rendering"],
    capture_output=True,
    text=True
)
print(result.stdout)
print(result.stderr)

print("\n" + "=" * 60)
print("Files installed (from pip show -f):")
print("=" * 60)

result = subprocess.run(
    [sys.executable, "-m", "pip", "show", "-f", "lego-rendering"],
    capture_output=True,
    text=True
)
print(result.stdout)
