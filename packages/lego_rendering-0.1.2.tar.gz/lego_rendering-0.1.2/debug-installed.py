import sys
import os
import glob

site_packages = "/Applications/Blender.app/Contents/Resources/4.3/python/lib/python3.11/site-packages"

print("=" * 60)
print("Checking what was installed in site-packages:")
print("=" * 60)

# Look for lego-rendering related files/directories
patterns = [
    "lego*",
    "*lego*rendering*"
]

found_items = set()
for pattern in patterns:
    items = glob.glob(os.path.join(site_packages, pattern))
    found_items.update(items)

if found_items:
    for item in sorted(found_items):
        rel_path = os.path.relpath(item, site_packages)
        if os.path.isdir(item):
            print(f"\nDirectory: {rel_path}/")
            # List contents
            try:
                contents = os.listdir(item)
                for c in sorted(contents)[:20]:  # Limit to first 20
                    print(f"  - {c}")
                if len(contents) > 20:
                    print(f"  ... and {len(contents) - 20} more items")
            except Exception as e:
                print(f"  Error listing: {e}")
        else:
            print(f"\nFile: {rel_path}")
            # Show file size
            try:
                size = os.path.getsize(item)
                print(f"  Size: {size} bytes")
            except Exception as e:
                print(f"  Error getting size: {e}")
else:
    print("No lego-rendering related files found!")

print("\n" + "=" * 60)
print("Looking for .dist-info directories:")
print("=" * 60)
dist_info = glob.glob(os.path.join(site_packages, "*lego*.dist-info"))
for d in dist_info:
    print(f"\n{os.path.basename(d)}")
    try:
        record = os.path.join(d, "RECORD")
        if os.path.exists(record):
            print("  Files installed (from RECORD):")
            with open(record) as f:
                lines = f.readlines()[:30]  # First 30 lines
                for line in lines:
                    file_path = line.split(',')[0]
                    print(f"    {file_path}")
                if len(f.readlines()) > 30:
                    print(f"    ... and more")
    except Exception as e:
        print(f"  Error reading RECORD: {e}")
