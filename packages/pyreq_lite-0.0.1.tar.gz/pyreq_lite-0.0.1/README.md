# pyreq-lite (safe demo)

This is a *safe* demonstration package. It **does not** run on import.
To demonstrate behavior, run:

- `pyreq-lite` (after installing) or
- `python -m pyreq_lite`

This will create a file `pyreq_lite_demo.txt` in the current directory with a harmless message.
