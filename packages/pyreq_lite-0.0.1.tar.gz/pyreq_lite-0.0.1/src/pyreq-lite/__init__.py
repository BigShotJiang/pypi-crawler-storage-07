# package init — intentionally minimal
__all__ = ["cli"]
