# input_with_helper.template

`input_with_helper.template` is used by AOB generated add-ons.
