# cocorum

The primary use from this module is the `RumbleAPI` class, the wrapper for the Rumble Live Stream API.
All other classes are supporting sub-classes.

::: cocorum

S.D.G.
