# cocorum.uploadphp

The primary use from this module is the `UploadPHP` class, used for uploading videos. You must first create an instance of `cocorum.servicephp.ServicePHP()`, and then pass it to this class upon initialization.
All other classes are supporting sub-classes.

::: cocorum.uploadphp

S.D.G.
