# -*- coding: utf-8 -*-

from .caster import rum_caster

caster = rum_caster

__version__ = "1.40.0"