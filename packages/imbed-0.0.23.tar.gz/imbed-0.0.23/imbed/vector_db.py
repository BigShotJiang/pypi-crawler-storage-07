"""Facades for vector databases"""
