"""Examples with imbed"""
