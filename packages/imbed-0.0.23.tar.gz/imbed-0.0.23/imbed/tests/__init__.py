"""Tests for imbed"""
