"""
Mock module for WebSocket server testing.
"""

from .data import MockDataProvider

__all__ = ['MockDataProvider']