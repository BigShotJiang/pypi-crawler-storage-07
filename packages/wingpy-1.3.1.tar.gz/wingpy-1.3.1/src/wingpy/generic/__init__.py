from wingpy.generic.generic import GenericRESTAPI

__all__ = ["GenericRESTAPI"]
