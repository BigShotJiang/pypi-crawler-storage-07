# -*- coding: utf-8 -*-

from .caster import sagemaker_metrics_caster

caster = sagemaker_metrics_caster

__version__ = "1.40.0"