# Support

- For bugs, open an issue with a minimal reproducible example.
- For questions, use GitHub Discussions.
- For features, open a Feature Request issue with clear use cases.
