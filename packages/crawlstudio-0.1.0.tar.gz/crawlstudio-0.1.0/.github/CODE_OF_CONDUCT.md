# Code of Conduct

We follow the Contributor Covenant and strive to maintain a welcoming, inclusive, and respectful community.

- Be respectful and constructive.
- Assume good intent and seek to understand.
- No harassment or discrimination.

Report incidents privately to the maintainers via security contact or email.
