---
name: Feature request
about: Suggest an idea for this project
labels: enhancement
---

### Problem
What problem are you trying to solve?

### Proposal
Describe the solution you'd like.

### Alternatives
Describe any alternative solutions or features you've considered.

### Additional context
Add any other context or screenshots.
