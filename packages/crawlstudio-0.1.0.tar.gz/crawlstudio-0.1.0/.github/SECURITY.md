# Security Policy

- Do not publicly disclose security issues. Email the maintainer to report vulnerabilities.
- We aim to acknowledge reports within 72 hours and provide a remediation plan as soon as possible.
- Include steps to reproduce, affected versions, and any PoC.
