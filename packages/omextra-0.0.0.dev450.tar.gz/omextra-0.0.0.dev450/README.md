# Overview

Core-like code not appropriate for inclusion in `omlish` for one reason or another. A bit like
[`golang.org/x`](https://pkg.go.dev/golang.org/x).

# Notable packages

- **[text.antlr](https://github.com/wrmsr/omlish/blob/master/omextra/text/antlr)** -
  [ANTLR](https://www.antlr.org/)-related code.
