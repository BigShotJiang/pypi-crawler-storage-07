# -*- coding: utf-8 -*-

from .caster import pinpoint_sms_voice_v2_caster

caster = pinpoint_sms_voice_v2_caster

__version__ = "1.40.0"