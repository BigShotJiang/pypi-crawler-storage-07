# CHANGELOG

<!-- version list -->

## v0.1.0 (2025-09-26)

### Features

- **api**: Support the historic joa api endpoint
  ([#12](https://github.com/paddy74/python-usajobsapi/pull/12),
  [`02ea27b`](https://github.com/paddy74/python-usajobsapi/commit/02ea27b2cb1b65b95b78c22604cc16832b834eb0))


## v0.0.1 (2025-09-22)

- Initial Release
