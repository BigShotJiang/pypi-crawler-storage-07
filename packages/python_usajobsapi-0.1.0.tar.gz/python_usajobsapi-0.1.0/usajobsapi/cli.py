def main() -> None:
    pass
