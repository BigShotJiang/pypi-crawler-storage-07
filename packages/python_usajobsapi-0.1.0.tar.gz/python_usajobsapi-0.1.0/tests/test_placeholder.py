"""Placeholder tests for USAJobs API package."""


def test_placeholder() -> None:
    """A trivial test to ensure the test suite runs."""
    assert True
