# -*- coding: utf-8 -*-

from .caster import security_ir_caster

caster = security_ir_caster

__version__ = "1.40.0"