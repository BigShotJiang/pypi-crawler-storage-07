fake image file
