cd ..
git status