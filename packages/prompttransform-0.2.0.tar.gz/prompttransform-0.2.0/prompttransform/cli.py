# Packaged CLI wrapper copied from root Promptransform.py (verbatim with minor main() wrapper)
# NOTE: Keep logic identical; only change is relative import and added main() for entry point.

from .promptify import Promptify, Techniques, Transformation  # type: ignore
from .version import __version__

# Original CLI source follows (copied):
#!/usr/bin/env python3
"""
Promptransform - Comprehensive Text Transformation Library for AI Security Testing

A modular library and CLI tool providing 100+ transformation techniques for
AI security research, prompt injection testing, and jailbreaking detection.

Author: AI Security Research Team
License: Open Source - For authorized security testing only
"""

import json
import sys
import os
import logging
import time
from pathlib import Path
from typing import Dict, List, Any, Optional

# Modern CLI dependencies
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn, TimeRemainingColumn
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich.prompt import Prompt, Confirm
from rich.syntax import Syntax
from rich.columns import Columns
from rich.tree import Tree
from rich import box
from rich.align import Align
from rich.layout import Layout
from rich.live import Live
import typer

# Set UTF-8 encoding for Windows console
if sys.platform == "win32":
    import locale
    if locale.getpreferredencoding().upper() != 'UTF-8':
        os.environ["PYTHONIOENCODING"] = "utf-8"
    try:
        import colorama
        colorama.init(autoreset=True)
    except ImportError:
        pass

console = Console(
    force_terminal=True,
    legacy_windows=False if sys.platform != "win32" else True,
    emoji=False if sys.platform == "win32" else True
)

BANNER_TEXT = "PromptTransform"
SUBTITLE = "AI Security Testing • Prompt Injection • Jailbreaking Research"
VERSION = __version__  # Use package version

# Global option state
_version_flag_triggered = False


def get_platform_text(text_with_emoji: str, text_without_emoji: Optional[str] = None) -> str:
    if sys.platform == "win32":
        if text_without_emoji:
            return text_without_emoji
        import re
        return re.sub(r'[🎯⚡💥👋✓✗📝🔍⚙️📂🚀💣☠⭐🔥❤💔🔒🔑⚗]', '', text_with_emoji).strip()
    return text_with_emoji

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('promptransform.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class ModernConfig:
    def __init__(self):
        self.config_dir = Path.home() / ".promptransform"
        self.config_file = self.config_dir / "config.json"
        self.config_dir.mkdir(exist_ok=True)
        self.config = self._load_config()

    def _load_config(self) -> Dict:
        default_config = {
            "theme": "dark",
            "output_format": "rich",
            "show_progress": True,
            "save_history": True,
            "auto_copy": False,
            "default_intensity": 0.5,
            "default_level": "advanced",
            "favorite_techniques": ["homoglyph", "dan", "adversarial_suffix"]
        }
        if not self.config_file.exists():
            self.save(default_config)
            return default_config
        try:
            with open(self.config_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            self.save(default_config)
            return default_config

    def get(self, key: str, default: Any = None) -> Any:
        return self.config.get(key, default)

    def set(self, key: str, value: Any):
        self.config[key] = value
        self.save(self.config)

    def save(self, data: Dict):
        with open(self.config_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4)

class ModernPromptransformCLI:
    def __init__(self):
        self.config = ModernConfig()
        self.promptify = Promptify("")

    def _display_banner(self):
        banner_panel = Panel(
            Text(BANNER_TEXT, style="bold magenta", justify="center"),
            border_style="green",
            padding=(1, 4)
        )
        subtitle_text = Text(SUBTITLE, style="cyan", justify="center")
        version_text = Text(f"v{VERSION}", style="dim", justify="center")

        console.print(banner_panel)
        console.print(subtitle_text)
        console.print(version_text)
        console.print()

    def _get_all_techniques_by_category(self) -> Dict[str, List[Dict[str, Any]]]:
        categorized = {}
        for tech_enum in Techniques.get_all():
            tech_instance = tech_enum.value
            category = tech_instance.category
            if category not in categorized:
                categorized[category] = []
            categorized[category].append({
                "name": tech_enum.name.lower(),
                "description": tech_instance.description,
            })
        return categorized

    def list_techniques(self):
        self._display_banner()
        console.print(Panel(Text("Available Transformation Techniques", style="bold yellow"), border_style="yellow"))

        categorized_techniques = self._get_all_techniques_by_category()
        tree = Tree(
            get_platform_text("📚 Categories", "Categories"),
            style="bold cyan",
            guide_style="cyan"
        )
        for category, techniques in sorted(categorized_techniques.items()):
            category_node = tree.add(
                get_platform_text(f"📁 {category.title()}", category.title()),
                style="green"
            )
            for tech in sorted(techniques, key=lambda x: x['name']):
                category_node.add(
                    Text(f"{tech['name']}", style="magenta")
                ).add(Text(f"  {tech['description']}", style="dim"))
        console.print(tree)
        console.print()

    def _run_with_progress(self, text: str, techniques: List[str], params_list: List[Dict], level: Optional[str] = None) -> str:
        result = text
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            TimeRemainingColumn(),
            console=console,
            transient=True
        ) as progress:
            task = progress.add_task("[cyan]Applying transformations...", total=len(techniques))
            self.promptify.set_prompt(text)
            for i, tech_name in enumerate(techniques):
                try:
                    tech_enum = Techniques[tech_name.upper()]
                    params = params_list[i] if i < len(params_list) else {}
                    if level:
                        params['level'] = level
                    self.promptify.apply(tech_enum, **params)
                    progress.update(task, advance=1, description=f"[cyan]Applied [bold]{tech_name}[/bold]")
                    time.sleep(0.1)
                except KeyError:
                    progress.stop()
                    console.print(f"[bold red]Error: Technique '{tech_name}' not found.[/bold red]")
                    return text
                except Exception as e:
                    progress.stop()
                    console.print(f"[bold red]Error applying technique '{tech_name}': {e}[/bold red]")
                    return text
        return self.promptify.get_transformed_prompt()

    def transform_text(self, text: str, techniques: List[str], params_str: Optional[str] = None, level: Optional[str] = None):
        self._display_banner()
        params_list = self._parse_params(params_str)
        console.print(Panel(Text("Input Prompt", style="bold green"), border_style="green", expand=False))
        console.print(Syntax(text, "python", theme="monokai", line_numbers=True))
        console.print()

        console.print(Panel(Text("Applied Techniques", style="bold blue"), border_style="blue", expand=False))
        tech_table = Table(box=box.ROUNDED, show_header=True, header_style="bold blue")
        tech_table.add_column("Order", style="dim")
        tech_table.add_column("Technique")
        tech_table.add_column("Parameters")
        if level:
            tech_table.add_column("Level")
        for i, tech_name in enumerate(techniques):
            params = params_list[i] if i < len(params_list) else {}
            row = [str(i + 1), tech_name, json.dumps(params) if params else "default"]
            if level:
                row.append(level)
            tech_table.add_row(*row)
        console.print(tech_table)
        console.print()

        transformed_text = self._run_with_progress(text, techniques, params_list, level)
        console.print(Panel(Text("Transformed Prompt", style="bold magenta"), border_style="magenta", expand=False))
        console.print(Syntax(transformed_text, "python", theme="monokai", line_numbers=True))
        console.print()
        if self.config.get("auto_copy", False):
            try:
                import pyperclip
                pyperclip.copy(transformed_text)
                console.print(get_platform_text("✓ Copied to clipboard!", "Copied to clipboard!"), style="green")
            except ImportError:
                console.print(get_platform_text("✗ Failed to copy to clipboard. `pyperclip` not installed or supported.", "Failed to copy to clipboard."), style="yellow")
            except Exception as e:
                console.print(get_platform_text(f"✗ Failed to copy to clipboard: {e}", f"Failed to copy to clipboard: {e}"), style="yellow")

    def _parse_params(self, params_str: Optional[str]) -> List[Dict]:
        if not params_str:
            return []
        try:
            params = json.loads(params_str)
            if isinstance(params, list):
                return params
            if isinstance(params, dict):
                return [params]
            return []
        except json.JSONDecodeError:
            console.print(f"[bold red]Error: Invalid JSON format for --params: {params_str}[/bold red]")
            return []

    def interactive_mode(self):
        self._display_banner()
        console.print(Panel(
            Text("Entering Interactive Mode", justify="center", style="bold yellow"),
            border_style="yellow"
        ))
        console.print("Type 'help' for commands, 'exit' to quit.")
        prompt_text = Prompt.ask("[bold green]Enter the initial prompt")
        self.promptify.set_prompt(prompt_text)
        while True:
            try:
                command_str = Prompt.ask(f"\n[bold cyan]PromptTransform ({len(self.promptify.history)} steps)>")
                if not command_str:
                    continue
                parts = command_str.split()
                command = parts[0].lower()
                args = parts[1:]
                if command in ["exit", "quit"]:
                    break
                elif command == "help":
                    self._interactive_help()
                elif command == "prompt":
                    self.promptify.set_prompt(" ".join(args))
                    console.print(f"[green]Prompt updated.[/green]")
                elif command == "show":
                    self._interactive_show()
                elif command == "apply":
                    self._interactive_apply(args)
                elif command == "reset":
                    self.promptify.reset()
                    console.print("[yellow]Transformations reset.[/yellow]")
                elif command == "list":
                    self.list_techniques()
                else:
                    console.print(f"[red]Unknown command: {command}. Type 'help' for a list of commands.[/red]")
            except (KeyboardInterrupt, EOFError):
                break
        console.print("\n[bold yellow]Exiting interactive mode.[/bold yellow]")

    def _interactive_help(self):
        help_text = """
[bold]Interactive Mode Commands:[/bold]
  [cyan]prompt <new_prompt>[/cyan]   - Set a new initial prompt.
  [cyan]apply <tech> [k=v ...][/cyan] - Apply a transformation. Ex: `apply dan version=evil`
  [cyan]show[/cyan]                  - Show original, current transformed prompt, and history.
  [cyan]reset[/cyan]                 - Clear all applied transformations.
  [cyan]list[/cyan]                  - List all available techniques.
  [cyan]help[/cyan]                  - Show this help message.
  [cyan]exit / quit[/cyan]           - Exit the interactive session.
        """
        console.print(Panel(help_text, title="Help", border_style="blue"))

    def _interactive_show(self):
        layout = Layout()
        layout.split(
            Layout(name="header", size=3),
            Layout(ratio=1, name="main"),
            Layout(size=10, name="footer"),
        )
        layout["main"].split_row(Layout(name="side"), Layout(name="body", ratio=2))
        original_panel = Panel(
            Syntax(self.promptify.get_original_prompt(), "text", theme="monokai", line_numbers=True, word_wrap=True),
            title="Original Prompt",
            border_style="green"
        )
        transformed_panel = Panel(
            Syntax(self.promptify.get_transformed_prompt(), "text", theme="monokai", line_numbers=True, word_wrap=True),
            title="Current Transformed Prompt",
            border_style="magenta"
        )
        history_tree = Tree("Transformation History", guide_style="bold bright_blue")
        if self.promptify.history:
            for i, (tech, params) in enumerate(self.promptify.history):
                params_str = ", ".join(f"{k}={v}" for k, v in params.items())
                history_tree.add(f"[cyan]{i+1}.[/cyan] [magenta]{tech.name.lower()}[/magenta] [dim]({params_str})[/dim]")
        else:
            history_tree.add("[dim]No transformations applied yet.[/dim]")
        history_panel = Panel(history_tree, title="History", border_style="blue")
        console.print(original_panel)
        console.print(transformed_panel)
        console.print(history_panel)

    def _interactive_apply(self, args: List[str]):
        if not args:
            console.print("[red]Error: 'apply' requires a technique name.[/red]")
            return
        tech_name = args[0].upper()
        try:
            tech_enum = Techniques[tech_name]
        except KeyError:
            console.print(f"[red]Error: Technique '{args[0]}' not found.[/red]")
            return
        params = {}
        for arg in args[1:]:
            if "=" in arg:
                key, value = arg.split("=", 1)
                try:
                    params[key] = json.loads(value)
                except json.JSONDecodeError:
                    params[key] = value
            else:
                console.print(f"[yellow]Warning: Ignoring invalid parameter format '{arg}'. Use key=value.[/yellow]")
        self.promptify.apply(tech_enum, **params)
        console.print(f"[green]Applied [bold]{tech_name.lower()}[/bold] with params: {params}[/green]")
        self._interactive_show()

app = typer.Typer(
    add_completion=False,
    rich_markup_mode="rich",
    help="A modern CLI for the PromptTransform library.",
    no_args_is_help=True,
    invoke_without_command=True,
)
cli_instance = ModernPromptransformCLI()

@app.callback()
def main_callback(
    version: bool = typer.Option(False, "--version", "-V", help="Show version and exit", is_eager=True),
):
    global _version_flag_triggered
    if version:
        _version_flag_triggered = True
        console.print(f"PromptTransform version: {VERSION}")
        raise typer.Exit()

@app.command(name="version", help="Print version and exit.")
def version_cmd():
    console.print(f"PromptTransform version: {VERSION}")

@app.command(name="list", help=get_platform_text("📝 List all available transformation techniques.", "List all available transformation techniques."))
def list_techniques_command():
    cli_instance.list_techniques()

@app.command(name="run", help=get_platform_text("🚀 Apply transformations to a prompt.", "Apply transformations to a prompt."))
def run_command(
    prompt: str = typer.Option(..., "--prompt", "-p", help="The input prompt text to transform."),
    techniques: List[str] = typer.Option(..., "--technique", "-t", help="One or more techniques to apply in order."),
    params: Optional[str] = typer.Option(None, "--params", "-a", help="JSON string for technique parameters. Either a single dict or a list of dicts."),
    level: Optional[str] = typer.Option(None, "--level", "-l", help="The enhancement level to use (e.g., 'enhanced')."),
):
    cli_instance.transform_text(prompt, techniques, params, level)

@app.command(name="interactive", help=get_platform_text("💬 Start an interactive transformation session.", "Start an interactive transformation session."))
def interactive_command():
    cli_instance.interactive_mode()

# Added explicit main wrapper for console_script entry point
def main():  # pragma: no cover - thin wrapper
    app()

if __name__ == "__main__":  # pragma: no cover
    main()
