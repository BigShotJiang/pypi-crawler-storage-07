"""PromptTransform package interface.

This package mirrors the root-level `promptify.py` exactly (verbatim copy) to
ensure zero integrity drift. Always apply changes to the root file first and
then overwrite `Publish/prompttransform/promptify.py`.

Exports:
	Promptify  - Fluent API for chaining transformations.
	Techniques - Enum of all transformation strategies.
	Transformation - Abstract base class for custom extensions.

Versioning:
	The `__version__` field follows semantic versioning. Increment as you
	publish changes. For development snapshots, append `-dev`.
"""

from .promptify import Promptify, Techniques, Transformation  # type: ignore
from .version import __version__  # single source of truth

__all__ = [
	"Promptify",
	"Techniques",
	"Transformation",
	"__version__",
]

# Convenience alias for external tooling
version = __version__
