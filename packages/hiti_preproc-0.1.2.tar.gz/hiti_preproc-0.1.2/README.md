# HITI-Preproc [Early-Alpha]

*Beatrice Brown-Mulry*

WIP package for the DICOM preprocessing workflows used internally in the HITI Lab.
