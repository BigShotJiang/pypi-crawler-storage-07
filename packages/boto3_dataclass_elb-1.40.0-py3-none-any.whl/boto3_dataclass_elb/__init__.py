# -*- coding: utf-8 -*-

from .caster import elb_caster

caster = elb_caster

__version__ = "1.40.0"