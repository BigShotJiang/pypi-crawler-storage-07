# Bridge

::: sieves.tasks.predictive.bridges.Bridge
::: sieves.tasks.predictive.bridges.GliXBridge