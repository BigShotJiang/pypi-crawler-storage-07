# Named Entity Recognition

::: sieves.tasks.predictive.ner.core
::: sieves.tasks.predictive.ner.bridges