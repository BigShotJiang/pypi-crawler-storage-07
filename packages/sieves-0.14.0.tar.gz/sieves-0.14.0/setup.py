#!/usr/bin/env python
"""Setup script for the Sieves package."""

if __name__ == "__main__":
    from setuptools import find_packages, setup

    setup(name="sieves", packages=find_packages())
