"""Youdao Translator
====================

.. todo::
    Refer `<https://github.com/ChestnutHeng/Wudao-dict>`_.
"""
