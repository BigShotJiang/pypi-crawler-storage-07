"""Yandex Translator
====================

.. todo::
    Refer `<https://github.com/soimort/translate-shell>`_
"""
