# Translate Shell

```{autofile} ../../src/*/*.py
---
module:
---
```
