# -*- coding: utf-8 -*-

from .caster import rolesanywhere_caster

caster = rolesanywhere_caster

__version__ = "1.40.0"