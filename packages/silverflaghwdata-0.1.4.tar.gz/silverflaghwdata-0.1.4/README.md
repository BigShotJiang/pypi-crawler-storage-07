# hw-cam-datawarehousing
Mass data colleciton of highway cameras.

## Data sources
State highway data sources: https://silverflag.net/resources/publicdata/dotcctv.html
