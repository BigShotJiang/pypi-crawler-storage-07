# Changelog

## [0.1.3] - 2025-01-09

- Fixed blank lines being incorrectly added after multi-line docstrings in function bodies

## [0.1.2] - 2025-01-09

- Fixed blank lines being removed between consecutive class methods
- Added --version flag to display version from pyproject.toml
- Fixed blank lines after docstrings in function bodies
- Fixed internal blank lines being removed from multi-line docstrings
- Fixed comment block "leave-as-is" behavior for blank line preservation

## [0.1.1] - 2025-01-09

- Initial release