from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np
import pytest
import safetensors
from tokenizers import Tokenizer

from model2vec import StaticModel


def test_initialization(mock_vectors: np.ndarray, mock_tokenizer: Tokenizer, mock_config: dict[str, str]) -> None:
    """Test successful initialization of StaticModel."""
    model = StaticModel(vectors=mock_vectors, tokenizer=mock_tokenizer, config=mock_config)
    assert model.embedding.shape == (5, 2)
    assert len(model.tokens) == 5
    assert model.tokenizer == mock_tokenizer
    assert model.config == mock_config


def test_initialization_token_vector_mismatch(mock_tokenizer: Tokenizer, mock_config: dict[str, str]) -> None:
    """Test if error is raised when number of tokens and vectors don't match."""
    mock_vectors = np.array([[0.1, 0.2], [0.2, 0.3]])
    with pytest.raises(ValueError):
        StaticModel(vectors=mock_vectors, tokenizer=mock_tokenizer, config=mock_config)


def test_tokenize(mock_vectors: np.ndarray, mock_tokenizer: Tokenizer, mock_config: dict[str, str]) -> None:
    """Test tokenization of a sentence."""
    model = StaticModel(vectors=mock_vectors, tokenizer=mock_tokenizer, config=mock_config)
    model._can_encode_fast = True
    tokens_fast = model.tokenize(["word1 word2"])
    model._can_encode_fast = False
    tokens_slow = model.tokenize(["word1 word2"])

    assert tokens_fast == tokens_slow


def test_encode_batch_fast(
    mock_vectors: np.ndarray, mock_berttokenizer: Tokenizer, mock_config: dict[str, str]
) -> None:
    """Test tokenization of a sentence."""
    if hasattr(mock_berttokenizer, "encode_batch_fast"):
        del mock_berttokenizer.encode_batch_fast
        model = StaticModel(vectors=mock_vectors, tokenizer=mock_berttokenizer, config=mock_config)
        assert not model._can_encode_fast


def test_encode_single_sentence(
    mock_vectors: np.ndarray, mock_tokenizer: Tokenizer, mock_config: dict[str, str]
) -> None:
    """Test encoding of a single sentence."""
    model = StaticModel(vectors=mock_vectors, tokenizer=mock_tokenizer, config=mock_config)
    encoded = model.encode("word1 word2")
    assert encoded.shape == (2,)


def test_encode_single_sentence_empty(
    mock_vectors: np.ndarray, mock_tokenizer: Tokenizer, mock_config: dict[str, str]
) -> None:
    """Test encoding of a single empty sentence."""
    model = StaticModel(vectors=mock_vectors, tokenizer=mock_tokenizer, config=mock_config)
    model.normalize = True
    encoded = model.encode("")
    assert not np.isnan(encoded).any()
    assert np.all(encoded == 0)


def test_encode_multiple_sentences(
    mock_vectors: np.ndarray, mock_tokenizer: Tokenizer, mock_config: dict[str, str]
) -> None:
    """Test encoding of multiple sentences."""
    model = StaticModel(vectors=mock_vectors, tokenizer=mock_tokenizer, config=mock_config)
    encoded = model.encode(["word1 word2", "word1 word3"])
    assert encoded.shape == (2, 2)


def test_encode_as_sequence(mock_vectors: np.ndarray, mock_tokenizer: Tokenizer, mock_config: dict[str, str]) -> None:
    """Test encoding of sentences as tokens."""
    sentences = ["word1 word2", "word1 word3"]
    model = StaticModel(vectors=mock_vectors, tokenizer=mock_tokenizer, config=mock_config)
    encoded_sequence = model.encode_as_sequence(sentences)
    encoded = model.encode(sentences)

    assert len(encoded_sequence) == 2

    means = [np.mean(sequence, axis=0) for sequence in encoded_sequence]
    assert np.allclose(means, encoded)


def test_encode_multiprocessing(
    mock_vectors: np.ndarray, mock_tokenizer: Tokenizer, mock_config: dict[str, str]
) -> None:
    """Test encoding with multiprocessing."""
    model = StaticModel(vectors=mock_vectors, tokenizer=mock_tokenizer, config=mock_config)
    # Generate a list of 15k inputs to test multiprocessing
    sentences = ["word1 word2"] * 15_000
    encoded = model.encode(sentences, use_multiprocessing=True)
    assert encoded.shape == (15000, 2)


def test_encode_as_sequence_multiprocessing(
    mock_vectors: np.ndarray, mock_tokenizer: Tokenizer, mock_config: dict[str, str]
) -> None:
    """Test encoding of sentences as tokens with multiprocessing."""
    model = StaticModel(vectors=mock_vectors, tokenizer=mock_tokenizer, config=mock_config)
    # Generate a list of 15k inputs to test multiprocessing
    sentences = ["word1 word2"] * 15_000
    encoded = model.encode_as_sequence(sentences, use_multiprocessing=True)
    assert len(encoded) == 15_000


def test_encode_as_tokens_empty(
    mock_vectors: np.ndarray, mock_tokenizer: Tokenizer, mock_config: dict[str, str]
) -> None:
    """Test encoding of an empty list of sentences."""
    model = StaticModel(vectors=mock_vectors, tokenizer=mock_tokenizer, config=mock_config)
    encoded: list[np.ndarray] | np.ndarray
    encoded = model.encode_as_sequence("")
    assert np.array_equal(encoded, np.zeros(shape=(0, 2), dtype=model.embedding.dtype))

    encoded_list = model.encode_as_sequence(["", ""])
    out = [np.zeros(shape=(0, 2), dtype=model.embedding.dtype) for _ in range(2)]
    assert [np.array_equal(x, y) for x, y in zip(encoded_list, out)]


def test_encode_empty_sentence(
    mock_vectors: np.ndarray, mock_tokenizer: Tokenizer, mock_config: dict[str, str]
) -> None:
    """Test encoding with an empty sentence."""
    model = StaticModel(vectors=mock_vectors, tokenizer=mock_tokenizer, config=mock_config)
    encoded = model.encode("")
    assert np.array_equal(encoded, np.zeros((2,)))


def test_normalize(mock_vectors: np.ndarray, mock_tokenizer: Tokenizer, mock_config: dict[str, str]) -> None:
    """Test normalization of vectors."""
    s = "word1 word2 word3"
    model = StaticModel(vectors=mock_vectors, tokenizer=mock_tokenizer, config=mock_config, normalize=False)
    X = model.encode(s)
    model = StaticModel(vectors=mock_vectors, tokenizer=mock_tokenizer, config=mock_config, normalize=True)
    normalized = model.encode(s)

    expected = X / np.linalg.norm(X)

    np.testing.assert_almost_equal(normalized, expected)


def test_save_pretrained(
    tmp_path: Path, mock_vectors: np.ndarray, mock_tokenizer: Tokenizer, mock_config: dict[str, str]
) -> None:
    """Test saving a pretrained model."""
    model = StaticModel(vectors=mock_vectors, tokenizer=mock_tokenizer, config=mock_config)

    # Save the model to the tmp_path
    save_path = tmp_path / "saved_model"
    model.save_pretrained(save_path)

    # Check that the save_path directory contains the saved files
    assert save_path.exists()

    assert (save_path / "model.safetensors").exists()
    assert (save_path / "tokenizer.json").exists()
    assert (save_path / "config.json").exists()
    assert (save_path / "modules.json").exists()


def test_load_pretrained(
    tmp_path: Path, mock_vectors: np.ndarray, mock_tokenizer: Tokenizer, mock_config: dict[str, str]
) -> None:
    """Test loading a pretrained model after saving it."""
    # Save the model to a temporary path
    model = StaticModel(vectors=mock_vectors, tokenizer=mock_tokenizer, config=mock_config)
    save_path = tmp_path / "saved_model"
    model.save_pretrained(save_path)

    # Load the model back from the same path
    loaded_model = StaticModel.from_pretrained(save_path)

    # Assert that the loaded model has the same properties as the original one
    np.testing.assert_array_equal(loaded_model.embedding, mock_vectors)
    assert loaded_model.tokenizer.get_vocab() == mock_tokenizer.get_vocab()
    for k, v in mock_config.items():
        assert loaded_model.config.get(k) == v
    assert "embedding_dtype" in loaded_model.config


def test_load_pretrained_quantized(
    tmp_path: Path, mock_vectors: np.ndarray, mock_tokenizer: Tokenizer, mock_config: dict[str, str]
) -> None:
    """Test loading a pretrained model after saving it."""
    # Save the model to a temporary path
    model = StaticModel(vectors=mock_vectors, tokenizer=mock_tokenizer, config=mock_config)
    save_path = tmp_path / "saved_model"
    model.save_pretrained(save_path)

    # Load the model back from the same path
    loaded_model = StaticModel.from_pretrained(save_path, quantize_to="int8")

    # Assert that the loaded model has the same properties as the original one
    assert loaded_model.embedding.dtype == np.int8
    assert loaded_model.embedding.shape == mock_vectors.shape
    assert loaded_model.embedding_dtype == "int8"

    # Load the model back from the same path
    loaded_model = StaticModel.from_pretrained(save_path, quantize_to="float16")

    # Assert that the loaded model has the same properties as the original one
    assert loaded_model.embedding.dtype == np.float16
    assert loaded_model.embedding.shape == mock_vectors.shape
    assert loaded_model.embedding_dtype == "float16"

    # Load the model back from the same path
    loaded_model = StaticModel.from_pretrained(save_path, quantize_to="float32")
    # Assert that the loaded model has the same properties as the original one
    assert loaded_model.embedding.dtype == np.float32
    assert loaded_model.embedding.shape == mock_vectors.shape
    assert loaded_model.embedding_dtype == "float32"

    # Load the model back from the same path
    loaded_model = StaticModel.from_pretrained(save_path, quantize_to="float64")
    # Assert that the loaded model has the same properties as the original one
    assert loaded_model.embedding.dtype == np.float64
    # Should not copy if same as original.
    assert loaded_model.embedding is loaded_model.embedding


def test_load_pretrained_dim(
    tmp_path: Path, mock_vectors: np.ndarray, mock_tokenizer: Tokenizer, mock_config: dict[str, str]
) -> None:
    """Test loading a pretrained model with dimensionality."""
    # Save the model to a temporary path
    model = StaticModel(vectors=mock_vectors, tokenizer=mock_tokenizer, config=mock_config)
    save_path = tmp_path / "saved_model"
    model.save_pretrained(save_path)

    loaded_model = StaticModel.from_pretrained(save_path, dimensionality=2)

    # Assert that the loaded model has the same properties as the original one
    np.testing.assert_array_equal(loaded_model.embedding, mock_vectors[:, :2])
    assert loaded_model.tokenizer.get_vocab() == mock_tokenizer.get_vocab()
    for k, v in mock_config.items():
        assert loaded_model.config.get(k) == v
    assert "embedding_dtype" in loaded_model.config

    # Load the model back from the same path
    loaded_model = StaticModel.from_pretrained(save_path, dimensionality=None)

    # Assert that the loaded model has the same properties as the original one
    np.testing.assert_array_equal(loaded_model.embedding, mock_vectors)
    assert loaded_model.tokenizer.get_vocab() == mock_tokenizer.get_vocab()
    for k, v in mock_config.items():
        assert loaded_model.config.get(k) == v
    assert "embedding_dtype" in loaded_model.config

    # Load the model back from the same path
    with pytest.raises(ValueError):
        StaticModel.from_pretrained(save_path, dimensionality=3000)


def test_load_pretrained_vocabulary_quantized(
    tmp_path: Path, mock_vectors: np.ndarray, mock_tokenizer: Tokenizer, mock_config: dict[str, str]
) -> None:
    """Test loading a pretrained model with vocabulary quantization."""
    # Save the model to a temporary path
    model = StaticModel(vectors=mock_vectors, tokenizer=mock_tokenizer, config=mock_config)
    save_path = tmp_path / "saved_model"
    model.save_pretrained(save_path)

    # Load the model back from the same path
    loaded_model = StaticModel.from_pretrained(save_path, vocabulary_quantization=3)

    # Assert that the loaded model has the same properties as the original one
    assert loaded_model.embedding.dtype == np.float64
    assert loaded_model.embedding.shape == (3, 2)  # Assuming 3 clusters after quantization
    assert loaded_model.weights is not None
    assert loaded_model.weights.shape == (5,)
    assert loaded_model.token_mapping is not None
    assert loaded_model.vocabulary_quantization == 3
    assert len(loaded_model.token_mapping) == mock_tokenizer.get_vocab_size()
    assert len(loaded_model.token_mapping) == len(loaded_model.weights)
    assert loaded_model.encode("word1 word2").shape == (2,)
    assert loaded_model.encode(["word1 word2"] * 4).shape == (4, 2)


def test_initialize_normalize(mock_vectors: np.ndarray, mock_tokenizer: Tokenizer) -> None:
    """Tests whether the normalization initialization is correct."""
    model = StaticModel(mock_vectors, mock_tokenizer, {}, normalize=None)
    assert not model.normalize

    model = StaticModel(mock_vectors, mock_tokenizer, {}, normalize=False)
    assert not model.normalize

    model = StaticModel(mock_vectors, mock_tokenizer, {}, normalize=True)
    assert model.normalize

    model = StaticModel(mock_vectors, mock_tokenizer, {"normalize": False}, normalize=True)
    assert model.normalize

    model = StaticModel(mock_vectors, mock_tokenizer, {"normalize": True}, normalize=False)
    assert not model.normalize


def test_set_normalize(mock_vectors: np.ndarray, mock_tokenizer: Tokenizer) -> None:
    """Tests whether the normalize is set correctly."""
    model = StaticModel(mock_vectors, mock_tokenizer, {}, normalize=True)
    model.normalize = False
    assert model.config == {"normalize": False}
    model.normalize = True
    assert model.config == {"normalize": True}


def test_dim(mock_vectors: np.ndarray, mock_tokenizer: Tokenizer, mock_config: dict[str, str]) -> None:
    """Tests the dimensionality of the model."""
    model = StaticModel(mock_vectors, mock_tokenizer, mock_config)
    assert model.dim == 2
    assert model.dim == model.embedding.shape[1]
