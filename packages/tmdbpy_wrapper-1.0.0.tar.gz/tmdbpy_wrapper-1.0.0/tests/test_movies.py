"""Tests for movies endpoint."""

import pytest

from tmdb_py import TMDB


@pytest.fixture
def tmdb():
    """Create TMDB client instance."""
    token = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI4YTkzMmVkYTgxZjVlYTZmN2M4YjUzMDc2YzRmMDM1OCIsIm5iZiI6MTc1Mjk1NTcwOC42NTkwMDAyLCJzdWIiOiI2ODdiZmIzYzAyMTNhNGY3MzUzOGQzOGEiLCJzY29wZXMiOlsiYXBpX3JlYWQiXSwidmVyc2lvbiI6MX0.sknSSTNsuv4ASZXmAcZ-dCmtO_iXGyj2tkHBIFyCRwE"
    return TMDB(token)


def test_movie_details(tmdb):
    """Test getting movie details."""
    # Fight Club
    movie = tmdb.movies.details(movie_id=550)

    assert movie["id"] == 550
    assert "title" in movie
    assert "overview" in movie
    assert "release_date" in movie
    assert "vote_average" in movie


def test_movie_details_with_append(tmdb):
    """Test getting movie details with append_to_response."""
    movie = tmdb.movies.details(movie_id=550, append_to_response=["credits", "videos"])

    assert "credits" in movie
    assert "videos" in movie
    assert "cast" in movie["credits"]
    assert "crew" in movie["credits"]


def test_movie_images(tmdb):
    """Test getting movie images."""
    images = tmdb.movies.images(movie_id=550)

    assert "backdrops" in images
    assert "posters" in images
    assert "logos" in images


def test_movie_reviews(tmdb):
    """Test getting movie reviews."""
    reviews = tmdb.movies.reviews(movie_id=550)

    assert "results" in reviews
    assert "page" in reviews
    assert "total_pages" in reviews


def test_movie_similar(tmdb):
    """Test getting similar movies."""
    similar = tmdb.movies.similar(movie_id=550)

    assert "results" in similar
    assert "page" in similar
    assert len(similar["results"]) > 0


def test_movie_videos(tmdb):
    """Test getting movie videos."""
    videos = tmdb.movies.videos(movie_id=550)

    assert "results" in videos


def test_movies_now_playing(tmdb):
    """Test getting now playing movies."""
    now_playing = tmdb.movies.now_playing()

    assert "results" in now_playing
    assert "page" in now_playing
    assert len(now_playing["results"]) > 0


def test_movies_popular(tmdb):
    """Test getting popular movies."""
    popular = tmdb.movies.popular()

    assert "results" in popular
    assert "page" in popular
    assert len(popular["results"]) > 0


def test_movies_top_rated(tmdb):
    """Test getting top rated movies."""
    top_rated = tmdb.movies.top_rated()

    assert "results" in top_rated
    assert "page" in top_rated
    assert len(top_rated["results"]) > 0
