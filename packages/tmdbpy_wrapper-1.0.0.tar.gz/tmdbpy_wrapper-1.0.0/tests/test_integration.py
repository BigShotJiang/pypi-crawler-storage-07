"""Integration tests for TMDB client."""

import pytest

from tmdb_py import TMDB, TMDBNotFoundError


@pytest.fixture
def tmdb():
    """Create TMDB client instance."""
    token = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI4YTkzMmVkYTgxZjVlYTZmN2M4YjUzMDc2YzRmMDM1OCIsIm5iZiI6MTc1Mjk1NTcwOC42NTkwMDAyLCJzdWIiOiI2ODdiZmIzYzAyMTNhNGY3MzUzOGQzOGEiLCJzY29wZXMiOlsiYXBpX3JlYWQiXSwidmVyc2lvbiI6MX0.sknSSTNsuv4ASZXmAcZ-dCmtO_iXGyj2tkHBIFyCRwE"
    return TMDB(token)


def test_complete_workflow(tmdb):
    """Test a complete workflow: search -> details -> similar."""
    # 1. Search for a movie
    search_results = tmdb.search.movies(query="The Matrix")
    assert len(search_results["results"]) > 0

    # 2. Get the first movie's ID
    movie_id = search_results["results"][0]["id"]

    # 3. Get detailed information
    movie = tmdb.movies.details(movie_id=movie_id, append_to_response=["credits", "videos"])
    assert "title" in movie
    assert "credits" in movie
    assert "videos" in movie

    # 4. Get similar movies
    similar = tmdb.movies.similar(movie_id=movie_id)
    assert len(similar["results"]) > 0


def test_tv_show_workflow(tmdb):
    """Test TV show workflow: search -> details -> season -> episode."""
    # 1. Search for a TV show
    search_results = tmdb.search.tv_shows(query="Breaking Bad")
    assert len(search_results["results"]) > 0

    # 2. Get TV show details
    tv_id = search_results["results"][0]["id"]
    tv_show = tmdb.tv_shows.details(tv_id=tv_id)
    assert "name" in tv_show

    # 3. Get season details
    season = tmdb.tv_seasons.details(tv_show_id=tv_id, season_number=1)
    assert "episodes" in season
    assert len(season["episodes"]) > 0

    # 4. Get episode details
    episode = tmdb.tv_episodes.details(tv_show_id=tv_id, season_number=1, episode_number=1)
    assert "name" in episode
    assert "overview" in episode


def test_trending_workflow(tmdb):
    """Test trending workflow."""
    # Get trending movies
    trending_movies = tmdb.trending.trending(media_type="movie", time_window="week")
    assert len(trending_movies["results"]) > 0

    # Get trending TV shows
    trending_tv = tmdb.trending.trending(media_type="tv", time_window="day")
    assert len(trending_tv["results"]) > 0

    # Get all trending
    trending_all = tmdb.trending.trending(media_type="all", time_window="week")
    assert len(trending_all["results"]) > 0


def test_genre_workflow(tmdb):
    """Test genre workflow."""
    # Get movie genres
    movie_genres = tmdb.genre.movies()
    assert "genres" in movie_genres
    assert len(movie_genres["genres"]) > 0

    # Get TV genres
    tv_genres = tmdb.genre.tv_shows()
    assert "genres" in tv_genres
    assert len(tv_genres["genres"]) > 0


def test_error_handling(tmdb):
    """Test error handling for non-existent movie."""
    with pytest.raises(TMDBNotFoundError):
        tmdb.movies.details(movie_id=999999999)


def test_all_endpoints_accessible(tmdb):
    """Test that all endpoints are accessible."""
    assert hasattr(tmdb, "search")
    assert hasattr(tmdb, "movies")
    assert hasattr(tmdb, "tv_shows")
    assert hasattr(tmdb, "tv_seasons")
    assert hasattr(tmdb, "tv_episodes")
    assert hasattr(tmdb, "trending")
    assert hasattr(tmdb, "genre")


def test_pagination(tmdb):
    """Test pagination in search results."""
    # Get page 1
    page1 = tmdb.movies.popular(page=1)
    assert page1["page"] == 1
    assert len(page1["results"]) > 0

    # Get page 2
    page2 = tmdb.movies.popular(page=2)
    assert page2["page"] == 2
    assert len(page2["results"]) > 0

    # Results should be different
    assert page1["results"][0]["id"] != page2["results"][0]["id"]
