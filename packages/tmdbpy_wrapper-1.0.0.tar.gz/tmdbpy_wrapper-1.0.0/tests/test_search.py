"""Tests for search endpoint."""

import pytest

from tmdb_py import TMDB


@pytest.fixture
def tmdb():
    """Create TMDB client instance."""
    token = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI4YTkzMmVkYTgxZjVlYTZmN2M4YjUzMDc2YzRmMDM1OCIsIm5iZiI6MTc1Mjk1NTcwOC42NTkwMDAyLCJzdWIiOiI2ODdiZmIzYzAyMTNhNGY3MzUzOGQzOGEiLCJzY29wZXMiOlsiYXBpX3JlYWQiXSwidmVyc2lvbiI6MX0.sknSSTNsuv4ASZXmAcZ-dCmtO_iXGyj2tkHBIFyCRwE"
    return TMDB(token)


def test_search_movies(tmdb):
    """Test searching for movies."""
    results = tmdb.search.movies(query="American Pie")

    assert "results" in results
    assert "page" in results
    assert "total_pages" in results
    assert "total_results" in results
    assert len(results["results"]) > 0

    # Check first result has expected fields
    first_movie = results["results"][0]
    assert "id" in first_movie
    assert "title" in first_movie
    assert "overview" in first_movie


def test_search_tv_shows(tmdb):
    """Test searching for TV shows."""
    results = tmdb.search.tv_shows(query="Breaking Bad")

    assert "results" in results
    assert "page" in results
    assert len(results["results"]) > 0

    first_show = results["results"][0]
    assert "id" in first_show
    assert "name" in first_show


def test_search_multi(tmdb):
    """Test multi search."""
    results = tmdb.search.multi(query="Tom Hanks")

    assert "results" in results
    assert "page" in results
    assert len(results["results"]) > 0

    # Results should contain mixed media types
    first_result = results["results"][0]
    assert "id" in first_result
    assert "media_type" in first_result
