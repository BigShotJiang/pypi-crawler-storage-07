"""Main TMDB client."""

from .endpoints.genre import GenreEndpoint
from .endpoints.movies import MoviesEndpoint
from .endpoints.search import SearchEndpoint
from .endpoints.trending import TrendingEndpoint
from .endpoints.tv_episodes import TvEpisodesEndpoint
from .endpoints.tv_seasons import TvSeasonsEndpoint
from .endpoints.tv_shows import TvShowsEndpoint


class TMDB:
    """Main TMDB API client."""

    def __init__(self, access_token: str):
        """
        Initialize the TMDB client.

        Args:
            access_token: TMDB API access token (Bearer token)

        Example:
            >>> tmdb = TMDB('your_access_token')
            >>> movies = tmdb.search.movies(query='American Pie')
        """
        self.access_token = access_token

    @property
    def search(self) -> SearchEndpoint:
        """Access search endpoints."""
        return SearchEndpoint(self.access_token)

    @property
    def movies(self) -> MoviesEndpoint:
        """Access movie endpoints."""
        return MoviesEndpoint(self.access_token)

    @property
    def tv_shows(self) -> TvShowsEndpoint:
        """Access TV show endpoints."""
        return TvShowsEndpoint(self.access_token)

    @property
    def tv_seasons(self) -> TvSeasonsEndpoint:
        """Access TV season endpoints."""
        return TvSeasonsEndpoint(self.access_token)

    @property
    def tv_episodes(self) -> TvEpisodesEndpoint:
        """Access TV episode endpoints."""
        return TvEpisodesEndpoint(self.access_token)

    @property
    def trending(self) -> TrendingEndpoint:
        """Access trending endpoints."""
        return TrendingEndpoint(self.access_token)

    @property
    def genre(self) -> GenreEndpoint:
        """Access genre endpoints."""
        return GenreEndpoint(self.access_token)
