"""Custom exceptions for TMDB API."""

from typing import Any, Dict, Optional


class TMDBException(Exception):
    """Base exception for TMDB API errors."""

    def __init__(self, message: str, status_code: Optional[int] = None, response: Optional[Dict[str, Any]] = None):
        self.message = message
        self.status_code = status_code
        self.response = response
        super().__init__(self.message)


class TMDBAuthenticationError(TMDBException):
    """Raised when authentication fails."""
    pass


class TMDBNotFoundError(TMDBException):
    """Raised when a resource is not found."""
    pass


class TMDBValidationError(TMDBException):
    """Raised when request validation fails."""
    pass


class TMDBRateLimitError(TMDBException):
    """Raised when rate limit is exceeded."""
    pass


class TMDBServerError(TMDBException):
    """Raised when server encounters an error."""
    pass
