"""Low-level HTTP client for TMDB API."""

from typing import Any, Dict, Optional
from urllib.parse import urlencode

import httpx

from .constants import BASE_URL_V3
from .exceptions import (
    TMDBAuthenticationError,
    TMDBException,
    TMDBNotFoundError,
    TMDBRateLimitError,
    TMDBServerError,
    TMDBValidationError,
)


class Api:
    """Low-level HTTP client for TMDB API."""

    def __init__(self, access_token: str):
        """
        Initialize the API client.

        Args:
            access_token: TMDB API access token (Bearer token)
        """
        self.access_token = access_token
        self._client: Optional[httpx.Client] = None

    @property
    def client(self) -> httpx.Client:
        """Get or create HTTP client."""
        if self._client is None:
            self._client = httpx.Client(
                headers={
                    "Authorization": f"Bearer {self.access_token}",
                    "Content-Type": "application/json;charset=utf-8",
                }
            )
        return self._client

    def _parse_options(self, options: Optional[Dict[str, Any]]) -> str:
        """
        Parse options dictionary to URL query string.

        Args:
            options: Dictionary of query parameters

        Returns:
            URL-encoded query string
        """
        if not options:
            return ""

        # Filter out None values
        filtered_options = {k: v for k, v in options.items() if v is not None}

        # Convert lists to comma-separated strings
        for key, value in filtered_options.items():
            if isinstance(value, list):
                filtered_options[key] = ",".join(str(v) for v in value)

        return urlencode(filtered_options)

    def _handle_error(self, response: httpx.Response) -> None:
        """
        Handle HTTP error responses.

        Args:
            response: HTTP response object

        Raises:
            TMDBException: Appropriate exception based on status code
        """
        try:
            error_data = response.json()
            message = error_data.get("status_message", "Unknown error")
        except Exception:
            message = response.text or "Unknown error"

        status_code = response.status_code

        if status_code == 401:
            raise TMDBAuthenticationError(message, status_code, error_data if 'error_data' in locals() else None)
        elif status_code == 404:
            raise TMDBNotFoundError(message, status_code, error_data if 'error_data' in locals() else None)
        elif status_code == 422:
            raise TMDBValidationError(message, status_code, error_data if 'error_data' in locals() else None)
        elif status_code == 429:
            raise TMDBRateLimitError(message, status_code, error_data if 'error_data' in locals() else None)
        elif status_code >= 500:
            raise TMDBServerError(message, status_code, error_data if 'error_data' in locals() else None)
        else:
            raise TMDBException(message, status_code, error_data if 'error_data' in locals() else None)

    def get(self, path: str, options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Make a GET request to TMDB API.

        Args:
            path: API endpoint path (e.g., '/search/movie')
            options: Query parameters

        Returns:
            JSON response as dictionary

        Raises:
            TMDBException: If request fails
        """
        params = self._parse_options(options)
        url = f"{BASE_URL_V3}{path}"
        if params:
            url = f"{url}?{params}"

        response = self.client.get(url)

        if not response.is_success:
            self._handle_error(response)

        return response.json()

    def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            self._client.close()
            self._client = None

    def __enter__(self) -> "Api":
        """Context manager entry."""
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Context manager exit."""
        self.close()
