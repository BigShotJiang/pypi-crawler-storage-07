"""TMDB Python API wrapper."""

from .client import TMDB
from .exceptions import (
    TMDBAuthenticationError,
    TMDBException,
    TMDBNotFoundError,
    TMDBRateLimitError,
    TMDBServerError,
    TMDBValidationError,
)

__version__ = "1.0.0"

__all__ = [
    "TMDB",
    "TMDBException",
    "TMDBAuthenticationError",
    "TMDBNotFoundError",
    "TMDBValidationError",
    "TMDBRateLimitError",
    "TMDBServerError",
]
