"""TV seasons endpoint implementation."""

from typing import Any, Dict, List, Optional

from .base import BaseEndpoint
from ..models.tv_shows import SeasonDetails
from ..models.common import Images, Videos


class TvSeasonsEndpoint(BaseEndpoint):
    """TV seasons endpoint for TMDB API with type safety."""

    def _base_season(self, tv_show_id: int, season_number: int) -> str:
        """Generate base URL for season endpoints."""
        return f"/tv/{tv_show_id}/season/{season_number}"

    def details(
        self,
        tv_show_id: int,
        season_number: int,
        append_to_response: Optional[List[str]] = None,
        language: Optional[str] = None,
    ) -> SeasonDetails:
        """Get TV season details with type safety."""
        options = {
            "append_to_response": ",".join(append_to_response) if append_to_response else None,
            "language": language,
        }
        data = self.api.get(self._base_season(tv_show_id, season_number), options)
        return SeasonDetails(**data)

    def images(
        self,
        tv_show_id: int,
        season_number: int,
        language: Optional[str] = None,
        include_image_language: Optional[List[str]] = None,
    ) -> Images:
        """Get TV season images with type safety."""
        options = {
            "language": language,
            "include_image_language": ",".join(include_image_language)
            if include_image_language
            else None,
        }
        data = self.api.get(f"{self._base_season(tv_show_id, season_number)}/images", options)
        return Images(**data)

    def videos(
        self,
        tv_show_id: int,
        season_number: int,
        language: Optional[str] = None,
        include_video_language: Optional[List[str]] = None,
    ) -> Videos:
        """Get TV season videos with type safety."""
        options = {
            "language": language,
            "include_video_language": ",".join(include_video_language)
            if include_video_language
            else None,
        }
        data = self.api.get(f"{self._base_season(tv_show_id, season_number)}/videos", options)
        return Videos(**data)
