"""Endpoints package."""

from .base import BaseEndpoint
from .genre import GenreEndpoint, get_genre_name
from .movies import MoviesEndpoint
from .search import SearchEndpoint
from .trending import TrendingEndpoint
from .tv_episodes import TvEpisodesEndpoint
from .tv_seasons import TvSeasonsEndpoint
from .tv_shows import TvShowsEndpoint

__all__ = [
    "BaseEndpoint",
    "SearchEndpoint",
    "MoviesEndpoint",
    "TvShowsEndpoint",
    "TvSeasonsEndpoint",
    "TvEpisodesEndpoint",
    "TrendingEndpoint",
    "GenreEndpoint",
    "get_genre_name",
]
