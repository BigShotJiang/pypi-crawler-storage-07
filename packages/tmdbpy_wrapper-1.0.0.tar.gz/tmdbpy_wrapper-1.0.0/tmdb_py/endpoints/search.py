"""Search endpoint implementation."""

from typing import Any, Dict, Optional

from .base import BaseEndpoint
from ..models.common import PaginatedResponse
from ..models.movies import Movie
from ..models.tv_shows import TvShow
from ..models.search import MultiSearchResult


class SearchEndpoint(BaseEndpoint):
    """
    Search endpoint for TMDB API.

    Provides methods to search for movies, TV shows, and multi-content.
    """

    BASE_SEARCH = "/search"

    def movies(
        self,
        query: str,
        page: Optional[int] = None,
        language: Optional[str] = None,
        region: Optional[str] = None,
        include_adult: Optional[bool] = None,
        year: Optional[int] = None,
        primary_release_year: Optional[int] = None,
    ) -> PaginatedResponse[Movie]:
        """
        Search for movies.

        Args:
            query: Search query string
            page: Page number (default: 1)
            language: ISO 639-1 language code (e.g., 'en-US')
            region: ISO 3166-1 region code
            include_adult: Include adult content in results
            year: Filter by year
            primary_release_year: Filter by primary release year

        Returns:
            PaginatedResponse containing Movie objects

        Example:
            >>> endpoint = SearchEndpoint('token')
            >>> results = endpoint.movies(query='American Pie')
            >>> for movie in results.results:
            >>>     print(movie.title)
        """
        options = {
            "query": query,
            "page": page,
            "language": language,
            "region": region,
            "include_adult": include_adult,
            "year": year,
            "primary_release_year": primary_release_year,
        }
        data = self.api.get(f"{self.BASE_SEARCH}/movie", options)
        return PaginatedResponse[Movie](**data)

    def tv_shows(
        self,
        query: str,
        page: Optional[int] = None,
        language: Optional[str] = None,
        include_adult: Optional[bool] = None,
        year: Optional[int] = None,
        first_air_date_year: Optional[int] = None,
    ) -> PaginatedResponse[TvShow]:
        """
        Search for TV shows.

        Args:
            query: Search query string
            page: Page number (default: 1)
            language: ISO 639-1 language code (e.g., 'en-US')
            include_adult: Include adult content in results
            year: Filter by year
            first_air_date_year: Filter by first air date year

        Returns:
            PaginatedResponse containing TvShow objects

        Example:
            >>> endpoint = SearchEndpoint('token')
            >>> results = endpoint.tv_shows(query='Breaking Bad')
            >>> for show in results.results:
            >>>     print(show.name)
        """
        options = {
            "query": query,
            "page": page,
            "language": language,
            "include_adult": include_adult,
            "year": year,
            "first_air_date_year": first_air_date_year,
        }
        data = self.api.get(f"{self.BASE_SEARCH}/tv", options)
        return PaginatedResponse[TvShow](**data)

    def multi(
        self,
        query: str,
        page: Optional[int] = None,
        language: Optional[str] = None,
        include_adult: Optional[bool] = None,
    ) -> PaginatedResponse[MultiSearchResult]:
        """
        Multi-search for movies, TV shows, and people.

        Args:
            query: Search query string
            page: Page number (default: 1)
            language: ISO 639-1 language code (e.g., 'en-US')
            include_adult: Include adult content in results

        Returns:
            PaginatedResponse containing MultiSearchResult objects

        Example:
            >>> endpoint = SearchEndpoint('token')
            >>> results = endpoint.multi(query='Tom Hanks')
            >>> for result in results.results:
            >>>     print(result)
        """
        options = {
            "query": query,
            "page": page,
            "language": language,
            "include_adult": include_adult,
        }
        data = self.api.get(f"{self.BASE_SEARCH}/multi", options)
        return PaginatedResponse[MultiSearchResult](**data)
