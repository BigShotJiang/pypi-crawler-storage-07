"""Base endpoint class."""

from ..api import Api


class BaseEndpoint:
    """Base class for all endpoint classes."""

    def __init__(self, access_token: str):
        """
        Initialize the base endpoint.

        Args:
            access_token: TMDB API access token
        """
        self.access_token = access_token
        self.api = Api(access_token)
