"""Genre endpoint implementation."""

from typing import Optional

from .base import BaseEndpoint
from ..models.common import GenresResponse

# Genre mapping (same as in tmdb-ts)
GENRES = {
    28: "Action",
    12: "Adventure",
    16: "Animation",
    35: "Comedy",
    80: "Crime",
    99: "Documentary",
    18: "Drama",
    10751: "Family",
    14: "Fantasy",
    36: "History",
    27: "Horror",
    10402: "Music",
    9648: "Mystery",
    10749: "Romance",
    878: "Science Fiction",
    10770: "TV Movie",
    53: "Thriller",
    10752: "War",
    37: "Western",
    10759: "Action & Adventure",
    10762: "Kids",
    10763: "News",
    10764: "Reality",
    10765: "Sci-Fi & Fantasy",
    10766: "Soap",
    10767: "Talk",
    10768: "War & Politics",
}


class GenreEndpoint(BaseEndpoint):
    """
    Genre endpoint for TMDB API.

    Provides methods to get genre lists for movies and TV shows.
    """

    def movies(self, language: Optional[str] = None) -> GenresResponse:
        """
        Get the list of official genres for movies.

        Args:
            language: ISO 639-1 language code (e.g., 'en-US')

        Returns:
            GenresResponse containing movie genres with type safety

        Example:
            >>> endpoint = GenreEndpoint('token')
            >>> genres = endpoint.movies()
            >>> for genre in genres.genres:
            ...     print(f"{genre.id}: {genre.name}")
        """
        options = {"language": language}
        data = self.api.get("/genre/movie/list", options)
        return GenresResponse(**data)

    def tv_shows(self, language: Optional[str] = None) -> GenresResponse:
        """
        Get the list of official genres for TV shows.

        Args:
            language: ISO 639-1 language code (e.g., 'en-US')

        Returns:
            GenresResponse containing TV show genres with type safety

        Example:
            >>> endpoint = GenreEndpoint('token')
            >>> genres = endpoint.tv_shows()
            >>> for genre in genres.genres:
            ...     print(f"{genre.id}: {genre.name}")
        """
        options = {"language": language}
        data = self.api.get("/genre/tv/list", options)
        return GenresResponse(**data)


def get_genre_name(genre_id: int) -> Optional[str]:
    """
    Get genre name by ID.

    Args:
        genre_id: Genre ID

    Returns:
        Genre name or None if not found

    Example:
        >>> name = get_genre_name(28)
        >>> print(name)  # "Action"
    """
    return GENRES.get(genre_id)
