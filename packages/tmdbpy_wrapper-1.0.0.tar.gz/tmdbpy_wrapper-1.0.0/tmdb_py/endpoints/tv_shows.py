"""TV shows endpoint implementation."""

from typing import Any, Dict, List, Optional

from .base import BaseEndpoint
from ..models.tv_shows import TvShow, TvShowDetails, SeasonDetails
from ..models.common import Images, Videos, PaginatedResponse


class TvShowsEndpoint(BaseEndpoint):
    """TV shows endpoint for TMDB API with type safety."""

    BASE_TV = "/tv"

    def details(
        self,
        tv_id: int,
        append_to_response: Optional[List[str]] = None,
        language: Optional[str] = None,
    ) -> TvShowDetails:
        """Get TV show details with type safety."""
        options = {
            "append_to_response": ",".join(append_to_response) if append_to_response else None,
            "language": language,
        }
        data = self.api.get(f"{self.BASE_TV}/{tv_id}", options)
        return TvShowDetails(**data)

    def season(self, tv_id: int, season_number: int) -> SeasonDetails:
        """Get TV show season details with type safety."""
        data = self.api.get(f"{self.BASE_TV}/{tv_id}/season/{season_number}")
        return SeasonDetails(**data)

    def images(
        self,
        tv_id: int,
        language: Optional[str] = None,
        include_image_language: Optional[List[str]] = None,
    ) -> Images:
        """Get TV show images with type safety."""
        options = {
            "language": language,
            "include_image_language": ",".join(include_image_language)
            if include_image_language
            else None,
        }
        data = self.api.get(f"{self.BASE_TV}/{tv_id}/images", options)
        return Images(**data)

    def similar(
        self,
        tv_id: int,
        language: Optional[str] = None,
        page: Optional[int] = None,
    ) -> PaginatedResponse[TvShow]:
        """Get similar TV shows with type safety."""
        options = {"language": language, "page": page}
        data = self.api.get(f"{self.BASE_TV}/{tv_id}/similar", options)
        return PaginatedResponse[TvShow](**data)

    def videos(
        self,
        tv_id: int,
        language: Optional[str] = None,
        include_video_language: Optional[List[str]] = None,
    ) -> Videos:
        """Get TV show videos with type safety."""
        options = {
            "language": language,
            "include_video_language": ",".join(include_video_language)
            if include_video_language
            else None,
        }
        data = self.api.get(f"{self.BASE_TV}/{tv_id}/videos", options)
        return Videos(**data)

    def on_the_air(
        self,
        language: Optional[str] = None,
        page: Optional[int] = None,
        timezone: Optional[str] = None,
    ) -> PaginatedResponse[TvShow]:
        """Get TV shows currently on the air with type safety."""
        options = {"language": language, "page": page, "timezone": timezone}
        data = self.api.get(f"{self.BASE_TV}/on_the_air", options)
        return PaginatedResponse[TvShow](**data)

    def popular(
        self,
        language: Optional[str] = None,
        page: Optional[int] = None,
    ) -> PaginatedResponse[TvShow]:
        """Get popular TV shows with type safety."""
        options = {"language": language, "page": page}
        data = self.api.get(f"{self.BASE_TV}/popular", options)
        return PaginatedResponse[TvShow](**data)

    def top_rated(
        self,
        language: Optional[str] = None,
        page: Optional[int] = None,
    ) -> PaginatedResponse[TvShow]:
        """Get top rated TV shows with type safety."""
        options = {"language": language, "page": page}
        data = self.api.get(f"{self.BASE_TV}/top_rated", options)
        return PaginatedResponse[TvShow](**data)
