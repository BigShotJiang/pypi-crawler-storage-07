"""Movies endpoint implementation."""

from typing import Any, Dict, List, Optional

from .base import BaseEndpoint
from ..models.movies import Movie, MovieDetails, MoviesPlayingNow
from ..models.common import Images, Videos, Reviews, PaginatedResponse


class MoviesEndpoint(BaseEndpoint):
    """
    Movies endpoint for TMDB API.

    Provides methods to get movie details, images, reviews, and lists.
    """

    BASE_MOVIE = "/movie"

    def details(
        self,
        movie_id: int,
        append_to_response: Optional[List[str]] = None,
        language: Optional[str] = None,
    ) -> MovieDetails:
        """Get movie details with type safety."""
        options = {
            "append_to_response": ",".join(append_to_response) if append_to_response else None,
            "language": language,
        }
        data = self.api.get(f"{self.BASE_MOVIE}/{movie_id}", options)
        return MovieDetails(**data)

    def images(
        self,
        movie_id: int,
        language: Optional[str] = None,
        include_image_language: Optional[List[str]] = None,
    ) -> Images:
        """Get movie images with type safety."""
        options = {
            "language": language,
            "include_image_language": ",".join(include_image_language)
            if include_image_language
            else None,
        }
        data = self.api.get(f"{self.BASE_MOVIE}/{movie_id}/images", options)
        return Images(**data)

    def reviews(
        self,
        movie_id: int,
        language: Optional[str] = None,
        page: Optional[int] = None,
    ) -> Reviews:
        """Get movie reviews with type safety."""
        options = {"language": language, "page": page}
        data = self.api.get(f"{self.BASE_MOVIE}/{movie_id}/reviews", options)
        return Reviews(**data)

    def similar(
        self,
        movie_id: int,
        language: Optional[str] = None,
        page: Optional[int] = None,
    ) -> PaginatedResponse[Movie]:
        """Get similar movies with type safety."""
        options = {"language": language, "page": page}
        data = self.api.get(f"{self.BASE_MOVIE}/{movie_id}/similar", options)
        return PaginatedResponse[Movie](**data)

    def videos(
        self,
        movie_id: int,
        language: Optional[str] = None,
    ) -> Videos:
        """Get movie videos with type safety."""
        options = {"language": language}
        data = self.api.get(f"{self.BASE_MOVIE}/{movie_id}/videos", options)
        return Videos(**data)

    def now_playing(
        self,
        language: Optional[str] = None,
        page: Optional[int] = None,
        region: Optional[str] = None,
    ) -> MoviesPlayingNow:
        """Get movies now playing with type safety."""
        options = {"language": language, "page": page, "region": region}
        data = self.api.get(f"{self.BASE_MOVIE}/now_playing", options)
        return MoviesPlayingNow(**data)

    def popular(
        self,
        language: Optional[str] = None,
        page: Optional[int] = None,
    ) -> PaginatedResponse[Movie]:
        """Get popular movies with type safety."""
        options = {"language": language, "page": page}
        data = self.api.get(f"{self.BASE_MOVIE}/popular", options)
        return PaginatedResponse[Movie](**data)

    def top_rated(
        self,
        language: Optional[str] = None,
        page: Optional[int] = None,
        region: Optional[str] = None,
    ) -> PaginatedResponse[Movie]:
        """Get top rated movies with type safety."""
        options = {"language": language, "page": page, "region": region}
        data = self.api.get(f"{self.BASE_MOVIE}/top_rated", options)
        return PaginatedResponse[Movie](**data)
