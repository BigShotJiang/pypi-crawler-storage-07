"""Trending endpoint implementation."""

from typing import Literal, Optional

from .base import BaseEndpoint
from ..models.trending import TrendingResult
from ..models.common import PaginatedResponse


class TrendingEndpoint(BaseEndpoint):
    """Trending endpoint for TMDB API with type safety."""

    def trending(
        self,
        media_type: Literal["all", "movie", "tv", "person"],
        time_window: Literal["day", "week"],
        language: Optional[str] = None,
        page: Optional[int] = None,
    ) -> PaginatedResponse[TrendingResult]:
        """Get trending content with type safety."""
        options = {"language": language, "page": page}
        data = self.api.get(f"/trending/{media_type}/{time_window}", options)
        return PaginatedResponse[TrendingResult](**data)
