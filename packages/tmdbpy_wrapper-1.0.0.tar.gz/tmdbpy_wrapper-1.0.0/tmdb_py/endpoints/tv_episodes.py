"""TV episodes endpoint implementation."""

from typing import Any, Dict, List, Optional

from .base import BaseEndpoint
from ..models.tv_shows import Episode
from ..models.common import Images, Videos


class TvEpisodesEndpoint(BaseEndpoint):
    """TV episodes endpoint for TMDB API with type safety."""

    def _base_episode(self, tv_show_id: int, season_number: int, episode_number: int) -> str:
        """Generate base URL for episode endpoints."""
        return f"/tv/{tv_show_id}/season/{season_number}/episode/{episode_number}"

    def details(
        self,
        tv_show_id: int,
        season_number: int,
        episode_number: int,
        append_to_response: Optional[List[str]] = None,
        language: Optional[str] = None,
    ) -> Episode:
        """Get TV episode details with type safety."""
        options = {
            "append_to_response": ",".join(append_to_response) if append_to_response else None,
            "language": language,
        }
        data = self.api.get(self._base_episode(tv_show_id, season_number, episode_number), options)
        return Episode(**data)

    def images(
        self,
        tv_show_id: int,
        season_number: int,
        episode_number: int,
        language: Optional[str] = None,
        include_image_language: Optional[List[str]] = None,
    ) -> Images:
        """Get TV episode images with type safety."""
        options = {
            "language": language,
            "include_image_language": ",".join(include_image_language)
            if include_image_language
            else None,
        }
        data = self.api.get(f"{self._base_episode(tv_show_id, season_number, episode_number)}/images", options)
        return Images(**data)

    def videos(
        self,
        tv_show_id: int,
        season_number: int,
        episode_number: int,
        language: Optional[str] = None,
        include_video_language: Optional[List[str]] = None,
    ) -> Videos:
        """Get TV episode videos with type safety."""
        options = {
            "language": language,
            "include_video_language": ",".join(include_video_language)
            if include_video_language
            else None,
        }
        data = self.api.get(f"{self._base_episode(tv_show_id, season_number, episode_number)}/videos", options)
        return Videos(**data)
