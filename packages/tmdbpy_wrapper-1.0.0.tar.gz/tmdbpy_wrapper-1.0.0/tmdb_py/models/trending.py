"""Trending-related models."""

from typing import Literal, Union

from .movies import MovieWithMediaType
from .people import PersonWithMediaType
from .tv_shows import TvShowWithMediaType

TrendingMediaType = Literal["all", "movie", "tv", "person"]
TimeWindow = Literal["day", "week"]

TrendingResult = Union[MovieWithMediaType, TvShowWithMediaType, PersonWithMediaType]
