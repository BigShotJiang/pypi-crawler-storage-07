"""Person-related models."""

from typing import List, Optional, Union
from .movies import Movie, MovieWithMediaType
from .tv_shows import TvShow, TvShowWithMediaType
from pydantic import BaseModel, Field


class Person(BaseModel):
    """Person model."""

    adult: bool
    gender: int
    id: int
    known_for_department: str
    name: str
    original_name: str
    popularity: float
    profile_path: Optional[str] = None
    known_for: List[Union[Movie, TvShow]] = Field(default_factory=list)


class PersonWithMediaType(Person):
    """Person model with media_type field for multi-search and trending."""

    media_type: str = "person"
    known_for: List[Union[MovieWithMediaType, TvShowWithMediaType]] = Field(default_factory=list)



