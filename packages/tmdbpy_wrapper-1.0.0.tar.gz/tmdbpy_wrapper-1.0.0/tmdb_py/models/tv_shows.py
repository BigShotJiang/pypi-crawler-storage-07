"""TV show-related models."""

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from .common import Genre, ProductionCompany, ProductionCountry, SpokenLanguage


class Network(BaseModel):
    """Network model."""

    id: int
    logo_path: Optional[str] = None
    name: str
    origin_country: str


class CreatedBy(BaseModel):
    """Creator model."""

    id: int
    credit_id: str
    name: str
    gender: int
    profile_path: Optional[str] = None


class Season(BaseModel):
    """Season model."""

    air_date: Optional[str] = None
    episode_count: int
    id: int
    name: str
    overview: str
    poster_path: Optional[str] = None
    season_number: int


class Episode(BaseModel):
    """Episode model."""

    air_date: Optional[str] = None
    episode_number: int
    id: int
    name: str
    overview: str
    production_code: str
    runtime: Optional[int] = None
    season_number: int
    still_path: Optional[str] = None
    vote_average: float
    vote_count: int


class TvShowBase(BaseModel):
    """Base TV show model with common fields."""

    adult: bool
    backdrop_path: Optional[str] = None
    first_air_date: Optional[str] = None
    id: int
    name: str
    origin_country: List[str] = Field(default_factory=list)
    original_language: str
    original_name: str
    overview: str
    popularity: float
    poster_path: Optional[str] = None
    vote_average: float
    vote_count: int


class TvShow(TvShowBase):
    """Basic TV show model with genre IDs."""

    genre_ids: List[int] = Field(default_factory=list)


class TvShowWithMediaType(TvShow):
    """TV show model with media_type field for multi-search and trending."""

    media_type: str = "tv"


class TvShowDetails(TvShowBase):
    """Detailed TV show model with full genre objects and additional fields."""

    created_by: List[CreatedBy] = Field(default_factory=list)
    episode_run_time: List[int] = Field(default_factory=list)
    genres: List[Genre] = Field(default_factory=list)
    homepage: str
    in_production: bool
    languages: List[str] = Field(default_factory=list)
    last_air_date: Optional[str] = None
    last_episode_to_air: Optional[Episode] = None
    next_episode_to_air: Optional[Episode] = None
    networks: List[Network] = Field(default_factory=list)
    number_of_episodes: int
    number_of_seasons: int
    production_companies: List[ProductionCompany] = Field(default_factory=list)
    production_countries: List[ProductionCountry] = Field(default_factory=list)
    seasons: List[Season] = Field(default_factory=list)
    spoken_languages: List[SpokenLanguage] = Field(default_factory=list)
    status: str
    tagline: str
    type: str


class SeasonDetails(BaseModel):
    """Detailed season model."""

    _id: str
    air_date: Optional[str] = None
    episodes: List[Episode] = Field(default_factory=list)
    name: str
    overview: str
    id: int
    poster_path: Optional[str] = None
    season_number: int
