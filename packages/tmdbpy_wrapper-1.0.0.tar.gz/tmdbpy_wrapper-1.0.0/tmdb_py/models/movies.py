"""Movie-related models."""

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from .common import Genre, ProductionCompany, ProductionCountry, SpokenLanguage


class MovieBase(BaseModel):
    """Base movie model with common fields."""

    adult: bool
    backdrop_path: Optional[str] = None
    id: int
    original_language: str
    original_title: str
    overview: str
    popularity: float
    poster_path: Optional[str] = None
    release_date: str
    title: str
    video: bool
    vote_average: float
    vote_count: int


class Movie(MovieBase):
    """Basic movie model with genre IDs."""

    genre_ids: List[int] = Field(default_factory=list)


class MovieWithMediaType(Movie):
    """Movie model with media_type field for multi-search and trending."""

    media_type: str = "movie"


class MovieDetails(MovieBase):
    """Detailed movie model with full genre objects and additional fields."""

    belongs_to_collection: Optional[Dict[str, Any]] = None
    budget: int
    genres: List[Genre] = Field(default_factory=list)
    homepage: Optional[str] = None
    imdb_id: Optional[str] = None
    production_companies: List[ProductionCompany] = Field(default_factory=list)
    production_countries: List[ProductionCountry] = Field(default_factory=list)
    revenue: int
    runtime: Optional[int] = None
    spoken_languages: List[SpokenLanguage] = Field(default_factory=list)
    status: str
    tagline: Optional[str] = None
    origin_country: List[str] = Field(default_factory=list)


class MoviesPlayingNow(BaseModel):
    """Movies playing now response model with dates."""

    page: int
    results: List[Movie] = Field(default_factory=list)
    dates: Dict[str, str] = {}
    total_pages: int
    total_results: int
