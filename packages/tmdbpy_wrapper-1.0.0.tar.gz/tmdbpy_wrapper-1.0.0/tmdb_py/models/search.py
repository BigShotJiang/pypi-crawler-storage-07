"""Search-related models."""

from typing import Union

from .movies import MovieWithMediaType
from .people import PersonWithMediaType
from .tv_shows import TvShowWithMediaType

MultiSearchResult = Union[MovieWithMediaType, TvShowWithMediaType, PersonWithMediaType]
