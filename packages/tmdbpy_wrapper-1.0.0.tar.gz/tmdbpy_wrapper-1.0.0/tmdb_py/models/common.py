"""Common models and types used across endpoints."""

from typing import Any, Dict, Generic, List, Optional, TypeVar

from pydantic import BaseModel, Field

T = TypeVar("T")


class Genre(BaseModel):
    """Genre model."""

    id: int
    name: str


class GenresResponse(BaseModel):
    """Genres API response model."""

    genres: List[Genre]


class SpokenLanguage(BaseModel):
    """Spoken language model."""

    english_name: str
    iso_639_1: str
    name: str


class ProductionCompany(BaseModel):
    """Production company model."""

    id: int
    logo_path: Optional[str] = None
    name: str
    origin_country: str


class ProductionCountry(BaseModel):
    """Production country model."""

    iso_3166_1: str
    name: str


class Image(BaseModel):
    """Image model."""

    aspect_ratio: float
    height: int
    iso_639_1: Optional[str] = None
    file_path: str
    vote_average: float
    vote_count: int
    width: int


class Images(BaseModel):
    """Images collection model."""

    backdrops: List[Image] = Field(default_factory=list)
    logos: List[Image] = Field(default_factory=list)
    posters: List[Image] = Field(default_factory=list)
    id: int
    stills: List[Image] = Field(default_factory=list)


class Video(BaseModel):
    """Video model."""

    iso_639_1: str
    iso_3166_1: str
    name: str
    key: str
    site: str
    size: int
    type: str
    official: bool
    published_at: str
    id: str


class Videos(BaseModel):
    """Videos collection model."""

    results: List[Video] = Field(default_factory=list)
    id: int


class ReviewAuthorDetails(BaseModel):
    """Review author details model."""

    name: str
    username: str
    avatar_path: Optional[str] = None
    rating: Optional[float] = None


class Review(BaseModel):
    """Review model."""

    author: str
    author_details: ReviewAuthorDetails
    content: str
    created_at: str
    id: str
    updated_at: str
    url: str


class Reviews(BaseModel):
    """Reviews collection model."""

    page: int
    results: List[Review] = Field(default_factory=list)
    total_pages: int
    total_results: int
    id: int


class PaginatedResponse(BaseModel, Generic[T]):
    """Generic paginated response model."""

    page: int
    results: List[T]
    total_pages: int
    total_results: int
