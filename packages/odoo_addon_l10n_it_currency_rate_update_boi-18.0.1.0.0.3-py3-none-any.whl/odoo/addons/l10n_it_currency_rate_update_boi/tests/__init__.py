from . import test_currency_rate_update_boi
