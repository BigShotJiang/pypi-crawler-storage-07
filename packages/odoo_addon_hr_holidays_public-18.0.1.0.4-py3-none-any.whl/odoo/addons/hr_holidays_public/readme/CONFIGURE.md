Go to *Time Off -\> Configuration -\> Time Off Types* and open a Leave
Type

- Check "Exclude Public Holidays" to exclude public holidays.
