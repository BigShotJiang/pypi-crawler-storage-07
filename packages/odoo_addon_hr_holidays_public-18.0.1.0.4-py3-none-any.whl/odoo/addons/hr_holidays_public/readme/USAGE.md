For adding public holidays:

1.  Go to the menu *Calendar \> Configuration > Public Holidays \> Public Holidays*.
2.  Create your public holidays.

For using public holidays on leaves:

1.  Go to *Time Off \> Dashboard*.
2.  Select dragging on the calendar the days you want to be on leave, or
    go to the form view for selecting start and end dates.
3.  Select the proper "Leave Type" that has "Exclude Public Holidays"
    checked.
4.  If no leave type is yet specified, then default configuration is to
    exclude public holidays.
5.  The number of days will be computed excluding public holidays that
    match the selected employee, including global, country and state
    holidays.
6.  If no employee is yet selected, only global holidays will be taken
    into account.

In calendar views in HR holiday app public will be display (likes other
unusual days) according the current user employee country/state. If not
set the there is a fallback to the current company country/state to
filter public holidays.
