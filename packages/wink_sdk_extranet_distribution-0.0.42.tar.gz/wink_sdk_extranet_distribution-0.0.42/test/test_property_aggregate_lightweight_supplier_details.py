# coding: utf-8

"""
    Wink API

     # Introduction  Welcome to the Wink API - A programmer-friendly way to manage, sell and book travel inventory on the Wink platform. The API gives you all the tools you need to ready your properties and inventory for sale across 1000s of our native sales channels.  Integrators, affiliates, travel agents and content creators have the ability search for your travel inventory and promote / sell it in a wide variety of ways.   # Integrations  We have already integrated with the most well-known channel managers so you don't have to. To see our current integrations, please go to https://extranet.wink.travel and scroll to Connectivity section. Once your properties are set up, you can finish the setup by mapping your property to Wink using your channel manager partner portal. If your properties don't have a channel manager, you can easily manage rates and availability with this API.   # Intended Audience  Programmers are [most likely] a requirement to start integrating with Wink. Companies and organizations that would most benefit from integrating with us are new and existing travel companies that have relationships with suppliers and that need an advanced system from which to manage their travel inventory and get that same inventory out to as many eyeballs as possible at the lowest price possible.  - Hotel chains  - Hotel brands  - Travel tech companies  - Destination sites  - Integrators  - Aggregators  - Destination management companies  - Travel agencies  - OTAs   ## APIs  Not every integrator needs every API. For that reason, we have separated APIs into context.  ### Test API   - [Ping](/ping): The Ping API is a quick test endpoint to verify that your credentials work Wink.  ### Common APIs  - [Notifications](/notifications): The Notifications API is a way for us to stay in touch with your user, property or affiliate account. - [User Settings](/user-settings): The User Settings API exposes endpoints to allow 3rd party integrators to communicate with Wink.  ### Consume APIs Consume endpoints are for developers who want to find existing travel inventory and either book it or use it to advertise through one of their Wink affiliate accounts.   - [Configuration](/customization-client): A single endpoint to retrieve whitelabel + customization information for the booking customization.  - [Lookup](/lookup): All APIs related to locating inventory by region, locale and property flags.  - [Inventory](/inventory): All APIs related to retrieve known travel inventory as it was found using the Lookup API..  - [Booking](/booking): All APIs related to creating bookings on the platform.  - [Travel Agent](/travel-agent): The Travel Agent API exposes endpoints to manage agent-facilitated bookings.   ### Produce APIs  Produce endpoints are for developers who want to create and manage travel inventory.   #### Property  - [Property registration](/extranet/property/register): As a producer, this is, oftentimes, where you start your journey. These endpoints let you create properties on Wink.  - [Property](/extranet/property): This collection of property endpoints are mostly management endpoints that let you display, change status and similar for your existing properties.  - [Facilities](/extranet/facilities): This collection of endpoints let you manage facilities; such as room types.  - [Experiences](/extranet/experiences): This collection of endpoints let you manage experiences, such as activities.  - [Monetize](/extranet/monetize): The Monetize API exposes endpoints for managing cancellation polies, rate plans, promotions and more on Wink.  - [Distribution](/extranet/distribution): The Distribution API exposes endpoints for sales channels, connecting with affiliates, managing rates and inventory calendars and more on Wink.  - [Property Booking](/extranet/booking): The Property Booking API exposes endpoints for managing bookings and reviews at the property-level.   #### Affiliate  - [Affiliate](/affiliate): This collection of affiliate endpoints are mostly management endpoints that let you display, change status and similar for your existing accounts.  - [Browse](/affiliate/browse): The Browse API exposes endpoints for affiliates to find suppliers and inventory to sell.  - [Inventory](/affiliate/inventory): The Inventory API exposes endpoints for affiliates to manage the inventory they want to sell and how they want to sell it.  - [Sales Channel](/affiliate/sales-channel): The Sales Channel API exposes endpoints for affiliates to manage existing sales channels as well as find new ones.  - [WinkLinks](/affiliate/winklinks): The WinkLinks API exposes endpoints for affiliates to manage their WinkLinks page.   #### Rate provider  - [Channel manager](/channel-manager): The Channel Manager API enables external channel manager partners to map, exchange rate / availability information with us as well as be informed of bookings that occur on the Wink platform for one of their properties.   ### Taxonomy APIs  Taxonomy endpoints are for developers who want to consume and produce travel inventory and need taxonomies of standard and non-standard codes for inventory types, classes, statuses etc.   - [Reference](/reactive): All APIs related to retrieving platform-supported taxonomies.   ### Insight APIs  Insight endpoints do exactly what the name implies - They offer platform-level insight into the activities of producers and consumers.   - [Analytics](/analytics): All APIs related to tracking metrics across a wide variety of data source segments including, more entertaining, leaderboard metrics.   ### Payment APIs  Payment endpoints are for developers who want to purchase travel inventory. This can be done via the API as a registered Travel Agent or using our API in conjunction with our PCI compliant reactive widget for all other entities.   - [TripPay](/reactive): All APIs related to TripPay account management, booking, mapping and integration features.   ## SDKs  We are actively working on supporting the most used languages out there. If you don't see your language here, reach out to us with a request to officially add your language. In the meantime, if you want to roll your own SDK, you can do so by downloading the OpenAPI spec and using one of the many available OpenAPI generators available: [https://openapi-generator.tech/docs/generators](https://openapi-generator.tech/docs/generators).   - Java SDK [https://github.com/wink-travel/wink-sdk-java](https://github.com/wink-travel/wink-sdk-java)   ## Usage  These features are made available to you via a [REST API](https://en.wikipedia.org/wiki/Representational_state_transfer). This API is language agnostic.   ## Versioning  We chose to version our endpoints in a way that we hope affects your integration minimally. You request the version of our API you wish to work with via the `Wink-Version` header. When it's time for you to upgrade, you only have to change the version number to get access to our updated endpoints.   ## Release history  - Follow updates on Github: https://github.com/wink-travel/wink-sdk-java/blob/master/CHANGELOG.md    # Extranet Distribution API The Distribution API exposes endpoints for sales channels, connecting with affiliates, managing rates and inventory calendars and more on Wink. This API lets you:  1. Verifier: Test your availability and promotions and create test bookings to simulate the entire booking workflow. 2. Sales Channels: Manage your sales channels. 3. Explore Network: Find new affiliates to work with. 4. Inventory: Manage inventory at the sales channel-level. 5. Calendars: Manage availability calendars for all your inventory.  Browse the endpoints in the left navigation bar to get started.  

    The version of the OpenAPI document: 30.17.1
    Contact: bjorn@wink.travel
    Generated by OpenAPI Generator (https://openapi-generator.tech)

    Do not edit the class manually.
"""  # noqa: E501


import unittest

from wink_sdk_extranet_distribution.models.property_aggregate_lightweight_supplier_details import PropertyAggregateLightweightSupplierDetails

class TestPropertyAggregateLightweightSupplierDetails(unittest.TestCase):
    """PropertyAggregateLightweightSupplierDetails unit test stubs"""

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def make_instance(self, include_optional) -> PropertyAggregateLightweightSupplierDetails:
        """Test PropertyAggregateLightweightSupplierDetails
            include_optional is a boolean, when False only required
            params are included, when True both required and
            optional params are included """
        # uncomment below to create an instance of `PropertyAggregateLightweightSupplierDetails`
        """
        model = PropertyAggregateLightweightSupplierDetails()
        if include_optional:
            return PropertyAggregateLightweightSupplierDetails(
                hotel_identifier = 'hotel-1',
                name = 'The Loveliest Hotel',
                local_name = 'Det Beste Hotellet',
                chain = 'Hotel chain',
                brand = 'Hotel brand',
                url_name = 'the-loveliest-hotel-new-york-united-states',
                star_rating = 4,
                bookings = 6054,
                aggregate_review_rating = 7.8,
                location = {type=POINT, coordinates=[100.5581533, 13.7370197]},
                descriptions = [
                    wink_sdk_extranet_distribution.models.simple_description_supplier_details.SimpleDescription_SupplierDetails(
                        name = 'An example title', 
                        description = 'This is a longer description in the specified language.', 
                        language = 'en', 
                        creator = 'USER', 
                        md5_content_hash = '', 
                        hash_mismatch = True, )
                    ],
                aggregate_greendex_rating = 7.0,
                lifestyle_types = [
                    null
                    ],
                total_reviews = 989,
                reservations = wink_sdk_extranet_distribution.models.contact_supplier.Contact_Supplier(
                    first_name = 'John', 
                    last_name = 'Smith', 
                    email = 'johnsmith@email.com', 
                    secondary_email = 'johnsmith2@email.com', 
                    phone_number = '+12125551212', 
                    full_name = 'John Smith', 
                    summary = 'John Smith (johnsmith@gmail.com / +12125551212)', ),
                socials = [
                    wink_sdk_extranet_distribution.models.social_supplier_details.Social_SupplierDetails(
                        type = 'FACEBOOK', 
                        location = '', )
                    ],
                images = [
                    wink_sdk_extranet_distribution.models.simple_multimedia_supplier_details.SimpleMultimedia_SupplierDetails(
                        multimedia_identifier = 'image-1', 
                        identifier = 'cloudinary-image-1', 
                        type = 'IMAGE', 
                        source = 'CLOUDINARY', 
                        sort = 10, 
                        angle = '-90', 
                        width = 2560, 
                        height = 1600, 
                        published = True, 
                        category = '1', 
                        descriptions = [
                            wink_sdk_extranet_distribution.models.simple_description_supplier_details.SimpleDescription_SupplierDetails(
                                name = 'An example title', 
                                description = 'This is a longer description in the specified language.', 
                                language = 'en', 
                                creator = 'USER', 
                                md5_content_hash = '', 
                                hash_mismatch = True, )
                            ], 
                        lifestyle_type = 'LIFESTYLE_HEALTH_FITNESS', 
                        attribution = [
                            wink_sdk_extranet_distribution.models.image_attribution_supplier_details.ImageAttribution_SupplierDetails(
                                url = 'https://maps.google.com/maps/contrib/111628493169070103594', 
                                name = 'Samuel Adams', )
                            ], 
                        is_landscape = True, )
                    ],
                videos = [
                    wink_sdk_extranet_distribution.models.simple_multimedia_supplier_details.SimpleMultimedia_SupplierDetails(
                        multimedia_identifier = 'image-1', 
                        identifier = 'cloudinary-image-1', 
                        type = 'IMAGE', 
                        source = 'CLOUDINARY', 
                        sort = 10, 
                        angle = '-90', 
                        width = 2560, 
                        height = 1600, 
                        published = True, 
                        category = '1', 
                        descriptions = [
                            wink_sdk_extranet_distribution.models.simple_description_supplier_details.SimpleDescription_SupplierDetails(
                                name = 'An example title', 
                                description = 'This is a longer description in the specified language.', 
                                language = 'en', 
                                creator = 'USER', 
                                md5_content_hash = '', 
                                hash_mismatch = True, )
                            ], 
                        lifestyle_type = 'LIFESTYLE_HEALTH_FITNESS', 
                        attribution = [
                            wink_sdk_extranet_distribution.models.image_attribution_supplier_details.ImageAttribution_SupplierDetails(
                                url = 'https://maps.google.com/maps/contrib/111628493169070103594', 
                                name = 'Samuel Adams', )
                            ], 
                        is_landscape = True, )
                    ],
                policy = wink_sdk_extranet_distribution.models.property_policy_supplier_details.PropertyPolicy_SupplierDetails(
                    children_allowed = True, 
                    children_minimum_age = 6, 
                    internet_availability = 'YES', 
                    internet_connection_type = 'WIFI', 
                    internet_connection_location = 'ENTIRE_PROPERTY', 
                    parking_availability = 'YES', 
                    parking_access = 'PRIVATE', 
                    pets_allowed = True, 
                    pet_max_weight_in_kilos = 10, 
                    pet_charge = wink_sdk_extranet_distribution.models.custom_monetary_amount.CustomMonetaryAmount(
                        amount = 1.337, 
                        currency = '0', ), 
                    check_out_time = '10:00', 
                    check_in_time = '14:00', ),
                third_party_reviews = [
                    wink_sdk_extranet_distribution.models.travel_inventory_recognition_supplier_details.TravelInventoryRecognition_SupplierDetails(
                        identifier = 'recognition-1', 
                        category = 'AWARD', 
                        type = 'PERCENT_RATING', 
                        provider = 'Michelin', 
                        rating = 8.5, 
                        max_rating = 10, 
                        date = '2020-10-24', 
                        official_appointment_ind = True, 
                        rating_symbol = '*', )
                    ],
                attractions = 5,
                activities = 3,
                places = 9,
                restaurants = 2,
                meeting_rooms = 2,
                spas = 1,
                add_ons = 5,
                general_manager = wink_sdk_extranet_distribution.models.general_manager_supplier_details.GeneralManager_SupplierDetails(
                    name = 'Jane Doe', 
                    image = cl-image-1, 
                    descriptions = [
                        wink_sdk_extranet_distribution.models.localized_description_supplier_details.LocalizedDescription_SupplierDetails(
                            description = 'This is a longer description in the specified language.', 
                            language = 'en', 
                            creator = 'USER', 
                            md5_content_hash = '', 
                            hash_mismatch = True, )
                        ], ),
                location_category = '34',
                segment_category = '7',
                hotel_category = '45',
                architectural_style = '7',
                when_built = '1927',
                currency_code = 'USD',
                membership_rate_discount = 9,
                price_score = 9,
                perk_score = 4,
                add_on_score = 4,
                loyalty_score = 5,
                popular_score = 45,
                experience_score = 5,
                hotel_amenity_codes = [1, 7],
                property_accessibility_codes = [1, 7],
                property_security_codes = [1, 7],
                number_of_rooms = 32,
                address = wink_sdk_extranet_distribution.models.simple_address_supplier.SimpleAddress_Supplier(
                    address1 = '234', 
                    address2 = 'Pebble #5001', 
                    state = 'CA', 
                    postal_code = '90210', 
                    county = 'Alameda county', 
                    city = '0', 
                    country_code = '0', 
                    country = 'United States', 
                    full_address = '11', ),
                active = True,
                url_parameters = ''
            )
        else:
            return PropertyAggregateLightweightSupplierDetails(
        )
        """

    def testPropertyAggregateLightweightSupplierDetails(self):
        """Test PropertyAggregateLightweightSupplierDetails"""
        # inst_req_only = self.make_instance(include_optional=False)
        # inst_req_and_optional = self.make_instance(include_optional=True)

if __name__ == '__main__':
    unittest.main()
