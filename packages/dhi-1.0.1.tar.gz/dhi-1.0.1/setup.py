from setuptools import setup, Extension, find_packages
from pathlib import Path
import os
import sys

# Read README
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text() if readme_file.exists() else ""

# Try to build native extension, but make it optional
try:
    # Path to the Zig-built shared library
    lib_dir = os.path.join(os.path.dirname(__file__), '..', 'zig-out', 'lib')
    lib_name = 'satya'
    
    # Platform-specific library extension
    if sys.platform == 'darwin':
        lib_file = f'lib{lib_name}.dylib'
    elif sys.platform == 'win32':
        lib_file = f'{lib_name}.dll'
    else:
        lib_file = f'lib{lib_name}.so'
    
    lib_path = os.path.join(lib_dir, lib_file)
    
    # Only build extension if library exists
    if os.path.exists(lib_path):
        native_ext = Extension(
            'dhi._dhi_native',
            sources=['dhi/_native.c'],
            include_dirs=[],
            library_dirs=[lib_dir],
            libraries=[lib_name],
            runtime_library_dirs=[lib_dir] if sys.platform != 'darwin' else [],
            extra_link_args=[f'-Wl,-rpath,@loader_path'] if sys.platform == 'darwin' else [],
        )
        ext_modules = [native_ext]
    else:
        print("WARNING: Zig library not found, installing pure Python version")
        ext_modules = []
except Exception as e:
    print(f"WARNING: Could not build native extension: {e}")
    print("Installing pure Python version")
    ext_modules = []

setup(
    ext_modules=ext_modules,
)
