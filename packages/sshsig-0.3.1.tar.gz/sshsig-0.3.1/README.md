SSHSIG
======

Python port of the lightweight SSH Signature format of `ssh-keygen`.

[Documentation](https://castedo.github.io/sshsig/)


Repositories
------------

* <https://github.com/castedo/sshsig> (primary)
* <https://gitlab.com/perm.pub/sshsiglib> (secondary)
