API reference
#############

CameraList class
****************

.. autoclass:: camera_list.CameraList
   :members:


CameraBasler class
******************

.. autoclass:: camera_basler.CameraBasler
   :members:


CameraBaslerWidget class
************************

.. autoclass:: camera_basler_widget.CameraBaslerWidget
   :members: