API reference
#############

CameraList class
****************

.. autoclass:: camera_list.CameraList
   :members:


CameraIds class
******************

.. autoclass:: camera_ids.CameraIds
   :members:


CameraIdsWidget class
************************

.. autoclass:: camera_ids_widget.CameraIdsWidget
   :members: