__all__ = [
    "camera_basler",        # refers to the 'camera_basler.py' file
    "camera_basler_widget", # refers to the 'camera_basler_widget.py' file
    "camera_list",          # refers to the 'camera_list.py' file
]