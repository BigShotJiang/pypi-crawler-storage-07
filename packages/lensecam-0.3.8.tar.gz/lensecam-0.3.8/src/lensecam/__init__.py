__all__ = [
    "ids",      # refers to the 'ids' dir
    "basler",      # refers to the 'basler' dir
    "camera_thread", #refers to the 'camera_thread' file
]
