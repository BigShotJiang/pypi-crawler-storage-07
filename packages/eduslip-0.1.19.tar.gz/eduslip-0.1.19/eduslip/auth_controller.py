import requests

def is_user_subscribed(username: str):
    try:
        res = requests.post(
            "https://eduslip.vercel.app/api/cli/isSubscribedUser",
            json={"userName": username},
            timeout=10
        )
        return res.json()
    except Exception as e:
        return {"success": False, "message": str(e)}
