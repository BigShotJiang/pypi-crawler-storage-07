from eduslip.utils.JAVA import JAVA_SLIPS
from eduslip.utils.OS import OS_SLIPS
from eduslip.utils.PHP import PHP_SLIPS

def get_slip(subject: str, slip_no: int):
    if subject == "os":
        return OS_SLIPS[slip_no - 1] if slip_no <= len(OS_SLIPS) else {}
    elif subject == "php":
        return PHP_SLIPS[slip_no - 1] if slip_no <= len(PHP_SLIPS) else {}
    elif subject == "java":
        return JAVA_SLIPS[slip_no - 1] if slip_no <= len(JAVA_SLIPS) else {}
    return {}
