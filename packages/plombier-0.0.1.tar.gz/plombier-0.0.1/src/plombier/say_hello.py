def say_hello() -> str:
    return "Hello"
