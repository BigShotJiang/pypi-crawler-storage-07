# -*- coding: utf-8 -*-

from .caster import bcm_pricing_calculator_caster

caster = bcm_pricing_calculator_caster

__version__ = "1.40.0"