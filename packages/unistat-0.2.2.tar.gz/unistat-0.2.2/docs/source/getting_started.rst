.. _getting_started:

Getting Started
===============

To install ``unistat``:

.. code-block:: bash

   pip install unistat