.. automodule:: unistat.regression
   :members:
   :undoc-members:
   :show-inheritance:
   :exclude-members: bool_cols, reg, std_reg