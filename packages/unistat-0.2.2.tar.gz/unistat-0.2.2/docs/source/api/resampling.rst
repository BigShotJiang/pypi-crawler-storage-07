.. automodule:: unistat.resampling
   :members:
   :undoc-members:
   :show-inheritance:
   :exclude-members: boot_ci_hi, boot_ci_lo, boot_ci_pct, boot_dist, boot_mean, boot_sem, obs_stat, p, perm_dist