.. automodule:: unistat.continuous
   :members:
   :undoc-members:
   :show-inheritance: