# Directory creation logic
