# Security helpers
