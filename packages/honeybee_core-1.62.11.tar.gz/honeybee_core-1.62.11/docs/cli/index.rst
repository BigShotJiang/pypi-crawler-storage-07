CLI Docs
========

Installation
------------

To check if the Honeybee command line interface is installed correctly try ``honeybee viz`` and you
should get a ``viiiiiiiiiiiiizzzzzzzzz!`` back in response!
