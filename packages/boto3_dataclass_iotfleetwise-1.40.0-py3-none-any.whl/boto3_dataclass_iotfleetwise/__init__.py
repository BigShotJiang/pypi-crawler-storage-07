# -*- coding: utf-8 -*-

from .caster import iotfleetwise_caster

caster = iotfleetwise_caster

__version__ = "1.40.0"