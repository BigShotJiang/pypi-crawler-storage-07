from setuptools import find_packages, setup

setup(
    name="SoIdea-update-python",
    version="0.1.0",
    author="Soidea",
    author_email="",
    description="本项目为跨平台自动升级脚本，支持命令行参数、GUI显示、配置文件、默认参数三层优先级，具备日志轮转、异常兜底、回滚、进程管理、hash 校验等生产级特性。当前测试版本，请勿生产环境中使用",
    long_description=open("README.md", encoding="utf-8").read() if __import__('os').path.exists('README.md') else '',
    long_description_content_type="text/markdown",
    url="https://github.com/Soidea",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "toml",
        "pyyaml",
        # 其它依赖会自动补全
    ],
    python_requires=">=3.7",
    license="GPL-3.0",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: GNU General Public License v3 (GPLv3)",
        "Operating System :: OS Independent",
    ],
)