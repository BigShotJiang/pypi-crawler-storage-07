# SoIdea_update_python: 核心升级逻辑库
from .backup import *
from .config import *
from .constants import *
from .encoding_utils import *
from .events import *
from .git_utils import *
from .lock_utils import *
from .log_utils import ProgressBar, setup_logger
from .package import *
from .package_sources import *
from .path_utils import *
from .platform_utils import *
from .process import *
from .process_utils import *
from .self_update_utils import *
from .signature import *
from .update_manager import *
from .upgrade_utils import *
from .version_utils import *

# src/my_package/__init__.py
__version__ = "0.1.2"
