import os
import sys


def ensure_utf8_console():
    """
    强制控制台输出为 UTF-8，兼容 Windows/Linux/Mac。
    """
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    if sys.platform == 'win32':
        os.system('chcp 65001')
