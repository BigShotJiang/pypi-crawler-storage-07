# 是否在启动时自动清理 uploads 下同名 exe 文件（可通过配置注入）
ENABLE_STARTUP_UPLOADS_CLEAN = True


"""
SoIdea-update-python 公用常量文件
供客户端、开发端、服务端统一引用
"""


# 默认配置文件名
DEFAULT_CONFIG_FILE = "upgrade_config.toml"
DEFAULT_BUILD_CONFIG_FILE = "build_config.toml"
DEFAULT_WEB_CONFIG_FILE = "web_config.toml"

# 默认目录
DEFAULT_BACKUP_DIR = "backup"
DEFAULT_UPLOAD_DIR = "uploads"
DEFAULT_UPDATE_TMP_DIR = "update_tmp"

# 默认主程序名（可通过参数覆盖）
DEFAULT_MAIN_EXE = "main.exe"

# 升级包相关
DEFAULT_UPDATE_ZIP = "update.zip"
DEFAULT_SIG_SUFFIX = ".sig"
DEFAULT_HASH_ALGO = "sha256"

# 关键参数 key
PARAM_CONFIG = "config"
PARAM_WORKDIR = "workdir"
PARAM_HASH = "hash"
PARAM_SIG = "sig"
PARAM_NAME = "name"
PARAM_PATH = "path"


DEFAULT_LOG_DIR = "logs"
DEFAULT_LOG_FILE = "SoIdea-update-python.log"

# 是否启用命令行参数（如为 False，则所有命令行参数无效，仅用配置文件/默认值）
ENABLE_CMD_ARGS = True
# 是否启用默认参数（如为 False，则仅用配置文件参数，默认值无效）
ENABLE_DEFAULT_ARGS = True
# 是否在启动时自动清理 uploads 下同名 exe 文件（可通过配置注入）
ENABLE_STARTUP_UPLOADS_CLEAN = True

# 可根据实际业务继续补充



# 四个主入口文件的版本号（打包时自动更新）
VERSION_BUILD_UPDATE_PACKAGE = '1.0.46'
VERSION_UPDATER = '1.1.46'
VERSION_WEB_SERVICE = '1.2.46'
VERSION_HELLOWORLD_LOCK = '1.3.46'
