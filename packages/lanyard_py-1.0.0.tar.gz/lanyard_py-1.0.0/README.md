# lanyard.py

<p align="center">
    <img alt="PyPI - Downloads" src="https://img.shields.io/pypi/dw/lanyard.py?style=flat-square">
    <img alt="PyPI - Status" src="https://img.shields.io/pypi/status/lanyard.py?style=flat-square">
    <img alt="PyPI - Version" src="https://img.shields.io/pypi/v/lanyard.py?style=flat-square">
    <img alt="GitHub License" src="https://img.shields.io/github/license/nerma-now/lanyard.py?style=flat-square">
    <img alt="GitHub contributors" src="https://img.shields.io/github/contributors/nerma-now/lanyard.py?style=flat-square">
    <img alt="GitHub commit activity" src="https://img.shields.io/github/commit-activity/w/nerma-now/lanyard.py?style=flat-square">
</p>

lanyard.py is a modern and fully asynchronous wrapper for Lanyard API written in Python 3.12+.

***Documentation***:

— 🇺🇸 [English](https://nerma-now.github.io/lanyard.py/)

### Thanks
— [lanyard](https://github.com/Phineas/lanyard)

