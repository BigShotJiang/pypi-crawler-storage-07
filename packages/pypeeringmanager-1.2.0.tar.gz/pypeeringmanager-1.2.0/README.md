# PyPeeringManager

This client library for Peering-Manager is based off of `pynetbox` (https://github.com/digitalocean/pynetbox)
and can be used in a similar manner.

Peering-Manager's models can be reached through the `peering`, `net` and `extras` attributes of the API object.
