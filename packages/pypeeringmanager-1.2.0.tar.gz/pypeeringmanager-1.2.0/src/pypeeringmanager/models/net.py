from pynetbox.core.response import Record

class Connections(Record):
    pass