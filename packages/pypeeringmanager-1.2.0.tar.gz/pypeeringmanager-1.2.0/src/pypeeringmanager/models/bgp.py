from pynetbox.core.response import Record

class Relationships(Record):
    pass