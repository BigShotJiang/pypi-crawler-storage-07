# -*- coding: utf-8 -*-

from .caster import appconfigdata_caster

caster = appconfigdata_caster

__version__ = "1.40.0"