## 18.0.1.0.3 (2025-09-11)

### Features

- When using attribute mapping, only write value that changes.
  Not writing the value systematically avoids getting security mail on login/email
  when there is no real change.


## 18.0.1.0.2 (2025-05-13)

### Bugfixes

- Avoid redirecting when there is a SAML error.


## 18.0.1.0.0

Initial migration for 18.0.
