This addon requires the python module `pysaml2`.

`pysaml2` requires the binary `xmlsec1` (on Debian or Ubuntu you can
install it with `apt-get install xmlsec1`)
