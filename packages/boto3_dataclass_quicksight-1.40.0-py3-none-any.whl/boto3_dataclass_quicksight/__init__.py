# -*- coding: utf-8 -*-

from .caster import quicksight_caster

caster = quicksight_caster

__version__ = "1.40.0"