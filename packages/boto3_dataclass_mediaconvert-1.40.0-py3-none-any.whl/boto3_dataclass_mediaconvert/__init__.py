# -*- coding: utf-8 -*-

from .caster import mediaconvert_caster

caster = mediaconvert_caster

__version__ = "1.40.0"