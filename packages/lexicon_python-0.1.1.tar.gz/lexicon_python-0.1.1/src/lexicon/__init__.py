"""Public package surface for the lexicon Python client."""

from .lexicon import LexiconClient

__all__ = ["LexiconClient"]
