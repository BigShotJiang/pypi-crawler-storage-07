from .extractor import TextEntityExtractor

def bul(text: str):
    return TextEntityExtractor().extract_all(text)
