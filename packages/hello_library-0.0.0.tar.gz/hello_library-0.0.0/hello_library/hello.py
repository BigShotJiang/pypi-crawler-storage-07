def print_hello():
    print("Lumelang ke Maqai!")