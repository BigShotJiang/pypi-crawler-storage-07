# coding=utf-8
from .._impl import (
    timeseries_archetype_SeriesArchetypeService as SeriesArchetypeService,
)

__all__ = [
    'SeriesArchetypeService',
]

