import os
import warnings
from base64 import b64encode

import xarray as xr

from cchdo.hydro import accessors  # noqa: F401
from cchdo.hydro.exchange import read_exchange
from cchdo.hydro.exchange.exceptions import (
    ExchangeDataFlagPairError,
    ExchangeParameterUndefError,
)
from cchdo.params import WHPNames


def make_netcdf_file_json(path):
    with open(path, "rb") as f:
        return {
            "name": "netcdf.nc",  # not important isn't used
            "type": "application/x-netcdf",
            "body": b64encode(f.read()).decode("utf8"),
        }


def p_file(file_m):
    t_dir, file, file_metadata, roundtrip = file_m
    checks = {"flags": False}
    unknown_params = []

    warnings.simplefilter("ignore")
    if ("OSNUM", None) not in WHPNames:
        WHPNames.add_alias(("OSNUM", None), ("EVENT_NUMBER", None))

    if file_metadata["data_type"] == "ctd" and ("NITRATE", "UMOL/KG") not in WHPNames:
        # HOT names that are a little dangerous to have in the real DB
        WHPNames.add_alias(("NITRATE", "UMOL/KG"), ("CTDNITRATE", "UMOL/KG"))
        WHPNames.add_alias(("CHLPIG", "uG/L"), ("CTDFLUOR", "MG/M^3"))
        WHPNames.add_alias(("CHLPIG", "UG/L"), ("CTDFLUOR", "MG/M^3"))

        # other one off things
        WHPNames.add_alias(("CTDFLUOR", "UG/L_UNCALIBRATED"), ("CTDFLUOR", "MG/M^3"))
        WHPNames.add_alias(("_OS_ID", None), ("EVENT_NUMBER", None))
        WHPNames.add_alias(("CTDSAL", "PPS-78"), ("CTDSAL", "PSS-78"))

    try:
        ex_xr = read_exchange(file, checks=checks)
    except ExchangeParameterUndefError as err:
        return (500, repr(err), file_metadata, err.error_data)
    except ExchangeDataFlagPairError:
        try:
            ex_xr = read_exchange(file, fill_values=("-999", "-99"), checks=checks)
        except (ValueError, KeyError) as err:
            return (500, repr(err), file_metadata, unknown_params)
    except (ValueError, KeyError) as err:
        return (500, repr(err), file_metadata, unknown_params)

    to_path = os.path.join(t_dir, f"{file_metadata['id']}_{ex_xr.cchdo.gen_fname()}")
    ex_xr.to_netcdf(to_path)
    if roundtrip:
        ds = xr.load_dataset(to_path)
        try:
            ex = ds.cchdo.to_exchange()
        except ValueError as err:
            return (
                500,
                f"Roundtrip back to exchange: {err!r}",
                file_metadata,
                unknown_params,
            )
        try:
            ex_xr = read_exchange(ex, checks=checks)
        except ValueError as err:
            return (
                500,
                f"Roundtrip back to and from exchange: {err!r}",
                file_metadata,
                unknown_params,
            )

    return (200, to_path, file_metadata, unknown_params)


def p_file_cf(file_m):
    _t_dir, file, file_metadata = file_m

    warnings.simplefilter("ignore")

    ex_xr = xr.load_dataset(file)
    try:
        ex_xr.cchdo.to_exchange()
        exchange_ok = True
    except Exception:
        exchange_ok = False

    try:
        ex_xr.cchdo.to_coards()
        coards_ok = True
    except Exception:
        coards_ok = False

    try:
        ex_xr.cchdo.to_woce()
        woce_ok = True
    except Exception:
        woce_ok = False

    try:
        ex_xr.cchdo.to_sum()
        sum_ok = True
    except Exception:
        sum_ok = False

    return (file_metadata, exchange_ok, coards_ok, woce_ok, sum_ok)
