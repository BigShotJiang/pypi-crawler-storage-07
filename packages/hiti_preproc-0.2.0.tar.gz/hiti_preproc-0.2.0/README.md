# HITI-Preproc [Alpha]

*Beatrice Brown-Mulry*

WIP package for the DICOM preprocessing workflows used internally in the HITI Lab. Example usage is included in the `example.ipynb` notebook. 

Installable from PyPI with `pip install hiti-preproc`.
