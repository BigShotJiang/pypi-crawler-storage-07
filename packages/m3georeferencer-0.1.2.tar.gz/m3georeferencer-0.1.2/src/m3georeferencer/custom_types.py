# Standarad Libraries
from pathlib import Path
import os

PathLike = str | os.PathLike | Path
