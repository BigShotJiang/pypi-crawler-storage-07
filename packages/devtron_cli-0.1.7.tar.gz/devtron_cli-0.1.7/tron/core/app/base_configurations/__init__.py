"""Base configuration models and helpers for tron."""

