"""The Wanting package."""

from wanting.wanting import FieldInfoEx, Unavailable, Unmapped, Wanting, wanting_fields

__author__ = "Narvin Singh"
__version__ = "0.2.0"

__all__ = ["FieldInfoEx", "Unavailable", "Unmapped", "Wanting", "__version__", "wanting_fields"]
