"""
Copyright CNRS (https://www.cnrs.fr/index.php/en)
Contributor(s): Eric Debreuve (eric.debreuve@cnrs.fr) since 2025
SEE COPYRIGHT NOTICE BELOW
"""

import dataclasses as d
import typing as h

import numpy as nmpy
from p_pattern.extension.type import number_h

parameter_h = number_h
parameter_interval_h = tuple[parameter_h, parameter_h]
parameter_precision_h = number_h | None

PI_ANGLE = nmpy.pi


@d.dataclass(slots=True, repr=False, eq=False)
class parameter_t:
    """
    min, max: cannot be "infinity".
    min_inclusive, max_inclusive: used only if type is float.
    default_precision:
        - If type is int, None means 1.
        - Otherwise (float), None means "infinite".
    """

    type: type[parameter_h]
    min: parameter_h
    max: parameter_h
    min_inclusive: bool
    max_inclusive: bool
    default_interval: parameter_interval_h
    default_precision: parameter_precision_h

    interval: tuple[parameter_interval_h, parameter_precision_h] = ()

    @classmethod
    def NewAngle(cls, pi_factor: float, /) -> h.Self:
        """"""
        return cls(
            type=float,
            min=0.0,
            max=2.0 * PI_ANGLE,
            min_inclusive=True,
            max_inclusive=False,
            default_interval=(0.0, pi_factor * PI_ANGLE),
            default_precision=(0.5 * pi_factor) * 5.0 * PI_ANGLE / 180.0,
        )


"""
COPYRIGHT NOTICE

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use,
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info".

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability.

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or
data to be ensured and,  more generally, to use and operate it in the
same conditions as regards security.

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.

SEE LICENCE NOTICE: file README-LICENCE-utf8.txt at project source root.
"""
