# -*- coding: utf-8 -*-

from .caster import servicecatalog_appregistry_caster

caster = servicecatalog_appregistry_caster

__version__ = "1.40.0"