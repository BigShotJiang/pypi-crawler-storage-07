# -*- coding: utf-8 -*-

from .caster import license_manager_user_subscriptions_caster

caster = license_manager_user_subscriptions_caster

__version__ = "1.40.0"