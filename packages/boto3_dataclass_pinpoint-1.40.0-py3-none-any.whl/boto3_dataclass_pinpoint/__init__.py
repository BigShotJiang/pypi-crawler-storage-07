# -*- coding: utf-8 -*-

from .caster import pinpoint_caster

caster = pinpoint_caster

__version__ = "1.40.0"