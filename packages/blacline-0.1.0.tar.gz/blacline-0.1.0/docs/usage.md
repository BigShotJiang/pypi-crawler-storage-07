# Usage

To use blacline in a project:

```python
import blacline
```
