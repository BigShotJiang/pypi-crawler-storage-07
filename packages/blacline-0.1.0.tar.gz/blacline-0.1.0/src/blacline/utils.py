def do_something_useful():
    print("Replace this with a utility function")
