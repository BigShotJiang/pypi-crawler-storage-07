from fastapi import Depends

Require = Depends
