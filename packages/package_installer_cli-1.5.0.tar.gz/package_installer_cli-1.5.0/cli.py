#!/usr/bin/env python3
import subprocess
import sys
import os
import platform
from pathlib import Path

def main():
    """Main entry point for the CLI (runs the bundled executable)"""
    package_dir = Path(__file__).parent
    exec_dir = package_dir / "bundle" / "executables"

    system = platform.system().lower()
    if system == "linux":
        exec_path = exec_dir / "package-installer-linux"
    elif system == "darwin":
        exec_path = exec_dir / "package-installer-macos"
    elif system == "windows":
        exec_path = exec_dir / "package-installer-win.exe"
    else:
        print(f"Unsupported OS: {system}")
        sys.exit(1)

    if not exec_path.exists():
        print(f"Error: Bundled executable not found: {exec_path}")
        sys.exit(1)

    try:
        # Make sure the binary is executable (for Unix)
        if system in ("linux", "darwin"):
            exec_path.chmod(exec_path.stat().st_mode | 0o111)
        result = subprocess.run([str(exec_path)] + sys.argv[1:])
        sys.exit(result.returncode)
    except KeyboardInterrupt:
        sys.exit(1)
    except Exception as e:
        print(f"Error running bundled CLI: {e}")
        print("Please check that the bundled executable is properly built and compatible with your system.")
        print("You may need to rebuild the bundle or contact support.")
        sys.exit(1)

if __name__ == "__main__":
    main()