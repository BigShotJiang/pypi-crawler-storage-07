"""Namespace for generic libraries."""
