# Copyright (C) 2025 <UTN FRA>
#
# Author: Facundo Falcone <f.falcone@sistemas-utnfra.com.ar>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

vistas_lk = [
    358893,
    484729,
    386529,
    450948,
    819036,
    557622,
    511376,
    1223905,
    290251,
    759592,
    4814906,
    487818,
    361233,
    237316,
    2368142,
    2249163,
    5110149,
    357002,
    5645428,
    803638,
    1336165,
    1193517,
    4598531,
    1490188,
    1057923,
    1430280,
    1280577,
    1737550,
    8582125,
    2510950,
    1069398,
    3923815,
    2610523,
    1938173,
    10583979,
    143826,
    42725525,
    6659065,
    68417463,
    4989580,
    74770,
    44135202,
    54222413,
    4193349,
    43098188,
    58312006,
    8407578,
    172130337,
    662812,
    482704891
]