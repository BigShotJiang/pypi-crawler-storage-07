from .pyvidplayer import Video
from .utn_video_player import UTNVideoPlayer