"""ksef test suite."""
