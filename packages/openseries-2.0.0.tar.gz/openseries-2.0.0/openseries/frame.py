"""The OpenFrame class."""

from __future__ import annotations

from copy import deepcopy
from functools import reduce
from logging import getLogger
from typing import TYPE_CHECKING, Any, cast

from numpy import (
    array,
    asarray,
    concatenate,
    corrcoef,
    cov,
    diff,
    divide,
    float64,
    isinf,
    isnan,
    linalg,
    log,
    nan,
    sqrt,
    std,
)
from pandas import (
    DataFrame,
    DatetimeIndex,
    Index,
    MultiIndex,
    Series,
    concat,
    merge,
)

if TYPE_CHECKING:  # pragma: no cover
    import datetime as dt

    from numpy.typing import NDArray
    from pandas import Series as _Series
    from pandas import Timestamp

    SeriesFloat = _Series[float]
else:
    SeriesFloat = Series

from pydantic import field_validator
from sklearn.linear_model import LinearRegression  # type: ignore[import-untyped]

from ._common_model import _calculate_time_factor, _CommonModel, _get_base_column_data
from .datefixer import _do_resample_to_business_period_ends
from .owntypes import (
    DaysInYearType,
    LabelsNotUniqueError,
    LiteralBizDayFreq,
    LiteralCaptureRatio,
    LiteralFrameProps,
    LiteralHowMerge,
    LiteralPandasReindexMethod,
    LiteralPortfolioWeightings,
    LiteralTrunc,
    MergingResultedInEmptyError,
    MixedValuetypesError,
    NoWeightsError,
    OpenFramePropertiesList,
    RatioInputError,
    ResampleDataLossError,
    Self,
    ValueType,
)
from .series import OpenTimeSeries

logger = getLogger(__name__)

__all__ = ["OpenFrame"]


class OpenFrame(_CommonModel[SeriesFloat]):
    """OpenFrame objects hold OpenTimeSeries in the list constituents.

    The intended use is to allow comparisons across these timeseries.

    Parameters
    ----------
    constituents: list[OpenTimeSeries]
        List of objects of Class OpenTimeSeries
    weights: list[float], optional
        List of weights in float format.

    Returns:
    --------
    OpenFrame
        Object of the class OpenFrame

    """

    constituents: list[OpenTimeSeries]
    tsdf: DataFrame = DataFrame(dtype="float64")
    weights: list[float] | None = None

    @field_validator("constituents")
    def _check_labels_unique(
        cls: type[OpenFrame],  # noqa: N805
        tseries: list[OpenTimeSeries],
    ) -> list[OpenTimeSeries]:
        """Pydantic validator ensuring that OpenFrame labels are unique."""
        labls = [x.label for x in tseries]
        if len(set(labls)) != len(labls):
            msg = "TimeSeries names/labels must be unique"
            raise LabelsNotUniqueError(msg)
        return tseries

    def __init__(
        self: Self,
        constituents: list[OpenTimeSeries],
        weights: list[float] | None = None,
    ) -> None:
        """OpenFrame objects hold OpenTimeSeries in the list constituents.

        The intended use is to allow comparisons across these timeseries.

        Parameters
        ----------
        constituents: list[OpenTimeSeries]
            List of objects of Class OpenTimeSeries
        weights: list[float], optional
            List of weights in float format.

        Returns:
        --------
        OpenFrame
            Object of the class OpenFrame

        """
        copied_constituents = [ts.from_deepcopy() for ts in constituents]

        super().__init__(  # type: ignore[call-arg]
            constituents=copied_constituents,
            weights=weights,
        )

        self.constituents = copied_constituents
        self.weights = weights
        self._set_tsdf()

    def _set_tsdf(self: Self) -> None:
        """Set the tsdf DataFrame."""
        if self.constituents is not None and len(self.constituents) != 0:
            if len(self.constituents) == 1:
                self.tsdf = self.constituents[0].tsdf.copy()
            else:
                self.tsdf = concat(
                    [x.tsdf for x in self.constituents], axis="columns", sort=True
                )
        else:
            logger.warning("OpenFrame() was passed an empty list.")

    def from_deepcopy(self: Self) -> Self:
        """Create copy of the OpenFrame object.

        Returns:
        --------
        OpenFrame
            An OpenFrame object

        """
        return deepcopy(self)

    def merge_series(
        self: Self,
        how: LiteralHowMerge = "outer",
    ) -> Self:
        """Merge index of Pandas Dataframes of the constituent OpenTimeSeries.

        Parameters
        ----------
        how: LiteralHowMerge, default: "outer"
            The Pandas merge method.

        Returns:
        --------
        OpenFrame
            An OpenFrame object

        """
        lvl_zero = list(self.columns_lvl_zero)
        self.tsdf = reduce(
            lambda left, right: merge(
                left=left,
                right=right,
                how=how,
                left_index=True,
                right_index=True,
            ),
            [x.tsdf for x in self.constituents],
        )

        mapper = dict(zip(self.columns_lvl_zero, lvl_zero, strict=True))
        self.tsdf = self.tsdf.rename(columns=mapper, level=0)

        if self.tsdf.empty:
            msg = (
                "Merging OpenTimeSeries DataFrames with "
                f"argument how={how} produced an empty DataFrame."
            )
            raise MergingResultedInEmptyError(msg)

        if how == "inner":
            for xerie in self.constituents:
                xerie.tsdf = xerie.tsdf.loc[self.tsdf.index]
        return self

    def all_properties(
        self: Self,
        properties: list[LiteralFrameProps] | None = None,
    ) -> DataFrame:
        """Calculate chosen timeseries properties.

        Parameters
        ----------
        properties: list[LiteralFrameProps], optional
            The properties to calculate. Defaults to calculating all available.

        Returns:
        --------
        pandas.DataFrame
            Properties of the contituent OpenTimeSeries

        """
        if properties:
            props = OpenFramePropertiesList(*properties)
            prop_list = [getattr(self, x) for x in props]
        else:
            prop_list = [
                getattr(self, x) for x in OpenFramePropertiesList.allowed_strings
            ]
        return cast("DataFrame", concat(prop_list, axis="columns").T)

    @property
    def lengths_of_items(self: Self) -> Series[int]:
        """Number of observations of all constituents.

        Returns:
        --------
        Pandas.Series[int]
            Number of observations of all constituents

        """
        return Series(
            data=[self.tsdf[col].count() for col in self.tsdf.columns],
            index=self.tsdf.columns,
            name="observations",
        ).astype(int)

    @property
    def item_count(self: Self) -> int:
        """Number of constituents.

        Returns:
        --------
        int
            Number of constituents

        """
        return len(self.constituents)

    @property
    def columns_lvl_zero(self: Self) -> list[str]:
        """Level 0 values of the MultiIndex columns in the .tsdf DataFrame.

        Returns:
        --------
        list[str]
            Level 0 values of the MultiIndex columns in the .tsdf DataFrame

        """
        return list(self.tsdf.columns.get_level_values(0))

    @property
    def columns_lvl_one(self: Self) -> list[ValueType]:
        """Level 1 values of the MultiIndex columns in the .tsdf DataFrame.

        Returns:
        --------
        list[ValueType]
            Level 1 values of the MultiIndex columns in the .tsdf DataFrame

        """
        return list(self.tsdf.columns.get_level_values(1))

    @property
    def first_indices(self: Self) -> Series[dt.date]:
        """The first dates in the timeseries of all constituents.

        Returns:
        --------
        Pandas.Series[dt.date]
            The first dates in the timeseries of all constituents

        """
        return Series(
            data=[i.first_idx for i in self.constituents],
            index=self.tsdf.columns,
            name="first indices",
            dtype="datetime64[ns]",
        ).dt.date

    @property
    def last_indices(self: Self) -> Series[dt.date]:
        """The last dates in the timeseries of all constituents.

        Returns:
        --------
        Pandas.Series[dt.date]
            The last dates in the timeseries of all constituents

        """
        return Series(
            data=[i.last_idx for i in self.constituents],
            index=self.tsdf.columns,
            name="last indices",
            dtype="datetime64[ns]",
        ).dt.date

    @property
    def span_of_days_all(self: Self) -> Series[int]:
        """Number of days from the first date to the last for all items in the frame.

        Returns:
        --------
        Pandas.Series[int]
            Number of days from the first date to the last for all
            items in the frame.

        """
        return Series(
            data=[c.span_of_days for c in self.constituents],
            index=self.tsdf.columns,
            name="span of days",
        ).astype(int)

    def value_to_ret(self: Self) -> Self:
        """Convert series of values into series of returns.

        Returns:
        --------
        OpenFrame
            The returns of the values in the series

        """
        returns = self.tsdf.ffill().pct_change()
        returns.iloc[0] = 0
        new_labels: list[ValueType] = [ValueType.RTRN] * self.item_count
        arrays: list[Index[Any], list[ValueType]] = [  # type: ignore[type-arg]
            self.tsdf.columns.get_level_values(0),
            new_labels,
        ]
        returns.columns = MultiIndex.from_arrays(arrays=arrays)
        self.tsdf = returns.copy()
        return self

    def value_to_diff(self: Self, periods: int = 1) -> Self:
        """Convert series of values to series of their period differences.

        Parameters
        ----------
        periods: int, default: 1
            The number of periods between observations over which difference
            is calculated

        Returns:
        --------
        OpenFrame
            An OpenFrame object

        """
        self.tsdf = self.tsdf.diff(periods=periods)
        self.tsdf.iloc[0] = 0
        new_labels: list[ValueType] = [ValueType.RTRN] * self.item_count
        arrays: list[Index[Any], list[ValueType]] = [  # type: ignore[type-arg]
            self.tsdf.columns.get_level_values(0),
            new_labels,
        ]
        self.tsdf.columns = MultiIndex.from_arrays(arrays)
        return self

    def to_cumret(self: Self) -> Self:
        """Convert series of returns into cumulative series of values.

        Returns:
        --------
        OpenFrame
            An OpenFrame object

        """
        vtypes = [x == ValueType.RTRN for x in self.tsdf.columns.get_level_values(1)]
        if not any(vtypes):
            returns = self.tsdf.ffill().pct_change()
            returns.iloc[0] = 0
        elif all(vtypes):
            returns = self.tsdf.copy()
            returns.iloc[0] = 0
        else:
            msg = "Mix of series types will give inconsistent results"
            raise MixedValuetypesError(msg)

        returns = returns.add(1.0)
        self.tsdf = returns.cumprod(axis=0) / returns.iloc[0]

        new_labels: list[ValueType] = [ValueType.PRICE] * self.item_count
        arrays: list[Index[Any], list[ValueType]] = [  # type: ignore[type-arg]
            self.tsdf.columns.get_level_values(0),
            new_labels,
        ]
        self.tsdf.columns = MultiIndex.from_arrays(arrays)
        return self

    def resample(
        self: Self,
        freq: LiteralBizDayFreq | str = "BME",
    ) -> Self:
        """Resample the timeseries frequency.

        Parameters
        ----------
        freq: LiteralBizDayFreq | str, default "BME"
            The date offset string that sets the resampled frequency

        Returns:
        --------
        OpenFrame
            An OpenFrame object

        """
        vtypes = [x == ValueType.RTRN for x in self.tsdf.columns.get_level_values(1)]
        if not any(vtypes):
            value_type = ValueType.PRICE
        elif all(vtypes):
            value_type = ValueType.RTRN
        else:
            msg = "Mix of series types will give inconsistent results"
            raise MixedValuetypesError(msg)

        self.tsdf.index = DatetimeIndex(self.tsdf.index)
        if value_type == ValueType.PRICE:
            self.tsdf = self.tsdf.resample(freq).last()
        else:
            self.tsdf = self.tsdf.resample(freq).sum()
        self.tsdf.index = Index(d.date() for d in DatetimeIndex(self.tsdf.index))
        for xerie in self.constituents:
            xerie.tsdf.index = DatetimeIndex(xerie.tsdf.index)
            if value_type == ValueType.PRICE:
                xerie.tsdf = xerie.tsdf.resample(freq).last()
            else:
                xerie.tsdf = xerie.tsdf.resample(freq).sum()
            xerie.tsdf.index = Index(
                dejt.date() for dejt in DatetimeIndex(xerie.tsdf.index)
            )

        return self

    def resample_to_business_period_ends(
        self: Self,
        freq: LiteralBizDayFreq = "BME",
        method: LiteralPandasReindexMethod = "nearest",
    ) -> Self:
        """Resamples timeseries frequency to the business calendar month end dates.

        Stubs left in place. Stubs will be aligned to the shortest stub.

        Parameters
        ----------
        freq: LiteralBizDayFreq, default "BME"
            The date offset string that sets the resampled frequency
        method: LiteralPandasReindexMethod, default: nearest
            Controls the method used to align values across columns

        Returns:
        --------
        OpenFrame
            An OpenFrame object

        """
        vtypes = [x == ValueType.RTRN for x in self.tsdf.columns.get_level_values(1)]
        if any(vtypes):
            msg = (
                "Do not run resample_to_business_period_ends on return series. "
                "The operation will pick the last data point in the sparser series. "
                "It will not sum returns and therefore data will be lost."
            )
            raise ResampleDataLossError(msg)

        for xerie in self.constituents:
            dates = _do_resample_to_business_period_ends(
                data=xerie.tsdf,
                freq=freq,
                countries=xerie.countries,
                markets=xerie.markets,
            )
            xerie.tsdf = xerie.tsdf.reindex(
                [deyt.date() for deyt in dates],
                method=method,
            )

        arrays = [
            self.tsdf.columns.get_level_values(0),
            self.tsdf.columns.get_level_values(1),
        ]

        self._set_tsdf()

        self.tsdf.columns = MultiIndex.from_arrays(arrays)

        return self

    def ewma_risk(
        self: Self,
        lmbda: float = 0.94,
        day_chunk: int = 11,
        dlta_degr_freedms: int = 0,
        first_column: int = 0,
        second_column: int = 1,
        corr_scale: float = 2.0,
        months_from_last: int | None = None,
        from_date: dt.date | None = None,
        to_date: dt.date | None = None,
        periods_in_a_year_fixed: DaysInYearType | None = None,
    ) -> DataFrame:
        """Exponentially Weighted Moving Average Volatilities and Correlation.

        Exponentially Weighted Moving Average (EWMA) for Volatilities and
        Correlation. https://www.investopedia.com/articles/07/ewma.asp.

        Parameters
        ----------
        lmbda: float, default: 0.94
            Scaling factor to determine weighting.
        day_chunk: int, default: 11
            Sampling the data which is assumed to be daily.
        dlta_degr_freedms: int, default: 0
            Variance bias factor taking the value 0 or 1.
        first_column: int, default: 0
            Column of first timeseries.
        second_column: int, default: 1
            Column of second timeseries.
        corr_scale: float, default: 2.0
            Correlation scale factor.
        months_from_last : int, optional
            number of months offset as positive integer. Overrides use of from_date
            and to_date
        from_date : datetime.date, optional
            Specific from date
        to_date : datetime.date, optional
            Specific to date
        periods_in_a_year_fixed : DaysInYearType, optional
            Allows locking the periods-in-a-year to simplify test cases and
            comparisons

        Returns:
        --------
        Pandas.DataFrame
            Series volatilities and correlation

        """
        earlier, later = self.calc_range(
            months_offset=months_from_last,
            from_dt=from_date,
            to_dt=to_date,
        )
        if periods_in_a_year_fixed is None:
            fraction = (later - earlier).days / 365.25
            how_many = (
                self.tsdf.loc[cast("Timestamp", earlier) : cast("Timestamp", later)]
                .count()
                .iloc[0]
            )
            time_factor = how_many / fraction
        else:
            time_factor = periods_in_a_year_fixed

        corr_label = (
            cast("tuple[str, str]", self.tsdf.iloc[:, first_column].name)[0]
            + "_VS_"
            + cast("tuple[str, str]", self.tsdf.iloc[:, second_column].name)[0]
        )
        cols = [
            cast("tuple[str, str]", self.tsdf.iloc[:, first_column].name)[0],
            cast("tuple[str, str]", self.tsdf.iloc[:, second_column].name)[0],
        ]

        data = self.tsdf.loc[
            cast("Timestamp", earlier) : cast("Timestamp", later)
        ].copy()

        for rtn in cols:
            arr = concatenate([array([nan]), diff(log(data[(rtn, ValueType.PRICE)]))])
            data[rtn, ValueType.RTRN] = arr

        raw_one = [
            data[(cols[0], ValueType.RTRN)]
            .iloc[1:day_chunk]
            .std(ddof=dlta_degr_freedms)
            * sqrt(time_factor),
        ]
        raw_two = [
            data[(cols[1], ValueType.RTRN)]
            .iloc[1:day_chunk]
            .std(ddof=dlta_degr_freedms)
            * sqrt(time_factor),
        ]
        rm = data[(cols[0], ValueType.RTRN)].iloc[1:day_chunk]
        m: NDArray[float64] = asarray(rm, dtype=float64)
        ry = data[(cols[1], ValueType.RTRN)].iloc[1:day_chunk]
        y: NDArray[float64] = asarray(ry, dtype=float64)

        raw_cov = [cov(m=m, y=y, ddof=dlta_degr_freedms)[0][1]]

        r1 = data[(cols[0], ValueType.RTRN)]
        r2 = data[(cols[1], ValueType.RTRN)]

        alpha = 1.0 - lmbda

        s1 = (r1.pow(2) * time_factor).copy()
        s2 = (r2.pow(2) * time_factor).copy()
        sc = (r1 * r2 * time_factor).copy()

        s1.iloc[0] = float(raw_one[0] ** 2)
        s2.iloc[0] = float(raw_two[0] ** 2)
        sc.iloc[0] = float(raw_cov[0])

        m1 = s1.ewm(alpha=alpha, adjust=False).mean()
        m2 = s2.ewm(alpha=alpha, adjust=False).mean()
        mc = sc.ewm(alpha=alpha, adjust=False).mean()

        m1v = m1.to_numpy(copy=False)
        m2v = m2.to_numpy(copy=False)
        mcv = mc.to_numpy(copy=False)

        vol1 = sqrt(m1v)
        vol2 = sqrt(m2v)
        denom = corr_scale * vol1 * vol2

        corr = mcv / denom
        corr[denom == 0.0] = nan

        return DataFrame(
            index=[*cols, corr_label],
            columns=data.index,
            data=[vol1, vol2, corr],
        ).T

    @property
    def correl_matrix(self: Self) -> DataFrame:
        """Correlation matrix.

        This property returns the correlation matrix of the time series
        in the frame.

        Returns:
        --------
        pandas.DataFrame
            Correlation matrix of the time series in the frame.

        """
        corr_matrix = (
            self.tsdf.ffill()
            .pct_change()
            .corr(
                method="pearson",
                min_periods=1,
            )
        )
        corr_matrix.columns = corr_matrix.columns.droplevel(level=1)
        corr_matrix.index = corr_matrix.index.droplevel(level=1)
        corr_matrix.index.name = "Correlation"
        return corr_matrix

    def add_timeseries(
        self: Self,
        new_series: OpenTimeSeries,
    ) -> Self:
        """To add an OpenTimeSeries object.

        Parameters
        ----------
        new_series: OpenTimeSeries
            The timeseries to add

        Returns:
        --------
        OpenFrame
            An OpenFrame object

        """
        self.constituents += [new_series]
        self.tsdf = concat([self.tsdf, new_series.tsdf], axis="columns", sort=True)
        return self

    def delete_timeseries(self: Self, lvl_zero_item: str) -> Self:
        """To delete an OpenTimeSeries object.

        Parameters
        ----------
        lvl_zero_item: str
            The .tsdf column level 0 value of the timeseries to delete

        Returns:
        --------
        OpenFrame
            An OpenFrame object

        """
        if self.weights:
            new_c, new_w = [], []
            for serie, weight in zip(self.constituents, self.weights, strict=True):
                if serie.label != lvl_zero_item:
                    new_c.append(serie)
                    new_w.append(weight)
            self.constituents = new_c
            self.weights = new_w
        else:
            self.constituents = [
                item for item in self.constituents if item.label != lvl_zero_item
            ]
        self.tsdf = self.tsdf.drop(lvl_zero_item, axis="columns", level=0)
        return self

    def trunc_frame(
        self: Self,
        start_cut: dt.date | None = None,
        end_cut: dt.date | None = None,
        where: LiteralTrunc = "both",
    ) -> Self:
        """Truncate DataFrame such that all timeseries have the same time span.

        Parameters
        ----------
        start_cut: datetime.date, optional
            New first date
        end_cut: datetime.date, optional
            New last date
        where: LiteralTrunc, default: both
            Determines where dataframe is truncated also when start_cut
            or end_cut is None.

        Returns:
        --------
        OpenFrame
            An OpenFrame object

        """
        if not start_cut and where in ["before", "both"]:
            start_cut = self.first_indices.max()
        if not end_cut and where in ["after", "both"]:
            end_cut = self.last_indices.min()
        self.tsdf = self.tsdf.sort_index()
        self.tsdf = self.tsdf.truncate(before=start_cut, after=end_cut, copy=False)

        for xerie in self.constituents:
            xerie.tsdf = xerie.tsdf.truncate(
                before=start_cut,
                after=end_cut,
                copy=False,
            )
        if len(set(self.first_indices)) != 1:
            msg = (
                f"One or more constituents still "
                f"not truncated to same start dates.\n"
                f"{self.tsdf.head()}"
            )
            logger.warning(msg=msg)
        if len(set(self.last_indices)) != 1:
            msg = (
                f"One or more constituents still "
                f"not truncated to same end dates.\n"
                f"{self.tsdf.tail()}"
            )
            logger.warning(msg=msg)
        return self

    def relative(
        self: Self,
        long_column: int = 0,
        short_column: int = 1,
        *,
        base_zero: bool = True,
    ) -> None:
        """Calculate cumulative relative return between two series.

        Parameters
        ----------
        long_column: int, default: 0
            Column number of timeseries bought
        short_column: int, default: 1
            Column number of timeseries sold
        base_zero: bool, default: True
            If set to False 1.0 is added to allow for a capital base and
            to allow a volatility calculation

        """
        rel_label = (
            cast("tuple[str, str]", self.tsdf.iloc[:, long_column].name)[0]
            + "_over_"
            + cast("tuple[str, str]", self.tsdf.iloc[:, short_column].name)[0]
        )
        if base_zero:
            self.tsdf[rel_label, ValueType.RELRTRN] = (
                self.tsdf.iloc[:, long_column] - self.tsdf.iloc[:, short_column]
            )
        else:
            self.tsdf[rel_label, ValueType.RELRTRN] = (
                1.0 + self.tsdf.iloc[:, long_column] - self.tsdf.iloc[:, short_column]
            )
        self.constituents += [
            OpenTimeSeries.from_df(self.tsdf.iloc[:, -1]),
        ]

    def tracking_error_func(
        self: Self,
        base_column: tuple[str, ValueType] | int = -1,
        months_from_last: int | None = None,
        from_date: dt.date | None = None,
        to_date: dt.date | None = None,
        periods_in_a_year_fixed: DaysInYearType | None = None,
    ) -> Series[float]:
        """Tracking Error.

        Calculates Tracking Error which is the standard deviation of the
        difference between the fund and its index returns.
        https://www.investopedia.com/terms/t/trackingerror.asp.

        Parameters
        ----------
        base_column: tuple[str, ValueType] | int, default: -1
            Column of timeseries that is the denominator in the ratio.
        months_from_last : int, optional
            number of months offset as positive integer. Overrides use of from_date
            and to_date
        from_date : datetime.date, optional
            Specific from date
        to_date : datetime.date, optional
            Specific to date
        periods_in_a_year_fixed : DaysInYearType, optional
            Allows locking the periods-in-a-year to simplify test cases and
            comparisons

        Returns:
        --------
        Pandas.Series[float]
            Tracking Errors

        """
        earlier, later = self.calc_range(
            months_offset=months_from_last,
            from_dt=from_date,
            to_dt=to_date,
        )

        shortdf, short_item, short_label = _get_base_column_data(
            self=self,
            base_column=base_column,
            earlier=earlier,
            later=later,
        )

        time_factor = _calculate_time_factor(
            data=shortdf,
            earlier=earlier,
            later=later,
            periods_in_a_year_fixed=periods_in_a_year_fixed,
        )

        terrors = []
        for item in self.tsdf:
            if item == short_item:
                terrors.append(0.0)
            else:
                longdf = self.tsdf.loc[
                    cast("Timestamp", earlier) : cast("Timestamp", later)
                ][item]
                relative = longdf.ffill().pct_change() - shortdf.ffill().pct_change()
                vol = float(relative.std() * sqrt(time_factor))
                terrors.append(vol)

        return Series(
            data=terrors,
            index=self.tsdf.columns,
            name=f"Tracking Errors vs {short_label}",
            dtype="float64",
        )

    def info_ratio_func(
        self: Self,
        base_column: tuple[str, ValueType] | int = -1,
        months_from_last: int | None = None,
        from_date: dt.date | None = None,
        to_date: dt.date | None = None,
        periods_in_a_year_fixed: DaysInYearType | None = None,
    ) -> Series[float]:
        """Information Ratio.

        The Information Ratio equals ( fund return less index return ) divided
        by the Tracking Error. And the Tracking Error is the standard deviation of
        the difference between the fund and its index returns.
        The ratio is calculated using the annualized arithmetic mean of returns.

        Parameters
        ----------
        base_column: tuple[str, ValueType] | int, default: -1
            Column of timeseries that is the denominator in the ratio.
        months_from_last : int, optional
            number of months offset as positive integer. Overrides use of from_date
            and to_date
        from_date : datetime.date, optional
            Specific from date
        to_date : datetime.date, optional
            Specific to date
        periods_in_a_year_fixed : DaysInYearType, optional
            Allows locking the periods-in-a-year to simplify test cases and
            comparisons

        Returns:
        --------
        Pandas.Series[float]
            Information Ratios

        """
        earlier, later = self.calc_range(
            months_offset=months_from_last,
            from_dt=from_date,
            to_dt=to_date,
        )

        shortdf, short_item, short_label = _get_base_column_data(
            self=self,
            base_column=base_column,
            earlier=earlier,
            later=later,
        )

        time_factor = _calculate_time_factor(
            data=shortdf,
            earlier=earlier,
            later=later,
            periods_in_a_year_fixed=periods_in_a_year_fixed,
        )

        ratios = []
        for item in self.tsdf:
            if item == short_item:
                ratios.append(0.0)
            else:
                longdf = self.tsdf.loc[
                    cast("Timestamp", earlier) : cast("Timestamp", later)
                ][item]
                relative = longdf.ffill().pct_change() - shortdf.ffill().pct_change()
                ret = float(relative.mean() * time_factor)
                vol = float(relative.std() * sqrt(time_factor))
                ratios.append(ret / vol)

        return Series(
            data=ratios,
            index=self.tsdf.columns,
            name=f"Info Ratios vs {short_label}",
            dtype="float64",
        )

    def capture_ratio_func(
        self: Self,
        ratio: LiteralCaptureRatio,
        base_column: tuple[str, ValueType] | int = -1,
        months_from_last: int | None = None,
        from_date: dt.date | None = None,
        to_date: dt.date | None = None,
        periods_in_a_year_fixed: DaysInYearType | None = None,
    ) -> Series[float]:
        """Capture Ratio.

        The Up (Down) Capture Ratio is calculated by dividing the CAGR
        of the asset during periods that the benchmark returns are positive (negative)
        by the CAGR of the benchmark during the same periods.
        CaptureRatio.BOTH is the Up ratio divided by the Down ratio.
        Source: 'Capture Ratios: A Popular Method of Measuring Portfolio Performance
        in Practice', Don R. Cox and Delbert C. Goff, Journal of Economics and
        Finance Education (Vol 2 Winter 2013).
        https://www.economics-finance.org/jefe/volume12-2/11ArticleCox.pdf.

        Parameters
        ----------
        ratio: LiteralCaptureRatio
            The ratio to calculate
        base_column: tuple[str, ValueType] | int, default: -1
            Column of timeseries that is the denominator in the ratio.
        months_from_last : int, optional
            number of months offset as positive integer. Overrides use of from_date
            and to_date
        from_date : datetime.date, optional
            Specific from date
        to_date : datetime.date, optional
            Specific to date
        periods_in_a_year_fixed : DaysInYearType, optional
            Allows locking the periods-in-a-year to simplify test cases and
            comparisons

        Returns:
        --------
        Pandas.Series[float]
            Capture Ratios

        """
        loss_limit: float = 0.0
        earlier, later = self.calc_range(
            months_offset=months_from_last,
            from_dt=from_date,
            to_dt=to_date,
        )
        fraction: float = (later - earlier).days / 365.25

        msg = "base_column should be a tuple[str, ValueType] or an integer."
        if isinstance(base_column, tuple):
            shortdf = self.tsdf.loc[
                cast("Timestamp", earlier) : cast("Timestamp", later)
            ][base_column]
            short_item = base_column
            short_label = cast(
                "tuple[str, str]",
                self.tsdf[base_column].name,
            )[0]
        elif isinstance(base_column, int):
            shortdf = self.tsdf.loc[
                cast("Timestamp", earlier) : cast("Timestamp", later)
            ].iloc[:, base_column]
            short_item = cast(
                "tuple[str, ValueType]",
                self.tsdf.iloc[
                    :,
                    base_column,
                ].name,
            )
            short_label = cast("tuple[str, str]", self.tsdf.iloc[:, base_column].name)[
                0
            ]
        else:
            raise TypeError(msg)

        if periods_in_a_year_fixed:
            time_factor = float(periods_in_a_year_fixed)
        else:
            time_factor = shortdf.count() / fraction

        ratios = []
        for item in self.tsdf:
            if item == short_item:
                ratios.append(0.0)
            else:
                longdf = self.tsdf.loc[
                    cast("Timestamp", earlier) : cast("Timestamp", later)
                ][item]
                msg = "ratio must be one of 'up', 'down' or 'both'."
                if ratio == "up":
                    uparray = (
                        longdf.ffill()
                        .pct_change()[
                            shortdf.ffill().pct_change().to_numpy() > loss_limit
                        ]
                        .add(1)
                        .to_numpy()
                    )
                    up_rtrn = uparray.prod() ** (1 / (len(uparray) / time_factor)) - 1
                    upidxarray = (
                        shortdf.ffill()
                        .pct_change()[
                            shortdf.ffill().pct_change().to_numpy() > loss_limit
                        ]
                        .add(1)
                        .to_numpy()
                    )
                    up_idx_return = (
                        upidxarray.prod() ** (1 / (len(upidxarray) / time_factor)) - 1
                    )
                    ratios.append(up_rtrn / up_idx_return)
                elif ratio == "down":
                    downarray = (
                        longdf.ffill()
                        .pct_change()[
                            shortdf.ffill().pct_change().to_numpy() < loss_limit
                        ]
                        .add(1)
                        .to_numpy()
                    )
                    down_return = (
                        downarray.prod() ** (1 / (len(downarray) / time_factor)) - 1
                    )
                    downidxarray = (
                        shortdf.ffill()
                        .pct_change()[
                            shortdf.ffill().pct_change().to_numpy() < loss_limit
                        ]
                        .add(1)
                        .to_numpy()
                    )
                    down_idx_return = (
                        downidxarray.prod() ** (1 / (len(downidxarray) / time_factor))
                        - 1
                    )
                    ratios.append(down_return / down_idx_return)
                elif ratio == "both":
                    uparray = (
                        longdf.ffill()
                        .pct_change()[
                            shortdf.ffill().pct_change().to_numpy() > loss_limit
                        ]
                        .add(1)
                        .to_numpy()
                    )
                    up_rtrn = uparray.prod() ** (1 / (len(uparray) / time_factor)) - 1
                    upidxarray = (
                        shortdf.ffill()
                        .pct_change()[
                            shortdf.ffill().pct_change().to_numpy() > loss_limit
                        ]
                        .add(1)
                        .to_numpy()
                    )
                    up_idx_return = (
                        upidxarray.prod() ** (1 / (len(upidxarray) / time_factor)) - 1
                    )
                    downarray = (
                        longdf.ffill()
                        .pct_change()[
                            shortdf.ffill().pct_change().to_numpy() < loss_limit
                        ]
                        .add(1)
                        .to_numpy()
                    )
                    down_return = (
                        downarray.prod() ** (1 / (len(downarray) / time_factor)) - 1
                    )
                    downidxarray = (
                        shortdf.ffill()
                        .pct_change()[
                            shortdf.ffill().pct_change().to_numpy() < loss_limit
                        ]
                        .add(1)
                        .to_numpy()
                    )
                    down_idx_return = (
                        downidxarray.prod() ** (1 / (len(downidxarray) / time_factor))
                        - 1
                    )
                    ratios.append(
                        (up_rtrn / up_idx_return) / (down_return / down_idx_return),
                    )
                else:
                    raise RatioInputError(msg)

        if ratio == "up":
            resultname = f"Up Capture Ratios vs {short_label}"
        elif ratio == "down":
            resultname = f"Down Capture Ratios vs {short_label}"
        else:
            resultname = f"Up-Down Capture Ratios vs {short_label}"

        return Series(
            data=ratios,
            index=self.tsdf.columns,
            name=resultname,
            dtype="float64",
        )

    def beta(
        self: Self,
        asset: tuple[str, ValueType] | int,
        market: tuple[str, ValueType] | int,
        dlta_degr_freedms: int = 1,
    ) -> float:
        """Market Beta.

        Calculates Beta as Co-variance of asset & market divided by Variance
        of the market. https://www.investopedia.com/terms/b/beta.asp.

        Parameters
        ----------
        asset: tuple[str, ValueType] | int
            The column of the asset
        market: tuple[str, ValueType] | int
            The column of the market against which Beta is measured
        dlta_degr_freedms: int, default: 1
            Variance bias factor taking the value 0 or 1.

        Returns:
        --------
        float
            Beta as Co-variance of x & y divided by Variance of x

        """
        vtypes = [x == ValueType.RTRN for x in self.tsdf.columns.get_level_values(1)]
        if all(vtypes):
            msg = "asset should be a tuple[str, ValueType] or an integer."
            if isinstance(asset, tuple):
                y_value = self.tsdf[asset]
            elif isinstance(asset, int):
                y_value = self.tsdf.iloc[:, asset]
            else:
                raise TypeError(msg)

            msg = "market should be a tuple[str, ValueType] or an integer."
            if isinstance(market, tuple):
                x_value = self.tsdf[market]
            elif isinstance(market, int):
                x_value = self.tsdf.iloc[:, market]
            else:
                raise TypeError(msg)
        elif not any(vtypes):
            msg = "asset should be a tuple[str, ValueType] or an integer."
            if isinstance(asset, tuple):
                y_value = self.tsdf[asset].ffill().pct_change().iloc[1:]
            elif isinstance(asset, int):
                y_value = self.tsdf.iloc[:, asset].ffill().pct_change().iloc[1:]
            else:
                raise TypeError(msg)
            msg = "market should be a tuple[str, ValueType] or an integer."

            if isinstance(market, tuple):
                x_value = self.tsdf[market].ffill().pct_change().iloc[1:]
            elif isinstance(market, int):
                x_value = self.tsdf.iloc[:, market].ffill().pct_change().iloc[1:]
            else:
                raise TypeError(msg)
        else:
            msg = "Mix of series types will give inconsistent results"
            raise MixedValuetypesError(msg)

        covariance = cov(m=y_value, y=x_value, ddof=dlta_degr_freedms)
        beta = covariance[0, 1] / covariance[1, 1]

        return float(beta)

    def ord_least_squares_fit(
        self: Self,
        y_column: tuple[str, ValueType] | int,
        x_column: tuple[str, ValueType] | int,
        *,
        fitted_series: bool = True,
    ) -> dict[str, float]:
        """Ordinary Least Squares fit.

        Performs a linear regression and adds a new column with a fitted line
        using Ordinary Least Squares fit

        Parameters
        ----------
        y_column: tuple[str, ValueType] | int
            The column level values of the dependent variable y
        x_column: tuple[str, ValueType] | int
            The column level values of the exogenous variable x
        fitted_series: bool, default: True
            If True the fit is added as a new column in the .tsdf Pandas.DataFrame

        Returns:
        --------
        dict[str, float]
            A dictionary with the coefficient, intercept and rsquared outputs.

        """
        msg = "y_column should be a tuple[str, ValueType] or an integer."
        if isinstance(y_column, tuple):
            y_value = self.tsdf[y_column].to_numpy()
            y_label = cast(
                "tuple[str, str]",
                self.tsdf[y_column].name,
            )[0]
        elif isinstance(y_column, int):
            y_value = self.tsdf.iloc[:, y_column].to_numpy()
            y_label = cast("tuple[str, str]", self.tsdf.iloc[:, y_column].name)[0]
        else:
            raise TypeError(msg)

        msg = "x_column should be a tuple[str, ValueType] or an integer."
        if isinstance(x_column, tuple):
            x_value = self.tsdf[x_column].to_numpy().reshape(-1, 1)
            x_label = cast(
                "tuple[str, str]",
                self.tsdf[x_column].name,
            )[0]
        elif isinstance(x_column, int):
            x_value = self.tsdf.iloc[:, x_column].to_numpy().reshape(-1, 1)
            x_label = cast("tuple[str, str]", self.tsdf.iloc[:, x_column].name)[0]
        else:
            raise TypeError(msg)

        model = LinearRegression(fit_intercept=True)
        model.fit(x_value, y_value)
        if fitted_series:
            self.tsdf[y_label, x_label] = model.predict(x_value)
        return {
            "coefficient": model.coef_[0],
            "intercept": model.intercept_,
            "rsquared": model.score(x_value, y_value),
        }

    def jensen_alpha(
        self: Self,
        asset: tuple[str, ValueType] | int,
        market: tuple[str, ValueType] | int,
        riskfree_rate: float = 0.0,
        dlta_degr_freedms: int = 1,
    ) -> float:
        """Jensen's alpha.

        The Jensen's measure, or Jensen's alpha, is a risk-adjusted performance
        measure that represents the average return on a portfolio or investment,
        above or below that predicted by the capital asset pricing model (CAPM),
        given the portfolio's or investment's beta and the average market return.
        This metric is also commonly referred to as simply alpha.
        https://www.investopedia.com/terms/j/jensensmeasure.asp.

        Parameters
        ----------
        asset: tuple[str, ValueType] | int
            The column of the asset
        market: tuple[str, ValueType] | int
            The column of the market against which Jensen's alpha is measured
        riskfree_rate : float, default: 0.0
            The return of the zero volatility riskfree asset
        dlta_degr_freedms: int, default: 1
            Variance bias factor taking the value 0 or 1.

        Returns:
        --------
        float
            Jensen's alpha

        """
        vtypes = [x == ValueType.RTRN for x in self.tsdf.columns.get_level_values(1)]
        if not any(vtypes):
            msg = "asset should be a tuple[str, ValueType] or an integer."
            if isinstance(asset, tuple):
                asset_rtn = self.tsdf[asset].ffill().pct_change().iloc[1:]
                asset_rtn_mean = float(asset_rtn.mean() * self.periods_in_a_year)
            elif isinstance(asset, int):
                asset_rtn = self.tsdf.iloc[:, asset].ffill().pct_change().iloc[1:]
                asset_rtn_mean = float(asset_rtn.mean() * self.periods_in_a_year)
            else:
                raise TypeError(msg)

            msg = "market should be a tuple[str, ValueType] or an integer."
            if isinstance(market, tuple):
                market_rtn = self.tsdf[market].ffill().pct_change().iloc[1:]
                market_rtn_mean = float(market_rtn.mean() * self.periods_in_a_year)
            elif isinstance(market, int):
                market_rtn = self.tsdf.iloc[:, market].ffill().pct_change().iloc[1:]
                market_rtn_mean = float(market_rtn.mean() * self.periods_in_a_year)
            else:
                raise TypeError(msg)
        elif all(vtypes):
            msg = "asset should be a tuple[str, ValueType] or an integer."
            if isinstance(asset, tuple):
                asset_rtn = self.tsdf[asset]
                asset_rtn_mean = float(asset_rtn.mean() * self.periods_in_a_year)
            elif isinstance(asset, int):
                asset_rtn = self.tsdf.iloc[:, asset]
                asset_rtn_mean = float(asset_rtn.mean() * self.periods_in_a_year)
            else:
                raise TypeError(msg)

            msg = "market should be a tuple[str, ValueType] or an integer."
            if isinstance(market, tuple):
                market_rtn = self.tsdf[market]
                market_rtn_mean = float(market_rtn.mean() * self.periods_in_a_year)
            elif isinstance(market, int):
                market_rtn = self.tsdf.iloc[:, market]
                market_rtn_mean = float(market_rtn.mean() * self.periods_in_a_year)
            else:
                raise TypeError(msg)
        else:
            msg = "Mix of series types will give inconsistent results"
            raise MixedValuetypesError(msg)

        covariance = cov(m=asset_rtn, y=market_rtn, ddof=dlta_degr_freedms)
        beta = covariance[0, 1] / covariance[1, 1]

        return float(
            asset_rtn_mean - riskfree_rate - beta * (market_rtn_mean - riskfree_rate),
        )

    def make_portfolio(
        self: Self,
        name: str,
        weight_strat: LiteralPortfolioWeightings | None = None,
    ) -> DataFrame:
        """Calculate a basket timeseries based on the supplied weights.

        Parameters
        ----------
        name: str
            Name of the basket timeseries
        weight_strat: LiteralPortfolioWeightings, optional
            weight calculation strategies

        Returns:
        --------
        Pandas.DataFrame
            A basket timeseries

        """
        if self.weights is None and weight_strat is None:
            msg = (
                "OpenFrame weights property must be provided "
                "to run the make_portfolio method."
            )
            raise NoWeightsError(msg)

        vtypes = [x == ValueType.RTRN for x in self.tsdf.columns.get_level_values(1)]
        if not any(vtypes):
            returns = self.tsdf.ffill().pct_change()
            returns.iloc[0] = 0
        elif all(vtypes):
            returns = self.tsdf
        else:
            msg = "Mix of series types will give inconsistent results"
            raise MixedValuetypesError(msg)

        msg = "Weight strategy not implemented"
        if weight_strat:
            if weight_strat == "eq_weights":
                self.weights = [1.0 / self.item_count] * self.item_count
            elif weight_strat == "inv_vol":
                vol = divide(1.0, std(returns, axis=0, ddof=1))
                vol[isinf(vol)] = nan
                self.weights = list(divide(vol, vol.sum()))
            elif weight_strat == "max_div":
                corr_matrix = corrcoef(returns.T)
                corr_matrix[isinf(corr_matrix)] = nan
                corr_matrix[isnan(corr_matrix)] = nan
                try:
                    inv_corr_sum = linalg.inv(corr_matrix).sum(axis=1)
                    self.weights = list(divide(inv_corr_sum, inv_corr_sum.sum()))
                except linalg.LinAlgError:
                    self.weights = [1.0 / self.item_count] * self.item_count
            elif weight_strat == "target_risk":
                vols = std(returns, axis=0, ddof=1)
                min_vol_idx = vols.argmin()
                min_vol_weight = 0.6
                remaining_weight = 0.4
                weights = [remaining_weight / (self.item_count - 1)] * self.item_count
                weights[min_vol_idx] = min_vol_weight
                self.weights = weights
            else:
                raise NotImplementedError(msg)

        return DataFrame(
            data=(returns @ array(self.weights)).add(1.0).cumprod(),
            index=self.tsdf.index,
            columns=[[name], [ValueType.PRICE]],
            dtype="float64",
        )

    def rolling_info_ratio(
        self: Self,
        long_column: int = 0,
        short_column: int = 1,
        observations: int = 21,
        periods_in_a_year_fixed: DaysInYearType | None = None,
    ) -> DataFrame:
        """Calculate rolling Information Ratio.

        The Information Ratio equals ( fund return less index return ) divided by
        the Tracking Error. And the Tracking Error is the standard deviation of the
        difference between the fund and its index returns.

        Parameters
        ----------
        long_column: int, default: 0
            Column of timeseries that is the numerator in the ratio.
        short_column: int, default: 1
            Column of timeseries that is the denominator in the ratio.
        observations: int, default: 21
            The length of the rolling window to use is set as number of observations.
        periods_in_a_year_fixed : DaysInYearType, optional
            Allows locking the periods-in-a-year to simplify test cases and comparisons

        Returns:
        --------
        Pandas.DataFrame
            Rolling Information Ratios

        """
        long_label = cast(
            "tuple[str, str]",
            self.tsdf.iloc[:, long_column].name,
        )[0]
        short_label = cast(
            "tuple[str, str]",
            self.tsdf.iloc[:, short_column].name,
        )[0]
        ratio_label = f"{long_label} / {short_label}"
        if periods_in_a_year_fixed:
            time_factor = float(periods_in_a_year_fixed)
        else:
            time_factor = self.periods_in_a_year

        relative = (
            1.0 + self.tsdf.iloc[:, long_column] - self.tsdf.iloc[:, short_column]
        )

        retseries = (
            relative.ffill()
            .pct_change()
            .rolling(observations, min_periods=observations)
            .sum()
        )
        retdf = retseries.dropna().to_frame()

        voldf = relative.ffill().pct_change().rolling(
            observations,
            min_periods=observations,
        ).std() * sqrt(time_factor)
        voldf = voldf.dropna().to_frame()

        ratiodf = (retdf.iloc[:, 0] / voldf.iloc[:, 0]).to_frame()
        ratiodf.columns = [[ratio_label], ["Information Ratio"]]

        return DataFrame(ratiodf)

    def rolling_beta(
        self: Self,
        asset_column: int = 0,
        market_column: int = 1,
        observations: int = 21,
        dlta_degr_freedms: int = 1,
    ) -> DataFrame:
        """Calculate rolling Market Beta.

        Calculates Beta as Co-variance of asset & market divided by Variance
        of the market. https://www.investopedia.com/terms/b/beta.asp.

        Parameters
        ----------
        asset_column: int, default: 0
            Column of timeseries that is the asset.
        market_column: int, default: 1
            Column of timeseries that is the market.
        observations: int, default: 21
            The length of the rolling window to use is set as number of observations.
        dlta_degr_freedms: int, default: 1
            Variance bias factor taking the value 0 or 1.

        Returns:
        --------
        Pandas.DataFrame
            Rolling Betas

        """
        market_label = cast("tuple[str, str]", self.tsdf.iloc[:, market_column].name)[
            0
        ]
        asset_label = cast("tuple[str, str]", self.tsdf.iloc[:, asset_column].name)[0]
        beta_label = f"{asset_label} / {market_label}"

        rolling = (
            self.tsdf.ffill()
            .pct_change()
            .rolling(
                observations,
                min_periods=observations,
            )
        )

        rcov = rolling.cov(ddof=dlta_degr_freedms)
        rcov = rcov.dropna()

        rollbetaseries = rcov.iloc[:, asset_column].xs(
            market_label,
            level=1,
        ) / rcov.iloc[
            :,
            market_column,
        ].xs(
            market_label,
            level=1,
        )
        rollbeta = rollbetaseries.to_frame()
        rollbeta.index = rollbeta.index.droplevel(level=1)
        rollbeta.columns = MultiIndex.from_arrays([[beta_label], ["Beta"]])

        return rollbeta

    def rolling_corr(
        self: Self,
        first_column: int = 0,
        second_column: int = 1,
        observations: int = 21,
    ) -> DataFrame:
        """Calculate rolling Correlation.

        Calculates correlation between two series. The period with
        at least the given number of observations is the first period calculated.

        Parameters
        ----------
        first_column: int, default: 0
            The position as integer of the first timeseries to compare
        second_column: int, default: 1
            The position as integer of the second timeseries to compare
        observations: int, default: 21
            The length of the rolling window to use is set as number of observations

        Returns:
        --------
        Pandas.DataFrame
            Rolling Correlations

        """
        corr_label = (
            cast("tuple[str, str]", self.tsdf.iloc[:, first_column].name)[0]
            + "_VS_"
            + cast("tuple[str, str]", self.tsdf.iloc[:, second_column].name)[0]
        )
        first_series = (
            self.tsdf.iloc[:, first_column]
            .ffill()
            .pct_change()[1:]
            .rolling(observations, min_periods=observations)
        )
        second_series = self.tsdf.iloc[:, second_column].ffill().pct_change()[1:]
        corrdf = first_series.corr(other=second_series).dropna().to_frame()
        corrdf.columns = MultiIndex.from_arrays(
            [
                [corr_label],
                ["Rolling correlation"],
            ],
        )

        return DataFrame(corrdf)

    def multi_factor_linear_regression(
        self: Self,
        dependent_column: tuple[str, ValueType],
    ) -> tuple[DataFrame, OpenTimeSeries]:
        """Perform a multi-factor linear regression.

        This function treats one specified column in the DataFrame as the dependent
        variable (y) and uses all remaining columns as independent variables (X).
        It utilizes a scikit-learn LinearRegression model and returns a DataFrame
        with summary output and an OpenTimeSeries of predicted values.

        Parameters
        ----------
        dependent_column: tuple[str, ValueType]
            A tuple key to select the column in the OpenFrame.tsdf.columns
            to use as the dependent variable

        Returns:
        --------
        tuple[pandas.DataFrame, OpenTimeSeries]
            - A DataFrame with the R-squared, the intercept
              and the regression coefficients
            - An OpenTimeSeries of predicted values

        Raises:
            KeyError: If the column tuple is not found in the OpenFrame.tsdf.columns
            ValueError: If not all series are returnseries (ValueType.RTRN)
        """
        key_msg = (
            f"Tuple ({dependent_column[0]}, "
            f"{dependent_column[1].value}) not found in data."
        )
        if dependent_column not in self.tsdf.columns:
            raise KeyError(key_msg)

        vtype_msg = "All series should be of ValueType.RTRN."
        if not all(x == ValueType.RTRN for x in self.tsdf.columns.get_level_values(1)):
            raise MixedValuetypesError(vtype_msg)

        dependent = self.tsdf[dependent_column]
        factors = self.tsdf.drop(columns=[dependent_column])
        indx = ["R-square", "Intercept", *factors.columns.droplevel(level=1)]

        model = LinearRegression()
        model.fit(factors, dependent)

        predictions = OpenTimeSeries.from_arrays(
            name=f"Predicted {dependent_column[0]}",
            dates=[date.strftime("%Y-%m-%d") for date in self.tsdf.index],
            values=list(model.predict(factors)),
            valuetype=ValueType.RTRN,
        )

        output = [model.score(factors, dependent), model.intercept_, *model.coef_]

        result = DataFrame(data=output, index=indx, columns=[dependent_column[0]])

        return result, predictions.to_cumret()
