""" Entry point of mlx.unity2junit package """
from .unity2junit import main

if __name__ == '__main__':
    main()
