"""Module with all analysis scripts."""

from .colinear_tracks import *
from .event import *
from .metrics import *
from .save import *
