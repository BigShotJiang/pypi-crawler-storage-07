"""Detector geometry module."""

from .manager import Geometry
