class RecaptchaException(Exception):
    pass
