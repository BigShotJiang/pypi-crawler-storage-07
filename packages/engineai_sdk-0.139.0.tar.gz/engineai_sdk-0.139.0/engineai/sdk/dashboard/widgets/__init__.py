"""Specs for Widgets."""
