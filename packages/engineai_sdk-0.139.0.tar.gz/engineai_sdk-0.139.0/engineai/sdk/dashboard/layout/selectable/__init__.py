"""Specs for selectable layouts."""
