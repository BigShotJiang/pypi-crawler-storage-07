"""Spec for Card layout."""
