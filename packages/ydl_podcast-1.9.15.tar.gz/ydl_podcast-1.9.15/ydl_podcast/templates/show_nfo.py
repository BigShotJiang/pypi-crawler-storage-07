SHOW_NFO_TMPL = """<?xml version="1.0" encoding="utf-8" standalone="yes"?>
<tvshow>
  <lockdata>true</lockdata>
  <title>{{ title  }}</title>
</tvshow>
"""
