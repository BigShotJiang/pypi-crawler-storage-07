# -*- coding: utf-8 -*-

from .caster import ram_caster

caster = ram_caster

__version__ = "1.40.0"