from .mluacores import *
from .mluaroots import *
from .mlualogs import *
from .mluaenvs import *

@MLuaLoggerDecorator.info("Checking status.")
def status():
    MLuaLoggerDisplayer.info("Normal.")

def requirements() -> None:
    print("\n".join(["lupa", "colorama"]))

@MLuaLoggerDecorator.info("Testing module.")
@MLuaLoggerDecorator.timer()
def test(path: str) -> None:
    lua = MLuaEnvironment()
    module = MLuaModule(path)
    result = module.mount(lua)
    print(result)
