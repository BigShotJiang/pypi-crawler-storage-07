# -*- coding: utf-8 -*-

from .caster import sagemaker_caster

caster = sagemaker_caster

__version__ = "1.40.0"