# -*- coding: utf-8 -*-

from .caster import lookoutequipment_caster

caster = lookoutequipment_caster

__version__ = "1.40.0"