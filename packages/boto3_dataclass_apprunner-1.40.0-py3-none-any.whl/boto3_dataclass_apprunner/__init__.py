# -*- coding: utf-8 -*-

from .caster import apprunner_caster

caster = apprunner_caster

__version__ = "1.40.0"