"""Module for extracting bergamo metadata inputs"""
