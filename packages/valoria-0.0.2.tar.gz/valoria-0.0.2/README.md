# Fichier - Outils pour fichiers

Un outil en ligne de commande complet pour la gestion et l'analyse de fichiers et répertoires.

## 📋 Fonctionnalités

### 🔍 Structure des fichiers
```bash
fichier -structure [répertoire]
```
Affiche une arborescence complète du répertoire spécifié.

### 🗑️ Nettoyage des fichiers temporaires
```bash
fichier -tmp [répertoire]
```
Supprime tous les fichiers temporaires (`*.tmp`) dans le répertoire.

### 📄 Licence
```bash
fichier -license
```
Affiche les informations de licence du projet.

### 🔒 Vérification des permissions
```bash
fichier -perm [répertoire]
```
Vérifie et analyse les permissions des fichiers et identifie les problèmes potentiels.

### 🧹 Nettoyage avancé
```bash
fichier -clean [répertoire]
```
Supprime les fichiers vides et identifie les doublons.

### 📊 Analyse des dépendances
```bash
fichier -dependencies [répertoire]
```
Analyse les dépendances entre les fichiers.

### ⚙️ Modification des permissions
```bash
fichier -chmod <permissions> [répertoire]
```
Modifie les permissions des fichiers (ex: `755`, `u+x`).

### 💬 Mode interactif
```bash
fichier -interactive [répertoire]
```
Lance un mode interactif pour modifier les permissions.

## 🚀 Installation

1. Clonez le repository :
```bash
git clone <repository-url>
cd fichier
```

2. Installez les dépendances :
```bash
pip install -r requirements.txt
```

## 📖 Utilisation

### Exemples d'utilisation

**Sur mobile :**
```bash
fichier -structure /storage/emulated/0
```

**Sur PC :**
```bash
fichier -structure /chemin/vers/repertoire
```

**Nettoyage des fichiers temporaires :**
```bash
fichier -tmp /chemin/vers/repertoire
```

**Vérification des permissions :**
```bash
fichier -perm /chemin/vers/repertoire
```

**Modification des permissions :**
```bash
fichier -chmod 755 /chemin/vers/repertoire
fichier -chmod u+x /chemin/vers/repertoire
```

## 🛠️ Options disponibles

| Option | Description |
|--------|-------------|
| `-structure` | Afficher la structure des fichiers |
| `-tmp` | Supprimer tous les fichiers temporaires (*.tmp) |
| `-license` | Affiche la LICENSE |
| `-perm` | Vérifier les permissions des fichiers |
| `-clean` | Supprimer fichiers vides et doublons |
| `-dependencies` | Analyser les dépendances |
| `-chmod` | Modifier les permissions (ex: 755, u+x) |
| `-interactive` | Mode interactif pour chmod |
| `directory` | Répertoire à traiter (défaut: répertoire courant) |

## 📁 Structure du projet

```
fichier/
├── valoria/
│   ├── structure.py
│   ├── tmp.py
│   ├── license.py
│   ├── perm.py
│   ├── clean.py
│   ├── dependencies.py
│   └── chmod.py
├── main.py
└── README.md
```

## ⚠️ Notes importantes

- Par défaut, le répertoire courant (`.`) est utilisé si aucun répertoire n'est spécifié
- Utilisez le mode interactif pour une modification sécurisée des permissions
- La fonction de nettoyage supprime définitivement les fichiers - utilisez avec précaution

## 📄 Licence

Consultez les détails de la licence avec la commande :
```bash
fichier -license
```