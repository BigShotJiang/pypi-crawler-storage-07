__version__ = "0.6.0"

IMAGE_TAG = "0.6.0"
