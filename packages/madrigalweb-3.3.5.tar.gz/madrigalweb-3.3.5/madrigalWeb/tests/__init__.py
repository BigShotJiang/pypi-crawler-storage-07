"""unit test for Python remote API for access to any Madrigal server

$Id: __init__.py 7625 2023-10-30 17:35:31Z brideout $
"""
