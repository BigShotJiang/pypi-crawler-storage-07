class JWTTokenException(Exception):
    pass
