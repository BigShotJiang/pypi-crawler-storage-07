# src/hebcal_api/config.py
BASE_URL = "https://www.hebcal.com"
DEFAULT_PARAMS = {
    "v": "1",
    "cfg": "json",
}
