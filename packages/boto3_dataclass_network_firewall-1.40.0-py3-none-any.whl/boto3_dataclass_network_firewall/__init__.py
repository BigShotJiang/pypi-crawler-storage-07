# -*- coding: utf-8 -*-

from .caster import network_firewall_caster

caster = network_firewall_caster

__version__ = "1.40.0"