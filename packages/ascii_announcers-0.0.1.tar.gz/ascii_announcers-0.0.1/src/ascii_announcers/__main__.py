from ascii_announcers import announcers

print(list(announcers.keys()))

print(announcers["dog"])
