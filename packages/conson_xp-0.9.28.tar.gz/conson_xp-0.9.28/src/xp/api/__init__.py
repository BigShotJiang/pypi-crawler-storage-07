"""API module for FastAPI endpoints and models."""
