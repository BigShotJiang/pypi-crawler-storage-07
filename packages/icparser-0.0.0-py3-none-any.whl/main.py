def main():
    print("Hello from icparser!")


if __name__ == "__main__":
    main()
