Calc Mini Tutorial
------------------

The docs for this `calc` example are now documented as part of the main documentation, undr *Mini Tutorial*.
