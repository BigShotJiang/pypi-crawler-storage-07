from ._version import __version__  # noqa: F401

__toolname__ = 'TatSu'
