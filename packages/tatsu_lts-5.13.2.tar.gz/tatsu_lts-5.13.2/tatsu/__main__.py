from __future__ import annotations

import tatsu

if __name__ == '__main__':
    tatsu.main()
