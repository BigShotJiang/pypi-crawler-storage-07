.. include:: links.rst

Contributors
------------

The following, among others, have contributed to |TatSu| with
features, bug reports, bug fixes, or suggestions:

    `Alberto Berti`_,
    `Andrzej Fiedukowicz`_,
    `Andy Wright`_,
    `Basel Shishani`_,
    `Benjamin Beasley`_,
    `Daniel Martin`_,
    `Daniele Nicolodi`_,
    `David Chen`_,
    `David Delassus`_,
    `David Röthlisberger`_,
    `David Sanders`_,
    `Dmytro Ivanov`_,
    `Ehsan Kia`_,
    `Felipe`_,
    `Franck Pommereau`_,
    `Franklin Lee`_,
    `Gabriele Paganelli`_,
    `Guido van Rossum`_,
    `Jack Taylor`_,
    `Kathryn Long`_,
    `Karthikeyan Singaravelan`_,
    `Manuel Jacob`_,
    `Marcus Brinkmann`_,
    `Matt Piekenbrock`_,
    `Mark Jason Dominus`_,
    `Max Liebkies`_,
    `Michael Noronha`_,
    `Nicholas Bishop`_,
    `Nicolas Laurent`_,
    `Nils-Hero Lindemann`_,
    `Oleg Komarov`_,
    `Paul Houle`_,
    `Paul Sargent`_,
    `Robert Speer`_,
    `Ryan`_,
    `Ryan Gonzales`_,
    `Ruth-Polymnia`_,
    `S Brown`_,
    `Tonico Strasser`_,
    `Vic Nightfall`_,
    `Victor Uriarte`_,
    `Vinay Sajip`_,
    `franz\_g`_,
    `gkimbar`_,
    `nehz`_ ,
    `neumond`_,
    `pdw-mb`_,
    `pgebhard`_,
    `siemer`_,
    `by-Exist`_,
    `commonism`_,
    `Vincent Fazio`_

.. _commits: https://bitbucket.org/neogeny/grako/commits/all
.. _issues: https://bitbucket.org/neogeny/grako/issues

