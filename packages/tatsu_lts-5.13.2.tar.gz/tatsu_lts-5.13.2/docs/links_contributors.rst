
.. _Alberto Berti: https://github.com/azazel75
.. _Andrzej Fiedukowicz: https://github.com/fiedukow
.. _Andy Wright: https://github.com/acw1251
.. _Basel Shishani: https://bitbucket.org/basel-shishani
.. _Basel Shishani: https://bitbucket.org/basel-shishani
.. _Daniel Martin: https://github.com/fizbin
.. _Daniele Nicolodi: https://github.com/dnicolodi
.. _David Chen: https://github.com/davidchen
.. _David Delassus: https://bitbucket.org/linkdd
.. _David Röthlisberger: https://bitbucket.org/drothlis/
.. _David Röthlisberger: https://bitbucket.org/drothlis/
.. _David Sanders: https://github.com/davesque
.. _Dmytro Ivanov: https://bitbucket.org/jimon
.. _Ehsan Kia: https://github.com/ehsankia
.. _Felipe: https://github.com/fcoelho
.. _Franck Pommereau: https://github.com/fpom
.. _Franklin Lee: https://bitbucket.org/leewz
.. _Gabriele Paganelli: https://bitbucket.org/gapag
.. _Guido van Rossum: https://github.com/gvanrossum
.. _Jack Taylor: https://github.com/rayjolt
.. _Kathryn Long: https://bitbucket.org/starkat
.. _Karthikeyan Singaravelan: https://github.com/tirkarthi
.. _Manuel Jacob: https://github.com/manueljacob
.. _Marcus Brinkmann: https://bitbucket.org/lambdafu/
.. _Mark Jason Dominus: https://github.com/mjdominus
.. _Max Liebkies: https://bitbucket.org/gegenschall
.. _Michael Noronha: https://github.com/mtn
.. _Nicholas Bishop: https://github.com/nicholasbishop
.. _Nicolas Laurent: https://github.com/norswap
.. _Nils-Hero Lindemann: https://github.com/heronils
.. _Oleg Komarov: https://github.com/okomarov
.. _Paul Houle: https://github.com/paulhoule
.. _Paul Sargent: https://bitbucket.org/pauls
.. _Philippe Sigaud: https://github.com/PhilippeSigaud
.. _Robert Speer: https://bitbucket.org/r_speer
.. _Ruth-Polymnia: https://github.com/Ruth-Polymnia
.. _Ryan Gonzales: https://github.com/kirbyfan64
.. _Ryan: https://github.com/r-chaves
.. _S Brown: https://bitbucket.org/sjbrownBitbucket
.. _Tonico Strasser: https://bitbucket.org/tonico_strasser
.. _Vic Nightfall: https://github.com/Victorious3
.. _Victor Uriarte: https://bitbucket.org/vmuriart
.. _Vinay Sajip: https://bitbucket.org/vinay.sajip
.. _basel-shishani: https://bitbucket.org/basel-shishani
.. _basel-shishani: https://bitbucket.org/basel-shishani
.. _drothlis: https://bitbucket.org/drothlis
.. _drothlis: https://bitbucket.org/drothlis
.. _franz\_g: https://bitbucket.org/franz_g
.. _franz_g: https://bitbucket.org/franz_g
.. _gapag: https://bitbucket.org/gapag
.. _gegenschall: https://bitbucket.org/gegenschall
.. _gkimbar: https://bitbucket.org/gkimbar
.. _gkimbar: https://bitbucket.org/gkimbar
.. _jimon: https://bitbucket.org/jimon
.. _leewz: https://bitbucket.org/leewz
.. _linkdd: https://bitbucket.org/linkdd
.. _nehz: https://bitbucket.org/nehz
.. _nehz: https://bitbucket.org/nehz
.. _neumond: https://bitbucket.org/neumond
.. _neumond: https://bitbucket.org/neumond
.. _pauls: https://bitbucket.org/pauls
.. _pdw-mb: https://bitbucket.org/pdw-mb
.. _pgebhard: https://bitbucket.org/pgebhard
.. _pgebhard: https://bitbucket.org/pgebhard
.. _r_speer: https://bitbucket.org/r_speer
.. _siemer: https://bitbucket.org/siemer
.. _siemer: https://bitbucket.org/siemer
.. _sjbrownBitbucket: https://bitbucket.org/sjbrownBitbucket
.. _starkat: https://bitbucket.org/starkat
.. _tonico_strasser: https://bitbucket.org/tonico_strasser
.. _vinay.sajip: https://bitbucket.org/vinay.sajip
.. _vmuriart: https://bitbucket.org/vmuriart
.. _by-Exist: https://github.com/by-Exist
.. _commonism: https://github.com/commonism
.. _Vincent Fazio: https://github.com/vfazio
.. _Benjamin Beasley: https://github.com/musicinmybrain
.. _Matt Piekenbrock: https://github.com/peekxc
