.. include:: links.rst


Installation
------------

.. code:: bash

    $ pip install tatsu

.. warning::
    Modern versions of |TatSu| require active versions of Python (if the Python
    version is more than one and a half years old, things may not work).

