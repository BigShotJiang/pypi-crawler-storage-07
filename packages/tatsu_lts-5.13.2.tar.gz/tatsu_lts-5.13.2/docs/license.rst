License
-------

.. include:: LICENSE.txt
