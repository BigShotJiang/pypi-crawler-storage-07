

.. role:: console

.. role:: blackboard

.. role:: fail

.. role:: succeed

.. role:: try

