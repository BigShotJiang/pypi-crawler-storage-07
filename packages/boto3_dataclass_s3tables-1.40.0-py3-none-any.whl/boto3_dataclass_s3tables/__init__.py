# -*- coding: utf-8 -*-

from .caster import s3tables_caster

caster = s3tables_caster

__version__ = "1.40.0"