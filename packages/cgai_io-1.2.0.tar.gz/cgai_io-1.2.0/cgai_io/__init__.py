# -*- coding:utf-8 -*-
from .Copy import *
from .Delete import *
from .Move import *
from .Name import *
from .Pack import *
__title__ = 'cgai_io'
__version__ = '1.2.0'
__author__ = 'Master Zhang'
__author_email__ = '360014296@qq.com'
__license__ = 'GPLv3'
__description__ = """ 支持跨平台，支持window文件以及目录的快速复制 \n
 复制文件 copyfile,复制目录 copydir"""

