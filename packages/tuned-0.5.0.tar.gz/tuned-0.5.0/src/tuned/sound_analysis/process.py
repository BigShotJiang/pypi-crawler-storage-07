"""
Copyright (C) 2025 drd <drd.ltt000@gmail.com>

This file is part of TunEd.

TunEd is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

TunEd is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
"""
import sys
import threading
import time
import multiprocessing
from queue import Queue, Empty

import sounddevice as sd

from .analyzer import AudioAnalyzer
from .strategies import (
    AubioNoteDetectionStrategy,
    ChordDetectionStrategy,
    AubioAttackStrategy,
    SpectrumAnalysisStrategy
)

# --- Constantes et Configuration ---
SAMPLING_RATE = 48000
CHUNK_SIZE = 1024
# Un long tampon pour l'analyse spectrale, un court pour l'attaque
SPECTRAL_BUFFER_TIMES = 50
ATTACK_BUFFER_TIMES = 2

# Fenêtre temporelle (en secondes) après une attaque pour valider un accord.
SPECTRAL_BUFFER_DURATION = (SPECTRAL_BUFFER_TIMES * CHUNK_SIZE) / SAMPLING_RATE
ANALYSIS_WINDOW_SECONDS = SPECTRAL_BUFFER_DURATION * 1.4

# --- Profils de Détection d'Attaque par Instrument ---
INSTRUMENT_PROFILES = {
    'guitar': {
        'amplitude_settings': {'db_threshold': 40.0, 'cooldown_frames': 3, 'peak_window_size': 3},
        'spectral_settings': {'threshold_offset': 0.1}  # Très sensible pour capter les nuances
    },
    'bass': {
        'amplitude_settings': {'db_threshold': 25.0, 'cooldown_frames': 8, 'peak_window_size': 5},
        'spectral_settings': {'threshold_offset': 0.5}  # Moins sensible pour ignorer les bruits de frette
    }
}


class AudioStreamReader:
    """
    Gère le flux audio de sounddevice. Lit les données brutes et leur timestamp,
    les place dans les files d'attente pour les threads d'analyse, et peut
    également rediriger l'audio d'entrée vers la sortie pour un monitoring en temps réel.
    """
    def __init__(self, data_queues: list[Queue], monitoring: bool = False):
        self.data_queues = data_queues
        self.monitoring = monitoring
        self.running = False

        # On utilise un flux bidirectionnel si le monitoring est activé
        self.stream = sd.Stream(
            samplerate=SAMPLING_RATE, blocksize=CHUNK_SIZE,
            channels=1, dtype='float32',
            callback=self._callback,
            # Le flux est seulement en entrée (InputStream) si monitoring=False
            device=(None, None) if self.monitoring else (None, sd.default.device[1])
        )

    def _callback(self, indata, outdata, frames, time, status):
        if status:
            print(status, file=sys.stderr)
        
        # Si le monitoring est activé, on copie l'entrée vers la sortie
        if self.monitoring:
            outdata[:] = indata

        if self.running:
            # On envoie toujours les données d'entrée aux threads d'analyse
            for q in self.data_queues:
                q.put((indata.copy(), time.inputBufferAdcTime))

    def start(self):
        self.running = True
        self.stream.start()

    def stop(self):
        self.running = False
        time.sleep(0.1)
        self.stream.stop()
        self.stream.close()


class AnalysisThread(threading.Thread):
    """
    Thread de travail qui consomme des données audio d'une file, les traite
    via un AudioAnalyzer, et place les résultats dans une autre file.
    """
    def __init__(self, data_queue: Queue, results_queue: Queue, analyzer: AudioAnalyzer):
        super().__init__()
        self.data_queue = data_queue
        self.results_queue = results_queue
        self.analyzer = analyzer
        self.running = False

    def run(self):
        self.running = True
        while self.running:
            try:
                raw_frame, timestamp = self.data_queue.get(timeout=0.1)
                decoded_frame = raw_frame.squeeze()
                analysis_result = self.analyzer.analyze(decoded_frame, timestamp)
                self.results_queue.put(analysis_result)
            except Empty:
                continue

    def stop(self):
        self.running = False


class AnalysisProcess(multiprocessing.Process):
    """
    Processus dédié à l'ensemble de l'analyse audio.
    Il gère le flux audio et les threads d'analyse en interne, et envoie
    les résultats finaux au processus principal via une queue.
    """
    def __init__(self, results_queue: multiprocessing.Queue, shutdown_event: multiprocessing.Event,
                 detection_mode: str, ref_freq: int, identify_harmonics: bool, monitoring: bool = False):
        super().__init__()
        self.results_queue = results_queue
        self.shutdown_event = shutdown_event
        self.detection_mode = detection_mode
        self.ref_freq = ref_freq
        self.identify_harmonics = identify_harmonics
        self.monitoring = monitoring

    def run(self):
        """
        Le cœur du processus d'analyse. Cette méthode s'exécute lorsque
        le processus est démarré avec .start().
        """
        try:
            # Files de communication internes au processus (entre threads)
            spectral_data_queue = Queue()
            attack_data_queue = Queue()
            internal_results_queue = Queue()

            stream_reader = None
            spectral_thread = None
            attack_thread = None

            try:
                # 1. Création des stratégies d'analyse
                spectral_strategy: SpectrumAnalysisStrategy
                if self.detection_mode == 'note':
                    spectral_strategy = AubioNoteDetectionStrategy(sampling_rate=SAMPLING_RATE, ref_freq=self.ref_freq)
                else:  # 'chord'
                    spectral_strategy = ChordDetectionStrategy(ref_freq=self.ref_freq, identify_harmonics=self.identify_harmonics)

                # Crée les deux sous-stratégies avec les réglages du profil
                # amplitude_strategy = AmplitudeAttackStrategy(**profile['amplitude_settings'])
                # spectral_attack_strategy = AttackAnalysisStrategy(sampling_rate=SAMPLING_RATE, **profile['spectral_settings'])

                # Injecte les deux stratégies dans la stratégie hybride (méthode recommandée)
                # attack_strategy = HybridAttackStrategy(
                #     spectral_strategy=spectral_attack_strategy,
                #     amplitude_strategy=amplitude_strategy
                # )

                # --- AUTRES STRATÉGIES (POUR TESTS) ---
                # Stratégie basée sur la nouveauté spectrale seule
                # attack_strategy = AttackAnalysisStrategy(sampling_rate=SAMPLING_RATE, **profile['spectral_settings'])
                
                # Stratégie basée sur le volume seul
                # attack_strategy = AmplitudeAttackStrategy(**profile['amplitude_settings'])

                # --- NOUVELLE STRATÉGIE AUBIO (POUR TESTS) ---
                attack_strategy = AubioAttackStrategy(
                    sampling_rate=SAMPLING_RATE, win_s=CHUNK_SIZE, hop_s=CHUNK_SIZE, method="specdiff"
                )

                # 2. Création des moteurs AudioAnalyzer
                spectral_analyzer = AudioAnalyzer(
                    strategy=spectral_strategy, sampling_rate=SAMPLING_RATE,
                    chunk_size=CHUNK_SIZE, buffer_times=SPECTRAL_BUFFER_TIMES)

                attack_analyzer = AudioAnalyzer(
                    strategy=attack_strategy, sampling_rate=SAMPLING_RATE,
                    chunk_size=CHUNK_SIZE, buffer_times=ATTACK_BUFFER_TIMES)

                # 3. Création et démarrage des threads internes
                stream_reader = AudioStreamReader([spectral_data_queue, attack_data_queue], monitoring=self.monitoring)
                spectral_thread = AnalysisThread(spectral_data_queue, internal_results_queue, spectral_analyzer)
                attack_thread = AnalysisThread(attack_data_queue, internal_results_queue, attack_analyzer)

                spectral_thread.start()
                attack_thread.start()
                stream_reader.start()

                # 4. Boucle principale du processus : consomme les résultats internes et les envoie à l'extérieur
                last_analysis_results = {}
                last_attack_timestamp = 0.0

                while not self.shutdown_event.is_set():
                    try:
                        new_result_part = internal_results_queue.get(timeout=0.1)
                        last_analysis_results.update(new_result_part)

                        # --- Logique de corrélation temporelle ---
                        if 'attack' in new_result_part and new_result_part['attack'].detected:
                            last_attack_timestamp = new_result_part['attack'].timestamp

                        if self.detection_mode == 'chord' and 'chord' in new_result_part and last_attack_timestamp > 0:
                            current_chord = new_result_part['chord']
                            current_timestamp = current_chord.timestamp

                            last_attack_timestamp = 0.0

                        # Envoie le dictionnaire de résultats consolidés au processus principal
                        self.results_queue.put(last_analysis_results.copy())

                    except Empty:
                        continue

            except Exception as e:
                # En cas d'erreur, on peut l'envoyer au processus principal pour l'afficher
                self.results_queue.put({'error': str(e)})
            finally:
                # 5. Arrêt propre des threads et des ressources
                if spectral_thread: spectral_thread.stop()
                if attack_thread: attack_thread.stop()
                if stream_reader: stream_reader.stop()
                if spectral_thread: spectral_thread.join()
                if attack_thread: attack_thread.join()
        except KeyboardInterrupt:
            # Le processus principal gère l'arrêt, on ignore donc l'interruption ici
            # pour éviter un traceback inutile.
            pass

    def stop(self):
        """Méthode pour signaler l'arrêt du processus depuis l'extérieur."""
        self.shutdown_event.set()
