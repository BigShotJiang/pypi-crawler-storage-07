"""
Copyright (C) 2025 drd <drd.ltt000@gmail.com>

This file is part of TunEd.

TunEd is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free software Foundation, either version 3 of the License, or
(at your option) any later version.

TunEd is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
"""
from dataclasses import dataclass


@dataclass
class Attack:
    """Représente une attaque musicale détectée."""
    detected: bool
    timestamp: float = 0.0
    # score de nouveauté calculé par AttackAnalysisStrategy
    novelty_score: float = 0.0
    # seuil calculé par AttackAnalysisStrategy
    threshold: float = 0.0

