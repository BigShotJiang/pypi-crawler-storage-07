import pytest

from url_is_in import convert_url_to_surt_with_wildcard


def test_url_to_surt():
    assert convert_url_to_surt_with_wildcard("https://example.com") == "com,example)/"
    assert convert_url_to_surt_with_wildcard("http://example.com") == "com,example)/"
    assert convert_url_to_surt_with_wildcard("ftp://example.com") == "com,example)/"

    assert convert_url_to_surt_with_wildcard("*.com") == "com,"
    assert convert_url_to_surt_with_wildcard("*.example.com") == "com,example,"


@pytest.mark.parametrize(
    "invalid_url",
    [
        # Wild card not in the begging
        ("example.com*"),
        # Wild card with URL
        ("*.example.com/foo/bar"),
        ("*.example.com?foo=bar"),
        # Wild card without dot
        ("*example.com"),
    ],
)
def test_url_to_surt_errors(invalid_url):
    with pytest.raises(ValueError):
        convert_url_to_surt_with_wildcard(invalid_url)
