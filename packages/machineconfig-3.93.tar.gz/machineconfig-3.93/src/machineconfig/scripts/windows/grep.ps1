
& "C:\Program Files\Git\usr\bin\grep.exe" $args
