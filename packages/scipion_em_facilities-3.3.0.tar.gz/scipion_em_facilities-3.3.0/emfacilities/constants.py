# -*- coding: utf-8 -*-
# **************************************************************************
# *
# * Authors:     J.M. De la Rosa Trevin (jmdelarosa@cnb.csic.es)
# *
# * Unidad de  Bioinformatica of Centro Nacional de Biotecnologia , CSIC
# *
# * This program is free software; you can redistribute it and/or modify
# * it under the terms of the GNU General Public License as published by
# * the Free Software Foundation; either version 2 of the License, or
# * (at your option) any later version.
# *
# * This program is distributed in the hope that it will be useful,
# * but WITHOUT ANY WARRANTY; without even the implied warranty of
# * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# * GNU General Public License for more details.
# *
# * You should have received a copy of the GNU General Public License
# * along with this program; if not, write to the Free Software
# * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
# * 02111-1307  USA
# *
# *  All comments concerning this program package may be sent to the
# *  e-mail address 'scipion@cnb.csic.es'
# *
# **************************************************************************
"""
This modules contains constants related to emfacilities
"""

URL = 'https://scipion-em.github.io/docs/docs/facilities/facilities.html'
SECRETSFILE = 'secrets.cfg'
EMFACILITIES_HOME_VARNAME = 'EMFACILITIES_HOME'
FACILITIES_VERSION = '3.3.0'

# Streamlit environment
FACLITIES_STREAMLIT = 'facilities-streamlit'
STRM_ENV_NAME = f'{FACLITIES_STREAMLIT}-{FACILITIES_VERSION}'
STRM_PROGRAM = 'streamlit'

FACILITIES_ENV_ACTIVATION = 'FACILITIES_ENV_ACTIVATION'
FACILITIES_DEFAULT_ACTIVATION_CMD = 'conda activate %s' % STRM_ENV_NAME