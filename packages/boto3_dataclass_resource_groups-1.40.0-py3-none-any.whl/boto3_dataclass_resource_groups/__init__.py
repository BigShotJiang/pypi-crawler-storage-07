# -*- coding: utf-8 -*-

from .caster import resource_groups_caster

caster = resource_groups_caster

__version__ = "1.40.0"