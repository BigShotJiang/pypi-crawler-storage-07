# Author(s): Silvio Gregorini (silviogregorini@openforce.it)
# Copyright 2019 Openforce Srls Unipersonale (www.openforce.it)
# Copyright 2023 Simone Rubino - Aion Tech
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from odoo import _, api, fields, models
from odoo.exceptions import ValidationError
from odoo.fields import Command


class AccountMoveLine(models.Model):
    _inherit = "account.move.line"

    asset_accounting_info_ids = fields.One2many(
        "asset.accounting.info", "move_line_id", string="Assets Accounting Info"
    )

    l10n_it_asset_ids = fields.Many2many(
        "asset.asset", compute="_compute_asset_data", store=True, string="Assets"
    )

    dep_line_ids = fields.Many2many(
        "asset.depreciation.line",
        compute="_compute_asset_data",
        store=True,
        string="Depreciation Lines",
    )

    @api.constrains("company_id")
    def check_company(self):
        for move_line in self:
            comp = move_line.get_linked_aa_info_records().mapped("company_id")
            if len(comp) > 1 or (comp and comp != move_line.company_id):
                raise ValidationError(
                    _(
                        "`%(move_line)s`: cannot change move line's company once it's"
                        " already related to an asset.",
                        move_line=move_line.name_get()[0][-1],
                    )
                )

    @api.depends(
        "asset_accounting_info_ids",
        "asset_accounting_info_ids.l10n_it_asset_id",
        "asset_accounting_info_ids.dep_line_id",
    )
    def _compute_asset_data(self):
        for line in self:
            aa_info = line.get_linked_aa_info_records()
            assets = aa_info.mapped("l10n_it_asset_id")
            dep_lines = aa_info.mapped("dep_line_id")
            if dep_lines:
                assets += dep_lines.mapped("l10n_it_asset_id")
            line.update(
                {
                    "l10n_it_asset_ids": [Command.set(assets.ids)],
                    "dep_line_ids": [Command.set(dep_lines.ids)],
                }
            )

    def get_asset_purchase_amount(self, currency=None):
        purchase_amount = 0
        for line in self:
            purchase_amount += line.currency_id._convert(
                line.debit - line.credit,
                currency,
                line.company_id,
                line.date,
            )
        return purchase_amount

    def get_linked_aa_info_records(self):
        self.ensure_one()
        return self.asset_accounting_info_ids
