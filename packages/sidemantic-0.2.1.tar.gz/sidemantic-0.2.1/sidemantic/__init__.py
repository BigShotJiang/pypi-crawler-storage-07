"""Sidemantic: SQLGlot-based semantic layer with multi-format adapter support."""

__version__ = "0.1.2"

from sidemantic.core.dimension import Dimension
from sidemantic.core.metric import Metric
from sidemantic.core.model import Model
from sidemantic.core.parameter import Parameter
from sidemantic.core.relationship import Relationship

# Backwards compatibility alias
Measure = Metric

__all__ = [
    "Dimension",
    "Measure",  # Backwards compatibility
    "Metric",
    "Model",
    "Parameter",
    "Relationship",
    "SemanticLayer",
]

def __getattr__(name):  # Lazy import to avoid importing duckdb on package import
    if name == "SemanticLayer":
        from sidemantic.core.semantic_layer import SemanticLayer  # type: ignore
        return SemanticLayer
    raise AttributeError(name)
