# -*- coding: utf-8 -*-

from .caster import ds_data_caster

caster = ds_data_caster

__version__ = "1.40.0"