0.4
Released: 2018-06-11
    - Небольшая реорганизация в файлах установки;
    - Директория lib переименова в core;
    - Директории lib обработчиков переименованы в stuff;
    - Изменены имена функций обработчиков (opening, closing).
    - параметры вызова основной функции:
      main(files=None, profile=None, options=None)

0.3
Released: 2016-04-22
    - Добавлена директория handlers для обработчиков
    - параметры вызова основной функции:
      main(files=None, profile=None)

0.2
Released: 2013-09-27
    - development version
    - параметры вызова основной функции:
      main(files=None, method=None)

0.1
Released: 2013-02-22
    - initial version
