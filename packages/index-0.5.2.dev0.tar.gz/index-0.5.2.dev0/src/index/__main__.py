#!/usr/bin/env python
# coding=utf-8
# Stan 2024-12-25

from dotenv import load_dotenv; load_dotenv()

from .cli import main

main()
