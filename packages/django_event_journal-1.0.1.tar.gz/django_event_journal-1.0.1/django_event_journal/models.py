from django.db import models
from django.utils import timezone
import json


class EventJournal(models.Model):
    """
    Model for storing event logs in PostgreSQL database.
    
    This model stores various types of events with associated metadata
    including user information, event details, IP address, and user agent.
    """
    
    event_type = models.CharField(
        max_length=100,
        help_text="Type of event being logged (e.g., 'user_login', 'file_upload')"
    )
    
    user_id = models.IntegerField(
        null=True,
        blank=True,
        help_text="ID of the user associated with this event (nullable for system events)"
    )
    
    event_info = models.JSONField(
        default=dict,
        blank=True,
        help_text="Additional event information stored as JSON"
    )
    
    ip_address = models.GenericIPAddressField(
        null=True,
        blank=True,
        help_text="Client IP address"
    )
    
    user_agent = models.TextField(
        blank=True,
        help_text="Client user agent string"
    )
    
    timestamp = models.DateTimeField(
        default=timezone.now,
        help_text="When the event occurred"
    )
    
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="When this event log entry was created"
    )
    
    class Meta:
        db_table = 'django_event_journal_eventjournal'
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['event_type']),
            models.Index(fields=['user_id']),
            models.Index(fields=['timestamp']),
            models.Index(fields=['event_type', 'timestamp']),
        ]
        verbose_name = 'Event Journal'
        verbose_name_plural = 'Event Journals'
    
    def __str__(self):
        user_info = f"User ID: {self.user_id}" if self.user_id else "System"
        return f"{self.event_type} - {user_info} - {self.timestamp}"
    
    @classmethod
    def log_event(
        cls,
        event_type,
        user_id=None,
        event_info=None,
        ip_address=None,
        user_agent=None,
        timestamp=None
    ):
        """
        Log an event to the database.
        
        Args:
            event_type (str): Type of event being logged
            user_id (int, optional): ID of the user associated with this event
            event_info (dict, optional): Additional event information
            ip_address (str, optional): Client IP address
            user_agent (str, optional): Client user agent string
            timestamp (datetime, optional): Event timestamp (defaults to now)
        
        Returns:
            EventJournal: The created EventJournal instance
        
        Example:
            EventJournal.log_event(
                event_type='duplicate_upload_attempt',
                user_id=user.id,
                event_info={
                    'file_id': existing_file.id,
                    'filename': existing_file.original_filename,
                    'file_type': existing_file.file_type,
                    'size': existing_file.size,
                    'checksum': existing_file.checksum,
                    'is_new_file': False,
                    'is_deduplication': False,
                    'reference_count': existing_file.reference_count,
                    'user_relationship_type': 'owner' if file_user.is_owner else 'reference'
                },
                ip_address=get_client_ip(request),
                user_agent=get_user_agent(request)
            )
        """
        if event_info is None:
            event_info = {}
        
        if timestamp is None:
            timestamp = timezone.now()
        
        return cls.objects.create(
            event_type=event_type,
            user_id=user_id,
            event_info=event_info,
            ip_address=ip_address,
            user_agent=user_agent or '',
            timestamp=timestamp
        )
    
    def get_event_info_display(self):
        """
        Return a formatted string representation of event_info.
        """
        if not self.event_info:
            return "No additional information"
        
        try:
            return json.dumps(self.event_info, indent=2, default=str)
        except (TypeError, ValueError):
            return str(self.event_info)
    
    def get_user_display(self):
        """
        Return a formatted string representation of the user.
        """
        if not self.user_id:
            return "System"
        
        return f"User ID: {self.user_id}"
