from django.contrib import admin
from django.utils.html import format_html
from django.urls import reverse
from django.utils.safestring import mark_safe
import json

from .models import EventJournal


@admin.register(EventJournal)
class EventJournalAdmin(admin.ModelAdmin):
    """
    Admin interface for EventJournal model.
    """
    
    list_display = [
        'event_type',
        'get_user_display',
        'get_ip_address_display',
        'timestamp',
        'created_at',
        'get_event_info_preview',
    ]
    
    list_filter = [
        'event_type',
        'timestamp',
        'created_at',
        'user_id',
    ]
    
    search_fields = [
        'event_type',
        'user_id',
        'ip_address',
        'user_agent',
    ]
    
    readonly_fields = [
        'created_at',
        'get_event_info_formatted',
        'get_user_agent_display',
    ]
    
    fieldsets = (
        ('Event Information', {
            'fields': ('event_type', 'timestamp', 'created_at')
        }),
        ('User Information', {
            'fields': ('user_id', 'get_user_display')
        }),
        ('Request Information', {
            'fields': ('ip_address', 'get_user_agent_display')
        }),
        ('Event Details', {
            'fields': ('get_event_info_formatted',),
            'classes': ('collapse',)
        }),
    )
    
    ordering = ['-timestamp']
    
    def get_user_display(self, obj):
        """Display user information."""
        if not obj.user_id:
            return format_html('<span style="color: #666;">System</span>')
        
        return format_html(
            '<span style="color: #007cba; font-weight: bold;">User ID: {}</span>',
            obj.user_id
        )
    get_user_display.short_description = 'User'
    get_user_display.admin_order_field = 'user_id'
    
    def get_ip_address_display(self, obj):
        """Display IP address with styling."""
        if not obj.ip_address:
            return format_html('<span style="color: #666;">-</span>')
        return obj.ip_address
    get_ip_address_display.short_description = 'IP Address'
    get_ip_address_display.admin_order_field = 'ip_address'
    
    def get_event_info_preview(self, obj):
        """Display a preview of event info."""
        if not obj.event_info:
            return format_html('<span style="color: #666;">No data</span>')
        
        # Get first few key-value pairs for preview
        preview_items = list(obj.event_info.items())[:3]
        preview_text = ', '.join([f'{k}: {v}' for k, v in preview_items])
        
        if len(obj.event_info) > 3:
            preview_text += '...'
        
        return format_html(
            '<span title="{}">{}</span>',
            obj.get_event_info_display(),
            preview_text[:100] + ('...' if len(preview_text) > 100 else '')
        )
    get_event_info_preview.short_description = 'Event Info Preview'
    
    def get_event_info_formatted(self, obj):
        """Display formatted event info."""
        if not obj.event_info:
            return format_html('<span style="color: #666;">No additional information</span>')
        
        try:
            formatted_json = json.dumps(obj.event_info, indent=2, default=str)
            return format_html('<pre style="background: #f8f8f8; padding: 10px; border-radius: 4px; overflow-x: auto;">{}</pre>', formatted_json)
        except (TypeError, ValueError):
            return format_html('<pre style="background: #f8f8f8; padding: 10px; border-radius: 4px;">{}</pre>', str(obj.event_info))
    get_event_info_formatted.short_description = 'Event Information (JSON)'
    
    def get_user_agent_display(self, obj):
        """Display user agent with truncation."""
        if not obj.user_agent:
            return format_html('<span style="color: #666;">-</span>')
        
        # Truncate long user agents
        user_agent = obj.user_agent
        if len(user_agent) > 100:
            user_agent = user_agent[:100] + '...'
        
        return format_html(
            '<span title="{}">{}</span>',
            obj.user_agent,
            user_agent
        )
    get_user_agent_display.short_description = 'User Agent'
    
    def has_add_permission(self, request):
        """Disable adding EventJournal entries through admin."""
        return False
    
    def has_change_permission(self, request, obj=None):
        """Disable editing EventJournal entries through admin."""
        return False
    
    def has_delete_permission(self, request, obj=None):
        """Allow deletion of EventJournal entries."""
        return True
