"""
Standalone Django Event Logger.

This module allows you to use the Django Event Logger without a full Django project.
It automatically configures Django with pre-configured database settings.
"""

import os
import sys
import django
from pathlib import Path

# Add the current directory to Python path
current_dir = Path(__file__).parent
sys.path.insert(0, str(current_dir))

from .default_settings import DEFAULT_SETTINGS

def setup_django():
    """Set up Django with default settings."""
    # Set up Django environment
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'django_event_logger.standalone_settings')
    
    # Configure Django settings
    from django.conf import settings
    if not settings.configured:
        settings.configure(**DEFAULT_SETTINGS)
    
    # Initialize Django
    django.setup()

def get_event_journal():
    """Get the EventJournal model after Django is set up."""
    from .models import EventJournal
    return EventJournal

def get_utils():
    """Get utility functions after Django is set up."""
    from .utils import get_client_ip, get_user_agent, get_request_info
    return get_client_ip, get_user_agent, get_request_info

def log_event(event_type, user_id=None, event_info=None, ip_address=None, user_agent=None, timestamp=None):
    """
    Standalone function to log an event.
    
    This function automatically sets up Django if not already configured.
    Assumes the EventJournal table already exists in the database.
    
    Args:
        event_type (str): Type of event being logged
        user_id (int, optional): ID of the user associated with this event
        event_info (dict, optional): Additional event information
        ip_address (str, optional): Client IP address
        user_agent (str, optional): Client user agent string
        timestamp (datetime, optional): Event timestamp (defaults to now)
    
    Returns:
        EventJournal: The created EventJournal instance
    
    Example:
        from django_event_logger.standalone import log_event
        
        # Log an event
        event_log = log_event(
            event_type='user_event',
            event_info={'event': 'login', 'method': 'email'},
            ip_address='192.168.1.1',
            user_agent='Mozilla/5.0...'
        )
    """
    # Set up Django if not already done
    if not django.apps.apps.ready:
        setup_django()
    
    # Get EventJournal model
    EventJournal = get_event_journal()
    
    # Log the event
    return EventJournal.log_event(
        event_type=event_type,
        user_id=user_id,
        event_info=event_info,
        ip_address=ip_address,
        user_agent=user_agent,
        timestamp=timestamp
    )

def check_table_exists():
    """Check if EventJournal table exists in the database."""
    try:
        setup_django()
        
        from django.db import connection
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables 
                    WHERE table_name = 'django_event_journal_eventjournal'
                );
            """)
            table_exists = cursor.fetchone()[0]
        
        if table_exists:
            print("✅ EventJournal table found in database.")
            return True
        else:
            print("❌ EventJournal table not found in database.")
            print("Please ensure the table exists before using the library.")
            return False
            
    except Exception as e:
        print(f"❌ Error checking table: {e}")
        return False

def test_connection():
    """Test the database connection."""
    setup_django()
    
    from django.db import connection
    
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT version();")
            version = cursor.fetchone()[0]
            print(f"✅ Connected to PostgreSQL: {version}")
            return True
    except Exception as e:
        print(f"❌ Database connection failed: {e}")
        return False

# Auto-setup when imported
if __name__ != '__main__':
    # Only auto-setup if not running as main
    pass
