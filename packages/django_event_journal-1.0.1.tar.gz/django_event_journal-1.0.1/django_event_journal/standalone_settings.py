"""
Standalone Django settings for the Event Logger.

This module provides Django settings when using the event logger standalone.
"""

from .default_settings import DEFAULT_SETTINGS

# Use the default settings
globals().update(DEFAULT_SETTINGS)
