"""
Django Event Logger

A Django library for logging events to PostgreSQL database.
"""

__version__ = "1.0.1"
__author__ = "Amol Saini"
__email__ = "amol.saini567@gmail.com"

# Lazy imports to avoid AppRegistryNotReady error
def get_EventJournal():
    from .models import EventJournal
    return EventJournal

def get_utils():
    from .utils import get_client_ip, get_user_agent
    return get_client_ip, get_user_agent

# Import standalone functionality (these don't import models directly)
from .standalone import log_event, setup_django, test_connection, check_table_exists

# For backward compatibility, provide lazy access to models
def __getattr__(name):
    if name == 'EventJournal':
        return get_EventJournal()
    elif name in ['get_client_ip', 'get_user_agent']:
        return getattr(get_utils(), name)
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")

__all__ = [
    'EventJournal',
    'get_client_ip',
    'get_user_agent',
    'log_event',  # Standalone function
    'setup_django',  # Standalone setup
    'test_connection',  # Connection test
    'check_table_exists',  # Table existence check
]
