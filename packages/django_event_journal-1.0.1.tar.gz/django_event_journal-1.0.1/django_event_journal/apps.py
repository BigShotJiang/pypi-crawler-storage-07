from django.apps import AppConfig


class DjangoEventLoggerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_event_journal'
    verbose_name = 'Django Event Logger'
