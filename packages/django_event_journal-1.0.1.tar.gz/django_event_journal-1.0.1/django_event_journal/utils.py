"""
Utility functions for Django Event Logger.
"""


def get_client_ip(request):
    """
    Extract the client IP address from the request.
    
    This function checks various headers to determine the real client IP,
    taking into account proxies and load balancers.
    
    Args:
        request: Django HttpRequest object
        
    Returns:
        str: Client IP address or None if not found
        
    Example:
        ip_address = get_client_ip(request)
    """
    if not request:
        return None
    
    # Check for forwarded IP first (common with proxies/load balancers)
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        # X-Forwarded-For can contain multiple IPs, take the first one
        ip = x_forwarded_for.split(',')[0].strip()
        return ip
    
    # Check for real IP header
    x_real_ip = request.META.get('HTTP_X_REAL_IP')
    if x_real_ip:
        return x_real_ip.strip()
    
    # Check for client IP header
    x_client_ip = request.META.get('HTTP_X_CLIENT_IP')
    if x_client_ip:
        return x_client_ip.strip()
    
    # Check for CF-Connecting-IP (Cloudflare)
    cf_connecting_ip = request.META.get('HTTP_CF_CONNECTING_IP')
    if cf_connecting_ip:
        return cf_connecting_ip.strip()
    
    # Fall back to REMOTE_ADDR
    remote_addr = request.META.get('REMOTE_ADDR')
    if remote_addr:
        return remote_addr.strip()
    
    return None


def get_user_agent(request):
    """
    Extract the user agent string from the request.
    
    Args:
        request: Django HttpRequest object
        
    Returns:
        str: User agent string or empty string if not found
        
    Example:
        user_agent = get_user_agent(request)
    """
    if not request:
        return ''
    
    return request.META.get('HTTP_USER_AGENT', '')


def get_request_info(request):
    """
    Extract comprehensive request information.
    
    Args:
        request: Django HttpRequest object
        
    Returns:
        dict: Dictionary containing IP address, user agent, and other request info
        
    Example:
        request_info = get_request_info(request)
        # Returns: {
        #     'ip_address': '192.168.1.1',
        #     'user_agent': 'Mozilla/5.0...',
        #     'method': 'POST',
        #     'path': '/api/upload/',
        #     'query_string': 'param=value'
        # }
    """
    if not request:
        return {}
    
    return {
        'ip_address': get_client_ip(request),
        'user_agent': get_user_agent(request),
        'method': request.method,
        'path': request.path,
        'query_string': request.META.get('QUERY_STRING', ''),
        'content_type': request.META.get('CONTENT_TYPE', ''),
        'referer': request.META.get('HTTP_REFERER', ''),
    }
