#!/usr/bin/env python
"""
Quick Start Script for Django Event Logger

This script demonstrates the simplest way to use the event logger
with pre-configured database settings.
"""

from django_event_journal import log_event, test_connection, check_table_exists

def quick_start():
    """Quick start example."""
    print("🚀 Django Event Logger - Quick Start")
    print("=" * 40)
    
    # 1. Test connection
    print("Testing database connection...")
    if test_connection():
        print("✅ Connected to database!")
    else:
        print("❌ Connection failed!")
        return
    
    # 2. Check if table exists
    print("\nChecking if EventLog table exists...")
    if not check_table_exists():
        print("❌ EventLog table not found!")
        print("Please create the table in your database first.")
        return
    print("✅ EventLog table found!")
    
    # 3. Log your first event
    print("\nLogging your first event...")
    event = log_event(
        event_type='quick_start_test',
        event_info={
            'message': 'Hello from Django Event Logger!',
            'database': 'PostgreSQL',
            'setup': 'pre_configured'
        },
        ip_address='127.0.0.1',
        user_agent='Quick Start Script'
    )
    
    print(f"✅ Event logged with ID: {event.id}")
    print("\n🎉 You're ready to use Django Event Logger!")
    print("\nNext steps:")
    print("1. Import: from django_event_logger import log_event")
    print("2. Log events: log_event('event_type', event_info={...})")
    print("3. Check your database for logged events")

if __name__ == '__main__':
    quick_start()
