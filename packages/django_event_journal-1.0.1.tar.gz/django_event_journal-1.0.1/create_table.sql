-- SQL script to create the EventLog table in PostgreSQL
-- Run this script in your PostgreSQL database before using the library

CREATE TABLE IF NOT EXISTS django_event_journal_eventjournal (
    id BIGSERIAL PRIMARY KEY,
    event_type VARCHAR(100) NOT NULL,
    user_id INTEGER NULL,
    event_info JSONB DEFAULT '{}' NOT NULL,
    ip_address INET NULL,
    user_agent TEXT DEFAULT '' NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    
    -- Foreign key constraint (optional, uncomment if you have a users table)
    -- CONSTRAINT fk_eventlog_user FOREIGN KEY (user_id) REFERENCES auth_user(id) ON DELETE SET NULL
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS django_even_event_t_3fe44d_idx ON django_event_journal_eventjournal (event_type);
CREATE INDEX IF NOT EXISTS django_even_user_id_883352_idx ON django_event_journal_eventjournal (user_id);
CREATE INDEX IF NOT EXISTS django_even_timesta_a20cf3_idx ON django_event_journal_eventjournal (timestamp);
CREATE INDEX IF NOT EXISTS django_even_event_t_2582be_idx ON django_event_journal_eventjournal (event_type, timestamp);

-- Add comments for documentation
COMMENT ON TABLE django_event_journal_eventjournal IS 'Event logging table for Django Event Logger';
COMMENT ON COLUMN django_event_journal_eventjournal.event_type IS 'Type of event being logged (e.g., user_login, file_upload)';
COMMENT ON COLUMN django_event_journal_eventjournal.user_id IS 'User associated with this event (nullable for system events)';
COMMENT ON COLUMN django_event_journal_eventjournal.event_info IS 'Additional event information stored as JSON';
COMMENT ON COLUMN django_event_journal_eventjournal.ip_address IS 'Client IP address';
COMMENT ON COLUMN django_event_journal_eventjournal.user_agent IS 'Client user agent string';
COMMENT ON COLUMN django_event_journal_eventjournal.timestamp IS 'When the event occurred';
COMMENT ON COLUMN django_event_journal_eventjournal.created_at IS 'When this log entry was created';
