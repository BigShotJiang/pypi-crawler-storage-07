from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="django-event-journal",
    version="1.0.1",
    author="Amol Saini",
    author_email="amol.saini567@gmail.com",
    description="A Django library for logging events to PostgreSQL database",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/amolsr/django_event_journal",
    project_urls={
        "Bug Reports": "https://github.com/amolsr/django_event_journal/issues",
        "Source": "https://github.com/amolsr/django_event_journal",
        "Documentation": "https://github.com/amolsr/django_event_journal#readme",
    },
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Framework :: Django",
        "Framework :: Django :: 3.2",
        "Framework :: Django :: 4.0",
        "Framework :: Django :: 4.1",
        "Framework :: Django :: 4.2",
        "Framework :: Django :: 5.0",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: System :: Logging",
        "Topic :: Database",
    ],
    python_requires=">=3.8",
    install_requires=[
        "Django>=3.2",
        "psycopg2-binary>=2.8.6",
    ],
    extras_require={
        "dev": [
            "pytest>=6.0",
            "pytest-django>=4.0",
            "black>=22.0",
            "flake8>=4.0",
            "twine>=4.0",
            "build>=0.10",
        ],
    },
    entry_points={
        "console_scripts": [
            "django-event-journal-test=django_event_journal.standalone:test_connection",
        ],
    },
    keywords="django, logging, events, postgresql, supabase, database, audit",
    include_package_data=True,
    zip_safe=False,
)
