#!/usr/bin/env python
"""
Example usage of Django Event Logger with pre-configured database settings.

This example shows how to use the event logger in any Python script without
setting up a full Django project.
"""

from django_event_journal import log_event, test_connection, check_table_exists

def main():
    """Main example function."""
    print("📝 Django Event Logger - Standalone Usage Example")
    print("=" * 60)
    
    # 1. Test connection
    print("1. Testing database connection...")
    if not test_connection():
        print("❌ Cannot connect to database. Please check your connection.")
        return
    
    # 2. Check if table exists
    print("\n2. Checking if EventLog table exists...")
    if not check_table_exists():
        print("❌ EventLog table not found!")
        print("Please create the table in your database first.")
        return
    
    # 3. Log various types of events
    print("\n3. Logging events...")
    
    # Example 1: User login event
    print("   - Logging user login...")
    login_event = log_event(
        event_type='user_login',
        user_id=123,
        event_info={
            'login_method': 'email',
            'success': True,
            'session_id': 'sess_abc123'
        },
        ip_address='192.168.1.50',
        user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    )
    print(f"   ✅ Login event logged: {login_event.id}")
    
    # Example 2: File upload event
    print("   - Logging file upload...")
    upload_event = log_event(
        event_type='file_upload',
        user_id=123,
        event_info={
            'file_id': 'file_456',
            'filename': 'document.pdf',
            'file_type': 'application/pdf',
            'size': 2048000,
            'checksum': 'def789ghi012',
            'upload_method': 'web_interface'
        },
        ip_address='192.168.1.50',
        user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    )
    print(f"   ✅ Upload event logged: {upload_event.id}")
    
    # Example 3: Duplicate upload attempt (your original example)
    print("   - Logging duplicate upload attempt...")
    duplicate_event = log_event(
        event_type='duplicate_upload_attempt',
        user_id=123,
        event_info={
            'file_id': 'existing_file_789',
            'filename': 'duplicate_document.pdf',
            'file_type': 'application/pdf',
            'size': 2048000,
            'checksum': 'def789ghi012',
            'is_new_file': False,
            'is_deduplication': False,
            'reference_count': 2,
            'user_relationship_type': 'owner'
        },
        ip_address='192.168.1.50',
        user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    )
    print(f"   ✅ Duplicate upload event logged: {duplicate_event.id}")
    
    # Example 4: API request event
    print("   - Logging API request...")
    api_event = log_event(
        event_type='api_request',
        user_id=123,
        event_info={
            'endpoint': '/api/files/upload',
            'method': 'POST',
            'status_code': 200,
            'response_time_ms': 150,
            'request_id': 'req_xyz789'
        },
        ip_address='192.168.1.50',
        user_agent='Python-requests/2.28.0'
    )
    print(f"   ✅ API request event logged: {api_event.id}")
    
    # Example 5: System event
    print("   - Logging system event...")
    system_event = log_event(
        event_type='system_maintenance',
        event_info={
            'maintenance_type': 'database_cleanup',
            'duration_seconds': 300,
            'records_processed': 1000,
            'records_deleted': 500,
            'maintenance_id': 'maint_abc123'
        },
        ip_address='127.0.0.1',
        user_agent='System Maintenance Script'
    )
    print(f"   ✅ System event logged: {system_event.id}")
    
    print("\n🎉 All events logged successfully!")
    print("✅ Check your database to see the logged events.")
    print("\n💡 You can now use this pattern in any Python script:")
    print("   from django_event_logger import log_event")
    print("   log_event('your_event_type', event_info={...})")

if __name__ == '__main__':
    main()
