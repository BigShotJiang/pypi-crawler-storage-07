"""Helper functions for Plugwise USB."""
