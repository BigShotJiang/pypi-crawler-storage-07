from .split import train_test_split

__all__ = ["train_test_split"]
