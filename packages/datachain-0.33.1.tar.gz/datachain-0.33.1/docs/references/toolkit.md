# Toolkit

Here you can find the toolkit functions on top of DataChain for common DS/ML operations (e.g. train/test split). Import these functions from `datachain.toolkit`.

::: datachain.toolkit
