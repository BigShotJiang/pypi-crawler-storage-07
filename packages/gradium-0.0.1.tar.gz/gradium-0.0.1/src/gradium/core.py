def grd(text: str) -> str:
    return f"Hello, {text}!"
