# gradium

The Gradium API library for Python.

```python
from gradium import grd
print(grd("PyPI"))
```

