# SentryGate

A pluggable API Gateway toolkit for FastAPI with authentication and rate limiting.

This project provides middleware and routing components to easily add gateway functionality to your FastAPI applications.
