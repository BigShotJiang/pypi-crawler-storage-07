import httpx
from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from jose import jwt, jwk
from jose.exceptions import JOSEError
import time


jwks_cache= {
    "keys": None,
    "last_fetched": 0
}

JWKS_TTL_SECONDS = 3600

async def get_supabase_jwks(jwks_url: str):
    now= time.time()
    if not jwks_cache["keys"] or (now - jwks_cache ["last_fetched"] > JWKS_TTL_SECONDS):
        async with httpx.AsyncClient() as client:
            print("🔄 Fetching new Supabase JWKS...")
            response= await client.get(jwks_url)
            response.raise_for_status()
            jwks_cache["keys"]= response.json()["keys"]
            jwks_cache["last_fetched"]= now
    return jwks_cache["keys"]

class AuthMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, supabase_url: str, supabase_jwt_secret: str):
        super().__init__(app)
        self.supabase_url = supabase_url
        self.supabase_jwt_secret = supabase_jwt_secret
        self.jwks_url =  f"{supabase_url}/auth/v1/jwks"
        
    async def dispatch(self, request: Request, call_next):
        auth_header = request.headers.get("Authorization")
        if not auth_header or not auth_header.startswith("Bearer "):
            return Response("Not authorized: Missing or invalid Authorization header", status_code=401)
        
        token = auth_header.split(" ")[1]
        
        try:
            jwks= await get_supabase_jwks(self.jwks_url)
            
            unverified_header = jwt.get_unverified_header(token)
            rsa_key = {}
            
            for key in jwks:
                if key["kid"] == unverified_header["kid"]:
                    rsa_key = {
                        "kty": key["kty"],
                        "kid": key["kid"],
                        "use": key["use"],
                        "n": key["n"],
                        "e": key["e"]
                    }
            if not rsa_key:
                raise JOSEError("Unable to find matching public key")
            
            
            payload = jwt.decode(
                token,
                rsa_key,
                algorithms=["RS256"],
                audience="authenticated", # Important: Verify the token's audience
                issuer=f"{self.supabase_url}/auth/v1",
            )
            
            request.state.user = payload
            
        except JOSEError as e:
            return Response(f"Not authorized: {e}", status_code=401)
        
        response = await call_next(request)
        return response