import time
import redis.asyncio as redis
from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
import os
import asyncio
    
LUA_SCRIPT = """
    -- Remove timestamps older than the window
    redis.call('ZREMRANGEBYSCORE', KEYS[1], '-inf', ARGV[2])
    -- Get the current number of requests
    local current_requests = redis.call('ZCARD', KEYS[1])
    -- If the limit is reached, return 0 (deny)
    if current_requests >= tonumber(ARGV[3]) then
        return 0
    end
    -- Otherwise, add the new request timestamp and return 1 (allow)
    redis.call('ZADD', KEYS[1], ARGV[1], ARGV[1])
    -- Set an expiration on the key to auto-clean Redis memory for inactive users
    redis.call('EXPIRE', KEYS[1], tonumber(ARGV[4]))
    return 1
    """
    
    
class RateLimitingMiddleware(BaseHTTPMiddleware):
    def __init__(
        self,
        app,
        redis_url: str,
        requests_per_window: int,
        window_seconds: int,
    ):
        super().__init__(app)
        self.redis_url = redis_url
        self.requests_per_window = requests_per_window
        self.window_seconds = window_seconds
        self.redis_client = None

    async def connect_to_redis(self):
        try:
            self.redis_client = await redis.from_url(self.redis_url, decode_responses=True)
            await self.redis_client.ping()
            print("✅ Rate Limiter successfully connected to Redis.")
        except redis.exceptions.ConnectionError as e:
            print(f"--- Rate Limiter could not connect to Redis: {e} ---")
            self.redis_client = None

    async def close_redis_client(self):
        if self.redis_client:
            await self.redis_client.close()
            print("✅ Rate Limiter successfully disconnected from Redis.")
            self.redis_client = None

    async def dispatch(self, request: Request, call_next):
        if self.redis_client is None:
            await self.connect_to_redis()
            if self.redis_client is None:
                print("Warning: Rate Limiter is not connected to Redis. Bypassing.")
                return await call_next(request)

        # Identify users by an API key in the header.
        api_key = request.headers.get("X-API-Key")
        if not api_key:
            return Response("Not authorized: Missing X-API-Key header", status_code=401)

        # --- Rate Limiting Configuration ---
        current_time = time.time()
        window_start = current_time - self.window_seconds

        # Register the script with Redis. 
        check_and_insert_script = self.redis_client.register_script(LUA_SCRIPT)

        # Execute the Lua script atomically on the Redis server.
        # The script returns 1 if the request is allowed, 0 if denied.
        is_allowed = await check_and_insert_script(
            keys=[api_key],
            args=[
                current_time,
                window_start,
                self.requests_per_window,
                self.window_seconds + 5  # Add a small buffer for key expiration
            ]
        )

        if not is_allowed:
            # If the script returned 0, the limit has been exceeded.
            return Response("Too Many Requests", status_code=429)

        # If the script returned 1, pass control to the next middleware or route handler.
        response = await call_next(request)
        return response
    