from fastapi import APIRouter, Request, HTTPException, Response
import httpx
import time
import os
import asyncio
from starlette.background import BackgroundTask
from starlette.responses import StreamingResponse

# This client should be shared across the application that uses the router.
# For simplicity in this package, we define it here.
client = httpx.AsyncClient()

def create_gateway_router(routes: list) -> APIRouter:
    """
    Creates and returns a FastAPI APIRouter that acts as a dynamic gateway.

    Args:
        routes (list): A list of route configuration dictionaries.
                       Each dict should have 'path_prefix' and 'target_service'.

    Returns:
        APIRouter: A FastAPI router with a catch-all route configured.
    """
    router = APIRouter()

    #--helper functions to filter headers--
    def filter_headers(headers:dict)->dict:
        """Filters out hop-by-hop headers that shouldn't be forwarded."""
        headers_to_exclude = [
            "host", "content-length", "transfer-encoding", "connection"
        ]
        return {k: v for k, v in headers.items() if k.lower() not in headers_to_exclude}

    @router.api_route("/{path:path}", methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"])
    async def route_request(request:Request):
        request_path = f"/{request.path_params['path']}"
        target_service = None

        # Find the correct target service from the provided routes config
        for route in routes:
            if request_path.startswith(route["path_prefix"]):
                target_service = route["target_service"]
                break

        if not target_service:
            # If no route matches, let other routes in the app handle it.
            # We can't raise a 404 here, as the user's app might have a matching route.
            # This is a key difference in a pluggable router.
            # For a standalone gateway, a 404 would be appropriate.
            # A more advanced implementation might return a special response
            # that the main app can choose to interpret as a 404.
            # For now, we'll let it fall through. A 404 will be raised by FastAPI if no route matches.
            return Response(status_code=404) # Or let it fall through

        #prepare and stream the request to the target service
        target_url = httpx.URL(
            url=f"{target_service}{request_path}",
            query=request.url.query.encode("utf-8")
        )

        downstream_request = client.build_request(
            method=request.method,
            url=target_url,
            headers=filter_headers(dict(request.headers)),
            content=request.stream()
        )

        try:
            downstream_response = await client.send(downstream_request, stream=True)
        except httpx.ConnectError:
            return Response(content="Upstream service is unavailable.", status_code=502)

        #stream the response back to the client
        background_task = BackgroundTask(downstream_response.aclose)

        return StreamingResponse(
            downstream_response.aiter_raw(),
            status_code=downstream_response.status_code,
            headers=filter_headers(dict(downstream_response.headers)),
            background=background_task
        )

    return router