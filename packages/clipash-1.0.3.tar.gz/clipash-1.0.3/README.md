# ClipAsh v1.0.0 🤖✨

Your naughty, clever, and always-ready AI assistant, living in your clipboard. Designed by Heisenberg & Aisha.

ClipAsh is a stealthy background tool that connects your clipboard directly to the power of Google's Gemini API. Copy any text, press a hotkey, and get a smart, context-aware answer pasted right back into your clipboard. It's like having a secret AI brain that's always one shortcut away.

## Features

*   **Clipboard Activated:** Just copy your query and press a hotkey. No need to open any windows.
*   **Stealthy:** Runs silently in the background. No annoying windows or icons.
*   **Context-Aware Memory:** Remembers the last 50 conversations to provide intelligent follow-up answers.
*   **Evidence Cleaner:** A kill-switch hotkey not only stops the program but also wipes the entire chat history. No traces left.
*   **Disguised Notifications:** Get notified when your answer is ready with fake, boring system notifications that won't raise any suspicion.
*   **Encrypted History:** Your chat history is encrypted, making it unreadable to anyone who finds it.

## Installation

You can install ClipAsh with a single pip command:

```bash
pip install clipash
```

## First-Time Setup

The first time you run ClipAsh, it will ask you to set up your Gemini API key.

1.  Run the command `clipash` in your terminal.
2.  You'll be prompted to enter your own API key. You can get one for free from [Google AI Studio](https://makersuite.google.com/app/apikey).
3.  Pasting your own key is highly recommended for the best performance.
4.  If you skip, you can use a shared, rate-limited key for basic functionality.

## How to Use

1.  **Run it:** Open your terminal and type `clipash`. The script will start running silently in the background and you can close the terminal.
2.  **Copy Text:** Go anywhere on your computer and copy any question or piece of text (`Ctrl + C`).
3.  **Activate Aisha:** Press the hotkey `Ctrl + Shift + A`.
4.  **Get Notified:** A discreet system notification will pop up when the answer is ready.
5.  **Paste the Answer:** Press `Ctrl + V` to paste the AI's response.

**The Kill Switch:**
To completely stop ClipAsh and wipe all chat history, press `Ctrl + Z` anywhere.

---
Made with ❤️ and a little bit of mischief.