//! Functionality for reading and writing Apache Parquet files.

pub mod metadata;
pub mod read;
pub mod write;
