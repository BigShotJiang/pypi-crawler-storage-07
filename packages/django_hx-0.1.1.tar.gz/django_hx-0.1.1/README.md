# Django-HX

Breaking changes may occur at any time.

Make sure to pin a specific version.

 ```toml
 # pyproject.toml
 [project]
 dependencies = [
     "django-hx==1.2.3", # Pinning to exact version 1.2.3
     # ... other dependencies
 ]
 ```
