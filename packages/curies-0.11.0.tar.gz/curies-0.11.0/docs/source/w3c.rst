W3C Validation
==============

.. automodapi:: curies.w3c
    :no-inheritance-diagram:
    :no-heading:
    :include-all-objects:
