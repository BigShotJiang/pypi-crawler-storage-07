<!--
Thanks for contributing to `curies`.
To help us out with reviewing, please consider the following:

- Does this pull request include a summary of the change? (See below.)
- Does this pull request include a descriptive title?
- Does this pull request include references to any relevant issues?

Caution: the maintainers often take an active role in pull requests,
and may push to your branch. Therefore, you should always sync your
local copy of the repository with the remote before continuing your
work.
-->

## Summary

<!-- What's the purpose of the change? What does it do, and why? -->
