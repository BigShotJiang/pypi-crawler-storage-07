from .var_string import encode_var_string

__all__ = ['encode_var_string']
