from typing import Any

import helpers_1


class Model:
    def predict(self, model_input: Any) -> Any:
        return helpers_1.foo(123)
