import helpers_2


def foo(x):
    return helpers_2.bar(x)
