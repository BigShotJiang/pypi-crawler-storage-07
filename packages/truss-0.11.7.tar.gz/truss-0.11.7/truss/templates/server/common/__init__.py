"""This module is designated to exist inside of Truss environments and containers"""
