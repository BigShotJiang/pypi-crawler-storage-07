import Model from '@girder/core/models/Model';

var ThumbnailModel = Model.extend({
    resourceName: 'thumbnail'
});

export default ThumbnailModel;
