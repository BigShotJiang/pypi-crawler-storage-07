# Calculadora Py

Calculadora en Python implementada con el patrón de diseño **State**.

## Instalación

```bash
pip install calculadora-py
