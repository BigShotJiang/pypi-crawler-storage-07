# -*- coding: utf-8 -*-

from .caster import amplifybackend_caster

caster = amplifybackend_caster

__version__ = "1.40.0"