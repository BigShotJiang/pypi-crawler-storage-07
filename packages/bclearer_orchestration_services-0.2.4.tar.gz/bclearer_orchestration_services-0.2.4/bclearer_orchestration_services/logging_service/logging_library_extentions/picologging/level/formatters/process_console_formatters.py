class ProcessConsoleFormatters:
    pass
