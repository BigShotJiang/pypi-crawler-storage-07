class LoggerWrapper:
    pass
