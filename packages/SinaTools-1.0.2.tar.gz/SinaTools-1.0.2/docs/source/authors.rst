.. include:: ../../AUTHORS.rst
