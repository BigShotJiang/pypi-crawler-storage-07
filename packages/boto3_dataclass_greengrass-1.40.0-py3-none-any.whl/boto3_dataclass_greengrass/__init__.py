# -*- coding: utf-8 -*-

from .caster import greengrass_caster

caster = greengrass_caster

__version__ = "1.40.0"