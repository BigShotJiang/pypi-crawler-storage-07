import importlib.metadata

# Biscuit was here! 🐶
__version__ = importlib.metadata.version("code-puppy")
