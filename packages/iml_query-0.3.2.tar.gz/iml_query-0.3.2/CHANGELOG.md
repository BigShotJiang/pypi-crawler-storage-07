# CHANGELOG

## [v0.3.0] - 2025.09.26
- multi-pattern query optimization
- add types (dataclasses) for captures

## [v0.2.0] - 2025.09.23
- IML code manipulation
  - remove decomp / verify / instance requests from IML code
  - attach decomp / verify / instance requests to IML code
- basic linting: detect nested measure attributes
- refactor
  - reorganize query.py into focused modules
  - better test coverage
- example script


## [v0.1.0] - 2025.09.19

- grammar
- basic queries
- basic API bundled with queries
