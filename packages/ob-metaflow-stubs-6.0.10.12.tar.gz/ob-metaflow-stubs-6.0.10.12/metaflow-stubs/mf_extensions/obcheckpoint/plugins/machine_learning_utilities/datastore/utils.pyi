######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.18.9.1+obcheckpoint(0.2.8);ob(v1)                                                    #
# Generated on 2025-09-30T17:31:30.301999                                                            #
######################################################################################################

from __future__ import annotations



def is_json_serializable(value):
    """
    Check if value is JSON serializable.
    """
    ...

def safe_serialize(data):
    ...

