######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.18.9.1+obcheckpoint(0.2.8);ob(v1)                                                    #
# Generated on 2025-09-30T17:31:30.257097                                                            #
######################################################################################################

from __future__ import annotations


from . import uv_environment as uv_environment

