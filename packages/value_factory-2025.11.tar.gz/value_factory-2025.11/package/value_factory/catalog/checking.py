IsInstanceFromPython = isinstance
