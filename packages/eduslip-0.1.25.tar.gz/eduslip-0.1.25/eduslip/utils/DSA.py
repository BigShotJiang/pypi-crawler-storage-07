DSA_SLIPS = [
    {
        "slipNo": 1,
        "questions": [
            {
                "question": " ",
                "filenames": ["Q1.c"]
            },
            {
                "question": " ",
                "filenames": ["btree.h"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "Q1.c": """#include <stdio.h>
#include <stdlib.h>
#include "btree.h"
int main()
{
    int ch, n, i, value, cnt;
    struct bst *newnode, *root, *temp;
    root = NULL;
    while (1)
    {
        printf("\\n---Binary Search Tree---\\n");
        printf("1.Insert\\n");
        printf("2.Inorder Traversal (Recursive)\\n");
        printf("3.Exit\\n");
        printf("Enter your choice:");
        scanf("%d", &ch);
        switch (ch)
        {
        case 1:
            printf("\\nHow many nodes to create:");
            scanf("%d", &n);
            for (i = 0; i < n; i++)
            {
                newnode = create();
                printf("\\nEnter the node data:");
                scanf("%d", &newnode->data);
                if (root == NULL)
                    root = newnode;
                else
                    insert(root, newnode);
            }
            break;
        case 2:
            printf("\\nInorder Traversal=");
            inorder(root);
            break;
        case 3:
            exit(0);
        default:
            printf("\\nInvalid Choice\\n");
        }
    }
}""",
            "btree.h": """#include <stdio.h>
#include <stdlib.h>

struct bst
{
    int data;
    struct bst *lchild, *rchild;
} node;
int cnt = 0, leafcnt = 0, nleafcnt = 0;

struct bst *create()
{
    struct bst *temp = (struct bst *)malloc(sizeof(struct bst));
    temp->lchild = NULL;
    temp->rchild = NULL;
    return temp;
}

void insert(struct bst *r, struct bst *new1)
{

    if (new1->data < r->data)
    {
        if (r->lchild == NULL)
            r->lchild = new1;
        else
            insert(r->lchild, new1);
    }

    if (new1->data > r->data)
    {
        if (r->rchild == NULL)
            r->rchild = new1;
        else
            insert(r->rchild, new1);
    }
}
void inorder(struct bst *temp)
{
    if (temp != NULL)
    {
        inorder(temp->lchild);
        printf("%d\\t", temp->data);
        inorder(temp->rchild);
    }
}""",
            "Q2.c": """#include <stdio.h>
#include <malloc.h>
void create(int a[10][10], int n)
{
    int i, j;
    printf("\\n****TYPE 1 FOR YES & 0 FOR NO****\\n");
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            a[i][j] = 0;
            if (i != j)
            {
                printf("\\nIs there any edge between %d & %d: ", i + 1, j + 1);
                scanf("%d", &a[i][j]);
            }
        }
    }
}
void inout(int a[10][10], int n)
{
    int i, j;
    int in = 0, out = 0, total = 0;
    printf("\\nVertex\\t\\tIndegree\\tOutdegree\\tTotal Degree");
    for (i = 0; i < n; i++)
    {
        in = out = 0;
        for (j = 0; j < n; j++)
        {
            in = in + a[j][i];
            out = out + a[i][j];
        }
        total = in + out;
        printf("\\n%d\\t\\t%d\\t\\t%d\\t\\t%d", i + 1, in, out, total);
    }
}
int main()
{
    int a[10][10], n;
    printf("\\nEnter the no. of vertex: ");
    scanf("%d", &n);
    create(a, n);
    inout(a, n);
}"""
        }
    },
    {
        "slipNo": 2,
        "questions": [
            {
                "question": " ",
                "filenames": ["Q1.c"]
            },
            {
                "question": " ",
                "filenames": ["btree.h"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "Q1.c": """#include<stdio.h>
#include<stdlib.h>
#include "btree.h"
int main()
{
    int ch,n,i,value,cnt;
    struct bst *newnode,*root,*temp;
    root=NULL;
    while(1)
    {
        printf("\\n---Binary Search Tree---\\n");
        printf("1.Insert\\n");
        printf("2.Search\\n");
        printf("3.Preorder Traversal (Recursive)\\n");
        printf("4.Exit\\n");
        printf("Enter your choice:");
        scanf("%d",&ch);
        switch(ch)
        {
                    case 1:printf("\\nHow many nodes to create:");
                        scanf("%d",&n);
                        for(i=0;i<n;i++)
                    {
                 		  newnode=create();
                        printf("\\nEnter the node data:");
                        scanf("%d",&newnode->data);
                        if(root==NULL)
                            root=newnode;
                        else
                            insert(root,newnode);
                    }
                    break;
            case 2:     printf("\\nEnter the node value to be searched:");
                    scanf("%d",&value);
                    temp=search(root,value);
                    if(temp==NULL)
                        printf("\\nNode Not Found\\n");
                    else
                        printf("\\nNode Found\\n");
                    break;
            case 3:     printf("\\nPreorder Traversal=");
                    preorder(root);
                    break;
            case 4: exit(0);
            default: printf("\\nInvalid Choice\\n");
        }
    }
}""",
            "btree.h": """#include<stdio.h>
#include<stdlib.h>

struct bst
{
    int data;
    struct bst *lchild,*rchild;
}node;
int cnt=0,leafcnt=0,nleafcnt=0;

struct bst *create()
{
    struct bst *temp=(struct bst*)malloc(sizeof(struct bst));
    temp->lchild=NULL;
    temp->rchild=NULL;
    return temp;
}

void insert(struct bst *r, struct bst *new1)
{

    if(new1->data < r->data)
    {
        if(r->lchild==NULL)
            r->lchild=new1;
        else
            insert(r->lchild,new1);
    }

    if(new1->data > r->data)
    {
        if(r->rchild==NULL)
            r->rchild=new1;
        else
            insert(r->rchild,new1);
    }
}
struct bst *search(struct bst *r, int key)
{
    struct bst *temp;
    temp=r;
    while(temp!=NULL)
    {
        if(temp->data==key)
            return temp;
        if(key < temp->data)
            temp=temp->lchild;
        else
            temp=temp->rchild;
    }
    return NULL;
}
void preorder(struct bst *temp)
{
    if(temp!=NULL)
    {
        printf("%d\\t",temp->data);
        preorder(temp->lchild);
        preorder(temp->rchild);
    }
}""",
            "Q2.c": """#include <stdio.h>
#include <stdlib.h>
#define MAX 10
void dijkstra(int G[MAX][MAX], int n, int startnode);
int main()
{
    int G[MAX][MAX], i, j, n, u;
    printf("enter no. of vertices:");
    scanf("%d", &n);
    printf("\\nenter the adjacency matrix:\\n");
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
            scanf("%d", &G[i][j]);
    printf("\\nenter the starting node:");
    scanf("%d", &u);
    dijkstra(G, n, u);
    return 0;
}
void dijkstra(int G[MAX][MAX], int n, int startnode)
{
    int cost[MAX][MAX], distance[MAX], pred[MAX];
    int visited[MAX], count, mindistance, nextnode, i, j;
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
            if (G[i][j] == 0)
                cost[i][j] = 999;
            else
                cost[i][j] = G[i][j];
    for (i = 0; i < n; i++)
    {
        distance[i] = cost[startnode][i];
        pred[i] = startnode;
        visited[i] = 0;
    }
    distance[startnode] = 0;
    visited[startnode] = 1;
    count = 1;
    while (count < n - 1)
    {
        mindistance = 999;
        for (i = 0; i < n; i++)
            if (distance[i] < mindistance && !visited[i])
            {
                mindistance = distance[i];
                nextnode = i;
            }
        visited[nextnode] = 1;
        for (i = 0; i < n; i++)
            if (!visited[i])
                if (mindistance + cost[nextnode][i] < distance[i])
                {
                    distance[i] = mindistance + cost[nextnode][i];
                    pred[i] = nextnode;
                }
        count++;
    }
    for (i = 0; i < n; i++)
        if (i != startnode)
        {
            printf("\\n distance of node%d=%d", i, distance[i]);
            printf("\\n Path=%d", i);
            j = i;
            do
            {
                j = pred[j];
                printf("<-%d", j);
            } while (j != startnode);
        }
}""",
        }
    },
    {
        "slipNo": 3,
        "questions": [
            {
                "question": " ",
                "filenames": ["Q1.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "Q1.c": """#include <stdio.h>
#include <stdlib.h>
#define TABLE_SIZE 10

int h[TABLE_SIZE];

void initTable() {
    for (int i = 0; i < TABLE_SIZE; i++) {
        h[i] = -1;
    }
}

void insert() {
    int key, index, i, hkey;
    printf("\\nEnter a value to insert into hash table: ");
    scanf("%d", &key);

    hkey = key % TABLE_SIZE;
    for (i = 0; i < TABLE_SIZE; i++) {
        index = (hkey + i) % TABLE_SIZE;
        if (h[index] == -1) {
            h[index] = key;
            printf("Inserted %d at index %d\\n", key, index);
            break;
        }
    }
    if (i == TABLE_SIZE)
        printf("\\nElement cannot be inserted (table full)\\n");
}

void search() {
    int key, index, i, hkey;
    printf("\\nEnter search element: ");
    scanf("%d", &key);

    hkey = key % TABLE_SIZE;
    for (i = 0; i < TABLE_SIZE; i++) {
        index = (hkey + i) % TABLE_SIZE;
        if (h[index] == key) {
            printf("Value %d is found at index %d\\n", key, index);
            break;
        }
    }
    if (i == TABLE_SIZE)
        printf("\\nValue not found\\n");
}

void display() {
    printf("\\nElements in the hash table are:\\n");
    for (int i = 0; i < TABLE_SIZE; i++) {
        printf("Index %d -> %d\\n", i, h[i]);
    }
}

int main() {
    int opt;
    initTable();

    while (1) {
        printf("\\nPress 1. Insert \\n2. Display \\n3. Search \\n4. Exit\\n");
        scanf("%d", &opt);

        switch (opt) {
        case 1: insert(); break;
        case 2: display(); break;
        case 3: search(); break;
        case 4: exit(0);
        default: printf("Invalid option!\\n");
        }
    }
    return 0;
}
""",
            "Q2.c": """#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
typedef struct node
{
    int vertex;
    struct node *next;
} NODE;
void create(int a[10][10], int n)
{
    int i, j;
    printf("\\n****TYPE 1 FOR YES & 0 FOR NO****\\n");
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            a[i][j] = 0;
            if (i != j)
            {
                printf("\\nIs there any edge between %d & %d: ", i + 1, j + 1);
                scanf("%d", &a[i][j]);
            }
        }
    }
}

void display(int a[10][10], int n)
{
    int i, j;
    printf("\\nThe Matrix is: \\n");
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            printf("%d\\t", a[i][j]);
        }
        printf("\\n");
    }
}
void recdfs(int a[20][20], int n, int v)
{
    int w;
    static int visited[20] = {0};
    visited[v] = 1;
    printf("v%d\\t", v + 1);
    for (w = 0; w < n; w++)
    {
        if ((a[v][w] == 1) && (visited[w] == 0))
            recdfs(a, n, w);
    }
}

int main()
{
    int a[10][10], n;
    printf("\\nEnter the no. of vertex: ");
    scanf("%d", &n);
    create(a, n);
    display(a, n);
    printf("\\nThe Depth First Search Traversal is: \\n");
    recdfs(a, n, 0);
}"""
        }
    },
    {
        "slipNo": 4,
        "questions": [
            {
                "question": " ",
                "filenames": ["Q1.c"]
            },
            {
                "question": " ",
                "filenames": ["btree.h"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "Q1.c": """#include <stdio.h>
#include <stdlib.h>
#include "btree.h"
    int main()
{
    int ch, n, i, value, cnt;
    struct bst *newnode, *root, *temp;
    root = NULL;
    while (1)
    {
        printf("\\n---Binary Search Tree---\\n");
        printf("1.Insert\\n");
        printf("2.Preorder Traversal (Recursive)\\n\\n");
        printf("3.Postorder Traversal (Recursive)\\n");
        printf("4.Exit\\n");
        printf("Enter your choice:");
        scanf("%d", &ch);
        switch (ch)
        {
        case 1:
            printf("\\nHow many nodes to create:");
            scanf("%d", &n);
            for (i = 0; i < n; i++)
            {
                newnode = create();
                printf("\\nEnter the node data:");
                scanf("%d", &newnode->data);
                if (root == NULL)
                    root = newnode;
                else
                    insert(root, newnode);
            }
            break;
        case 2:
            printf("\\nPreorder Traversal=");
            preorder(root);
            break;
        case 3:
            printf("\\nPostorder Traversal=");
            postorder(root);
            break;
        case 4:
            exit(0);
        default:
            printf("\\nInvalid Choice\\n");
        }
    }
}""",
            "btree.h": """#include <stdio.h>
#include <stdlib.h>

    struct bst
{
    int data;
    struct bst *lchild, *rchild;
} node;
int cnt = 0, leafcnt = 0, nleafcnt = 0;

struct bst *create()
{
    struct bst *temp = (struct bst *)malloc(sizeof(struct bst));
    temp->lchild = NULL;
    temp->rchild = NULL;
    return temp;
}

void insert(struct bst *r, struct bst *new1)
{

    if (new1->data < r->data)
    {
        if (r->lchild == NULL)
            r->lchild = new1;
        else
            insert(r->lchild, new1);
    }

    if (new1->data > r->data)
    {
        if (r->rchild == NULL)
            r->rchild = new1;
        else
            insert(r->rchild, new1);
    }
}
void postorder(struct bst *temp)
{
    if (temp != NULL)
    {
        postorder(temp->lchild);
        postorder(temp->rchild);
        printf("%d\\t", temp->data);
    }
}
void preorder(struct bst *temp)
{
    if (temp != NULL)
    {
        printf("%d\\t", temp->data);
        preorder(temp->lchild);
        preorder(temp->rchild);
    }
}""",
            "Q2.c": """#include <stdio.h>
    int main()
{
    int a[10][10], i, j, n;
    // Create
    printf("\\nEnter total no. of vertex: ");
    scanf("%d", &n);
    // printf("\\n**PRESS 1 FOR YES & 0 FOR NO**\\n");
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            a[i][j] = 0;
            if (i != j)
            {
                printf("\\nIs there edge between %d & %d: ", i + 1, j + 1);
                scanf("%d", &a[i][j]);
            }
        }
    }
    // Display
    printf("\\n Matrix is \\n");
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            printf("%d\\t", a[i][j]);
        }
        printf("\\n");
    }
}"""
        }
    },
    {
        "slipNo": 5,
        "questions": [
            {
                "question": " ",
                "filenames": ["Q1.c"]
            },
            {
                "question": " ",
                "filenames": ["btree.h"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "Q1.c": """#include <stdio.h>
#include <stdlib.h>
#include "btree.h"
int main()
{
    int ch, n, i, value, cnt;
    struct bst *newnode, *root, *temp;
    root = NULL;
    while (1)
    {
        printf("\\n---Binary Search Tree---\\n");
        printf("1.Insert\\n");
        printf("2.postorder Traversal (Recursive)\\n");
        printf("3.Exit\\n");
        printf("Enter your choice:");
        scanf("%d", &ch);
        switch (ch)
        {
        case 1:
            printf("\\nHow many nodes to create:");
            scanf("%d", &n);
            for (i = 0; i < n; i++)
            {
                newnode = create();
                printf("\\nEnter the node data:");
                scanf("%d", &newnode->data);
                if (root == NULL)
                    root = newnode;
                else
                    insert(root, newnode);
            }
            break;
        case 2:
            printf("\\npostorder Traversal=");
            postorder(root);
            break;
        case 3:
            exit(0);
        default:
            printf("\\nInvalid Choice\\n");
        }
    }
}""",
            "btree.h": """#include <stdio.h>
#include <stdlib.h>

struct bst
{
    int data;
    struct bst *lchild, *rchild;
} node;
int cnt = 0, leafcnt = 0, nleafcnt = 0;

struct bst *create()
{
    struct bst *temp = (struct bst *)malloc(sizeof(struct bst));
    temp->lchild = NULL;
    temp->rchild = NULL;
    return temp;
}

void insert(struct bst *r, struct bst *new1)
{

    if (new1->data < r->data)
    {
        if (r->lchild == NULL)
            r->lchild = new1;
        else
            insert(r->lchild, new1);
    }

    if (new1->data > r->data)
    {
        if (r->rchild == NULL)
            r->rchild = new1;
        else
            insert(r->rchild, new1);
    }
}
void postorder(struct bst *temp)
{
    if (temp != NULL)
    {
        postorder(temp->lchild);
        postorder(temp->rchild);
        printf("%d\\t", temp->data);
    }
}""",
            "Q2.c": """#include <stdio.h>
#include <stdlib.h>
#define MAXSIZE 20
typedef struct
{
    int data[MAXSIZE];
    int front, rear;
} QUEUE;
void initq(QUEUE *pq)
{
    pq->front = pq->rear = -1;
}
void addq(QUEUE *pq, int n)
{
    pq->data[++pq->rear] = n;
}
int removeq(QUEUE *pq)
{
    return pq->data[++pq->front];
}
int isempty(QUEUE *pq)
{
    return (pq->front == pq->rear);
}
void create(int a[10][10], int n)
{
    printf("\\nType 1 for Yes and 0 for No\\n");
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            a[i][j] = 0;
            if (i != j)
            {
                printf("\\n Is there edge between %d and %d:", i + 1, j + 1);
                scanf("%d", &a[i][j]);
            }
        }
    }
}
void bfs(int a[10][10], int n)
{
    int v = 0;
    int visited[20] = {0};
    QUEUE q;
    initq(&q);
    printf("\\nThe breadth first traversal is:\\n");
    visited[v] = 1;
    addq(&q, v);
    while (!isempty(&q))
    {
        v = removeq(&q);
        printf("v%d\\t", v + 1);
        for (int w = 0; w < n; w++)
        {
            if ((a[v][w] == 1) && (visited[w] == 0))
            {
                addq(&q, w);
                visited[w] = 1;
            }
        }
    }
}
int main()
{
    int a[10][10], n;
    printf("\\nEnter the no of vertex:");
    scanf("%d", &n);
    create(a, n);
    bfs(a, n);
}"""
        }
    },
    {
        "slipNo": 6,
        "questions": [
            {
                "question": " ",
                "filenames": ["Q1.c"]
            },
            {
                "question": " ",
                "filenames": ["btree.h"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "Q1.c": """#include <stdio.h>
#include <stdlib.h>
#include "btree.h"
    int main()
{
    int ch, n, i, value, cnt;
    struct bst *newnode, *root, *temp;
    root = NULL;
    while (1)
    {
        printf("\\n---Binary Search Tree---\\n");
        printf("1.Insert\\n");
        printf("2.Preorder Traversal (Recursive)\\n\\n");
        printf("3.Postorder Traversal (Recursive)\\n");
        printf("4.Exit\\n");
        printf("Enter your choice:");
        scanf("%d", &ch);
        switch (ch)
        {
        case 1:
            printf("\\nHow many nodes to create:");
            scanf("%d", &n);
            for (i = 0; i < n; i++)
            {
                newnode = create();
                printf("\\nEnter the node data:");
                scanf("%d", &newnode->data);
                if (root == NULL)
                    root = newnode;
                else
                    insert(root, newnode);
            }
            break;
        case 2:
            printf("\\nPreorder Traversal=");
            preorder(root);
            break;
        case 3:
            printf("\\nPostorder Traversal=");
            postorder(root);
            break;

        case 4:
            exit(0);
        default:
            printf("\\nInvalid Choice\\n");
        }
    }
}""",
            "btree.h": """#include <stdio.h>
#include <stdlib.h>

    struct bst
{
    int data;
    struct bst *lchild, *rchild;
} node;
int cnt = 0, leafcnt = 0, nleafcnt = 0;

struct bst *create()
{
    struct bst *temp = (struct bst *)malloc(sizeof(struct bst));
    temp->lchild = NULL;
    temp->rchild = NULL;
    return temp;
}

void insert(struct bst *r, struct bst *new1)
{

    if (new1->data < r->data)
    {
        if (r->lchild == NULL)
            r->lchild = new1;
        else
            insert(r->lchild, new1);
    }

    if (new1->data > r->data)
    {
        if (r->rchild == NULL)
            r->rchild = new1;
        else
            insert(r->rchild, new1);
    }
}
void postorder(struct bst *temp)
{
    if (temp != NULL)
    {
        postorder(temp->lchild);
        postorder(temp->rchild);
        printf("%d\\t", temp->data);
    }
}
void preorder(struct bst *temp)
{
    if (temp != NULL)
    {
        printf("%d\\t", temp->data);
        preorder(temp->lchild);
        preorder(temp->rchild);
    }
}""",
            "Q2.c": """#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
    int vertex;
    struct node *next;
} NODE;

NODE *list[10];

void create(int a[10][10], int n)
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            a[i][j] = 0;
            if (i != j)
            {
                printf("\\nIs there edge between %d & %d: ", i + 1, j + 1);
                scanf("%d", &a[i][j]);
            }
        }
    }
}

void clist(int a[10][10], int n)
{
    NODE *temp, *newnode;
    for (int i = 0; i < n; i++)
    {
        list[i] = NULL;
        for (int j = 0; j < n; j++)
        {
            if (a[i][j] == 1)
            {
                newnode = (NODE *)malloc(sizeof(NODE));
                newnode->vertex = j + 1;
                newnode->next = NULL;
                if (list[i] == NULL)
                    list[i] = temp = newnode;
                else
                {
                    temp->next = newnode;
                    temp = newnode;
                }
            }
        }
    }
}

void dlist(int n)
{
    NODE *temp;
    printf("\\nThe Adjacency list is:\\n");
    for (int i = 0; i < n; i++)
    {
        printf("v%d --> ", i + 1);
        temp = list[i];
        while (temp)
        {
            printf("v%d --> ", temp->vertex);
            temp = temp->next;
        }
        printf("NULL\\n");
    }
}

int main()
{
    int a[10][10], n, i, j, in, out;

    printf("\\nEnter the no. of vertex: ");
    scanf("%d", &n);

    create(a, n);
    clist(a, n);
    dlist(n);

    printf("Vertex   In-degree   Out-degree\\n");

    for (i = 0; i < n; i++)
    {
        in = out = 0;
        for (j = 0; j < n; j++)
        {
            in += a[j][i];
            out += a[i][j]; // Count outgoing edges
        }
        printf("%3d%14d%10d\\n", i + 1, in, out);
    }

    return 0;
}
"""
        }
    },
    {
        "slipNo": 7,
        "questions": [
            {
                "question": " ",
                "filenames": ["Q1.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "Q1.c": """#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node *left, *right;
} Node;

Node* createNode(int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    return newNode;
}

Node* insert(Node* root, int data) {
    if (root == NULL) return createNode(data);
    if (data < root->data) root->left = insert(root->left, data);
    else root->right = insert(root->right, data);
    return root;
}

void preorder(Node* root) {
    if (root == NULL) return;
    printf("%d ", root->data);
    preorder(root->left);
    preorder(root->right);
}

int main() {
    Node* root = NULL;
    int choice, data;

    do {
        printf("\\n1. Insert\\n2. Preorder Traversal\\n3. Exit\\nEnter choice: ");
        scanf("%d", &choice);
        if (choice == 1) {
            printf("Enter value: ");
            scanf("%d", &data);
            root = insert(root, data);
        } else if (choice == 2) {
            preorder(root);
            printf("\\n");
        }
    } while (choice != 3);

    return 0;
}""",
            "Q2.c": """#include <stdio.h>
#include <stdlib.h>

#define MAX_VERTICES 100

int adjMatrix[MAX_VERTICES][MAX_VERTICES];
int visited[MAX_VERTICES];
int vertices;

void initializeMatrix()
{
    for (int i = 0; i < vertices; i++)
    {
        for (int j = 0; j < vertices; j++)
        {
            adjMatrix[i][j] = 0;
        }
        visited[i] = 0;
    }
}

void addEdge(int src, int dest)
{
    adjMatrix[src][dest] = 1;
    adjMatrix[dest][src] = 1;
}

void displayMatrix()
{
    for (int i = 0; i < vertices; i++)
    {
        for (int j = 0; j < vertices; j++)
        {
            printf("%d ", adjMatrix[i][j]);
        }
        printf("\\n");
    }
}

void DFS(int vertex)
{
    printf("%d ", vertex);
    visited[vertex] = 1;
    for (int i = 0; i < vertices; i++)
    {
        if (adjMatrix[vertex][i] == 1 && !visited[i])
        {
            DFS(i);
        }
    }
}

int main()
{
    int edges, src, dest;

    printf("Enter number of vertices: ");
    scanf("%d", &vertices);

    initializeMatrix();

    printf("Enter number of edges: ");
    scanf("%d", &edges);

    for (int i = 0; i < edges; i++)
    {
        printf("Enter edge (source destination): ");
        scanf("%d %d", &src, &dest);
        addEdge(src, dest);
    }

    displayMatrix();

    printf("\\nDFS Traversal: ");
    DFS(0);
    printf("\\n");

    return 0;
}"""
        }
    },
    {
        "slipNo": 8,
        "questions": [
            {
                "question": " ",
                "filenames": ["Q1.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "Q1.c": """#include <stdio.h>
#include <stdlib.h>

#define MAX_VERTICES 100

    int adjMatrix[MAX_VERTICES][MAX_VERTICES];
int vertices;

void initializeMatrix()
{
    for (int i = 0; i < vertices; i++)
    {
        for (int j = 0; j < vertices; j++)
        {
            adjMatrix[i][j] = 0;
        }
    }
}

void addEdge(int src, int dest)
{
    adjMatrix[src][dest] = 1;
    adjMatrix[dest][src] = 1;
}

void displayMatrix()
{
    for (int i = 0; i < vertices; i++)
    {
        for (int j = 0; j < vertices; j++)
        {
            printf("%d ", adjMatrix[i][j]);
        }
        printf("\\n");
    }
}

int main()
{
    int edges, src, dest;

    printf("Enter number of vertices: ");
    scanf("%d", &vertices);

    initializeMatrix();

    printf("Enter number of edges: ");
    scanf("%d", &edges);

    for (int i = 0; i < edges; i++)
    {
        printf("Enter edge (source destination): ");
        scanf("%d %d", &src, &dest);
        addEdge(src, dest);
    }

    displayMatrix();

    return 0;
}""",
            "Q2.c": """#include <stdio.h>
#include <stdlib.h>
#define TABLE_SIZE 10

int h[TABLE_SIZE];

void initTable()
{
    for (int i = 0; i < TABLE_SIZE; i++)
    {
        h[i] = -1;
    }
}

void insert()
{
    int key, index, i, hkey;
    printf("\\nEnter a value to insert into hash table: ");
    scanf("%d", &key);

    hkey = key % TABLE_SIZE;
    for (i = 0; i < TABLE_SIZE; i++)
    {
        index = (hkey + i) % TABLE_SIZE;
        if (h[index] == -1)
        {
            h[index] = key;
            printf("Inserted %d at index %d\\n", key, index);
            break;
        }
    }
    if (i == TABLE_SIZE)
        printf("\\nElement cannot be inserted (table full)\\n");
}

void search()
{
    int key, index, i, hkey;
    printf("\\nEnter search element: ");
    scanf("%d", &key);

    hkey = key % TABLE_SIZE;
    for (i = 0; i < TABLE_SIZE; i++)
    {
        index = (hkey + i) % TABLE_SIZE;
        if (h[index] == key)
        {
            printf("Value %d is found at index %d\\n", key, index);
            break;
        }
    }
    if (i == TABLE_SIZE)
        printf("\\nValue not found\\n");
}

void display()
{
    printf("\\nElements in the hash table are:\\n");
    for (int i = 0; i < TABLE_SIZE; i++)
    {
        printf("Index %d -> %d\\n", i, h[i]);
    }
}

int main()
{
    int opt;
    initTable();

    while (1)
    {
        printf("\\nPress 1. Insert\\n 2. Display\\n 3. Search\\n 4. Exit\\n");
        scanf("%d", &opt);

        switch (opt)
        {
        case 1:
            insert();
            break;
        case 2:
            display();
            break;
        case 3:
            search();
            break;
        case 4:
            exit(0);
        default:
            printf("Invalid option!\\n");
        }
    }
    return 0;
}
"""
        }
    },
    {
        "slipNo": 9,
        "questions": [
            {
                "question": " ",
                "filenames": ["Q1.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "Q1.c": """#include <stdio.h>
#include <stdlib.h>

#define MAX 100

    int adj[MAX][MAX];
int visited[MAX];
int vertices;

void initialize()
{
    for (int i = 0; i < vertices; i++)
    {
        for (int j = 0; j < vertices; j++)
        {
            adj[i][j] = 0;
        }
        visited[i] = 0;
    }
}

void addEdge(int src, int dest)
{
    adj[src][dest] = 1;
    adj[dest][src] = 1;
}

void displayMatrix()
{
    for (int i = 0; i < vertices; i++)
    {
        for (int j = 0; j < vertices; j++)
        {
            printf("%d ", adj[i][j]);
        }
        printf("\\n");
    }
}

void DFS(int vertex)
{
    printf("%d ", vertex);
    visited[vertex] = 1;
    for (int i = 0; i < vertices; i++)
    {
        if (adj[vertex][i] == 1 && !visited[i])
        {
            DFS(i);
        }
    }
}

int main()
{
    int edges, src, dest;

    printf("Enter number of vertices: ");
    scanf("%d", &vertices);

    initialize();

    printf("Enter number of edges: ");
    scanf("%d", &edges);

    for (int i = 0; i < edges; i++)
    {
        printf("Enter edge (source destination): ");
        scanf("%d %d", &src, &dest);
        addEdge(src, dest);
    }

    displayMatrix();

    printf("\\nDFS Traversal: ");
    DFS(0);
    printf("\\n");

    return 0;
}""",
            "Q2.c": """#include <stdio.h>
#include <stdlib.h>

    typedef struct Node
{
    int data;
    struct Node *left, *right;
} Node;

Node *createNode(int data)
{
    Node *newNode = (Node *)malloc(sizeof(Node));
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    return newNode;
}

Node *insert(Node *root, int data)
{
    if (root == NULL)
        return createNode(data);
    if (data < root->data)
        root->left = insert(root->left, data);
    else if (data > root->data)
        root->right = insert(root->right, data);
    return root;
}

int countLeafNodes(Node *root)
{
    if (root == NULL)
        return 0;
    if (root->left == NULL && root->right == NULL)
        return 1;
    return countLeafNodes(root->left) + countLeafNodes(root->right);
}

int main()
{
    Node *root = NULL;
    int n, value;

    printf("Enter number of elements: ");
    scanf("%d", &n);

    for (int i = 0; i < n; i++)
    {
        printf("Enter value: ");
        scanf("%d", &value);
        root = insert(root, value);
    }

    printf("Leaf Nodes Count: %d\\n", countLeafNodes(root));

    return 0;
}"""
        }
    },
    {
        "slipNo": 10,
        "questions": [
            {
                "question": " ",
                "filenames": ["Q1.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "Q1.c": """#include <stdio.h>
#include <stdlib.h>

#define MAX 100

    int adjMatrix[MAX][MAX];
int visited[MAX];
int numVertices;

void initialize()
{
    for (int i = 0; i < MAX; i++)
    {
        for (int j = 0; j < MAX; j++)
        {
            adjMatrix[i][j] = 0;
        }
        visited[i] = 0;
    }
}

void addEdge(int u, int v)
{
    adjMatrix[u][v] = 1;
    adjMatrix[v][u] = 1;
}

void DFS(int vertex)
{
    printf("%d ", vertex);
    visited[vertex] = 1;

    for (int i = 0; i < numVertices; i++)
    {
        if (adjMatrix[vertex][i] == 1 && !visited[i])
        {
            DFS(i);
        }
    }
}

int main()
{
    int numEdges, u, v;

    printf("Enter the number of vertices: ");
    scanf("%d", &numVertices);

    printf("Enter the number of edges: ");
    scanf("%d", &numEdges);

    initialize();

    printf("Enter the edges (u v):\\n");
    for (int i = 0; i < numEdges; i++)
    {
        scanf("%d %d", &u, &v);
        addEdge(u, v);
    }

    printf("Adjacency Matrix:\\n");
    for (int i = 0; i < numVertices; i++)
    {
        for (int j = 0; j < numVertices; j++)
        {
            printf("%d ", adjMatrix[i][j]);
        }
        printf("\\n");
    }

    printf("DFS Traversal starting from vertex 0:\\n");
    DFS(0);

    return 0;
}""",
            "Q2.c": """#include <stdio.h>

#define MAX 100

    int adj[MAX][MAX];
int vertices;

void initialize()
{
    for (int i = 0; i < vertices; i++)
    {
        for (int j = 0; j < vertices; j++)
        {
            adj[i][j] = 0;
        }
    }
}

void addEdge(int src, int dest) { adj[src][dest] = 1; }

void displayMatrix()
{
    for (int i = 0; i < vertices; i++)
    {
        for (int j = 0; j < vertices; j++)
        {
            printf("%d ", adj[i][j]);
        }
        printf("\\n");
    }
}

void printIndegree()
{
    for (int i = 0; i < vertices; i++)
    {
        int indegree = 0;
        for (int j = 0; j < vertices; j++)
        {
            if (adj[j][i] == 1)
            {
                indegree++;
            }
        }
        printf("Vertex %d: Indegree = %d\\n", i, indegree);
    }
}

int main()
{
    int edges, src, dest;

    printf("Enter number of vertices: ");
    scanf("%d", &vertices);

    initialize();

    printf("Enter number of edges: ");
    scanf("%d", &edges);

    for (int i = 0; i < edges; i++)
    {
        printf("Enter edge (source destination): ");
        scanf("%d %d", &src, &dest);
        addEdge(src, dest);
    }

    displayMatrix();

    printIndegree();

    return 0;
}"""
        }
    },
    {
        "slipNo": 11,
        "questions": [
            {
                "question": " ",
                "filenames": ["Q1.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
            {
                "question": "",
                "filenames": ["btree.h"]
            },
        ],
        "answers": {
            "Q1.c": """#include <stdio.h>
#include <stdlib.h>
#define MAXSIZE 20
    typedef struct
{
    int data[MAXSIZE];
    int front, rear;
} QUEUE;
void initq(QUEUE *pq)
{
    pq->front = pq->rear = -1;
}
void addq(QUEUE *pq, int n)
{
    pq->data[++pq->rear] = n;
}
int removeq(QUEUE *pq)
{
    return pq->data[++pq->front];
}
int isempty(QUEUE *pq)
{
    return (pq->front == pq->rear);
}
void create(int a[10][10], int n)
{
    printf("\\nType 1 for Yes and 0 for No\\n");
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            a[i][j] = 0;
            if (i != j)
            {
                printf("\\n Is there edge between %d and %d:", i + 1, j + 1);
                scanf("%d", &a[i][j]);
            }
        }
    }
}
void bfs(int a[10][10], int n)
{
    int v = 0;
    int visited[20] = {0};
    QUEUE q;
    initq(&q);
    printf("\\nThe breadth first traversal is:\\n");
    visited[v] = 1;
    addq(&q, v);
    while (!isempty(&q))
    {
        v = removeq(&q);
        printf("v%d\\t", v + 1);
        for (int w = 0; w < n; w++)
        {
            if ((a[v][w] == 1) && (visited[w] == 0))
            {
                addq(&q, w);
                visited[w] = 1;
            }
        }
    }
}
int main()
{
    int a[10][10], n;
    printf("\\nEnter the no of vertex:");
    scanf("%d", &n);
    create(a, n);
    bfs(a, n);
}""",
            "Q2.c": """#include <stdio.h>
#include <stdlib.h>
#include "btree.h"
    int main()
{
    int ch, n, i, value, cnt;
    struct bst *newnode, *root, *temp;
    root = NULL;
    while (1)
    {
        printf("\\n---Binary Search Tree---\\n");
        printf("1.Insert\\n");
        printf("2.Inorder Traversal (Recursive)\\n");
        printf("3.Exit\\n");
        printf("Enter your choice:");
        scanf("%d", &ch);
        switch (ch)
        {
        case 1:
            printf("\\nHow many nodes to create:");
            scanf("%d", &n);
            for (i = 0; i < n; i++)
            {
                newnode = create();
                printf("\\nEnter the node data:");
                scanf("%d", &newnode->data);
                if (root == NULL)
                    root = newnode;
                else
                    insert(root, newnode);
            }
            break;
        case 2:
            printf("\\nInorder Traversal=");
            inorder(root);
            break;
        case 3:
            exit(0);
        default:
            printf("\\nInvalid Choice\\n");
        }
    }
}""",
            "btree.h": """#include <stdio.h>
#include <stdlib.h>

struct bst
{
    int data;
    struct bst *lchild, *rchild;
} node;
int cnt = 0, leafcnt = 0, nleafcnt = 0;

struct bst *create()
{
    struct bst *temp = (struct bst *)malloc(sizeof(struct bst));
    temp->lchild = NULL;
    temp->rchild = NULL;
    return temp;
}

void insert(struct bst *r, struct bst *new1)
{

    if (new1->data < r->data)
    {
        if (r->lchild == NULL)
            r->lchild = new1;
        else
            insert(r->lchild, new1);
    }

    if (new1->data > r->data)
    {
        if (r->rchild == NULL)
            r->rchild = new1;
        else
            insert(r->rchild, new1);
    }
}
void inorder(struct bst *temp)
{
    if (temp != NULL)
    {
        inorder(temp->lchild);
        printf("%d\\t", temp->data);
        inorder(temp->rchild);
    }
}
""",
        }
    },
    {
        "slipNo": 12,
        "questions": [
            {
                "question": " ",
                "filenames": ["Q1.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "Q1.c": """#include <stdio.h>
#include <stdlib.h>

#define MAX 100

int adjMatrix[MAX][MAX];
int visited[MAX];
int vertices;

void initializeGraph()
{
    for (int i = 0; i < MAX; i++)
    {
        for (int j = 0; j < MAX; j++)
        {
            adjMatrix[i][j] = 0;
        }
        visited[i] = 0;
    }
}

void addEdge(int start, int end)
{
    adjMatrix[start][end] = 1;
    adjMatrix[end][start] = 1;
}

void DFS(int vertex)
{
    printf("%d ", vertex);
    visited[vertex] = 1;
    for (int i = 0; i < vertices; i++)
    {
        if (adjMatrix[vertex][i] == 1 && !visited[i])
        {
            DFS(i);
        }
    }
}

int main()
{
    int edges, start, end, startVertex;
    printf("Enter number of vertices: ");
    scanf("%d", &vertices);
    printf("Enter number of edges: ");
    scanf("%d", &edges);

    initializeGraph();

    for (int i = 0; i < edges; i++)
    {
        printf("Enter edge (start end): ");
        scanf("%d %d", &start, &end);
        addEdge(start, end);
    }

    printf("Enter starting vertex for DFS: ");
    scanf("%d", &startVertex);
    printf("DFS Traversal: ");
    DFS(startVertex);
    printf("\\n");

    return 0;
}""",
            "Q2.c": """#include <stdio.h>
#include <stdlib.h>

    typedef struct Node
{
    int data;
    struct Node *left;
    struct Node *right;
} Node;

Node *createNode(int data);
Node *insert(Node *root, int data);
void preorder(Node *root);

Node *createNode(int data)
{
    Node *newNode = (Node *)malloc(sizeof(Node));
    newNode->data = data;
    newNode->left = NULL;
    newNode->right = NULL;
    return newNode;
}

Node *insert(Node *root, int data)
{
    if (root == NULL)
    {
        return createNode(data);
    }
    if (data < root->data)
    {
        root->left = insert(root->left, data);
    }
    else if (data > root->data)
    {
        root->right = insert(root->right, data);
    }
    return root;
}

void preorder(Node *root)
{
    if (root != NULL)
    {
        printf("%d ", root->data);
        preorder(root->left);
        preorder(root->right);
    }
}

int main()
{
    Node *root = NULL;
    int choice, data;

    while (1)
    {
        printf("\\nMenu:\\n");
        printf("1. Insert\\n");
        printf("2. Preorder Traversal\\n");
        printf("3. Exit\\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            printf("Enter the data to insert: ");
            scanf("%d", &data);
            root = insert(root, data);
            break;
        case 2:
            printf("Preorder Traversal: ");
            preorder(root);
            printf("\\n");
            break;
        case 3:
            exit(0);
        default:
            printf("Invalid choice! Please try again.\\n");
        }
    }
    return 0;
}"""
        }
    },
    {
        "slipNo": 13,
        "questions": [
            {
                "question": " ",
                "filenames": ["Q1.c"]
            },
            {
                "question": " ",
                "filenames": ["bcopy.h"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "Q1.c": """#include <stdio.h>
#include "bcopy.h"
int main()
{
  int ch, p;
  NODE *root1, *root2;
  do
  {
  printf("\\n1:create \\n2:copy \\n3:preorder \\n4:comparebst \\n5:Exit");
  printf("\\n enter ur choice");
  scanf("%d",&ch);
  switch(ch)
  {
    case 1:
      root1 = create();
      break;
    case 2:
      root2 = copyt(root1);
      break;
    case 3:
      preorder(root2);
      break;
    case 4:
      p = comparebst(root1, root2);
      if (p == 0)
      {
        printf("\\n bst is not same");
      }
      else
      {
        printf("\\n bst is  same");
      }
      break;
    case 5:
      exit(0);
      break;
  }
  } while (ch != 6);
}""",
            "bcopy.h" : """#include <stdio.h>
#include <stdlib.h>
typedef struct node
{
  int info;
  struct node *left, *right;
} NODE;
NODE *create();
NODE *insert(NODE *, int);
NODE *create()
{
  int i, n, x;
  NODE *root;
  root = NULL;
  printf("\\nEnter the no. of nodes: ");
  scanf("%d", &n);
  for (i = 0; i < n; i++)
  {
    printf("\\nEnter the node: ");
    scanf("%d", &x);
    root = insert(root, x);
  }
  return (root);
}
NODE *insert(NODE *T, int x)
{
  NODE *r;
  if (T == NULL)
  {
    r = (NODE *)malloc(sizeof(NODE));
    r->left = r->right = NULL;
    r->info = x;
    return (r);
  }
  else if (x < T->info)
  {
    T->left = insert(T->left, x);
    return (T);
  }
  if (x > T->info)
  {
    T->right = insert(T->right, x);
    return (T);
  }
  else
    printf("\\nDuplicate Value!!\\n");
  return (T);
}
NODE *copyt(NODE *root)
{
  NODE *newnode;
  if (root != NULL)
  {
    newnode = (NODE *)malloc(sizeof(NODE));
    newnode->info = root->info;
    newnode->left = copyt(root->left);
    newnode->right = copyt(root->right);
    return (newnode);
  }
  else
    return NULL;
}
void preorder(NODE *root2)
{
  if (root2 != NULL)
  {
    printf("%d\\t", root2->info);
    preorder(root2->left);
    preorder(root2->right);
  }
}
int comparebst(NODE *root1, NODE *root2)
{
  if (root1 == NULL && root2 == NULL)
    return 1;
  else if (root1 != NULL && root2 != NULL)
    if (root1->info == root2->info)
      if (comparebst(root1->left, root2->left))
        return comparebst(root1->right, root2->right);
  return 0;
}""",
            "Q2.c": """#include <stdio.h>
int main()
{
  int a[10][10], i, j, n;

  printf("\\nEnter total no. of vertex: ");
  scanf("%d", &n);

  for (i = 0; i < n; i++)
  {
    for (j = 0; j < n; j++)
    {
      a[i][j] = 0;
      if (i != j)
      {
        printf("\\nIs there edge between %d & %d: ", i + 1, j + 1);
        scanf("%d", &a[i][j]);
      }
    }
  }
  // Display
  printf("\\n Matrix is \\n");
  for (i = 0; i < n; i++)
  {
    for (j = 0; j < n; j++)
    {
      printf("%d\\t", a[i][j]);
    }
    printf("\\n");
  }
}"""
        }
    },
    {
        "slipNo": 14,
        "questions": [
            {
                "question": " ",
                "filenames": ["Q1.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "Q1.c": """#include <stdio.h>
#include <stdlib.h>

typedef struct node {
    int vertex;
    struct node *next;
} NODE;

NODE *list[10];

void create(int a[10][10], int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            a[i][j] = 0;
            if (i != j) {
                printf("\\nIs there edge between %d & %d: ", i + 1, j + 1);
                scanf("%d", &a[i][j]);
            }
        }
    }
}

void clist(int a[10][10], int n) {
    NODE *temp, *newnode;
    for (int i = 0; i < n; i++) {
        list[i] = NULL;
        for (int j = 0; j < n; j++) {
            if (a[i][j] == 1) {
                newnode = (NODE *)malloc(sizeof(NODE));
                newnode->vertex = j + 1;
                newnode->next = NULL;
                if (list[i] == NULL)
                    list[i] = temp = newnode;
                else {
                    temp->next = newnode;
                    temp = newnode;
                }
            }
        }
    }
}

void dlist(int n) {
    NODE *temp;
    printf("\\nThe Adjacency list is:\\n");
    for (int i = 0; i < n; i++) {
        printf("v%d --> ", i + 1);
        temp = list[i];
        while (temp) {
            printf("v%d --> ", temp->vertex);
            temp = temp->next;
        }
        printf("NULL\\n");
    }
}

int main() {
    int a[10][10], n, i, j, in, out;

    printf("\\nEnter the no. of vertex: ");
    scanf("%d", &n);

    create(a, n);
    clist(a, n);
    dlist(n);

    printf("Vertex   In-degree   Out-degree\\n");

    for (i = 0; i < n; i++) {
        in = out = 0;
        for (j = 0; j < n; j++) {
            in += a[j][i];
            out += a[i][j]; // Count outgoing edges
        }
        printf("%3d%14d%10d\\n", i + 1, in, out);
    }

    return 0;
}""",
            "Q2.c": """#include <stdio.h>
#include <stdlib.h>
typedef struct bst
{
    int data;
    struct bst *lchild, *rchild;
} node;
int cnt = 0, leafcnt = 0, nleafcnt = 0;
struct bst *create()
{
    struct bst *temp = (struct bst *)malloc(sizeof(struct bst));
    temp->lchild = NULL;
    temp->rchild = NULL;
    return temp;
}

void insert(struct bst *r, struct bst *new1)
{

    if (new1->data < r->data)
    {

        if (r->lchild == NULL)
            r->lchild = new1;
        else
            insert(r->lchild, new1);
    }
    if (new1->data > r->data)
    {

        if (r->rchild == NULL)
            r->rchild = new1;
        else
            insert(r->rchild, new1);
    }
}

int count(struct bst *temp)
{

    if (temp != NULL)
    {

        cnt++;
        count(temp->lchild);
        count(temp->rchild);
    }
    return cnt;
}

int main()
{
    int ch, n, i, value, cnt;
    struct bst *newnode, *root, *temp;
    root = NULL;
    while (1)
    {
        printf("\\n------Binary Search Tree------\\n");

        printf("1.Insert\\n");
        printf("2.Count Total Nodes\\n");
        printf("3.Exit\\n");
        printf("Enter your choice:");
        scanf("%d", &ch);
        switch (ch)
        {
        case 1:
            printf("\\n How many nodes to create:");
            scanf("%d", &n);
            for (i = 0; i < n; i++)
            {
                newnode = create();
                printf("\\nEnter the node data:");
                scanf("%d", &newnode->data);
                if (root == NULL)
                    root = newnode;
                else
                    insert(root, newnode);
            }
            break;
        case 2:
            cnt = count(root);
            printf("\\n Total number of nodes =%d\\n", cnt);
            break;

        case 3:
            exit(0);
        default:
            printf("\\nInvalid Choice\\n");
        }
    }
}"""
        }
    },
    {
        "slipNo": 15,
        "questions": [
            {
                "question": " ",
                "filenames": ["Q1.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "Q1.c": """#include <stdio.h>
#include <stdlib.h>
#define TABLE_SIZE 10

int h[TABLE_SIZE];

void initTable() {
    for (int i = 0; i < TABLE_SIZE; i++) {
        h[i] = -1; // -1 indicates empty slot
    }
}

void insert() {
    int key, index, i, hkey;
    printf("\\nEnter a value to insert into hash table: ");
    scanf("%d", &key);

    hkey = key % TABLE_SIZE;
    for (i = 0; i < TABLE_SIZE; i++) {
        index = (hkey + i) % TABLE_SIZE;
        if (h[index] == -1) {
            h[index] = key;
            printf("Inserted %d at index %d\\n", key, index);
            break;
        }
    }
    if (i == TABLE_SIZE)
        printf("\\nElement cannot be inserted (table full)\\n");
}

void search() {
    int key, index, i, hkey;
    printf("\\nEnter search element: ");
    scanf("%d", &key);

    hkey = key % TABLE_SIZE;
    for (i = 0; i < TABLE_SIZE; i++) {
        index = (hkey + i) % TABLE_SIZE;
        if (h[index] == key) {
            printf("Value %d is found at index %d\\n", key, index);
            break;
        }
    }
    if (i == TABLE_SIZE)
        printf("\\nValue not found\\n");
}

void display() {
    printf("\\nElements in the hash table are:\\n");
    for (int i = 0; i < TABLE_SIZE; i++) {
        printf("Index %d -> %d\\n", i, h[i]);
    }
}

int main() {
    int opt;
    initTable(); // initialize with -1 (empty)

    while (1) {
        printf("\\nPress 1. Insert\\n 2. Display\\n 3. Search\\n 4. Exit\\n");
        scanf("%d", &opt);

        switch (opt) {
        case 1: insert(); break;
        case 2: display(); break;
        case 3: search(); break;
        case 4: exit(0);
        default: printf("Invalid option!\\n");
        }
    }
    return 0;
}
""",
            "Q2.c": """#include <stdio.h>
#include <stdlib.h>
typedef struct bst
{
    int data;
    struct bst *lchild, *rchild;
} node;
int cnt = 0, leafcnt = 0, nleafcnt = 0;
struct bst *create()
{
    struct bst *temp = (struct bst *)malloc(sizeof(struct bst));
    temp->lchild = NULL;
    temp->rchild = NULL;
    return temp;
}

void insert(struct bst *r, struct bst *new1)
{

    if (new1->data < r->data)
    {

        if (r->lchild == NULL)
            r->lchild = new1;
        else
            insert(r->lchild, new1);
    }
    if (new1->data > r->data)
    {

        if (r->rchild == NULL)
            r->rchild = new1;
        else
            insert(r->rchild, new1);
    }
}

int count(struct bst *temp)
{

    if (temp != NULL)
    {

        cnt++;
        count(temp->lchild);
        count(temp->rchild);
    }
    return cnt;
}

int main()
{
    int ch, n, i, value, cnt;
    struct bst *newnode, *root, *temp;
    root = NULL;
    while (1)
    {
        printf("\\n------Binary Search Tree------\\n");

        printf("1.Insert\\n");
        printf("2.Count Total Nodes\\n");
        printf("3.Exit\\n");
        printf("Enter your choice:");
        scanf("%d", &ch);
        switch (ch)
        {
        case 1:
            printf("\\n How many nodes to create:");
            scanf("%d", &n);
            for (i = 0; i < n; i++)
            {
                newnode = create();
                printf("\\nEnter the node data:");
                scanf("%d", &newnode->data);
                if (root == NULL)
                    root = newnode;
                else
                    insert(root, newnode);
            }
            break;
        case 2:
            cnt = count(root);
            printf("\\n Total number of nodes =%d\\n", cnt);
            break;

        case 3:
            exit(0);
        default:
            printf("\\nInvalid Choice\\n");
        }
    }
}"""
        }
    },
    {
        "slipNo": 16,
        "questions": [
            {
                "question": " ",
                "filenames": ["Q1.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "Q1.c": """#include <stdio.h>
#include <stdlib.h>
#define MAXSIZE 20
typedef struct
{
    int data[MAXSIZE];
    int front, rear;
} QUEUE;
void initq(QUEUE *pq)
{
    pq->front = pq->rear = -1;
}
void addq(QUEUE *pq, int n)
{
    pq->data[++pq->rear] = n;
}
int removeq(QUEUE *pq)
{
    return pq->data[++pq->front];
}
int isempty(QUEUE *pq)
{
    return (pq->front == pq->rear);
}
void create(int a[10][10], int n)
{
    printf("\\nType 1 for Yes and 0 for No\\n");
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            a[i][j] = 0;
            if (i != j)
            {
                printf("\\n Is there edge between %d and %d:", i + 1, j + 1);
                scanf("%d", &a[i][j]);
            }
        }
    }
}
void bfs(int a[10][10], int n)
{
    int v = 0;
    int visited[20] = {0};
    QUEUE q;
    initq(&q);
    printf("\\nThe breadth first traversal is:\\n");
    visited[v] = 1;
    addq(&q, v);
    while (!isempty(&q))
    {
        v = removeq(&q);
        printf("v%d\\t", v + 1);
        for (int w = 0; w < n; w++)
        {
            if ((a[v][w] == 1) && (visited[w] == 0))
            {
                addq(&q, w);
                visited[w] = 1;
            }
        }
    }
}
int main()
{
    int a[10][10], n;
    printf("\\nEnter the no of vertex:");
    scanf("%d", &n);
    create(a, n);
    bfs(a, n);
}""",
            "Q2.c": """#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node *left;
    struct Node *right;
} Node;

Node *createNode(int data);
Node *insert(Node *root, int data);
void preorder(Node *root);

Node *createNode(int data) {
    Node *newNode = (Node *)malloc(sizeof(Node));
    newNode->data = data;
    newNode->left = NULL;
    newNode->right = NULL;
    return newNode;
}

Node *insert(Node *root, int data) {
    if (root == NULL) {
        return createNode(data);
    }
    if (data < root->data) {
        root->left = insert(root->left, data);
    } else if (data > root->data) {
        root->right = insert(root->right, data);
    }
    return root;
}

void preorder(Node *root) {
    if (root != NULL) {
        printf("%d ", root->data);
        preorder(root->left);
        preorder(root->right);
    }
}

int main() {
    Node *root = NULL;
    int choice, data;

    while (1) {
        printf("\\nMenu:\\n");
        printf("1. Insert\\n");
        printf("2. Preorder Traversal\\n");
        printf("3. Exit\\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter the data to insert: ");
                scanf("%d", &data);
                root = insert(root, data);
                break;
            case 2:
                printf("Preorder Traversal: ");
                preorder(root);
                printf("\\n");
                break;
            case 3:
                exit(0);
            default:
                printf("Invalid choice! Please try again.\\n");
        }
    }
    return 0;
}
"""
        }
    },
    {
        "slipNo": 17,
        "questions": [
            {
                "question": " ",
                "filenames": ["Q1.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "Q1.c": """#include <stdio.h>
#include <stdlib.h>
typedef struct bst
{
  int data;
  struct bst *lchild, *rchild;
} node;
int cnt = 0, leafcnt = 0, nleafcnt = 0;

struct bst *create()
{
  struct bst *temp = (struct bst *)malloc(sizeof(struct bst));
  temp->lchild = NULL;
  temp->rchild = NULL;
  return temp;
}

void insert(struct bst *r, struct bst *new1)
{
  if (new1->data < r->data)
  {
    if (r->lchild == NULL)
      r->lchild = new1;
    else
      insert(r->lchild, new1);
  }
  if (new1->data > r->data)
  {
    if (r->rchild == NULL)
      r->rchild = new1;
    else
      insert(r->rchild, new1);
  }
}
int count(struct bst *temp)
{
  if (temp != NULL)
  {
    cnt++;
    count(temp->lchild);
    count(temp->rchild);
  }
  return cnt;
}

int countleaf(struct bst *temp)
{
  if (temp != NULL)
  {
    if ((temp->lchild == NULL) && (temp->rchild == NULL))
      leafcnt++;
    countleaf(temp->lchild);
    countleaf(temp->rchild);
  }
  return leafcnt;
}
int countnleaf(struct bst *temp)
{

  if (temp != NULL)
  {

    if ((temp->lchild != NULL) || (temp->rchild != NULL))
      nleafcnt++;
    countnleaf(temp->lchild);
    countnleaf(temp->rchild);
  }
  return nleafcnt;
}
int main()
{
  int ch, n, i, value, cnt;
  struct bst *newnode, *root, *temp;
  root = NULL;
  while (1)
  {
    printf("\\n------Binary Search Tree------\\n");
    printf("1.Insert\\n");
    printf("2.Count Total Nodes\\n");
    printf("3.Count Leaf Nodes\\n");
    printf("4.Count Non Leaf Nodes\\n");
    printf("5.Exit\\n");
    printf("Enter your choice:");
    scanf("%d", &ch);
    switch (ch)
    {
    case 1:
      printf("\\n How many nodes to create:");
      scanf("%d", &n);
      for (i = 0; i < n; i++)
      {
        newnode = create();
        printf("\\nEnter the node data:");
        scanf("%d", &newnode->data);
        if (root == NULL)
          root = newnode;
        else
          insert(root, newnode);
      }
      break;
    case 2:
      cnt = count(root);
      printf("\\n Total number of nodes =%d\\n", cnt);
      break;
    case 3:
      cnt = countleaf(root);
      printf("\\n Total number of  leaf node=%d\\n", cnt);
      break;
    case 4:
      cnt = countnleaf(root);
      printf("\\n Total number of non leaf node=%d\\n", cnt);
      break;
    case 5:
      exit(0);
    default:
      printf("\\nInvalid Choice\\n");
    }
  }
}""",
            "Q2.c": """#include <stdio.h>
int main()
{
  int a[10][10], i, j, n;

  printf("\\nEnter total no. of vertex: ");
  scanf("%d", &n);

  for (i = 0; i < n; i++)
  {
    for (j = 0; j < n; j++)
    {
      a[i][j] = 0;
      if (i != j)
      {
        printf("\\nIs there edge between %d & %d: ", i + 1, j + 1);
        scanf("%d", &a[i][j]);
      }
    }
  }

  printf("\\n Matrix is \\n");
  for (i = 0; i < n; i++)
  {
    for (j = 0; j < n; j++)
    {
      printf("%d\\t", a[i][j]);
    }
    printf("\\n");
  }
}"""
        }
    },
    {
        "slipNo": 18,
        "questions": [
            {
                "question": " ",
                "filenames": ["Q1.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "Q1.c": """#include <stdio.h>
#include <stdlib.h>
typedef struct bst
{
    int data;
    struct bst *lchild, *rchild;
} node;
int cnt = 0, leafcnt = 0, nleafcnt = 0;

struct bst *create()
{
    struct bst *temp = (struct bst *)malloc(sizeof(struct bst));
    temp->lchild = NULL;
    temp->rchild = NULL;
    return temp;
}

void insert(struct bst *r, struct bst *new1)
{
    if (new1->data < r->data)
    {
        if (r->lchild == NULL)
            r->lchild = new1;
        else
            insert(r->lchild, new1);
    }
    if (new1->data > r->data)
    {
        if (r->rchild == NULL)
            r->rchild = new1;
        else
            insert(r->rchild, new1);
    }
}
int count(struct bst *temp)
{
    if (temp != NULL)
    {
        cnt++;
        count(temp->lchild);
        count(temp->rchild);
    }
    return cnt;
}

int countleaf(struct bst *temp)
{
    if (temp != NULL)
    {
        if ((temp->lchild == NULL) && (temp->rchild == NULL))
            leafcnt++;
        countleaf(temp->lchild);
        countleaf(temp->rchild);
    }
    return leafcnt;
}
int countnleaf(struct bst *temp)
{

    if (temp != NULL)
    {

        if ((temp->lchild != NULL) || (temp->rchild != NULL))
            nleafcnt++;
        countnleaf(temp->lchild);
        countnleaf(temp->rchild);
    }
    return nleafcnt;
}
int main()
{
    int ch, n, i, value, cnt;
    struct bst *newnode, *root, *temp;
    root = NULL;
    while (1)
    {
        printf("\\n------Binary Search Tree------\\n");
        printf("1.Insert\\n");
        printf("2.Count Total Nodes\\n");
        printf("3.Count Leaf Nodes\\n");
        printf("4.Count Non Leaf Nodes\\n");
        printf("5.Exit\\n");
        printf("Enter your choice:");
        scanf("%d", &ch);
        switch (ch)
        {
        case 1:
            printf("\\n How many nodes to create:");
            scanf("%d", &n);
            for (i = 0; i < n; i++)
            {
                newnode = create();
                printf("\\nEnter the node data:");
                scanf("%d", &newnode->data);
                if (root == NULL)
                    root = newnode;
                else
                    insert(root, newnode);
            }
            break;
        case 2:
            cnt = count(root);
            printf("\\n Total number of nodes =%d\\n", cnt);
            break;
        case 3:
            cnt = countleaf(root);
            printf("\\n Total number of  leaf node=%d\\n", cnt);
            break;
        case 4:
            cnt = countnleaf(root);
            printf("\\n Total number of non leaf node=%d\\n", cnt);
            break;
        case 5:
            exit(0);
        default:
            printf("\\nInvalid Choice\\n");
        }
    }
}""",
            "Q2.c": """#include <stdio.h>

#define MAX 100

int adj[MAX][MAX];
int vertices;

void initialize()
{
    for (int i = 0; i < vertices; i++)
    {
        for (int j = 0; j < vertices; j++)
        {
            adj[i][j] = 0;
        }
    }
}

void addEdge(int src, int dest)
{
    adj[src][dest] = 1;
}

void displayMatrix()
{
    for (int i = 0; i < vertices; i++)
    {
        for (int j = 0; j < vertices; j++)
        {
            printf("%d ", adj[i][j]);
        }
        printf("\\n");
    }
}

void printIndegree()
{
    for (int i = 0; i < vertices; i++)
    {
        int indegree = 0;
        for (int j = 0; j < vertices; j++)
        {
            if (adj[j][i] == 1)
            {
                indegree++;
            }
        }
        printf("Vertex %d: Indegree = %d\\n", i, indegree);
    }
}

int main()
{
    int edges, src, dest;

    printf("Enter number of vertices: ");
    scanf("%d", &vertices);

    initialize();

    printf("Enter number of edges: ");
    scanf("%d", &edges);

    for (int i = 0; i < edges; i++)
    {
        printf("Enter edge (source destination): ");
        scanf("%d %d", &src, &dest);
        addEdge(src, dest);
    }

    displayMatrix();

    printIndegree();

    return 0;
}"""
        }
    },
    {
        "slipNo": 19,
        "questions": [
            {
                "question": " ",
                "filenames": ["Q1.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "Q1.c": """#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
    int vertex;
    struct node *next;
} NODE;

NODE *list[10];

void create(int a[10][10], int n)
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            a[i][j] = 0;
            if (i != j)
            {
                printf("\\nIs there edge between %d & %d: ", i + 1, j + 1);
                scanf("%d", &a[i][j]);
            }
        }
    }
}

void clist(int a[10][10], int n)
{
    NODE *temp, *newnode;
    for (int i = 0; i < n; i++)
    {
        list[i] = NULL;
        for (int j = 0; j < n; j++)
        {
            if (a[i][j] == 1)
            {
                newnode = (NODE *)malloc(sizeof(NODE));
                newnode->vertex = j + 1;
                newnode->next = NULL;
                if (list[i] == NULL)
                    list[i] = temp = newnode;
                else
                {
                    temp->next = newnode;
                    temp = newnode;
                }
            }
        }
    }
}

void dlist(int n)
{
    NODE *temp;
    printf("\\nThe Adjacency list is:\\n");
    for (int i = 0; i < n; i++)
    {
        printf("v%d --> ", i + 1);
        temp = list[i];
        while (temp)
        {
            printf("v%d --> ", temp->vertex);
            temp = temp->next;
        }
        printf("NULL\\n");
    }
}

int main()
{
    int a[10][10], n, i, j, in, out;

    printf("\\nEnter the no. of vertex: ");
    scanf("%d", &n);

    create(a, n);
    clist(a, n);
    dlist(n);

    printf("Vertex   In-degree   Out-degree\\n");

    for (i = 0; i < n; i++)
    {
        in = out = 0;
        for (j = 0; j < n; j++)
        {
            in += a[j][i];
            out += a[i][j]; // Count outgoing edges
        }
        printf("%3d%14d%10d\\n", i + 1, in, out);
    }

    return 0;
}""",
            "Q2.c": """#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node *left;
    struct Node *right;
} Node;

Node *createNode(int data);
Node *insert(Node *root, int data);
void preorder(Node *root);

Node *createNode(int data) {
    Node *newNode = (Node *)malloc(sizeof(Node));
    newNode->data = data;
    newNode->left = NULL;
    newNode->right = NULL;
    return newNode;
}

Node *insert(Node *root, int data) {
    if (root == NULL) {
        return createNode(data);
    }
    if (data < root->data) {
        root->left = insert(root->left, data);
    } else if (data > root->data) {
        root->right = insert(root->right, data);
    }
    return root;
}

void preorder(Node *root) {
    if (root != NULL) {
        printf("%d ", root->data);
        preorder(root->left);
        preorder(root->right);
    }
}

int main() {
    Node *root = NULL;
    int choice, data;

    while (1) {
        printf("\\nMenu:\\n");
        printf("1. Insert\\n");
        printf("2. Preorder Traversal\\n");
        printf("3. Exit\\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter the data to insert: ");
                scanf("%d", &data);
                root = insert(root, data);
                break;
            case 2:
                printf("Preorder Traversal: ");
                preorder(root);
                printf("\\n");
                break;
            case 3:
                exit(0);
            default:
                printf("Invalid choice! Please try again.\\n");
        }
    }

    return 0;
}
"""
        }
    },
    {
        "slipNo": 20,
        "questions": [
            {
                "question": " ",
                "filenames": ["Q1.c"]
            },
            {
                "question": " ",
                "filenames": ["btree.h"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "Q1.c": """#include <stdio.h>
#include <stdlib.h>
#include "btree.h"
int main()
{
    int ch, n, i, value, cnt;
    struct bst *newnode, *root, *temp;
    root = NULL;
    while (1)
    {
        printf("\\n---Binary Search Tree---\\n");
        printf("1.Insert\\n");
        printf("2.Inorder Traversal (Recursive)\\n");
        printf("3.Exit\\n");
        printf("Enter your choice:");
        scanf("%d", &ch);
        switch (ch)
        {
        case 1:
            printf("\\nHow many nodes to create:");
            scanf("%d", &n);
            for (i = 0; i < n; i++)
            {
                newnode = create();
                printf("\\nEnter the node data:");
                scanf("%d", &newnode->data);
                if (root == NULL)
                    root = newnode;
                else
                    insert(root, newnode);
            }
            break;
        case 2:
            printf("\\nInorder Traversal=");
            inorder(root);
            break;
        case 3:
            exit(0);
        default:
            printf("\\nInvalid Choice\\n");
        }
    }
}""",
            "btree.h": """#include <stdio.h>
#include <stdlib.h>

struct bst
{
    int data;
    struct bst *lchild, *rchild;
} node;
int cnt = 0, leafcnt = 0, nleafcnt = 0;

struct bst *create()
{
    struct bst *temp = (struct bst *)malloc(sizeof(struct bst));
    temp->lchild = NULL;
    temp->rchild = NULL;
    return temp;
}

void insert(struct bst *r, struct bst *new1)
{

    if (new1->data < r->data)
    {
        if (r->lchild == NULL)
            r->lchild = new1;
        else
            insert(r->lchild, new1);
    }

    if (new1->data > r->data)
    {
        if (r->rchild == NULL)
            r->rchild = new1;
        else
            insert(r->rchild, new1);
    }
}
void inorder(struct bst *temp)
{
    if (temp != NULL)
    {
        inorder(temp->lchild);
        printf("%d\\t", temp->data);
        inorder(temp->rchild);
    }
}""",
            "Q2.c": """#include <stdio.h>

#define MAX 100

int adj[MAX][MAX];
int vertices;

void initialize()
{
    for (int i = 0; i < vertices; i++)
    {
        for (int j = 0; j < vertices; j++)
        {
            adj[i][j] = 0;
        }
    }
}

void addEdge(int src, int dest)
{
    adj[src][dest] = 1;
}

void displayMatrix()
{
    for (int i = 0; i < vertices; i++)
    {
        for (int j = 0; j < vertices; j++)
        {
            printf("%d ", adj[i][j]);
        }
        printf("\\n");
    }
}

void printIndegree()
{
    for (int i = 0; i < vertices; i++)
    {
        int indegree = 0;
        for (int j = 0; j < vertices; j++)
        {
            if (adj[j][i] == 1)
            {
                indegree++;
            }
        }
        printf("Vertex %d: Indegree = %d\\n", i, indegree);
    }
}

int main()
{
    int edges, src, dest;

    printf("Enter number of vertices: ");
    scanf("%d", &vertices);

    initialize();

    printf("Enter number of edges: ");
    scanf("%d", &edges);

    for (int i = 0; i < edges; i++)
    {
        printf("Enter edge (source destination): ");
        scanf("%d %d", &src, &dest);
        addEdge(src, dest);
    }
    displayMatrix();
    printIndegree();
    return 0;
}"""
        }
    },
    {
        "slipNo": 21,
        "questions": [
            {
                "question": " ",
                "filenames": ["Q1.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "Q1.c": """#include <stdio.h>
#include <stdlib.h>

#define MAX 100

int adjMatrix[MAX][MAX];
int visited[MAX];
int numVertices;

void initialize()
{
    for (int i = 0; i < MAX; i++)
    {
        for (int j = 0; j < MAX; j++)
        {
            adjMatrix[i][j] = 0;
        }
        visited[i] = 0;
    }
}

void addEdge(int u, int v)
{
    adjMatrix[u][v] = 1;
    adjMatrix[v][u] = 1;
}

void DFS(int vertex)
{
    printf("%d ", vertex);
    visited[vertex] = 1;

    for (int i = 0; i < numVertices; i++)
    {
        if (adjMatrix[vertex][i] == 1 && !visited[i])
        {
            DFS(i);
        }
    }
}

int main()
{
    int numEdges, u, v;

    printf("Enter the number of vertices: ");
    scanf("%d", &numVertices);

    printf("Enter the number of edges: ");
    scanf("%d", &numEdges);

    initialize();

    printf("Enter the edges (u v):\\n");
    for (int i = 0; i < numEdges; i++)
    {
        scanf("%d %d", &u, &v);
        addEdge(u, v);
    }

    printf("Adjacency Matrix:\\n");
    for (int i = 0; i < numVertices; i++)
    {
        for (int j = 0; j < numVertices; j++)
        {
            printf("%d ", adjMatrix[i][j]);
        }
        printf("\\n");
    }
    printf("DFS Traversal starting from vertex 0:\\n");
    DFS(0);
    return 0;
}""",
            "Q2.c": """#include <stdio.h>
#include <stdlib.h>
#define MAX 10
void dijkstra(int G[MAX][MAX], int n, int startnode);
int main()
{
    int G[MAX][MAX], i, j, n, u;
    printf("enter no. of vertices:");
    scanf("%d", &n);
    printf("\\nenter the adjacency matrix:\\n");
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
            scanf("%d", &G[i][j]);
    printf("\\nenter the starting node:");
    scanf("%d", &u);
    dijkstra(G, n, u);
    return 0;
}
void dijkstra(int G[MAX][MAX], int n, int startnode)
{
    int cost[MAX][MAX], distance[MAX], pred[MAX];
    int visited[MAX], count, mindistance, nextnode, i, j;
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
            if (G[i][j] == 0)
                cost[i][j] = 999;
            else
                cost[i][j] = G[i][j];
    for (i = 0; i < n; i++)
    {
        distance[i] = cost[startnode][i];
        pred[i] = startnode;
        visited[i] = 0;
    }
    distance[startnode] = 0;
    visited[startnode] = 1;
    count = 1;
    while (count < n - 1)
    {
        mindistance = 999;
        for (i = 0; i < n; i++)
            if (distance[i] < mindistance && !visited[i])
            {
                mindistance = distance[i];
                nextnode = i;
            }
        visited[nextnode] = 1;
        for (i = 0; i < n; i++)
            if (!visited[i])
                if (mindistance + cost[nextnode][i] < distance[i])
                {
                    distance[i] = mindistance + cost[nextnode][i];
                    pred[i] = nextnode;
                }
        count++;
    }
    for (i = 0; i < n; i++)
        if (i != startnode)
        {
            printf("\\n distance of node%d=%d", i, distance[i]);
            printf("\\n Path=%d", i);
            j = i;
            do
            {
                j = pred[j];
                printf("<-%d", j);
            } while (j != startnode);
        }
}"""
        }
    },
    {
        "slipNo": 22,
        "questions": [
            {
                "question": " ",
                "filenames": ["Q1.c"]
            },
            {
                "question": " ",
                "filenames": ["btree.h"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "Q1.c": """#include<stdio.h>
#include<stdlib.h>
#include "btree.h"
int main()
{
    int ch,n,i,value,cnt;
    struct bst *newnode,*root,*temp;
    root=NULL;
    while(1)
    {
        printf("\\n---Binary Search Tree---\\n");
        printf("1.Insert\\n");
        printf("2.postorder Traversal (Recursive)\\n");
        printf("3.Exit\\n");
        printf("Enter your choice:");
        scanf("%d",&ch);
        switch(ch)
        {
                    case 1:printf("\\nHow many nodes to create:");
                        scanf("%d",&n);
                        for(i=0;i<n;i++)
                    {
                 		  newnode=create();
                        printf("\\nEnter the node data:");
                        scanf("%d",&newnode->data);
                        if(root==NULL)
                            root=newnode;
                        else
                            insert(root,newnode);
                    }
                    break;
            case 2:      printf("\\npostorder Traversal=");
                    postorder(root);
                    break;
            case 3: exit(0);
            default: printf("\\nInvalid Choice\\n");
        }
    }
}""",
            "btree.h": """#include<stdio.h>
#include<stdlib.h>

struct bst
{
    int data;
    struct bst *lchild,*rchild;
}node;
int cnt=0,leafcnt=0,nleafcnt=0;

struct bst *create()
{
    struct bst *temp=(struct bst*)malloc(sizeof(struct bst));
    temp->lchild=NULL;
    temp->rchild=NULL;
    return temp;
}

void insert(struct bst *r, struct bst *new1)
{

    if(new1->data < r->data)
    {
        if(r->lchild==NULL)
            r->lchild=new1;
        else
            insert(r->lchild,new1);
    }

    if(new1->data > r->data)
    {
        if(r->rchild==NULL)
            r->rchild=new1;
        else
            insert(r->rchild,new1);
    }
}
void postorder(struct bst *temp)
{
    if(temp!=NULL)
    {
        postorder(temp->lchild);
        postorder(temp->rchild);
        printf("%d\\t",temp->data);
    }
}""",
            "Q2.c": """#include <stdio.h>
#include <stdlib.h>
#define TABLE_SIZE 10

int h[TABLE_SIZE];

void initTable() {
    for (int i = 0; i < TABLE_SIZE; i++) {
        h[i] = -1;
    }
}

void insert() {
    int key, index, i, hkey;
    printf("\\nEnter a value to insert into hash table: ");
    scanf("%d", &key);

    hkey = key % TABLE_SIZE;
    for (i = 0; i < TABLE_SIZE; i++) {
        index = (hkey + i) % TABLE_SIZE;
        if (h[index] == -1) {
            h[index] = key;
            printf("Inserted %d at index %d\\n", key, index);
            break;
        }
    }
    if (i == TABLE_SIZE)
        printf("\\nElement cannot be inserted (table full)\\n");
}

void search() {
    int key, index, i, hkey;
    printf("\\nEnter search element: ");
    scanf("%d", &key);

    hkey = key % TABLE_SIZE;
    for (i = 0; i < TABLE_SIZE; i++) {
        index = (hkey + i) % TABLE_SIZE;
        if (h[index] == key) {
            printf("Value %d is found at index %d\\n", key, index);
            break;
        }
    }
    if (i == TABLE_SIZE)
        printf("\\nValue not found\\n");
}

void display() {
    printf("\\nElements in the hash table are:\\n");
    for (int i = 0; i < TABLE_SIZE; i++) {
        printf("Index %d -> %d\\n", i, h[i]);
    }
}

int main() {
    int opt;
    initTable(); // initialize with -1 (empty)

    while (1) {
        printf("\\nPress 1. Insert\\n 2. Display\\n 3. Search\\n 4. Exit\\n");
        scanf("%d", &opt);

        switch (opt) {
        case 1: insert(); break;
        case 2: display(); break;
        case 3: search(); break;
        case 4: exit(0);
        default: printf("Invalid option!\\n");
        }
    }
    return 0;
}
"""
        }
    },
    {
        "slipNo": 23,
        "questions": [
            {
                "question": " ",
                "filenames": ["Q1.c"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "Q1.c": """#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
    int vertex;
    struct node *next;
} NODE;

NODE *list[10];

void create(int a[10][10], int n)
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            a[i][j] = 0;
            if (i != j)
            {
                printf("\\nIs there edge between %d & %d: ", i + 1, j + 1);
                scanf("%d", &a[i][j]);
            }
        }
    }
}

void clist(int a[10][10], int n)
{
    NODE *temp, *newnode;
    for (int i = 0; i < n; i++)
    {
        list[i] = NULL;
        for (int j = 0; j < n; j++)
        {
            if (a[i][j] == 1)
            {
                newnode = (NODE *)malloc(sizeof(NODE));
                newnode->vertex = j + 1;
                newnode->next = NULL;
                if (list[i] == NULL)
                    list[i] = temp = newnode;
                else
                {
                    temp->next = newnode;
                    temp = newnode;
                }
            }
        }
    }
}

void dlist(int n)
{
    NODE *temp;
    printf("\\nThe Adjacency list is:\\n");
    for (int i = 0; i < n; i++)
    {
        printf("v%d --> ", i + 1);
        temp = list[i];
        while (temp)
        {
            printf("v%d --> ", temp->vertex);
            temp = temp->next;
        }
        printf("NULL\\n");
    }
}

int main()
{
    int a[10][10], n, i, j, in, out;

    printf("\\nEnter the no. of vertex: ");
    scanf("%d", &n);

    create(a, n);
    clist(a, n);
    dlist(n);

    printf("Vertex   In-degree   Out-degree\\n");

    for (i = 0; i < n; i++)
    {
        in = out = 0;
        for (j = 0; j < n; j++)
        {
            in += a[j][i];
            out += a[i][j];
        }
        printf("%3d%14d%10d\\n", i + 1, in, out);
    }
    return 0;
}""",
            "Q2.c": """#include <stdio.h>
#include <stdlib.h>
typedef struct bst
{
    int data;
    struct bst *lchild, *rchild;
} node;
int cnt = 0, leafcnt = 0, nleafcnt = 0;
struct bst *create()
{
    struct bst *temp = (struct bst *)malloc(sizeof(struct bst));
    temp->lchild = NULL;
    temp->rchild = NULL;
    return temp;
}

void insert(struct bst *r, struct bst *new1)
{

    if (new1->data < r->data)
    {

        if (r->lchild == NULL)
            r->lchild = new1;
        else
            insert(r->lchild, new1);
    }
    if (new1->data > r->data)
    {

        if (r->rchild == NULL)
            r->rchild = new1;
        else
            insert(r->rchild, new1);
    }
}

int count(struct bst *temp)
{

    if (temp != NULL)
    {

        cnt++;
        count(temp->lchild);
        count(temp->rchild);
    }
    return cnt;
}

int main()
{
    int ch, n, i, value, cnt;
    struct bst *newnode, *root, *temp;
    root = NULL;
    while (1)
    {
        printf("\\n------Binary Search Tree------\\n");

        printf("1.Insert\\n");
        printf("2.Count Total Nodes\\n");
        printf("3.Exit\\n");
        printf("Enter your choice:");
        scanf("%d", &ch);
        switch (ch)
        {
        case 1:
            printf("\\n How many nodes to create:");
            scanf("%d", &n);
            for (i = 0; i < n; i++)
            {
                newnode = create();
                printf("\\nEnter the node data:");
                scanf("%d", &newnode->data);
                if (root == NULL)
                    root = newnode;
                else
                    insert(root, newnode);
            }
            break;
        case 2:
            cnt = count(root);
            printf("\\n Total number of nodes =%d\\n", cnt);
            break;

        case 3:
            exit(0);
        default:
            printf("\\nInvalid Choice\\n");
        }
    }
}"""
        }
    },
    {
        "slipNo": 24,
        "questions": [
            {
                "question": " ",
                "filenames": ["Q1.c"]
            },
            {
                "question": " ",
                "filenames": ["btree.h"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "Q1.c": """#include <stdio.h>
#include <stdlib.h>
#include "btree.h"
int main()
{
    int ch, n, i, value, cnt;
    struct bst *newnode, *root, *temp;
    root = NULL;
    while (1)
    {
        printf("\\n---Binary Search Tree---\\n");
        printf("1.Insert\\n");
        printf("2.postorder Traversal (Recursive)\\n");
        printf("3.Exit\\n");
        printf("Enter your choice:");
        scanf("%d", &ch);
        switch (ch)
        {
        case 1:
            printf("\\nHow many nodes to create:");
            scanf("%d", &n);
            for (i = 0; i < n; i++)
            {
                newnode = create();
                printf("\\nEnter the node data:");
                scanf("%d", &newnode->data);
                if (root == NULL)
                    root = newnode;
                else
                    insert(root, newnode);
            }
            break;
        case 2:
            printf("\\npostorder Traversal=");
            postorder(root);
            break;
        case 3:
            exit(0);
        default:
            printf("\\nInvalid Choice\\n");
        }
    }
}""",
            "btree.h": """#include <stdio.h>
#include <stdlib.h>

struct bst
{
    int data;
    struct bst *lchild, *rchild;
} node;
int cnt = 0, leafcnt = 0, nleafcnt = 0;

struct bst *create()
{
    struct bst *temp = (struct bst *)malloc(sizeof(struct bst));
    temp->lchild = NULL;
    temp->rchild = NULL;
    return temp;
}

void insert(struct bst *r, struct bst *new1)
{

    if (new1->data < r->data)
    {
        if (r->lchild == NULL)
            r->lchild = new1;
        else
            insert(r->lchild, new1);
    }

    if (new1->data > r->data)
    {
        if (r->rchild == NULL)
            r->rchild = new1;
        else
            insert(r->rchild, new1);
    }
}
void postorder(struct bst *temp)
{
    if (temp != NULL)
    {
        postorder(temp->lchild);
        postorder(temp->rchild);
        printf("%d\\t", temp->data);
    }
}""",
            "Q2.c": """#include <stdio.h>
#include <stdlib.h>
#define MAXSIZE 20
typedef struct
{
    int data[MAXSIZE];
    int front, rear;
} QUEUE;
void initq(QUEUE *pq)
{
    pq->front = pq->rear = -1;
}
void addq(QUEUE *pq, int n)
{
    pq->data[++pq->rear] = n;
}
int removeq(QUEUE *pq)
{
    return pq->data[++pq->front];
}
int isempty(QUEUE *pq)
{
    return (pq->front == pq->rear);
}
void create(int a[10][10], int n)
{
    printf("\\nType 1 for Yes and 0 for No\\n");
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            a[i][j] = 0;
            if (i != j)
            {
                printf("\\n Is there edge between %d and %d:", i + 1, j + 1);
                scanf("%d", &a[i][j]);
            }
        }
    }
}
void bfs(int a[10][10], int n)
{
    int v = 0;
    int visited[20] = {0};
    QUEUE q;
    initq(&q);
    printf("\\nThe breadth first traversal is:\\n");
    visited[v] = 1;
    addq(&q, v);
    while (!isempty(&q))
    {
        v = removeq(&q);
        printf("v%d\\t", v + 1);
        for (int w = 0; w < n; w++)
        {
            if ((a[v][w] == 1) && (visited[w] == 0))
            {
                addq(&q, w);
                visited[w] = 1;
            }
        }
    }
}
int main()
{
    int a[10][10], n;
    printf("\\nEnter the no of vertex:");
    scanf("%d", &n);
    create(a, n);
    bfs(a, n);
}"""
        }
    },
    {
        "slipNo": 25,
        "questions": [
            {
                "question": " ",
                "filenames": ["Q1.c"]
            },
            {
                "question": " ",
                "filenames": ["btree.h"]
            },
            {
                "question": "",
                "filenames": ["Q2.c"]
            },
        ],
        "answers": {
            "Q1.c": """#include <stdio.h>
#include <stdlib.h>
#include "btree.h"
int main()
{
    int ch, n, i, value, cnt;
    struct bst *newnode, *root, *temp;
    root = NULL;
    while (1)
    {
        printf("\\n---Binary Search Tree---\\n");
        printf("1.Insert\\n");
        printf("2.Preorder Traversal (Recursive)\\n\\n");
        printf("3.Postorder Traversal (Recursive)\\n");
        printf("4.Exit\\n");
        printf("Enter your choice:");
        scanf("%d", &ch);
        switch (ch)
        {
        case 1:
            printf("\\nHow many nodes to create:");
            scanf("%d", &n);
            for (i = 0; i < n; i++)
            {
                newnode = create();
                printf("\\nEnter the node data:");
                scanf("%d", &newnode->data);
                if (root == NULL)
                    root = newnode;
                else
                    insert(root, newnode);
            }
            break;
        case 2:
            printf("\\nPreorder Traversal=");
            preorder(root);
            break;
        case 3:
            printf("\\nPostorder Traversal=");
            postorder(root);
            break;

        case 4:
            exit(0);
        default:
            printf("\\nInvalid Choice\\n");
        }
    }
}""",
            "btree.h": """#include <stdio.h>
#include <stdlib.h>

    struct bst
{
    int data;
    struct bst *lchild, *rchild;
} node;
int cnt = 0, leafcnt = 0, nleafcnt = 0;

struct bst *create()
{
    struct bst *temp = (struct bst *)malloc(sizeof(struct bst));
    temp->lchild = NULL;
    temp->rchild = NULL;
    return temp;
}

void insert(struct bst *r, struct bst *new1)
{

    if (new1->data < r->data)
    {
        if (r->lchild == NULL)
            r->lchild = new1;
        else
            insert(r->lchild, new1);
    }

    if (new1->data > r->data)
    {
        if (r->rchild == NULL)
            r->rchild = new1;
        else
            insert(r->rchild, new1);
    }
}
void postorder(struct bst *temp)
{
    if (temp != NULL)
    {
        postorder(temp->lchild);
        postorder(temp->rchild);
        printf("%d\\t", temp->data);
    }
}
void preorder(struct bst *temp)
{
    if (temp != NULL)
    {
        printf("%d\\t", temp->data);
        preorder(temp->lchild);
        preorder(temp->rchild);
    }
}""",
            "Q2.c": """#include <stdio.h>
#include <stdlib.h>
#define TABLE_SIZE 10

int h[TABLE_SIZE];

void initTable() {
    for (int i = 0; i < TABLE_SIZE; i++) {
        h[i] = -1; // -1 indicates empty slot
    }
}

void insert() {
    int key, index, i, hkey;
    printf("\\nEnter a value to insert into hash table: ");
    scanf("%d", &key);

    hkey = key % TABLE_SIZE;
    for (i = 0; i < TABLE_SIZE; i++) {
        index = (hkey + i) % TABLE_SIZE;
        if (h[index] == -1) {
            h[index] = key;
            printf("Inserted %d at index %d\\n", key, index);
            break;
        }
    }
    if (i == TABLE_SIZE)
        printf("\\nElement cannot be inserted (table full)\\n");
}

void search() {
    int key, index, i, hkey;
    printf("\\nEnter search element: ");
    scanf("%d", &key);

    hkey = key % TABLE_SIZE;
    for (i = 0; i < TABLE_SIZE; i++) {
        index = (hkey + i) % TABLE_SIZE;
        if (h[index] == key) {
            printf("Value %d is found at index %d\\n", key, index);
            break;
        }
    }
    if (i == TABLE_SIZE)
        printf("\\nValue not found\\n");
}

void display() {
    printf("\\nElements in the hash table are:\\n");
    for (int i = 0; i < TABLE_SIZE; i++) {
        printf("Index %d -> %d\\n", i, h[i]);
    }
}

int main() {
    int opt;
    initTable(); // initialize with -1 (empty)

    while (1) {
        printf("\\nPress 1. Insert\\n 2. Display\\n 3. Search\\n 4. Exit\\n");
        scanf("%d", &opt);

        switch (opt) {
        case 1: insert(); break;
        case 2: display(); break;
        case 3: search(); break;
        case 4: exit(0);
        default: printf("Invalid option!\\n");
        }
    }
    return 0;
}
"""
        }
    },
]