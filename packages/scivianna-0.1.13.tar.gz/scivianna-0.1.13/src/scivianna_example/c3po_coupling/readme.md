#   C3PO coupling example

This example shows how to display a C3PO coupling in real time using C3PO : https://github.com/code-coupling/c3po

Folder to be better documented and organised.