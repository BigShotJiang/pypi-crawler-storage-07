##   Mandelbrot example

In this example, a Mandelbrot set is computed on a regular 2D grid and converted to a set of polygons.

In scivianna, geometries can be provided either as a set of polygons or from a 2D grid, the API proposes to convert from one to the other
