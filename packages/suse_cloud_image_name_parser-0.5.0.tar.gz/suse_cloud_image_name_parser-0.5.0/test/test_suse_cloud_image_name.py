import pytest

from suse_cloud_image_name_parser.suse_cloud_image_name import (
    SUSECloudImageName
)

class TestSUSECloudImageName(object):

    def test_suse_cloud_image_name(self):

        test_cases = [
            (
                "021d1b90c82943ec959408cff8e26c37__suse-manager-server-5-0-byos-v20250729-x86_64",
                {
                    'is_x86_64': True,
                    'is_aarch64': False,
                    'is_arm64': False,
                    'is_amd64': True,
                    'is_leap': False,
                    'is_sle_server': False,
                    'is_sle': False,
                    'is_suma': True,
                    'suma_type': 'server',
                    'is_sap': False,
                    'is_byos': True,
                    'is_payg': False,
                    'is_tomcat': False,
                    'is_basic': False,
                    'product_major_int': 5,
                    'product_minor_int': 0,
                    'product_version': '5.0',
                    'distro_version': '5.5',
                    'has_uuid_prefix': True,
                    'is_chost': False,
                    'is_hardened': False,
                    'is_micro': False,
                    'is_ssd': False,
                    'is_ltd': None,
                    'is_llc': None
                }
            ),
            (
                "suse-sles-15-sp7-hardened-byos-v20250619-hvm-ssd-x86_64",
                {
                    'is_x86_64': True,
                    'is_aarch64': False,
                    'is_arm64': False,
                    'is_amd64': True,
                    'is_leap': False,
                    'is_sle_server': True,
                    'is_sle': False,
                    'is_suma': False,
                    'suma_type': None,
                    'is_sap': False,
                    'is_byos': True,
                    'is_payg': False,
                    'is_tomcat': False,
                    'is_basic': False,
                    'product_major_int': 15,
                    'product_minor_int': 7,
                    'product_version': '15-SP7',
                    'distro_version': '15-SP7',
                    'has_uuid_prefix': False,
                    'is_chost': False,
                    'is_hardened': True,
                    'is_micro': False,
                    'is_ssd': True,
                    'is_ltd': None,
                    'is_llc': None
                }
            ),
            (
                "suse-sle-micro-5-3-v20250724-hvm-ssd-arm64-ltd",
                {
                    'is_x86_64': False,
                    'is_aarch64': True,
                    'is_arm64': True,
                    'is_amd64': False,
                    'is_leap': False,
                    'is_sle_server': False,
                    'is_sle': True,
                    'is_suma': False,
                    'suma_type': None,
                    'is_sap': False,
                    'is_byos': False,
                    'is_payg': True,
                    'is_tomcat': False,
                    'is_basic': False,
                    'product_major_int': 5,
                    'product_minor_int': 3,
                    'product_version': '5.3',
                    'distro_version': '15-SP4',
                    'has_uuid_prefix': False,
                    'is_chost': False,
                    'is_hardened': False,
                    'is_micro': True,
                    'is_ssd': True,
                    'is_ltd': True,
                    'is_llc': False
                }
            ),
            (
                "suse-sles-16-0-chost-byos-v20250725-hvm-ssd-x86_64",
                {
                    'is_x86_64': True,
                    'is_aarch64': False,
                    'is_arm64': False,
                    'is_amd64': True,
                    'is_leap': False,
                    'is_sle_server': True,
                    'is_sle': False,
                    'is_suma': False,
                    'suma_type': None,
                    'is_sap': False,
                    'is_byos': True,
                    'is_payg': False,
                    'is_tomcat': False,
                    'is_basic': False,
                    'product_major_int': 16,
                    'product_minor_int': 0,
                    'product_version': '16.0',
                    'distro_version': '16.0',
                    'has_uuid_prefix': False,
                    'is_chost': True,
                    'is_hardened': False,
                    'is_micro': False,
                    'is_ssd': True,
                    'is_ltd': None,
                    'is_llc': None
                }
            ),
            (
                "openSUSE-Leap-15-6-v20250725-hvm-ssd-arm64",
                {
                    'is_x86_64': False,
                    'is_aarch64': True,
                    'is_arm64': True,
                    'is_amd64': False,
                    'is_leap': True,
                    'is_sle_server': False,
                    'is_sle': False,
                    'is_suma': False,
                    'suma_type': None,
                    'is_sap': False,
                    'is_byos': False,
                    'is_payg': False,
                    'is_tomcat': False,
                    'is_basic': False,
                    'product_major_int': 15,
                    'product_minor_int': 6,
                    'product_version': '15.6',
                    'distro_version': '15.6',
                    'has_uuid_prefix': False,
                    'is_chost': False,
                    'is_hardened': False,
                    'is_micro': False,
                    'is_ssd': True,
                    'is_ltd': None,
                    'is_llc': None
                }
            ),
            (
                "suse-sles-16-0-tomcat-v20250101-hvm-ssd-x86_64-llc",
                {
                    'is_x86_64': True,
                    'is_aarch64': False,
                    'is_arm64': False,
                    'is_amd64': True,
                    'is_leap': False,
                    'is_sle_server': True,
                    'is_sle': False,
                    'is_suma': False,
                    'suma_type': None,
                    'is_sap': False,
                    'is_byos': False,
                    'is_payg': True,
                    'is_tomcat': True,
                    'is_basic': False,
                    'product_major_int': 16,
                    'product_minor_int': 0,
                    'product_version': '16.0',
                    'distro_version': '16.0',
                    'has_uuid_prefix': False,
                    'is_chost': False,
                    'is_hardened': False,
                    'is_micro': False,
                    'is_ssd': True,
                    'is_ltd': False,
                    'is_llc': True
                }
            ),
        ]

        for (image, expected_result) in test_cases:
            image_name = SUSECloudImageName(image)
            for key, value in expected_result.items():
                assert getattr(image_name, key) == value
