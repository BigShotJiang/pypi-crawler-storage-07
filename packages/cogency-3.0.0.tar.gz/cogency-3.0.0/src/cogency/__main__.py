"""Module entry point for cogency CLI."""

from .cli import main

if __name__ == "__main__":
    main()
