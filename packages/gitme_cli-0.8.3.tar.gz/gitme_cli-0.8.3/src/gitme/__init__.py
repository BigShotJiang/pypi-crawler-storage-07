"""GitMe - Git commit message generator"""

__version__ = "0.8.3"