# Atomic Red Team MCP Server

An MCP (Model Context Protocol) server that provides access to Atomic Red Team tests.

## Installation

### Quick Start with uvx (Recommended)

The easiest way to run the Atomic Red Team MCP server is using `uvx`:

```bash
# Run directly without installation
uvx atomic-red-team-mcp

# Or install globally
uv tool install atomic-red-team-mcp
atomic-red-team-mcp
```

### Install from PyPI

```bash
# Using pip
pip install atomic-red-team-mcp

# Using uv
uv tool install atomic-red-team-mcp

# Using pipx
pipx install atomic-red-team-mcp
```

### Using Docker

```bash
# Run the pre-built Docker container
docker run --rm -i -e MCP_TRANSPORT=streamable-http ghcr.io/cyberbuff/atomic-red-team-mcp:latest
```

## Usage

The server provides the following MCP tools:

- `query_atomics` - Search atomics by technique ID, name, description, or platform
- `refresh_atomics` - Download latest atomics from GitHub
- `create_atomic_test` - Get guidance for creating new atomic tests
- `validate_atomic` - Validate atomic test YAML
- `get_validation_schema` - Get the atomic test schema

And resources:
- `file://documents/{technique_id}` - Read atomic test files by technique ID

## Integration with Development Tools

### Claude Desktop

Add to your Claude Desktop configuration file:

**macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
**Windows**: `%APPDATA%\Claude\claude_desktop_config.json`

#### Option 1: Using uvx (Recommended)
```json
{
  "mcpServers": {
    "atomic-red-team": {
      "command": "uvx",
      "args": ["atomic-red-team-mcp"]
    }
  }
}
```

#### Option 2: Using Docker
```json
{
  "mcpServers": {
    "atomic-red-team": {
      "command": "docker",
      "args": [
        "run", "--rm", "-i",
        "ghcr.io/cyberbuff/atomic-red-team-mcp:latest"
      ]
    }
  }
}
```

### Cursor

Add to your Cursor settings (`settings.json`):

#### Option 1: Using uvx (Recommended)
```json
{
  "mcpServers": {
    "atomic-red-team": {
      "command": "uvx",
      "args": ["atomic-red-team-mcp"]
    }
  }
}
```

#### Option 2: Using Docker
```json
{
  "mcpServers": {
    "atomic-red-team": {
      "command": "docker",
      "args": [
        "run", "--rm", "-i",
        "ghcr.io/cyberbuff/atomic-red-team-mcp:latest"
      ]
    }
  }
}
```

### Cline (VS Code Extension)

Add to your Cline extension settings or `.cline_mcp_config.json`:

#### Option 1: Using uvx (Recommended)
```json
{
  "mcpServers": {
    "atomic-red-team": {
      "command": "uvx",
      "args": ["atomic-red-team-mcp"]
    }
  }
}
```

#### Option 2: Using Docker
```json
{
  "mcpServers": {
    "atomic-red-team": {
      "command": "docker",
      "args": [
        "run", "--rm", "-i",
        "ghcr.io/cyberbuff/atomic-red-team-mcp:latest"
      ]
    }
  }
}
```

### Zed Editor

Add to your Zed settings (`settings.json`):

#### Option 1: Using uvx (Recommended)
```json
{
  "experimental": {
    "mcp": {
      "servers": {
        "atomic-red-team": {
          "command": "uvx",
          "args": ["atomic-red-team-mcp"]
        }
      }
    }
  }
}
```

#### Option 2: Using Docker
```json
{
  "experimental": {
    "mcp": {
      "servers": {
        "atomic-red-team": {
          "command": "docker",
          "args": [
            "run", "--rm", "-i",
            "ghcr.io/cyberbuff/atomic-red-team-mcp:latest"
          ]
        }
      }
    }
  }
}
```

### Generic MCP Client

For any MCP client that supports stdio transport:

#### Using uvx (Recommended)
```bash
uvx atomic-red-team-mcp
```

#### Using Docker
```bash
docker run --rm -i ghcr.io/cyberbuff/atomic-red-team-mcp:latest
```

### Docker

Run the pre-built Docker container:

```bash
docker run -d \
  --name atomic-red-team-mcp-server \
  -p 2786:8000 \
  ghcr.io/cyberbuff/atomic-red-team-mcp:latest
```

The MCP server will be available at: `http://localhost:2786/mcp`

## Docker Compose

Alternatively, use the included docker-compose.yaml:

```bash
# Clone the repository
git clone <repository-url>
cd atomic-red-team-mcp

# Start the server
docker-compose up -d
```

## Configuration

Environment variables:
- `MCP_TRANSPORT` - Transport protocol (stdio, sse, streamable-http)
- `MCP_HOST` - Host address to bind the server (default: 0.0.0.0)
- `MCP_PORT` - Port for HTTP transports (default: 8000)
- `GITHUB_URL` - GitHub URL for atomics repository (default: https://github.com)
- `GITHUB_USER` - GitHub user/org (default: redcanaryco)
- `GITHUB_REPO` - Repository name (default: atomic-red-team)
