"""
Atomic Red Team MCP Server

An MCP server that provides access to Atomic Red Team tests for security professionals.
"""

__version__ = "0.1.3"
__author__ = "cyberbuff"

from main import mcp

__all__ = ["mcp"]

