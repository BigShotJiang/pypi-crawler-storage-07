# -*- coding: utf-8 -*-

from .caster import kinesis_video_archived_media_caster

caster = kinesis_video_archived_media_caster

__version__ = "1.40.0"