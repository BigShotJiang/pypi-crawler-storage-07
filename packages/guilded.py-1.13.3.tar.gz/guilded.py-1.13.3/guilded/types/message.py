"""
MIT License

Copyright (c) 2020-present shay (shayypy)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

from __future__ import annotations
from typing import List, Literal, Optional, TypedDict
from typing_extensions import NotRequired

from .channel import Mentions
from .embed import Embed


class ChatMessage(TypedDict):
    id: str
    type: Literal['default', 'system']
    serverId: NotRequired[str]
    groupId: NotRequired[str]
    channelId: str
    content: Optional[str]
    embeds: Optional[List[Embed]]
    replyMessageIds: NotRequired[str]
    isPrivate: NotRequired[bool]
    isSilent: NotRequired[bool]
    isPinned: NotRequired[bool]
    mentions: NotRequired[Mentions]
    createdAt: str
    createdBy: str
    createdByWebhookId: NotRequired[str]
    updatedAt: NotRequired[str]
    hiddenLinkPreviewUrls: NotRequired[List[str]]


class DeletedChatMessage(ChatMessage):
    deletedAt: str
