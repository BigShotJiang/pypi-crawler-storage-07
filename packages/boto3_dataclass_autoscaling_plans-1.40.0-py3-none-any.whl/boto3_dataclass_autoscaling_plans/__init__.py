# -*- coding: utf-8 -*-

from .caster import autoscaling_plans_caster

caster = autoscaling_plans_caster

__version__ = "1.40.0"