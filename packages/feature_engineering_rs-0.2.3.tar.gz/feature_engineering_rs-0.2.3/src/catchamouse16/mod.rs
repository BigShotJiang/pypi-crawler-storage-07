pub mod sy_driftingmean;
pub mod sy_slidingwindow;
pub mod st_localextrema;