pub mod builtin;
pub mod ir_hasher;
pub mod ir_helpers;
pub mod jinja_helpers;
mod json_schema;
pub mod repr;
mod walker;

pub use ir_helpers::{
    scope_diagnostics, ArgCoercer, ClassFieldWalker, ClassWalker, ClientWalker, EnumValueWalker,
    EnumWalker, ExprFunctionWalker, FunctionWalker, IRHelper, IRHelperExtended,
    IRSemanticStreamingHelper, RetryPolicyWalker, TemplateStringWalker, TestCaseWalker,
    TypeAliasWalker,
};
pub(super) use repr::IntermediateRepr;

// Add aliases for the IR types
pub type Enum = repr::Node<repr::Enum>;
pub type EnumValue = repr::Node<repr::EnumValue>;
pub type Class = repr::Node<repr::Class>;
pub type TypeAlias = repr::Node<repr::TypeAlias>;
pub type Field = repr::Node<repr::Field>;
pub type TypeIR = baml_types::TypeIR;
pub type TypeValue = baml_types::TypeValue;
pub type FunctionNode = repr::Node<repr::Function>;
pub type ExprFunctionNode = repr::Node<repr::ExprFunction>;
#[allow(dead_code)]
pub(super) type Function = repr::Function;
pub(super) type FunctionArgs = repr::FunctionArgs;
pub(super) type Impl = repr::Node<repr::Implementation>;
pub type Client = repr::Node<repr::Client>;
pub type RetryPolicy = repr::Node<repr::RetryPolicy>;
pub type TemplateString = repr::Node<repr::TemplateString>;
pub type TestCase = repr::Node<repr::TestCase>;
pub(super) type Walker<'db, I> = repr::Walker<'db, I>;

pub(super) type Prompt = repr::Prompt;

pub use walker::ExprFnAsFunctionWalker;
