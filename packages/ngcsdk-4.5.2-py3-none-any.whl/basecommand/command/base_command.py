#
# Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
#
# This software product is a proprietary product of Nvidia Corporation and its affiliates
# (the "Company") and all right, title, and interest in and to the software
# product, including all associated intellectual property rights, are and
# shall remain exclusively with the Company.
#
# This software product is governed by the End User License Agreement
# provided with the software product.

from ngcbase.command.clicommand import CLICommand


class BaseCommand(CLICommand):  # noqa: D101
    CMD_NAME = "base-command"
    HELP = "Base Command Commands"
    DESC = "Base Command Commands"
    CMD_ALIAS = ["bc"]
