This addon manages the banking mandate from the sale order to the
contract.
