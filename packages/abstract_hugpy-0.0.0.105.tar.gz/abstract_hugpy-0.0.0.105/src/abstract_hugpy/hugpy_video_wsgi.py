from abstract_hugpy.hugpy_console.hugpy_flasks.hugpy_video_flask_app import hugpy_video_app

app = hugpy_video_app()
