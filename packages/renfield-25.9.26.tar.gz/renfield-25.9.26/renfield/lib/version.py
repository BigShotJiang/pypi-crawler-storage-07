"""It's the version"""

__version__ = "25.9.26"
