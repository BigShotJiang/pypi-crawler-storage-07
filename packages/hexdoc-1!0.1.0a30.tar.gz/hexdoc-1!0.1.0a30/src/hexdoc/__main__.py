from hexdoc.cli.app import app

app()
