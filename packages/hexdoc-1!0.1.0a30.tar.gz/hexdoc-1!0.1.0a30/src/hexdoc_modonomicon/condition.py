from hexdoc.model import HexdocModel


class Condition(HexdocModel):
    """https://klikli-dev.github.io/modonomicon/docs/basics/unlock-conditions"""
