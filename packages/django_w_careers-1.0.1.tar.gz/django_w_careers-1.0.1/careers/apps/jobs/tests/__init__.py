"""Tests for careers.apps.jobs"""
