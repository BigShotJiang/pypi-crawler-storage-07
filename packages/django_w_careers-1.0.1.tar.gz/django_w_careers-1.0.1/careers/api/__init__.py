"""Django Careers APIs"""
