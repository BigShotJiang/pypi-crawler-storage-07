"""
Functional test about cmd
"""