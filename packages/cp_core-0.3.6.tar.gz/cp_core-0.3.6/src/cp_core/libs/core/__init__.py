"""
Contains all core function.
"""
