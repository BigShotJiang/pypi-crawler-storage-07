"""
Total event for protect.
"""
