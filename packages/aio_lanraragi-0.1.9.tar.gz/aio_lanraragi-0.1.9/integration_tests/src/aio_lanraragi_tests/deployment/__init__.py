"""
Deployment managers for the integration tests.
"""