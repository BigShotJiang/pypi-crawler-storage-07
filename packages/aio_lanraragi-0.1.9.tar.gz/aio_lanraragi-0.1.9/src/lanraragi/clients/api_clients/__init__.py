"""
API sub-client module. All resources in this module are private, and should not be accessed when used as a third-party library.
"""