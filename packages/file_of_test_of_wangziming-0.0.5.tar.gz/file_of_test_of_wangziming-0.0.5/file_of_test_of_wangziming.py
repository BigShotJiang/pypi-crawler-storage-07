str1 = '这是一个测试项目，测试成功。'

if __name__ == '__main__':
    print(str1)