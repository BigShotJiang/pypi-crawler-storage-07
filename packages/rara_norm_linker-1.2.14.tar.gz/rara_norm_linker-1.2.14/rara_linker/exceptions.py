class InvalidInputError(Exception):
	"""Raised when something incorrect given to parse."""
	pass
