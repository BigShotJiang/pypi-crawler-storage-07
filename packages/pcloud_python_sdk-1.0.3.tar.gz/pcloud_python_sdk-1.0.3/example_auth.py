from pcloud import PCloud, PCloudOAuth2Flow
app_key="4hQ2I2F9T3V"
app_secret="S1RuAXoVftkX9WGhywG5hJL7iogV"
redirect_uri="http://127.0.0.1:53682/callback"

flow = PCloudOAuth2Flow(app_key, app_secret,
                        redirect_uri=None,  # EXACT match
                        location="EU")

auth_url = flow.start(state="xyz")
print("Open:", auth_url)  # sanity check the redirect_uri value shown

code = input("Paste the code from the URL bar: ").strip()
tok = flow.finish(code)

pc = PCloud(access_token=tok.access_token, location="EU")
print(pc.files.list_folder(folderid=0))