"""
GreeumMCP adapters package.
""" 