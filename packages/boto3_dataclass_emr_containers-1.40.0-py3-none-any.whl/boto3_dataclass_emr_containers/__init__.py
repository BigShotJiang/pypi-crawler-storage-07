# -*- coding: utf-8 -*-

from .caster import emr_containers_caster

caster = emr_containers_caster

__version__ = "1.40.0"