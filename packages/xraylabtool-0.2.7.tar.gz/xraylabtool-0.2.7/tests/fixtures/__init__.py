"""Test fixtures and utilities for XRayLabTool tests."""
