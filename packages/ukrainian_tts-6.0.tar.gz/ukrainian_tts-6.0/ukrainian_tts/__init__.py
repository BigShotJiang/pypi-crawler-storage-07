import stanza

stanza.download("uk")
