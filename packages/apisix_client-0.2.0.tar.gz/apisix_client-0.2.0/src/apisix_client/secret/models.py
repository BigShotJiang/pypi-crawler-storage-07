import attrs


@attrs.define()
class SecretResponse: ...
