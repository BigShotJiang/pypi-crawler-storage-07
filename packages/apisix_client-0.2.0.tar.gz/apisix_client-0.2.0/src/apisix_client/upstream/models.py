import attrs


@attrs.define()
class UpstreamResponse: ...
