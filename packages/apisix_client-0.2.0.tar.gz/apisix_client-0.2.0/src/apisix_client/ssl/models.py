import attrs


@attrs.define()
class SSLResponse: ...
