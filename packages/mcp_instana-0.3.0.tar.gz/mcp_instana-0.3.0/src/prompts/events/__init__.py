"""Events-specific prompts package."""
