# Log module for MCP Instana
