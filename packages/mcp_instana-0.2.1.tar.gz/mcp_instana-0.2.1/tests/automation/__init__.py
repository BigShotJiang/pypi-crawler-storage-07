"""
Automation tests package

This package contains tests for automation-related MCP tools.
"""
