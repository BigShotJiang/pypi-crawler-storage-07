# Log tests module for MCP Instana
