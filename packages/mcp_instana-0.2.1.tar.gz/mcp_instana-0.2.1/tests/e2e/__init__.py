"""
E2E tests for MCP Instana Internal
"""

__version__ = "1.0.0"
