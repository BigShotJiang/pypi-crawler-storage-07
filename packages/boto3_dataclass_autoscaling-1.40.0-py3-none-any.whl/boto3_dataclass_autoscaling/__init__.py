# -*- coding: utf-8 -*-

from .caster import autoscaling_caster

caster = autoscaling_caster

__version__ = "1.40.0"