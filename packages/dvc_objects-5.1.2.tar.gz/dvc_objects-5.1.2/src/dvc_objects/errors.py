class ObjectFormatError(Exception):
    pass


class ObjectDBError(Exception):
    pass


class ObjectDBPermissionError(ObjectDBError):
    pass
