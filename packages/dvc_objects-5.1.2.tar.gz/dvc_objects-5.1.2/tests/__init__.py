"""Test suite for the dvc_objects package."""
