import os

from .workflow import Workflow

ROOT_PATH = os.path.dirname(__file__)
