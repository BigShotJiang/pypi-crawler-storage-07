# -*- coding: utf-8 -*-

from .caster import keyspaces_caster

caster = keyspaces_caster

__version__ = "1.40.0"