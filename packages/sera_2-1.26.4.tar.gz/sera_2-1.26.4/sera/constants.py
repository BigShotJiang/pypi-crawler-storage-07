from __future__ import annotations

# Constant representing an unassigned integer ID
NO_INT_ID: int = None  # type: ignore
