"""Whisper client."""
