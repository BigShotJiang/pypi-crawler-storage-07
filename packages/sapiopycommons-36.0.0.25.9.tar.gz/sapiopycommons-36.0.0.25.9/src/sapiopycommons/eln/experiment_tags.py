# CSP paths:
PLATE_DESIGNER_PLUGIN: str = "com.velox.gwt.client.plugins.multilayerplating.core.ElnMultiLayerPlatingClientPlugin"

# 3D Plate Designer entry tags:
PLATE_IDS_TAG: str = "MultiLayerPlating_Plate_RecordIdList"
PLATE_CONFIG_PREFS_TAG: str = "MultiLayerPlating_Entry_PrePlating_Prefs"
PLATE_LAYER_PREFS_TAG: str = "MultiLayerPlating_Entry_Prefs"
