# dev-py-transactionmanager-lib
Python Library "Transaction Manager" 
