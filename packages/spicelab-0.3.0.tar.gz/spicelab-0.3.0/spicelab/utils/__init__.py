"""Utilities package for spicelab."""

from .log import get_logger

__all__ = ["get_logger"]
