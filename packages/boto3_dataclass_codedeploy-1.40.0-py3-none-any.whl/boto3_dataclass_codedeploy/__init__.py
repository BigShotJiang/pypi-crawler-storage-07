# -*- coding: utf-8 -*-

from .caster import codedeploy_caster

caster = codedeploy_caster

__version__ = "1.40.0"