"""
This module contains the function to cancel segment.

Functions:
    _cancel_segment: Cancels segment.
"""

from nomad_media_pip.src.helpers.send_request import _send_request


def _cancel_segment(self, channel_id: str) -> dict | None:
    """
    Cancels segment.

    Args:
        channel_id (str): The ID of the channel to cancel the segment.

    Returns:
        dict: The JSON response from the server if the request is successful.
        None: If the request fails or the response cannot be parsed as JSON.
    """

    api_url: str = f"{self.config["serviceApiUrl"]}/api/admin/liveOperator/{channel_id}/cancelSegment"

    return _send_request(self, "Cancel Segment", api_url, "POST", None, None)
