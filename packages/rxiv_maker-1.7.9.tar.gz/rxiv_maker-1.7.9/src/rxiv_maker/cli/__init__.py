"""CLI module for rxiv-maker."""

from .main import main

__all__ = ["main"]
