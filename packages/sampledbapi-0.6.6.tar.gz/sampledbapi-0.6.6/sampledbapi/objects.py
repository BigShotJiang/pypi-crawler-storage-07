from __future__ import annotations

import base64
from datetime import datetime
from io import IOBase
from typing import BinaryIO, Dict, List, Optional, Any

from requests import Response

import hashlib

from .comm import SampleDBObject, get_data, post_data, put_data
from . import locations, users, utils

__all__ = ["Object", "File", "Comment", "get_list", "get", "create"]


class Object(SampleDBObject):

    object_id: Optional[int] = None
    version_id: Optional[int] = None
    version_editor: Optional[users.User] = None
    version_datetime: Optional[datetime] = None
    action_id: Optional[int] = None
    schema: Optional[dict] = None
    data: Optional[dict] = None

    def __init__(self, d: Dict, users_cache: Optional[Dict[int, users.User]] = None):
        """Initialize a new instrument from dictionary."""
        super().__init__(d)
        if "utc_datetime" in d:
            self.version_datetime = utils.str2datetime(d["utc_datetime"])
        if "user_id" in d:
            if users_cache is not None and d["user_id"] in users_cache:
                self.version_editor = users_cache[d["user_id"]]
            else:
                self.version_editor = users.get(d["user_id"])
        if "data" in d:
            self.data = utils.convert_json(d["data"])

    def __repr__(self) -> str:
        return f"Object {self.object_id}"

    @classmethod
    def from_json(cls, data: dict) -> Optional[Object]:
        if "_type" not in data or data["_type"] != "object_reference":
            return None
        return get(int(data["object_id"]))

    def to_json(self) -> Dict:
        return {"_type": "object_reference", "object_id": str(self.object_id)}

    def get_version(self, version_id: int) -> Object:
        """Get the specific version (version_id).

        Args:
            version_id (int): ID of the version to be retrieved.

        Returns:
            Object: Requested :class:`~sampledbapi.objects.Object`.
        """
        if isinstance(version_id, int):
            return Object(get_data(f"objects/{self.object_id}/versions/{version_id}"))
        else:
            raise TypeError()

    def update(self, data: dict, schema: Optional[dict] = None) -> Response:
        """Create a new version.

        The data is a dictionary that has to be formatted according to the
        action's schema. Exemplary data:

        .. code-block::

            {"name": {
                "_type": "text",
                "text": "Example Object"
            }}

        """
        if isinstance(data, dict):
            data_to_post = {"data": data}
            if isinstance(schema, dict):
                data_to_post["schema"] = schema
            return post_data(f"objects/{self.object_id}/versions/", data_to_post)
        else:
            raise TypeError()

    def get_related_objects(self):
        """Gets objects related to an object.

        Returns:
            Two lists containing referenced objects and referencing objects.

        """
        related_objects = get_data(f"objects/{self.object_id}/related_objects")
        referenced_object_ids = related_objects["referenced_objects"]
        referencing_object_ids = related_objects["referencing_objects"]
        referenced_objects = list(
            map(get, map(lambda dic: dic["object_id"], referenced_object_ids))
        )
        referencing_objects = list(
            map(get, map(lambda dic: dic["object_id"], referencing_object_ids))
        )
        return referenced_objects, referencing_objects

    def get_public(self) -> bool:
        """Get whether or not the object is public.

        Returns:
            bool: Whether the object is public or not.
        """
        return get_data(f"objects/{self.object_id}/permissions/public")

    def set_public(self, public: bool) -> Response:
        """Set whether or not the object is public.

        Args:
            public (bool): Whether the object is public or not.

        Returns:
            HTTPResponse: `See here. <https://scientific-it-systems.iffgit.fz-juelich.de/SampleDB/developer_guide/api.html#object-permissions>`__
        """
        if isinstance(public, bool):
            return put_data(f"objects/{self.object_id}/permissions/public", public)
        else:
            raise TypeError()

    def get_all_user_permissions(self) -> Dict:
        """Get a mapping of user IDs to their permissions.

        Returns:
            Dict: Mapping of user IDs to permissions.
        """
        return get_data(f"objects/{self.object_id}/permissions/users")

    def get_user_permissions(self, user_id: int) -> str:
        """Get the permissions of a user.

        Args:
            user_id (int): ID of the user.

        Returns:
            str: Permissions of user for the object.
        """
        if isinstance(user_id, int):
            return get_data(f"objects/{self.object_id}/permissions/users/{user_id}")
        else:
            raise TypeError()

    def set_user_permissions(self, user_id: int, permissions: str) -> Response:
        """Set the permissions of a user.

        Args:
            user_id (int): ID of the user.
            permissions (str): Permissions of user for the object.

        Returns:
            HTTPResponse: `See here. <https://scientific-it-systems.iffgit.fz-juelich.de/SampleDB/developer_guide/api.html#object-permissions>`__
        """
        if isinstance(user_id, int) and isinstance(permissions, str):
            return put_data(
                f"objects/{self.object_id}/permissions/users/{user_id}", permissions
            )
        else:
            raise TypeError()

    def get_all_group_permissions(self) -> Dict:
        """Get a mapping of basic group IDs to their permissions.

        Returns:
            Dict: Mapping of group IDs to permissions.
        """
        return get_data(f"objects/{self.object_id}/permissions/groups")

    def get_group_permissions(self, group_id: int) -> str:
        """Get the permissions of a basic group.

        Args:
            group_id (int): ID of the group.

        Returns:
            str: Permissions of group for the object.
        """
        if isinstance(group_id, int):
            return get_data(f"objects/{self.object_id}/permissions/groups/{group_id}")
        else:
            raise TypeError()

    def set_group_permissions(self, group_id: int, permissions: str) -> Response:
        """Set the permissions of a basic group.

        Args:
            group_id (int): ID of the group.
            permissions (str): Permissions of group for the object.

        Returns:
            HTTPResponse: `See here. <https://scientific-it-systems.iffgit.fz-juelich.de/SampleDB/developer_guide/api.html#object-permissions>`__
        """
        if isinstance(group_id, int) and isinstance(permissions, str):
            return put_data(
                f"objects/{self.object_id}/permissions/groups/{group_id}", permissions
            )
        else:
            raise TypeError()

    def get_all_project_group_permissions(self) -> Dict:
        """Get a mapping of project group IDs to their permissions.

        Returns:
            Dict: Mapping of project group IDs to permissions.
        """
        return get_data(f"objects/{self.object_id}/permissions/projects")

    def get_project_group_permissions(self, project_id: int) -> str:
        """Get the permissions of a project group.

        Args:
            project_id (int): ID of the project group.

        Returns:
            str: Permissions of project group for the object.
        """
        if isinstance(project_id, int):
            return get_data(
                f"objects/{self.object_id}/permissions/projects/{project_id}"
            )
        else:
            raise TypeError()

    def set_project_group_permissions(
        self, project_id: int, permissions: str
    ) -> Response:
        """Set the permissions of a project group.

        Args:
            project_id (int): ID of the project group.
            permissions (str): Permissions of project group for the object.

        Returns:
            HTTPResponse: `See here. <https://scientific-it-systems.iffgit.fz-juelich.de/SampleDB/developer_guide/api.html#object-permissions>`__
        """
        if isinstance(project_id, int) and isinstance(permissions, str):
            return put_data(
                f"objects/{self.object_id}/permissions/projects/{project_id}",
                permissions,
            )
        else:
            raise TypeError()

    def get_location_occurences(self) -> List[LocationOccurence]:
        """
        Get a list of all object locations assignments for a specific object.

        Args:

        Returns:
            List: `See here. <https://scientific-it-systems.iffgit.fz-juelich.de/SampleDB/developer_guide/api.html#reading-a-list-of-an-object-s-locations>`__

        """
        # Get the raw location occurrence data first
        locations_data = get_data(f"objects/{self.object_id}/locations")

        # Collect unique user IDs from the location occurrences
        user_ids = set()
        for loc_data in locations_data:
            if "responsible_user" in loc_data:
                user_ids.add(loc_data["responsible_user"])
            if "user" in loc_data:
                user_ids.add(loc_data["user"])

        # Fetch all users once and create a cache
        users_cache = {}
        for user_id in user_ids:
            users_cache[user_id] = users.get(user_id)

        # Create LocationOccurence instances with the users cache
        return [LocationOccurence(i, users_cache) for i in locations_data]

    def get_location_occurence(self, location_id: int) -> LocationOccurence:
        """
        Get a specific object location assignment (index) for a specific object.

        Args:
            location_id (int) : ID of the location

        Returns:
            LocationOccurence: `See here. <https://scientific-it-systems.iffgit.fz-juelich.de/SampleDB/developer_guide/api.html#reading-an-object-s-location>`__


        """
        if isinstance(location_id, int):
            return LocationOccurence(
                get_data(f"objects/{self.object_id}/locations/{location_id}")
            )
        else:
            raise TypeError()

    def get_file_list(self) -> List:
        """Get a list of all files.

        Returns:
            List: `See here. <https://scientific-it-systems.iffgit.fz-juelich.de/SampleDB/developer_guide/api.html#files>`__
        """
        return [File(i) for i in get_data(f"objects/{self.object_id}/files")]

    def get_file(self, file_id: int) -> File:
        """Get a specific file (file_id).

        Args:
            file_id (int): ID of the file.

        Returns:
            Dict: `See here. <https://scientific-it-systems.iffgit.fz-juelich.de/SampleDB/developer_guide/api.html#files>`__
        """
        if isinstance(file_id, int):
            return File(get_data(f"objects/{self.object_id}/files/{file_id}"))
        else:
            raise TypeError()

    def upload_file(self, path: str, name: Optional[str] = None) -> int:
        """Create a new file.

        Args:
            path (str): Path of the file to be uploaded.

        Returns:
            HTTPResponse: `See here. <https://scientific-it-systems.iffgit.fz-juelich.de/SampleDB/developer_guide/api.html#files>`__
        """
        if isinstance(path, str):
            with open(path, "rb") as f:
                f.name
                i = self.upload_file_raw(f.name if name is None else name, f)
            return i
        else:
            raise TypeError()

    def upload_file_raw(self, name: str, file_obj: BinaryIO) -> int:
        """Create a new file with local storage.

        Args:
            name (str): Name that the file will have online.
            file_obj (BinaryIO): A binary stream that can be read to be uploaded.

        Returns:
            HTTPResponse: `See here. <https://scientific-it-systems.iffgit.fz-juelich.de/SampleDB/developer_guide/api.html#files>`__
        """
        if isinstance(name, str) and isinstance(file_obj, IOBase):
            data = file_obj.read()
            base64encoded = base64.b64encode(data)
            sha256 = hashlib.sha256()
            sha256.update(data)
            response = post_data(
                f"objects/{self.object_id}/files/",
                {
                    "storage": "database",
                    "original_file_name": name,
                    "base64_content": base64encoded.decode(),
                    "hash": {"algorithm": "sha256", "hexdigest": sha256.hexdigest()},
                },
            )

            return int(response.headers["Location"].rsplit("/files/", 1)[1])
        else:
            raise TypeError()

    def post_link(self, url: str) -> Response:
        """Create a new file with url storage.

        Args:
            url (str): URL to be stored.

        Returns:
            HTTPResponse: `See here. <https://scientific-it-systems.iffgit.fz-juelich.de/SampleDB/developer_guide/api.html#files>`__
        """
        if isinstance(url, str):
            return post_data(
                f"objects/{self.object_id}/files/", {"storage": "url", "url": url}
            )
        else:
            raise TypeError()

    def get_comment_list(self) -> List[Comment]:
        """Get a list of all comments.

        Returns:
            List: List of :class:`~sampledbapi.objects.Comment`.
        """
        return [Comment(c) for c in get_data(f"objects/{self.object_id}/comments")]

    def get_comment(self, comment_id: int) -> Comment:
        """Get specific comment (comment_id).

        Args:
            comment_id (int): ID of the comment.

        Returns:
            Object: Requested :class:`~sampledbapi.objects.Comment`.
        """
        if isinstance(comment_id, int):
            return Comment(get_data(f"objects/{self.object_id}/comments/{comment_id}"))
        else:
            raise TypeError()

    def post_comment(self, comment: str) -> Response:
        """Create a new comment.

        Args:
            comment (str): Comment to be posted.

        Returns:
            HTTPResponse: `See here. <https://scientific-it-systems.iffgit.fz-juelich.de/SampleDB/developer_guide/api.html#comments>`__
        """
        if isinstance(comment, str):
            return post_data(
                f"objects/{self.object_id}/comments/", {"content": comment}
            )
        else:
            raise TypeError()


def get_list(
    q: str = "",
    action_id: int = -1,
    action_type: str = "",
    limit: int = -1,
    offset: int = -1,
    name_only: bool = False,
) -> List[Object]:
    """Get a list of all objects visible to the current user.

    The list only contains the current version of each object. By passing the
    parameter q to the query, the Advanced Search can be used. By passing the
    parameters action_id or action_type objects can be filtered by the action
    they were created with or by their type (e.g. sample or measurement).

    Instead of returning all objects, the parameters limit and offset can be
    used to reduce to maximum number of objects returned and to provide an
    offset in the returned set, so allow simple pagination.

    If the parameter name_only is provided, the object data and schema will be
    reduced to the name property, omitting all other properties and schema
    information.

    Args:
        q (str): Search string for advanced search, `see here. <https://scientific-it-systems.iffgit.fz-juelich.de/SampleDB/user_guide/search.html#advanced-search>`__
        action_id (int): Filter by action ID.
        action_type (str): Filter by action type.
        limit (int): Limit number of results (helpful for pagination).
        offset (int): Offset for limited retrieval of results (pagination).
        name_only (bool): Only names will be returned, no other information.

    Returns:
        List: List of :class:`~sampledbapi.objects.Object`.
    """
    if (
        isinstance(q, str) and
        isinstance(action_id, int) and
        isinstance(action_type, str) and
        isinstance(limit, int) and
        isinstance(offset, int) and
        isinstance(name_only, bool)
    ):
        pars: Dict[str, Any] = {}
        if q != "":
            pars["q"] = q
        if action_id > 0:
            pars["action_id"] = action_id
        if action_type != "":
            pars["action_type"] = action_type
        if limit > 0:
            pars["limit"] = limit
        if offset > 0:
            pars["offset"] = offset
        if name_only:
            pars["name_only"] = "true"

        # Get the raw object data first
        objects_data = get_data("objects", pars)

        # Collect unique user IDs from the objects
        user_ids = set()
        for obj_data in objects_data:
            if "user_id" in obj_data:
                user_ids.add(obj_data["user_id"])

        # Fetch all users once and create a cache
        users_cache = {}
        for user_id in user_ids:
            users_cache[user_id] = users.get(user_id)

        # Create Object instances with the users cache
        return [Object(o, users_cache) for o in objects_data]
    else:
        raise TypeError()


def get(object_id: int) -> Object:
    """Get the current version of an object (object_id).

    Args:
        object_id (int): ID of the object.

    Returns:
        Object: Requested :class:`~sampledbapi.objects.Object`.
    """
    if isinstance(object_id, int):
        return Object(get_data(f"objects/{object_id}"))
    else:
        raise TypeError()


def create(action_id: int, data: dict) -> int:
    """Create a new object.

    The data is a dictionary that has to be formatted according to the action's
    schema. Exemplary data:

    .. code-block::

        {"name": {
            "_type": "text",
            "text": "Example Object"
        }}

    Returns:
        int:
    """
    if isinstance(action_id, int) and isinstance(data, dict):
        response = post_data("objects/", {"action_id": action_id, "data": data})
        return int(
            response.headers["Location"]
            .rsplit("/objects/", 1)[1]
            .split("/versions/", 1)[0]
        )
    else:
        raise TypeError()


class File(SampleDBObject):

    object_id: Optional[int] = None
    file_id: Optional[int] = None
    storage: Optional[str] = None
    original_file_name: Optional[str] = None
    base64_content: Optional[str] = None
    url: Optional[str] = None
    hash: Optional[str] = None

    def __repr__(self) -> str:
        return f"File {self.file_id}, " + f"Name {self.original_file_name}"


class LocationOccurence(SampleDBObject):

    object_id: Optional[int] = None
    location: Optional[locations.Location] = None
    responsible_user: Optional[users.User] = None
    user: Optional[users.User] = None
    description: Optional[str] = None
    utc_datetime: Optional[datetime] = None

    def __init__(self, d: Dict, users_cache: Optional[Dict[int, users.User]] = None):
        """Initialize a new instrument from dictionary."""
        super().__init__(d)
        if "location" in d:
            self.location = locations.get(d["location"])
        if "responsible_user" in d:
            if users_cache is not None and d["responsible_user"] in users_cache:
                self.responsible_user = users_cache[d["responsible_user"]]
            else:
                self.responsible_user = users.get(d["responsible_user"])
        if "user" in d:
            if users_cache is not None and d["user"] in users_cache:
                self.user = users_cache[d["user"]]
            else:
                self.user = users.get(d["user"])
        if "utc_datetime" in d:
            self.utc_datetime = datetime.strptime(
                d["utc_datetime"], "%Y-%m-%dT%H:%M:%S.%f"
            )

    def __repr__(self) -> str:
        return (
            f"LocationOccurence of object {self.object_id} " +
            "(at {self.location.name})"
        )


class Comment(SampleDBObject):

    object_id: Optional[int] = None
    user_id: Optional[int] = None
    comment_id: Optional[int] = None
    content: Optional[str] = None
    utc_datetime: Optional[datetime] = None

    def __init__(self, d: Dict):
        """Initialize a new comment from dictionary."""
        super().__init__(d)
        if "utc_datetime" in d:
            self.utc_datetime = datetime.strptime(
                d["utc_datetime"], "%Y-%m-%dT%H:%M:%S.%f"
            )

    def __str__(self) -> str:
        return f"Comment on object {self.object_id}, " + f"posted {self.utc_datetime}"
