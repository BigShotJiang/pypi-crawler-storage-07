from django.apps import AppConfig


class CmsConfig(AppConfig):
    name = "unfold_extra.contrib.sites"
    label = "unfold_extra_sites"