from django.apps import AppConfig


class CmsConfig(AppConfig):
    name = "unfold_extra.contrib.auth"
    label = "unfold_extra_auth"