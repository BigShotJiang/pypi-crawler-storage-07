
& "C:\Program Files\Git\usr\bin\nano.exe" $args

