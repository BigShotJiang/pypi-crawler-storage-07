from .core import main

main()
