# -*- coding: utf-8 -*-

from .caster import forecastquery_caster

caster = forecastquery_caster

__version__ = "1.40.0"