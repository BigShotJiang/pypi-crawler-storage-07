"""
Строитель ботов для Smart Bot Factory
"""

import os
import sys
import asyncio
import logging
from pathlib import Path
from typing import Optional, Dict, Any, List

from ..config import Config
from ..integrations.openai_client import OpenAIClient
from ..integrations.supabase_client import SupabaseClient
from ..core.conversation_manager import ConversationManager
from ..admin.admin_manager import AdminManager
from ..analytics.analytics_manager import AnalyticsManager
from ..utils.prompt_loader import PromptLoader
from ..core.decorators import get_handlers_for_prompt
from ..core.router_manager import RouterManager

logger = logging.getLogger(__name__)

class BotBuilder:
    """
    Строитель ботов, который использует существующие файлы проекта
    и добавляет новые возможности через декораторы
    """
    
    def __init__(self, bot_id: str, config_dir: Optional[Path] = None):
        """
        Инициализация строителя бота
        
        Args:
            bot_id: Идентификатор бота
            config_dir: Путь к директории конфигурации (по умолчанию configs/bot_id)
        """
        self.bot_id = bot_id
        self.config_dir = config_dir or Path("bots") / bot_id
        
        # Компоненты бота
        self.config: Optional[Config] = None
        self.openai_client: Optional[OpenAIClient] = None
        self.supabase_client: Optional[SupabaseClient] = None
        self.conversation_manager: Optional[ConversationManager] = None
        self.admin_manager: Optional[AdminManager] = None
        self.analytics_manager: Optional[AnalyticsManager] = None
        self.prompt_loader: Optional[PromptLoader] = None
        self.router_manager: Optional[RouterManager] = None
        
        # Флаги инициализации
        self._initialized = False
        
        logger.info(f"🏗️ Создан BotBuilder для бота: {bot_id}")
    
    async def build(self) -> 'BotBuilder':
        """
        Строит и инициализирует все компоненты бота
        
        Returns:
            BotBuilder: Возвращает self для цепочки вызовов
        """
        if self._initialized:
            logger.warning(f"⚠️ Бот {self.bot_id} уже инициализирован")
            return self
        
        try:
            logger.info(f"🚀 Начинаем сборку бота {self.bot_id}")
            
            # 1. Инициализируем конфигурацию
            await self._init_config()
            
            # 2. Инициализируем клиенты
            await self._init_clients()
            
            # 3. Инициализируем менеджеры
            await self._init_managers()
            
            # 4. Обновляем промпты с информацией о доступных инструментах
            await self._update_prompts_with_tools()
            
            self._initialized = True
            logger.info(f"✅ Бот {self.bot_id} успешно собран и готов к работе")
            
            return self
            
        except Exception as e:
            logger.error(f"❌ Ошибка при сборке бота {self.bot_id}: {e}")
            raise
    
    async def _init_config(self):
        """Инициализация конфигурации"""
        logger.info(f"⚙️ Инициализация конфигурации для {self.bot_id}")
        
        # Устанавливаем BOT_ID в переменные окружения
        os.environ['BOT_ID'] = self.bot_id
        
        # Загружаем .env файл если существует
        env_file = self.config_dir / ".env"
        if env_file.exists():
            from dotenv import load_dotenv
            load_dotenv(env_file)
            logger.info(f"📄 Загружен .env файл: {env_file}")
        
        # Устанавливаем путь к промптам относительно папки бота
        prompts_subdir = os.environ.get("PROMT_FILES_DIR", "prompts")
        logger.info(f"🔍 PROMT_FILES_DIR из .env: {prompts_subdir}")
        
        prompts_dir = self.config_dir / prompts_subdir
        logger.info(f"🔍 Путь к промптам: {prompts_dir}")
        logger.info(f"🔍 Существует ли папка: {prompts_dir.exists()}")
        
        # ВАЖНО: Устанавливаем правильный путь ДО создания Config
        os.environ["PROMT_FILES_DIR"] = str(prompts_dir)
        logger.info(f"📁 Установлен путь к промптам: {prompts_dir}")
        
        # Создаем конфигурацию
        logger.info(f"🔍 PROMT_FILES_DIR перед созданием Config: {os.environ.get('PROMT_FILES_DIR')}")
        self.config = Config()
        logger.info(f"✅ Конфигурация инициализирована")
    
    async def _init_clients(self):
        """Инициализация клиентов"""
        logger.info(f"🔌 Инициализация клиентов для {self.bot_id}")
        
        # OpenAI клиент
        self.openai_client = OpenAIClient(
            api_key=self.config.OPENAI_API_KEY,
            model=self.config.OPENAI_MODEL,
            max_tokens=self.config.OPENAI_MAX_TOKENS,
            temperature=self.config.OPENAI_TEMPERATURE
        )
        logger.info(f"✅ OpenAI клиент инициализирован")
        
        # Supabase клиент
        self.supabase_client = SupabaseClient(
            url=self.config.SUPABASE_URL,
            key=self.config.SUPABASE_KEY,
            bot_id=self.bot_id
        )
        await self.supabase_client.initialize()
        logger.info(f"✅ Supabase клиент инициализирован")
    
    async def _init_managers(self):
        """Инициализация менеджеров"""
        logger.info(f"👥 Инициализация менеджеров для {self.bot_id}")
        
        # Admin Manager
        self.admin_manager = AdminManager(self.config, self.supabase_client)
        await self.admin_manager.sync_admins_from_config()
        logger.info(f"✅ Admin Manager инициализирован")
        
        # Analytics Manager
        self.analytics_manager = AnalyticsManager(self.supabase_client)
        logger.info(f"✅ Analytics Manager инициализирован")
        
        # Conversation Manager
        parse_mode = os.environ.get('MESSAGE_PARSE_MODE', 'Markdown')
        admin_session_timeout_minutes = int(os.environ.get('ADMIN_SESSION_TIMEOUT_MINUTES', '30'))
        
        self.conversation_manager = ConversationManager(self.supabase_client, self.admin_manager, parse_mode, admin_session_timeout_minutes)
        logger.info(f"✅ Conversation Manager инициализирован")
        
        # Router Manager (создаем только если еще не создан)
        if not self.router_manager:
            self.router_manager = RouterManager()
            logger.info(f"✅ Router Manager инициализирован")
        else:
            logger.info(f"✅ Router Manager уже был создан ранее")
        
        # Prompt Loader
        self.prompt_loader = PromptLoader(
            prompts_dir=self.config.PROMT_FILES_DIR
        )
        await self.prompt_loader.validate_prompts()
        logger.info(f"✅ Prompt Loader инициализирован")
    
    async def _update_prompts_with_tools(self):
        """
        Обновляет промпты информацией о доступных обработчиках событий
        """
        logger.info(f"🔧 Обновление промптов с информацией об обработчиках")
        
        # Получаем информацию о доступных обработчиках
        # Сначала пробуем получить из роутеров, если нет - из старых декораторов
        if self.router_manager:
            event_handlers_info = self.router_manager.get_handlers_for_prompt()
        else:
            event_handlers_info = get_handlers_for_prompt()
        
        # Если есть обработчики, добавляем их в системный промпт
        if event_handlers_info:
            # Сохраняем информацию о обработчиках для использования в handlers.py
            self._tools_prompt = event_handlers_info
            
            logger.info(f"✅ Промпты обновлены с информацией об обработчиках")
        else:
            self._tools_prompt = ""
            logger.info(f"ℹ️ Нет зарегистрированных обработчиков")
    
    def get_tools_prompt(self) -> str:
        """Возвращает промпт с информацией об инструментах"""
        return getattr(self, '_tools_prompt', '')
    
    def get_status(self) -> Dict[str, Any]:
        """Возвращает статус бота"""
        return {
            "bot_id": self.bot_id,
            "initialized": self._initialized,
            "config_dir": str(self.config_dir),
            "components": {
                "config": self.config is not None,
                "openai_client": self.openai_client is not None,
                "supabase_client": self.supabase_client is not None,
                "conversation_manager": self.conversation_manager is not None,
                "admin_manager": self.admin_manager is not None,
                "analytics_manager": self.analytics_manager is not None,
                "prompt_loader": self.prompt_loader is not None
            },
            "tools": {
                "event_handlers": len(get_handlers_for_prompt().split('\n')) if get_handlers_for_prompt() else 0
            }
        }
    
    def set_global_vars_in_module(self, module_name: str):
        """
        Устанавливает глобальные переменные в указанном модуле для удобного доступа
        
        Args:
            module_name: Имя модуля (например, 'valera', 'my_bot')
        """
        try:
            import sys
            import importlib
            
            # Получаем модуль бота
            bot_module = sys.modules.get(module_name)
            if not bot_module:
                logger.warning(f"⚠️ Модуль '{module_name}' не найден для установки глобальных переменных")
                return
            
            # Устанавливаем глобальные переменные
            bot_module.supabase_client = self.supabase_client
            bot_module.openai_client = self.openai_client
            bot_module.config = self.config
            bot_module.admin_manager = self.admin_manager
            bot_module.analytics_manager = self.analytics_manager
            bot_module.conversation_manager = self.conversation_manager
            bot_module.prompt_loader = self.prompt_loader
            
            logger.info(f"✅ Глобальные переменные установлены в модуле '{module_name}'")
            
        except Exception as e:
            logger.warning(f"⚠️ Не удалось установить глобальные переменные в модуле '{module_name}': {e}")
    
    def register_router(self, router):
        """
        Регистрирует роутер в менеджере роутеров
        
        Args:
            router: Роутер для регистрации
        """
        # Если RouterManager еще не инициализирован, создаем его
        if not self.router_manager:
            from ..core.router_manager import RouterManager
            self.router_manager = RouterManager()
            logger.info(f"✅ Router Manager создан для регистрации роутера '{router.name}'")
        
        self.router_manager.register_router(router)
        logger.info(f"✅ Роутер '{router.name}' зарегистрирован в боте {self.bot_id}")
    
    def get_router_manager(self) -> RouterManager:
        """Получает менеджер роутеров"""
        return self.router_manager
    
    async def start(self):
        """
        Запускает бота (аналог main.py)
        """
        if not self._initialized:
            raise RuntimeError(f"Бот {self.bot_id} не инициализирован. Вызовите build() сначала")
        
        logger.info(f"🚀 Запускаем бота {self.bot_id}")
        
        try:
            # Импортируем необходимые компоненты
            from aiogram import Bot, Dispatcher
            from aiogram.fsm.storage.memory import MemoryStorage
            
            # Создаем бота и диспетчер
            bot = Bot(token=self.config.TELEGRAM_BOT_TOKEN)
            storage = MemoryStorage()
            dp = Dispatcher(storage=storage)
            
            # Инициализируем базу данных
            await self.supabase_client.initialize()
            
            # Синхронизируем админов из конфигурации
            await self.admin_manager.sync_admins_from_config()
            
            # Проверяем доступность промптов
            prompts_status = await self.prompt_loader.validate_prompts()
            logger.info(f"Статус промптов: {prompts_status}")
            
            # Устанавливаем глобальные переменные ДО импорта обработчиков
            import sys
            import importlib
            
            # Устанавливаем глобальные переменные в модулях handlers и admin_logic
            try:
                handlers_module = importlib.import_module('smart_bot_factory.handlers.handlers')
                handlers_module.config = self.config
                handlers_module.bot = bot
                handlers_module.dp = dp
                handlers_module.supabase_client = self.supabase_client
                handlers_module.openai_client = self.openai_client
                handlers_module.prompt_loader = self.prompt_loader
                handlers_module.admin_manager = self.admin_manager
                handlers_module.analytics_manager = self.analytics_manager
                handlers_module.conversation_manager = self.conversation_manager
                logger.info("✅ Глобальные переменные установлены в handlers")
            except Exception as e:
                logger.warning(f"⚠️ Не удалось установить глобальные переменные в handlers: {e}")
            
            try:
                admin_logic_module = importlib.import_module('smart_bot_factory.admin.admin_logic')
                admin_logic_module.config = self.config
                admin_logic_module.bot = bot
                admin_logic_module.dp = dp
                admin_logic_module.supabase_client = self.supabase_client
                admin_logic_module.openai_client = self.openai_client
                admin_logic_module.prompt_loader = self.prompt_loader
                admin_logic_module.admin_manager = self.admin_manager
                admin_logic_module.analytics_manager = self.analytics_manager
                admin_logic_module.conversation_manager = self.conversation_manager
                logger.info("✅ Глобальные переменные установлены в admin_logic")
            except Exception as e:
                logger.warning(f"⚠️ Не удалось установить глобальные переменные в admin_logic: {e}")
            
            # Также устанавливаем в bot_utils
            try:
                bot_utils_module = importlib.import_module('smart_bot_factory.core.bot_utils')
                bot_utils_module.config = self.config
                bot_utils_module.bot = bot
                bot_utils_module.dp = dp
                bot_utils_module.supabase_client = self.supabase_client
                bot_utils_module.openai_client = self.openai_client
                bot_utils_module.prompt_loader = self.prompt_loader
                bot_utils_module.admin_manager = self.admin_manager
                bot_utils_module.analytics_manager = self.analytics_manager
                bot_utils_module.conversation_manager = self.conversation_manager
                logger.info("✅ Глобальные переменные установлены в bot_utils")
            except Exception as e:
                logger.warning(f"⚠️ Не удалось установить глобальные переменные в bot_utils: {e}")
            
            # Также устанавливаем в debug_routing
            try:
                from ..utils import debug_routing
                debug_routing.config = self.config
                debug_routing.bot = bot
                debug_routing.dp = dp
                debug_routing.supabase_client = self.supabase_client
                debug_routing.openai_client = self.openai_client
                debug_routing.prompt_loader = self.prompt_loader
                debug_routing.admin_manager = self.admin_manager
                debug_routing.conversation_manager = self.conversation_manager
                logger.info("✅ Глобальные переменные установлены в debug_routing")
            except Exception as e:
                logger.warning(f"⚠️ Не удалось установить глобальные переменные в debug_routing: {e}")
            
            # Теперь импортируем и настраиваем обработчики
            from ..handlers.handlers import setup_handlers
            from ..admin.admin_logic import setup_admin_handlers
            from ..core.bot_utils import setup_utils_handlers
            
            # Настраиваем обработчики запросов
            setup_utils_handlers(dp)    # Утилитарные команды (/status, /help)
            setup_admin_handlers(dp)    # Админские команды (/админ, /стат, /чат)
            setup_handlers(dp)          # Основные пользовательские обработчики
            
            # Устанавливаем глобальные переменные в модуле бота для удобного доступа
            self.set_global_vars_in_module(self.bot_id)
            
            # Устанавливаем глобальные переменные в core.globals для внутреннего использования
            from ..core.globals import set_globals
            set_globals(
                supabase_client=self.supabase_client,
                openai_client=self.openai_client,
                config=self.config,
                admin_manager=self.admin_manager,
                analytics_manager=self.analytics_manager,
                conversation_manager=self.conversation_manager,
                prompt_loader=self.prompt_loader,
                bot=bot,
                dp=dp
            )
            
            # Устанавливаем клиенты в clients модуль для пользователей
            from ..clients import set_clients
            set_clients(
                supabase=self.supabase_client,
                openai=self.openai_client
            )
            
            # Устанавливаем роутер-менеджер в декораторы
            if self.router_manager:
                from ..core.decorators import set_router_manager
                set_router_manager(self.router_manager)
            
            # Фоновые задачи выполняются через asyncio.create_task в decorators.py
            
            # Логируем информацию о запуске
            logger.info(f"✅ Бот {self.bot_id} запущен и готов к работе!")
            logger.info(f"   📊 Изоляция данных: bot_id = {self.config.BOT_ID}")
            logger.info(f"   👑 Админов настроено: {len(self.config.ADMIN_TELEGRAM_IDS)}")
            logger.info(f"   📝 Загружено промптов: {len(self.config.PROMPT_FILES)}")
            
            # Четкое сообщение о запуске
            print(f"\n🤖 БОТ {self.bot_id.upper()} УСПЕШНО ЗАПУЩЕН!")
            print(f"📱 Telegram Bot ID: {self.config.BOT_ID}")
            print(f"👑 Админов: {len(self.config.ADMIN_TELEGRAM_IDS)}")
            print(f"📝 Промптов: {len(self.config.PROMPT_FILES)}")
            print(f"⏳ Ожидание сообщений...")
            print(f"⏹️ Для остановки нажмите Ctrl+C\n")
            
            # Запуск polling (бесконечная обработка сообщений)
            await dp.start_polling(bot)
            
        except Exception as e:
            logger.error(f"❌ Ошибка при запуске бота {self.bot_id}: {e}")
            import traceback
            logger.error(f"Стек ошибки: {traceback.format_exc()}")
            raise
        finally:
            # Очистка ресурсов при завершении
            if 'bot' in locals():
                await bot.session.close()
