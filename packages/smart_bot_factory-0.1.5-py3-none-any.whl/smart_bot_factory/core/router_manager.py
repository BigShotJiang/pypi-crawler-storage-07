"""
Менеджер роутеров для Smart Bot Factory
"""

from typing import Dict, List, Any, Optional
import logging
from .router import Router

logger = logging.getLogger(__name__)

class RouterManager:
    """
    Менеджер для управления роутерами и их обработчиками
    """
    
    def __init__(self):
        self._routers: List[Router] = []
        self._combined_handlers: Dict[str, Dict[str, Any]] = {
            'event_handlers': {},
            'scheduled_tasks': {},
            'global_handlers': {}
        }
        
        logger.info("🔄 Создан менеджер роутеров")
    
    def register_router(self, router: Router):
        """
        Регистрирует роутер в менеджере
        
        Args:
            router: Роутер для регистрации
        """
        if router not in self._routers:
            self._routers.append(router)
            self._update_combined_handlers()
            logger.info(f"✅ Зарегистрирован роутер: {router.name}")
        else:
            logger.warning(f"⚠️ Роутер {router.name} уже зарегистрирован")
    
    def unregister_router(self, router: Router):
        """
        Отменяет регистрацию роутера
        
        Args:
            router: Роутер для отмены регистрации
        """
        if router in self._routers:
            self._routers.remove(router)
            self._update_combined_handlers()
            logger.info(f"❌ Отменена регистрация роутера: {router.name}")
        else:
            logger.warning(f"⚠️ Роутер {router.name} не найден в зарегистрированных")
    
    def _update_combined_handlers(self):
        """Обновляет объединенные обработчики всех роутеров"""
        # Очищаем текущие обработчики
        self._combined_handlers = {
            'event_handlers': {},
            'scheduled_tasks': {},
            'global_handlers': {}
        }
        
        # Собираем обработчики из всех роутеров
        for router in self._routers:
            # Обработчики событий
            for event_type, handler_info in router.get_event_handlers().items():
                if event_type in self._combined_handlers['event_handlers']:
                    existing_router = self._combined_handlers['event_handlers'][event_type]['router']
                    logger.warning(f"⚠️ Конфликт обработчиков событий '{event_type}' между роутерами {existing_router} и {router.name}")
                self._combined_handlers['event_handlers'][event_type] = handler_info
            
            # Запланированные задачи
            for task_name, task_info in router.get_scheduled_tasks().items():
                if task_name in self._combined_handlers['scheduled_tasks']:
                    existing_router = self._combined_handlers['scheduled_tasks'][task_name]['router']
                    logger.warning(f"⚠️ Конфликт задач '{task_name}' между роутерами {existing_router} и {router.name}")
                self._combined_handlers['scheduled_tasks'][task_name] = task_info
            
            # Глобальные обработчики
            for handler_type, handler_info in router.get_global_handlers().items():
                if handler_type in self._combined_handlers['global_handlers']:
                    existing_router = self._combined_handlers['global_handlers'][handler_type]['router']
                    logger.warning(f"⚠️ Конфликт глобальных обработчиков '{handler_type}' между роутерами {existing_router} и {router.name}")
                self._combined_handlers['global_handlers'][handler_type] = handler_info
        
        total_handlers = (len(self._combined_handlers['event_handlers']) + 
                         len(self._combined_handlers['scheduled_tasks']) + 
                         len(self._combined_handlers['global_handlers']))
        
        logger.info(f"📊 Обновлены объединенные обработчики: {total_handlers} обработчиков из {len(self._routers)} роутеров")
    
    def get_event_handlers(self) -> Dict[str, Dict[str, Any]]:
        """Получает все обработчики событий"""
        return self._combined_handlers['event_handlers'].copy()
    
    def get_scheduled_tasks(self) -> Dict[str, Dict[str, Any]]:
        """Получает все запланированные задачи"""
        return self._combined_handlers['scheduled_tasks'].copy()
    
    def get_global_handlers(self) -> Dict[str, Dict[str, Any]]:
        """Получает все глобальные обработчики"""
        return self._combined_handlers['global_handlers'].copy()
    
    def get_all_handlers(self) -> Dict[str, Dict[str, Any]]:
        """Получает все обработчики всех типов"""
        all_handlers = {}
        all_handlers.update(self._combined_handlers['event_handlers'])
        all_handlers.update(self._combined_handlers['scheduled_tasks'])
        all_handlers.update(self._combined_handlers['global_handlers'])
        return all_handlers
    
    def get_handlers_for_prompt(self) -> str:
        """Возвращает описание всех обработчиков для добавления в промпт ИИ"""
        prompt_parts: List[str] = []
        
        if not any(self._combined_handlers.values()):
            return ""
        
        if self._combined_handlers['event_handlers']:
            prompt_parts.append("ДОСТУПНЫЕ ОБРАБОТЧИКИ СОБЫТИЙ:")
            for event_type, handler_info in self._combined_handlers['event_handlers'].items():
                router_name = handler_info.get('router', 'unknown')
                prompt_parts.append(f"- {event_type}: {handler_info['name']} (роутер: {router_name})")
        
        if self._combined_handlers['scheduled_tasks']:
            prompt_parts.append("\nДОСТУПНЫЕ ЗАДАЧИ ДЛЯ ПЛАНИРОВАНИЯ:")
            for task_name, task_info in self._combined_handlers['scheduled_tasks'].items():
                router_name = task_info.get('router', 'unknown')
                prompt_parts.append(f"- {task_name}: {task_info['name']} (роутер: {router_name})")
        
        if self._combined_handlers['global_handlers']:
            prompt_parts.append("\nДОСТУПНЫЕ ГЛОБАЛЬНЫЕ ОБРАБОТЧИКИ:")
            for handler_type, handler_info in self._combined_handlers['global_handlers'].items():
                router_name = handler_info.get('router', 'unknown')
                prompt_parts.append(f"- {handler_type}: {handler_info['name']} (роутер: {router_name})")
        
        return "\n".join(prompt_parts)
    
    def get_router_by_name(self, name: str) -> Optional[Router]:
        """Получает роутер по имени"""
        for router in self._routers:
            if router.name == name:
                return router
        return None
    
    def get_router_stats(self) -> Dict[str, Any]:
        """Получает статистику по роутерам"""
        stats = {
            "total_routers": len(self._routers),
            "routers": []
        }
        
        for router in self._routers:
            router_stats = {
                "name": router.name,
                "event_handlers": len(router.get_event_handlers()),
                "scheduled_tasks": len(router.get_scheduled_tasks()),
                "global_handlers": len(router.get_global_handlers())
            }
            stats["routers"].append(router_stats)
        
        return stats
    
    def __repr__(self):
        return f"RouterManager(routers={len(self._routers)}, handlers={len(self.get_all_handlers())})"
