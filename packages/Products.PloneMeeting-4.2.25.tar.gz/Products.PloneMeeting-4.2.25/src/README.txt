Packages in eggs that you develop should go in this directory
