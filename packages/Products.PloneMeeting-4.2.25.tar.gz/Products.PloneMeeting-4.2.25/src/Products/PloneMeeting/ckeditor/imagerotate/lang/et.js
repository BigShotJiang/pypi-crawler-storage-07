﻿CKEDITOR.plugins.setLang('imagerotate', 'et', {
  rotateRight: 'Pööra päripäeva',
  rotateLeft: 'Pööra vastupäeva',
  errorNoImage: "no image element?",
  errorNoDOMImage: "no DOM image element?",
  errorImageFromOtherDomain: "Image is from other domain and can't be rotated",
});
