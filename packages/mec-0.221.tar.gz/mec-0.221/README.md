
Repository for the math+econ+code package.

https://pypi.org/project/mec/

https://www.math-econ-code.org
