def hello() -> str:
    return "Hello from aws-helpers-python-lib!"
