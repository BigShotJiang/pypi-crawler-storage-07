// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
//
// Modifications Copyright (C) 2025, Advanced Micro Devices, Inc. All rights
// reserved.
//

#pragma once

#include "gsl/gsl"
