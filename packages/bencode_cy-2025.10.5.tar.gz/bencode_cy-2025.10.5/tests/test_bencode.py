import pytest
import sys
from pathlib import Path

from bencode import bencode, bdecode


@pytest.fixture
def tor():
    f = Path("tests/debian-mac-13.1.0-amd64-netinst.iso.torrent")
    return f.read_bytes()


def test_bencode():
    assert bencode("WWWWWW") == b"6:WWWWWW"
    assert bencode(233) == b"i233e"


def test_bdecode():
    assert bdecode(b"6:WWWWWW") == b"WWWWWW"
    assert bdecode(b"i233e") == 233


def test_torrent(tor):
    torrent = bdecode(tor)
    assert torrent[b"announce"] == b"http://bttracker.debian.org:6969/announce"
    assert tor == bencode(torrent)


def test_bdecode_benchmark(benchmark, tor):
    benchmark(bdecode, tor)


def test_bencode_benchmark(benchmark, tor):
    e2 = bdecode(tor)
    benchmark(bencode, e2)


def test_bdecode_py_benchmark(benchmark, tor):
    from bencode._bencode import bdecode

    benchmark(bdecode, tor)


def test_bencode_py_benchmark(benchmark, tor):
    from bencode._bencode import bdecode, bencode

    e2 = bdecode(tor)
    benchmark(bencode, e2)


@pytest.mark.skipif(sys.version_info >= (3, 12), reason="anything")
def test_bdecoder_pyx_benchmark(benchmark, tor):
    from bencoder import bdecode, bencode

    benchmark(bdecode, tor)


@pytest.mark.skipif(sys.version_info >= (3, 12), reason="anything")
def test_bencoder_pyx_benchmark(benchmark, tor):
    from bencoder import bdecode, bencode

    e2 = bdecode(tor)
    benchmark(bencode, e2)


def test_fastbencode_rust_benchmark(benchmark, tor):
    from fastbencode import bdecode, bencode

    benchmark(bdecode, tor)


def test_fastbdecode_rust_benchmark(benchmark, tor):
    from fastbencode import bdecode, bencode

    e2 = bdecode(tor)
    benchmark(bencode, e2)


def test_bencodepy_benchmark(benchmark, tor):
    from bencodepy import decode as bdecode

    benchmark(bdecode, tor)


def test_bdecodepy_benchmark(benchmark, tor):
    from bencodepy import decode as bdecode
    from bencodepy import encode as bencode

    e2 = bdecode(tor)
    benchmark(bencode, e2)


def test_better_bencode_benchmark(benchmark, tor):
    from better_bencode import loads as bdecode

    benchmark(bdecode, tor)


def test_better_bdecode_benchmark(benchmark, tor):
    from better_bencode import loads as bdecode
    from better_bencode import dumps as bencode

    e2 = bdecode(tor)
    benchmark(bencode, e2)

def test_bcoding_benchmark(benchmark, tor):
    from bcoding import bdecode, bencode

    e2 = bdecode(tor)
    benchmark(bencode, e2)


def test_bending_benchmark(benchmark, tor):
    from bcoding import bdecode, bencode

    benchmark(bdecode, tor)