

class NotAvailableForDownload(Exception):
    ...