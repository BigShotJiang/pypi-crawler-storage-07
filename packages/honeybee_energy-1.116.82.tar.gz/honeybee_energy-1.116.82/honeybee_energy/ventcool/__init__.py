"""honeybee-energy ventilative cooling definitions.

This includes opening windows, turning on fans, and other forms of deliberately
letting in outdoor air for cooling.
"""
