# -*- coding: utf-8; -*-
################################################################################
#
#  Rattail -- Retail Software Framework
#  Copyright © 2010-2022 Lance Edgar
#
#  This file is part of Rattail.
#
#  Rattail is free software: you can redistribute it and/or modify it under the
#  terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  Rattail is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
#  FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
#  details.
#
#  You should have received a copy of the GNU General Public License along with
#  Rattail.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
This subpackage contains logic for the Rattail "datasync" daemon.

For general info see :doc:`rattail-manual:data/sync/index`.
"""

from __future__ import unicode_literals, absolute_import

from .watchers import DataSyncWatcher
from .consumers import (DataSyncConsumer,
                        DataSyncImportConsumer,
                        # TODO: deprecate / remove this
                        NewDataSyncImportConsumer,
                        FromRattailConsumer)
from .rattail import FromRattailToRattailExportConsumer, FromRattailToRattailImportConsumer
