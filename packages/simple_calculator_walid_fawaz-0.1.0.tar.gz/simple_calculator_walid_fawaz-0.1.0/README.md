# simple-calculator-walid-fawaz

حزمة آلة حاسبة بسيطة لعمليات الرياضيات الأساسية.

## التثبيت

```bash
pip install simple-calculator-walid-fawaz
```

## الاستخدام

```python
from simple_calculator_walid_fawaz import add, subtract, multiply, divide

print(add(5, 3))      # Output: 8
print(subtract(5, 3)) # Output: 2
print(multiply(5, 3)) # Output: 15
print(divide(5, 3))   # Output: 1.666...
```

## الترخيص

هذا المشروع مرخص بموجب ترخيص MIT.
