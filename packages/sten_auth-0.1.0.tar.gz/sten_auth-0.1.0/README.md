# StenAuth

**StenAuth** is a Python module for universal authentication, OTP, admin management, and encrypted data storage.  
It provides a single package to handle login, user management, OTP, encrypted data storage, and both Web/CLI administration.

---

# StenAuth (한국어)

**StenAuth**는 Python용 범용 인증, OTP, 관리자 관리, 암호화 데이터 저장 모듈입니다.  
단일 패키지로 로그인, 사용자 관리, OTP, 암호화 데이터 저장, Web/CLI 관리까지 모두 지원합니다.

---

## 🔹 Key Features / 주요 기능

### 1. Authentication (Auth) / 인증
- Password authentication (SHA-256/HMAC + salt) / 비밀번호 인증 (SHA-256/HMAC + 솔트)
- OTP (TOTP) authentication, configurable expiration / OTP(TOTP) 인증, 만료 시간 조정 가능
- User-specific authentication method (password or OTP) / 사용자별 인증 방식 선택 가능 (PW / OTP)

### 2. Universal Data Storage / 범용 데이터 저장
- SQLite-based database / SQLite 기반 DB 관리
- Encrypted storage and automatic decryption on retrieval / 데이터 암호화 저장 / 조회 시 자동 복호화
- Simple functions to store/load data / 함수 호출만으로 저장/조회 가능

### 3. Admin Features / 관리자 기능
- Admin account management (CLI/Web) / Admin 계정 관리 (CLI/웹)
- Register/delete users, reset passwords and OTPs / 사용자 등록/삭제, 비밀번호 초기화, OTP 초기화
- View user list / 사용자 목록 조회

### 4. Web UI / 웹 UI
- Flask-based Web UI / Flask 기반 Web UI
- Session-based login protection / 세션 기반 로그인 보호
- Full admin features accessible after login / 로그인 후 모든 관리자 기능 사용 가능

### 5. CLI / CLI
- Admin account initialization/change / Admin 계정 초기화/변경
- User management (register, delete, reset password/OTP) / 사용자 등록/삭제, PW/OTP 초기화
- OTP secret generation and interval setting / OTP secret 생성 및 만료 시간 설정
- Store/load encrypted data / 범용 데이터 저장/조회 가능

---

## 🔹 Installation / 설치

```bash
pip install sten_auth
