from .auth import set_user_password, set_user_otp, register_user
from .storage import get_conn, store_data, load_data
import os

ADMIN_KEY = "_admin_account"

def set_admin_username(username: str):
    secret = os.urandom(16)
    store_data(ADMIN_KEY, f"{username}:{secret.hex()}")
    return secret.hex()

def set_admin_password(password: str):
    username, _ = load_data(ADMIN_KEY).split(":")
    set_user_password(username, password)

def verify_admin(username: str, password: str) -> bool:
    admin_data = load_data(ADMIN_KEY)
    if not admin_data:
        return False
    stored_username, _ = admin_data.split(":")
    if username != stored_username:
        return False
    return set_user_password(username, password) is not None

def reset_user_password(username: str, password: str):
    return set_user_password(username, password)

def reset_user_otp(username: str) -> str:
    return set_user_otp(username)

def list_users() -> list[str]:
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT username FROM users")
    users = [row[0] for row in c.fetchall()]
    conn.close()
    return users

def delete_user(username: str) -> bool:
    conn = get_conn()
    c = conn.cursor()
    c.execute("DELETE FROM users WHERE username=?", (username,))
    conn.commit()
    conn.close()
    return True
