from flask import Flask, request, session, redirect, render_template_string, flash
from sten_auth.admin import verify_admin, list_users, reset_user_password, reset_user_otp, delete_user

app = Flask(__name__)
app.secret_key = "super_secure_random_key" 

from functools import wraps
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get("admin_logged_in"):
            return redirect("/")
        return f(*args, **kwargs)
    return decorated_function

BASE_TEMPLATE = """
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}Admin Panel{% endblock %}</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .fade-in {
            animation: fadeIn 0.3s ease-out;
        }
    </style>
</head>
<body class="bg-gradient-to-br from-slate-50 to-slate-100 min-h-screen">
    {% block content %}{% endblock %}
</body>
</html>
"""

LOGIN_TEMPLATE = BASE_TEMPLATE.replace("{% block content %}{% endblock %}", """
    <div class="min-h-screen flex items-center justify-center p-4">
        <div class="bg-white rounded-2xl shadow-xl w-full max-w-md p-8 fade-in">
            <div class="text-center mb-8">
                <div class="inline-flex items-center justify-center w-16 h-16 bg-blue-600 rounded-full mb-4">
                    <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
                    </svg>
                </div>
                <h2 class="text-3xl font-bold text-slate-800">Admin Login</h2>
                <p class="text-slate-500 mt-2">관리자 계정으로 로그인하세요</p>
            </div>
            
            {% if error %}
            <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6 rounded fade-in">
                <div class="flex items-center">
                    <svg class="w-5 h-5 text-red-500 mr-2" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
                    </svg>
                    <p class="text-red-700 font-medium">{{ error }}</p>
                </div>
            </div>
            {% endif %}
            
            <form method="post" class="space-y-6">
                <div>
                    <label class="block text-sm font-semibold text-slate-700 mb-2">Username</label>
                    <input 
                        type="text" 
                        name="username" 
                        required
                        class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all outline-none"
                        placeholder="관리자 아이디 입력"
                    >
                </div>
                
                <div>
                    <label class="block text-sm font-semibold text-slate-700 mb-2">Password</label>
                    <input 
                        type="password" 
                        name="password" 
                        required
                        class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all outline-none"
                        placeholder="비밀번호 입력"
                    >
                </div>
                
                <button 
                    type="submit"
                    class="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-lg transition-colors duration-200 shadow-lg hover:shadow-xl"
                >
                    로그인
                </button>
            </form>
        </div>
    </div>
""")

USERS_TEMPLATE = BASE_TEMPLATE.replace("{% block content %}{% endblock %}", """
    <div class="min-h-screen p-4 md:p-8">
        <div class="max-w-6xl mx-auto">
             헤더 
            <div class="bg-white rounded-2xl shadow-lg p-6 mb-6 fade-in">
                <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div>
                        <h1 class="text-3xl font-bold text-slate-800">사용자 관리</h1>
                        <p class="text-slate-500 mt-1">전체 {{ user_count }}명의 사용자</p>
                    </div>
                    <a 
                        href="/logout"
                        class="inline-flex items-center justify-center px-6 py-3 bg-slate-600 hover:bg-slate-700 text-white font-semibold rounded-lg transition-colors duration-200 shadow-md hover:shadow-lg"
                    >
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                        </svg>
                        로그아웃
                    </a>
                </div>
            </div>
            
            {% if message %}
            <div class="bg-green-50 border-l-4 border-green-500 p-4 mb-6 rounded fade-in">
                <div class="flex items-center">
                    <svg class="w-5 h-5 text-green-500 mr-2" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                    </svg>
                    <p class="text-green-700 font-medium">{{ message }}</p>
                </div>
            </div>
            {% endif %}
            
             사용자 목록 
            <div class="bg-white rounded-2xl shadow-lg overflow-hidden fade-in">
                {% if users %}
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-slate-50 border-b border-slate-200">
                            <tr>
                                <th class="px-6 py-4 text-left text-sm font-semibold text-slate-700">사용자명</th>
                                <th class="px-6 py-4 text-right text-sm font-semibold text-slate-700">작업</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            {% for user in users %}
                            <tr class="hover:bg-slate-50 transition-colors">
                                <td class="px-6 py-4">
                                    <div class="flex items-center">
                                        <div class="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                                            <span class="text-blue-600 font-semibold text-sm">{{ user[0]|upper }}</span>
                                        </div>
                                        <span class="font-medium text-slate-800">{{ user }}</span>
                                    </div>
                                </td>
                                <td class="px-6 py-4">
                                    <div class="flex items-center justify-end gap-2">
                                        <a 
                                            href="/reset_pw?user={{ user }}"
                                            class="inline-flex items-center px-4 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 font-medium rounded-lg transition-colors duration-200"
                                        >
                                            <svg class="w-4 h-4 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/>
                                            </svg>
                                            PW 초기화
                                        </a>
                                        <a 
                                            href="/reset_otp?user={{ user }}"
                                            class="inline-flex items-center px-4 py-2 bg-amber-50 hover:bg-amber-100 text-amber-700 font-medium rounded-lg transition-colors duration-200"
                                        >
                                            <svg class="w-4 h-4 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
                                            </svg>
                                            OTP 초기화
                                        </a>
                                        <button 
                                            onclick="confirmDelete('{{ user }}')"
                                            class="inline-flex items-center px-4 py-2 bg-red-50 hover:bg-red-100 text-red-700 font-medium rounded-lg transition-colors duration-200"
                                        >
                                            <svg class="w-4 h-4 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                                            </svg>
                                            삭제
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            {% endfor %}
                        </tbody>
                    </table>
                </div>
                {% else %}
                <div class="p-12 text-center">
                    <svg class="w-16 h-16 text-slate-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
                    </svg>
                    <p class="text-slate-500 text-lg">등록된 사용자가 없습니다</p>
                </div>
                {% endif %}
            </div>
        </div>
    </div>
    
    <script>
        function confirmDelete(username) {
            if (confirm(`정말로 "${username}" 사용자를 삭제하시겠습니까?\\n\\n이 작업은 되돌릴 수 없습니다.`)) {
                window.location.href = `/delete?user=${encodeURIComponent(username)}`;
            }
        }
    </script>
""")

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        
        if not username or not password:
            return render_template_string(LOGIN_TEMPLATE, error="아이디와 비밀번호를 입력해주세요")
        
        if verify_admin(username, password):
            session["admin_logged_in"] = True
            session["admin_username"] = username
            return redirect("/users")
        
        return render_template_string(LOGIN_TEMPLATE, error="아이디 또는 비밀번호가 올바르지 않습니다")
    
    if session.get("admin_logged_in"):
        return redirect("/users")
    
    return render_template_string(LOGIN_TEMPLATE, error=None)

@app.route("/users")
@login_required
def users():
    users_list = list_users()
    message = request.args.get("message")
    return render_template_string(
        USERS_TEMPLATE, 
        users=users_list, 
        user_count=len(users_list),
        message=message
    )

@app.route("/reset_pw")
@login_required
def reset_pw():
    user = request.args.get("user")
    if user:
        try:
            reset_user_password(user)
            return redirect("/users?message=" + f"{user}의 비밀번호가 초기화되었습니다")
        except Exception as e:
            return redirect("/users?message=" + f"오류 발생: {str(e)}")
    return redirect("/users")

@app.route("/reset_otp")
@login_required
def reset_otp():
    user = request.args.get("user")
    if user:
        try:
            reset_user_otp(user)
            return redirect("/users?message=" + f"{user}의 OTP가 초기화되었습니다")
        except Exception as e:
            return redirect("/users?message=" + f"오류 발생: {str(e)}")
    return redirect("/users")

@app.route("/delete")
@login_required
def delete():
    user = request.args.get("user")
    if user:
        try:
            delete_user(user)
            return redirect("/users?message=" + f"{user} 사용자가 삭제되었습니다")
        except Exception as e:
            return redirect("/users?message=" + f"오류 발생: {str(e)}")
    return redirect("/users")

@app.route("/logout")
@login_required
def logout():
    session.clear()
    return redirect("/")

def run_web_ui():
    app.run(port=8765)