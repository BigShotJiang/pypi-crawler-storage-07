from .utils import hash_password, verify_password, generate_otp_secret, get_totp_token
from .storage import get_conn
import base64
import os

def register_user(username: str, password: str | None = None, otp: bool = False) -> str | None:
    conn = get_conn()
    c = conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS users (username TEXT PRIMARY KEY, password TEXT, salt BLOB, otp_secret TEXT, method TEXT)")
    if otp:
        secret = generate_otp_secret()
        c.execute("INSERT OR REPLACE INTO users (username, password, salt, otp_secret, method) VALUES (?, ?, ?, ?, ?)",
                  (username, None, None, secret, "otp"))
        conn.commit()
        conn.close()
        return secret
    elif password:
        hashed, salt = hash_password(password)
        c.execute("INSERT OR REPLACE INTO users (username, password, salt, otp_secret, method) VALUES (?, ?, ?, ?, ?)",
                  (username, hashed, salt, None, "password"))
        conn.commit()
        conn.close()
        return None
    conn.close()
    return None

def login_user(username: str, credential: str) -> bool:
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT password, salt, otp_secret, method FROM users WHERE username=?", (username,))
    row = c.fetchone()
    conn.close()
    if not row:
        return False
    password, salt, otp_secret, method = row
    if method == "password" and password and salt:
        return verify_password(credential, password, salt)
    elif method == "otp" and otp_secret:
        return credential == get_totp_token(otp_secret)
    return False

def set_user_password(username: str, password: str) -> bool:
    hashed, salt = hash_password(password)
    conn = get_conn()
    c = conn.cursor()
    c.execute("UPDATE users SET password=?, salt=?, method='password', otp_secret=NULL WHERE username=?", (hashed, salt, username))
    conn.commit()
    conn.close()
    return True

def set_user_otp(username: str) -> str | None:
    secret = generate_otp_secret()
    conn = get_conn()
    c = conn.cursor()
    c.execute("UPDATE users SET otp_secret=?, method='otp', password=NULL, salt=NULL WHERE username=?", (secret, username))
    conn.commit()
    conn.close()
    return secret
