import hashlib
import hmac
import os
import base64
import time

def hash_password(password: str, salt: bytes | None = None) -> tuple[str, bytes]:
    if salt is None:
        salt = os.urandom(16)
    pwd_hash = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 200_000)
    return base64.b64encode(pwd_hash).decode(), salt

def verify_password(password: str, stored_hash: str, salt: bytes) -> bool:
    h, _ = hash_password(password, salt)
    return h == stored_hash

def generate_otp_secret(length: int = 16) -> str:
    return base64.b32encode(os.urandom(length)).decode('utf-8').rstrip('=')

def get_totp_token(secret: str, interval: int = 30) -> str:
    key = base64.b32decode(secret + '=' * ((8 - len(secret) % 8) % 8))
    t = int(time.time() / interval)
    msg = t.to_bytes(8, 'big')
    h = hmac.new(key, msg, hashlib.sha1).digest()
    o = h[-1] & 0x0F
    token = (int.from_bytes(h[o:o+4], 'big') & 0x7FFFFFFF) % 1000000
    return f"{token:06d}"
