import sqlite3
import os
from cryptography.fernet import Fernet

DB_FILE = "sten_auth.db"
KEY_FILE = "sten_key.key"

if not os.path.exists(KEY_FILE):
    key = Fernet.generate_key()
    with open(KEY_FILE, "wb") as f:
        f.write(key)
else:
    with open(KEY_FILE, "rb") as f:
        key = f.read()

fernet = Fernet(key)

def get_conn():
    conn = sqlite3.connect(DB_FILE)
    return conn

def store_data(key: str, value: str):
    conn = get_conn()
    c = conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS data (key TEXT PRIMARY KEY, value TEXT)")
    encrypted = fernet.encrypt(value.encode()).decode()
    c.execute("REPLACE INTO data (key, value) VALUES (?, ?)", (key, encrypted))
    conn.commit()
    conn.close()

def load_data(key: str) -> str:
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT value FROM data WHERE key=?", (key,))
    row = c.fetchone()
    conn.close()
    if row:
        return fernet.decrypt(row[0].encode()).decode()
    return None
