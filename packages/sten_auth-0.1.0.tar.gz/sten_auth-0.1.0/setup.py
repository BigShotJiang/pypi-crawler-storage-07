from setuptools import setup, find_packages

setup(
    name="sten_auth",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "Flask>=2.3",
        "cryptography>=41.0"
    ],
    python_requires=">=3.11",
    description="StenAuth: Secure Python authentication & data storage module",
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "License :: OSI Approved :: MIT License",
        "Development Status :: 4 - Beta",
        "Topic :: Security :: Cryptography",
    ],
)
