from . import app

__ALL__ = [app]
