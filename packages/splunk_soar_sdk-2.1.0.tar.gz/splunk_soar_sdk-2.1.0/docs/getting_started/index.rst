.. _getting_started_index:

Getting Started
===============

In this section we will guide you through the basic process of creating your first Splunk SOAR App.

.. toctree::
    :maxdepth: 4

    installation
    init_app
    defining_asset
    first_action
    testing_and_building
