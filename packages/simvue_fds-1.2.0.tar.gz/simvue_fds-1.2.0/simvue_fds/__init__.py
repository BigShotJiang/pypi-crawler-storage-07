"""FDS Connector.

This module provides functionality for the easy tracking and monitoring of  FDS simulations with Simvue.
"""
