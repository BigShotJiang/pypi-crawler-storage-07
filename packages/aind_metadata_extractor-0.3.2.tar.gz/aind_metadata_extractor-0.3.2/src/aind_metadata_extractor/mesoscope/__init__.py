"""mesoscope metadata extractor"""
