# -*- coding: utf-8 -*-

from .caster import pinpoint_email_caster

caster = pinpoint_email_caster

__version__ = "1.40.0"