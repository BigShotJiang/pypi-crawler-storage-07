# -*- coding: utf-8 -*-

from .caster import inspector_scan_caster

caster = inspector_scan_caster

__version__ = "1.40.0"