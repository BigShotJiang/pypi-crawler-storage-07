# src/eida_consistency/utils/constants.py
USER_AGENT = "eida-consistency"
