# pycalcpp
Calculadora matemática de alto rendimiento: núcleo en C++ (pybind11) y wrapper Python.

## Instalación
```bash
pip install pycalcpp