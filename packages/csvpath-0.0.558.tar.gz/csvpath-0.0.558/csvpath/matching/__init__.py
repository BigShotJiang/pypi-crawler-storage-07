""" this module implements the match part of a csvpath string """
