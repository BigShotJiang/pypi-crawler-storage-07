.. _spkg_gdbm:

gdbm: GNU database manager
==========================


Type
----

optional


Dependencies
------------




Installation commands
---------------------

.. tab:: Sage distribution:

   This is a dummy package and cannot be installed using the Sage distribution.

.. tab:: Alpine:

   .. CODE-BLOCK:: bash

       $ apk add gdbm-dev

.. tab:: Arch Linux:

   .. CODE-BLOCK:: bash

       $ sudo pacman -S gdbm

.. tab:: conda-forge:

   .. CODE-BLOCK:: bash

       $ conda install gdbm

.. tab:: Debian/Ubuntu:

   .. CODE-BLOCK:: bash

       $ sudo apt-get install libgdbm-dev

.. tab:: Fedora/Redhat/CentOS:

   .. CODE-BLOCK:: bash

       $ sudo dnf install gdbm-devel

.. tab:: FreeBSD:

   .. CODE-BLOCK:: bash

       $ sudo pkg install databases/gdbm

.. tab:: Gentoo Linux:

   .. CODE-BLOCK:: bash

       $ sudo emerge sys-libs/gdbm

.. tab:: Homebrew:

   .. CODE-BLOCK:: bash

       $ brew install gdbm

.. tab:: Nixpkgs:

   .. CODE-BLOCK:: bash

       $ nix-env -f \'\<nixpkgs\>\' --install --attr gdbm

.. tab:: openSUSE:

   .. CODE-BLOCK:: bash

       $ sudo zypper install gdbm

.. tab:: Slackware:

   .. CODE-BLOCK:: bash

       $ sudo slackpkg install gdbm

.. tab:: Void Linux:

   .. CODE-BLOCK:: bash

       $ sudo xbps-install gdbm-devel


If the system package is installed, ``./configure`` will check if it can be used.
