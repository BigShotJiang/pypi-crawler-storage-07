from . import project_project
from . import project_stakeholder
from . import project_stakeholder_role
from . import res_partner
