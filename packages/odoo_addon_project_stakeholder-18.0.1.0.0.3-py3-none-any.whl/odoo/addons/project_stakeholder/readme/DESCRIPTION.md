This module allows project stakeholders management:

* Add stakeholders on a project, with role and notes.
* Define and manage stakeholder roles.
* View project involvements of a stakeholder from the partner form.
