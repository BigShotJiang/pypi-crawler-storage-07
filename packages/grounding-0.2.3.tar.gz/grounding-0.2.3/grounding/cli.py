"""Command-line interface for the Grounding tooling."""

from __future__ import annotations

import sys
import typer
from rich.console import Console
from rich.panel import Panel
import questionary
from typing import Optional

from . import __version__
from .commands.auth import auth_app, login, logout, status
from .commands.configure import config_app, supabase, show
from .commands.agent import (
    agent_app, list_agents, create, forget, config as agent_config,
    import_token, revoke, update_label, rotate, set_billing
)
from .commands.server import server_app, start

app = typer.Typer(help="Grounding CLI", rich_markup_mode="markdown")
console = Console()

app.add_typer(auth_app, name="auth")
app.add_typer(config_app, name="config")
app.add_typer(agent_app, name="agent")
app.add_typer(server_app, name="server")

# Menu style
MENU_STYLE = questionary.Style([
    ('selected', 'bold'),
    ('pointer', 'bold'),
    ('highlighted', 'bold'),
])


def show_auth_menu() -> bool:
    """Show auth submenu and execute selected command. Returns True to continue, False to exit."""
    console.print()
    choices = [
        "login - Authenticate with Grounding",
        "logout - Clear stored session",
        "status - Show current auth status",
        "← back - Return to main menu"
    ]

    selection = questionary.select(
        "Auth commands:",
        choices=choices,
        style=MENU_STYLE,
        qmark=""
    ).ask()

    if selection is None or "back" in selection:
        return True

    command = selection.split(" - ")[0]
    console.print()

    try:
        if command == "login":
            login(
                supabase_url=None,
                provider="github",
                scopes="openid email",
                client_id=None,
                no_browser=False,
                manual=False
            )
        elif command == "logout":
            logout()
        elif command == "status":
            status()
    except typer.Exit:
        pass

    return True


def show_config_menu() -> bool:
    """Show config submenu and execute selected command. Returns True to continue, False to exit."""
    console.print()
    choices = [
        "supabase - Configure Supabase connection",
        "show - Display current configuration",
        "← back - Return to main menu"
    ]

    selection = questionary.select(
        "Config commands:",
        choices=choices,
        style=MENU_STYLE,
        qmark=""
    ).ask()

    if selection is None or "back" in selection:
        return True

    command = selection.split(" - ")[0]
    console.print()

    try:
        if command == "supabase":
            url = questionary.text("Supabase URL (leave empty to use default):").ask()
            anon_key = questionary.text("Supabase anon key (optional):").ask()
            supabase(
                url=url if url and url.strip() else None,
                anon_key=anon_key if anon_key and anon_key.strip() else None
            )
        elif command == "show":
            show()
    except typer.Exit:
        pass

    return True


def show_agent_menu() -> bool:
    """Show agent submenu and execute selected command. Returns True to continue, False to exit."""
    console.print()
    choices = [
        "list - List stored agent tokens",
        "create - Create a new agent token",
        "forget - Remove a token from local storage",
        "config - Show MCP client configuration",
        "import - Import an existing token",
        "revoke - Revoke a token",
        "update-label - Update token label",
        "rotate - Rotate a token",
        "set-billing - Change billing mode",
        "← back - Return to main menu"
    ]

    selection = questionary.select(
        "Agent commands:",
        choices=choices,
        style=MENU_STYLE,
        qmark=""
    ).ask()

    if selection is None or "back" in selection:
        return True

    command = selection.split(" - ")[0]
    console.print()

    try:
        if command == "list":
            remote = questionary.confirm("Query remote tokens from Supabase?", default=False).ask()
            show_billing = questionary.confirm("Show billing mode for each token?", default=False).ask()
            list_agents(remote=remote, show_billing=show_billing)
        elif command == "create":
            name = questionary.text("Agent name:").ask()
            if name and name.strip():
                label = questionary.text("Label (optional, visible in dashboard):").ask()
                note = questionary.text("Note (optional, stored locally):").ask()
                create(
                    name=name,
                    label=label if label and label.strip() else None,
                    note=note if note and note.strip() else None,
                    store=True,
                    billing_mode=None  # Will be prompted interactively in the create function
                )
        elif command == "forget":
            name = questionary.text("Agent name to remove:").ask()
            if name and name.strip():
                forget(name=name)
        elif command == "config":
            name = questionary.text("Agent name:").ask()
            if name and name.strip():
                format_choice = questionary.select(
                    "Output format:",
                    choices=["claude-desktop", "cline", "vscode", "openai", "anthropic", "gemini", "generic"],
                    default="claude-desktop",
                    qmark=""
                ).ask()
                agent_config(name=name, format=format_choice, endpoint="https://api.grounding.dev/mcp")
        elif command == "import":
            name = questionary.text("Friendly name for this token:").ask()
            if name and name.strip():
                token = questionary.text("Full token string:").ask()
                if token and token.strip():
                    note = questionary.text("Note (optional):").ask()
                    import_token(
                        name=name,
                        token=token,
                        note=note if note and note.strip() else None
                    )
        elif command == "revoke":
            name = questionary.text("Agent name to revoke:").ask()
            if name and name.strip():
                forget_local = questionary.confirm("Remove from local storage too?", default=True).ask()
                revoke(name=name, forget_local=forget_local)
        elif command == "update-label":
            name = questionary.text("Agent name:").ask()
            if name and name.strip():
                label = questionary.text("New label:").ask()
                if label and label.strip():
                    update_label(name=name, label=label)
        elif command == "rotate":
            name = questionary.text("Agent name to rotate:").ask()
            if name and name.strip():
                note = questionary.text("Note for new token (optional):").ask()
                rotate(name=name, note=note if note and note.strip() else None)
        elif command == "set-billing":
            name = questionary.text("Agent name:").ask()
            if name and name.strip():
                mode = questionary.select(
                    "Billing mode:",
                    choices=["subscription", "credits"],
                    qmark=""
                ).ask()
                set_billing(name=name, mode=mode)
    except typer.Exit:
        pass

    return True


def show_server_menu() -> bool:
    """Show server submenu and execute selected command. Returns True to continue, False to exit."""
    console.print()
    choices = [
        "start - Start the local MCP server",
        "← back - Return to main menu"
    ]

    selection = questionary.select(
        "Server commands:",
        choices=choices,
        style=MENU_STYLE,
        qmark=""
    ).ask()

    if selection is None or "back" in selection:
        return True

    command = selection.split(" - ")[0]
    console.print()

    try:
        if command == "start":
            agent = questionary.text("Agent name (optional, press Enter to skip):").ask()
            host = questionary.text("Host:", default="127.0.0.1").ask()
            port = questionary.text("Port:", default="3000").ask()
            start(
                agent=agent if agent and agent.strip() else None,
                token=None,
                host=host,
                port=int(port),
                install_dependencies=True
            )
    except typer.Exit:
        pass

    return True


def show_main_menu(show_welcome: bool = True) -> bool:
    """Display main interactive menu and handle user selection. Returns True to continue, False to exit."""
    if show_welcome:
        console.print(Panel(
            " [blink]*[/blink] [bold cyan]Welcome to Grounding CLI[/bold cyan] ",
            border_style="cyan",
            padding=(1, 0),
            expand=False
        ))
        console.print()
    else:
        # Add spacing between command output and menu
        console.print("\n")

    choices = [
        "auth - Authentication commands",
        "config - Configuration commands",
        "agent - Agent commands",
        "server - MCP server commands",
        "version - Show version information",
        "exit - Exit the CLI"
    ]

    selection = questionary.select(
        "What would you like to do?",
        choices=choices,
        style=MENU_STYLE,
        qmark=""
    ).ask()

    if selection is None or "exit" in selection:
        return False

    command = selection.split(" - ")[0]

    if command == "version":
        console.print(f"\nGrounding CLI version [bold]{__version__}[/bold]\n")
        return True
    elif command == "auth":
        return show_auth_menu()
    elif command == "config":
        return show_config_menu()
    elif command == "agent":
        return show_agent_menu()
    elif command == "server":
        return show_server_menu()

    return True


def interactive_mode() -> None:
    """Run the interactive menu in a loop."""
    # Show welcome panel only once
    first_run = True

    while True:
        try:
            if not show_main_menu(show_welcome=first_run):
                console.print("\n[dim]Goodbye![/dim]")
                break
            first_run = False
        except KeyboardInterrupt:
            console.print("\n[dim]Goodbye![/dim]")
            break
        except Exception as e:
            console.print(f"\n[red]Error:[/red] {e}")
            console.print()


@app.callback(invoke_without_command=True)
def main_callback(ctx: typer.Context) -> None:
    """Top-level callback to ensure the CLI initialises."""
    # If no subcommand was invoked, show the interactive menu
    if ctx.invoked_subcommand is None:
        interactive_mode()


@app.command()
def version() -> None:
    """Print the installed CLI version."""

    console.print(f"Grounding CLI version [bold]{__version__}[/bold]")


if __name__ == "__main__":
    app()
