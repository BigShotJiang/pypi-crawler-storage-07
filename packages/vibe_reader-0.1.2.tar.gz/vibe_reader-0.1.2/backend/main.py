from pathlib import Path
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from backend.tmux import router as tmux_router
from backend.files import router as files_router

app = FastAPI()

# Include routers
app.include_router(tmux_router)
app.include_router(files_router)

# Determine frontend directory path (works in both dev and installed package)
FRONTEND_DIR = Path(__file__).parent.parent / "frontend"

# Serve frontend
app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")

@app.get("/")
async def root():
    return FileResponse(str(FRONTEND_DIR / "index.html"))

def main():
    import uvicorn
    uvicorn.run("backend.main:app", host="0.0.0.0", port=28000)

if __name__ == "__main__":
    main()
