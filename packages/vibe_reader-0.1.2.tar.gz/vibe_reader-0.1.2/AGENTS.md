# Repository Guidelines

## Project Structure & Module Organization
- `backend/`: FastAPI routers (`main.py`, `tmux.py`, `files.py`) and any new backend utilities.
- `frontend/`: eink UI assets (`index.html`, `app.js`, `styles.css`) with vanilla JS and utility-first CSS.
- `src/vibe_reader/`: packaging glue and shared Python modules; keep type markers here.
- `tests/`: mirror backend modules with `test_*` files (e.g., `tests/test_tmux.py`, `tests/test_files.py`).

## Build, Test, and Development Commands
- `uv sync`: install project dependencies (add `HTTP(S)_PROXY` env vars when required).
- `uv run uvicorn backend.main:app --host 0.0.0.0 --port 28000 --reload`: local dev server with hot reload.
- `uv run uvicorn backend.main:app --host 0.0.0.0 --port 28000`: production preview.
- `uv run pytest`: execute the test suite once pytest is listed under dev dependencies.

## Coding Style & Naming Conventions
- Python: 3.10+, four-space indents, type hints, and FastAPI error handling via `HTTPException`.
- JavaScript: keep DOM refs camelCase at the top of `frontend/app.js`; stay framework-free.
- CSS: high-contrast, animation-free styles optimized for eink; prefer reusable utility classes.
- Share helpers across routers via dedicated modules in `backend/`.

## Testing Guidelines
- Use `pytest` with `pytest-asyncio` for coroutine coverage; mock `libtmux.Server`.
- Target ≥80% coverage on new paths; assert edge cases (empty tmux sessions, missing panes, binary file rejection).
- Name tests `test_*` and keep fixtures local when possible.

## Commit & Pull Request Guidelines
- Commit subjects: imperative mood (“Add scrollback scrollbar”); include brief bodies for behavior changes.
- Reference issues with `Fixes #123` when applicable.
- PRs should summarize intent, list validation steps (`uv run pytest`, tmux capture checks, file browser smoke tests), and include eink UI screenshots for frontend tweaks.
- Request cross-review when touching both backend and frontend layers.

## Security & Configuration Tips
- Expose the backend only behind VPN/SSH; never ship tmux without access controls.
- Keep proxy env vars out of committed scripts.
- Document new flags in `README.md` and surface user-configurable options in the Config view.
