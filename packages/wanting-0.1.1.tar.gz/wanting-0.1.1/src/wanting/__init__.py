"""The Wanting package."""

__version__ = "0.1.1"
