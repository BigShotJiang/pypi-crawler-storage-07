Wanting
#######

Wanting is a library for creating, and working with models that may have
incomplete information.

