FEATURES_EXTRACTION_MODULE = "neurokin.utils.features_extraction."
VALID_EXTRACTION_TARGETS = ["markers", "joints", "misc"]