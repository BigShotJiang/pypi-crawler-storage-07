"""captcha_ocr_devkit package metadata."""

__version__ = "1.20250921.926"
__all__ = ["__version__"]
