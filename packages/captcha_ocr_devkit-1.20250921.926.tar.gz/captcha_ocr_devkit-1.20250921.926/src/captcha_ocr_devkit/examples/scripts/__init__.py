"""Example shell scripts for captcha-ocr-devkit."""
