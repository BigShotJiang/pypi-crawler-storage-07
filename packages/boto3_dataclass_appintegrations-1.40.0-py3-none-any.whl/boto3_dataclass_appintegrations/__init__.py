# -*- coding: utf-8 -*-

from .caster import appintegrations_caster

caster = appintegrations_caster

__version__ = "1.40.0"