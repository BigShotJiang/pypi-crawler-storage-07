class Broca:
    def __init__(self):
        pass

__all__ = ['Broca']