from .cli.cli import main

# test with: python -m blueapi
if __name__ == "__main__":
    main()
