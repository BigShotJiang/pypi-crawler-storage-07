"""Contributed 'recipes'"""
