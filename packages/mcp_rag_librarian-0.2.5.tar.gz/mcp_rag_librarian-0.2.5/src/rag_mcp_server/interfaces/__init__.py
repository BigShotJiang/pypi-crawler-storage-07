"""
Interfaces package for SOLID principles compliance.
"""
