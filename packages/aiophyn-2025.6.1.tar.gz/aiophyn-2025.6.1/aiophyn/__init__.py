"""Define the aiophyn package."""
from .api import async_get_api
