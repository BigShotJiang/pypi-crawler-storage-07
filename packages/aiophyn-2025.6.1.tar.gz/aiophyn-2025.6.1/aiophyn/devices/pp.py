
from ..device import Device

class PhynPlus(Device):
    
    def set_
    
