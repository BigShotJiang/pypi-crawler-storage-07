# -*- coding: utf-8 -*-
from setuptools import setup

setup(
    name='pylocalauth',
    version='1.0.1',
    description='Cross-platform local authentication library for Python applications.',
    long_description='<p align="center">\n  <kbd><img src="https://raw.githubusercontent.com/AppSolves/pylocalauth/refs/heads/main/assets/github/repo_card.png?sanitize=true" alt="pylocalauth"></kbd>\n</p>\n<br>\n\n# `pylocalauth`\n\n<p align="center">Cross-platform local authentication library for Python applications.</p>\n<br>\n\n[![build](https://github.com/AppSolves/pylocalauth/workflows/Build/badge.svg)](https://github.com/AppSolves/pylocalauth/actions)\n[![PyPI version](https://badge.fury.io/py/pylocalauth.svg)](https://badge.fury.io/py/pylocalauth)\n[![Downloads](https://pepy.tech/badge/pylocalauth)](https://pepy.tech/project/pylocalauth)\n\n---\n\n**Documentation**: <a href="https://github.com/AppSolves/pylocalauth/blob/main/README.md" target="_blank">README</a>\n\n**Source Code**: <a href="https://github.com/AppSolves/pylocalauth" target="_blank">Repository</a>\n\n---\n\nAdd local authentication to your Python applications with ease. `pylocalauth` provides a simple and secure way to authenticate users using platform-specific methods such as passwords, biometrics, and PINs.\n\n## Features\n\n| Feature | Status |\n|---------|:------:|\n| **Cross-platform**: Works on Windows, macOS, and Linux. (*macOS is still in beta, but it should work reliably*) | ✅ |\n| **Multiple authentication methods**: Supports password-based, biometric (Windows Hello, Touch ID, etc.), and PIN-based authentication. | ✅ |\n| **Easy integration**: Simple API for integrating local authentication into your Python applications. | ✅ |\n| **Secure**: Utilizes platform-specific security features to ensure user data is protected. | ✅ |\n| **Lightweight**: Minimal dependencies and easy to install. | ✅ |\n\n<br>\n<table>\n  <tr>\n    <td align="center"><b>Windows Example</b></td>\n    <td align="center"><b>Linux Example</b></td>\n  </tr>\n  <tr>\n    <td align="center">\n      <kbd>\n        <img src="https://raw.githubusercontent.com/AppSolves/pylocalauth/refs/heads/main/assets/usage/windows.png?sanitize=true" alt="Windows Example" width="400"/>\n      </kbd>\n    </td>\n    <td align="center">\n      <kbd>\n        <img src="https://raw.githubusercontent.com/AppSolves/pylocalauth/refs/heads/main/assets/usage/linux.png?sanitize=true" alt="Linux Example" width="400"/>\n      </kbd>\n    </td>\n  </tr>\n</table>\n<br>\n\n## Installation\n\nYou can install `pylocalauth` via pip:\n\n```bash\npip install pylocalauth --upgrade\n```\n\n## Usage\n\nHere\'s a very simple example of how to use `pylocalauth` to authenticate a user:\n\n```python\nfrom pylocalauth import authenticate # Import the authenticate function for your platform\nresult = authenticate()\nif result:\n    print("Authentication successful!")\nelse:\n    print("Authentication failed.")\n```\n\nYou can also customize the message displayed during authentication:\n\n```python\nfrom pylocalauth import authenticate\nresult = authenticate(message="Please authenticate to proceed.")\n```\n\nBy default, `pylocalauth` will raise an `AuthUnavailableError` if authentication is not available on the current platform. You can disable this behavior by setting the `check_availability` parameter to `False` (You should only do this if you plan to handle the unavailability yourself):\n\n```python\nfrom pylocalauth import authenticate, is_available\nfrom pylocalauth.exceptions import AuthError, AuthUnavailableError\n\n# Let it handle availability automatically\ntry:\n    result = authenticate(check_availability=True) # default\n    print(f"Authentication successful?: {result}")\nexcept AuthUnavailableError:\n    print("Authentication is not available on this platform.")\nexcept AuthError as e:\n    print(f"An error occurred: {e}")\n\n# Handle availability yourself\ntry:\n    if not is_available():\n        print("Authentication is not available on this platform.")\n    else:\n        result = authenticate(check_availability=False)\n        print(f"Authentication successful?: {result}")\nexcept AuthError as e:\n    print(f"An error occurred: {e}")\n```\n\n## Contributing\n\nWe welcome contributions from the community! If you\'d like to contribute, please follow the steps explained in the [CONTRIBUTORS](CONTRIBUTORS.md) file.\n\n#### Contributions Needed\n\nWe are especially looking for help with the following:\n\n- **macOS support:** Testing, bug reports, and improvements for the macOS backend.\n- **Documentation & Tests:** Examples, API docs, tests (using `pytest` and `pytest-asyncio`) and usage guides.\n- **CI/CD:** Enhancements to cross-platform test automation.\n- **New authentication methods:** Suggestions or PRs for additional local authentication backends.\n- **Issue triage:** Help us reproduce and resolve open issues.\n\nIf you want to help, please see [CONTRIBUTORS](CONTRIBUTORS.md) and open an issue or pull request!\n\n## Development\n\n### Setup environment\n\nWe use [Hatch](https://hatch.pypa.io/latest/install/) to manage the development environment and production build. Ensure it\'s installed on your system.\n\n### Run unit tests\n\nYou can run all the tests with:\n\n```bash\nhatch run test\n```\n\n### Format the code\n\nExecute the following command to apply `isort` and `black` formatting:\n\n```bash\nhatch run lint\n```\n\n## License\n\nThis project is licensed under the terms of the Apache 2.0 license.\nSee the [LICENSE](LICENSE) file for more information.',
    author_email='Kaan Gönüldinc <contact@appsolves.dev>',
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Framework :: AsyncIO',
        'Framework :: Hatch',
        'Framework :: Pytest',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3 :: Only',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Programming Language :: Python :: 3.13',
        'Topic :: System :: Systems Administration :: Authentication/Directory',
    ],
    install_requires=[
        'pyobjc-framework-localauthentication; sys_platform == "darwin"',
        'pyobjc; sys_platform == "darwin"',
        'python-pam; sys_platform == "linux"',
        'six; sys_platform == "linux"',
        'winrt-windows-foundation; sys_platform == "win32"',
        'winrt-windows-security-credentials-ui; sys_platform == "win32"',
    ],
    packages=[
        'pylocalauth',
        'pylocalauth.platforms',
    ],
)
