# Practical 1
from .practical1 import a, a1, a2, a3, a4

# Practical 2
from .practical2 import b, b1, b2, b3, b4, b5

# Practical 3
from .practical3 import c, c1, c2, c3, c4, c5, c6, c7, c8

# Practical 4
from .practical4 import d, d1, d2, d3, d4, d5

# Practical 5
from .practical5 import e, e1, e2, e3, e4

# Practical 6
from .practical6 import f, f1, f2, f3, f4, f5

# Practical 7
from .practical7 import g, g1, g2, g3, g4

# Practical 8
from .practical8 import h, h1, h2, h3, h4, h5, h6, h7
