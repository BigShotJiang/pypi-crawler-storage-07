"""
Common service interfaces and base classes used across Strala applications.
"""

__all__ = []
