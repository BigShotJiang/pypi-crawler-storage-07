"""
Common schemas and data models used across Strala applications.
"""

from .base import BaseModel

__all__ = [
    "BaseModel",
]
