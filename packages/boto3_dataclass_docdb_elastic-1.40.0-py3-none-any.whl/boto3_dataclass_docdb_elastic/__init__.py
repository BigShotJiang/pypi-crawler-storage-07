# -*- coding: utf-8 -*-

from .caster import docdb_elastic_caster

caster = docdb_elastic_caster

__version__ = "1.40.0"