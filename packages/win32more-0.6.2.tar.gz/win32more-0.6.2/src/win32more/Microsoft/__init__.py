# Initialize WindowsAppSDK
import win32more.appsdk.mddbootstrap

win32more.appsdk.mddbootstrap.initialize()
