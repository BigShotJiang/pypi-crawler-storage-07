"""Base Node Stages."""
