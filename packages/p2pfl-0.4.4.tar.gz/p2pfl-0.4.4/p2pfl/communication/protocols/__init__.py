"""Communication protocol module."""
