"""Weights commands module."""
