"""casampi tests"""
