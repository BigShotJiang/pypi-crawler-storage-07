"""MySQL MCP Server - AI-friendly MySQL database operations."""

__version__ = "0.2.3"