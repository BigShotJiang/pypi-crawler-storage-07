# Automation Toolkit

基于uiautomator2的自动化测试工具包，提供设备控制、元素定位、图像识别等功能。

## 安装

```bash
pip install automation-toolkit