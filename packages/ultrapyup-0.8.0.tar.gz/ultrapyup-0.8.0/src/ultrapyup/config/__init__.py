from ultrapyup.config.ruff import ruff_config_setup
from ultrapyup.config.ty import ty_config_setup


__all__ = ["ruff_config_setup", "ty_config_setup"]
