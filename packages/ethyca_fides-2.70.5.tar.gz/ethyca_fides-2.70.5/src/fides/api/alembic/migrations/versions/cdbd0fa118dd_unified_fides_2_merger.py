"""unified fides 2 merger

Revision ID: cdbd0fa118dd
Revises: 6f98e1bd7e4f, cf88efa1ad89
Create Date: 2022-09-28 16:27:25.429064

"""

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision = "cdbd0fa118dd"
down_revision = ("6f98e1bd7e4f", "cf88efa1ad89")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
