### Stability (v1.0)

- Expand testing suite
- Ensure robustness
- Stress test
- GUI release

### Roving

- Add ability for roving CRNS data processing

### External Data Integration
- SoilGridsv2
- Google Earth Engine


### Docker/Server neptoon

- Dockerized versions of neptoon
- Server version (restAPI) for automatic updates hour by hour