

## Figures
1. Describe base figure structure


## 
1. Describe Magazine implementation