Most of our internal development is undertaken on our insitution GitLab instance (https://codebase.helmholtz.cloud/cosmos/neptoon). This is due to the benefits (particularly CICD) we get with this. However we are very open to contributions. 

If you are interested in contributing, we would recommend to you to fork the repository on our public repo: www.gitlab.com/neptoon/neptoon

This public repository mirrors the main and development branchs, so you can be sure you will be forking the most current versions. So make a fork here

Check out the [Contribution Guidelines](https://codebase.helmholtz.cloud/cosmos/neptoon/-/blob/main/CONTRIBUTING.md?ref_type=heads) for some help on getting going.

Any issues please contact contact@neptoon.org