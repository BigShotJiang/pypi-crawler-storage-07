
import pandas as pd
import matplotlib.pyplot as plt

class Summarizer:
    def __init__(self, df: pd.DataFrame, histPlotDistinctCount: int=20) -> None:
        self.__df = df
        self.__histPlotDistinctCount = histPlotDistinctCount

    def run(self) -> None:
        print ("### WARN: Not handling null values")
        print ("Dimensions:", self.__df.shape)
        
        for col in self.__df.columns:
            colDataType = self.__df[col].dtype
            print ("\n-->", col, "| DataType->", colDataType)
            print ("Count null:", self.__df[col].isnull().sum())
            
            if colDataType in ['int64']:
                print ("Min:", self.__df[col].min())
                print ("Max:", self.__df[col].max())
                print ("Mean:", self.__df[col].mean())

            numDistinct = self.__df[col].nunique()
            print ("NumDistinct:", numDistinct)

            if numDistinct <= self.__histPlotDistinctCount:
                countDist = self.__df[col].value_counts()
                print (countDist.to_dict())
                plt.figure(figsize=(10, 3))
                countDist.plot(ax=None, kind='bar')
                plt.show()
