# Test configuration and fixtures
