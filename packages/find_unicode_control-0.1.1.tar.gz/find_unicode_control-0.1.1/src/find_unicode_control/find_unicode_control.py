#!/usr/bin/env python3
# SPDX-License-Identifier: BSD-3-Clause
"""Find unicode control characters in source files

By default the script takes one or more files or directories and looks for
unicode control characters in all text files.  To narrow down the files, provide
a config file with the -c command line, defining a scan_exclude list, which
should be a list of regular expressions matching paths to exclude from the scan.

There is a second mode enabled with -p which when set to 'all', prints all
control characters and when set to 'bidi', prints only the 9 bidirectional
control characters.
"""
from __future__ import print_function

import sys, os, argparse, re, unicodedata, subprocess
import importlib
from stat import *

try:
    import magic
except ImportError:
    magic = None

def _unicode(line, encoding):
    if isinstance(line, str):
        return line
    return line.decode(encoding)

import platform
if platform.python_version()[0] == '2':
    _chr = unichr
    do_unicode = unicode
else:
    _chr = chr
    do_unicode = _unicode

if platform.python_version_tuple() < ('3','04','0'):
    import imp

# .git and .hg will get excluded when they're part of a directory tree being
# scanned but not when they're explicitly specified as targets.  That is:
#
# find_unicode_control.py foo
#
# will skip foo/.git but
#
# cd foo && find_unicode_control.py .git
#
# will read into .git.  I've left it like this on purpose in case someone ever
# needs to scan inside these directories even though I don't see any reason to
# do that at the moment.  Also,
#
# find_unicode_control.py foo/.git
#
# will skip .git and I don't really care much about fixing it myself since you
# could just pushd/popd your way out of that.  Send a PR if you wish to see that
# work :)
scan_exclude = [r'/\.git/', r'/\.hg/', r'\.desktop$', r'ChangeLog$', r'NEWS$',
                r'\.ppd$', r'\.txt$', r'\.directory$']
scan_exclude_mime = [r'text/x-po$', r'text/x-tex$', r'text/x-troff$',
                     r'text/html$']
verbose_mode = False
detailed_mode = False

# Print to stderr in verbose mode.
def eprint(*args, **kwargs):
    if verbose_mode:
        print(*args, file=sys.stderr, **kwargs)

# Decode a single latin1 line.
def decodeline(inf):
    return do_unicode(inf, 'utf-8')

# Make a text string from a file, attempting to decode from latin1 if necessary.
# Other non-utf-8 locales are not supported at the moment.
def getfiletext(filename):
    text = None
    with open(filename) as infile:
        try:
            if detailed_mode:
                return [decodeline(inf) for inf in infile]
        except Exception as e:
            eprint('%s: %s' % (filename, e))
            return None

        try:
            text = decodeline(''.join(infile))
        except UnicodeDecodeError:
            eprint('%s: Retrying with latin1' % filename)
            try:
                text = ''.join([decodeline(inf) for inf in infile])
            except Exception as e:
                eprint('%s: %s' % (filename, e))
    if text:
        return set(text)
    else:
        return None

def analyze_text_detailed(filename, text, disallowed, msg):
    line = 0
    warned = False
    for t in text:
        line = line + 1
        subset = [c for c in t if _chr(ord(c)) in disallowed]
        if subset:
            print('%s:%d %s: %s' % (filename, line, msg, subset))
            warned = True
    if not warned:
        eprint('%s: OK' % filename)

    return warned

# Look for disallowed characters in the text.  We reduce all characters into a
# set to speed up analysis.  FIXME: Add a slow mode to get line numbers in files
# that have these disallowed chars.
def analyze_text(filename, text, disallowed, msg):
    if detailed_mode:
        return analyze_text_detailed(filename, text, disallowed, msg)

    if not text.isdisjoint(disallowed):
        print('%s: %s: %s' % (filename, msg, text & disallowed))
        return True
    else:
        eprint('%s: OK' % filename)

    return False

def get_mime(f):
    if magic:
        return magic.detect_from_filename(f).mime_type
    args = ['file', '--mime-type', f]
    proc = subprocess.Popen(args, stdout=subprocess.PIPE)
    m = [decodeline(x[:-1]) for x in proc.stdout][0].split(':')[1].strip()
    return m

def should_read(f):
    # Fast check, just the file name.
    if [e for e in scan_exclude if re.search(e, f)]:
        return False

    # Slower check, mime type.
    m = get_mime(f)
    if not 'text/' in m \
            or [e for e in scan_exclude_mime if re.search(e, m)]:
        return False
    return True

# Get file text and feed into analyze_text.
def analyze_file(f, disallowed, msg):
    eprint('%s: Reading file' % f)
    if should_read(f):
        text = getfiletext(f)
        if text:
            return analyze_text(f, text, disallowed, msg)
    else:
        eprint('%s: SKIPPED' % f)

    return False

# Actual implementation of the recursive descent into directories.
def analyze_any(p, disallowed, msg, dirs_seen):
    try:
        stat_res = os.stat(p)
    except Exception as e:
        eprint('%s: %s' % (p, e))
        return False

    mode = stat_res.st_mode
    if S_ISDIR(mode):
        # avoid analyzing the same dir twice
        inode = stat_res.st_ino
        if inode:
            if inode in dirs_seen:
                return False
            dirs_seen.add(inode)

        return analyze_dir(p, disallowed, msg, dirs_seen)
    elif S_ISREG(mode):
        return analyze_file(p, disallowed, msg)
    else:
        eprint('%s: UNREADABLE' % p)

    return False

# Recursively analyze files in the directory.
def analyze_dir(d, disallowed, msg, dirs_seen):
    warned = False

    for f in os.listdir(d):
        w = analyze_any(os.path.join(d, f), disallowed, msg, dirs_seen)
        warned = warned or w

    return warned

def analyze_paths(paths, disallowed, msg, dirs_seen):
    warned = False

    for p in paths:
        w = analyze_any(p, disallowed, msg, dirs_seen)
        warned = warned or w

    return warned

# All control characters.  We omit the ascii control characters.
def nonprint_unicode(c):
    cat = unicodedata.category(c)
    if cat.startswith('C') and cat != 'Cc':
        return True
    return False

# Entry point for the analysis.  Arguments are passed in cli.py.
def start_unicode_analysis(args):
    global verbose_mode, detailed_mode
    verbose_mode = args.verbose
    detailed_mode = args.detailed

    if not args.nonprint:
        # Formatting control characters in the unicode space.  This includes the
        # bidi control characters.
        disallowed = set(_chr(c) for c in range(sys.maxunicode) if \
                                 unicodedata.category(_chr(c)) == 'Cf')

        msg = 'unicode control characters'
    elif args.nonprint == 'all':
        # All control characters.
        disallowed = set(_chr(c) for c in range(sys.maxunicode) if \
                         nonprint_unicode(_chr(c)))

        msg = 'disallowed characters'
    else:
        # Only bidi control characters.
        disallowed = set([
            _chr(0x202a), _chr(0x202b), _chr(0x202c), _chr(0x202d), _chr(0x202e),
            _chr(0x2066), _chr(0x2067), _chr(0x2068), _chr(0x2069)])
        msg = 'bidirectional control characters'

    if args.config:
        if platform.python_version_tuple() >= ('3','04','0'):
            # load settings file, method for Python >= 3.4
            spec = importlib.util.spec_from_file_location("settings", args.config)
            settings = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(settings)
        else:
            # load settings file, method for Python < 3.4
            settings = imp.load_source("settings", args.config)

        if hasattr(settings, 'scan_exclude'):
            scan_exclude = scan_exclude + settings.scan_exclude
        if hasattr(settings, 'scan_exclude_mime'):
            scan_exclude_mime = scan_exclude_mime + settings.scan_exclude_mime

    if args.notests:
        scan_exclude = scan_exclude + [r'/test[^/]+/']

    dirs_seen = set()

    warned = analyze_paths(args.path, disallowed, msg, dirs_seen)

    if warned:
        exit(1)
