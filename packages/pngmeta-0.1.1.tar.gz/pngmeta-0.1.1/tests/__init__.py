"""Tests for pngmeta."""
