# AII — AI-Powered Terminal Assistant

**AII** (pronounced *"eye"*) is your **intelligent command-line companion** that brings Claude, GPT, and Gemini directly into your terminal through natural language commands.

**🎉 Version 0.4.5** — Git PR & Branch workflows | **v0.4.4** — Real-time streaming + Output modes | **v0.4.3** — Shell autocomplete

## Why AII?

**One CLI. 25 AI Functions. Natural Language. Zero Configuration Headaches.**

Stop context-switching between your terminal and ChatGPT. Get instant AI assistance for git commits, code generation, translation, content writing, shell automation, and analysis—all without leaving your terminal.

**Perfect for:**
- **Developers**: AI-powered git commits, code generation, and shell automation
- **Creators**: Content writing, translation, and social media posts
- **Professionals**: Email templates, document analysis, and research assistance

Built with the Pydantic AI framework for reliable, multi-provider LLM integration (Anthropic Claude, OpenAI GPT, Google Gemini).

### 📊 AII vs. Traditional Workflows

| Task | Without AII | With AII |
|------|-------------|----------|
| **Git Workflows** | Manual commits, PRs, branches | `aii commit/pr/branch` → AI-powered git automation |
| **Translation** | Copy to browser → ChatGPT → Copy back | `aii translate "text" to spanish` → Instant result |
| **Code Generation** | Search Stack Overflow → Adapt code | `aii create python email validator` → Complete function |
| **Shell Commands** | Google syntax → Test carefully | `aii find large files` → Safe command with explanation |
| **Content Writing** | Open docs/emails separately | `aii write email declining meeting` → Professional draft |

**Result:** Stay in your terminal, maintain flow state, get instant AI assistance.

---

## ✨ Key Features

### 🎯 Natural Language Interface
Just describe what you want—no commands to memorize:
- **25 AI Functions**: Content generation, code operations, git workflows, shell automation, analysis, translation
- **Multi-Provider**: Anthropic Claude, OpenAI GPT, Google Gemini with automatic fallbacks
- **Smart Confirmations**: Context-aware safety checks that don't interrupt safe operations
- **Session Memory**: Persistent conversations across commands

###  🛡️ Advanced Features

**New in v0.4.5:**
- **🔀 Git PR Generator**: AI-powered pull request creation with automatic title and description
  - Analyzes commit history across branches
  - Generates comprehensive PR descriptions with summary, changes, and test plan
  - Creates PR directly on GitHub via `gh` CLI
- **🌿 Smart Branch Naming**: Conventional branch names from natural language
  - Auto-detects type: feature/, bugfix/, docs/, refactor/, etc.
  - Generates clean slugs from descriptions
  - Validates branch doesn't exist before creation

**New in v0.4.4:**
- **🌊 Real-Time Response Streaming**: See LLM responses as they're generated — 60-80% faster perceived speed
  - Token-by-token display with <100ms latency
  - Works with Claude, GPT, and Gemini
  - Markdown rendering during streaming
  - Configurable with `--no-streaming` flag
- **🎨 OutputMode System**: Function-specific output formatting — Get exactly the detail you need
  - **CLEAN mode** (16 functions, 67% default): Just the result (perfect for quick queries and pipeable output)
  - **STANDARD mode** (5 functions, 21%): Result + metrics + simple summary (no expensive LLM analysis)
  - **THINKING mode** (3 functions, 12%): Full reasoning display with LLM semantic analysis
  - Smart defaults: Most functions → CLEAN (shell, translate, content), Analysis → THINKING (research, code_review)
  - CLI overrides: `--clean`, `--standard`, `--thinking` or per-function config in config.yaml
  - Session header only in THINKING mode (STANDARD/CLEAN are cleaner and faster)

**New in v0.4.3:**
- **⚡ Shell Autocomplete**: Tab completion for bash/zsh/fish — Type 40-60% faster
- **📜 Command History**: Arrow key navigation in interactive mode with 1000-command persistence

**New in v0.4.2:**
- **🚀 Interactive Setup Wizard**: 2-minute guided setup with arrow key navigation
- **💰 Real-Time Cost Tracking**: Transparent pricing for 27 AI models across 3 providers
- **⚙️ Quick Config**: Fast provider/model switching with `aii config provider/model`

**Core Features:**
- **LLM-First Architecture**: Advanced natural language understanding
- **Thinking Mode Display**: See AI reasoning, confidence scores, and token usage
- **Web Search Integration**: Research with real-time web results (DuckDuckGo, Brave, Google)
- **Health Diagnostics**: `aii doctor` command for troubleshooting setup issues
- **Debug Mode**: Complete diagnostics with 56 security patterns

---

## 🚀 Quick Start

### Installation

```bash
# With uv (recommended)
uv tool install aiiware-cli

# Or with pip
pip install aiiware-cli

# Verify
aii --version  # → aiiware-cli 0.4.4
```

### Setup *(Interactive Wizard in v0.4.2)*

```bash
# Interactive setup wizard (2 minutes)
aii config init

# Verify setup
aii doctor  # → Runs health checks for configuration, LLM provider, storage, etc.
```

**Features:**
- **Arrow key navigation** — Visual menu with provider descriptions
- **Automatic validation** — Tests API key before saving
- **Browser integration** — Opens API key signup pages
- **Guided experience** — Provider selection → API key → Model choice

**Troubleshooting:** If you encounter issues, run `aii doctor` to diagnose configuration problems.

**Get API Keys:**
- **Claude**: [console.anthropic.com](https://console.anthropic.com/)
- **GPT**: [platform.openai.com](https://platform.openai.com/)
- **Gemini**: [aistudio.google.com/apikey](https://aistudio.google.com/apikey)

### Shell Autocomplete *(New in v0.4.3)*

Enable tab completion for commands, flags, and parameters in bash, zsh, and fish:

```bash
# Install (auto-detects your shell)
aii install-completion

# Or specify shell explicitly
aii install-completion --shell bash
aii install-completion --shell zsh
aii install-completion --shell fish
```

**For zsh users:** Add to `~/.zshrc` if not already present:
```bash
fpath=(~/.zsh/completion $fpath)
autoload -Uz compinit && compinit
```

**Activate:**
```bash
source ~/.bashrc          # bash
exec zsh                  # zsh (or restart terminal)
# fish auto-loads automatically
```

**Usage:**
```bash
aii tr<TAB>                      → aii translate
aii translate --<TAB>            → --to --from --format --help
aii translate --to <TAB>         → spanish french german chinese  # zsh/fish
```

**Uninstall:**
```bash
aii uninstall-completion
```

### Interactive Mode with Command History *(New in v0.4.3)*

Interactive mode now includes persistent command history with arrow key navigation:

```bash
# Start interactive mode
aii

# Your commands are saved and can be recalled
> translate hello to French
Bonjour

> explain how LLMs work
[explanation...]

> ↑  # UP arrow — recalls previous commands
> ↓  # DOWN arrow — navigate forward
```

**Features:**
- **Arrow keys**: UP/DOWN for history, LEFT/RIGHT for editing
- **Keyboard shortcuts**: Home/End, Ctrl+A/E/K/U
- **Persistent**: 1000 commands saved at `~/.config/aii/.aii_history`
- **Zero config**: Works automatically

---

## 💡 What You Can Do

### 🔧 Core Use Cases

#### 🔀 **AI Git Workflows** — Complete git automation
```bash
# Smart commit messages
git add . && aii commit
# → Analyzes changes → Generates conventional commit → Shows confidence score

# Pull request creation (New in v0.4.5)
aii pr
# → Analyzes commits → Generates PR title/description → Creates on GitHub

# Smart branch naming (New in v0.4.5)
aii branch "add user authentication"
# → feature/add-user-authentication
```

#### 💻 **Code Generation** — Language-agnostic with best practices
```bash
aii create a python function to validate emails
# Complete with typing, docstrings, error handling, and examples
```

#### 🌍 **Translation** — Context-aware with cultural notes
```bash
# Quick answer (CLEAN mode default)
aii translate "running late for meeting" to spanish
# → "Voy a llegar tarde a la reunión"

# With full reasoning (override with --thinking)
aii translate "running late for meeting" to spanish --thinking
# → Shows translation logic, cultural context, confidence score
```

#### 📝 **Content Creation** — Professional writing assistance
```bash
aii write a tweet about AI breakthroughs in 2025
# → Engaging tweet with hashtags, character count validation
```

#### 🐚 **Shell Automation** — Safe command generation with explanations
```bash
aii find all python files modified this week
# → Generates command, explains safety, requests confirmation
```

#### 🧠 **Explanations** — Clear technical concepts
```bash
aii explain how transformers work in LLMs
# → Structured explanation with examples and analogies
```

#### 🔍 **Web Research** — Real-time information with sources
```bash
aii research latest developments in quantum computing
# → Searches web (DuckDuckGo/Brave/Google)
# → Synthesizes findings with [Source N] citations
```

#### 🎨 **Output Modes** — Control detail level **(New in v0.4.4)**
```bash
# CLEAN mode: Just the answer (default for most functions)
aii translate hello to french
# → "bonjour"

aii find largest file in Downloads --clean
# Generated command: `find ~/Downloads -type f -exec du -h {} + | sort -rh | head -n 1`
# Execute? [y/N]: y
# → 1.2G    bigfile.zip

# STANDARD mode: Answer + metrics (no expensive LLM analysis)
aii translate hello to french --standard
# → "bonjour"
# → ✓ translate: (1.8s) • 145↗ 28↘ (173 tokens)
# → 📊 Session Summary: ⚡ Total: 3.2s • 💰 $0.000043

# THINKING mode: Full reasoning (for when you need to understand why)
aii commit --thinking
# → 🔍 aii • Claude • Functions: 23 loaded
# → [Diff analysis + reasoning + commit message + confidence + LLM insights]
```

---

## 📖 Usage Guide

### 🎯 Natural Language Commands

No need to memorize syntax—just describe what you want:

| Command Type | Example | What Happens |
|-------------|---------|--------------|
| **Translation** | `aii translate hello to spanish` | Context-aware translation with cultural notes |
| **Git** | `aii commit` / `aii pr` / `aii branch "feature"` | AI-powered commits, PRs, and branch naming |
| **Code** | `aii write a python email validator` | Complete function with types, docs, examples |
| **Content** | `aii write a tweet about AI` | Character-limited, engaging, with hashtags |
| **Shell** | `aii find large files` | Generates safe command with explanation |
| **Analysis** | `aii explain machine learning` | Structured explanation with examples |

### 🔧 All 25 AI Functions

<details>
<summary><b>📝 Content Generation</b> (5 functions) — Click to expand</summary>

- **Universal Content**: Flexible generation with tone/style customization
- **Twitter/Social**: Platform-specific posts with character limits
- **Email Templates**: Professional business communication
- **Blog/Article**: Long-form content creation
</details>

<details>
<summary><b>💻 Code Operations</b> (2 functions)</summary>

- **Code Generation**: Multi-language with best practices, typing, documentation
- **Code Review**: Security analysis, style suggestions, optimization tips
</details>

<details>
<summary><b>🔀 Git Integration</b> (5 functions) — Enhanced in v0.4.5</summary>

- **AI Commit**: Diff analysis → Conventional commit messages with thinking mode
- **PR Generator** *(New)*: Analyze commits → Create GitHub pull requests with AI descriptions
- **Smart Branch** *(New)*: Natural language → Conventional branch names (feature/, bugfix/, etc.)
- **Git Status**: Repository insights with actionable suggestions
- **Git Diff**: Intelligent change analysis and explanations
</details>

<details>
<summary><b>🐚 Shell Operations</b> (4 functions)</summary>

- **Command Generation**: Safe shell command creation with confirmation
- **Enhanced Shell**: AI-powered execution with tool calling
- **Streaming Shell**: Real-time command output
- **Contextual Shell**: Environment-aware operations
</details>

<details>
<summary><b>🧠 Analysis & Research</b> (3 functions)</summary>

- **Explain**: Technical concepts with examples and analogies
- **Summarize**: Intelligent content condensation
- **Research**: Web-based research with source validation
</details>

<details>
<summary><b>🌍 Translation & Language</b> (2 functions)</summary>

- **Translation**: Multi-language with cultural context
- **Language Detection**: Automatic language identification
</details>

<details>
<summary><b>📊 Context Management</b> (3 functions)</summary>

- **Git Context**: Repository history and structure analysis
- **File Context**: Project structure and file system insights
- **System Context**: Environment information gathering
</details>

<details>
<summary><b>⚙️ System</b> (2 functions)</summary>

- **Help**: Dynamic assistance based on your context
- **Clarification**: Handles ambiguous requests intelligently
</details>

### 🎛️ Advanced Features

#### **OutputMode System** *(New in v0.4.4)*
Control output detail with function-specific defaults and CLI overrides:

- **CLEAN mode** (default for translate, explain, summarize): Just the result
- **STANDARD mode**: Result + metrics + session summary
- **THINKING mode** (default for git commit, code review): Full AI reasoning

```bash
# Defaults work intelligently
aii translate hello to spanish     # → "hola" (CLEAN default)
aii commit                          # → Full reasoning (THINKING default)

# Override any function
aii translate hello to spanish --thinking  # → See reasoning
aii commit --clean                         # → Quick commit

# CLI flags: --clean, --standard, --thinking, --verbose
```

#### **Smart Risk-Based Confirmations**
- **Safe operations** (translate, explain): Execute immediately, no interruption
- **Risky operations** (shell, git): Show command preview + safety notes + confirmation

#### **Token Tracking & Cost Transparency** *(Enhanced in v0.4.2)*
Monitor LLM usage and costs in real-time across all operations:
```bash
# 📊 Session: 3.2s • Tokens: 142↗ 28↘ (170 total) • 💰 $0.000049
# Shows: execution time, input/output tokens, exact cost
```

#### **Session Persistence**
```bash
aii explain quantum computing  # Auto-saves as session_abc123
aii --continue give me more examples  # Resumes conversation
```

#### **Debug Mode**
```bash
AII_DEBUG=1 aii commit  # Shows: security patterns, LLM recognition, token breakdown
```

---

## 🎨 Real-World Examples

### **AI Git Commit**

```bash
git add . && aii commit

# 🧠 Thinking: Analyzing changes... console.log added for debugging
# 💻 Commit: feat(app): add console logging for debugging
# 🎯 Confidence: 89% • Tokens: 245↗ 67↘
# Proceed? (y/n): y
# ✅ Committed: a1b2c3d
```

### **Context-Aware Translation**

```bash
aii translate "running late for meeting" to spanish

# 🧠 Converting informal business expression, maintaining urgency...
# 🌐 "Voy a llegar tarde a la reunión"
# 📝 Informal but professional. Alternative: "Me voy a retrasar" (more formal)
# 🎯 Confidence: 94%
```

### **Code Generation with Best Practices**

```bash
aii create a python email validator with error handling

# 💻 Returns complete function with:
# - RFC 5322 regex pattern
# - Type hints (typing.bool)
# - Comprehensive docstring
# - Error handling (TypeError, re.error)
# - Example usage with test cases
# 🎯 Confidence: 92% • 445 tokens generated
```

---

## ⚙️ Configuration

```bash
# Interactive setup
aii config init        # Guided provider + API key setup (v0.4.2: arrow key menu)
aii config show        # View current config
aii config validate    # Check configuration

# Quick config commands (New in v0.4.2)
aii config provider    # Switch LLM provider (Claude/GPT/Gemini)
aii config model       # Change model within provider
aii config web-search  # Configure web search integration

# Command-line options
aii --help             # Show help
aii --version          # Version info
aii --continue "msg"   # Resume last session
```

---

## 🐛 Troubleshooting

**Quick Diagnosis:** Run `aii doctor` to check your setup automatically.

| Issue | Solution |
|-------|----------|
| ❌ `ANTHROPIC_API_KEY not found` | Run `aii config init` or `export ANTHROPIC_API_KEY="key"` |
| ❌ `aii command not found` | Restart terminal or check PATH: `uv tool install aiiware-cli` |
| ⚠️ Slow responses | Check network or try different provider: `aii config init` |
| 🔍 Need diagnostics | Run `aii doctor` or enable debug: `AII_DEBUG=1 aii your-command` |
| 🔄 LLM timeout errors | Retry logic automatic in v0.4.1, check `aii doctor` for connectivity |
| ⚠️ Web search not working | Configure Brave Search API key (optional, free DuckDuckGo fallback available) |

---

## 🔧 Architecture

AII uses LLM-first design with:
- **Intent Recognition**: Natural language → function mapping via LLMs
- **Function Plugins**: 25 extensible functions across 8 categories
- **Smart Risk Assessment**: Context-aware confirmations
- **Multi-Provider**: Anthropic Claude, OpenAI GPT, Google Gemini
- **Session Persistence**: Conversation memory and metrics

---

## 📚 Links & Resources

- **📦 [PyPI Package](https://pypi.org/project/aiiware-cli)** — Official distribution
- **📖 Documentation** — Comprehensive examples in this README
- **🔄 Releases** — Version history on PyPI

---

## 📄 License & Credits

**License:** Apache 2.0 • Copyright 2025-present aiiware.com

**Built with:**
- [Pydantic AI](https://ai.pydantic.dev/) — Reliable LLM integration framework
- [Anthropic Claude](https://www.anthropic.com/claude) • [OpenAI GPT](https://openai.com/) • [Google Gemini](https://ai.google.dev/)

---

<div align="center">

**Made with ❤️ for developers who want AI-powered assistance without leaving the terminal**

[⬆ Back to top](#aii--ai-powered-terminal-assistant-for-developers)

</div>
