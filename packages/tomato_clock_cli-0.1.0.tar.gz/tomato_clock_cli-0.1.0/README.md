# Tomato Clock CLI

一个简单易用的番茄工作法命令行工具，帮助你高效管理时间和任务。

## 功能特点

- 标准的25分钟番茄钟计时
- 任务管理（添加、列表、删除）
- 番茄钟完成计数统计
- 美观的命令行界面（使用Rich库）
- 数据持久化存储
- 计时完成通知和提示音

## 安装

```bash
pip install --user tomato-clock-cli
```

## 使用方法

### 添加任务

```bash
tomato add "阅读技术文档"
```

### 查看任务列表

```bash
tomato ls
```

### 删除任务

```bash
tomato rm <任务ID>
```

### 开始番茄钟

```bash
# 使用默认25分钟
tomato start <任务ID>

# 自定义时长（例如30分钟）
tomato start <任务ID> -t 30
```

## 命令详解

- `add <任务名称>` - 添加新任务
- `ls` - 列出所有任务（显示ID、名称、完成番茄钟数和创建时间）
- `rm <任务ID>` - 删除指定任务
- `start <任务ID> [-t 时长]` - 开始指定任务的番茄钟计时
- `-v, --version` - 显示版本信息
- `-h, --help` - 显示帮助文档
## 数据存储

任务数据保存在 `~/.config/tomato-clock-cli/tasks.json` 文件中。

## 依赖项

- rich >= 10.0.0

## 许可证

MIT

## 版本

当前版本：0.1.0

---

开始使用番茄工作法，提高你的工作效率！ 🍅