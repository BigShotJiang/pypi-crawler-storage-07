from typing import List, Dict, Any, Optional
from storage import Storage


class TaskManager:
    def __init__(self):
        self.storage = Storage()
        self.data = self.storage.load_data()

    def add_task(self, name: str) -> int:
        """添加新任务并返回任务ID"""
        task_id = self.data["next_id"]
        task = {
            "id": task_id,
            "name": name,
            "completed_pomodoros": 0,
            "created_at": self._get_current_time(),
        }

        self.data["tasks"].append(task)
        self.data["next_id"] += 1
        self.storage.save_data(self.data)

        return task_id

    def list_tasks(self) -> List[Dict[str, Any]]:
        """返回所有任务列表"""
        return self.data["tasks"]

    def remove_task(self, task_id: int) -> bool:
        """删除指定ID的任务，返回是否成功"""
        initial_length = len(self.data["tasks"])
        self.data["tasks"] = [
            task for task in self.data["tasks"] if task["id"] != task_id
        ]

        if len(self.data["tasks"]) < initial_length:
            self.storage.save_data(self.data)
            return True
        return False

    def get_task(self, task_id: int) -> Optional[Dict[str, Any]]:
        """根据ID获取任务"""
        for task in self.data["tasks"]:
            if task["id"] == task_id:
                return task
        return None

    def increment_pomodoro_count(self, task_id: int) -> bool:
        """增加任务的番茄钟计数，返回是否成功"""
        task = self.get_task(task_id)
        if task:
            task["completed_pomodoros"] += 1
            self.storage.save_data(self.data)
            return True
        return False

    def _get_current_time(self):
        """获取当前时间字符串"""
        from datetime import datetime

        return datetime.now().isoformat()
