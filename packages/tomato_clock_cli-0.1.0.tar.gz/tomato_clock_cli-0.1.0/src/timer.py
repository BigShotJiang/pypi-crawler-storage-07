import time
import sys
from datetime import datetime, timedelta
from rich.progress import Progress, BarColumn, TextColumn, TimeRemainingColumn
from rich.console import Console
from rich import print as rprint


class TomatoTimer:
    def __init__(self, duration_minutes: int = 25):
        self.duration = duration_minutes * 60  # 转换为秒
        self.console = Console()

    def _show_notification(self, task_name: str):
        """显示完成通知"""
        print("\a")  # 系统提示音
        rprint(f"\n[bold green]🎉 番茄钟完成![/bold green]")
        # rprint(f"[green]任务 '{task_name}' 的番茄钟计时结束[/green]")
        rprint("[yellow]休息一下吧![/yellow]")

    def run(self, task_name: str) -> bool:
        """运行番茄钟，返回是否成功完成（没有被中断）"""
        remaining = self.duration
        rprint(f"\n[bold]🍅 开始番茄钟[/bold]")
        rprint(f"[cyan]任务: {task_name}[/cyan]")
        rprint(f"[cyan]时长: {self.duration // 60} 分钟[/cyan]")
        rprint("[yellow]提示: 按 Ctrl+C 可中断番茄钟[/yellow]\n")

        try:
            with Progress(
                TextColumn("[progress.description]{task.description}"),
                BarColumn(),
                TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
                TimeRemainingColumn(),
                console=self.console,
                expand=True,
                transient=True,
            ) as progress:
                task = progress.add_task(
                    f"[cyan]{task_name}[/cyan]", total=self.duration
                )
                while remaining > 0:
                    progress.update(task, advance=1)
                    remaining -= 1
                    time.sleep(1)
            # 番茄钟完成
            self._show_notification(task_name)
            return True

        except KeyboardInterrupt:
            rprint("\n[yellow]⏹️  番茄钟已被中断[/yellow]")
            return False
