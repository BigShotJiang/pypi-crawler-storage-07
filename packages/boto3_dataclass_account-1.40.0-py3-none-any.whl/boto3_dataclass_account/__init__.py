# -*- coding: utf-8 -*-

from .caster import account_caster

caster = account_caster

__version__ = "1.40.0"