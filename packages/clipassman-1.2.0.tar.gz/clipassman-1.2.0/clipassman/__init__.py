# Copyright © 2025, Alexander Suvorov
"""Cross-platform console Smart Password manager and generator."""
__version__ = '1.2.0'
