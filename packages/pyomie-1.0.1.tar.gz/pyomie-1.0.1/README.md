# pyomie

<p align="center">
  <a href="https://github.com/luuuis/pyomie/actions/workflows/ci.yml?query=branch%3Amain">
    <img src="https://img.shields.io/github/actions/workflow/status/luuuis/pyomie/ci.yml?branch=main&label=CI&logo=github&style=flat-square" alt="CI Status" >
  </a>
  <a href="https://pyomie.readthedocs.io">
    <img src="https://img.shields.io/readthedocs/pyomie.svg?logo=read-the-docs&logoColor=fff&style=flat-square" alt="Documentation Status">
  </a>
  <a href="https://codecov.io/gh/luuuis/pyomie">
    <img src="https://img.shields.io/codecov/c/github/luuuis/pyomie.svg?logo=codecov&logoColor=fff&style=flat-square" alt="Test coverage percentage">
  </a>
</p>
<p align="center">
  <a href="https://python-poetry.org/">
    <img src="https://img.shields.io/badge/packaging-poetry-299bd7?style=flat-square&logo=data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAASCAYAAABrXO8xAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAJJSURBVHgBfZLPa1NBEMe/s7tNXoxW1KJQKaUHkXhQvHgW6UHQQ09CBS/6V3hKc/AP8CqCrUcpmop3Cx48eDB4yEECjVQrlZb80CRN8t6OM/teagVxYZi38+Yz853dJbzoMV3MM8cJUcLMSUKIE8AzQ2PieZzFxEJOHMOgMQQ+dUgSAckNXhapU/NMhDSWLs1B24A8sO1xrN4NECkcAC9ASkiIJc6k5TRiUDPhnyMMdhKc+Zx19l6SgyeW76BEONY9exVQMzKExGKwwPsCzza7KGSSWRWEQhyEaDXp6ZHEr416ygbiKYOd7TEWvvcQIeusHYMJGhTwF9y7sGnSwaWyFAiyoxzqW0PM/RjghPxF2pWReAowTEXnDh0xgcLs8l2YQmOrj3N7ByiqEoH0cARs4u78WgAVkoEDIDoOi3AkcLOHU60RIg5wC4ZuTC7FaHKQm8Hq1fQuSOBvX/sodmNJSB5geaF5CPIkUeecdMxieoRO5jz9bheL6/tXjrwCyX/UYBUcjCaWHljx1xiX6z9xEjkYAzbGVnB8pvLmyXm9ep+W8CmsSHQQY77Zx1zboxAV0w7ybMhQmfqdmmw3nEp1I0Z+FGO6M8LZdoyZnuzzBdjISicKRnpxzI9fPb+0oYXsNdyi+d3h9bm9MWYHFtPeIZfLwzmFDKy1ai3p+PDls1Llz4yyFpferxjnyjJDSEy9CaCx5m2cJPerq6Xm34eTrZt3PqxYO1XOwDYZrFlH1fWnpU38Y9HRze3lj0vOujZcXKuuXm3jP+s3KbZVra7y2EAAAAAASUVORK5CYII=" alt="Poetry">
  </a>
  <a href="https://github.com/ambv/black">
    <img src="https://img.shields.io/badge/code%20style-black-000000.svg?style=flat-square" alt="black">
  </a>
  <a href="https://github.com/pre-commit/pre-commit">
    <img src="https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit&logoColor=white&style=flat-square" alt="pre-commit">
  </a>
</p>
<p align="center">
  <a href="https://pypi.org/project/pyomie/">
    <img src="https://img.shields.io/pypi/v/pyomie.svg?logo=python&logoColor=fff&style=flat-square" alt="PyPI Version">
  </a>
  <a href="https://pypi.org/project/pyomie/">
    <img src="https://img.shields.io/pypi/dm/pyomie" alt="pypy downloads">
  </a>
  <img src="https://img.shields.io/pypi/pyversions/pyomie.svg?style=flat-square&logo=python&amp;logoColor=fff" alt="Supported Python versions">
  <img src="https://img.shields.io/pypi/l/pyomie.svg?style=flat-square" alt="License">
</p>

---

**Documentation**: <a href="https://pyomie.readthedocs.io" target="_blank">https://pyomie.readthedocs.io </a>

**Source Code**: <a href="https://github.com/luuuis/pyomie" target="_blank">https://github.com/luuuis/pyomie </a>

---

A command-line interface and asynchronous client library for OMIE - Spain and Portugal electricity market data.

## Installation

Install this via pip (or your favourite package manager):

`pip install pyomie`

## Usage

The pyomie CLI returns a JSON payload for the given date.

````bash
% pyomie --help

 Usage: pyomie [OPTIONS] [DATE]

 Fetch the OMIE spot price data.

╭─ Arguments ─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────╮
│   date      [DATE]  Date to fetch in YYYY-MM-DD format [default: today's date]                                                                                                  │
╰─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────╯
╭─ Options ───────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────╮
│ --csv     --no-csv      Print the CSV as returned by OMIE, without parsing. [default: no-csv]                                                                                   │
│ --help                  Show this message and exit.                                                                                                                             │
╰─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────╯

% pyomie
{"url": "https://www.omie.es/sites/default/files/dados/AGNO_2025/MES_10/TXT/INT_PBC_EV_H_1_01_10_2025_01_10_2025.TXT", "market_date": "2025-10-01", "header": "OMIE - Mercado de electricidad;Fecha Emisi\u00f3n :30/09/2025 - 13:51;;01/10/2025;Precio del mercado diario (EUR/MWh);;;;", "es_pt_total_power": [29675.3, 29330.1, 28900.2, 28523.6, 28221.0, 27861.7, 27580.7, 27329.9, 26721.7, 26468.5, 26300.2, 26167.4, 25999.8, 25873.9, 25768.6, 25673.3, 25601.5, 25539.5, 25576.8, 25687.9, 25783.1, 25907.7, 26120.9, 26637.2, 27689.5, 28160.1, 28800.5, 29579.0, 31207.9, 32040.5, 32639.3, 33142.2, 33588.3, 34152.6, 34109.7, 34372.9, 35347.8, 35520.8, 35103.9, 36348.2, 35510.3, 36444.3, 37638.8, 38790.0, 37181.9, 38871.6, 39446.1, 39910.0, 39909.0, 40542.3, 40297.3, 40543.6, 40890.4, 41044.7, 41299.0, 41155.6, 40992.3, 40836.8, 40771.7, 40057.1, 40059.6, 39765.4, 39804.3, 39291.9, 39576.8, 39011.3, 38339.0, 36998.4, 39302.1, 38077.9, 36929.1, 35517.8, 36699.5, 35041.2, 35337.2, 35563.1, 35309.4, 35485.2, 35875.5, 36861.6, 38076.6, 38292.2, 38362.3, 38452.4, 38977.3, 38864.5, 38469.9, 37673.2, 36218.3, 35358.3, 34492.0, 33749.6, 32747.7, 32051.4, 31376.2, 30708.4], "es_purchases_power": [16095.8, 15882.8, 15653.2, 15424.4, 15299.1, 15094.1, 14927.8, 14795.7, 14347.6, 14188.7, 14111.0, 14044.4, 13979.3, 13922.4, 13875.5, 13823.2, 13792.4, 13788.1, 13839.7, 13953.7, 14071.8, 14203.3, 14370.8, 14803.3, 15405.2, 15736.8, 16205.6, 16829.8, 17691.2, 18434.2, 18928.1, 19312.7, 19868.6, 20212.1, 19843.6, 19704.0, 20585.9, 20207.2, 19178.1, 18982.5, 21073.0, 21580.4, 21608.5, 22544.0, 21584.3, 23134.7, 23592.4, 24025.2, 24111.1, 24194.4, 24185.5, 24310.5, 24404.5, 24624.1, 24966.4, 24841.1, 24612.5, 24471.3, 24378.0, 23689.6, 23541.9, 23276.3, 23397.1, 23354.7, 23242.3, 23132.4, 22550.9, 21534.2, 22984.8, 21866.5, 21090.8, 20924.3, 19129.9, 18682.8, 19141.1, 19561.4, 19171.1, 19488.0, 19899.9, 20788.8, 21535.5, 21626.0, 21666.2, 21566.4, 21964.2, 21897.5, 21581.9, 20960.2, 20077.2, 19441.4, 18837.3, 18358.3, 17899.1, 17456.3, 17009.7, 16610.9], "pt_purchases_power": [5660.3, 5530.5, 5393.0, 5296.6, 5216.9, 5122.2, 5056.7, 4991.3, 4896.5, 4846.0, 4790.9, 4750.7, 4673.4, 4636.6, 4611.1, 4588.8, 4567.2, 4537.2, 4533.4, 4528.6, 4505.8, 4494.9, 4499.5, 4502.7, 4532.4, 4560.2, 4601.9, 4676.2, 4885.2, 4985.6, 5101.3, 5226.4, 5413.9, 5516.4, 5631.7, 5763.6, 6172.9, 6222.5, 6282.6, 7193.6, 6404.0, 6432.5, 7289.7, 7247.5, 7178.6, 7158.7, 7164.5, 7115.9, 7167.6, 7639.1, 7375.3, 7477.3, 7736.4, 7665.2, 7595.0, 7594.8, 7572.6, 7570.0, 7631.9, 7640.7, 7743.4, 7772.0, 7777.8, 7401.4, 7772.3, 7414.1, 7435.4, 7239.1, 7435.5, 7495.3, 7347.4, 6371.4, 7207.0, 6240.6, 6334.9, 6394.3, 6298.3, 6377.5, 6490.1, 6620.7, 6754.8, 6842.3, 6842.7, 7000.7, 7151.1, 7081.5, 6985.7, 6888.5, 6794.6, 6691.3, 6557.9, 6416.5, 6334.2, 6197.1, 6068.6, 5882.9], "es_sales_power": [16743.2, 16677.6, 16744.0, 16513.7, 15790.2, 15840.4, 15847.1, 15809.5, 15351.4, 15340.8, 15275.9, 15220.1, 15081.7, 15011.8, 14937.2, 14845.7, 14792.9, 14762.7, 14702.5, 14617.4, 14660.2, 14736.8, 14898.8, 15249.8, 14896.2, 15169.8, 15288.8, 15403.9, 15879.0, 16371.9, 16640.8, 16694.5, 16911.0, 17356.7, 18129.7, 18433.0, 18527.4, 19516.0, 20005.9, 21495.4, 22767.0, 23403.8, 24917.4, 25996.7, 26185.9, 26607.9, 26925.8, 27180.3, 27374.4, 27474.4, 27517.0, 27520.2, 27323.6, 27305.8, 27252.3, 27177.6, 27047.7, 27006.1, 26933.0, 26778.6, 26687.9, 26575.0, 26420.8, 26472.1, 26168.6, 26181.4, 25770.7, 25346.2, 25438.6, 24787.0, 23513.9, 23003.4, 22312.8, 21105.6, 20102.2, 19629.5, 20067.3, 19537.6, 18943.0, 20054.5, 20029.4, 20168.8, 20193.8, 20234.8, 19672.8, 19669.2, 19744.5, 19615.8, 19663.9, 19495.4, 19238.5, 19285.4, 18410.6, 18395.9, 18254.2, 17886.6], "pt_sales_power": [3712.9, 3435.7, 3002.2, 2907.3, 3425.8, 3075.9, 2837.4, 2677.5, 2592.7, 2393.9, 2326.0, 2275.0, 2271.0, 2247.2, 2249.4, 2266.3, 2266.7, 2262.6, 2370.6, 2564.9, 2617.4, 2661.4, 2671.5, 2756.2, 2741.4, 2827.2, 3218.7, 3802.1, 4397.4, 4747.9, 5088.6, 5544.6, 6504.3, 6438.7, 5668.3, 4734.6, 6502.6, 4657.2, 3303.0, 2603.6, 3822.1, 3437.9, 3535.3, 3176.0, 3315.2, 3309.8, 3387.8, 3414.1, 3505.2, 3516.9, 3565.6, 3604.8, 3567.3, 3572.5, 3572.3, 3563.7, 3508.1, 3534.0, 3508.0, 3479.4, 3440.8, 3401.9, 3362.1, 3346.2, 3244.3, 3348.0, 3278.8, 3216.9, 3127.9, 3107.4, 3369.7, 3330.0, 2572.0, 2491.5, 3403.2, 5145.0, 3824.9, 5091.0, 5899.0, 5813.2, 5960.9, 5999.5, 6015.1, 6032.3, 7142.5, 7009.8, 6523.1, 5932.9, 5907.9, 5337.3, 4856.7, 4189.4, 4522.7, 3957.5, 3524.1, 3307.2], "es_pt_power": [21756.1, 21413.3, 21046.2, 20721.0, 20516.0, 20216.3, 19984.5, 19787.0, 19244.1, 19034.7, 18901.9, 18795.1, 18652.7, 18559.0, 18486.6, 18412.0, 18359.6, 18325.3, 18373.1, 18482.3, 18577.6, 18698.2, 18870.3, 19306.0, 19937.6, 20297.0, 20807.5, 21506.0, 22576.4, 23419.8, 24029.4, 24539.1, 25282.5, 25728.5, 25475.3, 25467.6, 26758.8, 26429.7, 25460.7, 26176.1, 27477.0, 28012.9, 28898.2, 29791.5, 28762.9, 30293.4, 30756.9, 31141.1, 31278.7, 31833.5, 31560.8, 31787.8, 32140.9, 32289.3, 32561.4, 32435.9, 32185.1, 32041.3, 32009.9, 31330.3, 31285.3, 31048.3, 31174.9, 30756.1, 31014.6, 30546.5, 29986.3, 28773.3, 30420.3, 29361.8, 28438.2, 27295.7, 26336.9, 24923.4, 25476.0, 25955.7, 25469.4, 25865.5, 26390.0, 27409.5, 28290.3, 28468.3, 28508.9, 28567.1, 29115.3, 28979.0, 28567.6, 27848.7, 26871.8, 26132.7, 25395.2, 24774.8, 24233.3, 23653.4, 23078.3, 22493.8], "es_to_pt_exports_power": [1947.4, 2094.8, 2390.8, 2389.3, 1791.1, 2046.3, 2219.3, 2313.8, 2303.8, 2452.1, 2464.9, 2475.7, 2402.4, 2389.4, 2361.7, 2322.5, 2300.5, 2274.6, 2162.8, 1963.7, 1888.4, 1833.5, 1828.0, 1746.5, 1791.0, 1733.0, 1383.2, 874.1, 487.8, 237.7, 12.7, 0.0, 0.0, 0.0, 0.0, 1029.0, 0.0, 1565.3, 2979.6, 4590.0, 2581.9, 2994.6, 3754.4, 4071.5, 3863.4, 3848.9, 3776.7, 3701.8, 3662.4, 4122.2, 3809.7, 3872.5, 4169.1, 4092.7, 4022.7, 4031.1, 4064.5, 4036.0, 4123.9, 4161.3, 4302.6, 4370.1, 4415.7, 4055.2, 4528.0, 4066.1, 4156.6, 4022.2, 4307.6, 4387.9, 3977.7, 3041.4, 4635.0, 3749.1, 2931.7, 1249.3, 2473.4, 1286.5, 591.1, 807.5, 793.9, 842.8, 827.6, 968.4, 8.6, 71.7, 462.6, 955.6, 886.7, 1354.0, 1701.2, 2227.1, 1811.5, 2239.6, 2544.5, 2575.7], "es_from_pt_imports_power": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 318.2, 1090.4, 922.3, 36.6, 0.0, 329.7, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0], "es_spot_price": [105.1, 104.24, 102.28, 102.0, 106.63, 105.68, 105.19, 105.01, 104.21, 102.0, 100.0, 100.0, 97.57, 97.51, 97.51, 97.91, 98.5, 100.0, 102.28, 105.0, 101.08, 101.28, 101.76, 102.24, 101.76, 102.24, 104.24, 105.68, 106.55, 110.41, 114.15, 122.58, 140.78, 130.56, 115.17, 106.63, 125.5, 105.01, 92.24, 60.0, 100.24, 65.0, 58.81, 45.0, 59.07, 44.2, 35.87, 24.97, 26.76, 22.5, 23.92, 22.5, 16.99, 16.68, 15.98, 15.45, 6.67, 15.31, 16.35, 17.76, 16.68, 18.94, 16.79, 24.57, 19.0, 26.56, 43.78, 58.55, 25.1, 50.0, 60.0, 77.67, 59.07, 75.01, 101.52, 110.69, 105.68, 112.21, 148.01, 134.33, 194.14, 217.45, 230.0, 230.0, 150.0, 130.0, 123.9, 113.75, 114.01, 109.0, 106.63, 104.24, 105.68, 104.21, 102.0, 101.52], "pt_spot_price": [105.1, 104.24, 102.28, 102.0, 106.63, 105.68, 105.19, 105.01, 104.21, 102.0, 100.0, 100.0, 97.57, 97.51, 97.51, 97.91, 98.5, 100.0, 102.28, 105.0, 101.08, 101.28, 101.76, 102.24, 101.76, 102.24, 104.24, 105.68, 106.55, 110.41, 114.15, 122.58, 140.78, 130.56, 115.17, 106.63, 125.5, 105.01, 92.24, 60.87, 100.24, 65.0, 58.81, 45.0, 59.07, 44.2, 35.87, 24.97, 26.76, 22.5, 23.92, 22.5, 16.99, 16.68, 15.98, 15.45, 6.67, 15.31, 16.35, 17.76, 16.68, 18.94, 16.79, 24.57, 19.0, 26.56, 43.78, 58.55, 25.1, 50.0, 60.0, 77.67, 60.0, 75.01, 101.52, 110.69, 105.68, 112.21, 148.01, 134.33, 194.14, 217.45, 230.0, 230.0, 150.0, 130.0, 123.9, 113.75, 114.01, 109.0, 106.63, 104.24, 105.68, 104.21, 102.0, 101.52]```
````

The output is a JSON payload that may be used by other tooling.

```bash

% pyomie 2025-10-02 | jq -c '.header, .pt_spot_price'
"OMIE - Mercado de electricidad;Fecha Emisión :01/10/2025 - 14:00;;02/10/2025;Precio del mercado diario (EUR/MWh);;;;"
[105.68,105.01,103.33,103.33,102.28,100.0,99.0,98.7,95.0,95.0,95.0,95.0,95.5,96.99,97.1,98.7,98.7,99.0,100.3,103.29,103.29,103.71,105.68,107.38,103.26,103.5,105.19,110.0,110.41,119.87,125.85,129.55,153.01,140.11,121.06,110.41,119.87,103.36,92.29,58.94,84.5,60.2,55.56,36.2,44.1,37.22,33.32,22.5,28.05,22.5,22.5,17.15,20.16,19.0,16.46,15.06,15.59,16.46,22.5,22.5,15.0,16.46,16.0,18.91,20.7,29.9,30.09,46.89,25.1,40.59,55.52,61.33,47.16,67.4,101.68,104.48,90.0,103.36,110.41,123.9,170.51,201.52,220.0,225.0,180.0,173.66,147.3,125.0,128.81,121.0,115.44,109.91,106.57,105.1,103.84,103.27]
```

You can also `pipx run pyomie` to [run the CLI from a temporary virtual environment](https://pipx.pypa.io/stable/#walkthrough-installing-a-package-and-its-applications-with-pipx).

## Contributors ✨

Thanks to these contributors ([emoji key](https://allcontributors.org/docs/en/emoji-key)):

<!-- prettier-ignore-start -->
<!-- ALL-CONTRIBUTORS-LIST:START - Do not remove or modify this section -->
<!-- prettier-ignore-start -->
<!-- markdownlint-disable -->
<table>
  <tbody>
    <tr>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/luuuis"><img src="https://avatars.githubusercontent.com/u/161006?v=4?s=80" width="80px;" alt="Luis Miranda"/><br /><sub><b>Luis Miranda</b></sub></a><br /><a href="https://github.com/luuuis/pyomie/commits?author=luuuis" title="Code">💻</a> <a href="#ideas-luuuis" title="Ideas, Planning, & Feedback">🤔</a> <a href="https://github.com/luuuis/pyomie/commits?author=luuuis" title="Documentation">📖</a></td>
    </tr>
  </tbody>
</table>

<!-- markdownlint-restore -->
<!-- prettier-ignore-end -->

<!-- ALL-CONTRIBUTORS-LIST:END -->
<!-- prettier-ignore-end -->

This project follows the [all-contributors](https://github.com/all-contributors/all-contributors) specification. Contributions of any kind welcome!

## Credits

This package was created with
[Copier](https://copier.readthedocs.io/) and the
[browniebroke/pypackage-template](https://github.com/browniebroke/pypackage-template)
project template.
