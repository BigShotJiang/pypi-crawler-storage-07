# -*- coding: utf-8 -*-

from .caster import ecs_caster

caster = ecs_caster

__version__ = "1.40.0"