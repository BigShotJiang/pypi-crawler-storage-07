"""Spark functions."""
