- Tecnativa \<<https://www.tecnativa.com>\>

  > - Víctor Martínez
  > - Pedro Baeza
  > - Carlos López

- APSL-Nagarro \<<https://www.apsl.tech>\>

  > - Antoni Marroig \<<amarroig@apsl.net>\>

- Grupo Isonor \<<https://www.grupoisonor.es>\>

  > - Alexandre D. Díaz
