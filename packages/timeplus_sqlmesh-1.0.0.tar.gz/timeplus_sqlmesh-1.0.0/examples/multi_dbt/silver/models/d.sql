SELECT
  *
FROM {{ ref("c") }}
