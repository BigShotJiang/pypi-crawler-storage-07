from .pan_card import ExtractPanData
from .aadhaar_card import ExtractAadhaarData

__all__ = [
    "ExtractPanData",
    "ExtractAadhaarData",
]