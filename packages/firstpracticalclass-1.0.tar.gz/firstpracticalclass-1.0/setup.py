from setuptools import setup, find_packages

setup(
    name="firstpracticalclass",
    version="1.0",
    author="Farhan",
    author_email="farhanqamar360@gmail.com",
    description="This is just a package",
    packages=find_packages(),
    python_requires=">=3.6",
    entry_point={
        "console_script":[
            "farhanqamar360@gmal.com"
            
            ],
        
        
        },

    )