"""FastMCP sub-servers for macOS applications."""

from .mail import mail_server

__all__ = ["mail_server"]
