from typing import NamedTuple


class WheelEggEcosystemData(NamedTuple):
    dependencies: list[str] | None = None
