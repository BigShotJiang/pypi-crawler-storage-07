"""Contains the domain logic of the application.

Everything related to business logic should be here.
"""
