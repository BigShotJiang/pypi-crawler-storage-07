from .core import parse_incoming_alert as parse
from .clean_parser import parse_incoming_clean_alert as parse_clean
