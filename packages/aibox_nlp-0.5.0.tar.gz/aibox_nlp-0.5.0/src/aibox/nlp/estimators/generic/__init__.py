"""Implementação de estimadores genéricos."""
