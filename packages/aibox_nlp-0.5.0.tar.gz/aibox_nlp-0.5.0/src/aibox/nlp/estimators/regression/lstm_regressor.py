"""Regressor baseado na
arquitetura LSTM.
"""

import typing

from aibox.nlp.estimators.generic.lstm import LSTMEstimator


class LSTMRegressor(LSTMEstimator):
    """Regressor LSTM.

    Para informações sobre a classe acesse
    :py:class:`~aibox.nlp.estimators.generic.lstm.LSTMEstimator`.
    """

    def __init__(
        self,
        hidden_size: int = 20,
        num_layers: int = 2,
        epochs: int = 10,
        bias: bool = True,
        dropout_prob: float = 0,
        bidirectional: bool = False,
        proj_size: int = 0,
        learning_rate: float = 1e-4,
        optim_params: dict = dict(),
        optim: typing.Literal["adam", "adamw", "rmsprop", "adagrad", "sgd"] = "adamw",
        regression_ensure_bounds=False,
        random_state: int | None = None,
        device: str = None,
    ):
        super().__init__(
            hidden_size=hidden_size,
            num_layers=num_layers,
            kind="regressor",
            epochs=epochs,
            bias=bias,
            dropout_prob=dropout_prob,
            bidirectional=bidirectional,
            proj_size=proj_size,
            learning_rate=learning_rate,
            optim_params=optim_params,
            optim=optim,
            regression_ensure_bounds=regression_ensure_bounds,
            random_state=random_state,
            device=device,
        )
