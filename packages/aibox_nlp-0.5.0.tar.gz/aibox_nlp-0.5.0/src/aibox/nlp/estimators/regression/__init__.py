"""Implementação de regressores."""
