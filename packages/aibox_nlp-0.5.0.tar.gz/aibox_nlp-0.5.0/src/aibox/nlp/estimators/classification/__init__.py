"""Implementação de classificadores."""
