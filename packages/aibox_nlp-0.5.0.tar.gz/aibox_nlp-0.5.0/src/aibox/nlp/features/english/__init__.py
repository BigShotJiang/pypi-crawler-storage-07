"""Características para o Inglês."""
