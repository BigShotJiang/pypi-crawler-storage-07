"""Extratores de características."""
