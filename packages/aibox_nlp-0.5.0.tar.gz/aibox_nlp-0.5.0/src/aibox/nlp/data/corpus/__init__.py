"""Implementação de corpus."""
