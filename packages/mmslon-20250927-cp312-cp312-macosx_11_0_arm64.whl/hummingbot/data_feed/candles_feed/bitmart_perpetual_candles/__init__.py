from hummingbot.data_feed.candles_feed.bitmart_perpetual_candles.bitmart_perpetual_candles import (
    BitmartPerpetualCandles,
)

__all__ = ["BitmartPerpetualCandles"]
