from hummingbot.data_feed.candles_feed.bitmart_spot_candles.bitmart_spot_candles import BitmartSpotCandles

__all__ = ["BitmartSpotCandles"]
