from hummingbot.data_feed.candles_feed.binance_spot_candles.binance_spot_candles import BinanceSpotCandles

__all__ = ["BinanceSpotCandles"]
