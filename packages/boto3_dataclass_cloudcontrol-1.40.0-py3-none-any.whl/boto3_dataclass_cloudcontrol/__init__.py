# -*- coding: utf-8 -*-

from .caster import cloudcontrol_caster

caster = cloudcontrol_caster

__version__ = "1.40.0"