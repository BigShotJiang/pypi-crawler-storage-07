from .. import uwsgi

issue_alarm = uwsgi.alarm
