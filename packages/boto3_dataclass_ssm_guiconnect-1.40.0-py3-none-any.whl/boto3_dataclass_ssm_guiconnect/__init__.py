# -*- coding: utf-8 -*-

from .caster import ssm_guiconnect_caster

caster = ssm_guiconnect_caster

__version__ = "1.40.0"