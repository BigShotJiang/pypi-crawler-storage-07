from __future__ import absolute_import

from graphql_client.api.call_api import CallApi
