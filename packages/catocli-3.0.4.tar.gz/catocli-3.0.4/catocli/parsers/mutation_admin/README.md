
## CATO-CLI - mutation.admin:
[Click here](https://api.catonetworks.com/documentation/#mutation-admin) for documentation on this operation.

### Usage for mutation.admin:

`catocli mutation admin -h`
