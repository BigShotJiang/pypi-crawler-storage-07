
## CATO-CLI - query.policy.wanFirewall:
[Click here](https://api.catonetworks.com/documentation/#query-wanFirewall) for documentation on this operation.

### Usage for query.policy.wanFirewall:

`catocli query policy wanFirewall -h`
