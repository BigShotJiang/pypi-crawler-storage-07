
## CATO-CLI - mutation.policy.wanNetwork:
[Click here](https://api.catonetworks.com/documentation/#mutation-wanNetwork) for documentation on this operation.

### Usage for mutation.policy.wanNetwork:

`catocli mutation policy wanNetwork -h`
