
## CATO-CLI - mutation.policy.socketLan:
[Click here](https://api.catonetworks.com/documentation/#mutation-socketLan) for documentation on this operation.

### Usage for mutation.policy.socketLan:

`catocli mutation policy socketLan -h`
