from cccv.auto.config import AutoConfig
from cccv.auto.model import AutoModel
