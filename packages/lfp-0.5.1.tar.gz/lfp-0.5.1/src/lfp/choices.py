DATABASE_CHOICES = [
    "sqlite",
    "postgresql",
]

FRONTEND_CHOICES = [
    "htmx",
    "vue",
    "react",
    "svelte",
]
