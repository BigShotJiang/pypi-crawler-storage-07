from .main import app

app(prog_name="lfp")
