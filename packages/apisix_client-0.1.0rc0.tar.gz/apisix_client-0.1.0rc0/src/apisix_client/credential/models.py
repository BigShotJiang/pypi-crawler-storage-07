import attrs


@attrs.define()
class CredentialResponse: ...
