import attrs


@attrs.define()
class GlobalRuleResponse: ...
