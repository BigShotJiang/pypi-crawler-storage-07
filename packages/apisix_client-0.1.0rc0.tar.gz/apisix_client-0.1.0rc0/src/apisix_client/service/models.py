import attrs


@attrs.define()
class ServiceResponse: ...
