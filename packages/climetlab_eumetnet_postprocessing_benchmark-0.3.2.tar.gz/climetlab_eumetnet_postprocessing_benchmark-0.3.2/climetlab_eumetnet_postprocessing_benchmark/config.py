
baseurl = "https://object-store.os-api.cci1.ecmwf.int/eumetnet-postprocessing-benchmark-training-dataset/"

EUPP_baseurl = "https://object-store.os-api.cci1.ecmwf.int/eumetnet-postprocessing-benchmark-1st-phase-training-dataset/"

EUPreciP_baseurl = "https://object-store.os-api.cci1.ecmwf.int/eumetnet-postprocessing-benchmark-precip-dataset/"
