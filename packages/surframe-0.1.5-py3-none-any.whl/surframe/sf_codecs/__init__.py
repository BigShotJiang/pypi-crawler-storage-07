# -*- coding: utf-8 -*-
"""Namespace de codecs (CAT/NUM/TS) — stubs."""
