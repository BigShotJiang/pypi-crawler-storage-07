Orange Widget Core
