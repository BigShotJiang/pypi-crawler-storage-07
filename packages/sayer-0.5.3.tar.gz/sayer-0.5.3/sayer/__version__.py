__version__ = "0.5.3"


def get_version() -> str:
    """
    Get the current version of Sayer.
    """
    return __version__
