# InfraGraph (INFRAstructure GRAPH)

InfraGraph defines a [model-driven, vendor-neutral API](https://infragraph.dev/openapi.html) for capturing a system of systems suitable for use in co-designing AI/HPC solutions.

The model and API allows for defining physical infrastructure using a standardized graph like terminology.

In addition to the base graph definition, user provided `annotations` can `extend the graph` allowing for an unlimited number of different physical and/or logical characteristics/view.

Additional information such as background, schema and examples can be found in the [online documentation](https://infragraph.dev).

Contributions can be made in the following ways:
- [open an issue](https://github.com/keysight/infragraph/issues) in the repository
- [fork the models repository](https://github.com/keysight/infragraph) and submit a PR