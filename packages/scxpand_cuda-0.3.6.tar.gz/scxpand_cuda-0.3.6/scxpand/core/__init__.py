# Core module for scXpand
