"""
Template tags for Cloudflare Images.
"""
