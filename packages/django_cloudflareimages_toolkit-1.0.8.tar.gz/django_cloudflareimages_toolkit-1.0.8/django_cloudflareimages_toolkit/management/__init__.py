"""
Management commands for Cloudflare Images.
"""
