print('Hello, World!')
