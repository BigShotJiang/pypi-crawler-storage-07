def main():
    print("Hello from glitchlings!")


if __name__ == "__main__":
    main()
