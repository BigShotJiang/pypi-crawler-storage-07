This module allows to store on stock move line level (when reserving quantities
on movement level) the reserved quant.

For instance, this allows to filter the locations based on the quant properties
(lot, ...) being transfered to a particular destination location
(e.g.: see stock_storage_type module).
