# -*- coding: utf-8 -*-
from yookassa.domain.common.payment_method_type import PaymentMethodType
from yookassa.domain.models.payment_data.payment_data import ResponsePaymentData


class PaymentDataInstallments(ResponsePaymentData):
    """
    Оплата через сервис «Заплатить по частям» (в кредит или рассрочку).
    """  # noqa: E501

    def __init__(self, *args, **kwargs):
        super(PaymentDataInstallments, self).__init__(*args, **kwargs)
        if self.type is None or self.type is not PaymentMethodType.INSTALMENTS:
            self.type = PaymentMethodType.INSTALMENTS
