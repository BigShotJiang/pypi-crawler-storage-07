# -*- coding: utf-8 -*-

from .caster import neptune_caster

caster = neptune_caster

__version__ = "1.40.0"