This module is a glue module between `sale_brand` and `partner_brand`.

If the customer has a brand assigned, it will set that brand on the Sales Order. If the customer has no brand, or if the customer is cleared from the SO, the brand on the SO will also be cleared.
