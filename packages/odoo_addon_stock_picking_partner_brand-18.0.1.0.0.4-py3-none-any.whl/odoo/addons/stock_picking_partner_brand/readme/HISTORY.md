## 18.0.1.0.0 (2025-05-20)

-   [ADD] First Release of module.
