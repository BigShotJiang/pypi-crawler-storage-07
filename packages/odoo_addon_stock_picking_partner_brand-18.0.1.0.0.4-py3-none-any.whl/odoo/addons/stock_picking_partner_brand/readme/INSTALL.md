
To install this module, you need to:

1.  Place the `sale_brand` module in your Odoo addons path.
2.  Install the `partner_brand` module in Odoo.

It will auto install if all the dependencies are available.
