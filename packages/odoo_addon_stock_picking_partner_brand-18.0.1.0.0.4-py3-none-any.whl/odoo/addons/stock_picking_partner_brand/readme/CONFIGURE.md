1. Configure Brands on Partners:
Navigate to Contacts.
Open the customer records for which you want to assign a brand.

2. On the customer form, locate the "Brand" field (provided by partner_brand) and select the appropriate brand.

3. Save the changes.
