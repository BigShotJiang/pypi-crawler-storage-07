from . import test_stock_picking_partner_brand
