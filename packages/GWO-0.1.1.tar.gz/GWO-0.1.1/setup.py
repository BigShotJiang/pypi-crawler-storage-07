from setuptools import setup, find_packages

setup(
    name="GWO",
    version="0.1.1",
    packages=find_packages(),
    author="RebornEnder",
    author_email="contact@dotbend.xyz",
    description="a damn fine wrapper for reverse-enginered gwo api",
    url="https://github.com/Reb0rnEnder/GWOApi",
    license="LICENCE",
    install_requires=[
        "aiohttp[speedups]>=3.12.15",
        "beautifulsoup4>=4.14.2",
        "unicodeit>=0.7.5"
    ]
)