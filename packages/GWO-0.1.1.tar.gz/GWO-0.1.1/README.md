## GWOApi
Really **cool** module for interacting with gdańskie wydawnictwo oświatowe's apps
> Uses only 3 external packages

```bash
> pip install -U GWO
```

## Usage
```python
import GWO
client = GWO.API.login()
print(f"Hello, {client.user.name}")
```