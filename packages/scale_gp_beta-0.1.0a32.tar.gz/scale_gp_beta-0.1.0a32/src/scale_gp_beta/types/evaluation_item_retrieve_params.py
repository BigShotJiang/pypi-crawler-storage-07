# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["EvaluationItemRetrieveParams"]


class EvaluationItemRetrieveParams(TypedDict, total=False):
    include_archived: bool
