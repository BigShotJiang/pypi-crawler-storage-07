# package metadata
package_name = "osmosis-ai"
package_version = "0.2.1"
