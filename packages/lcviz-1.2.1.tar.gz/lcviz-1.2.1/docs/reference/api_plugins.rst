.. _jdaviz-api-plugins:

Plugins API
===========

.. automodapi:: lcviz.plugins.binning.binning
  :no-inheritance-diagram:

.. automodapi:: lcviz.plugins.ephemeris.ephemeris
  :no-inheritance-diagram:

.. automodapi:: lcviz.plugins.export.export
  :no-inheritance-diagram:

.. automodapi:: lcviz.plugins.flatten.flatten
  :no-inheritance-diagram:

.. automodapi:: lcviz.plugins.flux_column.flux_column
  :no-inheritance-diagram:

.. automodapi:: lcviz.plugins.frequency_analysis.frequency_analysis
  :no-inheritance-diagram:

.. automodapi:: lcviz.plugins.markers.markers
  :no-inheritance-diagram:

.. automodapi:: lcviz.plugins.metadata_viewer.metadata_viewer
  :no-inheritance-diagram:

.. automodapi:: lcviz.plugins.plot_options.plot_options
  :no-inheritance-diagram:

.. automodapi:: lcviz.plugins.stitch.stitch
  :no-inheritance-diagram:

.. automodapi:: lcviz.plugins.subset_tools.subset_tools
  :no-inheritance-diagram:

.. automodapi:: lcviz.plugins.time_selector.time_selector
  :no-inheritance-diagram:
