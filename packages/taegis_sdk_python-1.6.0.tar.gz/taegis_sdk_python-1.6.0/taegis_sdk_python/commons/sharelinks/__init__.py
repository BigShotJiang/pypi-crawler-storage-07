"""Taegis Common Sharelinks Service Implementations."""
