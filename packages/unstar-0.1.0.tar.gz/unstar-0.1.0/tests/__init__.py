# Tests for unstar
