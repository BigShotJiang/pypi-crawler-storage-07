============
Installation
============

At the command line::

    $ pip install suitcase-nomad-camels-hdf5
