=====
Usage
=====

Start by importing ``suitcase.nomad-camels-hdf5``.

.. code-block:: python

    import suitcase.nomad_camels_hdf5
