# -*- coding: utf-8 -*-

from .caster import elasticache_caster

caster = elasticache_caster

__version__ = "1.40.0"