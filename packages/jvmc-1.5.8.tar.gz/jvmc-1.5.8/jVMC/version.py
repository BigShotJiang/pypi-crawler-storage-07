"""Current jVMC version at head on Github."""
__version__ = "1.5.8"
