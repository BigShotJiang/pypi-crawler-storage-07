"""Storage management for conversation extension pipeline."""

import json
import os
from pathlib import Path
from typing import Dict, Any
from omnigen.core.exceptions import StorageError


class ConversationExtensionStorage:
    """
    Storage manager for Conversation Extension Pipeline.
    
    Each pipeline has its own storage class with pipeline-specific needs.
    Handles JSONL output with automatic workspace isolation.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """Initialize storage."""
        self.config = config
        self.storage_type = config.get('type', 'jsonl')
        self.output_file = config.get('output_file', 'output.jsonl')
        self.partial_file = config.get('partial_file', 'partial.jsonl')
        self.failed_file = config.get('failed_file', 'failed.jsonl')
        
        # Create directories if needed
        self._ensure_directories()
    
    def _ensure_directories(self):
        """Create output directories if they don't exist."""
        for filepath in [self.output_file, self.partial_file, self.failed_file]:
            Path(filepath).parent.mkdir(parents=True, exist_ok=True)
    
    def save(self, conversation: Dict[str, Any]):
        """
        Save a conversation to appropriate file.
        
        Saves both partial and complete conversations to main output file
        with status indicators. Failed conversations go to separate file.
        
        Args:
            conversation: Conversation data with 'success' and status flags
        """
        try:
            # Add status indicator to conversation
            conv_with_status = conversation.copy()
            
            if conversation.get('success'):
                conv_with_status['status'] = 'completed'
                conv_with_status['is_complete'] = True
                # Save to main output file
                self._append_jsonl(self.output_file, conv_with_status)
            elif conversation.get('is_partial'):
                conv_with_status['status'] = 'partial'
                conv_with_status['is_complete'] = False
                # Save to main output file (user requested)
                self._append_jsonl(self.output_file, conv_with_status)
            else:
                conv_with_status['status'] = 'failed'
                conv_with_status['is_complete'] = False
                # Save failed to separate file
                self._append_jsonl(self.failed_file, conv_with_status)
        except Exception as e:
            raise StorageError(f"Failed to save conversation: {e}")
    
    def _append_jsonl(self, filepath: str, data: Dict[str, Any]):
        """Append data to JSONL file."""
        with open(filepath, 'a', encoding='utf-8') as f:
            f.write(json.dumps(data, ensure_ascii=False) + '\n')
    
    def get_stats(self) -> Dict[str, Any]:
        """Get storage statistics."""
        stats = {
            'output_count': 0,
            'completed_count': 0,
            'partial_count': 0,
            'failed_count': 0
        }
        
        # Count in output file by status
        if os.path.exists(self.output_file):
            with open(self.output_file, 'r') as f:
                for line in f:
                    try:
                        data = json.loads(line)
                        stats['output_count'] += 1
                        status = data.get('status', 'unknown')
                        if status == 'completed':
                            stats['completed_count'] += 1
                        elif status == 'partial':
                            stats['partial_count'] += 1
                    except:
                        continue
        
        # Count failed
        if os.path.exists(self.failed_file):
            with open(self.failed_file, 'r') as f:
                stats['failed_count'] = sum(1 for _ in f)
        
        return stats