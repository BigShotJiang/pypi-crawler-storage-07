"""Checkpoint manager for conversation extension pipeline."""

import json
import hashlib
import os
import uuid
from pathlib import Path
from typing import Dict, Any, Optional, List, Set
from datetime import datetime
from omnigen.utils.logger import setup_logger

logger = setup_logger()


class CheckpointManager:
    """
    Manages checkpoint/resume functionality for the pipeline.
    
    Enables recovery from interruptions without data loss or duplication.
    Uses hybrid identification (position + content hash) for reliability.
    """
    
    def __init__(self, checkpoint_path: str, config: Dict[str, Any]):
        """
        Initialize checkpoint manager.
        
        Args:
            checkpoint_path: Path to checkpoint file
            config: Pipeline configuration
        """
        self.checkpoint_path = Path(checkpoint_path)
        self.config = config
        self.checkpoint_data: Dict[str, Any] = {}
        self.processed_ids: Set[str] = set()
        self.partial_states: Dict[str, Dict] = {}
        
        # Ensure directory exists
        self.checkpoint_path.parent.mkdir(parents=True, exist_ok=True)
    
    def load_or_create(self) -> Dict[str, Any]:
        """
        Load existing checkpoint or create new one.
        
        Returns:
            Checkpoint data dictionary
        """
        if self.checkpoint_path.exists():
            try:
                with open(self.checkpoint_path, 'r', encoding='utf-8') as f:
                    self.checkpoint_data = json.load(f)
                
                # Validate checkpoint
                if self._validate_checkpoint():
                    logger.info(f"✓ Loaded checkpoint: {self.checkpoint_path}")
                    self._load_processed_ids()
                    return self.checkpoint_data
                else:
                    logger.warning("⚠️  Invalid checkpoint, backing up and starting fresh")
                    self._backup_checkpoint()
                    return self._create_new_checkpoint()
            except Exception as e:
                logger.error(f"Error loading checkpoint: {e}")
                self._backup_checkpoint()
                return self._create_new_checkpoint()
        else:
            return self._create_new_checkpoint()
    
    def _create_new_checkpoint(self) -> Dict[str, Any]:
        """Create new checkpoint structure."""
        self.checkpoint_data = {
            'version': '1.0',
            'run_id': str(uuid.uuid4()),
            'started_at': datetime.utcnow().isoformat(),
            'last_checkpoint_at': datetime.utcnow().isoformat(),
            'base_data': {
                'source_type': self.config.get('base_data', {}).get('source_type', 'file'),
                'file_path': self.config.get('base_data', {}).get('file_path', ''),
                'file_hash': self._calculate_input_hash(),
                'total_available': 0
            },
            'progress': {
                'total_processed': 0,
                'completed': 0,
                'partial': 0,
                'failed': 0,
                'skipped': 0,
                'last_position': -1
            },
            'processed_records': [],
            'partial_states': {}
        }
        self._save_checkpoint()
        logger.info(f"✓ Created new checkpoint: {self.checkpoint_path}")
        return self.checkpoint_data
    
    def _validate_checkpoint(self) -> bool:
        """Validate checkpoint structure and version."""
        required_keys = ['version', 'run_id', 'base_data', 'progress', 'processed_records']
        
        if not all(key in self.checkpoint_data for key in required_keys):
            return False
        
        # Check version compatibility
        if self.checkpoint_data.get('version') != '1.0':
            return False
        
        # Validate input file hasn't changed (if configured)
        if self.config.get('checkpoint', {}).get('validate_input_hash', True):
            stored_hash = self.checkpoint_data.get('base_data', {}).get('file_hash', '')
            current_hash = self._calculate_input_hash()
            
            if stored_hash and current_hash and stored_hash != current_hash:
                logger.warning("⚠️  Input file has changed since checkpoint was created")
                return False
        
        return True
    
    def _calculate_input_hash(self) -> str:
        """Calculate SHA256 hash of input file."""
        file_path = self.config.get('base_data', {}).get('file_path', '')
        
        if not file_path or not os.path.exists(file_path):
            return ''
        
        try:
            sha256 = hashlib.sha256()
            with open(file_path, 'rb') as f:
                for chunk in iter(lambda: f.read(8192), b''):
                    sha256.update(chunk)
            return sha256.hexdigest()
        except Exception as e:
            logger.warning(f"Could not calculate input hash: {e}")
            return ''
    
    def _load_processed_ids(self):
        """Load processed conversation IDs into set for quick lookup."""
        self.processed_ids.clear()
        for record in self.checkpoint_data.get('processed_records', []):
            conv_id = self._make_conversation_id(
                record.get('position', -1),
                record.get('content_hash', '')
            )
            self.processed_ids.add(conv_id)
        
        # Load partial states
        self.partial_states = self.checkpoint_data.get('partial_states', {})
        
        logger.info(f"Loaded {len(self.processed_ids)} processed conversation IDs")
        logger.info(f"Found {len(self.partial_states)} partial conversations to resume")
    
    def is_processed(self, position: int, content_hash: str) -> bool:
        """
        Check if conversation already processed.
        
        Args:
            position: Position in base data
            content_hash: Content hash of conversation
            
        Returns:
            True if already processed
        """
        conv_id = self._make_conversation_id(position, content_hash)
        return conv_id in self.processed_ids
    
    def add_processed(
        self,
        position: int,
        content_hash: str,
        status: str,
        conversation: Dict[str, Any],
        save_checkpoint: bool = True
    ):
        """
        Add conversation to processed records.
        
        Args:
            position: Position in base data
            content_hash: Content hash
            status: 'completed', 'partial', or 'failed'
            conversation: Full conversation data
            save_checkpoint: Whether to save checkpoint immediately
        """
        conv_id = self._make_conversation_id(position, content_hash)
        
        record = {
            'position': position,
            'content_hash': content_hash,
            'status': status,
            'turns_generated': sum(1 for m in conversation.get('conversations', []) if m.get('role') == 'user'),
            'last_message_role': conversation.get('conversations', [])[-1].get('role') if conversation.get('conversations') else None,
            'processed_at': datetime.utcnow().isoformat()
        }
        
        # Add to records
        self.checkpoint_data['processed_records'].append(record)
        self.processed_ids.add(conv_id)
        
        # Update progress
        progress = self.checkpoint_data['progress']
        progress['total_processed'] += 1
        progress['last_position'] = position
        
        if status == 'completed':
            progress['completed'] += 1
        elif status == 'partial':
            progress['partial'] += 1
        elif status == 'failed':
            progress['failed'] += 1
        elif status == 'skipped':
            progress['skipped'] += 1
        
        # Handle partial state
        if status == 'partial':
            self.partial_states[conv_id] = {
                'position': position,
                'content_hash': content_hash,
                'conversation': conversation.get('conversations', []),
                'turns_completed': record['turns_generated'],
                'last_role': record['last_message_role']
            }
            self.checkpoint_data['partial_states'] = self.partial_states
        elif conv_id in self.partial_states:
            # Remove from partial if now completed/failed
            del self.partial_states[conv_id]
            self.checkpoint_data['partial_states'] = self.partial_states
        
        if save_checkpoint:
            self._save_checkpoint()
    
    def get_partial_state(self, position: int, content_hash: str) -> Optional[Dict]:
        """
        Get partial conversation state for resume.
        
        Args:
            position: Position in base data
            content_hash: Content hash
            
        Returns:
            Partial state dict or None
        """
        conv_id = self._make_conversation_id(position, content_hash)
        return self.partial_states.get(conv_id)
    
    def get_resume_position(self) -> int:
        """Get position to resume from."""
        return self.checkpoint_data.get('progress', {}).get('last_position', -1) + 1
    
    def get_progress_summary(self) -> Dict[str, Any]:
        """Get progress summary for display."""
        progress = self.checkpoint_data.get('progress', {})
        return {
            'total_processed': progress.get('total_processed', 0),
            'completed': progress.get('completed', 0),
            'partial': progress.get('partial', 0),
            'failed': progress.get('failed', 0),
            'skipped': progress.get('skipped', 0),
            'last_position': progress.get('last_position', -1),
            'has_partials': len(self.partial_states) > 0,
            'num_partials': len(self.partial_states)
        }
    
    def _save_checkpoint(self):
        """Save checkpoint atomically."""
        try:
            self.checkpoint_data['last_checkpoint_at'] = datetime.utcnow().isoformat()
            
            # Write to temporary file
            temp_path = self.checkpoint_path.with_suffix('.tmp')
            with open(temp_path, 'w', encoding='utf-8') as f:
                json.dump(self.checkpoint_data, f, indent=2, ensure_ascii=False)
                f.flush()
                os.fsync(f.fileno())
            
            # Atomic rename
            temp_path.replace(self.checkpoint_path)
            
        except Exception as e:
            logger.error(f"Error saving checkpoint: {e}")
            raise
    
    def _backup_checkpoint(self):
        """Backup corrupted checkpoint."""
        if self.checkpoint_path.exists():
            backup_path = self.checkpoint_path.with_suffix('.backup')
            try:
                self.checkpoint_path.rename(backup_path)
                logger.info(f"Backed up checkpoint to: {backup_path}")
            except Exception as e:
                logger.error(f"Error backing up checkpoint: {e}")
    
    def _make_conversation_id(self, position: int, content_hash: str) -> str:
        """Create unique conversation ID from position and hash."""
        return f"{position}_{content_hash[:8]}"
    
    @staticmethod
    def calculate_content_hash(conversation: List[Dict]) -> str:
        """
        Calculate SHA256 hash of conversation content.
        
        Args:
            conversation: List of conversation messages
            
        Returns:
            Hex digest of hash
        """
        # Create deterministic string representation
        content = json.dumps(conversation, sort_keys=True, ensure_ascii=False)
        return hashlib.sha256(content.encode('utf-8')).hexdigest()