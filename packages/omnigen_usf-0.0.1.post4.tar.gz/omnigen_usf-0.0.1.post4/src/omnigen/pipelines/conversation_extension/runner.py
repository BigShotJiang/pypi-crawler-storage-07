"""Runner for conversation extension pipeline with parallel execution."""

import time
import signal
from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm
from omnigen.pipelines.conversation_extension.config import ConversationExtensionConfig
from omnigen.pipelines.conversation_extension.storage import ConversationExtensionStorage
from omnigen.pipelines.conversation_extension.checkpoint import CheckpointManager
from omnigen.utils.rate_limiter import RateLimiter
from omnigen.utils.logger import setup_logger
from omnigen.pipelines.conversation_extension.generator import ConversationGenerator
from omnigen.pipelines.conversation_extension.data_loader import BaseConversationLoader

logger = setup_logger()


class Runner:
    """Main runner for conversation extension pipeline."""
    
    def __init__(self, config: ConversationExtensionConfig):
        self.config = config
        self.rate_limiter = RateLimiter()
        
        # Initialize checkpoint manager
        checkpoint_config = config.get('checkpoint', {})
        checkpoint_enabled = checkpoint_config.get('enabled', True)
        
        if checkpoint_enabled:
            workspace_id = config.get('workspace_id', 'default')
            checkpoint_file = checkpoint_config.get(
                'checkpoint_file',
                f'workspaces/{workspace_id}/checkpoint.json'
            )
            self.checkpoint_manager = CheckpointManager(checkpoint_file, config.to_dict())
            self.checkpoint_data = self.checkpoint_manager.load_or_create()
        else:
            self.checkpoint_manager = None
            self.checkpoint_data = None
        
        # Initialize components with checkpoint manager
        self.data_loader = BaseConversationLoader(config, self.checkpoint_manager)
        self.generator = ConversationGenerator(config, self.rate_limiter)
        self.storage = ConversationExtensionStorage(config.get('storage', {}))
        
        # Track for graceful shutdown
        self.shutdown_requested = False
        self._setup_signal_handlers()
    
    def _setup_signal_handlers(self):
        """Setup handlers for graceful shutdown."""
        def signal_handler(signum, frame):
            logger.warning("\n⚠️  Shutdown signal received. Saving checkpoint...")
            self.shutdown_requested = True
        
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
    
    def run(self):
        """Run the pipeline with checkpoint/resume support."""
        try:
            num_convs_requested = self.config.get('generation.num_conversations')
            num_workers = self.config.get('generation.parallel_workers', 10)
            num_base_convs = len(self.data_loader.base_conversations)
            
            # Check if resuming
            is_resuming = False
            if self.checkpoint_manager:
                progress = self.checkpoint_manager.get_progress_summary()
                if progress['total_processed'] > 0:
                    is_resuming = True
            
            # Handle "process all" mode: 0, None, or not specified
            if num_convs_requested in (0, None):
                num_convs = num_base_convs
                process_all_mode = True
            else:
                # Calculate effective count (min of requested and available)
                num_convs = min(num_convs_requested, num_base_convs)
                process_all_mode = False
                
                # Warn if limiting to prevent duplicates
                if num_convs_requested > num_base_convs:
                    logger.warning(
                        f"⚠️  Requested {num_convs_requested} conversations but only "
                        f"{num_base_convs} base conversations available. "
                        f"Limiting to {num_convs} to prevent duplicates."
                    )
            
            # Display header
            logger.info("="*60)
            if is_resuming:
                logger.info("RESUMING FROM CHECKPOINT")
                logger.info("="*60)
                progress = self.checkpoint_manager.get_progress_summary()
                logger.info(f"Previous Run: {self.checkpoint_data.get('started_at', 'Unknown')}")
                logger.info(f"Already Processed: {progress['total_processed']} "
                          f"(✓{progress['completed']} ⚠{progress['partial']} ✗{progress['failed']} ~{progress['skipped']})")
                logger.info(f"Resuming Partials: {progress['num_partials']}")
                remaining = num_convs - progress['total_processed']
                logger.info(f"Remaining: {remaining}")
            else:
                logger.info("CONVERSATION EXTENSION PIPELINE")
                logger.info("="*60)
                logger.info(f"Base conversations: {num_base_convs}")
                if process_all_mode:
                    logger.info(f"Mode: Process ALL conversations")
                else:
                    logger.info(f"Requested: {num_convs_requested}")
                logger.info(f"Generating: {num_convs}")
            
            logger.info(f"Parallel workers: {num_workers}")
            logger.info("="*60)
            
            self._generate_parallel(num_convs, num_workers)
            
        except KeyboardInterrupt:
            logger.warning("\n⚠️  Interrupted. Progress saved in checkpoint.")
        except Exception as e:
            logger.error(f"Fatal error: {e}")
            raise
    
    def _generate_parallel(self, num_conversations: int, num_workers: int):
        """Generate conversations in parallel with checkpoint support."""
        complete = 0
        partial = 0
        failed = 0
        skipped = 0
        start_time = time.time()
        
        # Get initial progress if resuming
        if self.checkpoint_manager:
            progress = self.checkpoint_manager.get_progress_summary()
            complete = progress['completed']
            partial = progress['partial']
            failed = progress['failed']
            skipped = progress['skipped']
        
        pbar = tqdm(
            total=num_conversations,
            desc="Generating",
            unit=" conv",
            colour='cyan',
            ncols=140,
            initial=complete + partial + failed + skipped
        )
        
        with ThreadPoolExecutor(max_workers=num_workers, thread_name_prefix="Worker") as executor:
            futures = {}
            submitted = 0
            
            # Submit conversations
            try:
                for i in range(num_conversations):
                    if self.shutdown_requested:
                        logger.warning("Shutdown requested, stopping submission")
                        break
                    
                    try:
                        base_conv = self.data_loader.get_next_conversation()
                        position = base_conv.get('_position', -1)
                        content_hash = base_conv.get('_content_hash', '')
                        
                        # Check for partial state to resume
                        partial_state = None
                        if self.checkpoint_manager:
                            partial_state = self.checkpoint_manager.get_partial_state(position, content_hash)
                        
                        future = executor.submit(
                            self.generator.generate_conversation,
                            base_conv,
                            i,
                            partial_state
                        )
                        futures[future] = (i, position, content_hash)
                        submitted += 1
                    except RuntimeError:
                        # No more conversations available
                        break
            except Exception as e:
                logger.error(f"Error submitting conversations: {e}")
            
            # Process results
            batch_count = 0
            auto_save_freq = self.config.get('checkpoint.auto_save_frequency', 10)
            
            for future in as_completed(futures):
                if self.shutdown_requested:
                    logger.warning("Shutdown requested, waiting for running tasks...")
                
                conv_id, position, content_hash = futures[future]
                
                try:
                    result = future.result()
                    
                    # Skip if marked as skipped
                    if result.get('skipped'):
                        skipped += 1
                        continue
                    
                    # Save to storage
                    self.storage.save(result)
                    
                    # Determine status
                    status = 'failed'
                    if result.get('success'):
                        complete += 1
                        status = 'completed'
                    elif result.get('is_partial'):
                        partial += 1
                        status = 'partial'
                    else:
                        failed += 1
                        status = 'failed'
                    
                    # Save to checkpoint
                    if self.checkpoint_manager:
                        self.checkpoint_manager.add_processed(
                            position,
                            content_hash,
                            status,
                            result,
                            save_checkpoint=False  # Batch save
                        )
                        batch_count += 1
                        
                        # Auto-save checkpoint every N conversations
                        if batch_count >= auto_save_freq:
                            self.checkpoint_manager._save_checkpoint()
                            batch_count = 0
                    
                    # Update progress
                    rpm = self.rate_limiter.get_rpm()
                    pbar.update(1)
                    pbar.set_postfix_str(
                        f"✓{complete} ⚠{partial} ✗{failed} ~{skipped} | RPM:{rpm}"
                    )
                    
                except Exception as e:
                    logger.error(f"Error processing conv {conv_id}: {e}")
                    failed += 1
                    
                    # Save failed to checkpoint
                    if self.checkpoint_manager:
                        self.checkpoint_manager.add_processed(
                            position,
                            content_hash,
                            'failed',
                            {'id': conv_id, 'error': str(e), 'conversations': []},
                            save_checkpoint=False
                        )
                    
                    pbar.update(1)
            
            # Final checkpoint save
            if self.checkpoint_manager:
                self.checkpoint_manager._save_checkpoint()
                logger.info("✓ Final checkpoint saved")
        
        pbar.close()
        
        # Summary
        total_time = time.time() - start_time
        total = complete + partial + failed
        
        print("\n" + "="*60)
        print("GENERATION COMPLETE")
        print("="*60)
        print(f"✓ Complete: {complete:>5}")
        print(f"⚠ Partial:  {partial:>5}")
        print(f"✗ Failed:   {failed:>5}")
        print(f"~ Skipped:  {skipped:>5}")
        print(f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print(f"💾 Saved:   {complete + partial:>5}  ({(complete+partial)/total*100:.1f}% of processed)")
        print(f"⏱  Time:    {total_time/60:>5.1f} min")
        if total > 0:
            print(f"⚡ Speed:   {total/total_time:>5.2f} conv/s")
        print("="*60)
        
        if self.checkpoint_manager:
            print(f"\n📊 Checkpoint: {self.checkpoint_manager.checkpoint_path}")