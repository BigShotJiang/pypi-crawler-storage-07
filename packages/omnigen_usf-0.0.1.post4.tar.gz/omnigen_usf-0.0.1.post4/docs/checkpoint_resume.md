# Checkpoint & Resume System

The OmniGen conversation extension pipeline includes a robust checkpoint/resume system that allows you to recover from any interruption without data loss or duplication.

## 🎯 Features

- **Zero Data Loss**: Every conversation is saved before moving to the next
- **No Duplicates**: Hybrid identification (position + content hash) prevents duplicate processing
- **Partial Resume**: Continue incomplete multi-turn conversations from where they stopped
- **API Efficiency**: Resume exactly where you left off, no wasted API calls
- **Handles All Interruptions**: Manual stops (Ctrl+C), errors, rate limits, server failures, crashes

## 📋 How It Works

### Conversation Tracking

Each conversation is uniquely identified using:
- **Position**: Index in the base data file (for ordering)
- **Content Hash**: SHA256 hash of conversation content (for deduplication)
- **Combined ID**: `{position}_{hash[:8]}` for unique tracking

### Checkpoint Structure

```json
{
  "version": "1.0",
  "run_id": "unique-run-id",
  "started_at": "2025-10-04T20:00:00.000Z",
  "last_checkpoint_at": "2025-10-04T20:15:30.000Z",
  "base_data": {
    "source_type": "file",
    "file_path": "input.jsonl",
    "file_hash": "sha256-hash",
    "total_available": 1000
  },
  "progress": {
    "total_processed": 150,
    "completed": 120,
    "partial": 20,
    "failed": 10,
    "last_position": 149
  },
  "processed_records": [
    {
      "position": 0,
      "content_hash": "a1b2c3d4",
      "status": "completed",
      "turns_generated": 5,
      "last_message_role": "assistant",
      "processed_at": "2025-10-04T20:01:00.000Z"
    }
  ],
  "partial_states": {
    "5_b2c3d4e5": {
      "position": 5,
      "content_hash": "b2c3d4e5",
      "conversation": [...],
      "turns_completed": 3,
      "target_turns": 5,
      "last_role": "assistant"
    }
  }
}
```

## 🚀 Usage

### YAML Configuration

```yaml
workspace_id: "my_project"

# Checkpoint configuration
checkpoint:
  enabled: true
  checkpoint_file: "workspaces/my_project/checkpoint.json"
  auto_save_frequency: 10  # Save every 10 conversations
  validate_input_hash: true  # Verify input hasn't changed
  resume_mode: "auto"  # auto | manual | fresh

providers:
  user_followup:
    name: "openai"
    api_key: "${OPENAI_API_KEY}"
    model: "gpt-4"
  
  assistant_response:
    name: "openai"
    api_key: "${OPENAI_API_KEY}"
    model: "gpt-4"

generation:
  num_conversations: 1000
  turn_range:
    min: 3
    max: 8
  parallel_workers: 10
  extension_mode: "smart"

base_data:
  source_type: "file"
  file_path: "input.jsonl"
  format: "conversations"

storage:
  type: "jsonl"
  output_file: "workspaces/my_project/output.jsonl"
```

### Programmatic Usage

```python
from omnigen.pipelines.conversation_extension import (
    ConversationExtensionPipeline,
    ConversationExtensionConfigBuilder
)

# Build configuration with checkpoint enabled
config = (
    ConversationExtensionConfigBuilder(workspace_id="my_project")
    .add_provider(
        role="user_followup",
        name="openai",
        api_key=os.getenv("OPENAI_API_KEY"),
        model="gpt-4"
    )
    .add_provider(
        role="assistant_response",
        name="openai",
        api_key=os.getenv("OPENAI_API_KEY"),
        model="gpt-4"
    )
    .set_generation(
        num_conversations=1000,
        turn_range=(3, 8),
        parallel_workers=10,
        extension_mode="smart"
    )
    .set_data_source(
        source_type="file",
        file_path="input.jsonl",
        format="conversations"
    )
    .set_storage(
        type="jsonl",
        output_file="output.jsonl"
    )
    .set_checkpoint(
        enabled=True,
        auto_save_frequency=10,
        validate_input_hash=True,
        resume_mode="auto"
    )
    .build()
)

# Run pipeline
pipeline = ConversationExtensionPipeline(config)
pipeline.run()
```

## 📊 Resume Behavior

### First Run (No Checkpoint)

```
==========================================
CONVERSATION EXTENSION PIPELINE
==========================================
Base conversations: 1000
Mode: Process ALL conversations
Generating: 1000
Parallel workers: 10
==========================================
Generating: 100%|███████| 1000/1000 [10:00<00:00, ✓850 ⚠100 ✗50 | RPM:100]

==========================================
GENERATION COMPLETE
==========================================
✓ Complete:   850
⚠ Partial:    100
✗ Failed:      50
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💾 Saved:     950  (95.0%)
⏱  Time:     10.0 min
⚡ Speed:    1.67 conv/s
==========================================
```

### Interrupted Run

If you press Ctrl+C or encounter an error:

```
⚠️  Shutdown signal received. Saving checkpoint...
✓ Final checkpoint saved

⚠️  Interrupted. Progress saved in checkpoint.
```

### Resuming from Checkpoint

```
==========================================
RESUMING FROM CHECKPOINT
==========================================
Previous Run: 2025-10-04T20:00:00.000Z
Already Processed: 500 (✓400 ⚠80 ✗20 ~0)
Resuming Partials: 80
Remaining: 500
Parallel workers: 10
==========================================
Generating: 100%|███████| 1000/1000 [05:00<00:00, ✓850 ⚠100 ✗50 | RPM:100]
```

The pipeline will:
1. ✅ Skip already completed conversations
2. ✅ Resume partial conversations from where they stopped
3. ✅ Continue with remaining conversations

## 🔧 Configuration Options

### `checkpoint.enabled`
- **Type**: `boolean`
- **Default**: `true`
- **Description**: Enable/disable checkpoint functionality

### `checkpoint.checkpoint_file`
- **Type**: `string`
- **Default**: `"workspaces/{workspace_id}/checkpoint.json"`
- **Description**: Path to checkpoint file

### `checkpoint.auto_save_frequency`
- **Type**: `integer`
- **Default**: `10`
- **Description**: Save checkpoint every N conversations

### `checkpoint.validate_input_hash`
- **Type**: `boolean`
- **Default**: `true`
- **Description**: Verify input file hasn't changed on resume

### `checkpoint.resume_mode`
- **Type**: `string`
- **Default**: `"auto"`
- **Options**: 
  - `"auto"`: Automatically resume if checkpoint exists
  - `"manual"`: Require explicit confirmation to resume
  - `"fresh"`: Ignore checkpoint and start fresh

## 📝 Output Format

Both partial and complete conversations are saved to the same output file with status indicators:

```jsonl
{"id": 0, "status": "completed", "is_complete": true, "conversations": [...], "num_turns": 5, ...}
{"id": 1, "status": "partial", "is_complete": false, "conversations": [...], "num_turns": 3, ...}
{"id": 2, "status": "completed", "is_complete": true, "conversations": [...], "num_turns": 7, ...}
```

### Status Values

- **`completed`**: Successfully generated all requested turns
- **`partial`**: Interrupted during generation, may be incomplete
- **`failed`**: Error occurred, saved to failed file

## 🛡️ Safety Features

### Atomic Operations
All checkpoint saves use atomic file operations:
1. Write to temporary file: `checkpoint.tmp`
2. Sync to disk (`fsync`)
3. Atomic rename: `checkpoint.tmp` → `checkpoint.json`

### Input Validation
- SHA256 hash of input file is stored in checkpoint
- On resume, verifies input file hasn't changed
- Prevents processing wrong data

### Corruption Recovery
- Automatic validation on checkpoint load
- Corrupted checkpoints are backed up
- Fresh start with backup preserved

### Graceful Shutdown
- Signal handlers for SIGINT (Ctrl+C) and SIGTERM
- All running tasks complete before shutdown
- Final checkpoint saved automatically

## 🔍 Troubleshooting

### Checkpoint Not Resuming

**Problem**: Pipeline starts fresh despite existing checkpoint

**Solutions**:
1. Check `checkpoint.enabled` is `true`
2. Verify checkpoint file exists at specified path
3. Check `checkpoint.resume_mode` is not set to `"fresh"`
4. Review logs for checkpoint validation errors

### Input File Changed Warning

**Problem**: Warning about input file change on resume

**Solutions**:
1. If intentional, set `checkpoint.validate_input_hash: false`
2. If unintentional, restore original input file
3. Or delete checkpoint to start fresh: `rm checkpoint.json`

### Partial Conversations Not Resuming

**Problem**: Partial conversations restart from beginning

**Solutions**:
1. Ensure `partial_states` exists in checkpoint
2. Verify conversation has `_position` and `_content_hash` metadata
3. Check logs for partial state loading errors

## 💡 Best Practices

1. **Set Appropriate Save Frequency**
   ```yaml
   checkpoint:
     auto_save_frequency: 10  # Balance between performance and safety
   ```

2. **Use Workspace Isolation**
   ```python
   config = ConversationExtensionConfigBuilder(
       workspace_id="unique_project_id"  # Prevents conflicts
   )
   ```

3. **Monitor Checkpoint Size**
   - Large checkpoints (>100MB) may slow down saves
   - Consider processing in batches for very large datasets

4. **Backup Important Checkpoints**
   ```bash
   cp checkpoint.json checkpoint.backup.json
   ```

5. **Clean Up Old Checkpoints**
   ```bash
   # After successful completion
   rm checkpoint.json
   ```

## 🎬 Complete Example

```python
import os
from omnigen.pipelines.conversation_extension import (
    ConversationExtensionPipeline,
    ConversationExtensionConfigBuilder
)

# Configuration
config = (
    ConversationExtensionConfigBuilder(workspace_id="production_v1")
    .add_provider(
        role="user_followup",
        name="openai",
        api_key=os.getenv("OPENAI_API_KEY"),
        model="gpt-4-turbo"
    )
    .add_provider(
        role="assistant_response", 
        name="openai",
        api_key=os.getenv("OPENAI_API_KEY"),
        model="gpt-4-turbo"
    )
    .set_generation(
        num_conversations=10000,
        turn_range=(3, 8),
        parallel_workers=20,
        extension_mode="smart"
    )
    .set_data_source(
        source_type="file",
        file_path="data/base_conversations.jsonl",
        format="conversations"
    )
    .set_storage(
        type="jsonl",
        output_file="output.jsonl"
    )
    .set_checkpoint(
        enabled=True,
        checkpoint_file="checkpoint.json",
        auto_save_frequency=50,
        validate_input_hash=True,
        resume_mode="auto"
    )
    .build()
)

# Run with automatic resume
pipeline = ConversationExtensionPipeline(config)
pipeline.run()

# Can be interrupted and resumed multiple times
# Progress is never lost!
```

## 📈 Performance Impact

- **Checkpoint overhead**: ~10-50ms per save (amortized over batch)
- **Memory usage**: Minimal (checkpoint data structure is lightweight)
- **Disk space**: ~1-2KB per conversation in checkpoint
- **Resume speed**: Instant (processed IDs loaded into memory set)

## 🔗 Related Documentation

- [Configuration Guide](../README.md#configuration)
- [Storage System](../README.md#storage)
- [Error Handling](../README.md#error-handling)