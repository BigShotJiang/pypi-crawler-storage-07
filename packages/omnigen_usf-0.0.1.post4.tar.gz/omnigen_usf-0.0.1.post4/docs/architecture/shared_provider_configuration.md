# Shared Provider Configuration Architecture

## Overview

This document outlines the architectural design for centralizing provider configurations in OmniGen. Provider configurations represent third-party service settings (LLMs, VLMs, image engines) and are not pipeline-specific, making them ideal candidates for shared configuration management.

## Current Architecture (Problems)

### Issues:
1. **Duplication**: Each pipeline defines provider config structure separately
2. **Inconsistency**: Provider settings scattered across pipeline configs
3. **Maintenance**: Changes require updates in multiple places
4. **No Defaults**: Every pipeline must specify all provider settings

### Current Flow:
```
Pipeline Config (YAML/Code) 
    → Pipeline-specific Config Class
    → Generator creates providers
    → ProviderPool manages instances
```

## Proposed Architecture

### Core Principles:
1. **Centralized Configuration**: Provider configs defined in `core/provider_config.py`
2. **Shared Code**: Provider initialization logic reusable across pipelines
3. **Instance Isolation**: Each pipeline/request gets isolated provider instances
4. **Smart Defaults**: Sensible defaults with easy overrides
5. **Backward Compatible**: Existing configs continue to work

### New Architecture Flow:

```mermaid
graph TB
    A[Central Provider Config<br/>core/provider_config.py] --> B[ProviderConfigManager]
    C[Pipeline Config<br/>YAML/Code] --> D[Pipeline Config Class]
    B --> E[Provider Instances]
    D --> E
    E --> F[ProviderPool<br/>Shared Instances]
    F --> G[Pipeline Execution]
```

## Design Components

### 1. Central Provider Configuration (`src/omnigen/core/provider_config.py`)

```python
"""Central provider configuration management."""

from typing import Dict, Any, Optional
from dataclasses import dataclass, field, asdict

@dataclass
class ProviderDefaults:
    """Default provider settings."""
    
    # Default provider
    name: str = "ultrasafe"
    model: str = "usf-mini"
    temperature: float = 0.7
    max_tokens: int = 4096
    
    # Optional settings
    timeout: int = 300
    max_retries: int = 5
    retry_delay: int = 2
    base_url: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary, excluding None values."""
        return {k: v for k, v in asdict(self).items() if v is not None}


class ProviderConfigManager:
    """
    Centralized provider configuration manager.
    
    Provides:
    - Default configurations
    - Configuration merging
    - Validation
    - Easy provider setup across pipelines
    """
    
    # Default configurations for common providers
    DEFAULTS = {
        "ultrasafe": ProviderDefaults(
            name="ultrasafe",
            model="usf-mini",
            temperature=0.7,
            max_tokens=4096
        ),
        "openai": ProviderDefaults(
            name="openai",
            model="gpt-4-turbo",
            temperature=0.7,
            max_tokens=4096
        ),
        "anthropic": ProviderDefaults(
            name="anthropic",
            model="claude-3-5-sonnet-20241022",
            temperature=0.7,
            max_tokens=4096
        ),
        "openrouter": ProviderDefaults(
            name="openrouter",
            model="openai/gpt-4-turbo",
            temperature=0.7,
            max_tokens=4096
        )
    }
    
    @classmethod
    def get_default(cls, provider_name: str) -> Dict[str, Any]:
        """Get default configuration for a provider."""
        if provider_name in cls.DEFAULTS:
            return cls.DEFAULTS[provider_name].to_dict()
        # Return generic defaults for unknown providers
        return ProviderDefaults(name=provider_name).to_dict()
    
    @classmethod
    def create_config(
        cls,
        provider_name: str,
        api_key: str,
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Create provider configuration with smart defaults.
        
        Args:
            provider_name: Provider name (ultrasafe, openai, etc.)
            api_key: API key (required)
            model: Model name (uses default if not provided)
            temperature: Temperature (uses default if not provided)
            max_tokens: Max tokens (uses default if not provided)
            **kwargs: Additional provider-specific settings
            
        Returns:
            Complete provider configuration
        """
        # Start with defaults
        config = cls.get_default(provider_name)
        
        # Override with provided values
        config["api_key"] = api_key
        if model is not None:
            config["model"] = model
        if temperature is not None:
            config["temperature"] = temperature
        if max_tokens is not None:
            config["max_tokens"] = max_tokens
        
        # Add additional settings
        config.update(kwargs)
        
        return config
    
    @classmethod
    def merge_configs(cls, base: Dict[str, Any], overrides: Dict[str, Any]) -> Dict[str, Any]:
        """Merge configuration with overrides."""
        result = base.copy()
        result.update({k: v for k, v in overrides.items() if v is not None})
        return result
```

### 2. Pipeline Configuration Integration

#### Option A: YAML Configuration (Simplified)
```yaml
# Only specify what differs from defaults
providers:
  user_followup:
    name: ultrasafe  # Uses defaults: usf-mini, 0.7 temp, 4096 tokens
    api_key: ${OMNIGEN_USER_API_KEY}
    
  assistant_response:
    name: openai  # Uses defaults: gpt-4-turbo, 0.7 temp, 4096 tokens
    api_key: ${OMNIGEN_ASSISTANT_API_KEY}
    temperature: 0.9  # Override only what you need
```

#### Option B: Programmatic Configuration (Simplified)
```python
from omnigen.core.provider_config import ProviderConfigManager

# Simple - uses all defaults
config = ProviderConfigManager.create_config(
    provider_name="ultrasafe",
    api_key="sk-..."
)

# With overrides
config = ProviderConfigManager.create_config(
    provider_name="openai",
    api_key="sk-...",
    model="gpt-4o",  # Override model
    temperature=0.9  # Override temperature
)
```

### 3. Provider Initialization Helper (`src/omnigen/core/provider_helper.py`)

```python
"""Helper for provider initialization across pipelines."""

from typing import Dict, Any
from omnigen.providers.provider_pool import provider_pool
from omnigen.core.provider_config import ProviderConfigManager
from omnigen.core.base import BaseLLMProvider


class ProviderHelper:
    """
    Helper class for easy provider initialization in pipelines.
    
    Handles:
    - Default configuration application
    - Provider pool integration
    - Consistent error handling
    """
    
    @staticmethod
    def get_provider(
        role: str,
        config: Dict[str, Any],
        use_defaults: bool = True
    ) -> BaseLLMProvider:
        """
        Get or create provider instance for a role.
        
        Args:
            role: Role name (user_followup, assistant_response, etc.)
            config: Provider configuration (can be minimal with defaults)
            use_defaults: Whether to apply default settings
            
        Returns:
            Provider instance from pool (shared when configs match)
        """
        provider_name = config.get('name')
        if not provider_name:
            raise ValueError(f"Provider name required for role '{role}'")
        
        # Apply defaults if enabled
        if use_defaults:
            defaults = ProviderConfigManager.get_default(provider_name)
            final_config = ProviderConfigManager.merge_configs(defaults, config)
        else:
            final_config = config
        
        # Get from pool (shared instance if config matches)
        return provider_pool.get_or_create(provider_name, final_config)
    
    @staticmethod
    def get_providers_for_roles(
        roles_config: Dict[str, Dict[str, Any]],
        use_defaults: bool = True
    ) -> Dict[str, BaseLLMProvider]:
        """
        Get providers for multiple roles at once.
        
        Args:
            roles_config: Dict mapping role names to provider configs
            use_defaults: Whether to apply default settings
            
        Returns:
            Dict mapping role names to provider instances
        """
        providers = {}
        for role, config in roles_config.items():
            providers[role] = ProviderHelper.get_provider(role, config, use_defaults)
        return providers
```

### 4. Updated Pipeline Integration

#### Generator Update:
```python
class ConversationGenerator:
    def __init__(self, config: ConversationExtensionConfig, rate_limiter: RateLimiter):
        self.config = config
        self.rate_limiter = rate_limiter
        
        # Get provider configs
        user_config = config.get_provider_config('user_followup')
        assistant_config = config.get_provider_config('assistant_response')
        
        # Use helper to get providers with defaults
        from omnigen.core.provider_helper import ProviderHelper
        
        self.user_provider = ProviderHelper.get_provider(
            role='user_followup',
            config=user_config,
            use_defaults=True  # Apply defaults
        )
        
        self.assistant_provider = ProviderHelper.get_provider(
            role='assistant_response',
            config=assistant_config,
            use_defaults=True  # Apply defaults
        )
```

## Benefits

### 1. **Reduced Duplication**
- Provider settings defined once in core
- Pipelines only specify overrides
- Consistent configuration across project

### 2. **Better Defaults**
- Smart defaults for each provider
- Users only configure what's necessary
- Reduces configuration complexity

### 3. **Maintainability**
- Central place to update provider defaults
- Easy to add new providers
- Consistent behavior across pipelines

### 4. **Flexibility**
- Full override capability when needed
- Pipeline-specific customization still possible
- Backward compatible with existing configs

### 5. **Instance Isolation**
- Each pipeline gets isolated instances
- Provider pool still shares when configs match
- Multi-tenant safe

## Migration Path

### Phase 1: Add Core Configuration (Non-breaking)
1. Create `core/provider_config.py` with defaults
2. Create `core/provider_helper.py` with helpers
3. Update `core/__init__.py` to export new classes

### Phase 2: Update Pipelines (Gradual)
1. Update `ConversationExtensionConfig` to use defaults
2. Update `ConversationGenerator` to use helper
3. Maintain backward compatibility

### Phase 3: Update Examples & Docs
1. Update example configs to show simplified syntax
2. Update documentation
3. Create migration guide

### Phase 4: Deprecation (Optional)
1. Mark old pattern as deprecated
2. Provide migration warnings
3. Eventually remove in major version

## Configuration Examples

### Minimal Configuration (Uses All Defaults)
```yaml
providers:
  user_followup:
    name: ultrasafe
    api_key: ${API_KEY}
```

### Partial Override
```yaml
providers:
  user_followup:
    name: ultrasafe
    api_key: ${API_KEY}
    temperature: 0.9  # Only override temperature
```

### Full Custom Configuration
```yaml
providers:
  user_followup:
    name: custom_provider
    api_key: ${API_KEY}
    model: custom-model
    temperature: 0.8
    max_tokens: 8192
    custom_param: value
```

### Programmatic Usage
```python
from omnigen.core.provider_config import ProviderConfigManager

# Method 1: Using helper
config = ProviderConfigManager.create_config(
    provider_name="ultrasafe",
    api_key="sk-...",
    # temperature, model, max_tokens use defaults
)

# Method 2: Direct config builder
builder = ConversationExtensionConfigBuilder()
builder.add_provider(
    role="user_followup",
    name="ultrasafe",
    api_key="sk-...",
    # Defaults will be applied automatically
)
```

## Testing Strategy

### Unit Tests
- Test default configuration retrieval
- Test configuration merging
- Test override behavior
- Test validation

### Integration Tests  
- Test provider initialization with defaults
- Test pool sharing with default configs
- Test pipeline execution with minimal config
- Test backward compatibility

## Files to Create/Modify

### New Files:
1. `src/omnigen/core/provider_config.py` - Central configuration
2. `src/omnigen/core/provider_helper.py` - Helper utilities
3. `docs/architecture/shared_provider_configuration.md` - This document
4. `docs/migration/provider_config_migration.md` - Migration guide
5. `tests/core/test_provider_config.py` - Tests

### Modified Files:
1. `src/omnigen/core/__init__.py` - Export new classes
2. `src/omnigen/pipelines/conversation_extension/config.py` - Use defaults
3. `src/omnigen/pipelines/conversation_extension/generator.py` - Use helper
4. `examples/conversation_extension/config.yaml` - Simplified example
5. `examples/conversation_extension/programmatic_usage.py` - Show new pattern

## Success Criteria

1. ✅ Provider defaults centralized in core
2. ✅ Pipelines use shared configuration code
3. ✅ Minimal YAML configs (only overrides needed)
4. ✅ Backward compatible with existing configs
5. ✅ Instance isolation maintained
6. ✅ Provider pool sharing works with defaults
7. ✅ Full test coverage
8. ✅ Documentation updated
9. ✅ Examples demonstrate new pattern

## Next Steps

1. Review and approve this architecture
2. Implement core configuration module
3. Update conversation extension pipeline
4. Create tests and documentation
5. Add migration guide
6. Update all examples