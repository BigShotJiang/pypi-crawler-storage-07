# Changelog

## 0.4.0 - 2025-09-27

- feat(cli): introduce `tn link` command to save URLs with Wayback fallback integration
- feat(export): switch to yaml front matter and jinja templates

## 0.3.0 - 2025-09-26

- chore(scripts): add a script to prepare a release + just target
- feat(export): add html and markdown exporters
