import unimpeded


def test_version():
    assert unimpeded.__version__
