# DRF QueryFlex

Advanced filtering with GraphQL-like syntax for Django REST Framework.

## Features

- **GraphQL-like filtering syntax** - Support for complex queries with multiple operators
- **Field selection** - Choose exactly which fields to return, including nested relationships
- **Query optimization** - Automatic `select_related()` and `prefetch_related()` optimization
- **Multiple syntax formats** - JSON, simplified, and traditional DRF-style filtering
- **Security focused** - Field validation and depth limiting to prevent abuse
- **OpenAPI support** - Automatic schema generation for Swagger documentation

## Installation

```bash
pip install drf-queryflex#   q u e r y f l e x  
 