from artistools.estimators import plotestimators


def main() -> None:
    plotestimators.main()


if __name__ == "__main__":
    main()
