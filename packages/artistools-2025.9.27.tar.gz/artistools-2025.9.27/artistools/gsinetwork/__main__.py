from artistools.gsinetwork import plotqdotabund


def main() -> None:
    plotqdotabund.main()


if __name__ == "__main__":
    main()
