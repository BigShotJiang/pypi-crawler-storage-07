citation_types = {
    "FEDERAL": 1,
    "STATE": 2,
    "STATE_REGIONAL": 3,
    "SPECIALTY": 4,
    "SCOTUS_EARLY": 5,
    "LEXIS": 6,
    "WEST": 7,
    "NEUTRAL": 8,
}
