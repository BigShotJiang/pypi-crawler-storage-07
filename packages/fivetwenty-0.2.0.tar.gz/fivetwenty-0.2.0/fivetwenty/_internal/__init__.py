"""Internal utilities and helpers."""
