"""
Create MCP App - A CLI tool for bootstrapping MCP server projects
"""

__version__ = "1.0.1"
