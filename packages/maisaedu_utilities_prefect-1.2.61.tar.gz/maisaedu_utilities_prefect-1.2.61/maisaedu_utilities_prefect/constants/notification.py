SLACK = 'slack'
TEAMS = 'teams'