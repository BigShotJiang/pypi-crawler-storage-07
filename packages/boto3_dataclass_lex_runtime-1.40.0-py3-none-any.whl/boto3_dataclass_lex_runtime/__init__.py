# -*- coding: utf-8 -*-

from .caster import lex_runtime_caster

caster = lex_runtime_caster

__version__ = "1.40.0"