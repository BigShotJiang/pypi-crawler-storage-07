# -*- coding: utf-8 -*-

from .caster import s3_caster

caster = s3_caster

__version__ = "1.40.0"