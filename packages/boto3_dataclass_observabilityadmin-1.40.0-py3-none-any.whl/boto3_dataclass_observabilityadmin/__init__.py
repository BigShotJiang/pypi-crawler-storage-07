# -*- coding: utf-8 -*-

from .caster import observabilityadmin_caster

caster = observabilityadmin_caster

__version__ = "1.40.0"