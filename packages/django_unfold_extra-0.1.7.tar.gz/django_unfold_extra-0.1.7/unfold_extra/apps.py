from django.apps import AppConfig
from django.utils.translation import gettext_lazy as _


class UnfoldCMSConfig(AppConfig):
    name = "unfold_extra"
    verbose_name = _("Unfold Extra")
