

from .functions import (closeEvent,log,toggle_buttons,save_results,_slug,display_results,cancel_tasks,start_crawl,start_scrape,get_proxy_pool,load_proxy_list,apply_profile,load_profiles,init_ui, autofill_media_file)

def initFuncs(self):
    try:
        for f in (closeEvent,log,toggle_buttons,save_results,_slug,display_results,cancel_tasks,start_crawl,start_scrape,get_proxy_pool,load_proxy_list,apply_profile,load_profiles,init_ui, autofill_media_file):
            setattr(self, f.__name__, f)
    except Exception as e:
        logger.info(f"{e}")
    return self
