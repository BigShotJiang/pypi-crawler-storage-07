from __future__ import annotations
from ...imports import *
from typing import *
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QApplication,QTextEdit,QMessageBox,QMainWindow
from PyQt6 import QtWidgets, QtGui, QtCore, QtGui, QtWidgets
SB = QMessageBox.StandardButton
IDR = Qt.ItemDataRole
