# -*- coding: utf-8 -*-

from .caster import iotanalytics_caster

caster = iotanalytics_caster

__version__ = "1.40.0"