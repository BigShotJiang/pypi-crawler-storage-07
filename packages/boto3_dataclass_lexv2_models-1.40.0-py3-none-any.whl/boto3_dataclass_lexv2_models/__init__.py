# -*- coding: utf-8 -*-

from .caster import lexv2_models_caster

caster = lexv2_models_caster

__version__ = "1.40.0"