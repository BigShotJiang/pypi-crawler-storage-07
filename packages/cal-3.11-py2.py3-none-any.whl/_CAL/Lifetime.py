# -*- coding: utf-8 -*-
# Copyright (C) 2025 Christian Tanzer All rights reserved
# tanzer@gg32.com.
# #*** <License> ************************************************************#
# This module is part of the package CAL.
#
# This module is licensed under the terms of the BSD 3-Clause License
# <http://www.gg32.com/license/bsd_3c.html>.
# #*** </License> ***********************************************************#
#
#++
# Name
#    CAL.Lifetime
#
# Purpose
#    Model the lifetime of persons or things
#
# Revision Dates
#    24-Sep-2025 (CT) Creation
#    ««revision-date»»···
#--

from   _CAL                         import CAL
from   _TFL                         import TFL

from   _CAL.Date                    import Date, As_Date
from   _TFL._Meta.Once_Property     import Once_Property
from   _TFL._Meta.Property          import Typed_Property
from   _TFL._Meta.Single_Dispatch   import Single_Dispatch

import _TFL._Meta.Object

import datetime

class Lifetime (TFL.Meta.Object) :
    """Lifetime of a person or thing.

    >>> v = As_Lifetime (("2022-03-27", "2025-10-14"))
    >>> v
    Lifetime (2022-03-27, 2025-10-14)
    >>> print (v)
    2022-03-27··2025-10-14 ➙  3y 6m18d

    >>> w = As_Lifetime ("2022-03-27")
    >>> w
    Lifetime (2022-03-27)
    >>> print (w)
    2022-03-27

    >>> Lifetime.default_finish = As_Date ("2025-09-24")

    >>> x = As_Lifetime (("2022-03-27", "2025-10-14"))
    >>> x
    Lifetime (2022-03-27, 2025-10-14)
    >>> print (x)
    2022-03-27··2025-10-14 ➙  3y 6m18d

    >>> y = As_Lifetime ("2022-03-27")
    >>> y
    Lifetime (2022-03-27)
    >>> print (y)
    2022-03-27 ➙  3y 5m29d [–2025-09-24]

    """

    default_finish  = None

    def __init__ (self, start, finish = None) :
        self.start  = start
        self.finish = finish
    # end def __init__

    @Once_Property
    def duration (self) :
        for fin in (self.finish, self.default_finish) :
            if fin is not None :
                return fin - self.start
    # end def duration

    @Once_Property
    def fmtd_duration (self) :
        result  = "" if (dur := self.duration) is None \
            else dur.formatted ("%Ymd")
        if result and self.finish is None :
            result += " [–%s]" % self.default_finish.formatted ()
        return result
    # end def fmtd_duration

    @Once_Property
    def fmtd_finish (self) :
        return "" if (fin := self.finish) is None else fin.formatted ()
    # end def fmtd_start

    @Once_Property
    def fmtd_start (self) :
        return self.start.formatted ()
    # end def fmtd_start

    @Typed_Property
    def finish (value) :
        """`finish` requires a `value` of type `CAL.Date`"""
        return CAL.As_Date (value)
    # end def finish

    @Typed_Property
    def start (value) :
        """`start` requires a `value` of type `CAL.Date`"""
        return CAL.As_Date (value)
    # end def start

    def age_at (self, date = None) :
        """Return age at `date`, or `self.finish`"""
        d   = self.finish if date is None else As_Date (date)
        if d is not None :
            return d - self.start
    # end def age

    def __repr__ (self) :
        args    = [self.start.formatted ()]
        if (fin := self.finish) is not None :
            args.append (fin.formatted ())
        return "%s (%s)" % (self.__class__.__name__, ", ".join (args))
    # end def __repr__

    def __str__ (self) :
        parts   = [self.fmtd_start]
        if fin := self.fmtd_finish :
            parts   += ["··", fin]
        if dur := self.fmtd_duration :
            parts   += [" ➙ ", dur]
        return "".join (parts)
    # end def __str__

# end class Lifetime

@Single_Dispatch
def As_Lifetime (value) :
    """Return `value` as `Lifetime`, if possible."""
    if isinstance (value, (Lifetime, CAL.Lifetime)) :
        return value
    if value is not None :
        raise ValueError \
            ( "Expected instance of `Lifetime`, got %r with value `%s`"
            % (type (value), value)
            )
# end def As_Lifetime

@As_Lifetime.add_type (Date, datetime.date, str, int, float)
def _As_Lifetime__from_single_arg (value) :
    return Lifetime (value)
# end def _As_Lifetime__from_single_arg

@As_Lifetime.add_type (tuple, list)
def _As_Lifetime__from_tuple (value) :
    if 0 < len (value)  <= 2 :
        return Lifetime (* value)
    else :
        raise ValueError \
            ( "Expected instance of `tuple` with one or 2 elements"
              ", got %r with value `%s`"
            % (type (value), value)
            )
# end def _As_Lifetime__from_tuple

if __name__ != "__main__" :
    CAL._Export ("*")
### __END__ CAL.Lifetime
