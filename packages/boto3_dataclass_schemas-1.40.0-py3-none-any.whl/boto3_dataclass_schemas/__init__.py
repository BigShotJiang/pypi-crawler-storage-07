# -*- coding: utf-8 -*-

from .caster import schemas_caster

caster = schemas_caster

__version__ = "1.40.0"