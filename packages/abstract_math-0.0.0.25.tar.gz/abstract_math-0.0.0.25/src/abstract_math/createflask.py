from abstract_flask.generator import *
directory = "/home/computron/Documents/pythonTools/modules/abstract_math/src/abstract_math/solar_math"
from_files = generate_from_files(directory=directory)
input(from_files)
