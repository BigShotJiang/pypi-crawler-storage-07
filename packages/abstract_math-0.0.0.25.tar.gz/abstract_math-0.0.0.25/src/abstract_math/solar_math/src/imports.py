import math
from typing import Dict, Callable, Optional, Any
from ...safe_math import (
    multiply_it as mul, divide_it as div, add_it as add, subtract_it as sub, exp_it as exp
)
