console.log("I am some global Javascript.")
