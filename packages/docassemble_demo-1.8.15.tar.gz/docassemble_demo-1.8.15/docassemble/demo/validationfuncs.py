# do not pre-load
def is_multiple_of_four(x):
    return (1.0*x/4) == int(x/4)
