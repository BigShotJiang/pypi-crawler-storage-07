# -*- coding: utf-8 -*-

from .caster import events_caster

caster = events_caster

__version__ = "1.40.0"