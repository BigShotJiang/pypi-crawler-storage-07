# ---------- file: nodebuilder/__init__.py ----------
"""NodeBuilder package init."""
__version__ = "1.0.0"