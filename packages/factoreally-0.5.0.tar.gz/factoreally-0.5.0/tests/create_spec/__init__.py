"""Create spec functionality tests."""
