"""JSON specification building tests."""
