__all__ = ["hello"]
__version__ = "0.0.1"

def hello() -> str:
    return "rillio: hello world (name reservation)"
