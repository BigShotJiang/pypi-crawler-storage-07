def main():
    print("Hello from golden-rule!")


if __name__ == "__main__":
    main()
