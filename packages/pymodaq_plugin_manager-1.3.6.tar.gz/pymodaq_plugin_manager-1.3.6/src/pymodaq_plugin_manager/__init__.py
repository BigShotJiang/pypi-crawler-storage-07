from importlib import metadata

__version__ = metadata.version('pymodaq_plugin_manager')

