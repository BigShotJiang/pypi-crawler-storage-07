"""This package provides parsers for some file formats.
"""
from .elf import *
from .pe import *
from .pcap import *