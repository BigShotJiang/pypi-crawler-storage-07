"""This package provides some utilities for character encoding.
"""
from .ansi import *
from .bitconv import *
from .byteconv import *
from .char import *
from .dump import *
from .table import *
