"""This package provides functions equivalent to some MIPS instructions.
"""

class Instructions:
    """Emulate some MIPS instructions.
    """
    pass
