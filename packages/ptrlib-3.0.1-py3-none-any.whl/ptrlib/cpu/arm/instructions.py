"""This package provides functions equivalent to some Arm instructions.
"""

class Instructions:
    """Emulate some Arm instructions.
    """
    pass
