# scm-python-design-pattern
