# -*- coding: utf-8 -*-

from .caster import managedblockchain_query_caster

caster = managedblockchain_query_caster

__version__ = "1.40.0"