# -*- coding: utf-8 -*-

from .caster import route53_caster

caster = route53_caster

__version__ = "1.40.0"