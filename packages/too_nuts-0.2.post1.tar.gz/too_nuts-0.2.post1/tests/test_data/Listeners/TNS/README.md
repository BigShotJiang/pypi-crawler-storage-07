In this directory, TNS alerts are stored.
