In this directory, GCN alerts from an unknown type are stored.
