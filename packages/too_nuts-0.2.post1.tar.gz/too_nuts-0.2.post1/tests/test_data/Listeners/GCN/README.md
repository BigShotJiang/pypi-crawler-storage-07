In this directory, GCN alerts are stored.
