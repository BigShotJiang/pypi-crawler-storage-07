In this directory, databases are stored.
