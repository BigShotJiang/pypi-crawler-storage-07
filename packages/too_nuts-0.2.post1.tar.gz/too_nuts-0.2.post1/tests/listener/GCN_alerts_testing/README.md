GCN alerts to test parsers.

Test scripts can be found in the directory `too-scource-parser/tests`.
