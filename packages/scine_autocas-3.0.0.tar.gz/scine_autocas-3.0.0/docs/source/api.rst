API
===


.. autosummary::
   :toctree: generated
   :recursive:

   scine_autocas.cas_selection
   scine_autocas.interfaces
   scine_autocas.io
   scine_autocas.plots
   scine_autocas.utils
   scine_autocas.workflows

