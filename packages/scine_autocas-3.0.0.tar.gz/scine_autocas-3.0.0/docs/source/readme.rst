.. include:: ../../README.rst
   :start-after: inclusion-marker-do-not-remove
