class ArtifactBuildError(Exception):
    """Raise when artifact build process fails"""
