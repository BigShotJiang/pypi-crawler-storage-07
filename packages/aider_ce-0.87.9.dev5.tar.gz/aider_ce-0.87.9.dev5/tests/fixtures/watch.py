# fmt: off
# flake8: noqa

# Regular not AI comment
#ai 1 do something
# AI 2 make this better
# ai! 3 urgent change needed
#AI! 4 another urgent one
# this is not an ai comment
# aider is not an ai comment
# not an ai! comment


def dummy_function():
    #ai inside 5 function
    # final 6 ai!
    # final 7 ai
    # ai
    #ai
    # those are 8+9
    pass  # ai 10
