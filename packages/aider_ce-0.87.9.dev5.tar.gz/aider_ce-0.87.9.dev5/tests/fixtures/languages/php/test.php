<?php
function greet($name) {
    echo "Hello, $name!";
}
?>
