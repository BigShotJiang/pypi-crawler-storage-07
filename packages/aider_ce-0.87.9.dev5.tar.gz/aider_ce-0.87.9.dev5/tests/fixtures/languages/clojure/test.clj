(ns greeter.core)

(defn greet
  "Prints a greeting."
  [name]
  (println (str "Hello, " name "!")))
