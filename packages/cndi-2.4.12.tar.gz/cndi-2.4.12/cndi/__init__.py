import logging
logging.basicConfig(format=f'%(asctime)s - %(name)s -  %(levelname)s - %(message)s', level=logging.INFO)


BASE_NAME = "RCN"
