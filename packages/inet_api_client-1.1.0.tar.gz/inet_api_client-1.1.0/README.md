# Sky Cloud API Client

Sky Cloud API Client 是一个用于访问Sky Cloud平台API的Python客户端库。它提供了简单易用的接口，支持设备管理、VLAN管理、VPN管理、工作流管理等功能。

## 特性

- 🚀 **异步支持**: 基于aiohttp的异步HTTP客户端
- 🔐 **自动认证**: 支持用户名密码登录和Token认证
- 🛡️ **安全加密**: 内置密码加密和Token验证
- 📝 **完整API**: 覆盖Sky Cloud平台所有主要API接口
- 🔧 **易于使用**: 提供简化的方法和上下文管理器
- 📦 **独立部署**: 无需依赖配置文件，支持手动参数配置

## 安装

```bash
pip install sky-api-client
```

## 快速开始

### 基础用法

```python
import asyncio
from sky_api_client import SkyApiClient

async def main():
    # 创建客户端实例
    async with SkyApiClient(host="192.168.1.100") as client:
        # 获取设备信息
        device_info = await client.get_device_by_ip("192.168.1.1")
        print(device_info)
        
        # 获取VLAN列表
        vlan_list = await client.get_vlan_list_simple()
        print(vlan_list)

# 运行异步函数
asyncio.run(main())
```

### 自定义配置

```python
import asyncio
from sky_api_client import SkyApiClient

async def main():
    # 自定义配置
    client = SkyApiClient(
        host="192.168.1.100",
        port=8080,
        protocol="https",
        username="admin",
        password="your_password",
        timeout=120
    )
    
    # 手动初始化登录
    await client.init_login()
    
    # 使用API
    vpn_list = await client.get_vpn_list_simple()
    print(vpn_list)

asyncio.run(main())
```

### 使用预设Token

```python
import asyncio
from sky_api_client import SkyApiClient

async def main():
    # 使用预设Token
    client = SkyApiClient(
        host="192.168.1.100",
        token="your_jwt_token_here",
        auto_login=False
    )
    
    await client.init_login()
    
    # 使用API
    device_info = await client.get_device_by_name("device001")
    print(device_info)

asyncio.run(main())
```

## 主要功能

### 设备管理

```python
# 通过IP获取设备信息
device_info = await client.get_device_by_ip("192.168.1.1")

# 通过名称获取设备信息  
device_info = await client.get_device_by_name("switch001")

# 获取设备详情（通过设备类型）
device_info = await client.get_devices_info_for_name_and_type(
    "POST", 
    {"name": "device001"}, 
    "sky_switch_router"
)

# 获取接口信息
interface_info = await client.get_interface_info("GET", {"name": "GigabitEthernet0/1"})
```

### VLAN管理

```python
# 获取VLAN列表
vlan_list = await client.get_vlan_list_simple(page=0, size=100)

# 批量添加VLAN
vlan_data = [
    {"vlan_id": 100, "name": "VLAN100", "description": "测试VLAN"},
    {"vlan_id": 200, "name": "VLAN200", "description": "生产VLAN"}
]
result = await client.batch_add_vlan("POST", vlan_data)

# 批量删除VLAN
delete_data = [{"vlan_id": 100}, {"vlan_id": 200}]
result = await client.batch_del_vlan("DELETE", delete_data)

# 更新VLAN
update_data = {"vlan_id": 100, "name": "VLAN100_Updated"}
result = await client.put_vlan("PUT", update_data)

# VLAN配置同步
result = await client.vlan_config_sync("POST")
```

### VPN管理

```python
# 获取VPN列表
vpn_list = await client.get_vpn_list_simple(page=0, size=100)

# 添加单个VPN
vpn_data = {
    "name": "VPN001",
    "remote_ip": "1.1.1.1",
    "local_ip": "192.168.1.1",
    "psk": "shared_secret"
}
result = await client.add_vpn("POST", vpn_data)

# 批量添加VPN
vpn_list_data = [vpn_data, ...]
result = await client.add_vpn_batch("POST", vpn_list_data)

# 更新VPN
update_data = {"id": "vpn_id", "name": "VPN001_Updated"}
result = await client.update_vpn("PUT", update_data)

# 批量删除VPN
delete_data = [{"id": "vpn_id_1"}, {"id": "vpn_id_2"}]
result = await client.delete_vpn_batch("DELETE", delete_data)
```

### 工作流管理

```python
# 创建工作流任务
task_data = {
    "workflow_type": "device_config",
    "parameters": {
        "device_id": "device001",
        "action": "update_config"
    }
}
result = await client.create_workflow_task(task_data)

# 触发回调节点
callback_data = {"status": "completed", "result": "success"}
result = await client.callback_work_order("POST", "task_id/node_id", callback_data)

# 获取流水线信息
pipeline_info = await client.get_pipeline_info("GET", "pipeline_id")

# 回滚流水线
result = await client.rollback_pipeline("POST", "data_id", "pipeline_id")
```

### 脚本和节点管理

```python
# 获取脚本信息
script_info = await client.get_script_info("GET", "script_id")

# 获取节点详情
node_detail = await client.get_node_detail("GET", "node_id")
```

## API参考

### SkyApiClient

#### 初始化参数

- `host` (str): Sky Cloud服务器主机地址 **[必填]**
- `port` (int): 服务器端口，默认80
- `protocol` (str): 协议，默认"http" (http/https)
- `username` (str): 用户名，默认"admin"
- `password` (str): 密码，默认"r00tme"
- `timeout` (int): 请求超时时间，默认60秒
- `token` (str, 可选): 预设token，如果提供则跳过登录
- `auto_login` (bool): 是否自动登录，默认True

#### 主要方法

##### 认证相关
- `init_login()`: 初始化登录
- `check_token(token)`: 检查token是否过期
- `is_authenticated()`: 检查是否已认证
- `ensure_authenticated()`: 确保已认证

##### 设备管理
- `get_device_by_ip(ip, **kwargs)`: 通过IP获取设备信息
- `get_device_by_name(name, **kwargs)`: 通过名称获取设备信息
- `get_devices_info_for_name_and_type(method, data, device_type)`: 获取指定类型设备信息
- `get_switch_router_info(method, device_id)`: 获取交换机路由器详情

##### VLAN管理
- `get_vlan_list_simple(**kwargs)`: 获取VLAN列表
- `batch_add_vlan(method, data)`: 批量添加VLAN
- `batch_del_vlan(method, data)`: 批量删除VLAN
- `put_vlan(method, data)`: 更新VLAN
- `vlan_config_sync(method)`: VLAN配置同步

##### VPN管理
- `get_vpn_list_simple(**kwargs)`: 获取VPN列表
- `add_vpn(method, data)`: 添加单个VPN
- `add_vpn_batch(method, data)`: 批量添加VPN
- `update_vpn(method, data)`: 更新VPN
- `delete_vpn_batch(method, data)`: 批量删除VPN

##### 工作流管理
- `create_workflow_task(task_data)`: 创建工作流任务
- `callback_work_order(method, url_params, data)`: 触发回调节点
- `get_pipeline_info(method, data)`: 获取流水线信息
- `rollback_pipeline(method, data, pipeline_id)`: 回滚流水线

## 异常处理

```python
from sky_api_client import SkyApiClient, SkyApiException, AuthenticationError, APIRequestError

async def example_with_error_handling():
    try:
        async with SkyApiClient(host="192.168.1.100") as client:
            result = await client.get_device_by_ip("192.168.1.1")
            
    except AuthenticationError as e:
        print(f"认证失败: {e}")
    except APIRequestError as e:
        print(f"API请求失败: {e}")
    except SkyApiException as e:
        print(f"Sky API错误: {e}")
    except Exception as e:
        print(f"其他错误: {e}")
```

## 开发

### 安装开发依赖

```bash
pip install -e ".[dev]"
```

### 运行测试

```bash
pytest
```

### 代码格式化

```bash
black sky_api_client/
```

### 类型检查

```bash
mypy sky_api_client/
```

## 许可证

MIT License

## 支持

如有问题或建议，请提交Issue或联系维护者。

- GitHub: [https://github.com/sky-cloud/sky-api-client](https://github.com/sky-cloud/sky-api-client)
- Email: Bobby@sky-cloud.net
