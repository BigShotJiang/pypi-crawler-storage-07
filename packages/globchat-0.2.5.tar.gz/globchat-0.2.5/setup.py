from setuptools import setup, find_packages

setup(
    name="globchat",
    version="0.2.5",
    packages=find_packages(),
    install_requires=["requests"],
    description="Simple global console chat",
    author="Omer",
    python_requires=">=3.7",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)
