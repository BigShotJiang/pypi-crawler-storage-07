from . import core

def connect():
    """
    Start the global chat in the console.
    """
    username = input("Enter your username: ")
    core.chat_loop(username)
