import requests
import time
import sys

# Secret backend (don't reveal)
BASE_URL = "https://globchat.vercel.app"

def send_message(user, text):
    try:
        res = requests.post(f"{BASE_URL}/send", json={"user": user, "text": text})
        res.raise_for_status()
    except Exception as e:
        print(f"⚠️ Failed to send message: {e}", file=sys.stderr)

def get_messages():
    try:
        res = requests.get(f"{BASE_URL}/messages")
        res.raise_for_status()
        return res.json()
    except Exception:
        return []

def chat_loop(username):
    print(f"\n🌍 Connected as {username}\n(Type your messages, press CTRL+C to quit)\n")
    last_len = 0
    while True:
        try:
            msgs = get_messages()
            if len(msgs) > last_len:
                for msg in msgs[last_len:]:
                    print(f"[{msg['user']}] {msg['text']}")
                last_len = len(msgs)

            text = input("> ").strip()
            if text:
                send_message(username, text)

        except KeyboardInterrupt:
            print("\n👋 Disconnected")
            break
        except Exception as e:
            print(f"⚠️ Error: {e}", file=sys.stderr)
            time.sleep(2)
