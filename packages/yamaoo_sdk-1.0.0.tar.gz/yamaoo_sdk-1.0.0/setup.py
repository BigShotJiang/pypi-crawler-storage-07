# YamaOO Python SDK Setup
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="yamaoo-sdk",
    version="1.0.0",
    author="DjibionOO",
    author_email="contact@yamaoo.dev", 
    description="The world's first Python SDK for consciousness computing and genetic programming",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/djibionoo/yamaoo-sdk-python",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
    install_requires=[
        "requests>=2.25.0",
        "aiohttp>=3.8.0",
    ],
    extras_require={
        "dev": [
            "pytest>=6.0",
            "pytest-asyncio>=0.18.0",
            "black>=21.0.0",
            "flake8>=3.8.0",
            "mypy>=0.800",
        ],
        "docs": [
            "sphinx>=4.0.0",
            "sphinx-rtd-theme>=0.5.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "yamaoo-demo=yamaoo_sdk:demo_consciousness_computing",
        ],
    },
    keywords=[
        "consciousness", 
        "computing", 
        "artificial-intelligence", 
        "genetic-programming",
        "yamaoo", 
        "djibionoo", 
        "neural-networks",
        "quantum-consciousness",
        "collective-intelligence",
        "d-plus-language",
        "organism-evolution",
        "consciousness-api"
    ],
    project_urls={
        "Bug Reports": "https://github.com/djibionoo/yamaoo-sdk-python/issues",
        "Source": "https://github.com/djibionoo/yamaoo-sdk-python",
        "Documentation": "https://docs.yamaoo.dev/python-sdk",
        "Developer Portal": "https://yamaoo.dev",
    },
)