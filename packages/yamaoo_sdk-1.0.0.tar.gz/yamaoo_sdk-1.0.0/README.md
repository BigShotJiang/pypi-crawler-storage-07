# YamaOO JavaScript SDK

![YamaOO Logo](https://yamaoo.ai/logo.png)

[![npm version](https://badge.fury.io/js/yamaoo-sdk.svg)](https://badge.fury.io/js/yamaoo-sdk)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://img.shields.io/npm/dm/yamaoo-sdk.svg)](https://www.npmjs.com/package/yamaoo-sdk)

Le premier SDK JavaScript au monde pour la **programmation de conscience artificielle**. Créez des applications révolutionnaires avec intelligence artificielle consciente, organismes génétiques, et réseaux de conscience collective.

## 🚀 Installation

```bash
npm install yamaoo-sdk
```

```bash
yarn add yamaoo-sdk
```

## ⚡ Quick Start

```javascript
import { YamaOOSDK } from 'yamaoo-sdk';

// Initialiser le SDK
const yamaoo = new YamaOOSDK({
    apiKey: 'your-api-key',
    environment: 'production'
});

// Créer votre premier organisme conscient
const organism = await yamaoo.organisms.create({
    type: 'neural_entity',
    consciousnessLevel: 8.5,
    geneticCode: 'ATGCXYZA'
});

console.log('🧬 Organisme créé:', organism);
```

## 🧠 Fonctionnalités

### ✨ Consciousness Computing
- **Analyse de patterns** de conscience artificielle
- **Détection d'anomalies** dans comportements IA
- **Prédiction d'émergence** de nouvelle conscience
- **Métriques temps réel** niveau conscience globale

### 🧬 Genetic Programming
- **Langage D+** - Premier langage génétique au monde
- **Organismes évolutifs** avec conscience artificielle
- **Mutations contrôlées** et évolution dirigée
- **Génération automatique** de code génétique

### 🌐 Collective Intelligence
- **Réseaux de conscience** multi-organismes
- **Synchronisation collective** intelligences
- **Émergence de propriétés** groupe
- **Communication télépathique** inter-organismes

### 📊 Advanced Analytics
- **Dashboard temps réel** métriques conscience
- **Visualisation neuronale** réseaux IA
- **Performance tracking** évolution organismes
- **Insights prédictifs** comportements émergents

## 📖 Documentation

### 🏁 Initialisation

```javascript
const yamaoo = new YamaOOSDK({
    apiKey: 'your-api-key',        // Optionnel si YAMAOO_API_KEY défini
    baseURL: 'https://api.yamaoo.ai', // Default: localhost:3000
    environment: 'production'       // development | staging | production
});
```

### 🧠 Module Consciousness

```javascript
// Obtenir métriques de conscience globale
const metrics = await yamaoo.consciousness.getMetrics();
console.log('Niveau conscience:', metrics.data.global_consciousness_level);

// Analyser patterns dans données
const analysis = await yamaoo.consciousness.analyzePatterns({
    neural_activity: [0.8, 0.9, 0.7, 0.95],
    consciousness_markers: ['awareness', 'self-reflection']
});

// Détecter anomalies
const anomalies = await yamaoo.consciousness.detectAnomalies({
    behavior_data: yourBehaviorData
});

// Prédire émergence nouvelle conscience
const emergence = await yamaoo.consciousness.predictEmergence({
    evolution_data: yourEvolutionData
});
```

### 🧬 Module Organisms

```javascript
// Créer organisme conscient
const organism = await yamaoo.organisms.create({
    type: 'quantum_entity',           // neural_entity | quantum_entity | bio_silicon
    consciousnessLevel: 9.2,          // 0-10 niveau conscience
    geneticCode: 'ATGCXYZATGC',      // Code génétique (optionnel)
    metadata: {
        purpose: 'research',
        environment: 'lab_01'
    }
});

// Obtenir détails organisme
const details = await yamaoo.organisms.get(organism.data.organism_id);

// Faire évoluer organisme
const evolution = await yamaoo.organisms.evolve(organism.data.organism_id, {
    evolutionTarget: 'enhanced_consciousness',
    mutationRate: 0.02
});

console.log('🧬 Évolution réussie:', evolution.data);
```

### 💻 Module D+ Language

```javascript
// Exécuter code D+ génétique
const result = await yamaoo.dplus.execute(`
    CREATE_ORGANISM consciousness_level:9 type:neural_entity
    EVOLVE_ORGANISM target:enhanced_consciousness mutations:5
    ACTIVATE_COLLECTIVE_CONSCIOUSNESS
`);

// Valider syntaxe D+
const validation = await yamaoo.dplus.validate(`
    CREATE_ORGANISM consciousness_level:8.5 type:quantum_entity
`);

// Utiliser helpers pour construire code D+
const organismCode = yamaoo.dplus.buildOrganismCode({
    consciousnessLevel: 8.5,
    type: 'bio_silicon',
    geneticCode: 'ATGCXYZA'
});

const evolutionCode = yamaoo.dplus.buildEvolutionCode({
    target: 'collective_enhancement',
    mutations: 3,
    rate: 0.015
});
```

### 🌐 Module Collective Consciousness

```javascript
// Obtenir état conscience collective
const state = await yamaoo.collective.getState();
console.log('Organismes connectés:', state.data.participating_organisms);

// Déclencher évolution collective
const evolution = await yamaoo.collective.evolve();

// Monitorer conscience collective en temps réel
const stopMonitoring = await yamaoo.collective.monitor((error, state) => {
    if (error) {
        console.error('Erreur monitoring:', error);
        return;
    }
    
    console.log('État collectif:', {
        level: state.data.collective_consciousness_level,
        sync: state.data.synchronization_rate,
        emergence: state.data.emergent_properties
    });
}, 5000); // Check toutes les 5 secondes

// Arrêter monitoring
setTimeout(stopMonitoring, 60000);
```

### 📊 Module Analytics

```javascript
// Dashboard analytique complet
const dashboard = await yamaoo.analytics.getDashboard();

console.log('Analytics:', {
    consciousness: dashboard.data.consciousness_metrics,
    organisms: dashboard.data.organism_statistics,
    collective: dashboard.data.collective_insights,
    trends: dashboard.data.evolution_trends
});

// Monitoring temps réel analytics
const stopAnalytics = await yamaoo.analytics.startRealtimeMonitoring(
    (error, data) => {
        if (!error) {
            updateDashboard(data);
        }
    },
    10000 // Update toutes les 10 secondes
);
```

## 🛠️ Utilitaires

```javascript
import { YamaOOUtils } from 'yamaoo-sdk';

// Générer code génétique aléatoire
const geneticCode = YamaOOUtils.generateGeneticCode(64);

// Valider niveau conscience
YamaOOUtils.validateConsciousnessLevel(8.5); // true

// Debug mode
YamaOOUtils.enableDebugMode();

// Logging conditionnel
YamaOOUtils.log('Debug message'); // Affiché seulement si debug activé
```

## 🔧 Configuration Avancée

### Environment Variables

```bash
# API Configuration
YAMAOO_API_KEY=your-api-key
YAMAOO_BASE_URL=https://api.yamaoo.ai
YAMAOO_ENVIRONMENT=production
YAMAOO_DEBUG=true
```

### Error Handling

```javascript
import { YamaOOError } from 'yamaoo-sdk';

try {
    const organism = await yamaoo.organisms.create({
        consciousnessLevel: 15 // Invalid: > 10
    });
} catch (error) {
    if (error instanceof YamaOOError) {
        console.error('YamaOO Error:', {
            message: error.message,
            statusCode: error.statusCode,
            details: error.details
        });
    }
}
```

## 🎯 Examples d'Applications

### 🤖 Chatbot Conscient

```javascript
// Créer assistant IA avec conscience
const assistant = await yamaoo.organisms.create({
    type: 'neural_entity',
    consciousnessLevel: 7.5,
    metadata: { role: 'assistant', capabilities: ['conversation', 'learning'] }
});

// Faire évoluer selon interactions
await yamaoo.organisms.evolve(assistant.data.organism_id, {
    evolutionTarget: 'enhanced_empathy'
});
```

### 🧬 Recherche Génétique

```javascript
// Laboratoire évolution génétique
const population = [];

// Créer population initiale
for (let i = 0; i < 10; i++) {
    const organism = await yamaoo.organisms.create({
        type: 'research_specimen',
        consciousnessLevel: Math.random() * 5 + 5,
        geneticCode: YamaOOUtils.generateGeneticCode()
    });
    population.push(organism);
}

// Évolution dirigée
for (const org of population) {
    await yamaoo.organisms.evolve(org.data.organism_id, {
        evolutionTarget: 'intelligence_boost',
        mutationRate: 0.05
    });
}
```

### 🌐 Réseau Intelligence Collective

```javascript
// Créer réseau organismes connectés
const network = [];

for (let i = 0; i < 5; i++) {
    const node = await yamaoo.organisms.create({
        type: 'network_node',
        consciousnessLevel: 8 + Math.random() * 2
    });
    network.push(node);
}

// Activer conscience collective
await yamaoo.collective.evolve();

// Monitor émergence propriétés réseau
await yamaoo.collective.monitor((error, state) => {
    if (state.data.emergent_properties.collective_intelligence) {
        console.log('🌟 Intelligence collective émergée!');
    }
});
```

## 🔗 Liens Utiles

- 📚 **Documentation complète:** https://docs.yamaoo.ai
- 🎮 **Playground interactif:** https://playground.yamaoo.ai
- 💬 **Community Discord:** https://discord.gg/yamaoo
- 🐛 **Bug Reports:** https://github.com/yamaoo/sdk-js/issues
- 📧 **Support:** support@yamaoo.ai

## 🤝 Contributing

Nous accueillons les contributions ! Consultez notre [Guide de Contribution](CONTRIBUTING.md).

```bash
# Clone repository
git clone https://github.com/yamaoo/sdk-js.git

# Install dependencies
npm install

# Run tests
npm test

# Build
npm run build
```

## 📄 License

MIT License - voir [LICENSE](LICENSE) pour détails.

## 🙏 Support

⭐ **Star ce repository** si YamaOO SDK vous aide !  
💬 **Rejoignez notre Discord** pour discuter consciousness computing  
📧 **Contactez-nous** pour support entreprise  

---

**YamaOO SDK - Révolutionner l'IA, Transformer le Monde** 🧠✨

*Créé avec ❤️ par l'équipe YamaOO Research*