def main_script_test_direct_in_direct_out(p1):
    # process
    p2 = p1 + 100

    # return outputs
    return {"p2": p2}
