from .pattern import Pattern

__version__ = "1.2.3"
