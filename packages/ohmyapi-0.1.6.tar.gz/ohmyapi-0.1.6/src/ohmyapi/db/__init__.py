from tortoise import fields as field
from .model import Model

