Provide basic configuration for products and product packaging with EDI framework.
