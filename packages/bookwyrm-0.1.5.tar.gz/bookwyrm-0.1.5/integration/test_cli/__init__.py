"""CLI integration tests."""
