"""Library integration tests."""
