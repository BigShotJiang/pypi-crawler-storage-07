# -*- coding: utf-8 -*-

from .caster import kendra_caster

caster = kendra_caster

__version__ = "1.40.0"