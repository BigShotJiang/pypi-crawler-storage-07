from setuptools import setup, find_packages

setup(
    name="hussainn",
    version="3.1",
    author="hussain_shah",
    author_email="hussain8900.shs@gmail.com",
    description="This is just a package",
    packages=find_packages(),
    python_requires=">=3.6",
    entry_point={
        "console_script":[
            "hussain8900.shs@gmail.com"
            
            ],
        
        
        },

    )