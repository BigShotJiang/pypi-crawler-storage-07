def main():
    print("Hello from suture!")


if __name__ == "__main__":
    main()
