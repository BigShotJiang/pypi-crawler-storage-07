def main() -> None:
    from .proxy.start_gateway import main as gateway_main
    gateway_main()
