from .tool_decorator import tool

__all__ = ["tool"]
