"""
Contract-related tools for the Crypto.com developer platform.
"""

from crypto_com_developer_platform_client import Contract
from langchain_core.tools import tool