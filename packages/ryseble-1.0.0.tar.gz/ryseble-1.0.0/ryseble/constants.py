# Hardcoded UUIDs used by Ryse devices
HARDCODED_UUIDS = {
    "rx_uuid": "a72f2801-b0bd-498b-b4cd-4a3901388238",
    "tx_uuid": "a72f2802-b0bd-498b-b4cd-4a3901388238",
}

# Pairing mode flag
PAIRING_MODE_FLAG = 0x01