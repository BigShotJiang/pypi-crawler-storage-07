"""Bookmark manager package."""
