"""
Tests for lemmatization module
"""
