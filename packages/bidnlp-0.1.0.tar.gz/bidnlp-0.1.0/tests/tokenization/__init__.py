"""
Tests for tokenization module
"""
