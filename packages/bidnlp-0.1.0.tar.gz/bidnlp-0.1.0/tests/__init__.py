"""
Tests for BidNLP
"""
