"""
Tests for utils module
"""
