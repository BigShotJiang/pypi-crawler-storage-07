# -*- coding: utf-8 -*-

import typing as T
import dataclasses
from functools import cached_property

if T.TYPE_CHECKING:  # pragma: no cover
    from mypy_boto3_socialmessaging import type_defs


def field(name: str):
    def getter(self):
        return self.boto3_raw_data[name]

    return cached_property(getter)


@dataclasses.dataclass(frozen=True)
class WhatsAppSignupCallback:
    boto3_raw_data: "type_defs.WhatsAppSignupCallbackTypeDef" = dataclasses.field()

    accessToken = field("accessToken")
    callbackUrl = field("callbackUrl")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.WhatsAppSignupCallbackTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.WhatsAppSignupCallbackTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ResponseMetadata:
    boto3_raw_data: "type_defs.ResponseMetadataTypeDef" = dataclasses.field()

    RequestId = field("RequestId")
    HTTPStatusCode = field("HTTPStatusCode")
    HTTPHeaders = field("HTTPHeaders")
    RetryAttempts = field("RetryAttempts")
    HostId = field("HostId")

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.ResponseMetadataTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ResponseMetadataTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class S3File:
    boto3_raw_data: "type_defs.S3FileTypeDef" = dataclasses.field()

    bucketName = field("bucketName")
    key = field("key")

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.S3FileTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls, boto3_raw_data_list: T.Optional[T.Iterable["type_defs.S3FileTypeDef"]]
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class DeleteWhatsAppMessageMediaInput:
    boto3_raw_data: "type_defs.DeleteWhatsAppMessageMediaInputTypeDef" = (
        dataclasses.field()
    )

    mediaId = field("mediaId")
    originationPhoneNumberId = field("originationPhoneNumberId")

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional["type_defs.DeleteWhatsAppMessageMediaInputTypeDef"],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.DeleteWhatsAppMessageMediaInputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class DeleteWhatsAppMessageTemplateInput:
    boto3_raw_data: "type_defs.DeleteWhatsAppMessageTemplateInputTypeDef" = (
        dataclasses.field()
    )

    id = field("id")
    templateName = field("templateName")
    metaTemplateId = field("metaTemplateId")
    deleteAllLanguages = field("deleteAllLanguages")

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.DeleteWhatsAppMessageTemplateInputTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.DeleteWhatsAppMessageTemplateInputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class DisassociateWhatsAppBusinessAccountInput:
    boto3_raw_data: "type_defs.DisassociateWhatsAppBusinessAccountInputTypeDef" = (
        dataclasses.field()
    )

    id = field("id")

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.DisassociateWhatsAppBusinessAccountInputTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.DisassociateWhatsAppBusinessAccountInputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class GetLinkedWhatsAppBusinessAccountInput:
    boto3_raw_data: "type_defs.GetLinkedWhatsAppBusinessAccountInputTypeDef" = (
        dataclasses.field()
    )

    id = field("id")

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.GetLinkedWhatsAppBusinessAccountInputTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.GetLinkedWhatsAppBusinessAccountInputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class GetLinkedWhatsAppBusinessAccountPhoneNumberInput:
    boto3_raw_data: (
        "type_defs.GetLinkedWhatsAppBusinessAccountPhoneNumberInputTypeDef"
    ) = dataclasses.field()

    id = field("id")

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.GetLinkedWhatsAppBusinessAccountPhoneNumberInputTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable[
                "type_defs.GetLinkedWhatsAppBusinessAccountPhoneNumberInputTypeDef"
            ]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class WhatsAppPhoneNumberDetail:
    boto3_raw_data: "type_defs.WhatsAppPhoneNumberDetailTypeDef" = dataclasses.field()

    arn = field("arn")
    phoneNumber = field("phoneNumber")
    phoneNumberId = field("phoneNumberId")
    metaPhoneNumberId = field("metaPhoneNumberId")
    displayPhoneNumberName = field("displayPhoneNumberName")
    displayPhoneNumber = field("displayPhoneNumber")
    qualityRating = field("qualityRating")
    dataLocalizationRegion = field("dataLocalizationRegion")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.WhatsAppPhoneNumberDetailTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.WhatsAppPhoneNumberDetailTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class S3PresignedUrl:
    boto3_raw_data: "type_defs.S3PresignedUrlTypeDef" = dataclasses.field()

    url = field("url")
    headers = field("headers")

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.S3PresignedUrlTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[T.Iterable["type_defs.S3PresignedUrlTypeDef"]],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class GetWhatsAppMessageTemplateInput:
    boto3_raw_data: "type_defs.GetWhatsAppMessageTemplateInputTypeDef" = (
        dataclasses.field()
    )

    metaTemplateId = field("metaTemplateId")
    id = field("id")

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional["type_defs.GetWhatsAppMessageTemplateInputTypeDef"],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.GetWhatsAppMessageTemplateInputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class LibraryTemplateBodyInputs:
    boto3_raw_data: "type_defs.LibraryTemplateBodyInputsTypeDef" = dataclasses.field()

    addContactNumber = field("addContactNumber")
    addLearnMoreLink = field("addLearnMoreLink")
    addSecurityRecommendation = field("addSecurityRecommendation")
    addTrackPackageLink = field("addTrackPackageLink")
    codeExpirationMinutes = field("codeExpirationMinutes")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.LibraryTemplateBodyInputsTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.LibraryTemplateBodyInputsTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class LibraryTemplateButtonInput:
    boto3_raw_data: "type_defs.LibraryTemplateButtonInputTypeDef" = dataclasses.field()

    type = field("type")
    phoneNumber = field("phoneNumber")
    url = field("url")
    otpType = field("otpType")
    zeroTapTermsAccepted = field("zeroTapTermsAccepted")
    supportedApps = field("supportedApps")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.LibraryTemplateButtonInputTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.LibraryTemplateButtonInputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class LibraryTemplateButtonList:
    boto3_raw_data: "type_defs.LibraryTemplateButtonListTypeDef" = dataclasses.field()

    type = field("type")
    text = field("text")
    phoneNumber = field("phoneNumber")
    url = field("url")
    otpType = field("otpType")
    zeroTapTermsAccepted = field("zeroTapTermsAccepted")
    supportedApps = field("supportedApps")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.LibraryTemplateButtonListTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.LibraryTemplateButtonListTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class WhatsAppBusinessAccountEventDestination:
    boto3_raw_data: "type_defs.WhatsAppBusinessAccountEventDestinationTypeDef" = (
        dataclasses.field()
    )

    eventDestinationArn = field("eventDestinationArn")
    roleArn = field("roleArn")

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.WhatsAppBusinessAccountEventDestinationTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.WhatsAppBusinessAccountEventDestinationTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class WhatsAppPhoneNumberSummary:
    boto3_raw_data: "type_defs.WhatsAppPhoneNumberSummaryTypeDef" = dataclasses.field()

    arn = field("arn")
    phoneNumber = field("phoneNumber")
    phoneNumberId = field("phoneNumberId")
    metaPhoneNumberId = field("metaPhoneNumberId")
    displayPhoneNumberName = field("displayPhoneNumberName")
    displayPhoneNumber = field("displayPhoneNumber")
    qualityRating = field("qualityRating")
    dataLocalizationRegion = field("dataLocalizationRegion")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.WhatsAppPhoneNumberSummaryTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.WhatsAppPhoneNumberSummaryTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class PaginatorConfig:
    boto3_raw_data: "type_defs.PaginatorConfigTypeDef" = dataclasses.field()

    MaxItems = field("MaxItems")
    PageSize = field("PageSize")
    StartingToken = field("StartingToken")

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.PaginatorConfigTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[T.Iterable["type_defs.PaginatorConfigTypeDef"]],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListLinkedWhatsAppBusinessAccountsInput:
    boto3_raw_data: "type_defs.ListLinkedWhatsAppBusinessAccountsInputTypeDef" = (
        dataclasses.field()
    )

    nextToken = field("nextToken")
    maxResults = field("maxResults")

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.ListLinkedWhatsAppBusinessAccountsInputTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ListLinkedWhatsAppBusinessAccountsInputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListTagsForResourceInput:
    boto3_raw_data: "type_defs.ListTagsForResourceInputTypeDef" = dataclasses.field()

    resourceArn = field("resourceArn")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.ListTagsForResourceInputTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ListTagsForResourceInputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class Tag:
    boto3_raw_data: "type_defs.TagTypeDef" = dataclasses.field()

    key = field("key")
    value = field("value")

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.TagTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls, boto3_raw_data_list: T.Optional[T.Iterable["type_defs.TagTypeDef"]]
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListWhatsAppMessageTemplatesInput:
    boto3_raw_data: "type_defs.ListWhatsAppMessageTemplatesInputTypeDef" = (
        dataclasses.field()
    )

    id = field("id")
    nextToken = field("nextToken")
    maxResults = field("maxResults")

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.ListWhatsAppMessageTemplatesInputTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ListWhatsAppMessageTemplatesInputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class TemplateSummary:
    boto3_raw_data: "type_defs.TemplateSummaryTypeDef" = dataclasses.field()

    templateName = field("templateName")
    metaTemplateId = field("metaTemplateId")
    templateStatus = field("templateStatus")
    templateQualityScore = field("templateQualityScore")
    templateLanguage = field("templateLanguage")
    templateCategory = field("templateCategory")

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.TemplateSummaryTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[T.Iterable["type_defs.TemplateSummaryTypeDef"]],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListWhatsAppTemplateLibraryInput:
    boto3_raw_data: "type_defs.ListWhatsAppTemplateLibraryInputTypeDef" = (
        dataclasses.field()
    )

    id = field("id")
    nextToken = field("nextToken")
    maxResults = field("maxResults")
    filters = field("filters")

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional["type_defs.ListWhatsAppTemplateLibraryInputTypeDef"],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ListWhatsAppTemplateLibraryInputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class UntagResourceInput:
    boto3_raw_data: "type_defs.UntagResourceInputTypeDef" = dataclasses.field()

    resourceArn = field("resourceArn")
    tagKeys = field("tagKeys")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.UntagResourceInputTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.UntagResourceInputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class CreateWhatsAppMessageTemplateFromLibraryOutput:
    boto3_raw_data: (
        "type_defs.CreateWhatsAppMessageTemplateFromLibraryOutputTypeDef"
    ) = dataclasses.field()

    metaTemplateId = field("metaTemplateId")
    templateStatus = field("templateStatus")
    category = field("category")

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.CreateWhatsAppMessageTemplateFromLibraryOutputTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable[
                "type_defs.CreateWhatsAppMessageTemplateFromLibraryOutputTypeDef"
            ]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class CreateWhatsAppMessageTemplateMediaOutput:
    boto3_raw_data: "type_defs.CreateWhatsAppMessageTemplateMediaOutputTypeDef" = (
        dataclasses.field()
    )

    metaHeaderHandle = field("metaHeaderHandle")

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.CreateWhatsAppMessageTemplateMediaOutputTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.CreateWhatsAppMessageTemplateMediaOutputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class CreateWhatsAppMessageTemplateOutput:
    boto3_raw_data: "type_defs.CreateWhatsAppMessageTemplateOutputTypeDef" = (
        dataclasses.field()
    )

    metaTemplateId = field("metaTemplateId")
    templateStatus = field("templateStatus")
    category = field("category")

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.CreateWhatsAppMessageTemplateOutputTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.CreateWhatsAppMessageTemplateOutputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class DeleteWhatsAppMessageMediaOutput:
    boto3_raw_data: "type_defs.DeleteWhatsAppMessageMediaOutputTypeDef" = (
        dataclasses.field()
    )

    success = field("success")

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional["type_defs.DeleteWhatsAppMessageMediaOutputTypeDef"],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.DeleteWhatsAppMessageMediaOutputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class GetWhatsAppMessageMediaOutput:
    boto3_raw_data: "type_defs.GetWhatsAppMessageMediaOutputTypeDef" = (
        dataclasses.field()
    )

    mimeType = field("mimeType")
    fileSize = field("fileSize")

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional["type_defs.GetWhatsAppMessageMediaOutputTypeDef"],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.GetWhatsAppMessageMediaOutputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class GetWhatsAppMessageTemplateOutput:
    boto3_raw_data: "type_defs.GetWhatsAppMessageTemplateOutputTypeDef" = (
        dataclasses.field()
    )

    template = field("template")

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional["type_defs.GetWhatsAppMessageTemplateOutputTypeDef"],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.GetWhatsAppMessageTemplateOutputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class PostWhatsAppMessageMediaOutput:
    boto3_raw_data: "type_defs.PostWhatsAppMessageMediaOutputTypeDef" = (
        dataclasses.field()
    )

    mediaId = field("mediaId")

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional["type_defs.PostWhatsAppMessageMediaOutputTypeDef"],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.PostWhatsAppMessageMediaOutputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class SendWhatsAppMessageOutput:
    boto3_raw_data: "type_defs.SendWhatsAppMessageOutputTypeDef" = dataclasses.field()

    messageId = field("messageId")

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.SendWhatsAppMessageOutputTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.SendWhatsAppMessageOutputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class TagResourceOutput:
    boto3_raw_data: "type_defs.TagResourceOutputTypeDef" = dataclasses.field()

    statusCode = field("statusCode")

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.TagResourceOutputTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.TagResourceOutputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class UntagResourceOutput:
    boto3_raw_data: "type_defs.UntagResourceOutputTypeDef" = dataclasses.field()

    statusCode = field("statusCode")

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.UntagResourceOutputTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.UntagResourceOutputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class CreateWhatsAppMessageTemplateInput:
    boto3_raw_data: "type_defs.CreateWhatsAppMessageTemplateInputTypeDef" = (
        dataclasses.field()
    )

    templateDefinition = field("templateDefinition")
    id = field("id")

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.CreateWhatsAppMessageTemplateInputTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.CreateWhatsAppMessageTemplateInputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class SendWhatsAppMessageInput:
    boto3_raw_data: "type_defs.SendWhatsAppMessageInputTypeDef" = dataclasses.field()

    originationPhoneNumberId = field("originationPhoneNumberId")
    message = field("message")
    metaApiVersion = field("metaApiVersion")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.SendWhatsAppMessageInputTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.SendWhatsAppMessageInputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class UpdateWhatsAppMessageTemplateInput:
    boto3_raw_data: "type_defs.UpdateWhatsAppMessageTemplateInputTypeDef" = (
        dataclasses.field()
    )

    id = field("id")
    metaTemplateId = field("metaTemplateId")
    templateCategory = field("templateCategory")
    templateComponents = field("templateComponents")

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.UpdateWhatsAppMessageTemplateInputTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.UpdateWhatsAppMessageTemplateInputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class CreateWhatsAppMessageTemplateMediaInput:
    boto3_raw_data: "type_defs.CreateWhatsAppMessageTemplateMediaInputTypeDef" = (
        dataclasses.field()
    )

    id = field("id")

    @cached_property
    def sourceS3File(self):  # pragma: no cover
        return S3File.make_one(self.boto3_raw_data["sourceS3File"])

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.CreateWhatsAppMessageTemplateMediaInputTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.CreateWhatsAppMessageTemplateMediaInputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class GetLinkedWhatsAppBusinessAccountPhoneNumberOutput:
    boto3_raw_data: (
        "type_defs.GetLinkedWhatsAppBusinessAccountPhoneNumberOutputTypeDef"
    ) = dataclasses.field()

    @cached_property
    def phoneNumber(self):  # pragma: no cover
        return WhatsAppPhoneNumberDetail.make_one(self.boto3_raw_data["phoneNumber"])

    linkedWhatsAppBusinessAccountId = field("linkedWhatsAppBusinessAccountId")

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.GetLinkedWhatsAppBusinessAccountPhoneNumberOutputTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable[
                "type_defs.GetLinkedWhatsAppBusinessAccountPhoneNumberOutputTypeDef"
            ]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class LinkedWhatsAppBusinessAccountIdMetaData:
    boto3_raw_data: "type_defs.LinkedWhatsAppBusinessAccountIdMetaDataTypeDef" = (
        dataclasses.field()
    )

    accountName = field("accountName")
    registrationStatus = field("registrationStatus")

    @cached_property
    def unregisteredWhatsAppPhoneNumbers(self):  # pragma: no cover
        return WhatsAppPhoneNumberDetail.make_many(
            self.boto3_raw_data["unregisteredWhatsAppPhoneNumbers"]
        )

    wabaId = field("wabaId")

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.LinkedWhatsAppBusinessAccountIdMetaDataTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.LinkedWhatsAppBusinessAccountIdMetaDataTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class GetWhatsAppMessageMediaInput:
    boto3_raw_data: "type_defs.GetWhatsAppMessageMediaInputTypeDef" = (
        dataclasses.field()
    )

    mediaId = field("mediaId")
    originationPhoneNumberId = field("originationPhoneNumberId")
    metadataOnly = field("metadataOnly")

    @cached_property
    def destinationS3PresignedUrl(self):  # pragma: no cover
        return S3PresignedUrl.make_one(self.boto3_raw_data["destinationS3PresignedUrl"])

    @cached_property
    def destinationS3File(self):  # pragma: no cover
        return S3File.make_one(self.boto3_raw_data["destinationS3File"])

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.GetWhatsAppMessageMediaInputTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.GetWhatsAppMessageMediaInputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class PostWhatsAppMessageMediaInput:
    boto3_raw_data: "type_defs.PostWhatsAppMessageMediaInputTypeDef" = (
        dataclasses.field()
    )

    originationPhoneNumberId = field("originationPhoneNumberId")

    @cached_property
    def sourceS3PresignedUrl(self):  # pragma: no cover
        return S3PresignedUrl.make_one(self.boto3_raw_data["sourceS3PresignedUrl"])

    @cached_property
    def sourceS3File(self):  # pragma: no cover
        return S3File.make_one(self.boto3_raw_data["sourceS3File"])

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional["type_defs.PostWhatsAppMessageMediaInputTypeDef"],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.PostWhatsAppMessageMediaInputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class MetaLibraryTemplate:
    boto3_raw_data: "type_defs.MetaLibraryTemplateTypeDef" = dataclasses.field()

    templateName = field("templateName")
    libraryTemplateName = field("libraryTemplateName")
    templateCategory = field("templateCategory")
    templateLanguage = field("templateLanguage")

    @cached_property
    def libraryTemplateButtonInputs(self):  # pragma: no cover
        return LibraryTemplateButtonInput.make_many(
            self.boto3_raw_data["libraryTemplateButtonInputs"]
        )

    @cached_property
    def libraryTemplateBodyInputs(self):  # pragma: no cover
        return LibraryTemplateBodyInputs.make_one(
            self.boto3_raw_data["libraryTemplateBodyInputs"]
        )

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.MetaLibraryTemplateTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.MetaLibraryTemplateTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class MetaLibraryTemplateDefinition:
    boto3_raw_data: "type_defs.MetaLibraryTemplateDefinitionTypeDef" = (
        dataclasses.field()
    )

    templateName = field("templateName")
    templateLanguage = field("templateLanguage")
    templateCategory = field("templateCategory")
    templateTopic = field("templateTopic")
    templateUseCase = field("templateUseCase")
    templateIndustry = field("templateIndustry")
    templateHeader = field("templateHeader")
    templateBody = field("templateBody")

    @cached_property
    def templateButtons(self):  # pragma: no cover
        return LibraryTemplateButtonList.make_many(
            self.boto3_raw_data["templateButtons"]
        )

    templateId = field("templateId")

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional["type_defs.MetaLibraryTemplateDefinitionTypeDef"],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.MetaLibraryTemplateDefinitionTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class LinkedWhatsAppBusinessAccountSummary:
    boto3_raw_data: "type_defs.LinkedWhatsAppBusinessAccountSummaryTypeDef" = (
        dataclasses.field()
    )

    arn = field("arn")
    id = field("id")
    wabaId = field("wabaId")
    registrationStatus = field("registrationStatus")
    linkDate = field("linkDate")
    wabaName = field("wabaName")

    @cached_property
    def eventDestinations(self):  # pragma: no cover
        return WhatsAppBusinessAccountEventDestination.make_many(
            self.boto3_raw_data["eventDestinations"]
        )

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.LinkedWhatsAppBusinessAccountSummaryTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.LinkedWhatsAppBusinessAccountSummaryTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class PutWhatsAppBusinessAccountEventDestinationsInput:
    boto3_raw_data: (
        "type_defs.PutWhatsAppBusinessAccountEventDestinationsInputTypeDef"
    ) = dataclasses.field()

    id = field("id")

    @cached_property
    def eventDestinations(self):  # pragma: no cover
        return WhatsAppBusinessAccountEventDestination.make_many(
            self.boto3_raw_data["eventDestinations"]
        )

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.PutWhatsAppBusinessAccountEventDestinationsInputTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable[
                "type_defs.PutWhatsAppBusinessAccountEventDestinationsInputTypeDef"
            ]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class LinkedWhatsAppBusinessAccount:
    boto3_raw_data: "type_defs.LinkedWhatsAppBusinessAccountTypeDef" = (
        dataclasses.field()
    )

    arn = field("arn")
    id = field("id")
    wabaId = field("wabaId")
    registrationStatus = field("registrationStatus")
    linkDate = field("linkDate")
    wabaName = field("wabaName")

    @cached_property
    def eventDestinations(self):  # pragma: no cover
        return WhatsAppBusinessAccountEventDestination.make_many(
            self.boto3_raw_data["eventDestinations"]
        )

    @cached_property
    def phoneNumbers(self):  # pragma: no cover
        return WhatsAppPhoneNumberSummary.make_many(self.boto3_raw_data["phoneNumbers"])

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional["type_defs.LinkedWhatsAppBusinessAccountTypeDef"],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.LinkedWhatsAppBusinessAccountTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListLinkedWhatsAppBusinessAccountsInputPaginate:
    boto3_raw_data: (
        "type_defs.ListLinkedWhatsAppBusinessAccountsInputPaginateTypeDef"
    ) = dataclasses.field()

    @cached_property
    def PaginationConfig(self):  # pragma: no cover
        return PaginatorConfig.make_one(self.boto3_raw_data["PaginationConfig"])

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.ListLinkedWhatsAppBusinessAccountsInputPaginateTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable[
                "type_defs.ListLinkedWhatsAppBusinessAccountsInputPaginateTypeDef"
            ]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListWhatsAppMessageTemplatesInputPaginate:
    boto3_raw_data: "type_defs.ListWhatsAppMessageTemplatesInputPaginateTypeDef" = (
        dataclasses.field()
    )

    id = field("id")

    @cached_property
    def PaginationConfig(self):  # pragma: no cover
        return PaginatorConfig.make_one(self.boto3_raw_data["PaginationConfig"])

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.ListWhatsAppMessageTemplatesInputPaginateTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ListWhatsAppMessageTemplatesInputPaginateTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListWhatsAppTemplateLibraryInputPaginate:
    boto3_raw_data: "type_defs.ListWhatsAppTemplateLibraryInputPaginateTypeDef" = (
        dataclasses.field()
    )

    id = field("id")
    filters = field("filters")

    @cached_property
    def PaginationConfig(self):  # pragma: no cover
        return PaginatorConfig.make_one(self.boto3_raw_data["PaginationConfig"])

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.ListWhatsAppTemplateLibraryInputPaginateTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ListWhatsAppTemplateLibraryInputPaginateTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListTagsForResourceOutput:
    boto3_raw_data: "type_defs.ListTagsForResourceOutputTypeDef" = dataclasses.field()

    statusCode = field("statusCode")

    @cached_property
    def tags(self):  # pragma: no cover
        return Tag.make_many(self.boto3_raw_data["tags"])

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.ListTagsForResourceOutputTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ListTagsForResourceOutputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class TagResourceInput:
    boto3_raw_data: "type_defs.TagResourceInputTypeDef" = dataclasses.field()

    resourceArn = field("resourceArn")

    @cached_property
    def tags(self):  # pragma: no cover
        return Tag.make_many(self.boto3_raw_data["tags"])

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.TagResourceInputTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.TagResourceInputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class WabaPhoneNumberSetupFinalization:
    boto3_raw_data: "type_defs.WabaPhoneNumberSetupFinalizationTypeDef" = (
        dataclasses.field()
    )

    id = field("id")
    twoFactorPin = field("twoFactorPin")
    dataLocalizationRegion = field("dataLocalizationRegion")

    @cached_property
    def tags(self):  # pragma: no cover
        return Tag.make_many(self.boto3_raw_data["tags"])

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional["type_defs.WabaPhoneNumberSetupFinalizationTypeDef"],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.WabaPhoneNumberSetupFinalizationTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class WabaSetupFinalization:
    boto3_raw_data: "type_defs.WabaSetupFinalizationTypeDef" = dataclasses.field()

    id = field("id")

    @cached_property
    def eventDestinations(self):  # pragma: no cover
        return WhatsAppBusinessAccountEventDestination.make_many(
            self.boto3_raw_data["eventDestinations"]
        )

    @cached_property
    def tags(self):  # pragma: no cover
        return Tag.make_many(self.boto3_raw_data["tags"])

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.WabaSetupFinalizationTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.WabaSetupFinalizationTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListWhatsAppMessageTemplatesOutput:
    boto3_raw_data: "type_defs.ListWhatsAppMessageTemplatesOutputTypeDef" = (
        dataclasses.field()
    )

    @cached_property
    def templates(self):  # pragma: no cover
        return TemplateSummary.make_many(self.boto3_raw_data["templates"])

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    nextToken = field("nextToken")

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.ListWhatsAppMessageTemplatesOutputTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ListWhatsAppMessageTemplatesOutputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class WhatsAppSignupCallbackResult:
    boto3_raw_data: "type_defs.WhatsAppSignupCallbackResultTypeDef" = (
        dataclasses.field()
    )

    associateInProgressToken = field("associateInProgressToken")
    linkedAccountsWithIncompleteSetup = field("linkedAccountsWithIncompleteSetup")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.WhatsAppSignupCallbackResultTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.WhatsAppSignupCallbackResultTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class CreateWhatsAppMessageTemplateFromLibraryInput:
    boto3_raw_data: "type_defs.CreateWhatsAppMessageTemplateFromLibraryInputTypeDef" = (
        dataclasses.field()
    )

    @cached_property
    def metaLibraryTemplate(self):  # pragma: no cover
        return MetaLibraryTemplate.make_one(self.boto3_raw_data["metaLibraryTemplate"])

    id = field("id")

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.CreateWhatsAppMessageTemplateFromLibraryInputTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.CreateWhatsAppMessageTemplateFromLibraryInputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListWhatsAppTemplateLibraryOutput:
    boto3_raw_data: "type_defs.ListWhatsAppTemplateLibraryOutputTypeDef" = (
        dataclasses.field()
    )

    @cached_property
    def metaLibraryTemplates(self):  # pragma: no cover
        return MetaLibraryTemplateDefinition.make_many(
            self.boto3_raw_data["metaLibraryTemplates"]
        )

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    nextToken = field("nextToken")

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.ListWhatsAppTemplateLibraryOutputTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ListWhatsAppTemplateLibraryOutputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListLinkedWhatsAppBusinessAccountsOutput:
    boto3_raw_data: "type_defs.ListLinkedWhatsAppBusinessAccountsOutputTypeDef" = (
        dataclasses.field()
    )

    @cached_property
    def linkedAccounts(self):  # pragma: no cover
        return LinkedWhatsAppBusinessAccountSummary.make_many(
            self.boto3_raw_data["linkedAccounts"]
        )

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    nextToken = field("nextToken")

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.ListLinkedWhatsAppBusinessAccountsOutputTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ListLinkedWhatsAppBusinessAccountsOutputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class GetLinkedWhatsAppBusinessAccountOutput:
    boto3_raw_data: "type_defs.GetLinkedWhatsAppBusinessAccountOutputTypeDef" = (
        dataclasses.field()
    )

    @cached_property
    def account(self):  # pragma: no cover
        return LinkedWhatsAppBusinessAccount.make_one(self.boto3_raw_data["account"])

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.GetLinkedWhatsAppBusinessAccountOutputTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.GetLinkedWhatsAppBusinessAccountOutputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class WhatsAppSetupFinalization:
    boto3_raw_data: "type_defs.WhatsAppSetupFinalizationTypeDef" = dataclasses.field()

    associateInProgressToken = field("associateInProgressToken")

    @cached_property
    def phoneNumbers(self):  # pragma: no cover
        return WabaPhoneNumberSetupFinalization.make_many(
            self.boto3_raw_data["phoneNumbers"]
        )

    phoneNumberParent = field("phoneNumberParent")

    @cached_property
    def waba(self):  # pragma: no cover
        return WabaSetupFinalization.make_one(self.boto3_raw_data["waba"])

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.WhatsAppSetupFinalizationTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.WhatsAppSetupFinalizationTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class AssociateWhatsAppBusinessAccountOutput:
    boto3_raw_data: "type_defs.AssociateWhatsAppBusinessAccountOutputTypeDef" = (
        dataclasses.field()
    )

    @cached_property
    def signupCallbackResult(self):  # pragma: no cover
        return WhatsAppSignupCallbackResult.make_one(
            self.boto3_raw_data["signupCallbackResult"]
        )

    statusCode = field("statusCode")

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.AssociateWhatsAppBusinessAccountOutputTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.AssociateWhatsAppBusinessAccountOutputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class AssociateWhatsAppBusinessAccountInput:
    boto3_raw_data: "type_defs.AssociateWhatsAppBusinessAccountInputTypeDef" = (
        dataclasses.field()
    )

    @cached_property
    def signupCallback(self):  # pragma: no cover
        return WhatsAppSignupCallback.make_one(self.boto3_raw_data["signupCallback"])

    @cached_property
    def setupFinalization(self):  # pragma: no cover
        return WhatsAppSetupFinalization.make_one(
            self.boto3_raw_data["setupFinalization"]
        )

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.AssociateWhatsAppBusinessAccountInputTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.AssociateWhatsAppBusinessAccountInputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]
