# -*- coding: utf-8 -*-

import typing as T

from . import type_defs as dc_td

if T.TYPE_CHECKING:  # pragma: no cover
    from mypy_boto3_socialmessaging import type_defs as bs_td


class SOCIALMESSAGINGCaster:

    def associate_whatsapp_business_account(
        self,
        res: "bs_td.AssociateWhatsAppBusinessAccountOutputTypeDef",
    ) -> "dc_td.AssociateWhatsAppBusinessAccountOutput":
        return dc_td.AssociateWhatsAppBusinessAccountOutput.make_one(res)

    def create_whatsapp_message_template(
        self,
        res: "bs_td.CreateWhatsAppMessageTemplateOutputTypeDef",
    ) -> "dc_td.CreateWhatsAppMessageTemplateOutput":
        return dc_td.CreateWhatsAppMessageTemplateOutput.make_one(res)

    def create_whatsapp_message_template_from_library(
        self,
        res: "bs_td.CreateWhatsAppMessageTemplateFromLibraryOutputTypeDef",
    ) -> "dc_td.CreateWhatsAppMessageTemplateFromLibraryOutput":
        return dc_td.CreateWhatsAppMessageTemplateFromLibraryOutput.make_one(res)

    def create_whatsapp_message_template_media(
        self,
        res: "bs_td.CreateWhatsAppMessageTemplateMediaOutputTypeDef",
    ) -> "dc_td.CreateWhatsAppMessageTemplateMediaOutput":
        return dc_td.CreateWhatsAppMessageTemplateMediaOutput.make_one(res)

    def delete_whatsapp_message_media(
        self,
        res: "bs_td.DeleteWhatsAppMessageMediaOutputTypeDef",
    ) -> "dc_td.DeleteWhatsAppMessageMediaOutput":
        return dc_td.DeleteWhatsAppMessageMediaOutput.make_one(res)

    def get_linked_whatsapp_business_account(
        self,
        res: "bs_td.GetLinkedWhatsAppBusinessAccountOutputTypeDef",
    ) -> "dc_td.GetLinkedWhatsAppBusinessAccountOutput":
        return dc_td.GetLinkedWhatsAppBusinessAccountOutput.make_one(res)

    def get_linked_whatsapp_business_account_phone_number(
        self,
        res: "bs_td.GetLinkedWhatsAppBusinessAccountPhoneNumberOutputTypeDef",
    ) -> "dc_td.GetLinkedWhatsAppBusinessAccountPhoneNumberOutput":
        return dc_td.GetLinkedWhatsAppBusinessAccountPhoneNumberOutput.make_one(res)

    def get_whatsapp_message_media(
        self,
        res: "bs_td.GetWhatsAppMessageMediaOutputTypeDef",
    ) -> "dc_td.GetWhatsAppMessageMediaOutput":
        return dc_td.GetWhatsAppMessageMediaOutput.make_one(res)

    def get_whatsapp_message_template(
        self,
        res: "bs_td.GetWhatsAppMessageTemplateOutputTypeDef",
    ) -> "dc_td.GetWhatsAppMessageTemplateOutput":
        return dc_td.GetWhatsAppMessageTemplateOutput.make_one(res)

    def list_linked_whatsapp_business_accounts(
        self,
        res: "bs_td.ListLinkedWhatsAppBusinessAccountsOutputTypeDef",
    ) -> "dc_td.ListLinkedWhatsAppBusinessAccountsOutput":
        return dc_td.ListLinkedWhatsAppBusinessAccountsOutput.make_one(res)

    def list_tags_for_resource(
        self,
        res: "bs_td.ListTagsForResourceOutputTypeDef",
    ) -> "dc_td.ListTagsForResourceOutput":
        return dc_td.ListTagsForResourceOutput.make_one(res)

    def list_whatsapp_message_templates(
        self,
        res: "bs_td.ListWhatsAppMessageTemplatesOutputTypeDef",
    ) -> "dc_td.ListWhatsAppMessageTemplatesOutput":
        return dc_td.ListWhatsAppMessageTemplatesOutput.make_one(res)

    def list_whatsapp_template_library(
        self,
        res: "bs_td.ListWhatsAppTemplateLibraryOutputTypeDef",
    ) -> "dc_td.ListWhatsAppTemplateLibraryOutput":
        return dc_td.ListWhatsAppTemplateLibraryOutput.make_one(res)

    def post_whatsapp_message_media(
        self,
        res: "bs_td.PostWhatsAppMessageMediaOutputTypeDef",
    ) -> "dc_td.PostWhatsAppMessageMediaOutput":
        return dc_td.PostWhatsAppMessageMediaOutput.make_one(res)

    def send_whatsapp_message(
        self,
        res: "bs_td.SendWhatsAppMessageOutputTypeDef",
    ) -> "dc_td.SendWhatsAppMessageOutput":
        return dc_td.SendWhatsAppMessageOutput.make_one(res)

    def tag_resource(
        self,
        res: "bs_td.TagResourceOutputTypeDef",
    ) -> "dc_td.TagResourceOutput":
        return dc_td.TagResourceOutput.make_one(res)

    def untag_resource(
        self,
        res: "bs_td.UntagResourceOutputTypeDef",
    ) -> "dc_td.UntagResourceOutput":
        return dc_td.UntagResourceOutput.make_one(res)


socialmessaging_caster = SOCIALMESSAGINGCaster()
