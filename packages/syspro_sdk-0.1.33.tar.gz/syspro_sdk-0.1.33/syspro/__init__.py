from .models.base import SysproBaseModel
