from .plugin import FeedSyncPlugin

__all__ = ("FeedSyncPlugin",)
