# -*- coding: utf-8 -*-

from .caster import appflow_caster

caster = appflow_caster

__version__ = "1.40.0"