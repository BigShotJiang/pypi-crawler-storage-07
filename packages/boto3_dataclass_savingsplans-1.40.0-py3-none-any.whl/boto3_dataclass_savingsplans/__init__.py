# -*- coding: utf-8 -*-

from .caster import savingsplans_caster

caster = savingsplans_caster

__version__ = "1.40.0"