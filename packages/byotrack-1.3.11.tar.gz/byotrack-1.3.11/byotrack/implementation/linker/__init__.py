"""Linker implementations"""
