# pyinla: Python INLA Binary Installer

A command-line tool to download and install the latest pre-compiled binaries for R-INLA on Linux systems.

## Installation

To install the tool from your local source code, navigate to the project's root directory and run:

```bash
pip install -e .
