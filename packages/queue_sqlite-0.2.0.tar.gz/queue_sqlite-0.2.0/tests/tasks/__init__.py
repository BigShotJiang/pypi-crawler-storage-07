from .example import example

__all__ = [
    "example"
]