## cdf 

### Removed

- In `cdf deploy`, removing the recovery mechanism for failed deployment
of views. This is because the API has been fixed, so it is no longer
necessary.

## templates

No changes.