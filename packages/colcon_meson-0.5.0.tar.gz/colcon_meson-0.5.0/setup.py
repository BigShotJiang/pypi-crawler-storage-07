# Copyright 2024 Christian Rauch
# Licensed under the Apache License, Version 2.0

import setuptools

setuptools.setup()
