'''
    Module:
        libs.ops

    Description:
        This is the library sub-component of Genie for `genie.ops`.
'''

# metadata
__version__ = "25.9"
__author__ = 'Cisco Systems Inc.'
__contact__ = ['pyats-support@cisco.com', 'pyats-support-ext@cisco.com']
__copyright__ = 'Copyright (c) 2018, Cisco Systems Inc.'

from genie import abstract
abstract.declare_package(feature="ops")
