default_host = "192.168.1.105"
default_port = 28333