<div align="center"><img src="https://gitlab.com/GitFr33/nowfocus/-/raw/main/nowfocus.svg" width="60"  align="center">  

# *nowfocus* <br> Open-source task timer for linux  

**Avoid multifailing. Master your to-do lists. Track your time.**

</div>

nowfocus is a clean, keyboard-driven project time tracker build with python + GTK that flexibly connects multiple to-do lists with multiple time trackers and displays your current task and time spent in the status bar. 

## Features
- Unlimited flexible combinations of to-do lists and time tracking systems  
- Infinitely nestable lists  
- Inactivity detection that automatically pauses time tracking 
- Pomodoro timer  
- Task prioritization
- Time targets: set a minimum or maximum time for any task or list of tasks and get reminded to follow though 
- Randomness interrupt bell (optional) to keep you on track with tracking your time
- Keyboard-driven interface 
- Offline to-do list cache 
- CLI
- Run a command (or launch an application) when a task is started


<img src="https://gitlab.com/GitFr33/nowfocus/-/raw/main/docs/Screenshot-25-09-23-11-42-56.webp" width="500">  
<img src="https://gitlab.com/GitFr33/nowfocus/-/raw/main/docs/Screenshot-25-09-23-11-46-14.webp" width="400">  
<img src="https://gitlab.com/GitFr33/nowfocus/-/raw/main/docs/Screenshot-25-09-23-11-53-22.webp" width="400">  

<br>

### Currently Supported To-do List Backends

- Simple text or markdown file with indentation based sub-lists
- Any to-do list that supports [CalDav todos](https://en.wikipedia.org/wiki/CalDAV) 
- [todotxt format](http://todotxt.org/)
- [TaskWarrior](https://taskwarrior.org/)
- [Vikunja](https://www.vikunja.io)
- [Photosynthesis Timetracker](https://github.com/Photosynthesis/Timetracker/)  
- [Trello](https://www.trello.com)

### Currently Supported Time Tracker Backends 

- CSV file  
- [ActivityWatch](https://www.activitywatch.net)      
- [Photosynthesis Timetracker](https://github.com/Photosynthesis/Timetracker/)  
- [TimeWarrior](https://timewarrior.net)


## Installation (using pipx) 

Run the following in terminal to install and setup:
```
# Install dependencies
sudo apt install pip pipx gir1.2-appindicator3-0.1 meson libdbus-glib-1-dev patchelf libgirepository1.0-dev gcc libcairo2-dev pkg-config python3-dev

# Set up pipx
pipx ensurepath

# At this point you may need to restart your terminal window

# Install nowfocus
pipx install nowfocus

# Enter application directory
cd ~/.local/share/pipx/venvs/nowfocus/lib/python3.12/site-packages/nowfocus

# Copy .desktop and icon to .local/share 
cp src/desktop-extras/nowfocus.desktop ~/.local/share/applications/nowfocus.desktop
cp src/desktop-extras/nowfocus.svg ~/.local/share/icons/nowfocus.png
cp src/desktop-extras/nowfocus.svg ~/.local/share/icons/hicolor/scalable/apps/nowfocus.svg

# Setup autostart
cp src/desktop-extras/nowfocus.desktop ~/.config/autostart/nowfocus.desktop

# Set Super space as keybinding to raise task window 
chmod +x src/desktop-extras/set_gsettings_keybinding.sh

src/desktop-extras/set_gsettings_keybinding.sh "Open nowfocus" nowfocus "<Super>space"

# and now Focus!
nowfocus

```



## Usage

#### Set up to-do lists and time trackers

Open nowfocus **Settings** from the indicator menu or tasks window and connect your to-do lists and time tracker(s) 

#### Task Window Keybindings

- `F11` Toggle fullscreen
- `Esc` Close task window
- `Enter` Start top task (or make a new task with current search phrase if no results)
- `Ctrl + P` **Pause** current task
- `Ctrl + D` Pause current task and mark it **Done**
- `Ctrl + X` Cancel current task
- `Ctrl + N` **New** task
- `Ctrl + R` **Refresh** todolists
- `Ctrl + L` or `Ctrl + F` **Focus** the task search

#### Commandline Interface

- To raise the task window use simply: `nowfocus`  
- If nowfocus has crashed or failed to shut down nicely use `nowfocus --force`
- To start timing a task: add the task name as the first positional argument. `nowfocus "checking email"` 
- To stop timing use `nowfocus stop`
- Start with verbose logging use: `nowfocus -l 3`
- Start with targeted verbose logging use: `nowfocus -s trello`


## Development

### Install from Source

- Install dependencies from above.  
- Clone this repo somewhere (referred to as `YOUR_INSTALL_PATH`)  
- Change to `YOUR_INSTALL_PATH` directory with `cd YOUR_INSTALL_PATH/nowfocus`  
- build python module with `python3 -m build` (this should be done in a venv and will require some dependecies...)  
- pipx install -e --force YOUR_INSTALL_PATH/monotask/  
