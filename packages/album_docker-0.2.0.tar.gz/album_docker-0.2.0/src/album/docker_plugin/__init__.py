"""Docker plugin for Album."""
