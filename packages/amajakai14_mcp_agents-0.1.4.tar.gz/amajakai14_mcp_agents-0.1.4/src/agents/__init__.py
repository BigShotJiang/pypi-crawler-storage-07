"""
FastMCP - A simple Model Context Protocol server with basic math tools.
"""

from .server import main


if __name__ == "__main__":
    main()
