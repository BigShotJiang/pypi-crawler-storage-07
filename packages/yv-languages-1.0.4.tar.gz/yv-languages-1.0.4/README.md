# yv-languages

## Requirements

This project recommends Python 3.11 or higher.

## Installation

You need to connect to our private PyPi packages to install this library.
See how in our API Getting Started docs.

Then:

```bash
pip install yv-languages
```

Or if you are working in a microservice with Maker setup,
add `yv-languages` to your `requirements.in` file and run:

```bash
make deps-compile && make deps-install
```

## Usage

You can validate & make any language tag string canonical like:

```python
import yv_languages

bcp = yv_languages.canonical("eng")

print(str(bcp))  # "en"
```

## Development

This project was written and tested with Python 3.11.

We recommend using pyenv & pyenv-virtualenv which you can find instructions on installing
in our Getting Started documentation.

setup the project env
``` bash
make venv && make deps-install
```

create a .envrc file using this sample
``` bash
export PYTHONPATH=`pwd`
```

### Running tests

``` bash
make test
```

### Before committing any code

We have a pre-commit hook which should be setup.
You can symlink it to run before each commit by changing directory to the repo and running

``` bash
make githooks
```

## Syncing Rules

The source of truth for the language rules is the [locales service](https://gitlab.com/lifechurch/youversion/apis/systems/internationalization/locales). Locales has a scheduled job that regularly checks for new or or updated languages from various language authorities. Overrides are also possible through the locales project. It then updates the locales in the repo with an MR, changing the rules. We are mirroring a similar process here, but we are deriving our rules from locales since locales is the source of truth. Every day we will check for changes. If there are any, an MR will automatically be made with changes to `yv_languages/rules.json`. This file should NEVER be edited manually in this project.

Merge the MR and create a new tag with an incremented patch version to update the library with the new rules.
