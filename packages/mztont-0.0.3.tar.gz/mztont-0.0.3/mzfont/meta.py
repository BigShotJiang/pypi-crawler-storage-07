from hatchling.metadata.plugin.interface import MetadataHookInterface

package_meta = {
    'authors': [{'name': 'Jeroen F.J. Laros', 'email': 'jlaros@fixedpoint.nl'}],
    'description': 'Sharp MZ TrueType font.',
    'keywords': ['Sharp', 'MZ', 'font', 'TrueType'],
    'name': 'mztont',
    'project': 'MzFont',
    'url': 'https://github.com/jfjlaros/mzfont',
    'version': '0.0.3'}


class JSONMetaDataHook(MetadataHookInterface):
    def update(self, metadata):
        metadata.update(package_meta)
