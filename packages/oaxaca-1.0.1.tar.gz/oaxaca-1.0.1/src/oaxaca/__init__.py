from .oaxaca import Oaxaca
from .results import OaxacaResults

__all__ = [
    "Oaxaca",
    "OaxacaResults",
]
