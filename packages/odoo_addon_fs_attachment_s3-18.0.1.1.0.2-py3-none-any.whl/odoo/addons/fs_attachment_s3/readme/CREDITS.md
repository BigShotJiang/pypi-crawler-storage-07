The development of this module has been financially supported by:

- ACSONE SA/NV (https://www.acsone.eu)
- Alcyon Belux