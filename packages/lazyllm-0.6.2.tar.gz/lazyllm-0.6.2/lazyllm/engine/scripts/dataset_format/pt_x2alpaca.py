
def txt2pretrain(dataset_path: str) -> str:
    return dataset_path

def csv2pretrain(dataset_path: str) -> str:
    return dataset_path

def parquet2pretrain(dataset_path: str) -> str:
    return dataset_path

def json2pretrain(dataset_path: str) -> str:
    return dataset_path
