from .webmodule import WebModule

__all__ = [
    'WebModule'
]
