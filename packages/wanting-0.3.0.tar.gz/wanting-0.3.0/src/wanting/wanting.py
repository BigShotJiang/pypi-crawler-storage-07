"""The Wanting module."""

from collections.abc import Iterator
from types import UnionType
from typing import Annotated, Literal, NamedTuple, TypeGuard, Union, cast, get_origin

import pydantic
import pydantic_core


class Wanting(pydantic.BaseModel):
    """Abstract base class that represents an incomplete field value."""

    kind: str
    source: str
    value: Annotated[bytes, pydantic.BeforeValidator(pydantic_core.to_json)]


class Unavailable(Wanting):
    """Represents an unavailable field value."""

    kind: Literal["unavailable"] = "unavailable"
    value: Annotated[bytes, pydantic.BeforeValidator(pydantic_core.to_json)] = b"null"


class Unmapped(Wanting):
    """Represents an unmapped field value."""

    kind: Literal["unmapped"] = "unmapped"


class FieldInfoEx(NamedTuple):
    """Extended information about a field."""

    cls: type[pydantic.BaseModel]
    name: str
    info: pydantic.fields.FieldInfo


_UNION_TYPES = {UnionType, Union}


def _is_union_type(typ: object) -> TypeGuard[UnionType]:
    return get_origin(typ) in _UNION_TYPES


def _field_wanting_types(fi: pydantic.fields.FieldInfo) -> Iterator[type[Wanting]]:
    typ = fi.annotation
    if _is_union_type(typ):
        for utyp in typ.__args__:
            if issubclass(utyp, Wanting):
                yield utyp
    elif issubclass(cast("type", typ), Wanting):
        yield cast("type[Wanting]", typ)


def _field_has_wanting_type(fi: pydantic.fields.FieldInfo) -> bool:
    return bool(next(_field_wanting_types(fi), False))


def _field_model_types(fi: pydantic.fields.FieldInfo) -> Iterator[type[pydantic.BaseModel]]:
    typ = fi.annotation
    if issubclass(cast("type", typ), pydantic.BaseModel):
        yield cast("type[pydantic.BaseModel]", typ)
    elif _is_union_type(typ):
        for utyp in typ.__args__:
            if issubclass(utyp, pydantic.BaseModel):
                yield utyp


def wanting_fields(
    cls: type[pydantic.BaseModel], *, depth: int = -1
) -> Iterator[list[FieldInfoEx]]:
    """Get the fields in a model that could be :class:`Wanting`.

    Args:
        cls: The model to inspect for wanting fields.
        depth: How deeply to check nested models for wanting fields. The depth
            is zero-based, so ``0`` for only top-level fields. ``-1`` for no
            limit.

    Returns:
        An iterator of :class:`FieldInfoEx` lists, where each list describes
        the path to a top-level, or nested wanting field.
    """
    top_level_wanting_field_paths = (
        [FieldInfoEx(cls, name, fi)]
        for name, fi in cls.model_fields.items()
        if _field_has_wanting_type(fi)
    )
    yield from top_level_wanting_field_paths

    if depth == 0:
        return

    top_level_model_fields = [
        (name, fi, list(_field_model_types(fi))) for name, fi in cls.model_fields.items()
    ]
    nested_wanting_field_paths = (
        [FieldInfoEx(cls, name, fi), *path]
        for name, fi, typs in top_level_model_fields
        for typ in typs
        for path in wanting_fields(typ, depth=depth - 1)
    )
    yield from nested_wanting_field_paths
