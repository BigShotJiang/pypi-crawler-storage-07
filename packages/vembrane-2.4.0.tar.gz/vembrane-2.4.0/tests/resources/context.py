import random

random.seed(42)


def dummy_func(value):
    return value
