# provoke an error during context validation by using invalid syntax here

thisisinvalidpythoncode  # noqa: B018,F821
