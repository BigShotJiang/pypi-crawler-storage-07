# Python impmimonitoring

This module is a Python wrapper for the libipmimonitoring library from
https://www.gnu.org/software/freeipmi/ .

## Requirements

On debian based systems, install libipmimonitoring

```
sudo apt install -y libipmimonitoring6
```

Install with:

```
pip install impimonitoring
```

## Test application

ipmimonitoring/__main__.py contains a simple tool which read sensor
data, similar to ipmi-sensors from the freeipmi-tools package.

### Reading in-band sensors from the local BMC

Read sensors from the local machine using /dev/impiN.  Normally
opening that device requires root permissione:

```
sudo python -m ipmimonitoring
```

alternately, change the permissions so that your user can access the
device:

```
sudo chown $USER /dev/impi*
python -m ipmimonitoring
```

### Reading out-of-band sensors from a remote BMC

```
python -m ipmimonitoring --hostname=host --username=user --password=password
```

### Other flags

Keep reading IPMI data forever.  Optionally specify how many seconds
to wait between each read.  Default 1 second.

```
python -m ipmimonitoring --follow[=seconds]
```

Output JSON format.  Optionally pass the number of spaces to indent
the JSON data for a prettier readout.

```
python -m ipmimonitoring --json[=indent]
```

# License

All the code written by me is licensed under the MIT license.

Note that libimpimonitoring itself is licensed under GPLv2 or later,
but since libipmonitoring is distributed as a Debian package it should
be ok to use it the way this Python module does without tainting it.
Or that is how I read this paragraph from the GPLv2 license:

    However, as a special exception, the source code distributed need
    not include anything that is normally distributed (in either
    source or binary form) with the major components (compiler,
    kernel, and so on) of the operating system on which the executable
    runs, unless that component itself accompanies the executable

Also, as far as I know APIs are not copyrightable, so the headers and
APIs in wrapper.py and all enums should be ok to distribute under a
MIT license.
