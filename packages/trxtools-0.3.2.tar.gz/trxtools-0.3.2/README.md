trxtools v0.3.2
===============

Transcription/Transcriptomic tools. Package of python tools facilitating bioinformatic analysis of RNA and nascent RNA sequencing data.

Installation
------------
```pip install trxtools```

Documentation
-------------
Documentation can be found [here](https://turowskilab.github.io/trxtools/)

Authors
-------
Tomasz W. Turowski, Jan Mikołajczyk
