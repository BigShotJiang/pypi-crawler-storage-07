"""
PyUploader - A CLI tool to automate uploading packages to PyPI
"""

__version__ = "0.1.0"
__author__ = "chenxi"
__email__ = "your.email@example.com"