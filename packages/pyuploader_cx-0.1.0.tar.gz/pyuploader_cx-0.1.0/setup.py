#!/usr/bin/env python
"""
Setup script for compatibility with tools that still require it.
"""

from setuptools import setup

if __name__ == "__main__":
    setup(
        name='pyuploader',
        version='0.1.0',
        packages=['pyuploader'],
        install_requires=['twine>=4.0.0', 'click>=8.0.0'],
    )