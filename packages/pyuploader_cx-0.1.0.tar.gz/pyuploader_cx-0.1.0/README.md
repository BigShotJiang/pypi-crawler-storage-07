# PyUploader

A CLI tool to automate uploading Python packages to PyPI.

## Features

- Build and upload Python packages to PyPI or TestPyPI with a single command
- Support for API tokens and username/password authentication
- Option to clean build directories before building
- Option to skip existing distributions when uploading
- Simple and intuitive command-line interface

## Installation

You can install PyUploader using pip:

```bash
pip install pyuploader
```

Or, if you're installing from source:

```bash
pip install .
```

## Usage

PyUploader provides several commands to help you manage your package uploading workflow:

### Available Commands

```
Commands:
  upload     Build and upload a Python package (default command)
  init       Initialize PyUploader configuration
  edit       Edit package information in pyproject.toml
  fix        Fix format errors in pyproject.toml
  pypirc_config  Automatically configure ~/.pypirc file
```

### Default Command (upload)

The default command (when no specific command is provided) builds and uploads a package to PyPI:

```bash
pyuploader
```

### Command-line Options

```
Options:
  -d, --package-dir TEXT     Directory of the package to upload  [default: .]
  -r, --repository TEXT      PyPI repository to upload to (pypi or testpypi)
                             [default: pypi]
  -u, --username TEXT        Username for PyPI authentication
  -p, --password TEXT        Password or API token for PyPI authentication
  --dist-dir TEXT            Directory containing the distribution files
                             [default: dist]
  --build / --no-build       Whether to build the package before uploading
                             [default: build]
  --clean / --no-clean       Whether to clean the build directories before
                             building  [default: clean]
  --skip-existing            Skip uploading if the distribution already exists
  --help                     Show this message and exit.
```

### Examples

Upload to TestPyPI:

```bash
pyuploader --repository testpypi
```

Upload with authentication:

```bash
pyuploader --username __token__ --password YOUR_API_TOKEN_HERE
```

Skip building (upload existing distributions):

```bash
pyuploader --no-build
```

## Authentication

For PyPI authentication, you can:

1. Provide your username and password/API token directly via command-line options
2. Use a `~/.pypirc` configuration file
3. Let Twine prompt you for credentials during upload

### Using a .pypirc Configuration File

The `~/.pypirc` file allows you to store your PyPI credentials so you don't have to enter them every time you upload a package.

You can either create this file manually or use the `pypirc_config` command to automatically configure it.

#### Using the `pypirc_config` Command

The `pypirc_config` command provides an interactive interface to automatically configure your `~/.pypirc` file:

```bash
pyuploader pypirc_config
```

This command will:
1. guide you through setting up credentials for PyPI, TestPyPI, and pyuploader repositories
2. Set appropriate file permissions (600) to keep your credentials secure
3. Create all necessary configuration sections

Options:
- `--force, -f`: Force overwrite of an existing `.pypirc` file

#### Basic Configuration Format

```ini
[distutils]
index-servers =
    pypi
    testpypi
    pypiuploader

[pypi]
repository = https://upload.pypi.org/legacy/
username = __token__
password = your-pypi-api-token-here

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = your-testpypi-api-token-here

[pypiuploader]
repository = https://upload.pypi.org/legacy/
username = __token__
password = your-pypi-api-token-here
```

#### Important Notes:
- For API tokens, use `__token__` as the username
- Set appropriate file permissions: `chmod 600 ~/.pypirc` to keep your credentials secure
- The `pyuploader` section is specifically for this tool's default repository name

### Using API Tokens

API tokens are the recommended authentication method for PyPI. When using an API token:
- Use `__token__` as the username
- Use the entire token string (including the `pypi-` prefix) as the password

## Troubleshooting

### Common Errors

#### Missing 'pypiuploader' section from ~/.pypirc

If you see an error like:
```
ERROR    InvalidConfiguration: Missing 'pypiuploader' section from ~/.pypirc.
```

This means your `~/.pypirc` file does not have a configuration section named 'pyuploader'. To fix this:

1. Create or edit your `~/.pypirc` file
2. Add the 'pyuploader' section as shown in the configuration example above
3. Set appropriate permissions with `chmod 600 ~/.pypirc`

An example configuration file is provided in this repository as `.pypirc.uploader.example`.

## Requirements

- Python 3.7 or higher
- Twine 4.0.0 or higher
- Click 8.0.0 or higher

## License

This project is licensed under the MIT License.