Installation
============

Biscuit python is `published on PyPI <https://pypi.org/project/biscuit-python/>`_.

.. code-block:: sh

    pip install biscuit-python
