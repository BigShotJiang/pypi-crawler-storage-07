Api reference
=============

`biscuit_auth` module
---------------------

.. automodule:: biscuit_auth
   :members:
