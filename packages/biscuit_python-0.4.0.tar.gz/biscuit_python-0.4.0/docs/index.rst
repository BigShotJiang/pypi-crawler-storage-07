biscuit-python
==============

.. toctree::
   :maxdepth: 2

   installation
   basic-use
   datalog
   api-reference

This library provides support for the biscuit auth platform in python.

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
