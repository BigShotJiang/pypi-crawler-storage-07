# Security issues reporting

Security issues can be reported via [github](https://github.com/eclipse-biscuit/biscuit-python/security). 

