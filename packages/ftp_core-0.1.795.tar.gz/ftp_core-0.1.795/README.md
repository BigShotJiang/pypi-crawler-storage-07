# FTP_CALCULATOR Python Wrapper

A Python wrapper around the [FTP_CALCULATOR](https://github.com/ton_org/FTP_CALCULATOR) Rust core.

## Installation

```bash
pip install -e .
