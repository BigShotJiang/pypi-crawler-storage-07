# -*- coding: utf-8 -*-

from .caster import greengrassv2_caster

caster = greengrassv2_caster

__version__ = "1.40.0"