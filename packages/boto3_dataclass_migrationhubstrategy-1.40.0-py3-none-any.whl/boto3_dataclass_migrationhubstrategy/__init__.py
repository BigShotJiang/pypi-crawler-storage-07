# -*- coding: utf-8 -*-

from .caster import migrationhubstrategy_caster

caster = migrationhubstrategy_caster

__version__ = "1.40.0"