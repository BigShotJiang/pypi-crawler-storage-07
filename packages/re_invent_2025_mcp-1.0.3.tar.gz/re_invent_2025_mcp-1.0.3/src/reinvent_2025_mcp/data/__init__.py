# Data loading module
