// SPDX-License-Identifier: (Apache-2.0 OR MIT) AND CC0-1.0

#include "sig_stfl_xmss_xmssmt.c"

// ======================== XMSS-SHAKE256_10_256 ======================== //

XMSS_ALG(, _shake256_h10_256, _SHAKE256_H10_256)
