"""
{
    "app_data_dir": "",
    "logging": {
        "log_file": "",
        "per_log_max_size": "",
        "log_level": "",
    }
}
"""