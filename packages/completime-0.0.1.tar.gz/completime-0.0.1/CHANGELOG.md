# Changelog

## [0.0.1] - 2025-09-27
- Project initialization