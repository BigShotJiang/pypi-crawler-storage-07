# -*- coding: utf-8 -*-

from .caster import managedblockchain_caster

caster = managedblockchain_caster

__version__ = "1.40.0"