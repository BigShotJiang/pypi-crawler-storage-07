class BgDocAs:
    class DocAsoc:
        _tbl = 'DocAsoc'
        key = 'Key1'
        id = 'Id1'
        file_name = 'NombreFichero'
        time_stamp ='FechaHora'
        bin_file = 'BinariFile'
        added_by_user = 'IntroducidoPor'
        observations = 'Observaciones'
        digital_firm ='FirmaDigital'