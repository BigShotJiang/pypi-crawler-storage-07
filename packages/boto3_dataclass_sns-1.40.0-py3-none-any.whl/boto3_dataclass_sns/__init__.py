# -*- coding: utf-8 -*-

from .caster import sns_caster

caster = sns_caster

__version__ = "1.40.0"