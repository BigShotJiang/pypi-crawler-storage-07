from k_nickname.generator import Generator


# 기본 닉네임 생성기
gen = Generator()
print(gen.generate_k_nickname())   # 예: 심쿵호랑이42

# 숫자 없고 이모지 없는 닉네임
gen_no_number = Generator(use_number=False)
print(gen_no_number.generate_k_nickname())   # 예: 귀여운펭귄

# 숫자 없고 이모지 있는 닉네임
gen_with_emoji = Generator(use_number=False, use_emoji=True)
print(gen_with_emoji.generate_k_nickname())

# 사용자 정의 풀 적용
custom_gen = Generator(
    adjectives=["푸른", "붉은"],
    nouns=["용", "불사조"],
    use_number=True,
    number_range=(100, 999)
)
print(custom_gen.generate_k_nickname())   # 예: 붉은불사조321
