from setuptools import setup, find_packages

setup(
    name="k-nickname",
    version="0.1.5",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "emoji>=2.15.0,<3.0.0",
    ],
    python_requires=">=3.8",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="kyohoonsim",
    author_email="kyohoonsim@gmail.com",
    description="A simple Python package to generate Korean-style nickname",
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ]
)