from robot.api import logger


class QGISLibrary:
    """QGIS Robot Framework library."""
    def say_hello(self, name):
        """Say Hello"""
        message = f"Hello, {name}!"
        logger.info(message)
        return message