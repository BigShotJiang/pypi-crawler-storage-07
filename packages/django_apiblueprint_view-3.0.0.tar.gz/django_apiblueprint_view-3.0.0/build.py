print("Not compiling Libdrafter. Assuming a global install.")
exit(0)
