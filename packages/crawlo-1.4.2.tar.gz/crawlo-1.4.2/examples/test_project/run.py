#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
test_project 项目运行脚本
============================
基于 Crawlo 框架的简化爬虫启动器。

框架会自动处理爬虫模块的导入和注册，用户无需手动导入。
只需指定spider_modules参数，框架会自动扫描并导入所有爬虫。
"""
import sys
import asyncio

from crawlo.crawler import CrawlerProcess


def main():
    """主函数：运行爬虫"""
    try:
        # 指定爬虫模块路径，框架会自动导入并注册所有爬虫
        spider_modules = ['test_project.spiders']
        process = CrawlerProcess(spider_modules=spider_modules)

        # TODO 运行指定的爬虫
        asyncio.run(process.crawl('of_week_dis'))

    except Exception as e:
        print(f"❌ 运行失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()