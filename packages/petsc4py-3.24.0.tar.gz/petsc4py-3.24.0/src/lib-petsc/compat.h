#ifndef PETSC4PY_COMPAT_H
#define PETSC4PY_COMPAT_H

#include <petsc.h>
#include "compat/mpi.h"
#include "compat/hdf5.h"
#include "compat/mumps.h"
#include "compat/hypre.h"
#include "compat/hpddm.h"
#include "compat/viennacl.h"
#include "compat/cuda.h"
#include "compat/hip.h"
#include "compat/tao.h"
#include "compat/regressor.h"
#include "compat/h2opus.h"
#include "compat/spai.h"
#include "compat/plexexodusii.h"

#endif/*PETSC4PY_COMPAT_H*/
