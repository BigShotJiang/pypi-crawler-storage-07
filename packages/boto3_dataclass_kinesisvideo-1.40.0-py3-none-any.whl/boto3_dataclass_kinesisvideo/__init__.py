# -*- coding: utf-8 -*-

from .caster import kinesisvideo_caster

caster = kinesisvideo_caster

__version__ = "1.40.0"