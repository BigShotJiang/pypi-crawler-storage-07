# -*- coding: utf-8 -*-

from .caster import drs_caster

caster = drs_caster

__version__ = "1.40.0"