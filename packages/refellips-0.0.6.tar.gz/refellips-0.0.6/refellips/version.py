
# THIS FILE IS GENERATED FROM refellips SETUP.PY
short_version = '0.0.6'
version = '0.0.6'
full_version = '0.0.6'
git_revision = '74d29346e51010acec22449e015ec0ef78b8121b'
release = True
if not release:
    version = full_version
