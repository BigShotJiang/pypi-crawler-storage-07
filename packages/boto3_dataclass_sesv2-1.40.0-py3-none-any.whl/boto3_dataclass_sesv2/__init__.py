# -*- coding: utf-8 -*-

from .caster import sesv2_caster

caster = sesv2_caster

__version__ = "1.40.0"