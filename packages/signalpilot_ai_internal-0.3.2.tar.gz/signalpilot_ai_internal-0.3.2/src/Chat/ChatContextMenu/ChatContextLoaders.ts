/**
 * Constants and loading methods for chat context menu
 */
import { Contents } from '@jupyterlab/services';
import { ToolService } from '../../Services/ToolService';
import { DatabaseMetadataCache } from '../../Services/DatabaseMetadataCache';
import { KernelPreviewUtils } from '../../utils/kernelPreview';
import { AppStateService, ISnippet } from '../../AppState';
import { DataLoaderService } from './DataLoaderService';
import { DatabaseStateService } from '../../DatabaseStateService';

export interface MentionContext {
  type:
    | 'snippets'
    | 'data'
    | 'variable'
    | 'cell'
    | 'directory'
    | 'table'
    | 'database';
  id: string;
  name: string;
  content?: string;
  description?: string;
  path?: string; // For directories and files, store the relative path
  isDirectory?: boolean; // Flag to indicate if this is a directory
  parentPath?: string; // For navigation back to parent
}

// Constants
export const VARIABLE_TYPE_BLACKLIST = [
  'module',
  'type',
  'function',
  'ZMQExitAutocall',
  'method'
];

export const VARIABLE_NAME_BLACKLIST = ['In', 'Out'];

export const MENTION_CATEGORIES = [
  {
    id: 'snippets',
    name: 'Rules',
    icon: '📄',
    description: 'Reusable code and prompt templates'
  },
  {
    id: 'data',
    name: 'Data',
    icon: '📊',
    description: 'Dataset references and info'
  },
  {
    id: 'database',
    name: 'Database',
    icon: '🗄️',
    description: 'Database connections and info'
  },
  {
    id: 'variables',
    name: 'Variables',
    icon: '🔤',
    description: 'Code variables and values'
  },
  {
    id: 'cells',
    name: 'Cells',
    icon: '📝',
    description: 'Notebook cell references'
  },
  {
    id: 'tables',
    name: 'Tables',
    icon: '📋',
    description: 'Database table references'
  }
];

/**
 * Class responsible for loading different types of context items
 */
export class ChatContextLoaders {
  private contentManager: Contents.IManager;
  private toolService: ToolService;

  constructor(contentManager: Contents.IManager, toolService: ToolService) {
    this.contentManager = contentManager;
    this.toolService = toolService;
  }

  /**
   * Initialize context items for each category
   */
  public async initializeContextItems(): Promise<
    Map<string, MentionContext[]>
  > {
    const contextItems = new Map<string, MentionContext[]>();

    // Load snippets from AppState (empty initially)
    contextItems.set('snippets', []);
    contextItems.set('data', []);
    contextItems.set('database', []);
    contextItems.set('variables', []);
    contextItems.set('cells', []);
    contextItems.set('tables', []);

    console.log(
      'All context items after initialization:',
      Array.from(contextItems.entries())
    ); // Debug log

    return contextItems;
  }

  /**
   * Load snippets from AppState
   */
  public async loadSnippets(): Promise<MentionContext[]> {
    const snippets = AppStateService.getSnippets();
    return snippets.map(snippet => ({
      type: 'snippets' as const,
      id: snippet.id,
      name: snippet.title,
      description:
        snippet.description.length > 100
          ? snippet.description.substring(0, 100) + '...'
          : snippet.description,
      content: snippet.content
    }));
  }

  /**
   * Load datasets from the data directory using optimized Python kernel script
   * Supports directory traversal and shows directories at the top
   */
  public async loadDatasets(
    currentPath: string = './data'
  ): Promise<MentionContext[]> {
    const datasetContexts: MentionContext[] = [];

    // First, try to add database metadata from cache (never retry pulling it)
    // Only show this at the root level
    if (currentPath === './data') {
      try {
        const dbCache = DatabaseMetadataCache.getInstance();
        const cachedMetadata = await dbCache.getCachedMetadata();
        const db_prompt =
          'Database Connection Available:\n' +
          '- DB_URL environment variable is configured in your Python kernel\n' +
          '- You can connect to the database using standard Python libraries like psycopg2 or sqlalchemy\n' +
          '\n' +
          'Database Schema:\n';
        if (cachedMetadata) {
          datasetContexts.push({
            type: 'data' as const,
            id: 'database-schema',
            name: 'Database Schema',
            description: 'Current database schema information',
            content: `${db_prompt} \n \n ${cachedMetadata}`,
            isDirectory: false
          });
          console.log(
            '[ChatContextLoaders] Added database schema to data contexts'
          );
        }
      } catch (error) {
        console.warn(
          '[ChatContextLoaders] Could not load database metadata:',
          error
        );
      }
    }

    // Load file-based datasets using optimized Python kernel script
    try {
      const fileContexts = await this.loadDatasetsViaKernel(currentPath);
      datasetContexts.push(...fileContexts);
    } catch (error) {
      console.error('Error loading datasets from', currentPath, ':', error);
    }

    return datasetContexts;
  }

  /**
   * Load table names from cached database table schemas
   */
  public async loadTables(): Promise<MentionContext[]> {
    try {
      console.log('[ChatContextLoaders] Starting to load tables...');
      const dbCache = DatabaseMetadataCache.getInstance();
      console.log(
        '[ChatContextLoaders] About to call getCachedTableSchemas()...'
      );
      const tableSchemas = await dbCache.getCachedTableSchemas();
      console.log(
        '[ChatContextLoaders] getCachedTableSchemas() returned:',
        tableSchemas
      );

      console.log('[ChatContextLoaders] Received table schemas:', tableSchemas);
      console.log(
        '[ChatContextLoaders] Table schema keys:',
        Object.keys(tableSchemas || {})
      );

      if (!tableSchemas || Object.keys(tableSchemas).length === 0) {
        console.log('[ChatContextLoaders] No cached table schemas available');
        return [];
      }

      console.log(
        '[ChatContextLoaders] Found cached table schemas, creating table contexts...'
      );

      const tables: MentionContext[] = [];

      for (const [fullTableName, tableInfo] of Object.entries(tableSchemas)) {
        // Build detailed table schema information
        const schemaInfo = this.buildTableSchemaInfo(tableInfo);

        const table_prompt =
          'Database Connection Available:\n' +
          '- DB_URL environment variable is configured in your Python kernel\n' +
          '- You can connect to the database using standard Python libraries like psycopg2 or sqlalchemy\n' +
          '\n' +
          `Table Schema for ${tableInfo.table_name}:\n` +
          schemaInfo;

        tables.push({
          type: 'table' as const,
          id: `table-${fullTableName}`,
          name: tableInfo.table_name,
          description: `Table in ${tableInfo.schema} schema`,
          content: table_prompt
        });
      }

      console.log(
        `[ChatContextLoaders] Loaded ${tables.length} database tables`
      );
      return tables;
    } catch (error) {
      console.warn(
        '[ChatContextLoaders] Error loading database tables:',
        error
      );
      return [];
    }
  }

  /**
   * Build detailed table schema information from table info
   */
  private buildTableSchemaInfo(tableInfo: any): string {
    let schemaInfo = `Schema: ${tableInfo.schema}\n`;
    schemaInfo += `Table: ${tableInfo.table_name}\n\n`;

    // Add columns
    if (tableInfo.columns && tableInfo.columns.length > 0) {
      schemaInfo += `Columns (${tableInfo.columns.length}):\n`;
      for (const col of tableInfo.columns) {
        let dataType = col.data_type;

        // Format data type with precision/scale
        if (col.character_maximum_length) {
          dataType += `(${col.character_maximum_length})`;
        } else if (col.numeric_precision && col.numeric_scale !== null) {
          dataType += `(${col.numeric_precision},${col.numeric_scale})`;
        } else if (col.numeric_precision) {
          dataType += `(${col.numeric_precision})`;
        }

        // Add constraints
        const constraints = [];
        if (col.is_nullable === 'NO') {
          constraints.push('NOT NULL');
        }
        if (col.column_default) {
          constraints.push(`DEFAULT ${col.column_default}`);
        }
        if (
          tableInfo.primary_keys &&
          tableInfo.primary_keys.includes(col.column_name)
        ) {
          constraints.push('PRIMARY KEY');
        }

        const constraintText =
          constraints.length > 0 ? ` (${constraints.join(', ')})` : '';
        schemaInfo += `- ${col.column_name}: ${dataType}${constraintText}\n`;
      }
      schemaInfo += '\n';
    }

    // Add primary keys
    if (tableInfo.primary_keys && tableInfo.primary_keys.length > 0) {
      schemaInfo += `Primary Keys: ${tableInfo.primary_keys.join(', ')}\n`;
    }

    // Add foreign keys
    if (tableInfo.foreign_keys && tableInfo.foreign_keys.length > 0) {
      schemaInfo += 'Foreign Keys:\n';
      for (const fk of tableInfo.foreign_keys) {
        schemaInfo += `- ${fk.column_name} → ${fk.foreign_table_schema}.${fk.foreign_table_name}(${fk.foreign_column_name})\n`;
      }
    }

    return schemaInfo;
  }

  /**
   * Load datasets using the new DataLoaderService (fast, synchronous loading)
   */
  private async loadDatasetsViaKernel(
    currentPath: string = '/data'
  ): Promise<MentionContext[]> {
    console.log('Loading datasets via kernel from path:', currentPath);
    const kernel = this.toolService.getCurrentNotebook()?.kernel;

    if (!kernel) {
      console.warn('[ChatContextLoaders] No kernel available for file loading');
      return [];
    }

    try {
      // Fast synchronous load from cache/JSON file
      const mentionContexts = await DataLoaderService.loadDatasets(
        kernel,
        currentPath
      );
      console.log(
        `[ChatContextLoaders] Successfully loaded ${mentionContexts.length} items from ${currentPath}`
      );
      return mentionContexts;
    } catch (error) {
      console.error(
        '[ChatContextLoaders] Error loading datasets via kernel:',
        error
      );
      return [];
    }
  }

  /**
   * Trigger async refresh of data directory (non-blocking)
   * This should be called when the @ menu is opened
   */
  public triggerAsyncDataRefresh(): void {
    const kernel = this.toolService.getCurrentNotebook()?.kernel;
    if (!kernel) {
      console.warn('[ChatContextLoaders] No kernel available for data refresh');
      return;
    }

    // Start async refresh in the background (don't await it)
    DataLoaderService.refreshDataDirectory(kernel, './data')
      .then(() => {
        console.log(
          '[ChatContextLoaders] Data refresh completed in background'
        );
      })
      .catch(error => {
        console.warn('[ChatContextLoaders] Data refresh failed:', error);
      });
  }

  /**
   * Get the parent path from a given path
   */
  private getParentPath(path: string): string {
    const parts = path.split('/');
    parts.pop(); // Remove the last part
    return parts.join('/') || './data';
  }

  /**
   * Load notebook cells
   */
  public async loadCells(): Promise<MentionContext[]> {
    // console.log('Loading cells... ======================');
    const notebook = this.toolService.getCurrentNotebook();
    if (!notebook) {
      console.warn('No notebook available');
      return [];
    }

    const cellContexts: MentionContext[] = [];
    const cells = notebook.widget.model.cells as any;

    for (const cell of cells) {
      const tracker = cell.metadata.cell_tracker;
      if (tracker) {
        cellContexts.push({
          type: 'cell',
          id: tracker.trackingId,
          name: tracker.trackingId,
          description: '',
          content: cell.sharedModel.getSource()
        });
      }
    }

    return cellContexts;
  }

  /**
   * Load variables from the current kernel
   */
  public async loadVariables(): Promise<MentionContext[]> {
    console.log('Loading variables... ======================');
    const kernel = this.toolService.getCurrentNotebook()?.kernel;
    if (!kernel) {
      console.warn('No kernel available');
      return [];
    }

    try {
      // Use the shared kernel preview utilities to get detailed variable information
      const kernelVariables = await KernelPreviewUtils.getKernelVariables();

      if (!kernelVariables) {
        console.log('No kernel variables available');
        return [];
      }

      const variableContexts: MentionContext[] = [];

      for (const [varName, varInfo] of Object.entries(kernelVariables)) {
        // Skip variables in blacklists
        if (VARIABLE_NAME_BLACKLIST.includes(varName)) continue;
        if (VARIABLE_TYPE_BLACKLIST.includes(varInfo.type)) continue;

        // Create a description based on the variable info
        let description = varInfo.type || 'unknown';
        if (varInfo.shape) {
          description += ` (shape: ${JSON.stringify(varInfo.shape)})`;
        } else if (varInfo.size !== undefined && varInfo.size !== null) {
          description += ` (size: ${varInfo.size})`;
        }

        // Create content for the variable
        let content = '';
        if (varInfo.value !== undefined) {
          content = JSON.stringify(varInfo.value);
        } else if (varInfo.preview !== undefined) {
          content = JSON.stringify(varInfo.preview);
        } else if (varInfo.repr) {
          content = varInfo.repr;
        }

        variableContexts.push({
          type: 'variable',
          id: varName,
          name: varName,
          description: description,
          content: content
        });
      }

      console.log(
        `[ChatContextLoaders] Loaded ${variableContexts.length} variables`
      );
      return variableContexts;
    } catch (error) {
      console.error('Error loading variables:', error);
      return [];
    }
  }

  /**
   * Load database configurations from DatabaseStateService
   */
  public async loadDatabases(): Promise<MentionContext[]> {
    console.log('=== LOADING DATABASSES ===');
    try {
      // Import the getDatabases function dynamically to avoid circular imports
      const { getDatabases } = await import('./databaseHelper');
      const credentials = DatabaseStateService.getState().configurations;
      const databaseContexts = await getDatabases();

      console.log('===== DATABASE CONTEXTS =====');
      console.log(databaseContexts);
      console.log('==== DATABASE CREDENTIALS =====');
      console.log(credentials);

      for (const database of credentials) {
        console.log(database);
        if (database.database_schema) {
          console.log(JSON.parse(database.database_schema));
        }
      }

      console.log(
        `[ChatContextLoaders] Loaded ${databaseContexts.length} database configurations`
      );

      // Convert DatabaseContext to MentionContext
      return databaseContexts.map(db => ({
        type: db.type,
        id: db.id,
        name: db.name,
        description: db.description,
        content: db.content,
        isDirectory: db.isDirectory
      }));
    } catch (error) {
      console.error('Error loading database configurations:', error);
      return [];
    }
  }
}
