"""Modules to facility fitting of data"""

from .general import *
