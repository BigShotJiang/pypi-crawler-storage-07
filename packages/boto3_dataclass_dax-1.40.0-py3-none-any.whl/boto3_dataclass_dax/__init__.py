# -*- coding: utf-8 -*-

from .caster import dax_caster

caster = dax_caster

__version__ = "1.40.0"