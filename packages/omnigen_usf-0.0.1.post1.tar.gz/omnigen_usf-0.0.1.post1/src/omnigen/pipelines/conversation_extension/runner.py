"""Runner for conversation extension pipeline with parallel execution."""

import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm
from omnigen.pipelines.conversation_extension.config import ConversationExtensionConfig
from omnigen.pipelines.conversation_extension.storage import ConversationExtensionStorage
from omnigen.utils.rate_limiter import RateLimiter
from omnigen.utils.logger import setup_logger
from omnigen.pipelines.conversation_extension.generator import ConversationGenerator
from omnigen.pipelines.conversation_extension.data_loader import BaseConversationLoader

logger = setup_logger()


class Runner:
    """Main runner for conversation extension pipeline."""
    
    def __init__(self, config: ConversationExtensionConfig):
        self.config = config
        self.rate_limiter = RateLimiter()
        self.generator = ConversationGenerator(config, self.rate_limiter)
        self.data_loader = BaseConversationLoader(config)
        self.storage = ConversationExtensionStorage(config.get('storage', {}))
    
    def run(self):
        """Run the pipeline."""
        try:
            num_convs = self.config.get('generation.num_conversations', 10)
            num_workers = self.config.get('generation.parallel_workers', 10)
            
            logger.info("="*60)
            logger.info("CONVERSATION EXTENSION PIPELINE")
            logger.info("="*60)
            logger.info(f"Conversations: {num_convs}")
            logger.info(f"Parallel workers: {num_workers}")
            logger.info(f"Base questions: {len(self.data_loader.base_questions)}")
            logger.info("="*60)
            
            self._generate_parallel(num_convs, num_workers)
            
        except KeyboardInterrupt:
            logger.warning("\nInterrupted. Progress saved.")
        except Exception as e:
            logger.error(f"Fatal error: {e}")
            raise
    
    def _generate_parallel(self, num_conversations: int, num_workers: int):
        """Generate conversations in parallel."""
        complete = 0
        partial = 0
        failed = 0
        start_time = time.time()
        
        pbar = tqdm(
            total=num_conversations,
            desc="Generating",
            unit=" conv",
            colour='cyan',
            ncols=140
        )
        
        with ThreadPoolExecutor(max_workers=num_workers, thread_name_prefix="Worker") as executor:
            futures = {}
            
            # Submit all conversations
            for i in range(num_conversations):
                base_question = self.data_loader.get_next_question()
                future = executor.submit(self.generator.generate_conversation, base_question, i)
                futures[future] = i
            
            # Process results
            for future in as_completed(futures):
                conv_id = futures[future]
                
                try:
                    result = future.result()
                    self.storage.save(result)
                    
                    if result['success']:
                        complete += 1
                    elif result.get('is_partial'):
                        partial += 1
                    else:
                        failed += 1
                    
                    # Update progress
                    rpm = self.rate_limiter.get_rpm()
                    pbar.update(1)
                    pbar.set_postfix_str(
                        f"✓{complete} ⚠{partial} ✗{failed} | RPM:{rpm}"
                    )
                    
                except Exception as e:
                    logger.error(f"Error processing conv {conv_id}: {e}")
                    failed += 1
                    pbar.update(1)
        
        pbar.close()
        
        # Summary
        total_time = time.time() - start_time
        total = complete + partial + failed
        
        print("\n" + "="*60)
        print("GENERATION COMPLETE")
        print("="*60)
        print(f"✓ Complete: {complete:>5}")
        print(f"⚠ Partial:  {partial:>5}")
        print(f"✗ Failed:   {failed:>5}")
        print(f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print(f"💾 Saved:   {complete + partial:>5}  ({(complete+partial)/total*100:.1f}%)")
        print(f"⏱  Time:    {total_time/60:>5.1f} min")
        print(f"⚡ Speed:   {total/total_time:>5.2f} conv/s")
        print("="*60)