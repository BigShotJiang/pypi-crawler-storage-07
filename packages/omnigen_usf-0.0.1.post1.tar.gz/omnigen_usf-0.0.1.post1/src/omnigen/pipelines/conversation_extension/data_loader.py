"""Data loader for conversation extension pipeline."""

import json
import random
import threading
from pathlib import Path
from typing import List, Optional
from omnigen.core.config import Config


class BaseConversationLoader:
    """Load base conversations from file or HuggingFace."""
    
    def __init__(self, config: Config):
        self.config = config
        self.base_questions: List[str] = []
        self.current_index = 0
        self.lock = threading.Lock()
        
        source_type = config.get('base_data.source_type', 'file')
        
        if source_type == 'file':
            self._load_from_file()
        elif source_type == 'huggingface':
            self._load_from_huggingface()
        else:
            raise ValueError(f"Invalid source_type: {source_type}")
        
        if not self.base_questions:
            raise ValueError("No valid base questions found")
    
    def _load_from_file(self):
        """Load from local JSONL/JSON file."""
        file_path = self.config.get('base_data.file_path')
        if not file_path or not Path(file_path).exists():
            raise FileNotFoundError(f"Base conversation file not found: {file_path}")
        
        data_format = self.config.get('base_data.format', 'conversations')
        
        with open(file_path, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    data = json.loads(line)
                    convs = data.get(data_format, [])
                    
                    first_user = next((m for m in convs if m.get('role') == 'user'), None)
                    if first_user and first_user.get('content'):
                        self.base_questions.append(first_user['content'])
                except:
                    continue
        
        if self.config.get('base_data.shuffle', False):
            random.shuffle(self.base_questions)
    
    def _load_from_huggingface(self):
        """Load from HuggingFace dataset."""
        try:
            from datasets import load_dataset
        except ImportError:
            raise ImportError("datasets package required. Install with: pip install datasets")
        
        hf_dataset = self.config.get('base_data.hf_dataset')
        hf_split = self.config.get('base_data.hf_split', 'train')
        hf_token = self.config.get('base_data.hf_token')
        data_format = self.config.get('base_data.format', 'conversations')
        
        splits = [hf_split] if isinstance(hf_split, str) else hf_split
        
        for split_name in splits:
            dataset = load_dataset(
                hf_dataset,
                split=split_name,
                token=hf_token,
                streaming=self.config.get('base_data.hf_streaming', False)
            )
            
            for example in dataset:
                try:
                    conversations = example.get(data_format, [])
                    first_user = next((m for m in conversations if m.get('role') == 'user'), None)
                    if first_user and first_user.get('content'):
                        self.base_questions.append(first_user['content'])
                except:
                    continue
        
        if self.config.get('base_data.shuffle', False):
            random.shuffle(self.base_questions)
    
    def get_next_question(self) -> str:
        """Get next question (thread-safe)."""
        with self.lock:
            if self.current_index >= len(self.base_questions):
                self.current_index = 0
                if self.config.get('base_data.shuffle', False):
                    random.shuffle(self.base_questions)
            
            question = self.base_questions[self.current_index]
            self.current_index += 1
            return question