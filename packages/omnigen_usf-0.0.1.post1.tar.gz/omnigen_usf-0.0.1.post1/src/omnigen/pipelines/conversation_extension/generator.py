"""Conversation generator for conversation extension pipeline."""

import random
import re
import time
from datetime import datetime
from typing import List, Dict
from omnigen.pipelines.conversation_extension.config import ConversationExtensionConfig
from omnigen.providers.provider_pool import provider_pool
from omnigen.utils.datetime_gen import DateTimeGenerator
from omnigen.utils.rate_limiter import RateLimiter
from omnigen.utils.logger import setup_logger

logger = setup_logger()


class ConversationGenerator:
    """Generates extended multi-turn conversations."""
    
    def __init__(self, config: ConversationExtensionConfig, rate_limiter: RateLimiter):
        self.config = config
        self.rate_limiter = rate_limiter
        self.workspace_id = config.get('workspace_id', 'default')
        
        # Get provider configs for each role
        self.user_config = config.get_provider_config('user_followup')
        self.assistant_config = config.get_provider_config('assistant_response')
        
        # Get providers from pool (shared if same config, isolated if different)
        self.user_provider = provider_pool.get_or_create(
            self.user_config['name'],
            self.user_config
        )
        
        self.assistant_provider = provider_pool.get_or_create(
            self.assistant_config['name'],
            self.assistant_config
        )
        
        self.datetime_gen = DateTimeGenerator(config)
        self.prompts = config.get('prompts', {})
        self.system_config = config.get('system_messages', {})
        
        logger.info(f"Initialized generator for workspace: {self.workspace_id}")
    
    def generate_conversation(self, base_question: str, conv_id: int) -> Dict:
        """Generate a complete conversation."""
        conversation = []
        turn_range = self.config.get('generation.turn_range', {'min': 3, 'max': 8})
        num_turns = random.randint(turn_range['min'], turn_range['max'])
        conversation_datetime = self.datetime_gen.generate()
        
        try:
            for turn in range(num_turns):
                # User message
                if turn == 0:
                    user_msg = base_question
                else:
                    user_msg = self._generate_followup(conversation)
                
                conversation.append({'role': 'user', 'content': user_msg})
                
                # Assistant message
                assistant_msg = self._generate_response(conversation, conversation_datetime)
                conversation.append({'role': 'assistant', 'content': assistant_msg})
            
            # Apply system messages
            final_conversation = self._apply_system_messages(conversation, conversation_datetime)
            
            return {
                'id': conv_id,
                'conversations': final_conversation,
                'num_turns': num_turns,
                'num_messages': len(final_conversation),
                'ends_with': final_conversation[-1]['role'],
                'success': True,
                'is_complete': True,
                'generated_at': datetime.utcnow().isoformat()
            }
        except Exception as e:
            logger.error(f"Conversation {conv_id} failed: {e}")
            return {
                'id': conv_id,
                'error': str(e),
                'conversations': conversation,
                'success': False,
                'generated_at': datetime.utcnow().isoformat()
            }
    
    def _generate_followup(self, conversation: List[Dict]) -> str:
        """Generate follow-up question using user_followup provider."""
        history = "\n\n".join([f"{m['role'].upper()}: {m['content']}" for m in conversation])
        prompt = self.prompts['followup_question'].format(history=history)
        
        messages = [
            {"role": "system", "content": "You are generating natural follow-up questions."},
            {"role": "user", "content": prompt}
        ]
        
        self.rate_limiter.record_request()
        response = self.user_provider.chat_completion(
            messages,
            temperature=self.user_config.get('temperature', 0.7),
            max_tokens=self.user_config.get('max_tokens', 2048)
        )
        
        return self._extract_from_tags(response, 'user')
    
    def _generate_response(self, conversation: List[Dict], datetime_str: str) -> str:
        """Generate assistant response using assistant_response provider."""
        conversation_with_system = self._apply_system_messages(conversation, datetime_str)
        
        self.rate_limiter.record_request()
        response = self.assistant_provider.chat_completion(
            conversation_with_system,
            temperature=self.assistant_config.get('temperature', 0.7),
            max_tokens=self.assistant_config.get('max_tokens', 8192)
        )
        
        return response.strip()
    
    def _apply_system_messages(self, conversation: List[Dict], datetime_str: str) -> List[Dict]:
        """Apply system message configuration."""
        result = conversation.copy()
        timezone_str = self.datetime_gen.timezone_str if self.datetime_gen.enabled else 'UTC'
        has_system = any(msg.get('role') == 'system' for msg in result)
        
        # Add if missing
        if not has_system:
            add_if_missing = self.system_config.get('add_if_missing', {})
            if add_if_missing.get('enabled', False):
                content = add_if_missing.get('content', '')
                if content:
                    content = content.replace('{current_datetime}', datetime_str or '')
                    content = content.replace('{timezone}', timezone_str)
                    result.insert(0, {'role': 'system', 'content': content})
        
        # Prepend always
        prepend_always = self.system_config.get('prepend_always', {})
        if prepend_always.get('enabled', False):
            content = prepend_always.get('content', '')
            if content:
                content = content.replace('{current_datetime}', datetime_str or '')
                content = content.replace('{timezone}', timezone_str)
                result.insert(0, {'role': 'system', 'content': content})
        
        # Append always
        append_always = self.system_config.get('append_always', {})
        if append_always.get('enabled', False):
            content = append_always.get('content', '')
            if content:
                content = content.replace('{current_datetime}', datetime_str or '')
                content = content.replace('{timezone}', timezone_str)
                result.append({'role': 'system', 'content': content})
        
        return result
    
    def _extract_from_tags(self, text: str, tag: str) -> str:
        """Extract content from XML tags."""
        pattern = f'<{tag}>(.*?)</{tag}>'
        match = re.search(pattern, text, re.DOTALL)
        return match.group(1).strip() if match else text.strip()