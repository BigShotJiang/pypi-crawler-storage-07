# Conversation Extension Pipeline

Extends base conversations into rich multi-turn dialogues using LLM.

## Overview

This pipeline takes single-turn base conversations and extends them by generating:
- Natural follow-up questions from the user perspective
- Contextual assistant responses
- Multi-turn conversations (configurable 3-8 turns or custom)

## Quick Start

### 1. Set API Key

```bash
export OMNIGEN_API_KEY=your_api_key_here
```

### 2. Run Pipeline

```bash
# Using CLI
omnigen generate conversation_extension --config examples/conversation_extension/config.yaml

# Using Python
python examples/conversation_extension/basic_usage.py
```

## Configuration

See [`config.yaml`](config.yaml) for full configuration options.

### Key Settings

- **API**: Provider endpoint and credentials
- **Models**: Separate models for followup questions and responses
- **Generation**: Number of conversations and turn range
- **Base Data**: Source of initial conversations (file or HuggingFace)
- **Storage**: Output format (JSONL or MongoDB)
- **DateTime**: Dynamic timestamp injection
- **System Messages**: Configurable system message behavior

## Output Formats

### JSONL (Default)
```jsonl
{"id": 0, "conversations": [...], "num_turns": 3, "success": true}
```

### MongoDB
Set in config:
```yaml
storage:
  type: mongodb
  mongodb:
    connection_string: mongodb://localhost:27017
    database: omnigen
    collection: conversations
```

## Base Data Sources

### Local File (JSONL)
```yaml
base_data:
  source_type: file
  file_path: base_conversations.jsonl
  format: conversations
```

### HuggingFace Dataset
```yaml
base_data:
  source_type: huggingface
  hf_dataset: username/dataset
  hf_split: train
  hf_token: ${HF_TOKEN}
```

## Advanced Features

- **Parallel Processing**: Configurable workers (default: 10)
- **Rate Limiting**: Built-in with retry logic
- **DateTime Injection**: Random timestamps with timezone support
- **System Messages**: Prepend/append/add_if_missing
- **Custom Prompts**: Modify follow-up question generation

## Output Structure

```json
{
  "id": 0,
  "conversations": [
    {"role": "system", "content": "You are a helpful assistant. Time: 2025-06-15 10:30:00 UTC."},
    {"role": "user", "content": "How do I learn Python?"},
    {"role": "assistant", "content": "Learning Python is great! Start with..."},
    {"role": "user", "content": "What resources do you recommend?"},
    {"role": "assistant", "content": "I recommend..."}
  ],
  "num_turns": 2,
  "num_messages": 5,
  "success": true,
  "generated_at": "2025-01-15T10:30:45Z"
}
```

## Performance

- **Speed**: 1000+ conversations/minute (with 10 workers)
- **Rate Limiting**: Automatic with backoff
- **Memory**: Efficient streaming for large datasets