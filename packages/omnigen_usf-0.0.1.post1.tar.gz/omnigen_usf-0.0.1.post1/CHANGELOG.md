# Changelog

All notable changes to OmniGen will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.0.1.post1] - 2024-10-04

### Added
- Initial release of OmniGen framework
- Conversation Extension pipeline for extending single-turn to multi-turn conversations
- Support for multiple AI providers (OpenAI, Anthropic, Ultrasafe AI, OpenRouter)
- Multi-tenant SaaS architecture support with workspace isolation
- Parallel dataset generation capabilities
- Comprehensive configuration builder with fluent API
- JSONL and MongoDB storage backends
- Rate limiting and error handling
- CLI interface via `omnigen` command
- Comprehensive documentation and examples

### Features
- Pipeline-based architecture for modular data generation
- Provider pool system for load balancing and fallback
- Flexible turn range configuration (3-8 turns per conversation)
- Storage backends: JSONL files and MongoDB
- Thread-safe workspace management
- Progress tracking with tqdm
- Datetime-aware conversation generation

## [0.0.1] - 2024-10-04

### Added
- Initial beta release