from dbxparams import NotebookParams

class ProjectSettings(NotebookParams):
    market: str
    retries: int
    storage_root: str
    database_name: str

# Config file (settings.json)
# {
#   "market": "ES",
#   "retries": 3,
#   "storage_root": "/mnt/data",
#   "database_name": "sales_db"
# }

#  Use it in notebook
params = ProjectSettings.from_json("settings.json")
print(params.market)
print(params.database_name)
