from typing import Any, Dict, get_type_hints
from .errors import MissingParameterError, InvalidTypeError
from .types import cast_value
import json
import os


class NotebookParams:
    def __init__(self, dbutils: Any = None, defaults: Dict[str, Any] = None):
        """
        Initialize parameters.

        Args:
            dbutils: Databricks dbutils instance (optional in debug mode).
            defaults: Dict with fallback values for local/debug runs.
        """
        self._dbutils = dbutils
        self._defaults = defaults or {}
        self._parse_class_annotations()

    def _parse_class_annotations(self):
        """Read type annotations from subclass and assign values."""
        type_hints = get_type_hints(self.__class__)

        for name, type_hint in type_hints.items():
            default = getattr(self, name, None)
            if self._dbutils:
                try:
                    # Create widget if it does not exist
                    self._dbutils.widgets.text(
                        name, str(default) if default is not None else ""
                    )
                except Exception:
                    # Ignore if widget already exists
                    pass
            value = self._get_value(name, type_hint, default)
            setattr(self, name, value)

    def _get_value(self, name: str, type_hint: Any, default: Any):
        """
        Resolve parameter value:
        - From dbutils.widgets if available
        - Else from defaults dict
        - Else from class default
        - Else raise MissingParameterError
        """
        val = None

        # 1. Try dbutils.widgets
        if self._dbutils:
            try:
                val = self._dbutils.widgets.get(name)
            except Exception:
                pass

        # 2. Fallback to defaults dict
        if val is None and name in self._defaults:
            val = self._defaults[name]

        # 3. Fallback to class default
        if val is None and default is not None:
            val = default

        # 4. Error if still None or empty string
        if val is None or (isinstance(val, str) and val.strip() == ""):
            raise MissingParameterError(name)

        # 5. Validate type if hint provided
        try:
            return cast_value(val, type_hint) if type_hint else val
        except Exception:
            raise InvalidTypeError(name, type_hint, val)

    @classmethod
    def from_json(cls, json_source: str):
        """
        Create an instance of the subclass from a JSON file or JSON string.

        Args:
            json_source: Path to a JSON file or a raw JSON string.

        Returns:
            An initialized instance of the subclass.
        """
        data = None

        if os.path.exists(json_source):
            with open(json_source, "r", encoding="utf-8") as f:
                data = json.load(f)
        else:
            try:
                data = json.loads(json_source)
            except json.JSONDecodeError as e:
                raise ValueError(
                    f"Invalid JSON input: {e}. "
                    f"Expected a valid JSON file path or JSON string."
                )

        if not isinstance(data, dict):
            raise ValueError(
                f"Invalid JSON structure: expected a dict at top level, got {type(data).__name__}."
            )

        return cls(defaults=data)
