import json
import pytest
from pathlib import Path
from dbxparams import NotebookParams

# ---- Example subclass ----
class JsonParams(NotebookParams):
    market: str
    retries: int
    debug: bool
    storage_root: str
    database_name: str


# ---- Fixture global ----
@pytest.fixture
def json_path():
    """Path to the static test JSON."""
    return Path(__file__).parent / "resources" / "settings.json"


# ---- Tests ----
def test_from_json_file(json_path):
    """Should correctly load parameters from a valid JSON file."""
    params = JsonParams.from_json(str(json_path))
    assert params.market == "ES"
    assert params.retries == 3
    assert params.debug is True
    assert params.storage_root == "/mnt/data"
    assert params.database_name == "sales_db"


def test_from_json_string(json_path):
    """Should correctly load parameters from a JSON string (same content)."""
    raw_json = json_path.read_text()
    params = JsonParams.from_json(raw_json)
    assert params.market == "ES"
    assert params.retries == 3
    assert params.debug is True
    assert params.storage_root == "/mnt/data"
    assert params.database_name == "sales_db"


def test_from_json_nonexistent_file(tmp_path):
    """Should raise ValueError if the file path is invalid."""
    bad_path = tmp_path / "missing.json"
    with pytest.raises(ValueError):
        JsonParams.from_json(str(bad_path))


def test_from_json_invalid_json(tmp_path):
    """Should raise ValueError if JSON is malformed."""
    broken_path = tmp_path / "broken.json"
    broken_path.write_text("{invalid json}")
    with pytest.raises(ValueError):
        JsonParams.from_json(str(broken_path))


def test_from_json_wrong_structure(tmp_path):
    """Should raise ValueError if top-level JSON is not a dict."""
    list_path = tmp_path / "list.json"
    list_path.write_text(json.dumps(["a", "b", "c"]))
    with pytest.raises(ValueError):
        JsonParams.from_json(str(list_path))
