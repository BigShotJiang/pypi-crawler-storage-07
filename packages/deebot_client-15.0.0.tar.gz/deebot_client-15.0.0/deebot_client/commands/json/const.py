"""Command constants module."""

from __future__ import annotations

CODE = "code"
