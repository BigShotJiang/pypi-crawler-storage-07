# -*- coding: utf-8 -*-

from .caster import panorama_caster

caster = panorama_caster

__version__ = "1.40.0"