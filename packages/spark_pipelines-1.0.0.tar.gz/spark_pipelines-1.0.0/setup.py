from setuptools import setup, find_packages

setup(
    name="spark_pipelines",
    version="1.0.0",
    author="Nilesh Pise",
    author_email="neil9190patil@gmail.com",
    description="A simple data quality framework for PySpark DataFrames",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ])