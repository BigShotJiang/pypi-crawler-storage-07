"""
Paquete programacion
Ejercicios y ejemplos en Python
"""

__version__ = "0.1.0"

# Puedes importar cosas de uso frecuente aquí
from .Python import prueba
