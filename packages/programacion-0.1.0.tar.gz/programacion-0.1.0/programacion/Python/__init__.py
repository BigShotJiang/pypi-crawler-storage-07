"""
Subpaquete con scripts y ejercicios en Python
"""

from . import prueba
from . import prueba2
from . import prueba3
from . import prueba4
from . import prueba5
from . import prueba6
from . import prueba7
from . import prueba8
from . import prueba9
from . import prueba10
from . import prueba11

# Importa también la carpeta de ejercicios
from . import EjericiciosTema1
