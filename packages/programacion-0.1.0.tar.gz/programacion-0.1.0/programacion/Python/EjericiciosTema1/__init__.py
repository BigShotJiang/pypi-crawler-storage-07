"""
Ejercicios del Tema 1
"""

from . import cuentaAtras10_0
from . import ecuacion_primer_grado
from . import SumaFracciones
