This module allows to create documents for signature inside Odoo using
OWL.
