"""Doctest configuration."""

import platform
from doctest import ELLIPSIS, NORMALIZE_WHITESPACE

from sybil import Sybil
from sybil.parsers.rest import DocTestParser, PythonCodeBlockParser, SkipParser

from optional_dependencies import OptionalDependencyEnum, auto

# TODO: stop skipping doctests on Windows when there is uniform support for
#       numpy 2.0+ scalar repr. On windows it is printed as 1.0 instead of
#       `np.float64(1.0)`.
parsers = (
    [DocTestParser(optionflags=ELLIPSIS | NORMALIZE_WHITESPACE)]
    if platform.system() != "Windows"
    else []
) + [
    PythonCodeBlockParser(),
    SkipParser(),
]

pytest_collect_file = Sybil(
    parsers=parsers,
    patterns=["*.rst", "*.py"],
).pytest()


class OptDeps(OptionalDependencyEnum):  # type: ignore[misc]  # pylint: disable=invalid-enum-extension
    """Optional dependencies for ``zeroth``."""

    ASTROPY = auto()
    GALA = auto()


collect_ignore_glob = []
if not OptDeps.ASTROPY.installed:
    collect_ignore_glob.append("src/unxt/_interop/unxt_interop_astropy/*")
if not OptDeps.GALA.installed:
    collect_ignore_glob.append("src/unxt/_interop/unxt_interop_gala/*")
