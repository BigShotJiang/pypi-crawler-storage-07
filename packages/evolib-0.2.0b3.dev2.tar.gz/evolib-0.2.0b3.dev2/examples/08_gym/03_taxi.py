"""
"""
import numpy as np
from evolib import GymEnv, Individual, Population, resume_or_create

CONFIG_FILE = "./configs/03_taxi.yaml"
FRAME_FOLDER = "03_frames"
MAX_STEPS = 150

# init environment once (can be reused for all individuals)
gym_env = GymEnv("Taxi-v3", max_steps=MAX_STEPS)


def eval_fitness(indiv: Individual, episodes: int = 5) -> None:
    """
    Evaluate an individual in the Taxi-v3 environment with reward shaping,
    averaged across multiple episodes.
    """
    taxi_env = gym_env.env.unwrapped
    total_reward = 0.0

    for _ in range(episodes):
        obs, _ = gym_env.env.reset()
        ep_reward = 0.0

        for _ in range(gym_env.max_steps):
            # --- Choose action from network ---
            action_vec = indiv.para["brain"].net.calc([float(obs)])
            action = int(np.argmax(action_vec))

            # --- Decode current state ---
            old_taxi_row, old_taxi_col, pass_loc, dest_idx = taxi_env.decode(obs)

            # Target = passenger before pickup, else destination
            if pass_loc != 4:
                target_row, target_col = taxi_env.locs[pass_loc]
            else:
                target_row, target_col = taxi_env.locs[dest_idx]
            old_dist = abs(old_taxi_row - target_row) + abs(old_taxi_col - target_col)

            # --- Step ---
            obs, reward, terminated, truncated, _ = gym_env.env.step(action)
            ep_reward += reward

            # --- Shaping ---
            if reward == -10:
                ep_reward -= 5.0

            new_taxi_row, new_taxi_col, pass_loc, dest_idx = taxi_env.decode(obs)
            if pass_loc != 4:
                target_row, target_col = taxi_env.locs[pass_loc]
            else:
                target_row, target_col = taxi_env.locs[dest_idx]
            new_dist = abs(new_taxi_row - target_row) + abs(new_taxi_col - target_col)

            ep_reward += (old_dist - new_dist) * 0.2

            if terminated or truncated:
                break

        total_reward += ep_reward

    # Average fitness across episodes
    indiv.fitness = -total_reward / episodes

def on_generation_end(pop: Population) -> None:
    """Visualize the best individual of the current generation as a GIF."""

    best = pop.best()
    gif = gym_env.visualize(
        best,
        pop.generation_num,
        filename=f"{FRAME_FOLDER}/gen_{pop.generation_num:03d}.gif",
    )
    print(f"Saved: {gif}")


if __name__ == "__main__":
    pop = resume_or_create(
        CONFIG_FILE,
        fitness_function=eval_fitness,
        run_name="Taxi-v3",
    )

    pop.run(verbosity=1, on_generation_end=on_generation_end)
