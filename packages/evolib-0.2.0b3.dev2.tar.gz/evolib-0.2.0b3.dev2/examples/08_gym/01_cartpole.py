import numpy as np
from evolib import Population, Individual, resume_or_create, GymEnv

CONFIG_FILE = "./configs/01_cartpole.yaml"
FRAME_FOLDER = "01_frames"
MAX_STEPS = 500

# init environment once (can be reused for all individuals)
cartpole_env = GymEnv("CartPole-v1", max_steps=MAX_STEPS)


def eval_fitness(indiv: Individual) -> None:
    """Assign fitness to an individual by running one CartPole episode."""
    fitness = cartpole_env.evaluate(indiv, module="brain")
    indiv.fitness = -fitness


def on_generation_end(pop: Population) -> None:
    best = pop.best()
    gif = cartpole_env.visualize(best, pop.generation_num,
            filename=f"{FRAME_FOLDER}/gen_{pop.generation_num:03d}.gif")
    print(f"Saved: {gif}")


if __name__ == "__main__":
    pop = resume_or_create(
        CONFIG_FILE,
        fitness_function=eval_fitness,
        run_name="08_cartpole",
    )

    pop.run(verbosity=1, on_generation_end=on_generation_end)
