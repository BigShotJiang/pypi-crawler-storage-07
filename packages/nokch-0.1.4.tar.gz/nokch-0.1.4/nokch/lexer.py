"""lexical analysis 😃"""

from .tokens import T, Token


class Lexer:
    def __init__(self, code) -> None:
        if isinstance(code, str):
            code = [code]  # wrap string in a list
        self.lines = code
        self.line_index = 0
        self.text = self.lines[self.line_index] if self.lines else ""
        self.pos = 0
        self.c_char = self.text[0] if self.text else None

    def advance(self) -> None:
        self.pos += 1
        if self.pos < len(self.text):
            self.c_char = self.text[self.pos]
        else:
            self.c_char = None

    def skip_whitespace(self) -> None:
        while self.c_char is not None and self.c_char.isspace():
            self.advance()

    def number(self) -> Token:
        num_str = ""
        has_dot = False
        while self.c_char is not None and (self.c_char.isdigit() or self.c_char == "."):
            if self.c_char == ".":
                if has_dot:
                    break
                has_dot = True
            num_str += self.c_char
            self.advance()
        if has_dot:
            return Token(T.FLOAT, float(num_str))
        return Token(T.INT, int(num_str))

    def identifier(self) -> Token:
        result = ""
        while self.c_char is not None and (self.c_char.isalnum() or self.c_char == "_"):
            result += self.c_char
            self.advance()
        return Token(T.IDENTIFIER, result)

    def get_next_token(self) -> Token:
        while self.c_char is not None:
            if self.c_char.isspace():
                self.skip_whitespace()
                continue

            if self.c_char.isdigit():
                return self.number()

            if self.c_char.isalpha() or self.c_char == "_":
                return self.identifier()

            if self.c_char == "+":
                self.advance()
                return Token(T.PLUS)
            if self.c_char == "-":
                self.advance()
                return Token(T.MINUS)
            if self.c_char == "*":
                self.advance()
                if self.c_char == "*":
                    self.advance()
                    return Token(T.POW)
                return Token(T.MUL)
            if self.c_char == "/":
                self.advance()
                if self.c_char == "/":
                    self.advance()
                    return Token(T.FLOORDIV)
                return Token(T.DIV)
            if self.c_char == "%":
                self.advance()
                return Token(T.MOD)
            if self.c_char == "=":
                self.advance()
                return Token(T.ASSIGN)
            if self.c_char == ";":
                self.advance()
                return Token(T.SEMICOLON)  # new token type for semicolons

            raise ValueError(f"Unknown character: {self.c_char}")

        return Token(T.EOF)

    def next_line(self) -> bool:
        """Move to the next line if any. Returns False if no more lines."""
        self.line_index += 1
        if self.line_index < len(self.lines):
            self.text = self.lines[self.line_index]
            self.pos = 0
            self.c_char = self.text[0] if self.text else None
            return True
        return False

    def __call__(self):
        tokens = []
        while True:
            while (tok := self.get_next_token()).type != T.EOF:
                tokens.append(tok)
            if not self.next_line():
                break
        tokens.append(Token(T.EOF))
        return tokens
