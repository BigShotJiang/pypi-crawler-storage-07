"""Init for ``cltk.languages``."""

# from .glottolog import LANGUAGES
