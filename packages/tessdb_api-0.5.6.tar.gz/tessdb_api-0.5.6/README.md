# tessdb-api

API functions and dataclasses to build general utilities on top of the tessdb DAO

