# Enverge Proxy

[![PyPI version](https://img.shields.io/pypi/v/enverge_proxy)](https://pypi.org/project/enverge_proxy/)

Connects Google Colab with the Enverge servers through a proxy, which runs on the local machine.

The proxy routes http://localhost:9000 to https://colab.enverge.ai.

Enverge.ai runs a Jupyter Notebook server.

The proxy should handle all ports, all types of TCP requests and authentication.

# Requirements

- Python 3.10 and above
- Unix/Windows terminal

# Installation

```bash
pip install enverge_proxy
```

# Getting Started

```
enverge --help
enverge start
```

# Context

> [Enverge.ai](https://enverge.ai) - Simpler, greener, cheaper AI training platform. 
>
> Enverge harnesses excess green energy for powerful, cost-effective computing on GPUs, enabling environmentally friendly AI model development, training, and fine-tuning. Currently in private alpha with limited spots available.