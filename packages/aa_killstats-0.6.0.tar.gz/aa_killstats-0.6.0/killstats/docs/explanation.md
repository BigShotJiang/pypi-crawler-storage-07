## Explanation of the Killstats Functionality

### Single View in Overview

The Overview only display Corporation/Alliances you are in.
However, if you go to the Overview and click on a corporation, a single view is displayed. This means that only the kills of the selected corporation are displayed and not summarized.

### Single View Corporation A:

#### Hall of Fame:

- **Character A** - Ishtar - 220m

### Single View Corporation B:

#### Hall of Fame:

- **Character B (Main Character)** - Vexor - 100m
- **Character C** - Venture - 5m

### Single View Corporation C:

#### Hall of Fame:

- **Character D** - Stabber - 40m
