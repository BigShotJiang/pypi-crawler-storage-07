# special file for defining the current version of the package
__version__ = "1.8.3"
