from enum import Enum
from typing import Callable, Dict, Any
from .agent_card import AgentCard

class VerbType(Enum):
    TOOLS = 1
    PROMPTS = 2
    RESOURCES = 3

AuthCallback = Callable[[AgentCard], Dict[str, Any]]