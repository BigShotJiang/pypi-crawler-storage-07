__version__ = "1.0.0"
VERSION = __version__
"Current version"
