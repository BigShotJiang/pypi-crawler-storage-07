Model
=====

.. automodule:: jmstate.model
   :members:
   :undoc-members:
   :no-index:

.. autosummary::
   :toctree: generated/
   :recursive:

   MultiStateJointModel