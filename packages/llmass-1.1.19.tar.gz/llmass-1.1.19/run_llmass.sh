#!/bin/bash
# Wrapper script for llmass CLI - handles the missing command issue
# Usage: ./run_llmass.sh <command> [args...]
# Example: ./run_llmass.sh write --dry-run --limit 3

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

exec python3 llmass_cli.py "$@"
