#!/usr/bin/env python3
"""
Quick verification test for email_responder.py IMAP client migration
Tests that the new ImapClient integration works correctly
"""

import sys
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

def test_import():
    """Test that all imports work correctly"""
    try:
        from email_responder import EmailResponder
        print("✅ Import email_responder: OK")
        
        from llmass.imap import connect_imap
        print("✅ Import connect_imap: OK")
        
        # Store for later use
        globals()['EmailResponder'] = EmailResponder
        
        return True
    except Exception as e:
        print(f"❌ Import error: {e}")
        return False

def test_responder_init():
    """Test EmailResponder initialization (basic attributes only)"""
    try:
        # Import again in this scope
        from email_responder import EmailResponder
        
        print("✅ EmailResponder class import: OK")
        
        # Test that the class has the expected methods
        expected_methods = ['connect', '_detect_imap_server', 'process_emails', 'save_draft']
        for method in expected_methods:
            if hasattr(EmailResponder, method):
                print(f"✅ Method {method}: found")
            else:
                print(f"⚠️  Method {method}: not found")
        
        print("✅ EmailResponder structure check: OK")
        
        return True
    except Exception as e:
        print(f"❌ EmailResponder init error: {e}")
        return False

def test_config_loading():
    """Test that IMAP config variables load correctly"""
    try:
        imap_retries = int(os.getenv('IMAP_RETRIES', '2'))
        imap_backoff = float(os.getenv('IMAP_BACKOFF', '0.5'))
        
        print(f"✅ IMAP config: retries={imap_retries}, backoff={imap_backoff}")
        
        # Test reasonable values
        assert 0 <= imap_retries <= 10
        assert 0.0 <= imap_backoff <= 10.0
        print("✅ IMAP config validation: OK")
        
        return True
    except Exception as e:
        print(f"❌ Config loading error: {e}")
        return False

def main():
    """Run all verification tests"""
    print("🔍 Testing email_responder.py IMAP client migration...")
    print("=" * 60)
    
    tests = [
        ("Import tests", test_import),
        ("EmailResponder initialization", test_responder_init), 
        ("Config loading", test_config_loading),
    ]
    
    results = []
    for test_name, test_func in tests:
        print(f"\n📋 {test_name}:")
        try:
            result = test_func()
            results.append(result)
        except Exception as e:
            print(f"❌ {test_name} failed: {e}")
            results.append(False)
    
    print("\n" + "=" * 60)
    passed = sum(results)
    total = len(results)
    
    if passed == total:
        print(f"🎉 All tests passed! ({passed}/{total})")
        print("\n✨ Migration verification: SUCCESSFUL")
        print("🚀 Ready for dry-run testing!")
        return 0
    else:
        print(f"⚠️  Some tests failed: {passed}/{total} passed")
        return 1

if __name__ == "__main__":
    sys.exit(main())
