"""Email responder utilities."""
