from dataclasses import dataclass
from typing import Optional
import os
from dotenv import load_dotenv

from llmass.logging_utils import LogCtl


@dataclass
class OrganizerConfig:
    email: str
    password: str
    server: Optional[str] = None
    limit: Optional[int] = None
    since_days: Optional[int] = None
    since_date: Optional[str] = None
    folder: Optional[str] = None
    include_subfolders: bool = False
    similarity_threshold: Optional[float] = None
    min_cluster_size: Optional[int] = None
    min_cluster_fraction: Optional[float] = None
    dry_run: bool = False
    verbose: bool = False


class OrganizerApp:
    def __init__(self, log: Optional[LogCtl] = None):
        self.log = log or LogCtl(verbose=False)

    def run(self, cfg: OrganizerConfig) -> None:
        # For now, delegate to legacy EmailOrganizer to stay functional.
        from email_organizer import EmailOrganizer

        bot = EmailOrganizer(
            cfg.email,
            cfg.password,
            cfg.server,
            similarity_threshold=cfg.similarity_threshold,
            min_cluster_size=cfg.min_cluster_size,
            min_cluster_fraction=cfg.min_cluster_fraction,
            dry_run=cfg.dry_run,
            verbose=cfg.verbose,
        )
        if bot.connect():
            try:
                bot.organize_mailbox(
                    limit=cfg.limit if cfg.limit is not None else 100,
                    since_days=cfg.since_days if cfg.since_days is not None else 7,
                    since_date=cfg.since_date,
                    folder=cfg.folder,
                    include_subfolders=cfg.include_subfolders,
                )
            finally:
                bot.disconnect()


def run_clean_from_args(args) -> None:
    # Załaduj zmienne środowiskowe z .env jeśli jeszcze nie załadowane
    load_dotenv()
    
    log = LogCtl(verbose=bool(getattr(args, 'verbose', False)))
    cfg = OrganizerConfig(
        email=getattr(args, 'email', None) or os.getenv('EMAIL_ADDRESS', ''),
        password=getattr(args, 'password', None) or os.getenv('EMAIL_PASSWORD', ''),
        server=getattr(args, 'server', None) or os.getenv('IMAP_SERVER', None),
        limit=getattr(args, 'limit', None) or int(os.getenv('LIMIT', '100')),
        since_days=getattr(args, 'since_days', None) or int(os.getenv('SINCE_DAYS', '7')),
        since_date=getattr(args, 'since_date', None) or os.getenv('SINCE_DATE', None),
        folder=getattr(args, 'folder', None) or 'INBOX',
        include_subfolders=bool(getattr(args, 'include_subfolders', False)),
        similarity_threshold=getattr(args, 'similarity_threshold', None) or float(os.getenv('SIMILARITY_THRESHOLD', '0.25')),
        min_cluster_size=getattr(args, 'min_cluster_size', None) or int(os.getenv('MIN_CLUSTER_SIZE', '2')),
        min_cluster_fraction=getattr(args, 'min_cluster_fraction', None) or float(os.getenv('MIN_CLUSTER_FRACTION', '0.10')),
        dry_run=bool(getattr(args, 'dry_run', False)) or os.getenv('DRY_RUN', 'false').lower() == 'true',
        verbose=bool(getattr(args, 'verbose', False)),
    )
    if not cfg.email or not cfg.password:
        log.error("❌ Brak wymaganych danych logowania. Użyj --email i --password lub .env")
        log.error(f"   Email: {'✓' if cfg.email else '✗'} ({cfg.email or 'brak'})")
        log.error(f"   Password: {'✓' if cfg.password else '✗'} ({'***' if cfg.password else 'brak'})")
        return
    OrganizerApp(log).run(cfg)
