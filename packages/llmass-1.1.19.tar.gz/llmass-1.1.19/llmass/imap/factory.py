from __future__ import annotations
from typing import Tuple

from .session import ImapSession
from .client import ImapClient


def make_session(server: str, ssl: bool = True) -> ImapSession:
    """Create an ImapSession (not connected)."""
    return ImapSession(server, ssl=ssl)


def make_client(session: ImapSession, retries: int = 2, backoff: float = 0.5, verbose: bool = False) -> ImapClient:
    """Wrap a session with an ImapClient using simple retry/backoff policies."""
    return ImapClient(session, retries=retries, backoff=backoff, verbose=verbose)


def connect_imap(
    server: str,
    username: str,
    password: str,
    *,
    ssl: bool = True,
    retries: int = 2,
    backoff: float = 0.5,
    verbose: bool = False,
) -> Tuple[ImapClient, ImapSession]:
    """Create an ImapSession, connect+login, and return (client, session).

    The caller owns the session and should call session.close()/logout() when done.
    """
    session = ImapSession(server, ssl=ssl)
    session.connect()
    session.login(username, password)
    client = ImapClient(session, retries=retries, backoff=backoff, verbose=verbose)
    return client, session
