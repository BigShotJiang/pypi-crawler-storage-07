#!/bin/bash
# Quick dry-run test for email_responder.py migration
# Tests the new ImapClient integration without actual email operations

echo "🔍 Testing email_responder.py migration with dry-run..."
echo "=================================================="

# Check if .env exists
if [ ! -f .env ]; then
    echo "⚠️  .env file not found, using defaults"
    echo "   Ensure EMAIL_ADDRESS and EMAIL_PASSWORD are set"
fi

echo ""
echo "📋 Test 1: Basic help and argument parsing"
python3 email_responder.py --help | head -5
echo "✅ Help output: OK"

echo ""
echo "📋 Test 2: Dry-run with mock credentials (should fail connection gracefully)"
timeout 10s python3 email_responder.py \
    --email "test@localhost" \
    --password "test123" \
    --dry-run \
    --limit 1 \
    --since-days 1 2>/dev/null || echo "✅ Connection failed as expected (no server)"

echo ""
echo "📋 Test 3: Environment variable loading test"
python3 -c "
import os
from dotenv import load_dotenv
load_dotenv()

imap_retries = os.getenv('IMAP_RETRIES', '2')
imap_backoff = os.getenv('IMAP_BACKOFF', '0.5')
print(f'✅ IMAP_RETRIES: {imap_retries}')
print(f'✅ IMAP_BACKOFF: {imap_backoff}')
"

echo ""
echo "=================================================="
echo "🎉 Dry-run tests completed!"
echo ""
echo "Next steps:"
echo "- Set up real IMAP credentials in .env"
echo "- Test with: python3 email_responder.py --dry-run --limit 3"
echo "- For production: python3 email_responder.py --limit 5"
