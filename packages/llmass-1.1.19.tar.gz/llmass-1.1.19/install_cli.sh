#!/bin/bash
# Install LLMASS CLI in development mode
# This fixes the "No module named 'llmass'" error

set -e

echo "🔧 Installing LLMASS CLI in development mode..."

# Check if we're in a virtual environment
if [[ "$VIRTUAL_ENV" != "" ]]; then
    echo "✅ Virtual environment detected: $VIRTUAL_ENV"
    pip install -e .
    echo "✅ LLMASS CLI installed successfully!"
    echo "   You can now use: llmass clean --help"
elif command -v pipx &> /dev/null; then
    echo "📦 Installing with pipx (recommended for system-wide CLI)..."
    pipx install -e .
    echo "✅ LLMASS CLI installed with pipx!"
    echo "   You can now use: llmass clean --help"
else
    echo "⚠️  No virtual environment detected and pipx not available."
    echo "   Creating temporary virtual environment..."
    
    python3 -m venv venv_temp
    source venv_temp/bin/activate
    pip install -e .
    
    echo "✅ LLMASS CLI installed in temporary venv!"
    echo ""
    echo "To use it:"
    echo "   source venv_temp/bin/activate"
    echo "   llmass clean --help"
    echo ""
    echo "OR use the wrapper script:"
    echo "   ./run_llmass.sh clean --help"
fi

echo ""
echo "🎉 Installation complete!"
echo ""
echo "Test the CLI:"
echo "   llmass --help"
echo "   llmass clean --help"
echo "   llmass write --help"
