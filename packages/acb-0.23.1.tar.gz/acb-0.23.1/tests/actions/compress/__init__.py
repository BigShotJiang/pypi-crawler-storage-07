"""Compress action tests package."""
