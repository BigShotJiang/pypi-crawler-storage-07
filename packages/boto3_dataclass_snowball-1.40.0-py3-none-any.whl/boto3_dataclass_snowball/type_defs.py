# -*- coding: utf-8 -*-

import typing as T
import dataclasses
from functools import cached_property

if T.TYPE_CHECKING:  # pragma: no cover
    from mypy_boto3_snowball import type_defs


def field(name: str):
    def getter(self):
        return self.boto3_raw_data[name]

    return cached_property(getter)


@dataclasses.dataclass(frozen=True)
class Address:
    boto3_raw_data: "type_defs.AddressTypeDef" = dataclasses.field()

    AddressId = field("AddressId")
    Name = field("Name")
    Company = field("Company")
    Street1 = field("Street1")
    Street2 = field("Street2")
    Street3 = field("Street3")
    City = field("City")
    StateOrProvince = field("StateOrProvince")
    PrefectureOrDistrict = field("PrefectureOrDistrict")
    Landmark = field("Landmark")
    Country = field("Country")
    PostalCode = field("PostalCode")
    PhoneNumber = field("PhoneNumber")
    IsRestricted = field("IsRestricted")
    Type = field("Type")

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.AddressTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls, boto3_raw_data_list: T.Optional[T.Iterable["type_defs.AddressTypeDef"]]
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class CancelClusterRequest:
    boto3_raw_data: "type_defs.CancelClusterRequestTypeDef" = dataclasses.field()

    ClusterId = field("ClusterId")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.CancelClusterRequestTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.CancelClusterRequestTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class CancelJobRequest:
    boto3_raw_data: "type_defs.CancelJobRequestTypeDef" = dataclasses.field()

    JobId = field("JobId")

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.CancelJobRequestTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.CancelJobRequestTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ClusterListEntry:
    boto3_raw_data: "type_defs.ClusterListEntryTypeDef" = dataclasses.field()

    ClusterId = field("ClusterId")
    ClusterState = field("ClusterState")
    CreationDate = field("CreationDate")
    Description = field("Description")

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.ClusterListEntryTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ClusterListEntryTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class NotificationOutput:
    boto3_raw_data: "type_defs.NotificationOutputTypeDef" = dataclasses.field()

    SnsTopicARN = field("SnsTopicARN")
    JobStatesToNotify = field("JobStatesToNotify")
    NotifyAll = field("NotifyAll")
    DevicePickupSnsTopicARN = field("DevicePickupSnsTopicARN")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.NotificationOutputTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.NotificationOutputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class CompatibleImage:
    boto3_raw_data: "type_defs.CompatibleImageTypeDef" = dataclasses.field()

    AmiId = field("AmiId")
    Name = field("Name")

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.CompatibleImageTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[T.Iterable["type_defs.CompatibleImageTypeDef"]],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ResponseMetadata:
    boto3_raw_data: "type_defs.ResponseMetadataTypeDef" = dataclasses.field()

    RequestId = field("RequestId")
    HTTPStatusCode = field("HTTPStatusCode")
    HTTPHeaders = field("HTTPHeaders")
    RetryAttempts = field("RetryAttempts")
    HostId = field("HostId")

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.ResponseMetadataTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ResponseMetadataTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class JobListEntry:
    boto3_raw_data: "type_defs.JobListEntryTypeDef" = dataclasses.field()

    JobId = field("JobId")
    JobState = field("JobState")
    IsMaster = field("IsMaster")
    JobType = field("JobType")
    SnowballType = field("SnowballType")
    CreationDate = field("CreationDate")
    Description = field("Description")

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.JobListEntryTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[T.Iterable["type_defs.JobListEntryTypeDef"]],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class CreateLongTermPricingRequest:
    boto3_raw_data: "type_defs.CreateLongTermPricingRequestTypeDef" = (
        dataclasses.field()
    )

    LongTermPricingType = field("LongTermPricingType")
    SnowballType = field("SnowballType")
    IsLongTermPricingAutoRenew = field("IsLongTermPricingAutoRenew")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.CreateLongTermPricingRequestTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.CreateLongTermPricingRequestTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class CreateReturnShippingLabelRequest:
    boto3_raw_data: "type_defs.CreateReturnShippingLabelRequestTypeDef" = (
        dataclasses.field()
    )

    JobId = field("JobId")
    ShippingOption = field("ShippingOption")

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional["type_defs.CreateReturnShippingLabelRequestTypeDef"],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.CreateReturnShippingLabelRequestTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class DataTransfer:
    boto3_raw_data: "type_defs.DataTransferTypeDef" = dataclasses.field()

    BytesTransferred = field("BytesTransferred")
    ObjectsTransferred = field("ObjectsTransferred")
    TotalBytes = field("TotalBytes")
    TotalObjects = field("TotalObjects")

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.DataTransferTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[T.Iterable["type_defs.DataTransferTypeDef"]],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ServiceVersion:
    boto3_raw_data: "type_defs.ServiceVersionTypeDef" = dataclasses.field()

    Version = field("Version")

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.ServiceVersionTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[T.Iterable["type_defs.ServiceVersionTypeDef"]],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class DescribeAddressRequest:
    boto3_raw_data: "type_defs.DescribeAddressRequestTypeDef" = dataclasses.field()

    AddressId = field("AddressId")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.DescribeAddressRequestTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.DescribeAddressRequestTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class PaginatorConfig:
    boto3_raw_data: "type_defs.PaginatorConfigTypeDef" = dataclasses.field()

    MaxItems = field("MaxItems")
    PageSize = field("PageSize")
    StartingToken = field("StartingToken")

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.PaginatorConfigTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[T.Iterable["type_defs.PaginatorConfigTypeDef"]],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class DescribeAddressesRequest:
    boto3_raw_data: "type_defs.DescribeAddressesRequestTypeDef" = dataclasses.field()

    MaxResults = field("MaxResults")
    NextToken = field("NextToken")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.DescribeAddressesRequestTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.DescribeAddressesRequestTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class DescribeClusterRequest:
    boto3_raw_data: "type_defs.DescribeClusterRequestTypeDef" = dataclasses.field()

    ClusterId = field("ClusterId")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.DescribeClusterRequestTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.DescribeClusterRequestTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class DescribeJobRequest:
    boto3_raw_data: "type_defs.DescribeJobRequestTypeDef" = dataclasses.field()

    JobId = field("JobId")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.DescribeJobRequestTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.DescribeJobRequestTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class DescribeReturnShippingLabelRequest:
    boto3_raw_data: "type_defs.DescribeReturnShippingLabelRequestTypeDef" = (
        dataclasses.field()
    )

    JobId = field("JobId")

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.DescribeReturnShippingLabelRequestTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.DescribeReturnShippingLabelRequestTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class EKSOnDeviceServiceConfiguration:
    boto3_raw_data: "type_defs.EKSOnDeviceServiceConfigurationTypeDef" = (
        dataclasses.field()
    )

    KubernetesVersion = field("KubernetesVersion")
    EKSAnywhereVersion = field("EKSAnywhereVersion")

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional["type_defs.EKSOnDeviceServiceConfigurationTypeDef"],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.EKSOnDeviceServiceConfigurationTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class Ec2AmiResource:
    boto3_raw_data: "type_defs.Ec2AmiResourceTypeDef" = dataclasses.field()

    AmiId = field("AmiId")
    SnowballAmiId = field("SnowballAmiId")

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.Ec2AmiResourceTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[T.Iterable["type_defs.Ec2AmiResourceTypeDef"]],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class EventTriggerDefinition:
    boto3_raw_data: "type_defs.EventTriggerDefinitionTypeDef" = dataclasses.field()

    EventResourceARN = field("EventResourceARN")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.EventTriggerDefinitionTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.EventTriggerDefinitionTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class GetJobManifestRequest:
    boto3_raw_data: "type_defs.GetJobManifestRequestTypeDef" = dataclasses.field()

    JobId = field("JobId")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.GetJobManifestRequestTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.GetJobManifestRequestTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class GetJobUnlockCodeRequest:
    boto3_raw_data: "type_defs.GetJobUnlockCodeRequestTypeDef" = dataclasses.field()

    JobId = field("JobId")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.GetJobUnlockCodeRequestTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.GetJobUnlockCodeRequestTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class GetSoftwareUpdatesRequest:
    boto3_raw_data: "type_defs.GetSoftwareUpdatesRequestTypeDef" = dataclasses.field()

    JobId = field("JobId")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.GetSoftwareUpdatesRequestTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.GetSoftwareUpdatesRequestTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class INDTaxDocuments:
    boto3_raw_data: "type_defs.INDTaxDocumentsTypeDef" = dataclasses.field()

    GSTIN = field("GSTIN")

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.INDTaxDocumentsTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[T.Iterable["type_defs.INDTaxDocumentsTypeDef"]],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class JobLogs:
    boto3_raw_data: "type_defs.JobLogsTypeDef" = dataclasses.field()

    JobCompletionReportURI = field("JobCompletionReportURI")
    JobSuccessLogURI = field("JobSuccessLogURI")
    JobFailureLogURI = field("JobFailureLogURI")

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.JobLogsTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls, boto3_raw_data_list: T.Optional[T.Iterable["type_defs.JobLogsTypeDef"]]
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class PickupDetailsOutput:
    boto3_raw_data: "type_defs.PickupDetailsOutputTypeDef" = dataclasses.field()

    Name = field("Name")
    PhoneNumber = field("PhoneNumber")
    Email = field("Email")
    IdentificationNumber = field("IdentificationNumber")
    IdentificationExpirationDate = field("IdentificationExpirationDate")
    IdentificationIssuingOrg = field("IdentificationIssuingOrg")
    DevicePickupId = field("DevicePickupId")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.PickupDetailsOutputTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.PickupDetailsOutputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class KeyRange:
    boto3_raw_data: "type_defs.KeyRangeTypeDef" = dataclasses.field()

    BeginMarker = field("BeginMarker")
    EndMarker = field("EndMarker")

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.KeyRangeTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls, boto3_raw_data_list: T.Optional[T.Iterable["type_defs.KeyRangeTypeDef"]]
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListClusterJobsRequest:
    boto3_raw_data: "type_defs.ListClusterJobsRequestTypeDef" = dataclasses.field()

    ClusterId = field("ClusterId")
    MaxResults = field("MaxResults")
    NextToken = field("NextToken")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.ListClusterJobsRequestTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ListClusterJobsRequestTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListClustersRequest:
    boto3_raw_data: "type_defs.ListClustersRequestTypeDef" = dataclasses.field()

    MaxResults = field("MaxResults")
    NextToken = field("NextToken")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.ListClustersRequestTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ListClustersRequestTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListCompatibleImagesRequest:
    boto3_raw_data: "type_defs.ListCompatibleImagesRequestTypeDef" = dataclasses.field()

    MaxResults = field("MaxResults")
    NextToken = field("NextToken")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.ListCompatibleImagesRequestTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ListCompatibleImagesRequestTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListJobsRequest:
    boto3_raw_data: "type_defs.ListJobsRequestTypeDef" = dataclasses.field()

    MaxResults = field("MaxResults")
    NextToken = field("NextToken")

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.ListJobsRequestTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[T.Iterable["type_defs.ListJobsRequestTypeDef"]],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListLongTermPricingRequest:
    boto3_raw_data: "type_defs.ListLongTermPricingRequestTypeDef" = dataclasses.field()

    MaxResults = field("MaxResults")
    NextToken = field("NextToken")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.ListLongTermPricingRequestTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ListLongTermPricingRequestTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class LongTermPricingListEntry:
    boto3_raw_data: "type_defs.LongTermPricingListEntryTypeDef" = dataclasses.field()

    LongTermPricingId = field("LongTermPricingId")
    LongTermPricingEndDate = field("LongTermPricingEndDate")
    LongTermPricingStartDate = field("LongTermPricingStartDate")
    LongTermPricingType = field("LongTermPricingType")
    CurrentActiveJob = field("CurrentActiveJob")
    ReplacementJob = field("ReplacementJob")
    IsLongTermPricingAutoRenew = field("IsLongTermPricingAutoRenew")
    LongTermPricingStatus = field("LongTermPricingStatus")
    SnowballType = field("SnowballType")
    JobIds = field("JobIds")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.LongTermPricingListEntryTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.LongTermPricingListEntryTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListPickupLocationsRequest:
    boto3_raw_data: "type_defs.ListPickupLocationsRequestTypeDef" = dataclasses.field()

    MaxResults = field("MaxResults")
    NextToken = field("NextToken")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.ListPickupLocationsRequestTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ListPickupLocationsRequestTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class NFSOnDeviceServiceConfiguration:
    boto3_raw_data: "type_defs.NFSOnDeviceServiceConfigurationTypeDef" = (
        dataclasses.field()
    )

    StorageLimit = field("StorageLimit")
    StorageUnit = field("StorageUnit")

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional["type_defs.NFSOnDeviceServiceConfigurationTypeDef"],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.NFSOnDeviceServiceConfigurationTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class Notification:
    boto3_raw_data: "type_defs.NotificationTypeDef" = dataclasses.field()

    SnsTopicARN = field("SnsTopicARN")
    JobStatesToNotify = field("JobStatesToNotify")
    NotifyAll = field("NotifyAll")
    DevicePickupSnsTopicARN = field("DevicePickupSnsTopicARN")

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.NotificationTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[T.Iterable["type_defs.NotificationTypeDef"]],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class S3OnDeviceServiceConfiguration:
    boto3_raw_data: "type_defs.S3OnDeviceServiceConfigurationTypeDef" = (
        dataclasses.field()
    )

    StorageLimit = field("StorageLimit")
    StorageUnit = field("StorageUnit")
    ServiceSize = field("ServiceSize")
    FaultTolerance = field("FaultTolerance")

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional["type_defs.S3OnDeviceServiceConfigurationTypeDef"],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.S3OnDeviceServiceConfigurationTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class TGWOnDeviceServiceConfiguration:
    boto3_raw_data: "type_defs.TGWOnDeviceServiceConfigurationTypeDef" = (
        dataclasses.field()
    )

    StorageLimit = field("StorageLimit")
    StorageUnit = field("StorageUnit")

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional["type_defs.TGWOnDeviceServiceConfigurationTypeDef"],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.TGWOnDeviceServiceConfigurationTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class TargetOnDeviceService:
    boto3_raw_data: "type_defs.TargetOnDeviceServiceTypeDef" = dataclasses.field()

    ServiceName = field("ServiceName")
    TransferOption = field("TransferOption")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.TargetOnDeviceServiceTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.TargetOnDeviceServiceTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class Shipment:
    boto3_raw_data: "type_defs.ShipmentTypeDef" = dataclasses.field()

    Status = field("Status")
    TrackingNumber = field("TrackingNumber")

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.ShipmentTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls, boto3_raw_data_list: T.Optional[T.Iterable["type_defs.ShipmentTypeDef"]]
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class WirelessConnection:
    boto3_raw_data: "type_defs.WirelessConnectionTypeDef" = dataclasses.field()

    IsWifiEnabled = field("IsWifiEnabled")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.WirelessConnectionTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.WirelessConnectionTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class UpdateJobShipmentStateRequest:
    boto3_raw_data: "type_defs.UpdateJobShipmentStateRequestTypeDef" = (
        dataclasses.field()
    )

    JobId = field("JobId")
    ShipmentState = field("ShipmentState")

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional["type_defs.UpdateJobShipmentStateRequestTypeDef"],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.UpdateJobShipmentStateRequestTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class UpdateLongTermPricingRequest:
    boto3_raw_data: "type_defs.UpdateLongTermPricingRequestTypeDef" = (
        dataclasses.field()
    )

    LongTermPricingId = field("LongTermPricingId")
    ReplacementJob = field("ReplacementJob")
    IsLongTermPricingAutoRenew = field("IsLongTermPricingAutoRenew")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.UpdateLongTermPricingRequestTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.UpdateLongTermPricingRequestTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class CreateAddressRequest:
    boto3_raw_data: "type_defs.CreateAddressRequestTypeDef" = dataclasses.field()

    @cached_property
    def Address(self):  # pragma: no cover
        return Address.make_one(self.boto3_raw_data["Address"])

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.CreateAddressRequestTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.CreateAddressRequestTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class CreateAddressResult:
    boto3_raw_data: "type_defs.CreateAddressResultTypeDef" = dataclasses.field()

    AddressId = field("AddressId")

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.CreateAddressResultTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.CreateAddressResultTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class CreateJobResult:
    boto3_raw_data: "type_defs.CreateJobResultTypeDef" = dataclasses.field()

    JobId = field("JobId")

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.CreateJobResultTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[T.Iterable["type_defs.CreateJobResultTypeDef"]],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class CreateLongTermPricingResult:
    boto3_raw_data: "type_defs.CreateLongTermPricingResultTypeDef" = dataclasses.field()

    LongTermPricingId = field("LongTermPricingId")

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.CreateLongTermPricingResultTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.CreateLongTermPricingResultTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class CreateReturnShippingLabelResult:
    boto3_raw_data: "type_defs.CreateReturnShippingLabelResultTypeDef" = (
        dataclasses.field()
    )

    Status = field("Status")

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional["type_defs.CreateReturnShippingLabelResultTypeDef"],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.CreateReturnShippingLabelResultTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class DescribeAddressResult:
    boto3_raw_data: "type_defs.DescribeAddressResultTypeDef" = dataclasses.field()

    @cached_property
    def Address(self):  # pragma: no cover
        return Address.make_one(self.boto3_raw_data["Address"])

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.DescribeAddressResultTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.DescribeAddressResultTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class DescribeAddressesResult:
    boto3_raw_data: "type_defs.DescribeAddressesResultTypeDef" = dataclasses.field()

    @cached_property
    def Addresses(self):  # pragma: no cover
        return Address.make_many(self.boto3_raw_data["Addresses"])

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    NextToken = field("NextToken")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.DescribeAddressesResultTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.DescribeAddressesResultTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class DescribeReturnShippingLabelResult:
    boto3_raw_data: "type_defs.DescribeReturnShippingLabelResultTypeDef" = (
        dataclasses.field()
    )

    Status = field("Status")
    ExpirationDate = field("ExpirationDate")
    ReturnShippingLabelURI = field("ReturnShippingLabelURI")

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.DescribeReturnShippingLabelResultTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.DescribeReturnShippingLabelResultTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class GetJobManifestResult:
    boto3_raw_data: "type_defs.GetJobManifestResultTypeDef" = dataclasses.field()

    ManifestURI = field("ManifestURI")

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.GetJobManifestResultTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.GetJobManifestResultTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class GetJobUnlockCodeResult:
    boto3_raw_data: "type_defs.GetJobUnlockCodeResultTypeDef" = dataclasses.field()

    UnlockCode = field("UnlockCode")

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.GetJobUnlockCodeResultTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.GetJobUnlockCodeResultTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class GetSnowballUsageResult:
    boto3_raw_data: "type_defs.GetSnowballUsageResultTypeDef" = dataclasses.field()

    SnowballLimit = field("SnowballLimit")
    SnowballsInUse = field("SnowballsInUse")

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.GetSnowballUsageResultTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.GetSnowballUsageResultTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class GetSoftwareUpdatesResult:
    boto3_raw_data: "type_defs.GetSoftwareUpdatesResultTypeDef" = dataclasses.field()

    UpdatesURI = field("UpdatesURI")

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.GetSoftwareUpdatesResultTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.GetSoftwareUpdatesResultTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListClustersResult:
    boto3_raw_data: "type_defs.ListClustersResultTypeDef" = dataclasses.field()

    @cached_property
    def ClusterListEntries(self):  # pragma: no cover
        return ClusterListEntry.make_many(self.boto3_raw_data["ClusterListEntries"])

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    NextToken = field("NextToken")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.ListClustersResultTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ListClustersResultTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListCompatibleImagesResult:
    boto3_raw_data: "type_defs.ListCompatibleImagesResultTypeDef" = dataclasses.field()

    @cached_property
    def CompatibleImages(self):  # pragma: no cover
        return CompatibleImage.make_many(self.boto3_raw_data["CompatibleImages"])

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    NextToken = field("NextToken")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.ListCompatibleImagesResultTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ListCompatibleImagesResultTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListPickupLocationsResult:
    boto3_raw_data: "type_defs.ListPickupLocationsResultTypeDef" = dataclasses.field()

    @cached_property
    def Addresses(self):  # pragma: no cover
        return Address.make_many(self.boto3_raw_data["Addresses"])

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    NextToken = field("NextToken")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.ListPickupLocationsResultTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ListPickupLocationsResultTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class CreateClusterResult:
    boto3_raw_data: "type_defs.CreateClusterResultTypeDef" = dataclasses.field()

    ClusterId = field("ClusterId")

    @cached_property
    def JobListEntries(self):  # pragma: no cover
        return JobListEntry.make_many(self.boto3_raw_data["JobListEntries"])

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.CreateClusterResultTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.CreateClusterResultTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListClusterJobsResult:
    boto3_raw_data: "type_defs.ListClusterJobsResultTypeDef" = dataclasses.field()

    @cached_property
    def JobListEntries(self):  # pragma: no cover
        return JobListEntry.make_many(self.boto3_raw_data["JobListEntries"])

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    NextToken = field("NextToken")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.ListClusterJobsResultTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ListClusterJobsResultTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListJobsResult:
    boto3_raw_data: "type_defs.ListJobsResultTypeDef" = dataclasses.field()

    @cached_property
    def JobListEntries(self):  # pragma: no cover
        return JobListEntry.make_many(self.boto3_raw_data["JobListEntries"])

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    NextToken = field("NextToken")

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.ListJobsResultTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[T.Iterable["type_defs.ListJobsResultTypeDef"]],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class DependentService:
    boto3_raw_data: "type_defs.DependentServiceTypeDef" = dataclasses.field()

    ServiceName = field("ServiceName")

    @cached_property
    def ServiceVersion(self):  # pragma: no cover
        return ServiceVersion.make_one(self.boto3_raw_data["ServiceVersion"])

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.DependentServiceTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.DependentServiceTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class DescribeAddressesRequestPaginate:
    boto3_raw_data: "type_defs.DescribeAddressesRequestPaginateTypeDef" = (
        dataclasses.field()
    )

    @cached_property
    def PaginationConfig(self):  # pragma: no cover
        return PaginatorConfig.make_one(self.boto3_raw_data["PaginationConfig"])

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional["type_defs.DescribeAddressesRequestPaginateTypeDef"],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.DescribeAddressesRequestPaginateTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListClusterJobsRequestPaginate:
    boto3_raw_data: "type_defs.ListClusterJobsRequestPaginateTypeDef" = (
        dataclasses.field()
    )

    ClusterId = field("ClusterId")

    @cached_property
    def PaginationConfig(self):  # pragma: no cover
        return PaginatorConfig.make_one(self.boto3_raw_data["PaginationConfig"])

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional["type_defs.ListClusterJobsRequestPaginateTypeDef"],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ListClusterJobsRequestPaginateTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListClustersRequestPaginate:
    boto3_raw_data: "type_defs.ListClustersRequestPaginateTypeDef" = dataclasses.field()

    @cached_property
    def PaginationConfig(self):  # pragma: no cover
        return PaginatorConfig.make_one(self.boto3_raw_data["PaginationConfig"])

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.ListClustersRequestPaginateTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ListClustersRequestPaginateTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListCompatibleImagesRequestPaginate:
    boto3_raw_data: "type_defs.ListCompatibleImagesRequestPaginateTypeDef" = (
        dataclasses.field()
    )

    @cached_property
    def PaginationConfig(self):  # pragma: no cover
        return PaginatorConfig.make_one(self.boto3_raw_data["PaginationConfig"])

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.ListCompatibleImagesRequestPaginateTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ListCompatibleImagesRequestPaginateTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListJobsRequestPaginate:
    boto3_raw_data: "type_defs.ListJobsRequestPaginateTypeDef" = dataclasses.field()

    @cached_property
    def PaginationConfig(self):  # pragma: no cover
        return PaginatorConfig.make_one(self.boto3_raw_data["PaginationConfig"])

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.ListJobsRequestPaginateTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ListJobsRequestPaginateTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListLongTermPricingRequestPaginate:
    boto3_raw_data: "type_defs.ListLongTermPricingRequestPaginateTypeDef" = (
        dataclasses.field()
    )

    @cached_property
    def PaginationConfig(self):  # pragma: no cover
        return PaginatorConfig.make_one(self.boto3_raw_data["PaginationConfig"])

    @classmethod
    def make_one(
        cls,
        boto3_raw_data: T.Optional[
            "type_defs.ListLongTermPricingRequestPaginateTypeDef"
        ],
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ListLongTermPricingRequestPaginateTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class LambdaResourceOutput:
    boto3_raw_data: "type_defs.LambdaResourceOutputTypeDef" = dataclasses.field()

    LambdaArn = field("LambdaArn")

    @cached_property
    def EventTriggers(self):  # pragma: no cover
        return EventTriggerDefinition.make_many(self.boto3_raw_data["EventTriggers"])

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.LambdaResourceOutputTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.LambdaResourceOutputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class LambdaResource:
    boto3_raw_data: "type_defs.LambdaResourceTypeDef" = dataclasses.field()

    LambdaArn = field("LambdaArn")

    @cached_property
    def EventTriggers(self):  # pragma: no cover
        return EventTriggerDefinition.make_many(self.boto3_raw_data["EventTriggers"])

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.LambdaResourceTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[T.Iterable["type_defs.LambdaResourceTypeDef"]],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class TaxDocuments:
    boto3_raw_data: "type_defs.TaxDocumentsTypeDef" = dataclasses.field()

    @cached_property
    def IND(self):  # pragma: no cover
        return INDTaxDocuments.make_one(self.boto3_raw_data["IND"])

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.TaxDocumentsTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[T.Iterable["type_defs.TaxDocumentsTypeDef"]],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListLongTermPricingResult:
    boto3_raw_data: "type_defs.ListLongTermPricingResultTypeDef" = dataclasses.field()

    @cached_property
    def LongTermPricingEntries(self):  # pragma: no cover
        return LongTermPricingListEntry.make_many(
            self.boto3_raw_data["LongTermPricingEntries"]
        )

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    NextToken = field("NextToken")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.ListLongTermPricingResultTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ListLongTermPricingResultTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class OnDeviceServiceConfiguration:
    boto3_raw_data: "type_defs.OnDeviceServiceConfigurationTypeDef" = (
        dataclasses.field()
    )

    @cached_property
    def NFSOnDeviceService(self):  # pragma: no cover
        return NFSOnDeviceServiceConfiguration.make_one(
            self.boto3_raw_data["NFSOnDeviceService"]
        )

    @cached_property
    def TGWOnDeviceService(self):  # pragma: no cover
        return TGWOnDeviceServiceConfiguration.make_one(
            self.boto3_raw_data["TGWOnDeviceService"]
        )

    @cached_property
    def EKSOnDeviceService(self):  # pragma: no cover
        return EKSOnDeviceServiceConfiguration.make_one(
            self.boto3_raw_data["EKSOnDeviceService"]
        )

    @cached_property
    def S3OnDeviceService(self):  # pragma: no cover
        return S3OnDeviceServiceConfiguration.make_one(
            self.boto3_raw_data["S3OnDeviceService"]
        )

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.OnDeviceServiceConfigurationTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.OnDeviceServiceConfigurationTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class PickupDetails:
    boto3_raw_data: "type_defs.PickupDetailsTypeDef" = dataclasses.field()

    Name = field("Name")
    PhoneNumber = field("PhoneNumber")
    Email = field("Email")
    IdentificationNumber = field("IdentificationNumber")
    IdentificationExpirationDate = field("IdentificationExpirationDate")
    IdentificationIssuingOrg = field("IdentificationIssuingOrg")
    DevicePickupId = field("DevicePickupId")

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.PickupDetailsTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[T.Iterable["type_defs.PickupDetailsTypeDef"]],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class S3ResourceOutput:
    boto3_raw_data: "type_defs.S3ResourceOutputTypeDef" = dataclasses.field()

    BucketArn = field("BucketArn")

    @cached_property
    def KeyRange(self):  # pragma: no cover
        return KeyRange.make_one(self.boto3_raw_data["KeyRange"])

    @cached_property
    def TargetOnDeviceServices(self):  # pragma: no cover
        return TargetOnDeviceService.make_many(
            self.boto3_raw_data["TargetOnDeviceServices"]
        )

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.S3ResourceOutputTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.S3ResourceOutputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class S3Resource:
    boto3_raw_data: "type_defs.S3ResourceTypeDef" = dataclasses.field()

    BucketArn = field("BucketArn")

    @cached_property
    def KeyRange(self):  # pragma: no cover
        return KeyRange.make_one(self.boto3_raw_data["KeyRange"])

    @cached_property
    def TargetOnDeviceServices(self):  # pragma: no cover
        return TargetOnDeviceService.make_many(
            self.boto3_raw_data["TargetOnDeviceServices"]
        )

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.S3ResourceTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls, boto3_raw_data_list: T.Optional[T.Iterable["type_defs.S3ResourceTypeDef"]]
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ShippingDetails:
    boto3_raw_data: "type_defs.ShippingDetailsTypeDef" = dataclasses.field()

    ShippingOption = field("ShippingOption")

    @cached_property
    def InboundShipment(self):  # pragma: no cover
        return Shipment.make_one(self.boto3_raw_data["InboundShipment"])

    @cached_property
    def OutboundShipment(self):  # pragma: no cover
        return Shipment.make_one(self.boto3_raw_data["OutboundShipment"])

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.ShippingDetailsTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[T.Iterable["type_defs.ShippingDetailsTypeDef"]],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class SnowconeDeviceConfiguration:
    boto3_raw_data: "type_defs.SnowconeDeviceConfigurationTypeDef" = dataclasses.field()

    @cached_property
    def WirelessConnection(self):  # pragma: no cover
        return WirelessConnection.make_one(self.boto3_raw_data["WirelessConnection"])

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.SnowconeDeviceConfigurationTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.SnowconeDeviceConfigurationTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListServiceVersionsRequest:
    boto3_raw_data: "type_defs.ListServiceVersionsRequestTypeDef" = dataclasses.field()

    ServiceName = field("ServiceName")

    @cached_property
    def DependentServices(self):  # pragma: no cover
        return DependentService.make_many(self.boto3_raw_data["DependentServices"])

    MaxResults = field("MaxResults")
    NextToken = field("NextToken")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.ListServiceVersionsRequestTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ListServiceVersionsRequestTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ListServiceVersionsResult:
    boto3_raw_data: "type_defs.ListServiceVersionsResultTypeDef" = dataclasses.field()

    @cached_property
    def ServiceVersions(self):  # pragma: no cover
        return ServiceVersion.make_many(self.boto3_raw_data["ServiceVersions"])

    ServiceName = field("ServiceName")

    @cached_property
    def DependentServices(self):  # pragma: no cover
        return DependentService.make_many(self.boto3_raw_data["DependentServices"])

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    NextToken = field("NextToken")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.ListServiceVersionsResultTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.ListServiceVersionsResultTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class JobResourceOutput:
    boto3_raw_data: "type_defs.JobResourceOutputTypeDef" = dataclasses.field()

    @cached_property
    def S3Resources(self):  # pragma: no cover
        return S3ResourceOutput.make_many(self.boto3_raw_data["S3Resources"])

    @cached_property
    def LambdaResources(self):  # pragma: no cover
        return LambdaResourceOutput.make_many(self.boto3_raw_data["LambdaResources"])

    @cached_property
    def Ec2AmiResources(self):  # pragma: no cover
        return Ec2AmiResource.make_many(self.boto3_raw_data["Ec2AmiResources"])

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.JobResourceOutputTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.JobResourceOutputTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class JobResource:
    boto3_raw_data: "type_defs.JobResourceTypeDef" = dataclasses.field()

    @cached_property
    def S3Resources(self):  # pragma: no cover
        return S3Resource.make_many(self.boto3_raw_data["S3Resources"])

    @cached_property
    def LambdaResources(self):  # pragma: no cover
        return LambdaResource.make_many(self.boto3_raw_data["LambdaResources"])

    @cached_property
    def Ec2AmiResources(self):  # pragma: no cover
        return Ec2AmiResource.make_many(self.boto3_raw_data["Ec2AmiResources"])

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.JobResourceTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls, boto3_raw_data_list: T.Optional[T.Iterable["type_defs.JobResourceTypeDef"]]
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class DeviceConfiguration:
    boto3_raw_data: "type_defs.DeviceConfigurationTypeDef" = dataclasses.field()

    @cached_property
    def SnowconeDeviceConfiguration(self):  # pragma: no cover
        return SnowconeDeviceConfiguration.make_one(
            self.boto3_raw_data["SnowconeDeviceConfiguration"]
        )

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.DeviceConfigurationTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.DeviceConfigurationTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class ClusterMetadata:
    boto3_raw_data: "type_defs.ClusterMetadataTypeDef" = dataclasses.field()

    ClusterId = field("ClusterId")
    Description = field("Description")
    KmsKeyARN = field("KmsKeyARN")
    RoleARN = field("RoleARN")
    ClusterState = field("ClusterState")
    JobType = field("JobType")
    SnowballType = field("SnowballType")
    CreationDate = field("CreationDate")

    @cached_property
    def Resources(self):  # pragma: no cover
        return JobResourceOutput.make_one(self.boto3_raw_data["Resources"])

    AddressId = field("AddressId")
    ShippingOption = field("ShippingOption")

    @cached_property
    def Notification(self):  # pragma: no cover
        return NotificationOutput.make_one(self.boto3_raw_data["Notification"])

    ForwardingAddressId = field("ForwardingAddressId")

    @cached_property
    def TaxDocuments(self):  # pragma: no cover
        return TaxDocuments.make_one(self.boto3_raw_data["TaxDocuments"])

    @cached_property
    def OnDeviceServiceConfiguration(self):  # pragma: no cover
        return OnDeviceServiceConfiguration.make_one(
            self.boto3_raw_data["OnDeviceServiceConfiguration"]
        )

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.ClusterMetadataTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[T.Iterable["type_defs.ClusterMetadataTypeDef"]],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class JobMetadata:
    boto3_raw_data: "type_defs.JobMetadataTypeDef" = dataclasses.field()

    JobId = field("JobId")
    JobState = field("JobState")
    JobType = field("JobType")
    SnowballType = field("SnowballType")
    CreationDate = field("CreationDate")

    @cached_property
    def Resources(self):  # pragma: no cover
        return JobResourceOutput.make_one(self.boto3_raw_data["Resources"])

    Description = field("Description")
    KmsKeyARN = field("KmsKeyARN")
    RoleARN = field("RoleARN")
    AddressId = field("AddressId")

    @cached_property
    def ShippingDetails(self):  # pragma: no cover
        return ShippingDetails.make_one(self.boto3_raw_data["ShippingDetails"])

    SnowballCapacityPreference = field("SnowballCapacityPreference")

    @cached_property
    def Notification(self):  # pragma: no cover
        return NotificationOutput.make_one(self.boto3_raw_data["Notification"])

    @cached_property
    def DataTransferProgress(self):  # pragma: no cover
        return DataTransfer.make_one(self.boto3_raw_data["DataTransferProgress"])

    @cached_property
    def JobLogInfo(self):  # pragma: no cover
        return JobLogs.make_one(self.boto3_raw_data["JobLogInfo"])

    ClusterId = field("ClusterId")
    ForwardingAddressId = field("ForwardingAddressId")

    @cached_property
    def TaxDocuments(self):  # pragma: no cover
        return TaxDocuments.make_one(self.boto3_raw_data["TaxDocuments"])

    @cached_property
    def DeviceConfiguration(self):  # pragma: no cover
        return DeviceConfiguration.make_one(self.boto3_raw_data["DeviceConfiguration"])

    RemoteManagement = field("RemoteManagement")
    LongTermPricingId = field("LongTermPricingId")

    @cached_property
    def OnDeviceServiceConfiguration(self):  # pragma: no cover
        return OnDeviceServiceConfiguration.make_one(
            self.boto3_raw_data["OnDeviceServiceConfiguration"]
        )

    ImpactLevel = field("ImpactLevel")

    @cached_property
    def PickupDetails(self):  # pragma: no cover
        return PickupDetailsOutput.make_one(self.boto3_raw_data["PickupDetails"])

    SnowballId = field("SnowballId")

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.JobMetadataTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls, boto3_raw_data_list: T.Optional[T.Iterable["type_defs.JobMetadataTypeDef"]]
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class DescribeClusterResult:
    boto3_raw_data: "type_defs.DescribeClusterResultTypeDef" = dataclasses.field()

    @cached_property
    def ClusterMetadata(self):  # pragma: no cover
        return ClusterMetadata.make_one(self.boto3_raw_data["ClusterMetadata"])

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.DescribeClusterResultTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.DescribeClusterResultTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class CreateClusterRequest:
    boto3_raw_data: "type_defs.CreateClusterRequestTypeDef" = dataclasses.field()

    JobType = field("JobType")
    AddressId = field("AddressId")
    SnowballType = field("SnowballType")
    ShippingOption = field("ShippingOption")
    Resources = field("Resources")

    @cached_property
    def OnDeviceServiceConfiguration(self):  # pragma: no cover
        return OnDeviceServiceConfiguration.make_one(
            self.boto3_raw_data["OnDeviceServiceConfiguration"]
        )

    Description = field("Description")
    KmsKeyARN = field("KmsKeyARN")
    RoleARN = field("RoleARN")
    Notification = field("Notification")
    ForwardingAddressId = field("ForwardingAddressId")

    @cached_property
    def TaxDocuments(self):  # pragma: no cover
        return TaxDocuments.make_one(self.boto3_raw_data["TaxDocuments"])

    RemoteManagement = field("RemoteManagement")
    InitialClusterSize = field("InitialClusterSize")
    ForceCreateJobs = field("ForceCreateJobs")
    LongTermPricingIds = field("LongTermPricingIds")
    SnowballCapacityPreference = field("SnowballCapacityPreference")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.CreateClusterRequestTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.CreateClusterRequestTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class CreateJobRequest:
    boto3_raw_data: "type_defs.CreateJobRequestTypeDef" = dataclasses.field()

    JobType = field("JobType")
    Resources = field("Resources")

    @cached_property
    def OnDeviceServiceConfiguration(self):  # pragma: no cover
        return OnDeviceServiceConfiguration.make_one(
            self.boto3_raw_data["OnDeviceServiceConfiguration"]
        )

    Description = field("Description")
    AddressId = field("AddressId")
    KmsKeyARN = field("KmsKeyARN")
    RoleARN = field("RoleARN")
    SnowballCapacityPreference = field("SnowballCapacityPreference")
    ShippingOption = field("ShippingOption")
    Notification = field("Notification")
    ClusterId = field("ClusterId")
    SnowballType = field("SnowballType")
    ForwardingAddressId = field("ForwardingAddressId")

    @cached_property
    def TaxDocuments(self):  # pragma: no cover
        return TaxDocuments.make_one(self.boto3_raw_data["TaxDocuments"])

    @cached_property
    def DeviceConfiguration(self):  # pragma: no cover
        return DeviceConfiguration.make_one(self.boto3_raw_data["DeviceConfiguration"])

    RemoteManagement = field("RemoteManagement")
    LongTermPricingId = field("LongTermPricingId")
    ImpactLevel = field("ImpactLevel")
    PickupDetails = field("PickupDetails")

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.CreateJobRequestTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.CreateJobRequestTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class UpdateClusterRequest:
    boto3_raw_data: "type_defs.UpdateClusterRequestTypeDef" = dataclasses.field()

    ClusterId = field("ClusterId")
    RoleARN = field("RoleARN")
    Description = field("Description")
    Resources = field("Resources")

    @cached_property
    def OnDeviceServiceConfiguration(self):  # pragma: no cover
        return OnDeviceServiceConfiguration.make_one(
            self.boto3_raw_data["OnDeviceServiceConfiguration"]
        )

    AddressId = field("AddressId")
    ShippingOption = field("ShippingOption")
    Notification = field("Notification")
    ForwardingAddressId = field("ForwardingAddressId")

    @classmethod
    def make_one(
        cls, boto3_raw_data: T.Optional["type_defs.UpdateClusterRequestTypeDef"]
    ):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.UpdateClusterRequestTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class UpdateJobRequest:
    boto3_raw_data: "type_defs.UpdateJobRequestTypeDef" = dataclasses.field()

    JobId = field("JobId")
    RoleARN = field("RoleARN")
    Notification = field("Notification")
    Resources = field("Resources")

    @cached_property
    def OnDeviceServiceConfiguration(self):  # pragma: no cover
        return OnDeviceServiceConfiguration.make_one(
            self.boto3_raw_data["OnDeviceServiceConfiguration"]
        )

    AddressId = field("AddressId")
    ShippingOption = field("ShippingOption")
    Description = field("Description")
    SnowballCapacityPreference = field("SnowballCapacityPreference")
    ForwardingAddressId = field("ForwardingAddressId")
    PickupDetails = field("PickupDetails")

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.UpdateJobRequestTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.UpdateJobRequestTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]


@dataclasses.dataclass(frozen=True)
class DescribeJobResult:
    boto3_raw_data: "type_defs.DescribeJobResultTypeDef" = dataclasses.field()

    @cached_property
    def JobMetadata(self):  # pragma: no cover
        return JobMetadata.make_one(self.boto3_raw_data["JobMetadata"])

    @cached_property
    def SubJobMetadata(self):  # pragma: no cover
        return JobMetadata.make_many(self.boto3_raw_data["SubJobMetadata"])

    @cached_property
    def ResponseMetadata(self):  # pragma: no cover
        return ResponseMetadata.make_one(self.boto3_raw_data["ResponseMetadata"])

    @classmethod
    def make_one(cls, boto3_raw_data: T.Optional["type_defs.DescribeJobResultTypeDef"]):
        if boto3_raw_data is None:
            return None
        return cls(boto3_raw_data=boto3_raw_data)

    @classmethod
    def make_many(
        cls,
        boto3_raw_data_list: T.Optional[
            T.Iterable["type_defs.DescribeJobResultTypeDef"]
        ],
    ):
        if boto3_raw_data_list is None:
            return None
        return [
            cls(boto3_raw_data=boto3_raw_data) for boto3_raw_data in boto3_raw_data_list
        ]
