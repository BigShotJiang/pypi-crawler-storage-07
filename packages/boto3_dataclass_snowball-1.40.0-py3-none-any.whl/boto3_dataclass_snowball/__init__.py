# -*- coding: utf-8 -*-

from .caster import snowball_caster

caster = snowball_caster

__version__ = "1.40.0"