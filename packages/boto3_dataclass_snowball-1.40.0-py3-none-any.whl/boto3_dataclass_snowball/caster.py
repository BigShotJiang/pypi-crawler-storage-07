# -*- coding: utf-8 -*-

import typing as T

from . import type_defs as dc_td

if T.TYPE_CHECKING:  # pragma: no cover
    from mypy_boto3_snowball import type_defs as bs_td


class SNOWBALLCaster:

    def create_address(
        self,
        res: "bs_td.CreateAddressResultTypeDef",
    ) -> "dc_td.CreateAddressResult":
        return dc_td.CreateAddressResult.make_one(res)

    def create_cluster(
        self,
        res: "bs_td.CreateClusterResultTypeDef",
    ) -> "dc_td.CreateClusterResult":
        return dc_td.CreateClusterResult.make_one(res)

    def create_job(
        self,
        res: "bs_td.CreateJobResultTypeDef",
    ) -> "dc_td.CreateJobResult":
        return dc_td.CreateJobResult.make_one(res)

    def create_long_term_pricing(
        self,
        res: "bs_td.CreateLongTermPricingResultTypeDef",
    ) -> "dc_td.CreateLongTermPricingResult":
        return dc_td.CreateLongTermPricingResult.make_one(res)

    def create_return_shipping_label(
        self,
        res: "bs_td.CreateReturnShippingLabelResultTypeDef",
    ) -> "dc_td.CreateReturnShippingLabelResult":
        return dc_td.CreateReturnShippingLabelResult.make_one(res)

    def describe_address(
        self,
        res: "bs_td.DescribeAddressResultTypeDef",
    ) -> "dc_td.DescribeAddressResult":
        return dc_td.DescribeAddressResult.make_one(res)

    def describe_addresses(
        self,
        res: "bs_td.DescribeAddressesResultTypeDef",
    ) -> "dc_td.DescribeAddressesResult":
        return dc_td.DescribeAddressesResult.make_one(res)

    def describe_cluster(
        self,
        res: "bs_td.DescribeClusterResultTypeDef",
    ) -> "dc_td.DescribeClusterResult":
        return dc_td.DescribeClusterResult.make_one(res)

    def describe_job(
        self,
        res: "bs_td.DescribeJobResultTypeDef",
    ) -> "dc_td.DescribeJobResult":
        return dc_td.DescribeJobResult.make_one(res)

    def describe_return_shipping_label(
        self,
        res: "bs_td.DescribeReturnShippingLabelResultTypeDef",
    ) -> "dc_td.DescribeReturnShippingLabelResult":
        return dc_td.DescribeReturnShippingLabelResult.make_one(res)

    def get_job_manifest(
        self,
        res: "bs_td.GetJobManifestResultTypeDef",
    ) -> "dc_td.GetJobManifestResult":
        return dc_td.GetJobManifestResult.make_one(res)

    def get_job_unlock_code(
        self,
        res: "bs_td.GetJobUnlockCodeResultTypeDef",
    ) -> "dc_td.GetJobUnlockCodeResult":
        return dc_td.GetJobUnlockCodeResult.make_one(res)

    def get_snowball_usage(
        self,
        res: "bs_td.GetSnowballUsageResultTypeDef",
    ) -> "dc_td.GetSnowballUsageResult":
        return dc_td.GetSnowballUsageResult.make_one(res)

    def get_software_updates(
        self,
        res: "bs_td.GetSoftwareUpdatesResultTypeDef",
    ) -> "dc_td.GetSoftwareUpdatesResult":
        return dc_td.GetSoftwareUpdatesResult.make_one(res)

    def list_cluster_jobs(
        self,
        res: "bs_td.ListClusterJobsResultTypeDef",
    ) -> "dc_td.ListClusterJobsResult":
        return dc_td.ListClusterJobsResult.make_one(res)

    def list_clusters(
        self,
        res: "bs_td.ListClustersResultTypeDef",
    ) -> "dc_td.ListClustersResult":
        return dc_td.ListClustersResult.make_one(res)

    def list_compatible_images(
        self,
        res: "bs_td.ListCompatibleImagesResultTypeDef",
    ) -> "dc_td.ListCompatibleImagesResult":
        return dc_td.ListCompatibleImagesResult.make_one(res)

    def list_jobs(
        self,
        res: "bs_td.ListJobsResultTypeDef",
    ) -> "dc_td.ListJobsResult":
        return dc_td.ListJobsResult.make_one(res)

    def list_long_term_pricing(
        self,
        res: "bs_td.ListLongTermPricingResultTypeDef",
    ) -> "dc_td.ListLongTermPricingResult":
        return dc_td.ListLongTermPricingResult.make_one(res)

    def list_pickup_locations(
        self,
        res: "bs_td.ListPickupLocationsResultTypeDef",
    ) -> "dc_td.ListPickupLocationsResult":
        return dc_td.ListPickupLocationsResult.make_one(res)

    def list_service_versions(
        self,
        res: "bs_td.ListServiceVersionsResultTypeDef",
    ) -> "dc_td.ListServiceVersionsResult":
        return dc_td.ListServiceVersionsResult.make_one(res)


snowball_caster = SNOWBALLCaster()
