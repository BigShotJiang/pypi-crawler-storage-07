"""CLI module for KITECH Repository."""

from kitech_repository.cli.main import app

__all__ = ["app"]