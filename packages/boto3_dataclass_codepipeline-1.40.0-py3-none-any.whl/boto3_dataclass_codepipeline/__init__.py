# -*- coding: utf-8 -*-

from .caster import codepipeline_caster

caster = codepipeline_caster

__version__ = "1.40.0"