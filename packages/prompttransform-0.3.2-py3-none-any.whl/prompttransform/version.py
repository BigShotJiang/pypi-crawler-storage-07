"""Central version constant for prompttransform.

This mirrors the value exposed in `__init__.__version__`. Update both together
(or better: import from here inside __init__ if future refactor desired).
"""
__version__ = "0.3.2"
