::: workflows.events
    options:
      members:
        - Event
        - InputRequiredEvent
        - HumanResponseEvent
        - StartEvent
        - StopEvent
