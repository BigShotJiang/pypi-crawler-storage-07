"""Scripts for beanahead."""
