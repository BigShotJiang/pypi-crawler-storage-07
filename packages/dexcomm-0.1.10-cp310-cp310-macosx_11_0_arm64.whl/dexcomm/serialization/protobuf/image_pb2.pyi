from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class RGBImage(_message.Message):
    __slots__ = ("type", "height", "width", "data", "timestamp_ns", "encoding")
    class ImageType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        RGB: _ClassVar[RGBImage.ImageType]
        GRAYSCALE: _ClassVar[RGBImage.ImageType]
    RGB: RGBImage.ImageType
    GRAYSCALE: RGBImage.ImageType
    TYPE_FIELD_NUMBER: _ClassVar[int]
    HEIGHT_FIELD_NUMBER: _ClassVar[int]
    WIDTH_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_NS_FIELD_NUMBER: _ClassVar[int]
    ENCODING_FIELD_NUMBER: _ClassVar[int]
    type: RGBImage.ImageType
    height: int
    width: int
    data: bytes
    timestamp_ns: int
    encoding: str
    def __init__(self, type: _Optional[_Union[RGBImage.ImageType, str]] = ..., height: _Optional[int] = ..., width: _Optional[int] = ..., data: _Optional[bytes] = ..., timestamp_ns: _Optional[int] = ..., encoding: _Optional[str] = ...) -> None: ...

class DepthImage(_message.Message):
    __slots__ = ("height", "width", "scale", "data", "timestamp_ns", "encoding")
    HEIGHT_FIELD_NUMBER: _ClassVar[int]
    WIDTH_FIELD_NUMBER: _ClassVar[int]
    SCALE_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_NS_FIELD_NUMBER: _ClassVar[int]
    ENCODING_FIELD_NUMBER: _ClassVar[int]
    height: int
    width: int
    scale: float
    data: bytes
    timestamp_ns: int
    encoding: str
    def __init__(self, height: _Optional[int] = ..., width: _Optional[int] = ..., scale: _Optional[float] = ..., data: _Optional[bytes] = ..., timestamp_ns: _Optional[int] = ..., encoding: _Optional[str] = ...) -> None: ...

class Image(_message.Message):
    __slots__ = ("rgb", "depth")
    RGB_FIELD_NUMBER: _ClassVar[int]
    DEPTH_FIELD_NUMBER: _ClassVar[int]
    rgb: RGBImage
    depth: DepthImage
    def __init__(self, rgb: _Optional[_Union[RGBImage, _Mapping]] = ..., depth: _Optional[_Union[DepthImage, _Mapping]] = ...) -> None: ...

class ImageBatch(_message.Message):
    __slots__ = ("images",)
    IMAGES_FIELD_NUMBER: _ClassVar[int]
    images: _containers.RepeatedCompositeFieldContainer[Image]
    def __init__(self, images: _Optional[_Iterable[_Union[Image, _Mapping]]] = ...) -> None: ...
