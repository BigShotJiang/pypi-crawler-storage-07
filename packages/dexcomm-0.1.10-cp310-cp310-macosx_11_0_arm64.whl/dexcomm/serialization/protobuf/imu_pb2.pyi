from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class IMUData(_message.Message):
    __slots__ = ("acc", "gyro", "quat", "mag", "timestamp_ns")
    ACC_FIELD_NUMBER: _ClassVar[int]
    GYRO_FIELD_NUMBER: _ClassVar[int]
    QUAT_FIELD_NUMBER: _ClassVar[int]
    MAG_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_NS_FIELD_NUMBER: _ClassVar[int]
    acc: _containers.RepeatedScalarFieldContainer[float]
    gyro: _containers.RepeatedScalarFieldContainer[float]
    quat: _containers.RepeatedScalarFieldContainer[float]
    mag: _containers.RepeatedScalarFieldContainer[float]
    timestamp_ns: int
    def __init__(self, acc: _Optional[_Iterable[float]] = ..., gyro: _Optional[_Iterable[float]] = ..., quat: _Optional[_Iterable[float]] = ..., mag: _Optional[_Iterable[float]] = ..., timestamp_ns: _Optional[int] = ...) -> None: ...

class IMUBatch(_message.Message):
    __slots__ = ("samples",)
    SAMPLES_FIELD_NUMBER: _ClassVar[int]
    samples: _containers.RepeatedCompositeFieldContainer[IMUData]
    def __init__(self, samples: _Optional[_Iterable[_Union[IMUData, _Mapping]]] = ...) -> None: ...
