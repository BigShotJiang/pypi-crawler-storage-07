# -*- coding: utf-8 -*-

from .caster import codecommit_caster

caster = codecommit_caster

__version__ = "1.40.0"