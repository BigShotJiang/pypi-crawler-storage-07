# Core OSR Calculation Modules
