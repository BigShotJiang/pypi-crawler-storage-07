# OSR Component Calculators
