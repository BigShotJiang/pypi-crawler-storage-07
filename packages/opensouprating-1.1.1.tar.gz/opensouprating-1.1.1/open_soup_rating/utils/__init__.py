# Utility Functions
