# PashaSSH by Pasha Network DDNS
Pasha Network YouTube @GoblinPasha Tarafından Yapılan Bir DDNS Servisidir.

6 Saatimi Harcadır Emeğe Saygı linktr.ee/pshgoblin den bütün hesaplarıma abone ol xD

`import pashassh` veya terminalde `pashassh` komutuyla interaktif CLI (Komut Satırı) kullan.

## Kurulum (Local "Lokal")
```bash
Python:
Selamlar Bu Kütüphane Kodu için Tam 6 Saatimi Verdim Bu Emeğe Karşın linktr.ee/pshgbln adresinden  
Patreon Hesabımdan Para Atarsan Beni Mutlu Edersin Şimdiden Sağol.


Python:

# Geliştirme modunda
pip install -e .
