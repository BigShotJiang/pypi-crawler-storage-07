"""Utility functions for aind_metadata_upgrader"""
