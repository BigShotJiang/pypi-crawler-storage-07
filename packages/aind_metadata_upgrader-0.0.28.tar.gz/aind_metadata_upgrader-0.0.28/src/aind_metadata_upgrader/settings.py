"""Global settings for upgrader"""

FAKE_MISSING_DATA = True
