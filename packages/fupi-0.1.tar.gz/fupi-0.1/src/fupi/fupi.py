from pathlib import Path
import sys 


def add_devpaths(add_paths = ['src','test'], skip_paths = ['setup']):

    # we'll do this twice, one for 'src' and once for 'test'.  
    for dir_name in add_paths:

        # First, let's look for the target directory (tdir) anywhere in the existing path
        tdir = Path.cwd()
        if dir_name in tdir.parts: 

            # If found, let's back up until we're at the PARENT of dir_name, 
            # so we can pick up both 'test' and 'src' as siblings in the next step.
            while dir_name in tdir.parts: 
                tdir = tdir.parent


        # Second, let's load all qualifying subdirs into PATH. 
        # Yes, this is a terrible idea, don't use this outside of DEV or just goofing around. 
        dir = [f'{str(len(d.parts)).zfill(3)}::{d}' for d in tdir.rglob('*') if d.name[:1] if d.name in [dir_name] ]
        if dir: 


            # not any([t for t in test.parts if t in skip_paths])

            # select the shortest path (by dir depth, not character length)
            # and add it and all children to the path, except if any part
            # of the path appears in 'skip_paths' (aka downstream of that dir):
            dir = Path(sorted(dir)[0][5:])
            sys.path.append(str(dir.absolute()))
            sys.path.extend([str(d.absolute()) for d in dir.rglob('*/') 
                             if d.name[:1] not in ['.','_'] and 
                             not any([t for t in d.parts if t in skip_paths]) ])

        # if there is NOT a child directory with a matching name, then do nothing.
    
if __file__ == '__main__':
    add_devpaths()