# -*- coding: utf-8 -*-

import typing as T

from . import type_defs as dc_td

if T.TYPE_CHECKING:  # pragma: no cover
    from mypy_boto3_snow_device_management import type_defs as bs_td


class SNOW_DEVICE_MANAGEMENTCaster:

    def cancel_task(
        self,
        res: "bs_td.CancelTaskOutputTypeDef",
    ) -> "dc_td.CancelTaskOutput":
        return dc_td.CancelTaskOutput.make_one(res)

    def create_task(
        self,
        res: "bs_td.CreateTaskOutputTypeDef",
    ) -> "dc_td.CreateTaskOutput":
        return dc_td.CreateTaskOutput.make_one(res)

    def describe_device(
        self,
        res: "bs_td.DescribeDeviceOutputTypeDef",
    ) -> "dc_td.DescribeDeviceOutput":
        return dc_td.DescribeDeviceOutput.make_one(res)

    def describe_device_ec2_instances(
        self,
        res: "bs_td.DescribeDeviceEc2OutputTypeDef",
    ) -> "dc_td.DescribeDeviceEc2Output":
        return dc_td.DescribeDeviceEc2Output.make_one(res)

    def describe_execution(
        self,
        res: "bs_td.DescribeExecutionOutputTypeDef",
    ) -> "dc_td.DescribeExecutionOutput":
        return dc_td.DescribeExecutionOutput.make_one(res)

    def describe_task(
        self,
        res: "bs_td.DescribeTaskOutputTypeDef",
    ) -> "dc_td.DescribeTaskOutput":
        return dc_td.DescribeTaskOutput.make_one(res)

    def list_device_resources(
        self,
        res: "bs_td.ListDeviceResourcesOutputTypeDef",
    ) -> "dc_td.ListDeviceResourcesOutput":
        return dc_td.ListDeviceResourcesOutput.make_one(res)

    def list_devices(
        self,
        res: "bs_td.ListDevicesOutputTypeDef",
    ) -> "dc_td.ListDevicesOutput":
        return dc_td.ListDevicesOutput.make_one(res)

    def list_executions(
        self,
        res: "bs_td.ListExecutionsOutputTypeDef",
    ) -> "dc_td.ListExecutionsOutput":
        return dc_td.ListExecutionsOutput.make_one(res)

    def list_tags_for_resource(
        self,
        res: "bs_td.ListTagsForResourceOutputTypeDef",
    ) -> "dc_td.ListTagsForResourceOutput":
        return dc_td.ListTagsForResourceOutput.make_one(res)

    def list_tasks(
        self,
        res: "bs_td.ListTasksOutputTypeDef",
    ) -> "dc_td.ListTasksOutput":
        return dc_td.ListTasksOutput.make_one(res)

    def tag_resource(
        self,
        res: "bs_td.EmptyResponseMetadataTypeDef",
    ) -> "dc_td.EmptyResponseMetadata":
        return dc_td.EmptyResponseMetadata.make_one(res)

    def untag_resource(
        self,
        res: "bs_td.EmptyResponseMetadataTypeDef",
    ) -> "dc_td.EmptyResponseMetadata":
        return dc_td.EmptyResponseMetadata.make_one(res)


snow_device_management_caster = SNOW_DEVICE_MANAGEMENTCaster()
