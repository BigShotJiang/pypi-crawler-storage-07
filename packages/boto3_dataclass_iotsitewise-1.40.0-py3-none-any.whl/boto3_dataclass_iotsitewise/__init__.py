# -*- coding: utf-8 -*-

from .caster import iotsitewise_caster

caster = iotsitewise_caster

__version__ = "1.40.0"