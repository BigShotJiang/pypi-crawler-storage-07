

from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta
import io
import logging
import threading
import traceback
import zipfile
import pandas as pd
import requests



logger = logging.getLogger(__name__)


zebubot = None
tick_count = 0
leg_pnl = {}
master_data_loaded = False
strategy_lock = threading.RLock()
position_entered = False
order_placed = False
order_lock = threading.RLock()
exit_all_position = False



# Strategy configuration (can be overridden by YAML config)
strategy_config = {
    'start_time': '09:30:00',  # Market start time
    'end_time': '15:30:00',    # Market end time
    'option_symbol': 'NSE:NIFTY 50',  # Primary option symbol
    'option_type': 'CE',  # Call or Put option (CE/PE)
    'strike_price': 0,  # 0 means ATM (At The Money)
    'quantity': 1,  # Number of lots
    'order_type': 'market',  # market or limit
    'product_type': 'I',  # I for Intraday, M for MIS
    'entry_delay_seconds': 0,  # Delay after start time before placing order
    'exit_delay_seconds': 0,  # Delay before end time to exit position
    'square_off_time': '15:10:00',  # Square off time
    'overall_target': 1000,  # Overall target in INR
    'overall_stop_loss': 1000,  # Overall stop loss in INR
    'idx_pair': 'NSE:NIFTY 50',  # Index pair
    'legs': {  # Default legs configuration
        1: {
            'exch': 'MCX',
            'symbol': 'CRUDEOIL',
            'expiry': '17-09-2025',
            'option_type': 'CE',
            'strike_price': 'ATM',
            'lot_size': 1,
            'order_type': 'market',
            'product_type': 'I',
            'entry_time': '09:30:00',
            'exit_time': '15:30:00'
        }
    }
}



def parse_time(time_str):
    """Parse time string in HH:MM:SS format."""
    try:
        return datetime.strptime(time_str, '%H:%M:%S').time()
    except ValueError:
        logger.error(f"Invalid time format: {time_str}. Use HH:MM:SS format.")
        return None

def get_data(url):
    """Download and extract data from zip file URL."""
    try:
        r = requests.get(url)
        z = zipfile.ZipFile(io.BytesIO(r.content))
        ur = (url.split("/")[-1].split(".")[0])
        
        with z.open(ur + ".txt") as f:
            data = f.read()
            df = pd.read_csv(io.BytesIO(data), dtype=str)
        return df
    except Exception as e:
        logger.error(f"Error downloading data from {url}: {e}")
        return None

def load_strategy_config():
    """Load strategy configuration from YAML file or use defaults."""
    global strategy_config
    
    try:
        # Try to load from YAML config if available
        # The 'strategy' variable is injected by RealtimeExecutor
        print(f"🔍 Debug: Checking for strategy in globals...")
        print(f"   'strategy' in globals: {'strategy' in globals()}")
        if 'strategy' in globals():
            print(f"   strategy type: {type(globals()['strategy'])}")
            print(f"   strategy value: {globals()['strategy']}")
        
        if 'strategy' in globals() and isinstance(globals()['strategy'], dict):
            strategy = globals()['strategy']
            # Update strategy_config with values from YAML
            print(f"📋 Loading YAML config: {strategy}")
            strategy_config.update({
                'start_time': strategy.get('start_time', strategy_config['start_time']),
                'end_time': strategy.get('end_time', strategy_config['end_time']),
                'square_off_time': strategy.get('square_off_time', '15:10:00'),
                'overall_target': strategy.get('overall_target', 1000),
                'overall_stop_loss': strategy.get('overall_stop_loss', 1000),
                'idx_pair': strategy.get('idx_pair', 'NSE:NIFTY 50'),
                'legs': strategy.get('legs', {}),
            })
            logger.info("✅ Strategy configuration loaded from YAML")
            print("✅ Strategy configuration loaded from YAML")
        else:
            logger.info("📋 Using default strategy configuration")
            print("📋 Using default strategy configuration")
        
    except Exception as e:
        logger.error(f"❌ Error loading strategy config: {e}")
        print(f"❌ Error loading strategy config: {e}")
        logger.info("📋 Using default strategy configuration")
        print("📋 Using default strategy configuration")



def load_master_data():
    """Load NFO, BFO and MCX master data."""
    global nfo_master_data, bfo_master_data, mcx_master_data, master_data_loaded
    
    try:
        logger.info("📊 Loading NFO master data...")
        print("📊 Loading NFO master data...")
        
        # Load NFO data
        nfo_master_data = get_data("https://go.mynt.in/NFO_symbols.txt.zip")
        if nfo_master_data is not None:
            nfo_master_data['OptionType'] = nfo_master_data['OptionType'].replace('XX', 'FUT')
            nfo_master_data['Expiry Month'] = pd.to_datetime(nfo_master_data['Expiry'], format='%d-%b-%Y').dt.strftime('%b').str.upper()
            nfo_master_data['Expiry date'] = pd.to_datetime(nfo_master_data['Expiry'], format='%d-%b-%Y').dt.strftime('%d').str.upper()
            nfo_master_data['StrikePrice'] = nfo_master_data['StrikePrice'].astype(str).str.replace(r'\.0$', '', regex=True)
            logger.info(f"✅ NFO master data loaded: {len(nfo_master_data)} symbols")
            print(f"✅ NFO master data loaded: {len(nfo_master_data)} symbols")
        else:
            logger.error("❌ Failed to load NFO master data")
            print("❌ Failed to load NFO master data")
            return False
        
        logger.info("📊 Loading BFO master data...")
        print("📊 Loading BFO master data...")
        
        # Load BFO data
        bfo_master_data = get_data("https://go.mynt.in/BFO_symbols.txt.zip")
        if bfo_master_data is not None:
            bfo_master_data['OptionType'] = bfo_master_data['OptionType'].replace('XX', 'FUT')
            bfo_master_data['Expiry Month'] = pd.to_datetime(bfo_master_data['Expiry'], format='%d-%b-%Y').dt.strftime('%b').str.upper()
            bfo_master_data['Expiry date'] = pd.to_datetime(bfo_master_data['Expiry'], format='%d-%b-%Y').dt.strftime('%d').str.upper()
            
            # BFO uses 'Strike' column instead of 'StrikePrice'
            if 'Strike' in bfo_master_data.columns:
                bfo_master_data['StrikePrice'] = bfo_master_data['Strike'].astype(str).str.replace(r'\.0$', '', regex=True)
            else:
                bfo_master_data['StrikePrice'] = bfo_master_data['StrikePrice'].astype(str).str.replace(r'\.0$', '', regex=True)
            
            logger.info(f"✅ BFO master data loaded: {len(bfo_master_data)} symbols")
            print(f"✅ BFO master data loaded: {len(bfo_master_data)} symbols")
        else:
            logger.error("❌ Failed to load BFO master data")
            print("❌ Failed to load BFO master data")
            return False
        
        logger.info("📊 Loading MCX master data...")
        print("📊 Loading MCX master data...")
        
        # Load MCX data
        mcx_master_data = get_data("https://go.mynt.in/MCX_symbols.txt.zip")
        if mcx_master_data is not None:
            mcx_master_data['OptionType'] = mcx_master_data['OptionType'].replace('XX', 'FUT')
            mcx_master_data['Expiry Month'] = pd.to_datetime(mcx_master_data['Expiry'], format='%d-%b-%Y').dt.strftime('%b').str.upper()
            mcx_master_data['Expiry date'] = pd.to_datetime(mcx_master_data['Expiry'], format='%d-%b-%Y').dt.strftime('%d').str.upper()
            
            # MCX uses 'StrikePrice' column, but for futures (XX) it might be 0 or missing
            if 'StrikePrice' in mcx_master_data.columns:
                mcx_master_data['StrikePrice'] = mcx_master_data['StrikePrice'].astype(str).str.replace(r'\.0$', '', regex=True)
            else:
                # If StrikePrice column doesn't exist, create it with 0 for futures
                mcx_master_data['StrikePrice'] = '0'
            
            logger.info(f"✅ MCX master data loaded: {len(mcx_master_data)} symbols")
            print(f"✅ MCX master data loaded: {len(mcx_master_data)} symbols")
        else:
            logger.error("❌ Failed to load MCX master data")
            print("❌ Failed to load MCX master data")
            return False
        
        master_data_loaded = True
        logger.info("✅ Master data loaded successfully")
        print("✅ Master data loaded successfully")
        return True
        
    except Exception as e:
        logger.error(f"❌ Error loading master data: {e}")
        print(f"❌ Error loading master data: {e}")
        return False

def is_market_time():
    """Check if current time is within market hours."""
    try:
        current_time = datetime.now().time()
        start_time = parse_time(strategy_config['start_time'])
        end_time = parse_time(strategy_config['end_time'])
        
        if not start_time or not end_time:
            return False
            
        return start_time <= current_time <= end_time
    except Exception as e:
        logger.error(f"Error checking market time: {e}")
        return False

def is_entry_time():
    """Check if it's time to enter position."""
    try:
        if position_entered or order_placed:
            return False
            
        current_time = datetime.now().time()
        start_time = parse_time(strategy_config['start_time'])
        
        if not start_time:
            return False
            
        # Add entry delay
        entry_time_with_delay = (datetime.combine(datetime.today(), start_time) + 
                                timedelta(seconds=strategy_config['entry_delay_seconds'])).time()
        
        return current_time >= entry_time_with_delay
    except Exception as e:
        logger.error(f"Error checking entry time: {e}")
        return False


def calculate_expiry_date(expiry_str, base_date=None):
    """Calculate expiry date from string like 'current week', 'next week', etc."""
    if base_date is None:
        base_date = datetime.now()
    
    try:
        if expiry_str.lower() == "current week":
            # Find Thursday of current week
            days_ahead = 3 - base_date.weekday()  # Thursday is 3
            if days_ahead <= 0:  # Target day already happened this week
                days_ahead += 7
            return base_date + timedelta(days=days_ahead)
        
        elif expiry_str.lower() == "next week":
            # Find Thursday of next week
            days_ahead = 3 - base_date.weekday() + 7
            return base_date + timedelta(days=days_ahead)
        
        elif expiry_str.lower() == "current month":
            # Last Thursday of current month
            next_month = base_date.replace(day=28) + timedelta(days=4)
            last_day = next_month - timedelta(days=next_month.day)
            # Find last Thursday
            last_thursday = last_day - timedelta(days=(last_day.weekday() - 3) % 7)
            return last_thursday
        
        elif expiry_str.lower() == "next month":
            # Last Thursday of next month
            next_month = base_date.replace(day=28) + timedelta(days=4)
            next_month = next_month.replace(day=28) + timedelta(days=4)
            last_day = next_month - timedelta(days=next_month.day)
            last_thursday = last_day - timedelta(days=(last_day.weekday() - 3) % 7)
            return last_thursday
        
        else:
            # Try to parse as DD-MM-YYYY
            return datetime.strptime(expiry_str, '%d-%m-%Y')
    
    except Exception as e:
        logger.error(f"Error calculating expiry date for '{expiry_str}': {e}")
        return None

def get_fut_strike(leg_config):
    if leg_config['exch'] == "MCX":
        master_df = mcx_master_data
    elif leg_config['exch'] == "NFO":
        master_df = nfo_master_data
    elif leg_config['exch'] == "BFO":
        master_df = bfo_master_data
    else:
        return None

    expiry_date = calculate_expiry_date(leg_config['expiry'])
    if not expiry_date:
        return None

    master_df = master_df[
        (master_df['Exchange'] == leg_config['exch']) &
        (master_df['Symbol'] == leg_config['symbol']) &
        (master_df['Expiry'] == expiry_date.strftime("%d-%b-%Y").upper())
    ]


    if leg_config['option_type'].upper() == 'FUT':
        return master_df[master_df["OptionType"]=="FUT"].to_dict(orient="records")[0] if len(master_df[master_df["OptionType"]=="FUT"]) > 0 else None
    return None
    

def get_atm_strike(leg_config):
    if not master_data_loaded:
        load_master_data()
    underlying_symbol = strategy_config['idx_pair']
    

    main_pair_data= zebubot.get_symbol_info_return(underlying_symbol)
    if not main_pair_data:
        return None
    # print("main_pair_data::",main_pair_data)
    exchange = main_pair_data['symbol'].split(":")[0]
    token = main_pair_data['token']
    underlying_price = zebubot.myntapi.get_multiple_strikes_ltp([{"exch":exchange,"token":token},{
        "exch":"NSE",
        "token":"26009"
    }])

    print("underlying_price::",exchange+"|"+token)
    underlying_lp = underlying_price.get(exchange+"|"+token).get("lp")
    if not underlying_lp:
        return None
    print("underlying_lp::",underlying_lp)
    if leg_config['exch'] == "MCX":
        master_df = mcx_master_data.copy()
    elif leg_config['exch'] == "NFO":
        master_df = nfo_master_data.copy()
    elif leg_config['exch'] == "BFO":
        master_df = bfo_master_data.copy()
    else:
        return None


    expiry_date = calculate_expiry_date(leg_config['expiry'])
    if not expiry_date:
        return None

    master_df = master_df[
    (master_df['Exchange'] == leg_config['exch']) &
    (master_df['Symbol'] == leg_config['symbol']) &
    (master_df['Expiry'] == expiry_date.strftime("%d-%b-%Y").upper())
    ]

    
    if leg_config['option_type'].upper() == 'CE':
        df = master_df[master_df["OptionType"]=="CE"]
        df["diff"] = (df["StrikePrice"].astype(float) - float(underlying_lp)).abs()
        nearest_idx = df["diff"].idxmin()
        nearest_row = df.loc[nearest_idx]
        return nearest_row.to_dict()

    if leg_config['option_type'].upper() == 'PE':
        df = master_df[master_df["OptionType"]=="PE"]
        df["diff"] = (df["StrikePrice"].astype(float) - float(underlying_lp)).abs()
        nearest_idx = df["diff"].idxmin()
        nearest_row = df.loc[nearest_idx]
        return nearest_row.to_dict()
    


def get_price_premium(leg_config):
    if not master_data_loaded:
        load_master_data()
    underlying_symbol = strategy_config['idx_pair']
    main_pair_data= zebubot.get_symbol_info_return(underlying_symbol)
    if not main_pair_data:
        return None
    exchange = main_pair_data['symbol'].split(":")[0]
    token = main_pair_data['token']
    underlying_price = zebubot.myntapi.get_multiple_strikes_ltp([{"exch":exchange,"token":token},])
    underlying_lp = underlying_price.get(exchange+"|"+token).get("lp")
    if not underlying_lp:
        return None
    print("underlying_lp::",underlying_lp)
    if leg_config['exch'] == "MCX":
        master_df = mcx_master_data.copy()
    elif leg_config['exch'] == "NFO":
        master_df = nfo_master_data.copy()
    elif leg_config['exch'] == "BFO":
        master_df = bfo_master_data.copy()
    else:
        return None
    expiry_date = calculate_expiry_date(leg_config['expiry'])
    if not expiry_date:
        return None
    master_df = master_df[
        (master_df['Exchange'] == leg_config['exch']) &
        (master_df['Symbol'] == leg_config['symbol']) &
        (master_df['Expiry'] == expiry_date.strftime("%d-%b-%Y").upper()) &
        (master_df['OptionType'] == leg_config['option_type'])
    ].copy()

    reqest_data = master_df[["Exchange", "Token"]].copy()
    reqest_data.rename(columns={"Exchange":"exch","Token":"token"},inplace=True)
    response_data = zebubot.myntapi.get_multiple_strikes_ltp(reqest_data.to_dict(orient="records"))

    master_df["LTP"] = master_df.apply(lambda row: float(response_data.get(f"{row['Exchange']}|{row['Token']}", {}).get("lp", 0.0)), axis=1)
    master_df['LTP'] = master_df['LTP'].astype(float)
    master_df['diff'] = (master_df['LTP'] - float(leg_config['price_premium'])).abs()
    nearest_idx = master_df['diff'].idxmin()
    nearest_row = master_df.loc[nearest_idx]
    return nearest_row.to_dict()


    



def resolve_symbol(leg_config):
    """
    Resolve the correct symbol for a leg: FUT, ATM, ITM(+/-), OTM(+/-)
    Handles CE/PE offsets correctly.
    Returns the row from master_df as a dict.
    """
    if not master_data_loaded:
        load_master_data()

    option_type = leg_config.get("option_type")
    if "price_premium" in leg_config:
        return get_price_premium(leg_config)



    strike_price = str(leg_config.get("strike_price", "")).upper()

    # FUTURE
    if option_type == "FUT":
        return get_fut_strike(leg_config)

    # ATM
    if strike_price == "ATM":
        return get_atm_strike(leg_config)

    # Determine exchange & underlying
    underlying_symbol = strategy_config['idx_pair']
    main_pair_data = zebubot.get_symbol_info_return(underlying_symbol)
    if not main_pair_data:
        return None

    exchange = main_pair_data['symbol'].split(":")[0]
    token = main_pair_data['token']

    underlying_price = zebubot.myntapi.get_multiple_strikes_ltp([{"exch": exchange, "token": token},{
        "exch":"NSE",
        "token":"26009"
    }])
    underlying_lp = underlying_price.get(exchange + "|" + token, {}).get("lp")
    if not underlying_lp:
        return None

    print("underlying_lp::",underlying_lp)
    # Select master_df
    if leg_config['exch'] == "MCX":
        master_df = mcx_master_data.copy()
    elif leg_config['exch'] == "NFO":
        master_df = nfo_master_data.copy()
    elif leg_config['exch'] == "BFO":
        master_df = bfo_master_data.copy()
    else:
        return None

    expiry_date = calculate_expiry_date(leg_config['expiry'])
    if not expiry_date:
        return None

    # Filter by exchange, symbol, expiry, option type
    master_df = master_df[
        (master_df['Exchange'] == leg_config['exch']) &
        (master_df['Symbol'] == leg_config['symbol']) &
        (master_df['Expiry'] == expiry_date.strftime("%d-%b-%Y").upper()) &
        (master_df['OptionType'] == option_type)
    ].copy()

    df = master_df.sort_values("StrikePrice").reset_index(drop=True)

    # Determine base index
    base_idx = None
    if strike_price.startswith("ITM"):
        if option_type == 'CE':
            le_idx = df[df["StrikePrice"] <= underlying_lp].index
            if le_idx.empty: raise ValueError("No CE strikes ≤ underlying")
            itm_idx = le_idx[-1]  # 1 strike above underlying
        else:  # PE
            ge_idx = df[df["StrikePrice"] >= underlying_lp].index
            if ge_idx.empty: raise ValueError("No PE strikes ≥ underlying")
            itm_idx = ge_idx[0] # 1 strike below underlying

        # Parse offset
        offset = 0
        if "+" in strike_price:
            offset = int(strike_price.split("+")[1])
        elif "-" in strike_price:
            offset = -int(strike_price.split("-")[1])

        # Apply offset
        if option_type == 'CE':
            target_idx = itm_idx + offset
        else:  # PE
            target_idx = itm_idx + offset

    elif strike_price.startswith("OTM"):
        # CE: OTM = below underlying, PE: OTM = above underlying
        if option_type == 'PE':
            le_idx = df[df["StrikePrice"] <= underlying_lp].index
            if le_idx.empty: raise ValueError("No CE strikes ≤ underlying")
            base_idx = le_idx[-1]
        else:  # PE
            ge_idx = df[df["StrikePrice"] >= underlying_lp].index
            if ge_idx.empty: raise ValueError("No PE strikes ≥ underlying")
            base_idx = ge_idx[0]

        # Parse offset
        offset = 0
        if "+" in strike_price:
            offset = int(strike_price.split("+")[1])
        elif "-" in strike_price:
            offset = -int(strike_price.split("-")[1])

        # Apply offset
        if option_type == 'CE':
            target_idx = base_idx + offset  # CE: + → further OTM (lower strike)
        else:
            target_idx = base_idx + offset  # PE: + → further OTM (higher strike)

    else:
        # If exact numeric strike
        try:
            exact_strike = float(strike_price)
            target_idx = df[df["StrikePrice"] == exact_strike].index[0]
        except:
            raise ValueError(f"Cannot resolve strike: {strike_price}")

    # Clamp index
    target_idx = max(0, min(target_idx, len(df) - 1))

    return df.iloc[target_idx].to_dict()




class PriceType:
    Market = 'MKT'
    Limit = 'LMT'
    StopLossLimit = 'SL-LMT'
    StopLossMarket = 'SL-MKT'


def place_leg_order(leg_id, leg_config):
    resolve_symbol_data = resolve_symbol(leg_config)
    print("resolve_symbol_data::",resolve_symbol_data)
    exchange = resolve_symbol_data['Exchange']
    trading_symbol = resolve_symbol_data['TradingSymbol']
    master_lot_size = resolve_symbol_data['LotSize']
    lot_count = leg_config.get('lot_size', 1)
    order_type = leg_config.get('order_type', 'market')
    product_type = leg_config.get('product_type', 'I')
    total_quantity = lot_count * float(master_lot_size)
    action = leg_config.get('action', 'BUY').upper()
    order_side = 'B' if action == 'BUY' else 'S'
    if order_type.lower() == 'market':
        price_type = PriceType.Market
        price = 0.0
    elif order_type.lower() == 'limit':
        price_type = PriceType.Limit
    else:
        price_type = PriceType.Limit


    try:
        # print(dir(zebubot))
        order_result = zebubot.myntapi.place_order( 
            buy_or_sell = order_side, 
            product_type = product_type,
            exchange = exchange, 
            tradingsymbol = trading_symbol, 
            quantity = total_quantity, 
            discloseqty = 0,
            price_type = price_type, 
            price=0.0, 
            trigger_price=0.0,
            retention='DAY', 
            amo='NO', 
            remarks=None, 
            bookloss_price = 0.0, 
            bookprofit_price = 0.0, 
            trail_price = 0.0)
        
        print("order_result::",order_result)

        strategy_config[leg_id] = {
                    'order_id': order_result.get('norenordno', ''),
                    'symbol': trading_symbol,
                    'token': resolve_symbol_data['Token'],
                    'quantity': total_quantity,
                    'price': 0,
                    'execution_price': 0,
                    'side': order_side,
                    'action': action,
                    'timestamp': datetime.now(),
                    'status': 'OPEN'
                }
        return {
                    "stat":"Ok",
                    'order_id': order_result.get('norenordno', ''),
                    'symbol': trading_symbol,
                    'token': resolve_symbol_data['Token'],
                    'quantity': total_quantity,
                    'price': 0,
                    'execution_price': 0,
                    'side': order_side,
                    'action': action,
                    'timestamp': datetime.now(),
                    'status': 'OPEN'
                }
    except Exception as api_error:
        print(f"❌ API Error in place_order: {api_error}")
        print(f"   Error type: {type(api_error)}")
        print(f"   Error details: {str(api_error)}")
        logger.error(f"API Error in place_order: {api_error}")
        order_result = None


def place_entry_orders():
    results = {}
    with ThreadPoolExecutor(max_workers=len(strategy_config['legs'])) as executor:
        future_to_leg = {
            executor.submit(place_leg_order, i, strategy_config['legs'][i]): i
            for i in strategy_config['legs']
        }
        for future in as_completed(future_to_leg):
            leg = future_to_leg[future]
            try:
                print("future.result()::",future.result())
                results["order_info"][leg] = future.result()
            except Exception as e:
                traceback.print_exc()
                results["order_info"][leg] = {"stat":"Not_Ok"}
    
    return results

def exit_leg(leg_id, leg_config):
    order_side = 'S' if leg_config.get('action') == 'BUY' else 'B'
    product_type = leg_config.get('product_type', 'I')
    exchange = leg_config.get('exch', 'NFO')
    trading_symbol = leg_config.get('symbol', '')
    total_quantity = leg_config.get('quantity', 0)
    price_type = 'MKT'
    order_result = zebubot.myntapi.place_order( 
            buy_or_sell = order_side, 
            product_type = product_type,
            exchange = exchange, 
            tradingsymbol = trading_symbol, 
            quantity = total_quantity, 
            discloseqty = 0,
            price_type = price_type, 
            price=0.0, 
            trigger_price=0.0,
            retention='DAY', 
            amo='NO', 
            remarks=None, 
            bookloss_price = 0.0, 
            bookprofit_price = 0.0, 
            trail_price = 0.0)
    
    return order_result




def check_overall_target_stop_loss():
    if "overall_target" in strategy_config:
        overall_pnl = 0
        for order_id, order_info in strategy_config['order_info'].items():
            if order_info.get('status') == "COMPLETE" and order_info.get('exit') != "COMPLETE":
                lp = zebubot.myntapi.get_multiple_strikes_ltp([{"exch":order_info.get('exch'),"token":order_info.get('token')}])
                if order_info.get('action') == "BUY":
                    overall_pnl += ((float(lp) * float(order_info.get('quantity')))-(float(order_info.get('avg_price'))*float(order_info.get('quantity'))))
                else:
                    overall_pnl += ((float(order_info.get('avg_price'))*float(order_info.get('quantity')))-(float(lp) * float(order_info.get('quantity'))))

        if overall_pnl > strategy_config.get('overall_target'):
            for order_id, order_info in strategy_config['order_info'].items():
                if order_info.get('status') == "COMPLETE" and order_info.get('exit') != "COMPLETE":
                    exit_result = exit_leg(order_id, order_info)
                    if exit_result.get("stat") == "Ok":
                        strategy_config['order_info'][order_id]['exit'] = "COMPLETE"
                        strategy_config['order_info'][order_id]['exit_order_id'] = exit_result.get('norenordno')
            exit_all_position = True
            return "target"

    if "overall_stop_loss" in strategy_config:
        overall_pnl = 0
        for order_id, order_info in strategy_config['order_info'].items():
            if order_info.get('status') == "COMPLETE" and order_info.get('exit') != "COMPLETE":
                lp = zebubot.myntapi.get_multiple_strikes_ltp([{"exch":order_info.get('exch'),"token":order_info.get('token')}])
                if order_info.get('action') == "BUY":
                    overall_pnl += ((float(lp) * float(order_info.get('quantity')))-(float(order_info.get('avg_price'))*float(order_info.get('quantity'))))
                else:
                    overall_pnl += ((float(order_info.get('avg_price'))*float(order_info.get('quantity')))-(float(lp) * float(order_info.get('quantity'))))
        if overall_pnl < strategy_config.get('overall_stop_loss'):
            for order_id, order_info in strategy_config['order_info'].items():
                if order_info.get('status') == "COMPLETE" and order_info.get('exit') != "COMPLETE":
                    exit_result = exit_leg(order_id, order_info)
                    if exit_result.get("stat") == "Ok":
                        strategy_config['order_info'][order_id]['exit'] = "COMPLETE"
                        strategy_config['order_info'][order_id]['exit_order_id'] = exit_result.get('norenordno')
            exit_all_position = True
            return "stop_loss"




def on_tick(symbol, ticker_data):
    global tick_count, order_placed, position_entered
    # print(strategy_config)
    if not zebubot:
        return None
    with strategy_lock:
        tick_count += 1
        current_tick_count = tick_count
        if tick_count == 1:
            load_strategy_config()
            if not master_data_loaded:
                load_master_data()
            
            print("strategy_config::",strategy_config)
            main_pair_data= zebubot.get_symbol_info_return(strategy_config["idx_pair"])
            print("main_pair_data::",main_pair_data)
            zebubot.myntapi.subscribe(main_pair_data['api_symbol'])
    

    # if not order_placed and not position_entered:
    #     # Only use lock to set flags safely
    #     with order_lock:
    #         if not order_placed and not position_entered:
    #             order_placed = True
    #             position_entered = True

    #     print("placing entry orders::")
    #     threading.Thread(target=place_entry_orders, daemon=True).start()


    # Only place entry orders if within entry time
    # if is_entry_time():
    with order_lock:
        if not order_placed and not position_entered:
            print("Placing entry orders as it's entry time...")
            print("entry time::",datetime.now().time())
            # Mark flags to avoid duplicate threads
            order_placed = True
            # position_entered = True
            threading.Thread(target=place_entry_orders, daemon=True).start()

    if not position_entered and order_placed and tick_count % 5 == 0:
        order_book = zebubot.myntapi.get_orders()
        
        for order_id, order_info in strategy_config['order_info'].items():
            if order_info.get('stat') == "Ok" and order_info.get('status') == "OPEN":
                matching_order = next((o for o in order_book if o.get("order_id") == order_id), None)
                if matching_order:
                    # Update status
                    strategy_config['order_info'][order_id]['status'] = matching_order.get('status', order_info['status'])
                    
                    # Update avg_price if order is completed
                    if matching_order.get('status') == "COMPLETE":
                        avg_price = matching_order.get('avg_price')
                        if avg_price is not None:
                            strategy_config['order_info'][order_id]['avg_price'] = avg_price

        # Check if all legs are completed
        if all(info.get('status') == "COMPLETE" for info in strategy_config['order_info'].values()):
            position_entered = True
            
    for order_id, order_info in strategy_config['order_info'].items():
        if order_info.get('status') == "COMPLETE" and order_info.get('exit') != "COMPLETE":
            if "target" in order_info:
                lp = zebubot.myntapi.get_multiple_strikes_ltp([{"exch":order_info.get('exch'),"token":order_info.get('token')}])
                lp = lp.get(order_info.get('exch')+"|"+order_info.get('token')).get("lp")
                if order_info.get('action') == "BUY":
                    print(f"Current P&L {order_id}::",((float(lp) * float(order_info.get('quantity')))-(float(order_info.get('avg_price'))*float(order_info.get('quantity')))))
                    if ((float(lp) * float(order_info.get('quantity')))-(float(order_info.get('avg_price'))*float(order_info.get('quantity')))) > order_info.get('target'):

                        exit_result = exit_leg(order_id, order_info)
                        if exit_result.get("stat") == "Ok":
                            strategy_config['order_info'][order_id]['exit'] = "COMPLETE"
                            strategy_config['order_info'][order_id]['exit_order_id'] = exit_result.get('norenordno')

                else:
                    print(f"Current P&L {order_id}::",((float(order_info.get('avg_price'))*float(order_info.get('quantity')))-(float(lp) * float(order_info.get('quantity')))))
                    if ((float(order_info.get('avg_price'))*float(order_info.get('quantity')))-(float(lp) * float(order_info.get('quantity')))) > order_info.get('target'):
                        exit_result = exit_leg(order_id, order_info)
                        if exit_result.get("stat") == "Ok":
                            strategy_config['order_info'][order_id]['exit'] = "COMPLETE"
                            strategy_config['order_info'][order_id]['exit_order_id'] = exit_result.get('norenordno')

            if "stop_loss" in order_info:
                lp = zebubot.myntapi.get_multiple_strikes_ltp([{"exch":order_info.get('exch'),"token":order_info.get('token')}])
                lp = lp.get(order_info.get('exch')+"|"+order_info.get('token')).get("lp")
                if order_info.get('action') == "BUY":
                    if ((float(lp) * float(order_info.get('quantity')))-(float(order_info.get('avg_price'))*float(order_info.get('quantity')))) < order_info.get('stop_loss'):
                        exit_result = exit_leg(order_id, order_info)
                        if exit_result.get("stat") == "Ok":
                            strategy_config['order_info'][order_id]['exit'] = "COMPLETE"
                            strategy_config['order_info'][order_id]['exit_order_id'] = exit_result.get('norenordno')
                else:
                    if ((float(order_info.get('avg_price'))*float(order_info.get('quantity')))-(float(lp) * float(order_info.get('quantity')))) < order_info.get('stop_loss'):
                        exit_result = exit_leg(order_id, order_info)
                        if exit_result.get("stat") == "Ok":
                            strategy_config['order_info'][order_id]['exit'] = "COMPLETE"
                            strategy_config['order_info'][order_id]['exit_order_id'] = exit_result.get('norenordno')

                            

    if position_entered and not exit_all_position:
        threading.Thread(target=check_overall_target_stop_loss, daemon=True).start()


    
    


    




