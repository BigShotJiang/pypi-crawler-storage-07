# 🎮 PyCgame

**PyCgame** est un module Python pour créer facilement des jeux 2D avec :

* 🖼️ Gestion des **images**
* 🔊 Gestion des **sons**
* ⌨️ Gestion du **clavier/souris**
* 🎮 Support des **manettes et joysticks**
* 🧮 Fonctions **mathématiques intégrées**
* 🐞 Mode **debug** intégré

👉 Compatible avec **Windows 64 bits** et **Linux**.

👉 Arrive Samedi 4 octobre : compilation automatique pour Linux avec `make` + fonction random + autoriser ou non erreurs.log + support des joysticks + logs améliorés.

---

<img src="https://raw.githubusercontent.com/Baptistegrn/PyCgame/refs/heads/main/demo.gif" width="500">

## ⚡ Installation

Depuis PyPI :

```bash
pip install PyCgame
```

Import obligatoire dans votre projet :

```python
from PyCgame import PyCgame
```

⚠️ Attention : l’import exact `from PyCgame import PyCgame` doit être utilisé.

---

## 🐧 Utilisation sous Linux

Si les `.so` fournis ne sont pas compatibles avec votre distribution, vous devez les recompiler :

1. Allez dans le dossier `/compilation`
2. Exécutez :

   ```bash
   make
   ```
3. Un dossier `/so` sera créé avec `libjeu.so`
4. Déplacez  `libjeu.so`  dans le **dossier parent** de `compilation`
5. Placez au même endroit :

   * les .so de sdl2.32.8 sdl2image2.8.8 sdl2mixer2.8.1 ( normalement plusieurs )

---

## 🚀 Initialisation d’un jeu

```python
PyCgame.init(
    largeur=160,           # largeur virtuelle
    hauteur=90,            # hauteur virtuelle
    fps=60,                # nombre d’images par seconde
    coeff=3,               # facteur de mise à l’échelle
    chemin_image="./assets", # dossier images
    chemin_son="./assets",   # dossier sons
    dessiner=True,         # dessiner le fond ?
    bande_noir=True,       # bandes noires si ratio différent ?
    r=0, g=0, b=0,         # couleur de fond
    update_func=Update,    # fonction d’update
    nom_fenetre="MonJeu",  # nom de la fenêtre
    debug=False            # mode debug activable
)

PyCgame.stopper_jeu()
```

---

## 🔄 Boucle de mise à jour

```python
def Update():
    if PyCgame.touche_presser("Espace"):
        print("Espace pressée !")
```

---

## 📊 Propriétés globales

| Propriété            | Description                         |
| -------------------- | ----------------------------------- |
| `PyCgame.largeur`    | largeur virtuelle                   |
| `PyCgame.hauteur`    | hauteur virtuelle                   |
| `PyCgame.dt`         | delta time entre frames             |
| `PyCgame.fps`        | FPS actuel                          |
| `PyCgame.time`       | temps écoulé                        |
| `PyCgame.run`        | bool : le jeu tourne ?              |
| `PyCgame.decalage_x` | décalage en x du jeu en plein écran |
| `PyCgame.decalage_y` | décalage en y du jeu en plein écran |

---

## 🖱️ Gestion de la souris

```python
PyCgame.mouse_x
PyCgame.mouse_y
PyCgame.mouse_presse
PyCgame.mouse_juste_presse
PyCgame.mouse_droit_presse
PyCgame.mouse_droit_juste_presse
```

---

## ⌨️ Gestion du clavier

### Vérification des touches

```python
PyCgame.touche_presser("A")
PyCgame.touche_enfoncee("A")
```

### Liste complète des touches supportées
*(idem qu’avant)*

---

## 🎮 Gestion des manettes et joysticks

### Initialisation et fermeture

```python
PyCgame.init_mannette(0)

# Lecture des joysticks
valeurs = PyCgame.renvoie_joysticks(dead_zone=0.1)
if valeurs:
    lx, ly, rx, ry, lt, rt = valeurs
    print("Joystick gauche:", lx, ly)
    print("Joystick droit:", rx, ry)
    print("Triggers:", lt, rt)

PyCgame.fermer_joystick()
```

### Boutons supportés
*(idem qu’avant : A, B, X, Y, etc.)*

---

## 🖼️ Images et texte

```python
PyCgame.ajouter_image("./assets/perso.png", 10, 20, 32, 32, id_num=2)
PyCgame.ajouter_mot("./assets/police", "Hello", 50, 50, 1, 1, id_num=1)
PyCgame.supprimer_image(1)
PyCgame.modifier_image(20, 30, 32, 32, id_num=1)
PyCgame.modifier_texture("./assets/nouvelle_image.png", id_num=2)
PyCgame.ecrire_console("Hello World !")
PyCgame.colorier(255, 0, 0) # changer couleur de fond
```

---

## 🔊 Sons
*(idem qu’avant)*

---

## 🧮 Fonctions mathématiques

```python
PyCgame.abs_val(-5)
PyCgame.clamp(10, 0, 5)
PyCgame.pow(2, 3)
PyCgame.sqrt(16)
PyCgame.sin(3.14)
PyCgame.atan2(1, 1)
PyCgame.random(0, 10)
```

---

## 🖥️ Redimensionnement

```python
PyCgame.redimensionner_fenetre()
```

---

## 📂 Exemple minimal

```python
from PyCgame import PyCgame

def update():
    if PyCgame.touche_presser("Espace"):
        print("Espace pressée !")

PyCgame.init(largeur=160, hauteur=90, fps=60, update_func=update, debug=True)
```

---

## ✅ Notes importantes

* Les chemins des fichiers sont relatifs au projet.
* Les `id_num` doivent être **uniques** pour chaque image/texte sauf si on veut les modifier/supprimer ensemble.
* `update_func` doit être une **fonction callable**.
* Pour les manettes : toujours appeler `PyCgame.init_mannette()` après `PyCgame.init()` et fermer avec `PyCgame.fermer_joystick()` avant de quitter.

---

## 📬 Support

Pour signaler un bug ou proposer une amélioration :  
📧 **[Baptiste.guerin34@gmail.com](mailto:Baptiste.guerin34@gmail.com)**
