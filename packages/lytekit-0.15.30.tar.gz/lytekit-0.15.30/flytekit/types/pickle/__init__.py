"""
Flytekit Pickle Type
==========================================================
.. currentmodule:: flytekit.types.pickle

.. autosummary::
   :toctree: generated/

   FlytePickle
"""

from .pickle import FlytePickle
