def custom_prompt(event=None):
    async def coroutine():
        prompt_dialog = MultilineTextInputDialog(
            title="Custom Prompt",
            label="Enter your prompt:",
        )

        custom_prompt = await show_dialog_as_float(prompt_dialog)

        if custom_prompt is not None:
            buffer = event.app.current_buffer if event is not None else text_field.buffer
            selectedText = buffer.copy_selection().text
            content = selectedText if selectedText else buffer.text
            content = agentmake(f"# Instruction\n\n{custom_prompt}\n\n# Content\n\n{content}", system="auto")[-1].get("content", "").strip()
            content = re.sub(r"^.*?(```improved_prompt|```)(.+?)```.*?$", r"\2", content, flags=re.DOTALL).strip()
            # insert the improved prompt as a code block
            buffer.insert_text("\n\n```\n"+content+"\n```\n\n")
            # Repaint the application; get_app().invalidate() does not work here
            get_app().reset()