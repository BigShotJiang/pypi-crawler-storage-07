# ToolGuards for Enforcing Agentic Policy Adherence

A middleware solution for enforcement of business policies adherence in agentic workflows.

## Table of Contents

- [Overview](#overview)
- [When to Use This Middleware](#when-to-use-this-middleware)
- [Architecture](#architecture)
- [Installation](#installation)
- [Quick Start](#quick-start)
- [Parameters](#parameters)
  - [Constructor Parameters](#constructor-parameters)
  - [Build Phase Input Format](#build-phase-input-format)
  - [Run Phase Input Format](#run-phase-input-format)
  - [Run Phase Output Format](#run-phase-output-format)
- [Examples](#examples)
- [Benchmarks and Evaluation](#benchmarks-and-evaluation)


## Overview

Business policies (or guidelines) are normally detailed in company documents, and have traditionally been hard-coded into automatic assistant platforms. Contemporary agentic approaches take the "best-effort" strategy, where the policies are appended to the agent's system prompt -- an inherently non-deterministic approach, that does not scale effectively. Here we propose a deterministic, predictable and interpretable two-phase solution for agentic policy adherence at the tool-level: guards are executed prior to function invocation and raise alerts in case a tool-related policy deem violated.

### Key Components

The solution enforces policy adherence through a two-phase process:

(1) **Buildtime**: an offline two-step pipeline that automatically maps policy fragments to the relevant tools and generates policy validation code -- ToolGuards.

(2) **Runtime**: ToolGuards are deployed within the agent's ReAct flow, and are executed after "reason" and just before "act" (agent's tool invocation). If a planned action violates a policy, the agent is prompted to self-reflect and revise its plan before proceeding. Ultimately, the deployed ToolGuards will prevent the agent from taking an action violating a policy.

![two-phase-solution](buildtime-runtime.png)


## When it is Recommended to Use This Middleware:

Policies addressed in this study are those directly protecting tool invocation (pre-tool activation level), hence help preventing altering a system state in a way that contradicts business guidelines.




## Architecture

The offline buildtime process consists of two main components, as illustrated above:

(a) **Tool-Policy Mapper**: transforms an (often) lengthy and noisy natural language policy document into a compact, structured representation by linking clearly formulated policy statements to relevant tools from the provided toolkit.

(b) **ToolGuards Generator**: using the compact structured policy mapping, the generator creates guards (python) code through the test-driven development (TDD) paradigm.

As an example, the policy "Each reservation can have at most five passengers." would eventually be transformed into the below code, raising an exception if violated:

```python
def guard_passenger_limit(args: BookReservationRequest, history: ChatHistory, api: FlightBookingApi) -> None:

    if not hasattr(args, 'passengers') or args.passengers is None:
        raise PolicyViolationException("Missing passengers list in reservation request.")
    if len(args.passengers) > 5:
        raise PolicyViolationException("Each reservation can include up to five passengers.")
    if len(args.passengers) == 0:
        raise PolicyViolationException("At least one passenger must be provided.")    
    ...
```

## Installation

```bash
# Clone the repository
git clone ssh://git@github.ibm.com/AI4BA/agent-lifecycle-toolkit.git
cd agent-lifecycle-toolkit/pre-tool-guard-toolkit

# Install using uv (recommended)
uv sync

# Or install using pip
pip install -e . 


export AZURE_OPENAI_API_KEY=<open ai azure key>
export AZURE_API_BASE="https://eteopenai.azure-api.net"
export AZURE_API_VERSION="2024-08-01-preview"
export PROG_AI_PROVIDER=azure
export PROG_AI_MODEL=gpt-4o-2024-08-06
```

## Quick Start
```
import dotenv

from langchain_core.messages import HumanMessage

from altk.pre_tool_guard_toolkit.core import (
    ToolGuardBuildInput,
    ToolGuardBuildInputMetaData,
    ToolGuardRunInput,
    ToolGuardRunInputMetaData,
)
from altk.pre_tool_guard_toolkit.pre_tool_guard import PreToolGuardComponent

# Load environment variables
dotenv.load_dotenv()


class ToolGuardExample:
    """
    Runs examples with a ToolGuard middleware and validates tool invocation against policy.
    """

    def __init__(self, model, tools, workdir, policy_doc_path, short=True, tools2run=None):
        self.model = model
        self.tools = tools
        self.middleware = PreToolGuardComponent(model=model, tools=tools, workdir=workdir)

        build_input = ToolGuardBuildInput(
            metadata=ToolGuardBuildInputMetaData(
                policy_doc_path=policy_doc_path,
                tools2run=tools2run,
                short1=short,
            )
        )
        self.middleware._build(build_input)

    def run_example(self, user_message: str, tool_name: str, tool_params: dict, should_pass: bool):
        """
        Runs a single example through ToolGuard and checks if the result matches the expectation.
        """
        conversation_context = [HumanMessage(content=user_message)]

        run_input = ToolGuardRunInput(
            messages=conversation_context,
            metadata=ToolGuardRunInputMetaData(
                tool_name=tool_name,
                tool_parms=tool_params
            )
        )

        run_output = self.middleware._run(run_input)
        print(f"run_output: {run_output}")

        passed = not run_output.output.error_message
        if passed == should_pass:
            print("✅ Success!")
        else:
            print("❌ Failed!")

```

## Parameters

### Constructor Parameters

```python
PreToolGuardComponent(tools, workdir)
```

| Parameter | Type             | Description                                                                                                                                                                        |
| --------- | ---------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `tools`   | `list[Callable]` | List of tool functions (or `langchain` tools) that the middleware should manage. Each tool must have a well-defined signature and docstring describing parameters and return type. |
| `workdir` | `str` or `Path`  | Path to a writable working directory where intermediate build and runtime artifacts will be stored (`Step_1/` and `Step_2/` folders). Must exist or be creatable.                  |

###  Build Phase input format 

```python
ToolGuardBuildInput(
    metadata=ToolGuardBuildInputMetaData(
        policy_text="<HTML or Markdown policy string>",
        short1=True,
        validating_llm_client=<LLMClient instance>
    )
)
```

| Field                   | Type        | Description                                                                                                   |
| ----------------------- | ----------- |---------------------------------------------------------------------------------------------------------------|
| `policy_text`           | `str`       | The policy text. Can be plain text, Markdown, or HTML. This defines the rules and constraints for tool usage. |
| `short1`                | `bool`      | If `True`, runs a faster, summarized build process. If `False`, runs a full build.                            |
| `validating_llm_client` | `LLMClient` | A Validation LLM client used during build-time validation of the policy.                                      |

### Run phase Input Format
```python
ToolGuardRunInput(
    metadata=ToolGuardRunInputMetaData(
        tool_name="divide_tool",
        tool_parms={"g": 3, "h": 4},
        llm_client=<LLMClient instance>
    ),
    messages=[
        {"role": "user", "content": "Can you please calculate how much is 3/4?"}
    ]
)
```

| Field        | Type         | Description                                                                           |
| ------------ | ------------ | ------------------------------------------------------------------------------------- |
| `tool_name`  | `str`        | The name of the tool being invoked (must match one provided in `tools` during build). |
| `tool_parms` | `dict`       | Parameters for the tool call. Must match the tool’s expected argument names.          |
| `llm_client` | `LLMClient`  | Runtime LLM client used for evaluation.                                               |
| `messages`   | `list[dict]` | Conversation history in `{role, content}` format.                                     |

### Run phase Output Format
```python
ToolGuardRunOutput(
    output=ToolGuardRunOutputMetaData(
        error_message=False  # or string with violation reason
    )
)
```
| Field           | Type            | Description                                                                                          |
| --------------- | --------------- | ---------------------------------------------------------------------------------------------------- |
| `error_message` | `bool` or `str` | `False` if tool call passed validation, or a string with an error message if it violated the policy. |







## Examples

A simple use case can be found under pre-tool-guard-toolkit/examples/calculator_example





##  Benchmarks and Evaluation

This repository evaluates the effectiveness of `ToolGuards` — a framework for enforcing business policy adherence in LLM-driven agent workflows.

### Overview

We tested `ToolGuards` on the **τ-bench Airlines** benchmark, simulating real-world user requests that often conflict with predefined company policies. The evaluation includes three parts:


### 1. Tool-Policy Mapping Accuracy (Tables 1 & 2)

We assess how well different LLMs (e.g., GPT-4o, Claude, LLaMA) identify references to policy rules in tool documentation.

- **Table 1** reports **Precision (P), Recall (R), F1**, and **FRI** scores at both reference and policy levels.
- **Table 2** explores how the **length and relevance** of policy documents affect mapping performance, including variations with Out-of-Domain (OOD) and Irrelevant In-Domain (IID) content.



#### Table 1: Evaluation of Tool-Policy Mapper

| Model                  | Precision (P) | Recall (R) | F1       | FRI      |
| ---------------------- | ------------- | ---------- | -------- | -------- |
| GPT-4o                 | **0.88**      | 0.77       | **0.80** | **0.83** |
| GPT-4.1-mini           | 0.82          | **0.83**   | **0.80** | 0.66     |
| Claude-Sonnet-3.5      | 0.82          | 0.57       | 0.66     | 0.71     |
| Llama-3.3-70B-Instruct | 0.87          | 0.68       | 0.74     | 0.81     |
| Qwen2.5-72B-Instruct   | 0.85          | 0.55       | 0.62     | 0.73     |

#### Table 2: Effect of Policy Document Length and Relevance

| Policies Document | References F1 | FRI           |
| ----------------- | ------------- | ------------- |
| original (Orig)   | 0.80          | 0.83          |
| Orig + OOD        | 0.65 (-18.3%) | 0.74 (-10.8%) |
| OOD + Orig (rev)  | 0.71 (-10.8%) | 0.78 (-06.0%) |
| Orig + IID        | 0.67 (-16.1%) | 0.74 (-10.8%) |
| IID + Orig (rev)  | 0.73 (-08.7%) | 0.79 (-04.8%) |


### 2. Guard Code Quality (Table 3)

We evaluate `ToolGuard` code using **61 manually-written unit tests** (25 compliance, 36 violation cases).

- Each model is scored by its **Test Pass Ratio (TPR)** — min, max, and mean across all tools.
- **GPT-4.1** achieves the highest reliability with both ground-truth and automatically generated mappings.

#### Table 3: Evaluation of ToolGuard Generators

| Code Generator    | Tool-Policy Mapper | TPR Min  | TPR Max  | TPR Mean |
| ----------------- | ------------------ | -------- | -------- | -------- |
| GPT-4.1           | GT                 | **0.54** | **1.00** | **0.82** |
| GPT-4o            | GT                 | 0.00     | 0.61     | 0.31     |
| Claude-Sonnet-3.5 | GT                 | 0.50     | **1.00** | 0.80     |
| Claude-Haiku-3.5  | GT                 | 0.00     | **1.00** | 0.72     |
| GPT-4.1           | Gen (with GPT-4o)  | **0.54** | **1.00** | 0.75     |


### 3. End-to-End Agent Performance (Figure)

The benchmark evaluates agent compliance with and without `ToolGuards` using the **pass^k** metric:

- **pass^k** measures the probability that at least _k_ out of 10 task attempts are completed successfully.
- The original τ-bench system achieves `pass^1 = 0.450` and `pass^10 = 0.227`.
- With `ToolGuards`, performance improves to `pass^1 = 0.685` and `pass^10 = 0.500` — over **20 percentage points gain**.


<figure>
  <img src="end-to-end-pass.png" alt="τ-bench Airlines evaluation" width="400"/>
  <figcaption><strong>Caption:</strong> τ-bench Airlines benchmark evaluation. Deploying ToolGuards results in steady improvement of over 20 percentage points compared to the original run.</figcaption>
</figure>