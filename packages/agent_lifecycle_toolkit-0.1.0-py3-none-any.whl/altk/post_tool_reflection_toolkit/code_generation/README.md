# Code Generation for Tool Response Processing

If the agent calls tools which generate complex JSON objects as responses, this component will use LLM based Python code generation to process those responses and extract relevant information from them.

## Table of Contents

- [Code Generation for Tool Response Processing](#code-generation-for-tool-response-processing)
  - [Table of Contents](#table-of-contents)
  - [Overview](#overview)
  - [When it is recommended to Use This Component:](#when-it-is-recommended-to-use-this-component)
  - [Architecture](#architecture)
  - [Installation](#installation)
    - [Dependencies](#dependencies)
  - [Quick Start](#quick-start)
  - [Input Format](#input-format)
  - [Output Format](#output-format)
  - [Configuration](#configuration)
  - [Examples](#examples)
  - [API Reference](#api-reference)
  - [Performance Considerations](#performance-considerations)
  - [Error Handling](#error-handling)
  - [Testing](#testing)
    - [Running Tests](#running-tests)
  - [Troubleshooting](#troubleshooting)
    - [Common Issues](#common-issues)
      - [1. LLM Provider Authentication](#1-llm-provider-authentication)
  - [Contributing](#contributing)
    - [Development Setup](#development-setup)
  - [License](#license)
  - [Support](#support)

## Overview

The most common pattern for tool calling is to call a tool that returns some information. The agent then needs to process the tool response and extract the information from it. This information may be required either to respond back to the user or for the next step of the agent. When the tool responses are in JSON format, and the agent knows what information is needed from it, the code generation component prompts a LLM to generate Python code for parsing the JSON and extracting the required information. It executes the generated code and returns back the extracted content if the code execution succeeds.

The figure below shows the flow of tool calling with the code generation based tool response processing component:

<img src="./img_codegen_agent_flow.png" />

## When it is recommended to Use This Component:

Based on our evaluation, this approach to tool response processing is effective when the JSON tool responses are large and complex/highly nested and when the processing required is not trivial. For example, when the information to be extracted from the response is present as a single key, it might be easier for the model to extract it without code generation. But for more complex processing such as filtering and aggregation, code generation based processing is more accurate.


## Architecture

The figure below shows how the code generation component processes the tool response to get the answer i.e. the information from the JSON object.

<img src="./img_codegen_architecture.png" />

More details of how this component works and detailed evaluation can be found in our [draft paper](https://authorworkbench.apps.res.ibm.com/work/preview/19419).

## Installation

```bash
# Clone the repository
git clone ssh://git@github.ibm.com/AI4BA/agent-lifecycle-toolkit.git
cd agent-lifecycle-toolkit

# Install using uv (recommended)
uv pip install post-tool-reflection-toolkit

# Or install using pip
pip install ./post-tool-reflection-toolkit
```

### Dependencies

The middleware requires access to:
- **toolkit-core**: Core toolkit framework components
- **LLM Provider**: Access to language models (Watsonx, RITS, OpenAI, etc.)

## Quick Start
Here is how you can call the code generation based tool response processing:

```Python

from altk.toolkit_core.core.toolkit import AgentPhase
from altk.post_tool_reflection_toolkit.code_generation.code_generation import CodeGenerationComponent
from altk.post_tool_reflection_toolkit.core.toolkit import CodeGenerationRunInput, CodeGenerationRunOutput

nl_query = "I need info about X from service Y."
response = {...} # this is some tool or api response in JSON format
middleware = CodeGenerationComponent()

input_data = CodeGenerationRunInput(
    messages=[],
    nl_query=nl_query,
    tool_response=response
)
output = middleware.process(input_data, AgentPhase.RUNTIME)
```
## Input Format
The class post_tool_reflection_toolkit.core.toolkit.CodeGenerationRunInput expects two main inputs as follows:

1. `nl_query`: str, this is the natural language description hinting at what information needs to be extracted from the response. It can be the agent's thought corresponding to the tool call or the user query directly.

2. `tool_response`: Any, this is the JSON response from the tool.

## Output Format
The output is a `CodeGenerationRunOutput` object with a result property that contains the data that was extracted using the generated code.

## Configuration

The LLM model, provider and inference settings can be configured when creating the `CodeGenerationComponent` by supplying the relevant parameters. For example:

```python
from altk.post_tool_reflection_toolkit.code_generation.code_generation import CodeGenerationComponent

middleware = CodeGenerationComponent(
    model_id="meta-llama/llama-3-405b-instruct",
    provider="watsonx", # can be one of: watsonx, huggingface, openai 
    model_kwargs={
        "temperature": 0.5,
        "max_tokens": 1000,
        "min_tokens": 20,
        "seed": 42,
    }
)
```

- `use_docker_sandbox` when set to `True` will use the `DOCKER_HOST` in the environment variables to run the generated code in a container, setting to `False` will use a restricted Python interpreter locally. Running the generated code locally while faster carries some security risks.

## Examples
```python
from altk.toolkit_core.core.toolkit import AgentPhase
from altk.post_tool_reflection_toolkit.code_generation.code_generation import CodeGenerationComponent
from altk.post_tool_reflection_toolkit.core.toolkit import CodeGenerationRunInput, CodeGenerationRunOutput

middleware = CodeGenerationComponent()

input_data = CodeGenerationRunInput(
    messages=[],
    user_query=user_query,
    tool_responses=response
)
output = middleware.process(input_data, AgentPhase.RUNTIME)
```

## API Reference

## Performance Considerations

## Error Handling

If the model generates invalid code then an `InvalidCodeException` is thrown. 

## Testing
The middleware includes comprehensive test suites:
### Running Tests
```
# Run all tests
uv run pytest tests/post-tool-reflection/

# Run specific test categories
uv run pytest tests/post-tool-reflection/codegen_test.py
```

## Troubleshooting

### Common Issues

#### 1. LLM Provider Authentication
```bash
# Ensure your LLM provider credentials are set
export WX_API_KEY="your-api-key"
export WX_PROJECT_ID="your-project-id"
export WX_URL="https://us-south.ml.cloud.ibm.com"
```

## Contributing

### Development Setup
```bash
git clone ssh://git@github.ibm.com/AI4BA/agent-lifecycle-toolkit.git
cd agent-lifecycle-toolkit/post-tool-reflection-toolkit
uv sync --dev
```

## License

MIT License - see LICENSE file for details.

## Support

For questions and support:
- Create issues in the repository