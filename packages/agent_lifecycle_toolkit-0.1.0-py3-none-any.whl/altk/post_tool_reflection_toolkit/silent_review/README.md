# Silent Error Review
A prompt-based approach to **identify** silent errors in tool calls (errors that do not produce any visible or explicit error message); 

Determines whether the tool response is relevant, accurate and complete based on the user's query

## Usage Guidelines
Best suited for tool responses that are verbose and/or based on tabular responses.

### Interface
Expected input: 
- user query, 
- tool response, 
- tool specification, 
- tool input, 
- tool type

Expected output: 
- Accomplished | Partially Accomplished | Not Accomplished

### Sample Agent Integration
See a sample integration [here](https://github.ibm.com/AI4BA/wxo-agents-experimental/blob/1a7abaf47986a65b0ec4414cbc16bef619224861/watsonx_orchestrate/experimental/agents/extensions/react/react_silent_review.py#L232)

The below example should give you an idea of how to plug in this component into your agent pipeline: 
````
from altk.post_tool_reflection_toolkit.silent_review.silent_review import SilentReviewForJSONDataComponent
from altk.post_tool_reflection_toolkit.core.toolkit import SilentReviewRunInput
from altk.toolkit_core.core.toolkit import AgentPhase

input_data = SilentReviewRunInput(
        messages=[
            HumanMessage(content="Tell me the weather"),
            AIMessage(content="Calling the weather tool now")
        ],
        toolspec={
            "name": "get_weather",
            "description": "Gets weather for a city",
            "parameters": {
                "type": "object",
                "properties": {
                    "city": {"type": "string"}
                },
                "required": ["city"]
            }
        },
        tool_response={
            "name": "get_weather",
            "result": {"city": "NYC", "temperature": "75F", "condition": "Sunny"}
        }
    )

reviewer = SilentReviewForJSONDataComponent()
result = reviewer.process(data=input_data, phase=AgentPhase.RUNTIME)
print(result.outcome.value)

# possible outcomes

# NOT_ACCOMPLISHED = 0
# PARTIAL_ACCOMPLISH = 0.5
# ACCOMPLISHED = 1

````

## Behind the Scenes
### Approach Overview
Prompt an LLM with instructions to review the tool response and determine if it accomplishes the user's query. 

![img.png](img.png)

### Evaluation Results

Micro win rate is when you compute the win rate over all the individual data subsets and then take the average of all the win rates.
Macro win rate is when you compute win rate over all the samples in all the data subsets.

| Method               | Micro <br> Win Rate | Micro <br> Avg. Loop | Macro <br> Win Rate | Macro <br> Avg. Loop |
|----------------------| -- | -- | -- | -- | 
| React without Review | 0.068 | 8.72 | 0.061 | 8.51 |
| React with Review    | 0.127 | 7.77 | 0.104 | 7.90 |