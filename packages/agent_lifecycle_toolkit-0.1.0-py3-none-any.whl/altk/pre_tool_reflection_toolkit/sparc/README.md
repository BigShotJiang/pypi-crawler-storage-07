# Semantic Pre-execution Analysis for Reliable Calls (SPARC)

This component evaluates tool calls before execution, identifying potential issues and suggesting corrections or transformations across multiple validation layers.

## Table of Contents

- [Overview](#overview)
- [When it is recommended to Use This Middleware](#when-it-is-recommended-to-use-this-middleware)
- [Features](#features)
- [Experimental Results](#experimental-results)
- [Architecture](#architecture)
- [Installation](#installation)
- [Quick Start](#quick-start)
- [Input Format](#input-format)
- [Configuration](#configuration)
- [Validation Layers](#validation-layers)
- [Examples](#examples)
- [API Reference](#api-reference)
- [Performance Considerations](#performance-considerations)
- [Error Handling](#error-handling)
- [Testing](#testing)
- [Troubleshooting](#troubleshooting)
- [Contributing](#contributing)

## Overview

The Semantic Pre-execution Analysis for Reliable Calls (SPARC) Middleware provides multi-layered validation for tool calls in agentic systems. It combines syntactic validation, semantic analysis, and intelligent parameter transformations to ensure tool calls are correct, appropriate, and properly formatted before execution.

This component is designed to be used by any tool-calling agent right before tool execution, allowing you to configure metrics and checks based on your specific use case requirements.

### Key Components

1. **Syntactic Validation**: Python-based static analysis of tool call structure (fast and 100% accurate)
2. **Semantic Analysis**: LLM-as-a-judge evaluation of intent alignment and appropriateness
3. **Parameter Transformation**: Code generation for complex value transformations (units, formats, etc.)
4. **Flexible Configuration**: Multiple pre-configured validation profiles for different use cases

## When it is Recommended to Use This Component:

- **Critical Applications**: Tool execution can change state, databases, or have significant consequences
- **Complex Parameters**: Your tools have many parameters or complex parameter relationships
- **Unit Conversions**: Tools require specific units/formats that can't be validated statically
- **Parameter Validation**: You need to verify that parameters are grounded in conversation context
- **Quality Assurance**: You want to catch hallucinated or incorrect tool calls before execution
- **Production Systems**: Where tool call accuracy is critical for user experience
- **Financial/Medical/Legal**: Domains where incorrect tool calls could have serious consequences

### Configuration Guidelines by Use Case:

- **No parameters or simple parameters**: Use `Track.SYNTAX` for fast static validation only
- **Single-turn or Multi-turn agentic conversations (performance-sensitive)**: Use `Track.FAST_TRACK` for basic semantic validation
- **Single-turn or Multi-turn conversations (high accuracy)**: Use `Track.SLOW_TRACK` for comprehensive validation
- **Unit conversion focus**: Use `Track.TRANSFORMATIONS_ONLY` for transformation-specific validation

## Features

### 🔍 Multi-Layer Validation
- **Static Analysis**: JSON schema validation, type checking, required parameter verification (Python-based, fast, 100% accurate)
- **Semantic Evaluation**: Intent alignment, parameter grounding, function selection appropriateness (LLM-based)
- **Parameter-Level Analysis**: Individual parameter validation and hallucination detection (1 LLM call per metric)
- **Transformation Validation**: Complex value conversion verification using code generation (1 + N LLM calls, where N = parameters needing transformation)

### ⚡ Flexible Execution
- **Sync/Async Support**: Choose execution mode based on your application needs
- **Parallel Execution**: All semantic metrics can run in parallel with ASYNC mode
- **Configurable Metrics**: Select specific validation metrics for your use case
- **Error Handling**: Graceful degradation with detailed error reporting
- **Performance Optimized**: Configurable retry logic and parallel execution limits

### 🛠 Easy Integration
- **Middleware Pattern**: Clean integration with existing agentic frameworks
- **Flexible Input**: Supports OpenAI-compatible tool specifications and conversation history
- **Comprehensive Output**: Detailed validation results with explanations and corrections
- **Track-Based API**: Pre-configured validation profiles for different use cases

## Experimental Results

### Tau-bench Airline Domain Evaluation

We evaluated the SPARC Middleware on the Tau-bench airline domain to demonstrate its effectiveness in improving agent performance. In this experiment, we tested the reflection component by adding a reflection step before each tool call. If the tool call was incorrect, the reflection explanation and correction suggestions were returned to the agent to revise the tool call. Otherwise, the tool call was executed as usual.

The results below compare the regular agent (without reflection) and the enhanced version with reflection. The reflection includes both syntactic validation and fast track semantic validation (2 general metrics: hallucination detection and agentic constraint satisfaction).

The experiment was conducted across multiple agent models - GPT-4o, GPT-4o Mini, and Mistral Large - with various reflection models, including a case where the agent is GPT-4o Mini and the reflector is a stronger model like GPT-4o.

### Metrics Definition
- **Average Reward (Pass^1)**: The mean score across all tasks, reflecting overall agent performance
- **Pass^k**: K successful task attempts out of all possible attempts (≥k)

### Results Table

| Model | Metric | Without Reflection | With Reflection | Improvement (%) |
|-------|--------|-------------------|-----------------|----------------|
| GPT-4o | Average Reward | 0.47 | 0.485 | +3.19% |
| GPT-4o | Pass^1 | 0.47 | 0.485 | +3.19% |
| GPT-4o | Pass^2 | 0.3567 | 0.38 | +6.54% |
| GPT-4o | Pass^3 | 0.3 | 0.335 | +11.67% |
| GPT-4o | Pass^4 | 0.26 | 0.3 | +15.38% |
| GPT-4o Mini (reflection by GPT-4o) | Average Reward | 0.175 | 0.185 | +5.71% |
| GPT-4o Mini (reflection by GPT-4o) | Pass^1 | 0.175 | 0.185 | +5.71% |
| GPT-4o Mini (reflection by GPT-4o) | Pass^2 | 0.0833 | 0.1067 | +28.05% |
| GPT-4o Mini (reflection by GPT-4o) | Pass^3 | 0.04 | 0.085 | +112.50% |
| GPT-4o Mini (reflection by GPT-4o) | Pass^4 | 0.02 | 0.08 | +300.00% |
| Mistral Large (35 steps) | Average Reward | 0.08 | 0.1 | +25.00% |
| Mistral Large (35 steps) | Pass^1 | 0.08 | 0.1 | +25.00% |
| Mistral Large (35 steps) | Pass^2 | 0.0133 | 0.0333 | +150.38% |
| Mistral Large (35 steps) | Pass^3 | 0 | 0.01 | — |
| Mistral Large (35 steps) | Pass^4 | 0 | 0 | — |
| Mistral Large (60 steps) | Average Reward | 0.12 | 0.13 | +8.33% |
| Mistral Large (60 steps) | Pass^1 | 0.12 | 0.13 | +8.33% |
| Mistral Large (60 steps) | Pass^2 | 0.0367 | 0.0667 | +81.84% |
| Mistral Large (60 steps) | Pass^3 | 0.01 | 0.045 | +350.00% |
| Mistral Large (60 steps) | Pass^4 | 0 | 0.04 | — |

### Key Findings

1. **Consistent Improvement in Multi-Attempt Success**: The reflection mechanism shows significant improvements in Pass^2, Pass^3, and Pass^4 metrics across all models, indicating better performance when agents have multiple attempts to solve tasks.

2. **Model-Dependent Benefits**: While GPT-4o shows consistent improvements across all metrics, smaller models like GPT-4o Mini benefit more when reflection is performed by a stronger model (GPT-4o) rather than self-reflection.

3. **Substantial Gains for Weaker Models**: Mistral Large shows dramatic improvements, particularly in higher-order Pass metrics, demonstrating that reflection is especially valuable for models that initially struggle with tool calling accuracy.

### RewardBench Evaluation

We also evaluated the middleware on [RewardBench](https://huggingface.co/datasets/ibm-research/fc-reward-bench), a benchmark designed to evaluate reward model performance in function-calling tasks. The benchmark features 1,500 unique user inputs derived from the single-turn splits of the BFCL-v3 dataset, with each input paired with both correct and incorrect function calls.

**Configuration**: llama-4-maverick model using fast track validation (2 general metrics: hallucination detection and agentic constraint satisfaction)

| Model | TPR | TNR | Accuracy | Time/Sample |
|-------|-----|-----|----------|-------------|
| SPARC Reflector | 84.33% | 91.87% | 88.10% | 2.5 seconds |
| Granite-Guardian-3.2-5B | 37.33% | 20.60% | 54.27% | 50 milliseconds |
| FORM-1.5B | 75.40% | 71.07% | 73.23% | 12 milliseconds |
| FORM-3B | 64.27% | 86.60% | 75.43% | 25 milliseconds |

**Important Note**: The SPARC Reflector is fundamentally different from traditional reward models. While reward models (Granite-Guardian, FORM-1.5B, FORM-3B) produce continuous scores between 0 and 1, the reflector focuses on:

- **Error Localization**: Identifying specific issues in tool calls
- **Evidence Provision**: Explaining why a tool call is problematic
- **Correction Suggestions**: Providing actionable recommendations for fixes
- **Configurable Output**: Users can control output verbosity (explanation-only, evidence, corrections) to balance detail vs. processing time

This comprehensive analysis requires generating more tokens than simple reward scoring, which explains the longer processing time. However, the reflector's detailed feedback enables agents to actually correct their tool calls rather than just knowing they made an error.

### BFCL-v3 Detection Performance

We evaluated the reflector's ability to distinguish between correct and incorrect tool calls on the BFCL-v3 benchmark. The slow-track reflector (which includes multiple metrics and unit transformation checks) was tested on tool calls generated using Granite Function Calling 20B and compared against ground truth labels.

#### Single-Turn Performance

| Metric | Score |
|--------|-------|
| **Generator Model** | Granite Function Calling 20b |
| **Reflector Model** | Llama-3-3-70b |
| **Accuracy** | 0.872 |
| **Precision** | 0.823 |
| **Recall** | 0.765 |
| **F1 Score** | 0.793 |

#### Multi-Turn Performance

| Metric | Score |
|--------|-------|
| **Generator Model** | Granite Function Calling 20b |
| **Reflector Model** | Phi-4 |
| **Accuracy** | 0.866 |
| **Precision** | 0.944 |
| **Recall** | 0.905 |
| **F1 Score** | 0.924 |

These results demonstrate the reflector's strong ability to accurately identify problematic tool calls across both single-turn and multi-turn scenarios. The multi-turn configuration shows particularly high precision (94.4%) and recall (90.5%), indicating excellent performance in complex conversational contexts where tool calls may depend on previous interactions.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                SPARC Reflection Middleware                  │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌──────────────┐  ┌─────────────────────┐ │
│  │   Static    │  │   Semantic   │  │   Transformation    │ │
│  │ Validation  │  │  Analysis    │  │    Validation       │ │
│  │             │  │              │  │                     │ │
│  │ (Python)    │  │ (LLM based)  │  │    (LLM based)      │ │
│  └─────────────┘  └──────────────┘  └─────────────────────┘ │
├─────────────────────────────────────────────────────────────┤
│                    LLMEvalKit Integration                   │
│ ┌─────────────────────────────────────────────────────────┐ │
│ │                   Reflection Pipeline                   │ │
│ │  • Metrics Engine    • LLM Provider    • Result Proc    │ │
│ └─────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

## Installation

```bash
# Clone the repository
git clone ssh://git@github.ibm.com/AI4BA/agent-lifecycle-toolkit.git
cd agent-lifecycle-toolkit/pre-tool-reflection-toolkit

# Install using uv (recommended)
uv sync

# Or install using pip
pip install -e .
```

### Dependencies

The middleware requires access to:
- **toolkit-core**: Core middleware framework components
- **llmevalkit**: LLM evaluation and reflection pipeline
- **LLM Provider**: Access to language models (Watsonx, OpenAI, etc.)

## Quick Start

```python
import os
from altk.pre_tool_reflection_toolkit.core import (
    SPARCReflectionRunInput,
    Track,
    SPARCExecutionMode,
)
from altk.pre_tool_reflection_toolkit.sparc import SPARCReflectionComponent
from altk.toolkit_core.core.toolkit import AgentPhase, ComponentConfig
from langchain_core.messages import HumanMessage, AIMessage
from altk.toolkit_core.llm import get_llm

# Build ComponentConfig with ValidatingLLMClient (REQUIRED)
def build_config():
    """Build ComponentConfig with WatsonX ValidatingLLMClient."""
    WATSONX_CLIENT = get_llm("watsonx.output_val")  # ValidatingLLMClient
    return ComponentConfig(
        llm_client=WATSONX_CLIENT(
            model_name="meta-llama/llama-4-maverick-17b-128e-instruct-fp8",
        )
    )

# Initialize reflector with ComponentConfig and Track-based API
config = build_config()
reflector = SPARCReflectionComponent(
    config=config,  # ComponentConfig with ValidatingLLMClient
    track=Track.FAST_TRACK,  # Choose appropriate track
    execution_mode=SPARCExecutionMode.ASYNC,
)

# Check initialization
if reflector._initialization_error:
    print(f"Failed to initialize: {reflector._initialization_error}")
    exit(1)

# Define your tool specification (OpenAI format)
tool_specs = [{
    "type": "function",
    "function": {
        "name": "send_email",
        "description": "Send an email to recipients",
        "parameters": {
            "type": "object",
            "properties": {
                "to": {"type": "array", "items": {"type": "string"}},
                "subject": {"type": "string"},
                "body": {"type": "string"}
            },
            "required": ["to", "subject", "body"]
        }
    }
}]

# Prepare conversation context
messages = [
    HumanMessage(content="Send an email to team@company.com about the meeting"),
    AIMessage(content="I'll send that email for you.")
]

# Tool call to validate (OpenAI format)
tool_call = {
    "id": "1",
    "type": "function", 
    "function": {
        "name": "send_email",
        "arguments": '{"to": ["teams@company.com"], "subject": "Meeting Update", "body": "Meeting scheduled for tomorrow."}'
    }
}

# Run reflection
run_input = SPARCReflectionRunInput(
    messages=messages,
    tool_specs=tool_specs,
    tool_calls=[tool_call]
)

result = reflector.process(run_input, phase=AgentPhase.RUNTIME)

# Check results
if result.output.reflection_result.decision == "approve":
    print("✅ Tool call approved")
else:
    print("❌ Tool call rejected")
    for issue in result.output.reflection_result.issues:
        print(f"  - {issue.metric_name}: {issue.explanation}")
```

## Input Format

The middleware expects three main inputs in OpenAI-compatible formats:

### 1. Conversational History (messages)
List of messages representing the conversation context:

```python
from langchain_core.messages import HumanMessage, AIMessage

messages = [
    HumanMessage(content="What's the weather in New York?"),
    AIMessage(content="I'll check the weather for you."),
    HumanMessage(content="Make sure to use Fahrenheit please"),
    AIMessage(content="I'll get the weather in New York using Fahrenheit.")
]
```

### 2. Tool Specifications (OpenAI format)
Array of tool specifications following OpenAI function calling format:

```python
tool_specs = [
    {
        "type": "function",
        "function": {
            "name": "get_weather",
            "description": "Get current weather for a location",
            "parameters": {
                "type": "object",
                "properties": {
                    "location": {
                        "type": "string",
                        "description": "City and state/country"
                    },
                    "units": {
                        "type": "string",
                        "enum": ["celsius", "fahrenheit"],
                        "description": "Temperature units"
                    }
                },
                "required": ["location", "units"]
            }
        }
    }
]
```

### 3. Generated Tool Call (OpenAI format)
The tool call generated by your agent that needs validation:

```python
tool_call = {
    "id": "call_123",
    "type": "function",
    "function": {
        "name": "get_weather", 
        "arguments": '{"location": "New York, NY", "units": "fahrenheit"}'
    }
}
```

## ValidatingLLMClient Requirements

**IMPORTANT**: The SPARCReflectionComponent requires a `ValidatingLLMClient` instance for proper output validation and structured response handling.

### Supported ValidatingLLMClient Types

```python
from altk.toolkit_core.llm import get_llm

# WatsonX (using litellm) with output validation
WATSONX_CLIENT = get_llm("litellm.watsonx.output_val")

# WatsonX (using ibm-watsonx-ai) with output validation
WATSONX_CLIENT = get_llm("watsonx.output_val")

# Azure OpenAI with output validation
AZURE_CLIENT = get_llm("azure_openai.output_val")
```

### Configuration Examples

#### WatsonX ValidatingLLMClient
```python
def build_config():
    WATSONX_CLIENT = get_llm("watsonx.output_val")
    return ComponentConfig(
        llm_client=WATSONX_CLIENT(
            model_name="meta-llama/llama-4-maverick-17b-128e-instruct-fp8",
        )
    )
```

### Type Validation

The middleware automatically validates the LLM client type during initialization:

```python
# ✅ Correct - ValidatingLLMClient
config = build_config()  # Returns ValidatingLLMClient
middleware = SPARCReflectionComponent(config=config, track=Track.SYNTAX)

# ❌ Error - Regular LLMClient (not ValidatingLLMClient)
regular_client = get_llm("watsonx")  # Returns regular LLMClient
config = ComponentConfig(llm_client=regular_client(...))
middleware = SPARCReflectionComponent(config=config, track=Track.SYNTAX)
# TypeError: LLM client must be of type ValidatingLLMClient
```

## Configuration

### Track-Based Configuration

The middleware uses a Track enum for simplified configuration. Each track represents a predefined set of validation metrics optimized for specific use cases:

#### `Track.SYNTAX` - Fast Static Validation Only
- **LLM Calls**: 0
- **Validates**: JSON schema, types, required parameters
- **Use Case**: Fast validation, development/testing, simple tools
- **Performance**: Fastest (Python-based validation only)
- **Model Required**: No

```python
# SYNTAX track doesn't require LLM client (static validation only)
middleware = SPARCReflectionComponent(
    config=None,  # No config needed for static-only validation
    track=Track.SYNTAX,
    execution_mode=SPARCExecutionMode.ASYNC,
)
```

#### `Track.FAST_TRACK` - Basic Semantic Validation
- **LLM Calls**: 2
- **Validates**: General hallucination check + function selection appropriateness (executed in parallel)
- **Use Case**: Single-turn or multi-turn conversations, performance-sensitive applications
- **Performance**: Very fast
- **Model Required**: Yes

```python
config = build_config()  # ValidatingLLMClient required
middleware = SPARCReflectionComponent(
    config=config,
    track=Track.FAST_TRACK,
    execution_mode=SPARCExecutionMode.ASYNC,
)
```

#### `Track.SLOW_TRACK` - Comprehensive Validation
- **LLM Calls**: 5 + N (where N = parameters needing transformation, executed in parallel)
- **Validates**: General hallucination check + function selection appropriateness + value format + agentic constraint satisfaction + transformations
- **Use Case**: Single-turn or multi-turn conversations requiring high accuracy
- **Performance**: Moderate (depends on parameter count)
- **Model Required**: Yes

```python
config = build_config()  # ValidatingLLMClient required
middleware = SPARCReflectionComponent(
    config=config,
    track=Track.SLOW_TRACK,
    execution_mode=SPARCExecutionMode.ASYNC,
)
```

#### `Track.TRANSFORMATIONS_ONLY` - Unit/Format Conversion Focus
- **LLM Calls**: 1 + N (where N = parameters needing transformation, executed in parallel)
- **Validates**: Units conversion, format transformations
- **Use Case**: Systems with complex parameter transformation needs
- **Performance**: Variable (depends on transformation complexity)
- **Model Required**: No

```python
# TRANSFORMATIONS_ONLY track doesn't require LLM client for basic transformations
middleware = SPARCReflectionComponent(
    config=None,  # No config needed for transformation-only validation
    track=Track.TRANSFORMATIONS_ONLY,
    execution_mode=SPARCExecutionMode.ASYNC,
)
```

### Track Metrics Breakdown

Each track includes specific validation metrics optimized for different use cases:

#### `Track.SYNTAX`
- **Static validation only** (Python-based, no LLM calls)
- JSON schema compliance
- Type validation
- Required parameter verification
- Constraint validation (min/max, enum values)

#### `Track.FAST_TRACK`
- **METRIC_GENERAL_HALLUCINATION_CHECK**: Detects hallucinated or fabricated parameter values
- **METRIC_FUNCTION_SELECTION_APPROPRIATENESS**: Validates function choice matches user intent

#### `Track.SLOW_TRACK`
- **METRIC_GENERAL_HALLUCINATION_CHECK**: Detects hallucinated or fabricated parameter values
- **METRIC_PARAMETER_VALUE_FORMAT_ALIGNMENT**: Validates parameter format requirements
- **METRIC_FUNCTION_SELECTION_APPROPRIATENESS**: Validates function choice matches user intent
- **METRIC_AGENTIC_CONSTRAINTS_SATISFACTION**: Validates adherence to agentic conversation constraints and context
- **Transform enabled**: Unit/format conversions when needed

#### `Track.TRANSFORMATIONS_ONLY`
- **Transform enabled**: Focus on unit/format conversions
- **METRIC_TRANSFORMATION_DETECTION**: Identifies parameters needing transformation
- **Code generation**: Creates transformation code for each parameter requiring conversion
- **Supported conversions**: Temperature (F/C), distance (miles/km), weight (lbs/kg), and custom transformations

### Custom Configuration

For creating custom metric combinations instead of using predefined tracks, you can use the `custom_config` parameter with a `SPARCReflectionConfig` object:

```python
from altk.pre_tool_reflection_toolkit.core import SPARCReflectionConfig, SPARCExecutionMode

# Create custom configuration
custom_config = SPARCReflectionConfig(
    execution_mode=SPARCExecutionMode.ASYNC,  # Enable parallel execution
    general_metrics=["function_intent_alignment", "parameter_value_grounding"],
    function_metrics=["function_selection_appropriateness"],
    parameter_metrics=["parameter_hallucination_check"],
    transform_enabled=True,  # Enable transformation validation
    verbose_logging=True,
    retries=3,
    max_parallel=5  # Control parallel execution limit
)

# Use with middleware (LLM client still comes from ComponentConfig)
config = build_config()  # ComponentConfig with ValidatingLLMClient
middleware = SPARCReflectionComponent(
    config=config,  # LLM client configuration
    custom_config=custom_config,  # Validation configuration
    execution_mode=SPARCExecutionMode.ASYNC,
)
```

### Custom Metric Configuration

For advanced users who need specific combinations of validation metrics, you can bypass predefined tracks and create custom configurations:

#### Available Metrics

```python
from llmevalkit.function_calling.consts import (
    METRIC_GENERAL_HALLUCINATION_CHECK,        # Detects hallucinated parameter values
    METRIC_GENERAL_VALUE_FORMAT_ALIGNMENT,     # Validates parameter format requirements
    METRIC_FUNCTION_SELECTION_APPROPRIATENESS, # Validates function choice matches intent
    METRIC_AGENTIC_CONSTRAINTS_SATISFACTION,   # Validates agentic conversation constraints
    METRIC_PARAMETER_VALUE_FORMAT_ALIGNMENT,   # Validates parameter format requirements
    METRIC_PARAMETER_HALLUCINATION_CHECK,      # Per-parameter hallucination detection
)
```

#### Custom Configuration Examples

##### Example 1: Function Selection Only
```python
from altk.pre_tool_reflection_toolkit.core import SPARCReflectionConfig

# Only validate function selection appropriateness
custom_config = SPARCReflectionConfig(
    general_metrics=None,
    function_metrics=[METRIC_FUNCTION_SELECTION_APPROPRIATENESS],
    parameter_metrics=None,
)

config = build_config()
middleware = SPARCReflectionComponent(
    config=config,
    custom_config=custom_config,  # Use custom config instead of track
    execution_mode=SPARCExecutionMode.ASYNC,
)
```

##### Example 2: Comprehensive Parameter Validation
```python
# Focus on parameter-level validation with hallucination detection
custom_config = SPARCReflectionConfig(
    general_metrics=None,
    function_metrics=None,
    parameter_metrics=[
        METRIC_PARAMETER_HALLUCINATION_CHECK,
        METRIC_PARAMETER_VALUE_FORMAT_ALIGNMENT,
    ],
)

middleware = SPARCReflectionComponent(
    config=config,
    custom_config=custom_config,
    execution_mode=SPARCExecutionMode.ASYNC,
)
```

##### Example 3: Minimal Agentic Validation
```python
# Only agentic constraints for multi-turn conversations
custom_config = SPARCReflectionConfig(
    general_metrics=None,
    function_metrics=[METRIC_AGENTIC_CONSTRAINTS_SATISFACTION],
    parameter_metrics=None,
)

middleware = SPARCReflectionComponent(
    config=config,
    custom_config=custom_config,
    execution_mode=SPARCExecutionMode.ASYNC,
)
```

##### Example 4: All Metrics (Maximum Validation)
```python
# Use all available metrics for maximum validation coverage
custom_config = SPARCReflectionConfig(
    general_metrics=[
        METRIC_GENERAL_HALLUCINATION_CHECK,
        METRIC_GENERAL_VALUE_FORMAT_ALIGNMENT,
    ],
    function_metrics=[
        METRIC_FUNCTION_SELECTION_APPROPRIATENESS,
        METRIC_AGENTIC_CONSTRAINTS_SATISFACTION,
    ],
    parameter_metrics=[
        METRIC_PARAMETER_HALLUCINATION_CHECK,
        METRIC_PARAMETER_VALUE_FORMAT_ALIGNMENT,
    ],
    transform_enabled=True,  # Enable transformations
)

middleware = SPARCReflectionComponent(
    config=config,
    custom_config=custom_config,
    execution_mode=SPARCExecutionMode.ASYNC,
)
```

#### Metric Categories

- **General Metrics**: Applied to the overall tool call context
  - `METRIC_GENERAL_HALLUCINATION_CHECK`: Detects fabricated or hallucinated information
  - `METRIC_GENERAL_VALUE_FORMAT_ALIGNMENT`: Validates parameter format requirements

- **Function Metrics**: Applied to function selection and appropriateness
  - `METRIC_FUNCTION_SELECTION_APPROPRIATENESS`: Validates function choice matches user intent
  - `METRIC_AGENTIC_CONSTRAINTS_SATISFACTION`: Validates adherence to agentic conversation constraints

- **Parameter Metrics**: Applied to individual parameters (executed per parameter)
  - `METRIC_PARAMETER_HALLUCINATION_CHECK`: Detects hallucinated parameter values
  - `METRIC_PARAMETER_VALUE_FORMAT_ALIGNMENT`: Validates parameter format requirements

#### When to Use Custom Configuration

- **Specific Requirements**: Your use case needs a unique combination of metrics
- **Performance Optimization**: You want to minimize LLM calls for specific metrics
- **Experimental Validation**: Testing different metric combinations
- **Domain-Specific Needs**: Certain metrics are more important for your domain
- **Cost Optimization**: Reducing LLM usage while maintaining necessary validation

## Validation Layers

### 1. Static Validation (Python-based, 100% accurate, fast)

Validates tool call structure without LLM calls:

- **JSON Schema Compliance**: Validates tool call structure against OpenAI function calling format
- **Type Validation**: Ensures parameter types match schema definitions
- **Required Parameters**: Verifies all mandatory parameters are present
- **Constraint Validation**: Checks min/max values, string lengths, enum values
- **Format Validation**: Validates email formats, date formats, etc.

**Example Issues Detected:**
```python
# Missing required parameter
{"to": ["user@example.com"]}  # Missing "subject" and "body"

# Type mismatch  
{"participants": "user@example.com"}  # Should be array, not string

# Constraint violation
{"priority": "urgent"}  # Not in enum ["low", "normal", "high"]
```

### 2. Semantic Analysis (LLM-based, configurable metrics)

LLM-powered evaluation of tool call appropriateness. Each metric is an LLM call that can be executed in parallel.

**Example Issues Detected:**
```python
# Intent misalignment
User: "What's the weather?"
Tool Call: book_flight(origin="JFK", destination="LAX")  # Wrong function

# Parameter grounding issue
User: "Call my mom at +1234567890"  
Tool Call: send_sms(phone_number="+9876543210")  # Different number

# Parameter hallucination
User: "Check weather in Miami"
Tool Call: get_weather(location="Miami Beach, FL, USA, Downtown District")  # Too specific
```

### 3. Transformation Validation (Code generation-based)

**LLM Calls**: 1 + N (where N = number of parameters requiring transformation)
**Execution**: All transformation checks can run in parallel

Advanced validation using code generation for parameter transformations:

#### Supported Transformations
- **Unit Conversions**: Temperature (F and C), distance (miles and km), weight (lbs and kg)
- **Custom Transformations**: Extensible framework for domain-specific conversions

#### How It Works
1. **Detection**: Identifies potential transformation needs in conversation (1 LLM call)
2. **Code Generation**: LLM generates Python code to perform transformation (per parameter)
3. **Execution**: Safely executes transformation code in sandboxed environment
4. **Validation**: Compares original vs transformed values
5. **Suggestion**: Provides corrected parameter values if transformation needed

**Example Transformations:**
```python
# Temperature conversion
User: "Set thermostat to 75 degrees"  # Assumes Fahrenheit in US context
Tool Spec: {"temperature": {"description": "Temperature in Celsius"}}
Transformation: 75°F → 23.9°C

# Distance conversion  
User: "Calculate travel time for 50 miles at 60 mph"
Tool Spec: {"distance_km": ..., "speed_kmh": ...}
Transformation: 50 miles → 80.47 km, 60 mph → 96.56 km/h
```

## Examples

### Static Validation Example

```python
# examples/static_issues_example.py
from altk.pre_tool_reflection_toolkit.core import Track, SPARCExecutionMode
from altk.pre_tool_reflection_toolkit.sparc import SPARCReflectionComponent

def run_static_validation():
    # Initialize with SYNTAX track for fast static validation
    middleware = SPARCReflectionComponent(
        track=Track.SYNTAX,
        execution_mode=SPARCExecutionMode.ASYNC,
    )
    
    # Example: Missing required parameters
    tool_call = {
        "id": "1",
        "type": "function",
        "function": {
            "name": "send_email",
            "arguments": '{"to": ["user@example.com"]}'
            # Missing required "subject" and "body"
        }
    }
    
    # Will detect: Missing required parameters "subject", "body"
```

### Semantic Validation Example

```python
# examples/semantic_issues_example.py
from altk.pre_tool_reflection_toolkit.core import Track, SPARCExecutionMode
from altk.pre_tool_reflection_toolkit.sparc import SPARCReflectionComponent
from langchain_core.messages import HumanMessage, AIMessage

def run_semantic_validation():
    # Initialize with FAST_TRACK for agentic conversation validation
    middleware = SPARCReflectionComponent(
        track=Track.FAST_TRACK,
        execution_mode=SPARCExecutionMode.ASYNC,
        model_path="meta-llama/llama-4-maverick-17b-128e-instruct-fp8",
    )
    
    # Example: Function selection misalignment
    conversation = [
        HumanMessage("What's the weather in New York?"),
        AIMessage("I'll check the weather for you.")
    ]
    
    tool_call = {
        "id": "1",
        "type": "function",
        "function": {
            "name": "book_flight",  # Wrong function for weather query
            "arguments": '{"origin": "JFK", "destination": "LAX"}'
        }
    }
    
    # Will detect: Function intent misalignment
```

### Units Conversion Example

```python
# examples/units_conversion_error_example.py
from altk.pre_tool_reflection_toolkit.core import Track, SPARCExecutionMode
from altk.pre_tool_reflection_toolkit.sparc import SPARCReflectionComponent
from langchain_core.messages import HumanMessage, AIMessage

def run_transformation_validation():
    # Initialize with TRANSFORMATIONS_ONLY track for unit conversion focus
    middleware = SPARCReflectionComponent(
        track=Track.TRANSFORMATIONS_ONLY,
        execution_mode=SPARCExecutionMode.ASYNC,
    )
    
    # Example: Temperature unit conversion
    conversation = [
        HumanMessage("Set thermostat to 75 degrees Fahrenheit"),
        AIMessage("I'll set the thermostat.")
    ]
    
    tool_call = {
        "id": "1",
        "type": "function",
        "function": {
            "name": "set_thermostat",
            "arguments": '{"temperature": 75.0, "location": "living room"}'
            # Should be ~24°C, not 75
        }
    }
    
    # Will detect: Temperature conversion needed (75°F → 23.9°C)
    # Will suggest: {"temperature": 23.9}
```

## API Reference

### Core Types

#### `SPARCReflectionConfig`
Configuration class for the middleware.

```python
class SPARCReflectionConfig(BaseModel):
    model_path: str = "meta-llama/llama-4-maverick-17b-128e-instruct-fp8"
    execution_mode: SPARCExecutionMode = SPARCExecutionMode.SYNC
    general_metrics: Optional[List[str]] = None
    function_metrics: Optional[List[str]] = None  
    parameter_metrics: Optional[List[str]] = None
    transform_enabled: bool = False
    verbose_logging: bool = False
    retries: int = 3  # For async mode
    max_parallel: int = 7  # For async mode
    # ... additional fields
```

#### `SPARCReflectionResult`
Result of the reflection analysis.

```python
class SPARCReflectionResult(BaseModel):
    decision: SPARCReflectionDecision  # APPROVE, REJECT, ERROR
    issues: List[SPARCReflectionIssue] = []
    
    @property
    def has_issues(self) -> bool:
        return len(self.issues) > 0
```

#### `SPARCReflectionIssue`
Individual issue found during validation.

```python
class SPARCReflectionIssue(BaseModel):
    issue_type: SPARCReflectionIssueType  # STATIC, SEMANTIC_*, TRANSFORM, ERROR
    metric_name: str
    explanation: str
    correction: Optional[Dict[str, Any]] = None
```

## Performance Considerations

### Async vs Sync Mode
```python
# Async mode - enables parallel execution of all metrics
config.execution_mode = SPARCExecutionMode.ASYNC
config.max_parallel = 7  # Control parallel execution limit
config.retries = 3  # Retry failed LLM calls

# Sync mode - sequential execution (slower but simpler)
config.execution_mode = SPARCExecutionMode.SYNC
```

## Error Handling

The middleware provides comprehensive error handling:

### Initialization Errors
```python
middleware = SPARCReflectionComponent(config=config)
if middleware._initialization_error:
    print(f"Initialization failed: {middleware._initialization_error}")
    # Handle initialization failure
```

### Runtime Errors
```python
result = middleware.process(run_input, phase=AgentPhase.RUNTIME)
if result.output.reflection_result.decision == SPARCReflectionDecision.ERROR:
    # Handle error case
    error_issues = [issue for issue in result.output.reflection_result.issues 
                   if issue.issue_type == SPARCReflectionIssueType.ERROR]
```

### Graceful Degradation
- Static validation failures can optionally continue to semantic checks (`continue_on_static=True`)
- Individual metric failures don't stop the entire pipeline
- Transformation errors fall back to original values with warnings
- Async mode includes automatic retry logic for failed LLM calls

## Testing

The middleware includes comprehensive test suites:

### Running Tests
```bash
# Run all tests
uv run pytest tests/pre-tool-reflection/

# Run specific test categories
uv run pytest tests/pre-tool-reflection/test_static_validation.py
uv run pytest tests/pre-tool-reflection/test_semantic_validation.py
uv run pytest tests/pre-tool-reflection/test_units_conversion.py
```

### Test Categories
- **Static Validation Tests**: Schema validation, type checking, constraint violations
- **Semantic Validation Tests**: Intent alignment, parameter grounding, hallucination detection
- **Units Conversion Tests**: Temperature, distance, and format transformation validation

## Troubleshooting

### Common Issues

#### 1. LLM Provider Authentication
```bash
# Ensure your LLM provider credentials are set
export WX_API_KEY="your-api-key"
export WX_PROJECT_ID="your-project-id"
export WX_URL="https://us-south.ml.cloud.ibm.com"
```

#### 2. Model Path Configuration
```python
# Use correct model identifiers for your provider
config.model_path = "meta-llama/llama-4-maverick-17b-128e-instruct-fp8"  # Watsonx
```

#### 3. Performance Optimization
```python
# For high-throughput scenarios
config.execution_mode = SPARCExecutionMode.ASYNC
config.max_parallel = 10  # Increase parallel limit
config.retries = 2  # Reduce retries for speed

# For accuracy-critical scenarios
config.execution_mode = SPARCExecutionMode.ASYNC
config.max_parallel = 5  # Moderate parallelism
config.retries = 5  # More retries for reliability
```

### Debug Mode
```python
config.verbose_logging = True
config.include_raw_response = True

# Check detailed pipeline results
result = middleware.process(run_input, phase=AgentPhase.RUNTIME)
if hasattr(result.output, 'raw_pipeline_result'):
    print(result.output.raw_pipeline_result)
```

## Contributing

### Development Setup
```bash
git clone ssh://git@github.ibm.com/AI4BA/agent-lifecycle-toolkit.git
cd agent-lifecycle-toolkit/pre-tool-reflection-toolkit
uv sync --dev
```

### Running Examples
```bash
# Run static validation examples
uv run python examples/static_issues_example.py

# Run semantic validation examples  
uv run python examples/semantic_issues_example.py

# Run transformation examples
uv run python examples/units_conversion_error_example.py
```

## Support

For questions and support:
- Create issues in the repository
- Contact the agentic middleware team
