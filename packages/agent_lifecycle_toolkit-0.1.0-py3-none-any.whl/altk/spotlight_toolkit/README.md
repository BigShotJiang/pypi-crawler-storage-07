## SpotLight

<p align="center">
<a href="https://arxiv.org/abs/2505.12025" target="_blank">
  <img src="https://img.shields.io/badge/arXiv link-SpotLight-blue" alt="arXiv paper badge" />
</a>
</p>

### Overview
SpotLight enables users to emphasize important spans within their prompt and steers the LLMs attention towards those spans. It is an inference-time hook and does not involve any training or changes to model weights.

> [!IMPORTANT]
> SpotLight only works with locally loaded HuggingFace Transformer models


### Installation

```bash
# Clone the repository
git clone ssh://git@github.ibm.com/AI4BA/agent-lifecycle-toolkit.git
cd agent-lifecycle-toolkit/spotlight-toolkit

# Create a virtual environment using uv (recommended)
uv venv
uv pip install -e .
```

### Usage

1. Initialize the SpotLight config and middleware objects.
```python
from altk.spotlight_toolkit.core.config import SpotLightConfig
from altk.spotlight_toolkit.spotlight.spotlight import SpotLightComponent

# SpotLightConfig accepts the HF model path and generation arguments
config = SpotLightConfig(model_path="Qwen/Qwen2.5-1.5B-Instruct",
                         generation_kwargs={
                            'max_new_tokens=': 128,
                            'do_sample': False,
                            'device': 'cpu'
                             }
                         )
spotlight = SpotLightComponent(config=config)
```

2. Define the input messages and spans within the prompt to emphasize. Provide these while running SpotLight, along with an optional `alpha` parameter, that defines the amount of emphasis the LLM should place on the span.
> [!NOTE]
> To maintain consistency with the rest of this framework, we use Langchain's message format. SpotLight does support the traditional HF chat format as well.

```python
from langchain_core.messages import HumanMessage, AIMessage
from altk.toolkit_core.core.toolkit import AgentPhase
from altk.spotlight_toolkit.core.config import SpotLightMetadata, SpotLightRunInput

messages = [HumanMessage(content="List the capitals of the following countries - USA, Italy, Greece. Always give me the answer in JSON format.")]
emph_span = ["Always give me the answer in JSON format."]

run_input = SpotLightRunInput(
    messages=messages,
    metadata=SpotLightMetadata(emph_strings=emph_span, alpha=0.1),
)
result = spotlight.process(run_input, phase=AgentPhase.RUNTIME)
prediction = result.output.prediction
print(prediction)
```
> [!NOTE]
> If the emphasized span is not present in the prompt, SpotLight will raise an error

```bash
"""
{
  "capitals": {
    "USA": "Washington D.C.",
    "Italy": "Rome",
    "Greece": "Athens"
  }
}
"""
```

> [!TIP]
> You can emphasize multiple spans by providing them as a list of lists -- `emph_span = [[span_1], [span_2]]`
> If given an empty emphasis list, SpotLight returns the baseline model prediction
<img width="800" alt="image" src="https://github.ibm.com/AI4BA/agent-lifecycle-toolkit/blob/main/spotlight-toolkit/SpotLight_Infographic.jpeg">

