"""Test data module

.. autofunction:: load_test_data
"""

from acres import Loader

load_test_data = Loader(__package__)
