"""Core functionality for the simple port checker package."""
