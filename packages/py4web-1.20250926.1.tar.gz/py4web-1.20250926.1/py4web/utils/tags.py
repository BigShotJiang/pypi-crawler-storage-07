import logging

logging.warning(
    "Deprecation notice: replace py4web.utils.tags with pydal.tools.tags in your code."
)
