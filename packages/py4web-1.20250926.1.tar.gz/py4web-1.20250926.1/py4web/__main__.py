# allow py4web to be run as a module
# this file is called when running "python -m py4web"
from py4web.core import cli

cli()
