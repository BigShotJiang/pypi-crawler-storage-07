"""Module with common resources."""
