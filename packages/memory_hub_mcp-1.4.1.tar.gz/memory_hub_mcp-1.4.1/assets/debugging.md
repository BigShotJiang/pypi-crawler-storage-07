Installed 37 packages in 72ms
INFO:memory_hub.cli:Starting Memory Hub MCP Server (stdio mode) with config: AppConfig(qdrant_url=None, lm_studio_url=None, qdrant_client=None, http_client=None)
INFO:httpx:HTTP Request: GET http://localhost:6333 "HTTP/1.1 200 OK"
INFO:httpx:HTTP Request: GET http://localhost:6333/collections "HTTP/1.1 200 OK"
INFO: Collection 'ai_memory_hub_v1' already exists.
INFO:memory_hub.mcp_server:Memory Hub core services initialized
INFO:memory_hub.mcp_server:Memory Hub MCP Server starting with stdio transport
^C^CINFO: HTTP client closed.
INFO: Qdrant client closed.
INFO:memory_hub.mcp_server:Shutdown complete.
INFO:memory_hub.cli:Shutdown complete
Exception ignored in: <module 'threading' from '/Users/wontseemecomin/.local/share/uv/python/cpython-3.12.11-macos-aarch64-none/lib/python3.12/threading.py'>
Traceback (most recent call last):
  File "/Users/wontseemecomin/.local/share/uv/python/cpython-3.12.11-macos-aarch64-none/lib/python3.12/threading.py", line 1624, in _shutdown
    lock.acquire()
KeyboardInterrupt: 
Fatal Python error: _enter_buffered_busy: could not acquire lock for <_io.BufferedReader name='<stdin>'> at interpreter shutdown, possibly due to daemon threads
Python runtime state: finalizing (tstate=0x00000001064f31c8)

Current thread 0x0000000202375f00 (most recent call first):
  <no Python frame>