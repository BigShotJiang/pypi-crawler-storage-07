PASS = "🟢 PASS"
FAIL = "❌ FAIL"
NA = "⚪ N/A"

FILE_NAME = "automatic_sw_ut_result"
