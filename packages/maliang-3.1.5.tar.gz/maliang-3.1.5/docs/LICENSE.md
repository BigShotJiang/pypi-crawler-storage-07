---
icon: octicons/law-24
---

--8<-- "LICENSE.txt"
