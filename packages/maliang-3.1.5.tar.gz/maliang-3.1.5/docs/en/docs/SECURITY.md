---
icon: octicons/law-24
---

--8<-- "docs/SECURITY.md:4"
