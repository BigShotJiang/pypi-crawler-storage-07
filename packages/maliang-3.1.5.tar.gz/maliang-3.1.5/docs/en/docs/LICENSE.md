---
icon: octicons/law-16
---

--8<-- "docs/LICENSE.md:4"
