---
icon: octicons/comment-discussion-24
---

加入群聊，咨询更多信息！(1)
{ .annotate }

1. 能找到这里来，你可以的啊！顺便偷偷告诉你进群的答案就是`tkinter`！:)

=== ":fontawesome-brands-qq:{ .middle } QQ 群"

    <div align="center">
        <img src="../share.dark.png#only-dark" width=360 />
        <img src="../share.light.png#only-light" width=360 />
    </div>

=== "其它"

    !!! failure "还没有哦"

        敬请期待！
