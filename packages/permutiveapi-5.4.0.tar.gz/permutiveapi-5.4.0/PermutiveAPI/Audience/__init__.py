"""Audience API endpoint constants."""

_API_VERSION = "v1"
_API_ENDPOINT = f"https://api.permutive.app/audience-api/{_API_VERSION}/imports"
