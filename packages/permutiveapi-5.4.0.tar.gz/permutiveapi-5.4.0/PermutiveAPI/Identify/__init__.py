"""Identify API endpoint constants."""

_API_VERSION = "v2.0"
_API_ENDPOINT = f"https://api.permutive.com/{_API_VERSION}/identify"
