
VERSION = (1, 1, 4)

__author__ = "Nathaniel Albright"
__email__ = "developer@3dcg.guru"
__version__ = '.'.join(map(str, VERSION))