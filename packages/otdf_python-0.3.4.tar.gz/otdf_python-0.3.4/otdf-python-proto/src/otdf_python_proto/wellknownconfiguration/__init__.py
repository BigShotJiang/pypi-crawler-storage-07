"""wellknownconfiguration protobuf definitions."""
