"""entityresolution protobuf definitions."""
