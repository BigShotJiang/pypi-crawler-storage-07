from mcp_server_gaokao import main

# Make the package executable as a script by running `python -m mcp_server_gaokao` or `uv run -m mcp_server_gaokao`
if __name__ == "__main__":
    main()
