# Bundles
## "The only bundle of imports you'll ever need."

"**bundles**" is a python module I made, intended to help in mass imports. If you are going to simply need only one to five imports, **don't use bundles**. 

### BUT

If you think you'll be needing alot of imports, or don't care being an import over, **use bundles**.

# Bundles
## "The only bundle of imports you'll ever need."

