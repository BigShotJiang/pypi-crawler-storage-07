# -*- coding: utf-8 -*-

from .caster import lambda_caster

caster = lambda_caster

__version__ = "1.40.0"