"""Evaluator implementations for risk evaluation rules."""
