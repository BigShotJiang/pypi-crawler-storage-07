===============
Code of Conduct
===============

All contributors, maintainers, and users are expected to uphold standards of respectful and inclusive behavior in all project spaces.

A full Code of Conduct will be added here soon. In the meantime, please:

- Be respectful and considerate in all communications
- Collaborate in a welcoming and inclusive manner
- Report any unacceptable behavior to the project maintainers

Thank you for helping make this project a welcoming space for everyone!
