=========
Changelog
=========

Sources to write the changelog:

- https://keepachangelog.com/en/1.0.0/
- https://semver.org/


v0.2.0 - 2025-09-26
===================

Added
-----
- Support to transform image paths
- Support for robust source path processing (docs = /docs = docs/ = /docs/)
- gifs and new link to read the docs

Changed
-------
- List of prefixes into a single prefix (the relative paht to the root of the documentaion)

Fixed
-----
- Deprecation warning. traverse -> findall

v0.1.4 - 2025-09-25
===================

Added
-----
- Support to latexpdf

v0.1.3 - 2025-09-25
===================

Fixed
-----
- More pyproject classifiers

v0.1.2 - 2025-09-25
===================

Fixed
-----
- Pyproject classifiers

v0.1.1 - 2025-09-25
===================

Fixed
-----
- Readme underline

v0.1.0 - 2025-09-24
===================

Added
-----
- Main functionality for the plugin
- Tests for the plugin
- Project boilerplate

v0.0
====
