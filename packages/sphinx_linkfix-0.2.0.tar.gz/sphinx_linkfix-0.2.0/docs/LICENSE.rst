=======
License
=======

.. include:: ../LICENSE.txt
