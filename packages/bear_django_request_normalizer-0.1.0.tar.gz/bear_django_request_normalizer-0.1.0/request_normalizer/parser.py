import json
import logging
from io import BytesIO
from django.http import QueryDict

logger = logging.getLogger(__name__)


def normalize_request_data(request):
    if request.method in ['POST', 'PUT', 'PATCH', 'DELETE']:
        data = _get_request_data(request)
        normalized_data = _normalize_data(data)
        request._request_params = normalized_data
        _rebuild_request(request, normalized_data)
    elif request.method == 'GET':
        query_params = request.GET.copy()
        normalized_data = _normalize_data(query_params)
        request._request_params = normalized_data
        request.GET = normalized_data


def _get_request_data(request):
    if request.POST or request.FILES:
        return request.POST

    try:
        if request.body:
            return json.loads(request.body.decode('utf-8'))
    except json.JSONDecodeError:
        logger.warning("Failed to decode JSON body.", exc_info=True)

    return {}


def _normalize_data(data):
    if not data:
        return QueryDict() if isinstance(data, QueryDict) else {}

    if isinstance(data, QueryDict):
        result = QueryDict(mutable=True)
        for key in data.keys():
            for value in data.getlist(key):
                result.appendlist(key, _normalize_value(key, value))
        return result

    if isinstance(data, dict):
        return _normalize_dict(data)

    return data


def _normalize_dict(data):
    result = {}
    for key, value in data.items():
        if isinstance(value, list):
            processed_values = []
            for item in value:
                processed_value = _normalize_dict(item) if isinstance(item, dict) else _normalize_value(key, item)
                if processed_value is not None:
                    processed_values.append(processed_value)
            result[key] = processed_values
        else:
            result[key] = _normalize_value(key, value)
    return result


def _normalize_value(key, value):
    is_id_field = key.endswith('_id') or key == 'id' or key.replace("]", "").endswith('id')

    if isinstance(value, int) and not isinstance(value, bool) and value == 0 and is_id_field:
        return None

    if isinstance(value, str):
        stripped_value = value.strip()
        lower_value = stripped_value.lower()

        if lower_value == 'null': return None
        if lower_value == 'true': return True
        if lower_value == 'false': return False
        if is_id_field and (stripped_value == '0' or stripped_value == ''): return None

        if key == 'email' and stripped_value:
            return stripped_value.replace(' ', '').lower()

        return stripped_value

    return value


def _rebuild_request(request, normalized_data):
    content_type = request.content_type.lower()

    if 'application/json' in content_type:
        body = json.dumps(normalized_data).encode('utf-8')
        request._body = body
        request._stream = BytesIO(body)
    elif 'multipart/form-data' in content_type:
        request.POST = QueryDict('', mutable=True)
        request.POST.update(normalized_data)
    elif 'application/x-www-form-urlencoded' in content_type:
        request.POST = normalized_data if isinstance(normalized_data, QueryDict) else QueryDict(mutable=True).update(normalized_data)