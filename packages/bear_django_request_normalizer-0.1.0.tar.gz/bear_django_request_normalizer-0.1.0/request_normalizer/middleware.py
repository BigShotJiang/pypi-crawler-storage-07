from django.conf import settings
from .parser import normalize_request_data


class RequestNormalizerMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
        self.enabled = getattr(settings, 'REQUEST_NORMALIZER_ENABLE', True)
        self.prefixes = getattr(settings, 'REQUEST_NORMALIZER_PREFIXES', [])

    def __call__(self, request):
        if self.enabled and not hasattr(request, '_is_normalized') and any(request.path.startswith(prefix) for prefix in self.prefixes):
            normalize_request_data(request)
            request._is_normalized = True

        return self.get_response(request)