# -*- coding: utf-8 -*-

from .caster import elasticbeanstalk_caster

caster = elasticbeanstalk_caster

__version__ = "1.40.0"