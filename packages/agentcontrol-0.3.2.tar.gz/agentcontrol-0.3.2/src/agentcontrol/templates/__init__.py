"""Embedded project templates."""
