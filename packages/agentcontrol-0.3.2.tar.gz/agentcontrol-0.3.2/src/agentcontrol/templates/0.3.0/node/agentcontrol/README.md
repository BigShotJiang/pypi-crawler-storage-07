# AgentControl Universal Agent SDK — Node.js Capsule

This template bundles the AgentControl SDK capsule for Node.js projects. The SDK infrastructure is contained within `agentcontrol/`, while the rest of the repository remains untouched.

## Quick Start
1. Install global prerequisites and `agentcall` (see the top-level README).
2. Bootstrap the capsule:
   ```bash
   agentcall status /path/to/project
   agentcall init --template node /path/to/project
   ```
3. Install dependencies and prepare the workspace:
   ```bash
   cd /path/to/project
   agentcall setup
   ```
4. Execute the verification pipeline:
   ```bash
   agentcall verify
   ```

## Automatic Updates
- `agentcall` checks PyPI every few hours and upgrades itself before running commands when a newer release is published.
- Disable on demand via `AGENTCONTROL_DISABLE_AUTO_UPDATE=1` or `AGENTCONTROL_AUTO_UPDATE=0`.
- Choose updater (`pip` default, `pipx` alternative) with `AGENTCONTROL_AUTO_UPDATE_MODE`; after a successful upgrade CLI exits so you can rerun the command.

## Node.js specifics
- Commands operate from `agentcontrol/` and rely on npm scripts.
- Verification runs `npm install`, `npm run lint`, and `npm test`.
- Fix pipeline applies `npm run lint -- --fix`.
- Release pipeline runs `npm run build` (customise as required).

Refer to the root documentation for the full command reference and operational policies.
