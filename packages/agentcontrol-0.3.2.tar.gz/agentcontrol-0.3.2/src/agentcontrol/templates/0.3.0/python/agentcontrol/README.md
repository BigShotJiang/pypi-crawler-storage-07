# AgentControl Universal Agent SDK — Python Capsule

This template provisions the AgentControl SDK capsule for Python services. All SDK artefacts live inside `agentcontrol/`, while the host repository remains untouched.

## Quick Start
1. Install global prerequisites and the AgentControl CLI (see top-level README).
2. Initialise the capsule:
   ```bash
   agentcall init --template python /path/to/project
   # optional auto-bootstrap
   AGENTCONTROL_AUTO_INIT=1 agentcall status /path/to/project
   ```
3. Create and seed the local virtualenv within the capsule:
   ```bash
   cd /path/to/project
   agentcall setup
   ```
4. Run the verification pipeline:
   ```bash
   agentcall verify
   ```

## Automatic Updates
- `agentcall` checks PyPI every few hours and upgrades itself before running commands when a newer release is published.
- Disable on demand via `AGENTCONTROL_DISABLE_AUTO_UPDATE=1` or `AGENTCONTROL_AUTO_UPDATE=0`.
- Choose updater (`pip` default, `pipx` alternative) with `AGENTCONTROL_AUTO_UPDATE_MODE`; after a successful upgrade CLI exits so you can rerun the command.

## Python specifics
- Virtual environment resides in `agentcontrol/.venv`.
- Dependencies are pinned via `agentcontrol/requirements.txt` and `requirements.lock`.
- `SDK_VERIFY_COMMANDS` executes pytest; exit code 5 (no tests collected) is treated as success.

Refer to the root documentation for the full command surface, governance model, and operations charter.
