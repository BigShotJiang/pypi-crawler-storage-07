#pragma once

namespace ext
{
    enum class MyEnum2
    {
        V0, V1, V2, V3
    };
}