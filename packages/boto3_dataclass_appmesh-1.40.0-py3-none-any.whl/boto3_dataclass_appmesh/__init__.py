# -*- coding: utf-8 -*-

from .caster import appmesh_caster

caster = appmesh_caster

__version__ = "1.40.0"