"""Nautobot ChatOps Sockets."""
