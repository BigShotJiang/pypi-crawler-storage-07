from .file_of_test import main

if __name__ == "__main__":
    main()