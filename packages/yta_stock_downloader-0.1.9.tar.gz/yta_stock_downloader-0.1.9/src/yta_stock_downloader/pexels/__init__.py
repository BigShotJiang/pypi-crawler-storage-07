"""
TODO: Include the functionality related to
Pexels platform, as simple functions, that
are able to get and download images and videos.
"""
__all__ = []