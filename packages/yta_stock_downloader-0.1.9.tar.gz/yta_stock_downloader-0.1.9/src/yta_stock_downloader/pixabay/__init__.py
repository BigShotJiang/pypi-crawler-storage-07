"""
# TODO: Include the functionality related to
Pixabay platform, as simple functions, that
are able to get and download images and videos.
"""

__all__ = []