# Youtube Autónomo Stock Utils

The stock software we need to interact with the *Youtube Autónomo* project.

This project needs `.env` variables:
- Variable `PEXELS_API_KEY` need to be set to be able to fetch and download Pexels videos and images.
- Variable `PIXABAY_API_KEY` need to be set to be able to fetch and download Pixabay videos and images.