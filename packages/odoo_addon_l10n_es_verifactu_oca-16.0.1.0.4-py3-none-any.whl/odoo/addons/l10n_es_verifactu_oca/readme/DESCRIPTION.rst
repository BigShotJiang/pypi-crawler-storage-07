Módulo para la presentación inmediata de la facturación.
