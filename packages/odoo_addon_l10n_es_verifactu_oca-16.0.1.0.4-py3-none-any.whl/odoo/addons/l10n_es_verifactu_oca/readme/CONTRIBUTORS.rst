* Aures TIC:
  * Jose Zambudio
  * Almudena de La Puente
  * Anna Martínez
* ForgeFlow S.L.:
  * Laura Cazorla
  * Andreu Orensanz
  * Jordi Ballester
* Ozono multimedia:
  * Iván Antón
* SDi:
  * Fernando La Chica
* Process control:
  * Jorge Luis López
* Tecnativa:
  * Pedro M. Baeza
