from .base import Head
from .lm import LMHead

__all__ = ["LMHead", "Head"]
