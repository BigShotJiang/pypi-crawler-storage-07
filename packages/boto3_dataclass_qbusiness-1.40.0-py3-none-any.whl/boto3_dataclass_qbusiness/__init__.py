# -*- coding: utf-8 -*-

from .caster import qbusiness_caster

caster = qbusiness_caster

__version__ = "1.40.0"