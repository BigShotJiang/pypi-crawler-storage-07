=======
Credits
=======

Development Lead
----------------

Dominik Zuercher <dominik.zuercher@phys.ethz.ch>
Silvan Fischbacher <silvanf@phys.ethz.ch>

Previous Developers
-------------------

We thank Joerg Herbel for his valuable work on the project and a lot of helpful discussions.
