This addon limits payment mode selection in contract to the brand's allowed.
