mod converter;

use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use std::path::PathBuf;

#[pyfunction]
#[pyo3(signature = (input_path, output_path, batch_size=10000, compression=None, json_path=None, schema_mode=None, schema_infer_rows=None, schema_json=None))]
fn convert_json_to_parquet(
    input_path: String,
    output_path: String,
    batch_size: usize,
    compression: Option<String>,
    json_path: Option<String>,
    schema_mode: Option<String>,
    schema_infer_rows: Option<usize>,
    schema_json: Option<String>,
) -> PyResult<()> {
    let input = PathBuf::from(input_path);
    let output = PathBuf::from(output_path);

    if !input.exists() {
        return Err(PyValueError::new_err(format!(
            "Input file does not exist: {:?}",
            input
        )));
    }

    let compression_type = compression.as_deref().unwrap_or("snappy");

    converter::convert(
        &input,
        &output,
        batch_size,
        compression_type,
        json_path.as_deref(),
        schema_mode.as_deref(),
        schema_infer_rows,
        schema_json.as_deref(),
    )
    .map_err(|e| PyValueError::new_err(format!("Conversion failed: {}", e)))?;

    Ok(())
}

#[pymodule]
fn _native(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(convert_json_to_parquet, m)?)?;
    Ok(())
}
