use arrow::datatypes::{DataType, Field, Schema};
use arrow_json::reader::ReaderBuilder as JsonReaderBuilder;
use parquet::arrow::ArrowWriter;
use parquet::basic::{Compression, ZstdLevel};
use parquet::file::properties::WriterProperties;
use serde::de::{self, DeserializeSeed, MapAccess, SeqAccess, Visitor};
use serde::Deserialize;
use serde_json::{Deserializer, Value};
use std::collections::HashMap;
use std::fs::File;
use std::io::{BufReader, BufWriter, Write};
use std::path::Path;
use std::sync::Arc;
use tempfile::NamedTempFile;
use thiserror::Error;

#[derive(Error, Debug)]
pub enum ConversionError {
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),
    #[error("JSON error: {0}")]
    Json(#[from] serde_json::Error),
    #[error("Arrow error: {0}")]
    Arrow(#[from] arrow::error::ArrowError),
    #[error("Parquet error: {0}")]
    Parquet(#[from] parquet::errors::ParquetError),
    #[error("Schema inference failed: {0}")]
    SchemaInference(String),
}

pub fn convert(
    input_path: &Path,
    output_path: &Path,
    batch_size: usize,
    compression: &str,
    json_path: Option<&str>,
    schema_mode: Option<&str>,
    schema_infer_rows: Option<usize>,
    schema_json: Option<&str>,
) -> Result<(), ConversionError> {
    let ndjson_tmp = preprocess_to_ndjson(input_path, json_path)?;
    let ndjson_path = ndjson_tmp.path().to_path_buf();

    let schema = if let Some(s) = schema_json {
        parse_schema_json(s)?
    } else {
        match schema_mode.unwrap_or("sample") {
            "full" => infer_schema_full(&ndjson_path)?,
            _ => infer_schema_sample(&ndjson_path, schema_infer_rows.unwrap_or(10_000))?,
        }
    };
    let input_file = File::open(&ndjson_path)?;
    let reader = BufReader::with_capacity(1024 * 1024, input_file);

    let compression = match compression {
        "snappy" => Compression::SNAPPY,
        "gzip" => Compression::GZIP(parquet::basic::GzipLevel::default()),
        "lz4" => Compression::LZ4,
        "zstd" => Compression::ZSTD(ZstdLevel::default()),
        "uncompressed" | "none" => Compression::UNCOMPRESSED,
        _ => Compression::SNAPPY,
    };

    let props = WriterProperties::builder()
        .set_compression(compression)
        .set_max_row_group_size(batch_size)
        .build();

    let output_file = File::create(output_path)?;
    let writer = BufWriter::with_capacity(1024 * 1024, output_file);

    let mut arrow_writer = ArrowWriter::try_new(writer, Arc::clone(&schema), Some(props))?;

    let mut json_reader = JsonReaderBuilder::new(Arc::clone(&schema))
        .with_batch_size(batch_size)
        .build(reader)?;

    while let Some(batch) = json_reader.next() {
        let batch = batch?;
        arrow_writer.write(&batch)?;
    }

    arrow_writer.close()?;

    Ok(())
}

fn infer_schema_sample(ndjson_path: &Path, rows: usize) -> Result<Arc<Schema>, ConversionError> {
    use std::io::BufRead;
    let file = File::open(ndjson_path)?;
    let reader = BufReader::with_capacity(1024 * 1024, file);
    let mut fields: HashMap<String, DataType> = HashMap::new();
    for (i, line_res) in reader.lines().enumerate() {
        if i >= rows {
            break;
        }
        let line = line_res?;
        if line.trim().is_empty() {
            continue;
        }
        let value: Value = serde_json::from_str(&line)?;
        if let Value::Object(map) = value {
            for (k, v) in map.iter() {
                let dt = infer_type(v);
                fields
                    .entry(k.clone())
                    .and_modify(|e| *e = merge_types(e, &dt))
                    .or_insert(dt);
            }
        }
    }
    if fields.is_empty() {
        return Err(ConversionError::SchemaInference(
            "No data found for schema inference".into(),
        ));
    }
    let arrow_fields: Vec<Field> = fields
        .into_iter()
        .map(|(n, dt)| Field::new(n, dt, true))
        .collect();
    Ok(Arc::new(Schema::new(arrow_fields)))
}

fn infer_schema_full(ndjson_path: &Path) -> Result<Arc<Schema>, ConversionError> {
    use std::io::BufRead;
    let file = File::open(ndjson_path)?;
    let reader = BufReader::with_capacity(1024 * 1024, file);
    let mut fields: HashMap<String, DataType> = HashMap::new();
    for line_res in reader.lines() {
        let line = line_res?;
        if line.trim().is_empty() {
            continue;
        }
        let value: Value = serde_json::from_str(&line)?;
        if let Value::Object(map) = value {
            for (k, v) in map.iter() {
                let dt = infer_type(v);
                fields
                    .entry(k.clone())
                    .and_modify(|e| *e = merge_types(e, &dt))
                    .or_insert(dt);
            }
        }
    }
    if fields.is_empty() {
        return Err(ConversionError::SchemaInference(
            "No data found for schema inference".into(),
        ));
    }
    let arrow_fields: Vec<Field> = fields
        .into_iter()
        .map(|(n, dt)| Field::new(n, dt, true))
        .collect();
    Ok(Arc::new(Schema::new(arrow_fields)))
}

fn infer_type(value: &Value) -> DataType {
    match value {
        Value::Bool(_) => DataType::Boolean,
        Value::Number(n) => {
            if n.as_i64().is_some() {
                DataType::Int64
            } else {
                DataType::Float64
            }
        }
        Value::String(_) => DataType::Utf8,
        Value::Null => DataType::Null,
        Value::Array(arr) => {
            if let Some(first) = arr.first() {
                DataType::List(Arc::new(Field::new("item", infer_type(first), true)))
            } else {
                DataType::List(Arc::new(Field::new("item", DataType::Null, true)))
            }
        }
        Value::Object(map) => {
            let fields: Vec<Field> = map
                .iter()
                .map(|(k, v)| Field::new(k, infer_type(v), true))
                .collect();
            DataType::Struct(fields.into())
        }
    }
}

fn merge_types(existing: &DataType, new: &DataType) -> DataType {
    if existing == new {
        return existing.clone();
    }

    match (existing, new) {
        (DataType::Null, other) | (other, DataType::Null) => other.clone(),

        (DataType::Int64, DataType::Float64)
        | (DataType::Float64, DataType::Int64)
        | (DataType::UInt64, DataType::Float64)
        | (DataType::Float64, DataType::UInt64)
        | (DataType::Int64, DataType::UInt64)
        | (DataType::UInt64, DataType::Int64) => DataType::Float64,

        (DataType::List(a), DataType::List(b)) => {
            let merged = merge_types(a.data_type(), b.data_type());
            DataType::List(Arc::new(Field::new("item", merged, true)))
        }

        (DataType::Struct(a_fields), DataType::Struct(b_fields)) => {
            let mut field_map: HashMap<String, DataType> = HashMap::new();
            for f in a_fields.iter() {
                field_map.insert(f.name().clone(), f.data_type().clone());
            }
            for f in b_fields.iter() {
                field_map
                    .entry(f.name().clone())
                    .and_modify(|dt| *dt = merge_types(dt, f.data_type()))
                    .or_insert_with(|| f.data_type().clone());
            }
            let merged_fields: Vec<Field> = field_map
                .into_iter()
                .map(|(name, dt)| Field::new(name, dt, true))
                .collect();
            DataType::Struct(merged_fields.into())
        }

        (DataType::Utf8, _) | (_, DataType::Utf8) => DataType::Utf8,

        _ => DataType::Utf8,
    }
}

fn parse_schema_json(s: &str) -> Result<Arc<Schema>, ConversionError> {
    let v: Value = serde_json::from_str(s)?;
    let schema = match v {
        Value::Object(mut m) => {
            if let Some(fields_v) = m.remove("fields") {
                let fields = parse_fields_array(&fields_v)?;
                Schema::new(fields)
            } else {
                return Err(ConversionError::SchemaInference(
                    "schema JSON must contain 'fields'".into(),
                ));
            }
        }
        _ => {
            return Err(ConversionError::SchemaInference(
                "schema JSON must be an object".into(),
            ))
        }
    };
    Ok(Arc::new(schema))
}

fn parse_fields_array(v: &Value) -> Result<Vec<Field>, ConversionError> {
    let arr = v
        .as_array()
        .ok_or_else(|| ConversionError::SchemaInference("'fields' must be an array".into()))?;
    let mut out = Vec::with_capacity(arr.len());
    for f in arr {
        out.push(parse_field(f)?);
    }
    Ok(out)
}

fn parse_field(v: &Value) -> Result<Field, ConversionError> {
    let m = v
        .as_object()
        .ok_or_else(|| ConversionError::SchemaInference("field must be an object".into()))?;
    let name = m
        .get("name")
        .and_then(|x| x.as_str())
        .ok_or_else(|| ConversionError::SchemaInference("field missing name".into()))?;
    let dtype_v = m
        .get("type")
        .ok_or_else(|| ConversionError::SchemaInference("field missing type".into()))?;
    let dtype = parse_type(dtype_v)?;
    Ok(Field::new(name, dtype, true))
}

fn parse_type(v: &Value) -> Result<DataType, ConversionError> {
    match v {
        Value::String(s) => match s.as_str() {
            "boolean" | "bool" => Ok(DataType::Boolean),
            "int64" | "long" => Ok(DataType::Int64),
            "float64" | "double" | "number" => Ok(DataType::Float64),
            "utf8" | "string" => Ok(DataType::Utf8),
            other => Err(ConversionError::SchemaInference(format!(
                "unsupported primitive type: {}",
                other
            ))),
        },
        Value::Object(m) => {
            if let Some(elem) = m.get("list") {
                let elem_type = parse_type(elem)?;
                Ok(DataType::List(Arc::new(Field::new(
                    "item", elem_type, true,
                ))))
            } else if let Some(fields) = m.get("struct") {
                let fields = parse_fields_array(fields)?;
                Ok(DataType::Struct(fields.into()))
            } else if let (Some(t), Some(element)) = (m.get("type"), m.get("element")) {
                if t == "list" {
                    return Ok(DataType::List(Arc::new(Field::new(
                        "item",
                        parse_type(element)?,
                        true,
                    ))));
                }
                Err(ConversionError::SchemaInference(
                    "unsupported complex type object".into(),
                ))
            } else if let (Some(t), Some(fields)) = (m.get("type"), m.get("fields")) {
                if t == "struct" {
                    return Ok(DataType::Struct(parse_fields_array(fields)?.into()));
                }
                Err(ConversionError::SchemaInference(
                    "unsupported complex type object".into(),
                ))
            } else {
                Err(ConversionError::SchemaInference(
                    "unsupported type object".into(),
                ))
            }
        }
        _ => Err(ConversionError::SchemaInference("invalid type spec".into())),
    }
}

fn preprocess_to_ndjson(
    input_path: &Path,
    json_path: Option<&str>,
) -> Result<NamedTempFile, ConversionError> {
    let input_file = File::open(input_path)?;
    let reader = BufReader::with_capacity(1024 * 1024, input_file);
    let mut de = Deserializer::from_reader(reader);

    let mut tmp = NamedTempFile::new()?;
    let mut writer = BufWriter::with_capacity(1024 * 1024, tmp.as_file_mut());

    if let Some(path) = json_path {
        let segments: Vec<&str> = path.split('.').filter(|s| !s.is_empty()).collect();
        loop {
            let seed = PathEmitterSeed {
                segments: &segments,
                writer: &mut writer,
            };
            match seed.deserialize(&mut de) {
                Ok(()) => {}
                Err(e) if e.is_eof() => break,
                Err(e) => return Err(ConversionError::Json(e)),
            }
        }
    } else {
        loop {
            let seed = RootEmitterSeed {
                writer: &mut writer,
            };
            match seed.deserialize(&mut de) {
                Ok(()) => {}
                Err(e) if e.is_eof() => break,
                Err(e) => return Err(ConversionError::Json(e)),
            }
        }
    }

    writer.flush()?;
    drop(writer);
    Ok(tmp)
}

struct RootEmitterSeed<'a, W: Write> {
    writer: &'a mut W,
}

impl<'de, 'a, W: Write> DeserializeSeed<'de> for RootEmitterSeed<'a, W> {
    type Value = ();
    fn deserialize<D>(self, deserializer: D) -> Result<Self::Value, D::Error>
    where
        D: de::Deserializer<'de>,
    {
        deserializer.deserialize_any(RootEmitter {
            writer: self.writer,
        })
    }
}

struct RootEmitter<'a, W: Write> {
    writer: &'a mut W,
}

impl<'de, 'a, W: Write> Visitor<'de> for RootEmitter<'a, W> {
    type Value = ();
    fn expecting(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        f.write_str("root JSON value")
    }

    fn visit_seq<A>(self, mut seq: A) -> Result<Self::Value, A::Error>
    where
        A: SeqAccess<'de>,
    {
        while let Some(val) = seq.next_element::<Value>()? {
            serde_json::to_writer(&mut *self.writer, &val).map_err(de::Error::custom)?;
            self.writer.write_all(b"\n").map_err(de::Error::custom)?;
        }
        Ok(())
    }

    fn visit_map<A>(self, mut map: A) -> Result<Self::Value, A::Error>
    where
        A: MapAccess<'de>,
    {
        let mut obj = serde_json::Map::new();
        while let Some((k, v)) = map.next_entry::<String, Value>()? {
            obj.insert(k, v);
        }
        serde_json::to_writer(&mut *self.writer, &Value::Object(obj)).map_err(de::Error::custom)?;
        self.writer.write_all(b"\n").map_err(de::Error::custom)?;
        Ok(())
    }
}

struct PathEmitterSeed<'a, 'w, W: Write> {
    segments: &'a [&'a str],
    writer: &'w mut W,
}

impl<'de, 'a, 'w, W: Write> DeserializeSeed<'de> for PathEmitterSeed<'a, 'w, W> {
    type Value = ();
    fn deserialize<D>(self, deserializer: D) -> Result<Self::Value, D::Error>
    where
        D: de::Deserializer<'de>,
    {
        deserializer.deserialize_any(PathEmitter {
            segments: self.segments,
            writer: self.writer,
        })
    }
}

struct PathEmitter<'a, 'w, W: Write> {
    segments: &'a [&'a str],
    writer: &'w mut W,
}

impl<'de, 'a, 'w, W: Write> Visitor<'de> for PathEmitter<'a, 'w, W> {
    type Value = ();
    fn expecting(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        f.write_str("JSON value for path emitter")
    }

    fn visit_map<A>(self, mut map: A) -> Result<Self::Value, A::Error>
    where
        A: MapAccess<'de>,
    {
        if self.segments.is_empty() {
            let mut obj = serde_json::Map::new();
            while let Some((k, v)) = map.next_entry::<String, Value>()? {
                obj.insert(k, v);
            }
            serde_json::to_writer(&mut *self.writer, &Value::Object(obj))
                .map_err(de::Error::custom)?;
            self.writer.write_all(b"\n").map_err(de::Error::custom)?;
            return Ok(());
        }

        let head = self.segments[0];
        while let Some(k) = map.next_key::<String>()? {
            if k == head {
                let tail = &self.segments[1..];
                if tail.is_empty() {
                    let target_seed = RootEmitterSeed {
                        writer: self.writer,
                    };
                    map.next_value_seed(target_seed)?;
                } else {
                    let seed = PathEmitterSeed {
                        segments: tail,
                        writer: self.writer,
                    };
                    map.next_value_seed(seed)?;
                }
            } else {
                map.next_value::<de::IgnoredAny>()?;
            }
        }
        Ok(())
    }

    fn visit_seq<A>(self, mut seq: A) -> Result<Self::Value, A::Error>
    where
        A: SeqAccess<'de>,
    {
        if self.segments.is_empty() {
            while let Some(val) = seq.next_element::<Value>()? {
                serde_json::to_writer(&mut *self.writer, &val).map_err(de::Error::custom)?;
                self.writer.write_all(b"\n").map_err(de::Error::custom)?;
            }
            return Ok(());
        }

        let head = self.segments[0];

        if let Ok(target_index) = head.parse::<usize>() {
            let mut idx = 0usize;
            while let Some(()) = {
                let next = if idx == target_index {
                    let tail = &self.segments[1..];
                    let seed = PathEmitterSeed {
                        segments: tail,
                        writer: self.writer,
                    };
                    seq.next_element_seed(seed)?
                } else {
                    seq.next_element_seed(IgnoreSeed)?
                };
                idx += 1;
                next
            } {}
        } else {
            while let Some(()) = {
                let tail = &self.segments;
                let seed = PathEmitterSeed {
                    segments: tail,
                    writer: self.writer,
                };
                seq.next_element_seed(seed)?
            } {}
        }
        Ok(())
    }
}

struct IgnoreSeed;
impl<'de> DeserializeSeed<'de> for IgnoreSeed {
    type Value = ();
    fn deserialize<D>(self, deserializer: D) -> Result<Self::Value, D::Error>
    where
        D: de::Deserializer<'de>,
    {
        let _ = de::IgnoredAny::deserialize(deserializer)?;
        Ok(())
    }
}
