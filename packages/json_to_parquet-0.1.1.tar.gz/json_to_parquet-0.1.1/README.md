# JSON to Parquet Converter

A memory-efficient JSON to Parquet converter built with Rust, PyO3, and Arrow.
This library is designed to handle multi‑gigabyte JSON files without running
out of memory by using streaming path extraction, Arrow JSON batch reading,
and Parquet writing.


## Installation

```bash
maturin develop --release
```

## Usage

### Python API

```python
from json_to_parquet import convert_json_to_parquet

# Convert a JSON/NDJSON file to Parquet
convert_json_to_parquet(
    input_path="large_file.json",
    output_path="output.parquet",
    batch_size=10000,        # Arrow RecordBatch row count
    compression="snappy",   # snappy, gzip, lz4, zstd, none
    json_path=None,          # optional: e.g. "results" or "response.data.items"
    schema_mode="sample",   # "sample" (default) or "full"
    schema_infer_rows=10000, # used when schema_mode="sample"
)
```

### CLI

```bash
# Basic
json_to_parquet INPUT.json OUTPUT.parquet

# With options
json_to_parquet INPUT.json OUTPUT.parquet \
  --schema-mode full \
  --batch-size 20000 \
  --compression zstd \
  --json-path response.data.items
```

Manual schema example (lists, structs):
```python
import json
schema = {
    "fields": [
        {"name": "id", "type": "int64"},
        {"name": "payload", "type": {"struct": [
            {"name": "name", "type": "utf8"},
            {"name": "values", "type": {"list": {"struct": [
                {"name": "x", "type": "float64"},
                {"name": "y", "type": "float64"},
            ]}}},
        ]}},
    ]
}
convert_json_to_parquet(
    input_path="nested.json",
    output_path="out.parquet",
    schema_json=json.dumps(schema),
)
```

### Supported JSON Formats

The converter supports multiple JSON formats:

1. **Array of objects** (standard array):
```json
[
  {"id": 1, "name": "Alice", "score": 95.5},
  {"id": 2, "name": "Bob", "score": 87.3}
]
```

2. **Newline-delimited JSON** (NDJSON/JSONL):
```json
{"id": 1, "name": "Alice", "score": 95.5}
{"id": 2, "name": "Bob", "score": 87.3}
```

3. **Nested JSON with path navigation**:
```json
{
  "metadata": {"version": "1.0"},
  "results": [
    {"id": 1, "name": "Alice", "score": 95.5},
    {"id": 2, "name": "Bob", "score": 87.3}
  ]
}
```

For nested JSON, use the `json_path` parameter to extract the array:
```python
convert_json_to_parquet(
    input_path="nested.json",
    output_path="output.parquet",
    json_path="results"  # Extract the "results" array
)
```

You can navigate through multiple levels:
```python
# For JSON like: {"response": {"data": {"items": [...]}}}
convert_json_to_parquet(
    input_path="deeply_nested.json",
    output_path="output.parquet",
    json_path="response.data.items"
)
```

## Performance

- Size reduction: ~15× (2 GB JSON → 135 MB Parquet)
- Wall time: ~20 s (19.96 s)
- Throughput: ~100 MB/s input processed
- I/O writes: ~4.1 GB (temp NDJSON + Parquet)
- Memory: ~100 MB max RSS
