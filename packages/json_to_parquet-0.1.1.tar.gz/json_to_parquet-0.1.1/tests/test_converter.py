import json
import os
import tempfile
import pandas as pd
import pyarrow.parquet as pq
from json_to_parquet import convert_json_to_parquet


def test_simple_json_to_parquet():
    data = [
        {"id": 1, "name": "Alice", "age": 30, "score": 95.5},
        {"id": 2, "name": "Bob", "age": 25, "score": 87.3},
        {"id": 3, "name": "Charlie", "age": 35, "score": 92.1},
    ]

    with tempfile.TemporaryDirectory() as tmpdir:
        json_path = os.path.join(tmpdir, "test.json")
        parquet_path = os.path.join(tmpdir, "test.parquet")

        with open(json_path, "w") as f:
            json.dump(data, f)

        convert_json_to_parquet(
            input_path=json_path,
            output_path=parquet_path,
            batch_size=2,
        )

        assert os.path.exists(parquet_path)

        table = pq.read_table(parquet_path)
        df = table.to_pandas()

        assert len(df) == 3
        assert sorted(list(df.columns)) == ["age", "id", "name", "score"]
        assert df["name"].tolist() == ["Alice", "Bob", "Charlie"]
        assert df["age"].tolist() == [30, 25, 35]


def test_ndjson_to_parquet():
    data = [
        {"id": 1, "name": "Alice", "active": True},
        {"id": 2, "name": "Bob", "active": False},
        {"id": 3, "name": "Charlie", "active": True},
    ]

    with tempfile.TemporaryDirectory() as tmpdir:
        json_path = os.path.join(tmpdir, "test.ndjson")
        parquet_path = os.path.join(tmpdir, "test.parquet")

        with open(json_path, "w") as f:
            for record in data:
                f.write(json.dumps(record) + "\n")

        convert_json_to_parquet(
            input_path=json_path,
            output_path=parquet_path,
            batch_size=2,
        )

        assert os.path.exists(parquet_path)

        table = pq.read_table(parquet_path)
        df = table.to_pandas()

        assert len(df) == 3
        assert "active" in df.columns
        assert df["active"].tolist() == [True, False, True]


def test_large_batch():
    data = [{"id": i, "value": i * 2} for i in range(1000)]

    with tempfile.TemporaryDirectory() as tmpdir:
        json_path = os.path.join(tmpdir, "test.json")
        parquet_path = os.path.join(tmpdir, "test.parquet")

        with open(json_path, "w") as f:
            json.dump(data, f)

        convert_json_to_parquet(
            input_path=json_path,
            output_path=parquet_path,
            batch_size=100,
        )

        assert os.path.exists(parquet_path)

        table = pq.read_table(parquet_path)
        df = table.to_pandas()

        assert len(df) == 1000
        assert df["id"].min() == 0
        assert df["id"].max() == 999
        assert df["value"].max() == 1998


def test_compression():
    data = [{"id": i, "text": "x" * 100} for i in range(100)]

    compressions = ["snappy", "gzip", "none"]

    with tempfile.TemporaryDirectory() as tmpdir:
        json_path = os.path.join(tmpdir, "test.json")

        with open(json_path, "w") as f:
            json.dump(data, f)

        file_sizes = {}

        for comp in compressions:
            parquet_path = os.path.join(tmpdir, f"test_{comp}.parquet")

            convert_json_to_parquet(
                input_path=json_path,
                output_path=parquet_path,
                batch_size=50,
                compression=comp,
            )

            assert os.path.exists(parquet_path)
            file_sizes[comp] = os.path.getsize(parquet_path)

            table = pq.read_table(parquet_path)
            assert len(table) == 100

        assert file_sizes["none"] > file_sizes["snappy"]
        assert file_sizes["none"] > file_sizes["gzip"]


def test_null_values():
    data = [
        {"id": 1, "name": "Alice", "score": 95.5},
        {"id": 2, "name": None, "score": None},
        {"id": 3, "name": "Charlie", "score": 92.1},
    ]

    with tempfile.TemporaryDirectory() as tmpdir:
        json_path = os.path.join(tmpdir, "test.json")
        parquet_path = os.path.join(tmpdir, "test.parquet")

        with open(json_path, "w") as f:
            json.dump(data, f)

        convert_json_to_parquet(
            input_path=json_path,
            output_path=parquet_path,
        )

        assert os.path.exists(parquet_path)

        table = pq.read_table(parquet_path)
        df = table.to_pandas()

        assert len(df) == 3
        name_val = df.loc[1, "name"]
        score_val = df.loc[1, "score"]
        assert name_val is None or pd.isna(name_val) or name_val == "null"
        assert score_val is None or pd.isna(score_val) or score_val == 0.0


def test_json_path_navigation():
    data = {
        "metadata": {"version": "1.0", "created": "2024-01-01"},
        "results": [
            {"id": 1, "name": "Alice", "score": 95.5},
            {"id": 2, "name": "Bob", "score": 87.3},
            {"id": 3, "name": "Charlie", "score": 92.1},
        ],
        "summary": {"total": 3, "average": 91.6},
    }

    with tempfile.TemporaryDirectory() as tmpdir:
        json_path = os.path.join(tmpdir, "nested.json")
        parquet_path = os.path.join(tmpdir, "output.parquet")

        with open(json_path, "w") as f:
            json.dump(data, f)

        convert_json_to_parquet(
            input_path=json_path,
            output_path=parquet_path,
            batch_size=2,
            json_path="results",
        )

        assert os.path.exists(parquet_path)

        table = pq.read_table(parquet_path)
        df = table.to_pandas()

        assert len(df) == 3
        assert list(sorted(df.columns)) == ["id", "name", "score"]
        assert df["name"].tolist() == ["Alice", "Bob", "Charlie"]
        assert df["score"].tolist() == [95.5, 87.3, 92.1]


def test_deeply_nested_path():
    data = {
        "response": {
            "data": {
                "items": [
                    {"id": 1, "value": "A"},
                    {"id": 2, "value": "B"},
                    {"id": 3, "value": "C"},
                ]
            }
        }
    }

    with tempfile.TemporaryDirectory() as tmpdir:
        json_path = os.path.join(tmpdir, "deeply_nested.json")
        parquet_path = os.path.join(tmpdir, "output.parquet")

        with open(json_path, "w") as f:
            json.dump(data, f)

        convert_json_to_parquet(
            input_path=json_path,
            output_path=parquet_path,
            json_path="response.data.items",
        )

        table = pq.read_table(parquet_path)
        df = table.to_pandas()

        assert len(df) == 3
        assert df["value"].tolist() == ["A", "B", "C"]
