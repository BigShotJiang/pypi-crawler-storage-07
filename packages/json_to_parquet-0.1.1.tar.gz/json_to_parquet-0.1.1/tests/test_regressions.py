import json
import os
import tempfile
import math

import pandas as pd
import pyarrow.parquet as pq
import pytest

from json_to_parquet import convert_json_to_parquet


def test_ndjson_with_array_at_path_merges_across_lines():
    records = [
        {"items": [{"id": 1}, {"id": 2}]},
        {"items": [{"id": 3}]},
        {"items": [{"id": 4}, {"id": 5}, {"id": 6}]},
    ]

    with tempfile.TemporaryDirectory() as tmpdir:
        json_path = os.path.join(tmpdir, "input.ndjson")
        parquet_path = os.path.join(tmpdir, "out.parquet")

        with open(json_path, "w") as f:
            for rec in records:
                f.write(json.dumps(rec) + "\n")

        convert_json_to_parquet(
            input_path=json_path,
            output_path=parquet_path,
            batch_size=2,
            json_path="items",
        )

        table = pq.read_table(parquet_path)
        df = table.to_pandas()

        assert len(df) == 6
        assert sorted(df["id"].tolist()) == [1, 2, 3, 4, 5, 6]


def test_array_and_object_fields_nested_supported():
    data = [
        {"id": 1, "tags": ["a", "b"], "meta": {"k": "v"}},
        {"id": 2, "tags": [], "meta": {"n": 1}},
        {"id": 3, "tags": ["x"], "meta": None},
    ]

    with tempfile.TemporaryDirectory() as tmpdir:
        in_path = os.path.join(tmpdir, "input.json")
        out_path = os.path.join(tmpdir, "out.parquet")

        with open(in_path, "w") as f:
            json.dump(data, f)

        convert_json_to_parquet(
            input_path=in_path,
            output_path=out_path,
            batch_size=2,
        )

        table = pq.read_table(out_path)
        df = table.to_pandas()

        assert len(df) == 3
        for col in ["id", "tags", "meta"]:
            assert col in df.columns

        import pyarrow as pa

        schema = pq.read_table(out_path).schema
        assert pa.types.is_list(schema.field("tags").type)
        assert pa.types.is_struct(schema.field("meta").type)


def test_mixed_numeric_and_large_unsigned_promote_to_float():
    big = 9223372036854775808
    data = [
        {"id": 1, "value": 1},
        {"id": 2, "value": 1.5},
        {"id": 3, "value": big},
    ]

    with tempfile.TemporaryDirectory() as tmpdir:
        in_path = os.path.join(tmpdir, "input.json")
        out_path = os.path.join(tmpdir, "out.parquet")

        with open(in_path, "w") as f:
            json.dump(data, f)

        convert_json_to_parquet(
            input_path=in_path,
            output_path=out_path,
            batch_size=2,
        )

        table = pq.read_table(out_path)
        df = table.to_pandas()

        assert len(df) == 3
        vals = df["value"].tolist()
        assert all((isinstance(v, float) or pd.isna(v)) for v in vals)
        assert vals[0] == pytest.approx(1.0)
        assert vals[1] == pytest.approx(1.5)
        assert vals[2] > 0
        assert math.isfinite(vals[2])
        assert abs(vals[2] - float(big)) / float(big) < 1e-6
