import json
import os
import tempfile

import pyarrow as pa
import pyarrow.parquet as pq
from json_to_parquet import convert_json_to_parquet


def test_nested_list_of_structs():
    data = [
        {
            "id": 1,
            "groups": [
                {"name": "g1", "members": [{"id": 11}, {"id": 12}]},
                {"name": "g2", "members": []},
            ],
        },
        {
            "id": 2,
            "groups": [
                {"name": "g3", "members": [{"id": 21}]},
            ],
        },
    ]

    with tempfile.TemporaryDirectory() as tmp:
        ip = os.path.join(tmp, "in.json")
        op = os.path.join(tmp, "out.parquet")

        with open(ip, "w") as f:
            json.dump(data, f)

        convert_json_to_parquet(
            input_path=ip,
            output_path=op,
            batch_size=2,
        )

        t = pq.read_table(op)
        groups_type = t.schema.field("groups").type
        assert pa.types.is_list(groups_type)
        inner = groups_type.value_type
        assert pa.types.is_struct(inner)
        assert set([f.name for f in inner]) == {"name", "members"}
        members_type = inner.field("members").type
        assert pa.types.is_list(members_type)
        assert pa.types.is_struct(members_type.value_type)
        assert [f.name for f in members_type.value_type] == ["id"]

        arr = t.column("groups")
        assert arr.num_chunks == 1
        col = arr.chunks[0]
        assert len(col) == 2


def test_json_path_with_nested_lists_ndjson():
    records = [
        {"response": {"items": [{"a": 1}, {"a": 2}]}},
        {"response": {"items": [{"a": 3}]}},
    ]

    with tempfile.TemporaryDirectory() as tmp:
        ip = os.path.join(tmp, "in.ndjson")
        op = os.path.join(tmp, "out.parquet")

        with open(ip, "w") as f:
            for r in records:
                f.write(json.dumps(r) + "\n")

        convert_json_to_parquet(
            input_path=ip,
            output_path=op,
            json_path="response.items",
        )

        t = pq.read_table(op)
        assert t.num_rows == 3
        assert t.schema.names == ["a"]


def test_manual_schema_nested():
    schema = {
        "fields": [
            {"name": "id", "type": "int64"},
            {
                "name": "payload",
                "type": {
                    "struct": [
                        {"name": "name", "type": "utf8"},
                        {
                            "name": "values",
                            "type": {
                                "list": {
                                    "struct": [
                                        {"name": "x", "type": "float64"},
                                        {"name": "y", "type": "float64"},
                                    ]
                                }
                            },
                        },
                    ]
                },
            },
        ]
    }

    rows = [
        {"id": 1, "payload": {"name": "p1", "values": [{"x": 1.0, "y": 2.0}]}},
        {"id": 2, "payload": {"name": "p2", "values": []}},
    ]

    with tempfile.TemporaryDirectory() as tmp:
        ip = os.path.join(tmp, "in.json")
        op = os.path.join(tmp, "out.parquet")
        with open(ip, "w") as f:
            json.dump(rows, f)

        convert_json_to_parquet(
            input_path=ip,
            output_path=op,
            schema_json=json.dumps(schema),
        )

        t = pq.read_table(op)
        assert t.schema.field("payload").type.equals(
            pa.struct(
                [
                    pa.field("name", pa.utf8()),
                    pa.field(
                        "values",
                        pa.list_(
                            pa.struct(
                                [
                                    pa.field("x", pa.float64()),
                                    pa.field("y", pa.float64()),
                                ]
                            )
                        ),
                    ),
                ]
            )
        )
