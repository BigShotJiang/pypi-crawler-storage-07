"""MongoDB class file."""

from bits.mongo import Mongo


class MongoDB(Mongo):
    """MongoDB class."""
