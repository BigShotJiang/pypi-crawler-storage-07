from django.conf import settings

# Valores por defecto de configuración
DEFAULTS = {
    "AWS_STORAGE_BUCKET_NAME": None,   # Obligatorio (nombre del bucket)
    "AWS_REGION": "us-east-1",         # Región por defecto
    "AWS_ACCESS_KEY_ID": None,         # Si no está definido => usa IAM Role
    "AWS_SECRET_ACCESS_KEY": None,     # Si no está definido => usa IAM Role
    "AWS_QUERYSTRING_EXPIRE": 3600,    # Expiración default para presigned URLs
}


def get_setting(name):
    """
    Obtiene un valor de configuración desde Django settings,
    o aplica el valor por defecto definido en DEFAULTS.
    """
    return getattr(settings, name, DEFAULTS.get(name))
