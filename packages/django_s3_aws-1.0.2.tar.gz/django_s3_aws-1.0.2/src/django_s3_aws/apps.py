from django.apps import AppConfig


class DjangoS3AWSConfig(AppConfig):
    """
    Configuración de la aplicación django-s3-aws.
    Esto le indica a Django cómo registrar la app.
    """
    default_auto_field = "django.db.models.BigAutoField"
    name = "django_s3_aws"
    verbose_name = "Django AWS S3 Storage"
