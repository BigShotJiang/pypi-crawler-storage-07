import boto3
from botocore.exceptions import ClientError
from .settings import get_setting


def get_s3_client():
    """
    Retorna un cliente boto3 para S3 usando configuración desde settings.py de Django.
    Si no hay claves configuradas, boto3 usará credenciales por defecto (IAM Role, ~/.aws/credentials, etc).
    """
    return boto3.client(
        "s3",
        region_name=get_setting("AWS_REGION"),
        aws_access_key_id=get_setting("AWS_ACCESS_KEY_ID"),
        aws_secret_access_key=get_setting("AWS_SECRET_ACCESS_KEY"),
    )


def object_exists(bucket_name, key):
    """
    Verifica si un objeto existe en un bucket S3.
    Retorna True si existe, False si no.
    """
    s3 = get_s3_client()
    try:
        s3.head_object(Bucket=bucket_name, Key=key)
        return True
    except ClientError as e:
        if e.response["Error"]["Code"] == "404":
            return False
        raise


def generate_presigned_url(bucket_name, key, expiration=None):
    """
    Genera una URL firmada temporal para acceder a un objeto privado en S3.
    :param bucket_name: str
    :param key: str (ruta/archivo dentro del bucket)
    :param expiration: int en segundos (default: AWS_QUERYSTRING_EXPIRE)
    """
    s3 = get_s3_client()
    exp = expiration or get_setting("AWS_QUERYSTRING_EXPIRE")

    return s3.generate_presigned_url(
        "get_object",
        Params={"Bucket": bucket_name, "Key": key},
        ExpiresIn=exp,
    )
