# 🌐 django-s3-aws

[![Python](https://img.shields.io/badge/python-3.9%2B-blue.svg)](https://www.python.org/)  
[![Django](https://img.shields.io/badge/django-3.2%2B-green.svg)](https://www.djangoproject.com/)  
[![License](https://img.shields.io/badge/license-MIT-yellow.svg)](LICENSE)

**django-s3-aws** is a Django storage backend that integrates **Amazon S3** in a simple way to manage static and media files.  
It includes support for presigned URLs, ACLs, and secure access to private buckets.

---

## ✨ Features

- 🔹 Compatible with **Django 3.2+ and 4.0+**  
- 🔹 Direct integration with **Amazon S3** using `boto3`  
- 🔹 Generate **presigned URLs** for secure downloads  
- 🔹 Minimal configuration: you only need the bucket name  
- 🔹 Built-in defaults handled inside the library (`src/django_s3_aws/settings.py`)  

---

## ⚙️ Installation

```bash
pip install django-s3-aws


Then add the library to your project:

# settings.py
INSTALLED_APPS = [
    ...
    "django_s3_aws",
]

```

## Configuration in settings.py
AWS_STORAGE_BUCKET_NAME = "my-bucket"
AWS_REGION = "us-east-1"

# Optional (if you are not using IAM Roles in AWS)
AWS_ACCESS_KEY_ID = "my-access-key"
AWS_SECRET_ACCESS_KEY = "my-secret-key"

DEFAULT_FILE_STORAGE = "django_s3_aws.storage.S3AWSStorage"


## Basic Usage
from django.core.files.base import ContentFile
from django_s3_aws.storage import S3AWSStorage

storage = S3AWSStorage()

# Save a file
storage.save("example.txt", ContentFile(b"Hello from S3!"))

# Generate a public or presigned URL
print(storage.url("example.txt"))
print(storage.generate_presigned_url("example.txt", expiration=600))


## Roadmap

 Full integration with moto3 for mocking S3 in tests

 Compatibility with django-storages API

 Support for advanced configurations (versioning, SSE, etc.)
 
 
## License
 django-s3-aws is licensed under the MIT License.

## Contacto

[LinkedIn](https://www.linkedin.com/in/hugo345?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app) hugo aragon