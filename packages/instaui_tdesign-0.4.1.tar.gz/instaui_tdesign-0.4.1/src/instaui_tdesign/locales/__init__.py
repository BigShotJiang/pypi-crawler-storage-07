from ._index import get_locale


__all__ = ["get_locale"]
