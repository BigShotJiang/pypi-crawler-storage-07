# Copyright © 2025, Alexander Suvorov


class Config:
    name = 'Smart Password Generator'
    url = 'https://github.com/smartlegionlab/clipassgen/'
    copyright_ = 'Copyright © 2025, Alexander Suvorov. All rights reserved.'
