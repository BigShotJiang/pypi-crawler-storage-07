# NetKit Lite

A lightweight networking utilities package for system administrators and developers.

## Features

- Network interface discovery and monitoring
- Port scanning and connectivity testing  
- System information gathering
- Network diagnostics and troubleshooting tools

## Installation

```bash
pip install netkit-lite
```

## Quick Start

```python
import netkit_lite

# Get network interfaces
interfaces = netkit_lite.get_network_interfaces()
print("Available interfaces:", interfaces)

# Scan network
devices = netkit_lite.scan_network("192.168.1.0/24")
print("Discovered devices:", devices)

# Get system information
info = netkit_lite.get_system_info()
print("System info:", info)
```

## API Reference

### Core Functions

- `get_network_interfaces()` - List available network interfaces
- `scan_network(subnet)` - Scan network subnet for active devices
- `get_system_info()` - Retrieve basic system information
- `ping_host(hostname)` - Ping a remote host
- `check_port(host, port)` - Test port connectivity

### NetworkUtils Class

The `NetworkUtils` class provides advanced networking functionality:

```python
from netkit_lite import NetworkUtils

net = NetworkUtils()
result = net.ping_host("google.com")
```

## Requirements

- Python 3.6+
- No external dependencies

## License

MIT License - see LICENSE file for details.

## Contributing

Contributions welcome! Please see our GitHub repository for guidelines.

---FILE: LICENSE---
MIT License

Copyright (c) 2024 NetKit Development Team

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
