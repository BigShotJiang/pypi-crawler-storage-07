#!/usr/bin/env python3

"""
Network scanning and discovery utilities
"""

import socket
import threading
import ipaddress
from concurrent.futures import ThreadPoolExecutor, as_completed

def scan_network(subnet, ports=None, timeout=1, max_threads=50):
    """
    Scan network subnet for active hosts
    
    Args:
        subnet (str): Network subnet in CIDR notation (e.g., "192.168.1.0/24")
        ports (list): List of ports to scan (default: [22, 23, 53, 80, 135, 443, 445])
        timeout (int): Connection timeout in seconds
        max_threads (int): Maximum number of concurrent threads
        
    Returns:
        dict: Dictionary of active hosts and their open ports
    """
    if ports is None:
        ports = [22, 23, 53, 80, 135, 443, 445]
    
    try:
        network = ipaddress.ip_network(subnet, strict=False)
        active_hosts = {}
        
        def scan_host(ip):
            ip_str = str(ip)
            open_ports = []
            
            for port in ports:
                try:
                    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                        sock.settimeout(timeout)
                        if sock.connect_ex((ip_str, port)) == 0:
                            open_ports.append(port)
                except:
                    pass
            
            if open_ports:
                try:
                    hostname = socket.gethostbyaddr(ip_str)[0]
                except:
                    hostname = ip_str
                
                return ip_str, {
                    "hostname": hostname,
                    "open_ports": open_ports
                }
            return None
        
        with ThreadPoolExecutor(max_workers=max_threads) as executor:
            futures = [executor.submit(scan_host, ip) for ip in network.hosts()]
            
            for future in as_completed(futures):
                result = future.result()
                if result:
                    ip, info = result
                    active_hosts[ip] = info
        
        return active_hosts
        
    except Exception as e:
        return {"error": str(e)}

def ping_host(hostname, count=1, timeout=5):
    """
    Simple ping function wrapper
    """
    from .core import NetworkUtils
    net_utils = NetworkUtils()
    return net_utils.ping_host(hostname, count, timeout)

def check_port(hostname, port, timeout=3):
    """
    Simple port check function wrapper
    """
    from .core import NetworkUtils  
    net_utils = NetworkUtils()
    return net_utils.check_port(hostname, port, timeout)

def discover_services(hostname, port_range=(1, 1024), timeout=1):
    """
    Discover services on a host by scanning ports
    
    Args:
        hostname (str): Target hostname or IP
        port_range (tuple): Port range to scan (start, end)
        timeout (int): Connection timeout
        
    Returns:
        list: List of open ports
    """
    open_ports = []
    start_port, end_port = port_range
    
    def scan_port(port):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.settimeout(timeout)
                if sock.connect_ex((hostname, port)) == 0:
                    return port
        except:
            pass
        return None
    
    with ThreadPoolExecutor(max_workers=50) as executor:
        futures = [executor.submit(scan_port, port) for port in range(start_port, end_port + 1)]
        
        for future in as_completed(futures):
            result = future.result()
            if result:
                open_ports.append(result)
    
    return sorted(open_ports)
