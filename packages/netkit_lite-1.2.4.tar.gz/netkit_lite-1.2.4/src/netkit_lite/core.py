#!/usr/bin/env python3

"""
Core networking utilities
"""

import socket
import subprocess
import platform

class NetworkUtils:
    """Main networking utilities class"""
    
    def __init__(self):
        self.platform = platform.system().lower()
    
    def ping_host(self, hostname, count=1, timeout=5):
        """
        Ping a host to check connectivity
        
        Args:
            hostname (str): Target hostname or IP
            count (int): Number of ping packets
            timeout (int): Timeout in seconds
            
        Returns:
            dict: Ping results
        """
        try:
            if self.platform == "windows":
                cmd = ["ping", "-n", str(count), hostname]
            else:
                cmd = ["ping", "-c", str(count), "-W", str(timeout), hostname]
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout+2)
            
            return {
                "success": result.returncode == 0,
                "output": result.stdout,
                "error": result.stderr
            }
        except Exception as e:
            return {
                "success": False,
                "output": "",
                "error": str(e)
            }
    
    def check_port(self, hostname, port, timeout=3):
        """
        Check if a port is open on a host
        
        Args:
            hostname (str): Target hostname or IP
            port (int): Target port number
            timeout (int): Connection timeout
            
        Returns:
            dict: Port check results
        """
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.settimeout(timeout)
                result = sock.connect_ex((hostname, port))
                
                return {
                    "open": result == 0,
                    "hostname": hostname,
                    "port": port,
                    "response_time": timeout if result != 0 else None
                }
        except Exception as e:
            return {
                "open": False,
                "hostname": hostname,
                "port": port,
                "error": str(e)
            }
    
    def get_local_ip(self):
        """Get local IP address"""
        try:
            # Connect to a remote address to get local IP
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
                sock.connect(("8.8.8.8", 80))
                return sock.getsockname()[0]
        except Exception:
            return "127.0.0.1"
    
    def resolve_hostname(self, hostname):
        """Resolve hostname to IP address"""
        try:
            return socket.gethostbyname(hostname)
        except Exception as e:
            return None
