#!/usr/bin/env python3

"""
System and utility functions
"""

import socket
import platform
import psutil
import os
import json
from datetime import datetime

def get_system_info():
    """
    Get comprehensive system information
    
    Returns:
        dict: System information dictionary
    """
    try:
        info = {
            "hostname": socket.gethostname(),
            "platform": platform.system(),
            "platform_release": platform.release(),
            "platform_version": platform.version(),
            "architecture": platform.machine(),
            "processor": platform.processor(),
            "python_version": platform.python_version(),
            "timestamp": datetime.now().isoformat()
        }
        
        # Add network info if available
        try:
            info["local_ip"] = get_local_ip()
        except:
            info["local_ip"] = "unknown"
            
        return info
        
    except Exception as e:
        return {"error": str(e)}

def get_network_interfaces():
    """
    Get available network interfaces
    
    Returns:
        list: List of network interface names
    """
    try:
        # Try using psutil if available
        try:
            import psutil
            interfaces = list(psutil.net_if_addrs().keys())
            return interfaces
        except ImportError:
            pass
        
        # Fallback methods
        if platform.system().lower() == "windows":
            # Windows fallback
            return ["Ethernet", "Wi-Fi", "Loopback"]
        else:
            # Unix-like systems fallback
            try:
                import subprocess
                result = subprocess.run(["ip", "link", "show"], 
                                      capture_output=True, text=True, timeout=5)
                interfaces = []
                for line in result.stdout.split('\n'):
                    if ': ' in line and 'state' in line.lower():
                        name = line.split(':')[1].strip().split('@')[0]
                        interfaces.append(name)
                return interfaces
            except:
                return ["eth0", "lo", "wlan0"]  # Generic fallback
                
    except Exception:
        return ["eth0", "lo"]  # Minimal fallback

def get_local_ip():
    """Get local IP address"""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.connect(("8.8.8.8", 80))
            return sock.getsockname()[0]
    except:
        return "127.0.0.1"

def save_network_config(filename, config):
    """
    Save network configuration to file
    
    Args:
        filename (str): Output filename
        config (dict): Configuration dictionary
    """
    try:
        with open(filename, 'w') as f:
            json.dump(config, f, indent=2)
        return True
    except Exception:
        return False

def load_network_config(filename):
    """
    Load network configuration from file
    
    Args:
        filename (str): Input filename
        
    Returns:
        dict: Configuration dictionary
    """
    try:
        with open(filename, 'r') as f:
            return json.load(f)
    except Exception:
        return {}

def get_network_stats():
    """Get network statistics if psutil is available"""
    try:
        import psutil
        stats = psutil.net_io_counters()
        return {
            "bytes_sent": stats.bytes_sent,
            "bytes_recv": stats.bytes_recv,
            "packets_sent": stats.packets_sent,
            "packets_recv": stats.packets_recv
        }
    except ImportError:
        return {"error": "psutil not available"}
    except Exception as e:
        return {"error": str(e)}