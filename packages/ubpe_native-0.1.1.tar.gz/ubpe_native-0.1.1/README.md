# ubpe-native

Plain Python implementation of the Universal Byte Pair Encoding Tokenizer.

> The package is a part of the general [`ubpe`](https://github.com/Scurrra/ubpe) package, where I divided general import and implementations, because I'm planning to provide other implementations as well. So the package should not be directly installed. Please, use `pip install ubpe[native]` instead.