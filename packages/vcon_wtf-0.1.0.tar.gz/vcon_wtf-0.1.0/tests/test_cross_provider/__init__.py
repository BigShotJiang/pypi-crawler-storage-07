"""
Cross-provider testing package.

This package contains tests for comparing consistency, performance, and quality
across multiple transcription providers.
"""
