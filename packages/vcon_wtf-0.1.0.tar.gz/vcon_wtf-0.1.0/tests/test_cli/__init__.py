"""
Tests for CLI functionality.
"""
