"""
Test suite for WTF transcript converter.

This module contains all tests for the WTF transcript converter library.
"""
