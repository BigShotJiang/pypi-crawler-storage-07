def main():
    print("Hello from wtf-transcript-converter!")


if __name__ == "__main__":
    main()
