# -*- coding: utf-8 -*-

from .caster import amp_caster

caster = amp_caster

__version__ = "1.40.0"