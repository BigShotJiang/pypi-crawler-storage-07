from .tables import configure_models

__all__ = [
    "configure_models",
]
