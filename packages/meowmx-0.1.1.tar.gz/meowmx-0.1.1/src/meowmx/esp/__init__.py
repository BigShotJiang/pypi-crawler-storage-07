# This copies a lot of work from the [postgres-event-sourcing](https://github.com/eugene-khyst/postgresql-event-sourcing)
# repository, specifically the [migrations](https://github.com/eugene-khyst/postgresql-event-sourcing/tree/856de8c81e4ef4cc53f3e2d6011014e2a9173968/event-sourcing-app/src/main/resources/db/migration)
# and the [repository Java package](https://github.com/eugene-khyst/postgresql-event-sourcing/tree/856de8c81e4ef4cc53f3e2d6011014e2a9173968/postgresql-event-sourcing-core/src/main/java/eventsourcing/postgresql/repository).


