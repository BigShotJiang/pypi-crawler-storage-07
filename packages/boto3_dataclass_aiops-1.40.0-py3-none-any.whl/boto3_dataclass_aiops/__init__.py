# -*- coding: utf-8 -*-

from .caster import aiops_caster

caster = aiops_caster

__version__ = "1.40.0"