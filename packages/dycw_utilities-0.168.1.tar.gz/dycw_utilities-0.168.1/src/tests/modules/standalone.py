from __future__ import annotations

POSITIVE_INT = 1
ZERO_INT = 0
NEGATIVE_INT = -1
POSITIVE_FLOAT = 1.0
ZERO_FLOAT = 0.0
NEGATIVE_FLOAT = -1.0


class IntSubclass(int): ...


class FloatSubclass1(float): ...


class FloatSubclass2(float): ...
