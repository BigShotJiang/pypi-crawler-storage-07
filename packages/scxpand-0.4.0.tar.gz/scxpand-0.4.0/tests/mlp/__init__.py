"""Tests for MLP components."""
