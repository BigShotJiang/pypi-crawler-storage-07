class KnowledgeBaseConversionException(Exception):
    pass
