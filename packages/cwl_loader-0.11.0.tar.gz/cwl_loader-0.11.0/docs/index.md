# Introduction

The **cwl_loader** Python library is a helper library to simplify the loading operations of CWL documents to [cwl-utils](https://github.com/common-workflow-language/cwl-utils) object models.

## API doc

Refer to [latest](./api/latest/cwl_loader.md) published API documentation to explore the utilities.
