# curse
A Python Package to Determine In profanity in Persian


## Installation
```bash
pip install curse
```


## Usage
```python
from curse import CurseAgent

curse = CurseAgent()

text = "your persion text"
test = curse.predict(text=text)
print(test.status)
```