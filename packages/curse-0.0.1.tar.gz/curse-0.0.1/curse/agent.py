import joblib
import json


class CursePrediction:
    def __init__(self, status: bool, probability: float):
        self.status = status
        self.probability = f"{probability*100:.0f}%"
        self.level = self.set_level(probability)

    def set_level(self, prob):
        if prob < 0.33:
            return "Low"
        elif prob < 0.66:
            return "Medium"
        else:
            return "High"

    def parse(self):
        return {
            "status": bool(self.status),
            "probability": self.probability,
            "level": self.level
        }

    def jsonify(self):
        return json.dumps(self.parse(), ensure_ascii=False, indent=2)

    def __repr__(self):
        return self.jsonify()


class CurseAgent:
    def __init__(self):
        self.model = joblib.load("curse/CurseAgent.pkl")

    def predict(self, text: str) -> CursePrediction:
        """ A Python Package to Determine In profanity in Persian

        Args:
            text (str): ...

        Returns:
            CursePrediction: CursePrediction
            
        Example:
            >>> from from curse import CurseAgent
            >>> agent = CurseAgent()
            >>> text = "your persion text"
            >>> test = agent.predict(text)
            >>> print(test.status) # True or False
            >>> print(test.probability) # 10%
            >>> print(test.level) # Low
        """
        probability = self.model.predict_proba([text])[0][1]
        status = probability >= 0.5
        return CursePrediction(status, probability)