"""A set of fake data generators that can be used to fiddle around with simulations."""

from .soep.soep_faker import soep

__all__ = ["soep"]
