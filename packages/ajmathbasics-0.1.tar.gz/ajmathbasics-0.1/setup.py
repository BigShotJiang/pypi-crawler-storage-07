from setuptools import setup, find_packages

classifiers = [
    'Development Status :: 3 - Alpha',
    'Intended Audience :: Education',
    'License :: OSI Approved :: MIT License',
    'Programming Language :: Python :: 3'
]

setup(
    name='ajMathbasics',
    version='0.1',
    description='A collection of basic mathematical operations',
    long_description=open('README.md').read(),
    author='Ajay Tingare',
    author_email='ajaytingare99@gmail.com',
    url='https://github.com/ajaytingare/universal_libs',
    packages=find_packages(),
    classifiers=classifiers,
    keywords='math basics operations',
    license='MIT',
    install_requires=[],
    python_requires='>=3.6'
)
