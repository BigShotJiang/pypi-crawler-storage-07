from enum import StrEnum


class DatabaseType(StrEnum):
    SQL_ALCHEMY = "SQL_ALCHEMY"
    TEMPLATE = "TEMPLATE"
