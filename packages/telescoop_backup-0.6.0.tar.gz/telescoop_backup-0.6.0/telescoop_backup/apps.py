from django.apps import AppConfig


class AuthConfig(AppConfig):
    name = "telescoop_backup"
    label = "telescoop_backup"
    verbose_name = "Utilisateurs"
