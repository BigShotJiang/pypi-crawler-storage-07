# Version 1.1.2

- The `ItemPool` class now correctly honors the `id` field of items. (#30, #31)
- Examples and the readme file have been updated accordingly.