"""Third-party LLM implementations for crewAI."""
