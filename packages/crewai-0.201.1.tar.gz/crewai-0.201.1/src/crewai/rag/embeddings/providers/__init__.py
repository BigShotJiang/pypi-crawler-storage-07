"""Embedding provider implementations."""
