# -*- coding: utf-8 -*-

from .caster import redshift_data_caster

caster = redshift_data_caster

__version__ = "1.40.0"