# -*- coding: utf-8 -*-

from .caster import inspector_caster

caster = inspector_caster

__version__ = "1.40.0"