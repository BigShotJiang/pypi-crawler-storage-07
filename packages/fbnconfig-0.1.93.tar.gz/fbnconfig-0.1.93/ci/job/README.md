# Docker image used in the examples

`docker build . -t harbor.finbourne.com/ceng/fbnconfig-pipeline:0.1 --platform=linux/amd64`

`docker push harbor.finbourne.com/ceng/fbnconfig-pipeline:0.1 `
