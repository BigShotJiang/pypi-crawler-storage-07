"""
Public health functionality for sim_sci_test_monorepo
"""

try:
    from ._version import __version__
except ImportError:
    # Package is not installed
    __version__ = "unknown"