# sim_sci_test_monorepo.public_health

Public health functionality for the sim_sci_test_monorepo namespace package.

## Installation

```bash
pip install sim-sci-test-monorepo-public-health
```

## Usage

```python
from sim_sci_test_monorepo.public_health import ...
```