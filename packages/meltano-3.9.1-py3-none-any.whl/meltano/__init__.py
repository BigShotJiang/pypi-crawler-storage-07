"""Meltano."""

from __future__ import annotations

# Managed by commitizen
__version__ = "3.9.1"
