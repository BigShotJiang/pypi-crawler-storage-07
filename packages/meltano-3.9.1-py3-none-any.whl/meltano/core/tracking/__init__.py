"""Meltano telemetry."""

from __future__ import annotations

from meltano.core.tracking.tracker import BlockEvents, Tracker
