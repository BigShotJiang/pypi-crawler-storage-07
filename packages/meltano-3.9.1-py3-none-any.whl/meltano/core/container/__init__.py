"""Handling of plugin container commands."""

from __future__ import annotations
