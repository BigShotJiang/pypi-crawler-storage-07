from tidy3d_mcp.server import main

__all__ = ['main']
