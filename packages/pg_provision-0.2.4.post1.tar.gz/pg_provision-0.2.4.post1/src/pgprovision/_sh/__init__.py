# Marker so `importlib.resources.files("pgprovision._sh")` works.
__all__ = ()
