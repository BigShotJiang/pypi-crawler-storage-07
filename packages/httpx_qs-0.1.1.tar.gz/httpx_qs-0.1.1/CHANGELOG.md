## 0.1.1

* [CHORE] limit httpx to `>=0.28.1, <1.0.0`

## 0.1.0

* [CHORE] Initial release.
