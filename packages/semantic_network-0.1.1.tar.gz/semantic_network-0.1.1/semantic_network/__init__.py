from .net import SemanticNetwork
