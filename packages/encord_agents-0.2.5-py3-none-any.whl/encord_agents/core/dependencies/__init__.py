from .models import Depends

__all__ = ["Depends"]
