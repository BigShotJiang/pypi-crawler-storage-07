from typing import Literal

Base64Formats = Literal[".jpeg", ".jpg", ".png"]
