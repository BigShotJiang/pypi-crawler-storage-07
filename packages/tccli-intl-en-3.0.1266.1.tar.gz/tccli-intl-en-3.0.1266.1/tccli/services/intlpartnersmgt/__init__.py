# -*- coding: utf-8 -*-

from tccli.services.intlpartnersmgt.intlpartnersmgt_client import action_caller
    