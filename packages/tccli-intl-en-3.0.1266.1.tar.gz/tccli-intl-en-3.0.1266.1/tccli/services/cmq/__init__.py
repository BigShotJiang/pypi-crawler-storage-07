# -*- coding: utf-8 -*-

from tccli.services.cmq.cmq_client import action_caller
    