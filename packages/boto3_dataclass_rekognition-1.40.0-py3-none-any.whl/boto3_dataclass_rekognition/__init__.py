# -*- coding: utf-8 -*-

from .caster import rekognition_caster

caster = rekognition_caster

__version__ = "1.40.0"