# PydanticTest

Uma aplicação simples demonstrando o uso do Pydantic para validação de dados.

## Instalação

```bash
pip install pydanticTest
```

## Uso

```bash
pydantic-test
```

## Desenvolvimento

Para executar localmente:

```bash
uv run start
```
