'''Start the application'''
from .main import main

if __name__ == "__main__":
    main("Alessander S. Goulart", "sander@uniwork.com.br", 50)
