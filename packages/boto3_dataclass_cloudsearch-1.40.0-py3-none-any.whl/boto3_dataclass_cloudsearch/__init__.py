# -*- coding: utf-8 -*-

from .caster import cloudsearch_caster

caster = cloudsearch_caster

__version__ = "1.40.0"