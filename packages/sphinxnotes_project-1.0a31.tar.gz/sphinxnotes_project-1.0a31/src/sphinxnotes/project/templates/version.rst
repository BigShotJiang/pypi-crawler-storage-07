
:Date: :ref:`📅{{ date }} <any-version.date+by-year>`
:Download: :tag:`{{ title }}`

{% for line in content %}
{{ line }}
{% endfor %}

