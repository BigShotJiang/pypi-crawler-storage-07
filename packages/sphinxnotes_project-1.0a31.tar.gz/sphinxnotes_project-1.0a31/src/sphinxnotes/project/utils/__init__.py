"""
sphinxnotes.project.utils
~~~~~~~~~~~~~~~~~~~~~~~~~

Shared utility functions between sphinxnotes projects.

:copyright: Copyright 2025 Shengyu Zhang
:license: BSD, see LICENSE for details.
"""
