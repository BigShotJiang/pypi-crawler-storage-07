"""Functions for supporting statistics."""
