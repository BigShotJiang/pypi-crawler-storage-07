"""All actor rules."""
