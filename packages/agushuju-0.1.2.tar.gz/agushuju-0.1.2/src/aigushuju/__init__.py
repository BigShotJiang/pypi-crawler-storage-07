# -*- coding: utf-8 -*-
from agushuju import api  # 提供 aigushuju.api 的同名入口
from agushuju import __version__  # 导入版本号

__all__ = ["api", "__version__"]
