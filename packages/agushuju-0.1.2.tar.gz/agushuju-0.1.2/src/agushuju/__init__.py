# -*- coding: utf-8 -*-
from .client import api

__version__ = "0.1.2"
__all__ = ["api"]

