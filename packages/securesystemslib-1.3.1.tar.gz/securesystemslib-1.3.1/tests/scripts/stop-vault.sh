#!/usr/bin/env bash

pkill -f "vault server -dev"
