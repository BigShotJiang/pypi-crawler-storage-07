# type: ignore

import click

from mycli.packages.prompt_utils import confirm_destructive_query


def test_confirm_destructive_query_notty() -> None:
    stdin = click.get_text_stream("stdin")
    assert stdin.isatty() is False

    sql = "drop database foo;"
    assert confirm_destructive_query(sql) is None
