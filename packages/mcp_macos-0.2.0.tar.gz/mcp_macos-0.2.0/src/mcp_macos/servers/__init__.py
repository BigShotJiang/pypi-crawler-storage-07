"""Server modules for macOS Mail and Calendar."""
