__license__ = "BSD"
__author__ = "Ymagis"
__version__ = "1.6.1"
