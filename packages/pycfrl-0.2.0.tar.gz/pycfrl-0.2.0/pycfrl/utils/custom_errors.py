class InvalidModelError(Exception):
    pass