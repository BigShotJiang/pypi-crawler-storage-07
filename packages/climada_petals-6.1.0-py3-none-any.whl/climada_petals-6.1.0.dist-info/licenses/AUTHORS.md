# CLIMADA PETALS List of Authors

* Gabriela Aznar-Siguan
* David N. Bresch
* Samuel Eberenz
* Jan Hartman
* Marine Perus
* Thomas Röösli
* Dario Stocker
* Veronica Bozzini
* Tobias Geiger
* Carmen B. Steinmann
* Evelyn Mühlhofer
* Rachel Bungerer
* Inga Sauer
* Samuel Lüthi
* Pui Man Kam
* Simona Meiler
* Alessio Ciullo
* Thomas Vogt
* Benoit P. Guillod
* Chahan Kropf
* Emanuel Schmid
* Chris Fairless
* Jan Wüthrich
* Zélie Stalhandske
* Lukas Riedel
* Samuel Juhel
* Jere Lehtomaa
* Valentin Gebhard
* Dahyann Araya
