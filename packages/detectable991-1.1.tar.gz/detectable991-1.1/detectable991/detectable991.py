def sm1(a,b):
    return a + b




