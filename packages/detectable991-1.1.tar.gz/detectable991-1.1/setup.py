from setuptools import setup, find_packages

setup(
    name="detectable991",
    version="1.1",
    author="Noman",
    author_email="mnomanansari99@gmail.com",
    description="This is just a package",
    packages=find_packages(),
    python_requires=">=3.6",
    entry_point={
        "console_script":[
            "mnomanansari99@gmal.com"
            
            ],
        
        
        },

    )