/**
 * Copyright 2021 ACSONE SA/NV (http://www.acsone.eu)
 * @author Simone Orsi <simahawk@gmail.com>
 * License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl.html).
 */

import {BaseRegistry} from "./registry.esm.js";

/* eslint no-unused-vars: 0*/

class PageRegistry extends BaseRegistry {
    constructor() {
        super(arguments);
    }

    add(key, component, route, metadata, override = false) {
        const rec = super.add(key, component, route, metadata, override);
        if (!_.result(rec, "metadata.tag")) {
            throw "`tag` is required for pages!";
        }
        _.defaults(rec.metadata, {
            display_name: function (instance, rec) {
                return rec.key;
            },
            is_enabled: function (instance, rec) {
                return true;
            },
        });
        return rec;
    }
    /**
     * Retrieve all pages matching given tag.
     *
     * @param {*} tag: metadata tag to filter with
     */
    by_tag(tag) {
        return _.filter(this._data, function (x) {
            return x.metadata.tag == tag;
        });
    }
}
export var page_registry = new PageRegistry();
