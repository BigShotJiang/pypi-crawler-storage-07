
from .core import Effect
mw_extinction = Effect.from_name("mw")
host_dust = Effect.from_name("hostdust")
