"""
Bitbucket MCP prompts module.
"""

from .main import init

__all__ = [
   "init"
]