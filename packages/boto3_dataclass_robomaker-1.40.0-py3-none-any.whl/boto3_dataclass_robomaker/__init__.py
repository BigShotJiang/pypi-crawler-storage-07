# -*- coding: utf-8 -*-

from .caster import robomaker_caster

caster = robomaker_caster

__version__ = "1.40.0"