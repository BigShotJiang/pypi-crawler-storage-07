API reference
=============

.. automodule:: diffstar.sfh
    :members: get_sfh_from_mah_kern
