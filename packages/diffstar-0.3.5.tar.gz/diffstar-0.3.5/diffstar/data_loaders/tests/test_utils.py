""" """


def test_load_flat_hdf5_import():
    from .. import load_flat_hdf5  # noqa
