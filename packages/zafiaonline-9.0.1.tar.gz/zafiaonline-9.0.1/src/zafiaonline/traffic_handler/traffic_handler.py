# coming soon
"""
class TrafficHandler:
    async def traffic_handler(
        self,
        request,
        data
    ):
        pass

    async def request_handler(self):
        pass

    async def data_handler(self):
        pass
"""
