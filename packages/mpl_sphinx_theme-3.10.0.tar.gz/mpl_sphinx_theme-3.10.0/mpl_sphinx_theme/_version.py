#!/usr/bin/env python
# coding: utf-8

# Copyright (c) Matplotlib developers.
# Distributed under the terms of the Modified BSD License.

version_info = (3, 10, 0)
__version__ = ".".join(map(str, version_info))
