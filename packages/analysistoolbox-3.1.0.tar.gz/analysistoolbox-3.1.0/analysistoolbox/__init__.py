# Turn off warnings
import warnings
warnings.filterwarnings('ignore')

# # Import all modules
# from .calculus import *
# from .data_collection import *
# from .data_processing import *
# from .descriptive_analytics import *
# from .file_management import *
# from .hypothesis_testing import *
# from .linear_algebra import *
# from .llm import *
# from .predictive_analytics import *
# from .prescriptive_analytics import *
# from .probability import *
# from .simulations import *
# from .statistics import *
# from .visualizations import *

# Turn on warnings
warnings.filterwarnings('default')
