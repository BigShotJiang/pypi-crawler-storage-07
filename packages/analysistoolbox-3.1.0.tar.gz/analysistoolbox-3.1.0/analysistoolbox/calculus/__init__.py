from .FindDerivative import FindDerivative
from .FindLimitOfFunction import FindLimitOfFunction
from .FindMinimumSquareLoss import FindMinimumSquareLoss
from .PlotFunction import PlotFunction
