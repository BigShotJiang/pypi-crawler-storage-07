# Music Assistant Base Models

Models used by Music Assistant (shared by client and server)

---

[![A project from the Open Home Foundation](https://www.openhomefoundation.org/badges/ohf-project.png)](https://www.openhomefoundation.org/)
