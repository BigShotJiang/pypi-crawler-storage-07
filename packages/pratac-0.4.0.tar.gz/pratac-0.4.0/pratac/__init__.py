"""
Pratac - Cleaning schedule management tool.
"""

__version__ = "0.4.0"