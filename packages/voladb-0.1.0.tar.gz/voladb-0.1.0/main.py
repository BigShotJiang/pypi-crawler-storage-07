def main():
    print("Hello from voladb!")


if __name__ == "__main__":
    main()
