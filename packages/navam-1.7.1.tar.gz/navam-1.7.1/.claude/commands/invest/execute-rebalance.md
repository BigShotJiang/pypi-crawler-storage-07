You are executing a systematic portfolio rebalancing to restore target allocations while optimizing for taxes and transaction costs. Follow this disciplined execution workflow:

**⚡ PERFORMANCE OPTIMIZATION (CRITICAL):**

**Phase 1: PARALLEL Core Planning**
Launch these key agents IN PARALLEL using the Task tool - DO NOT run them sequentially:

1. **rebalance-bot** - Rebalancing analysis and trade planning
2. **risk-shield-manager** - Risk validation and compliance
3. **tax-scout** - Tax optimization and sequencing

**CRITICAL INSTRUCTIONS:**
- Use the Task tool to launch ALL THREE core planning agents SIMULTANEOUSLY in a single response
- Each agent analyzes rebalancing from different critical perspectives in parallel
- Wait for ALL agents to complete before proceeding to execution
- This parallel approach reduces execution time by 60-70%

**WORKFLOW: Portfolio Rebalancing & Trade Execution**

1. **PARALLEL Core Planning Phase (Launch Simultaneously)**

   **Agent 1: rebalance-bot** (Rebalancing Analysis)
   - Task: "Analyze current vs target allocations and identify significant portfolio drift requiring correction. Calculate specific trades needed to restore strategic targets. Consider tax implications and suggest tax-efficient rebalancing strategies. Prioritize trades by magnitude of drift and importance."

   **Agent 2: risk-shield-manager** (Risk Validation)
   - Task: "Validate rebalancing plan to ensure proposed trades don't violate risk limits or create new concentrations. Check that final allocation aligns with risk parameters and IPS guidelines. Assess market timing considerations and execution risks."

   **Agent 3: tax-scout** (Tax Optimization)
   - Task: "Optimize trade sequencing for tax efficiency. Identify tax-loss harvesting opportunities within rebalancing. Consider wash-sale rule compliance and lot selection strategies. Balance rebalancing needs with tax optimization benefits."

2. **Sequential Execution Phase (After Parallel Planning Completes)**

   **Trade Execution (Trader Jane)**
   - Use trader-jane-execution agent for optimal trade execution
   - Apply appropriate order slicing and venue selection for each trade
   - Monitor execution progress and market impact
   - Provide real-time execution reports and cost analysis

   **Cash Management (Cash Treasury Steward)**
   - Use cash-treasury-steward agent for optimal cash deployment
   - Manage cash flows from sales and ensure efficient reinvestment
   - Optimize cash buffers and sweep arrangements
   - Coordinate with trade execution timing

   **Compliance Verification (Compliance Sentinel)**
   - Use compliance-sentinel agent for pre and post-trade compliance checks
   - Validate all trades meet regulatory and account-specific requirements
   - Generate compliance logs and audit trail
   - Flag any potential issues before execution

**Output Format:**
- Rebalancing Summary: Current vs target allocations and required trades
- Execution Plan: Specific trade orders with optimal routing and timing
- Tax Impact Analysis: Estimated tax consequences and optimization strategies
- Cost Estimate: Expected transaction costs and market impact
- Completion Report: Final allocations, execution quality, and performance impact

Execute rebalancing with institutional-quality precision while minimizing costs and tax impact to maximize long-term portfolio efficiency.
Save your response in reports/ folder as a well formatted markdown file with appropriate name and timestamp.