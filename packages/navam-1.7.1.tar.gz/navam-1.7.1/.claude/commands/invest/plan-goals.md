You are helping create a comprehensive financial plan aligned with the user's investment goals and time horizons. Execute this goal-based planning workflow:

**⚡ PERFORMANCE OPTIMIZATION (CRITICAL):**

**Phase 1: Information Gathering**
First, gather user's financial information through conversation:
   - Financial goals, time horizons
   - Current assets, income, expenses
   - Risk tolerance and constraints
   - Tax situation and preferences

**Phase 2: PARALLEL Agent Coordination (CRITICAL FOR SPEED)**
Once you have the information, launch these specialized agents IN PARALLEL using the Task tool - DO NOT run them sequentially:

1. **compass-goal-planner** - Goal mapping and risk profiling
2. **atlas-investment-strategist** - Strategic asset allocation
3. **risk-shield-manager** - Risk validation and stress testing

**CRITICAL INSTRUCTIONS:**
- Use the Task tool to launch ALL THREE agents SIMULTANEOUSLY in a single response
- Pass gathered user information as context to each agent
- Wait for ALL agents to complete before synthesizing results
- This parallel approach reduces execution time from ~10 minutes to ~2-3 minutes (70% faster)

**WORKFLOW: Financial Goal Planning & Investment Strategy**

1. **Information Gathering Phase**
   - Collect user's financial situation through conversation
   - Document all relevant information for agents

2. **PARALLEL Agent Execution (Use Task Tool for ALL THREE Simultaneously)**

   Launch all three agents IN PARALLEL in a SINGLE response with three Task tool calls:

   **Agent 1: compass-goal-planner** (Goal Mapping & Risk Profiling)
   - Task: "Create comprehensive goal map and risk profile using this information: [user data]. Develop goal prioritization with funding requirements, risk assessment (capacity/willingness/need), and emergency fund calculations."

   **Agent 2: atlas-investment-strategist** (Strategic Asset Allocation)
   - Task: "Design strategic asset allocation for goals using this information: [user data]. Create goal-based allocation recommendations, dynamic glide paths, performance benchmarks, and tax-optimization strategies."

   **Agent 3: risk-shield-manager** (Risk Validation)
   - Task: "Validate financial plan against risk parameters using this information: [user data]. Stress test strategy against market scenarios, ensure diversification, and create contingency plans."

3. **Synthesis & Implementation Planning**
   - Wait for ALL three agents to complete
   - Combine insights into comprehensive financial plan
   - Create detailed Investment Policy Statement (IPS)
   - Establish rebalancing triggers and monitoring framework

**Output Format:**
- Executive Summary: Goal achievement probability and recommended strategy
- Detailed IPS: Asset allocation targets, risk parameters, rebalancing rules
- Implementation Roadmap: Specific steps, account setup, initial investments
- Monitoring Framework: Review schedule, performance benchmarks, adjustment triggers

Create a comprehensive financial plan that transforms aspirations into actionable investment strategies with clear accountability measures and realistic timelines.
Save your response in reports/ folder as a well formatted markdown file with appropriate name and timestamp.