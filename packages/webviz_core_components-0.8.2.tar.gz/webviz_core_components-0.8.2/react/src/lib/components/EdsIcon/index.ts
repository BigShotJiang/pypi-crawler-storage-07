export { EdsIcon } from "./EdsIcon";
