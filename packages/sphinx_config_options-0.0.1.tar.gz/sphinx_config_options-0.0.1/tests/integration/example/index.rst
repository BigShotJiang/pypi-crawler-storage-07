
Test doc
========

Configuration Options
======================

.. config:option:: test_option
   :shortdesc: A test configuration option
   :type: string
   :default: default_value

   This is a test configuration option used for integration testing.
