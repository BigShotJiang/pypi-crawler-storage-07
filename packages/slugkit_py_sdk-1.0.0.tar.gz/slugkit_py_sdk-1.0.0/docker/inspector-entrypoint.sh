#!/bin/sh
# MCP Inspector Docker Entrypoint Script

set -e

# Default configuration file path
CONFIG_FILE="/app/config/mcp.json"
DEFAULT_SERVER="default"

# Check if config file exists
if [ -f "$CONFIG_FILE" ]; then
    echo "🔧 Found MCP configuration at: $CONFIG_FILE"
    
    # Check if a specific server is requested
    if [ -n "$MCP_SERVER_NAME" ]; then
        echo "🎯 Using server: $MCP_SERVER_NAME"
        exec npx @modelcontextprotocol/inspector --config "$CONFIG_FILE" --server "$MCP_SERVER_NAME"
    else
        # Try to use 'default' server, or let inspector handle it
        echo "🎯 Using default server configuration"
        exec npx @modelcontextprotocol/inspector --config "$CONFIG_FILE" --server "$DEFAULT_SERVER" || \
        exec npx @modelcontextprotocol/inspector --config "$CONFIG_FILE"
    fi
else
    echo "⚠️  No MCP configuration found at: $CONFIG_FILE"
    echo "📝 Starting inspector in interactive mode"
    echo "   You can configure servers through the web UI"
    exec npx @modelcontextprotocol/inspector
fi