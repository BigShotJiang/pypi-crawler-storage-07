# MCP Inspector Docker Container
# Uses the official approach: npx @modelcontextprotocol/inspector
FROM node:20-alpine

# Install dumb-init for proper signal handling
RUN apk add --no-cache dumb-init

# Create non-root user
RUN addgroup -g 1001 -S mcp && \
    adduser -S mcp -u 1001 -G mcp

# Set working directory
WORKDIR /app

# Set environment variables
ENV HUSKY=0
ENV NODE_ENV=production
ENV HOST=0.0.0.0
ENV CLIENT_PORT=3000
ENV SERVER_PORT=6277

# Pre-install the MCP Inspector package globally to speed up startup
RUN npm install -g @modelcontextprotocol/inspector

# Copy the entrypoint script
COPY ./docker/inspector-entrypoint.sh /usr/local/bin/entrypoint.sh
RUN chmod +x /usr/local/bin/entrypoint.sh

# Create necessary directories
RUN mkdir -p config logs && chown -R mcp:mcp /app

# Switch to non-root user
USER mcp

# Expose the client port (default 6274, but we're using 3000 for consistency)
EXPOSE 3000 6277

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=60s --retries=3 \
    CMD node -e "require('http').get('http://localhost:3000', (res) => { process.exit(res.statusCode === 200 || res.statusCode === 404 ? 0 : 1) }).on('error', () => { process.exit(1) })"

# Use dumb-init as PID 1
ENTRYPOINT ["dumb-init", "--"]

# Start the MCP Inspector
# The inspector will serve on CLIENT_PORT (3000) by default
CMD ["/usr/local/bin/entrypoint.sh"]
