"""Storage domain implementation."""
