# streamlit-custom-component

Filter Component for Streamlit and Cube Alchemy

## Installation instructions

```sh
pip install cube-alchemy-streamlit-components
```

## Usage

```python
from cube_alchemy_streamlit_components import filter
```

## Example

```python
streamlit run cube_alchemy_streamlit_components/filter/example.py
```