# 📦 NomDuProjet

Une courte description de ce que fait ton projet.

---

## 🚀 Fonctionnalités

- ✅ Fonctionnalité 1
- ✅ Fonctionnalité 2
- 🔧 Fonctionnalité en cours de développement

---

## 🛠️ Installation

Installe ce paquet via `pip` :

```bash
pip install nomduprojet

