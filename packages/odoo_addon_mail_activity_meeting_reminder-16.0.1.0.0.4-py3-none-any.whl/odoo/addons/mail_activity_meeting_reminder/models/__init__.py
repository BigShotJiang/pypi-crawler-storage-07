from . import mail_activity_type
from . import mail_activity
