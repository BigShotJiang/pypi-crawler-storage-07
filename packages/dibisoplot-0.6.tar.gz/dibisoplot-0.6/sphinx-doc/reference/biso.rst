BiSO
====

.. automodule:: dibisoplot.biso
   :members:
   :show-inheritance:
   :undoc-members:
