import logging

FFMPEG_PATH = "ffmpeg"
FFPROBE_PATH = "ffprobe"

logger = logging.getLogger("matvtool")
