""" Generic IOS-XE service implementations. """

__author__ = "Myles Dear"

import re
from unicon.eal.dialogs import Dialog
from unicon.core.errors import SubCommandFailure
from unicon.bases.routers.services import BaseService


from unicon.plugins.generic.service_implementation import (
    Configure as GenericConfigure,
    Execute as GenericExecute,
    Ping as GenericPing,
    HaConfigureService as GenericHAConfigure,
    HaExecService as GenericHAExecute,
    HAReloadService as GenericHAReload,
    SwitchoverService as GenericHASwitchover,
    Traceroute as GenericTraceroute,
    Copy as GenericCopy,
    ResetStandbyRP as GenericResetStandbyRP,
    Reload as GenericReload,
    Enable as GenericEnable,
    ContextMgrBaseService)


from .service_statements import execute_statement_list, configure_statement_list, confirm

from .statements import grub_prompt_stmt, boot_from_rommon_stmt

from unicon.plugins.generic.utils import GenericUtils
from unicon.plugins.generic.service_implementation import BashService as GenericBashService


# Simplex Services
# ----------------
class Configure(GenericConfigure):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.dialog += Dialog(configure_statement_list)

        class ConfigUtils(GenericUtils):
            def truncate_trailing_prompt(self, con_state,
                                         result,
                                         hostname=None,
                                         result_match=None):
                host_idx = result.rfind(hostname)
                if host_idx != -1:
                    result = result[:host_idx]
                else:
                    if result_match and len(result_match.last_match.groups()) > 2:
                        idx = result.rfind(result_match.last_match.group(2))
                        if idx:
                            result = result[:idx]
                return result

        self.utils = ConfigUtils()

    def pre_service(self, *args, **kwargs):

        self.acm_configlet = kwargs.pop('acm_configlet', None)
        self.syntax_configlet = kwargs.pop('syntax_configlet', None)
        self.config_syntax_check = kwargs.pop('config_syntax_check', False)
        self.rules = kwargs.pop('rules', False)
        self.prompt_recovery = kwargs.get('prompt_recovery', True)

        if self.acm_configlet:
            self.connection.state_machine.go_to('acm', self.connection.spawn,context={'acm_configlet': self.acm_configlet})
            self.start_state = 'acm'
            self.end_state = 'acm'

        elif self.rules:
            if self.connection.connected:
                self.connection.state_machine.go_to('rules', self.connection.spawn)
                self.start_state = 'rules'
                self.end_state = 'rules'

        elif self.syntax_configlet or self.config_syntax_check:
            configlet_name = self.syntax_configlet if self.syntax_configlet else ''
            self.connection.state_machine.go_to('syntax', self.connection.spawn,
                                                context={'syntax_configlet': configlet_name})
            self.start_state = 'syntax'
            self.end_state = 'syntax'

        else:
            super().pre_service(*args, **kwargs)

    def post_service(self, *args, **kwargs):
        if self.acm_configlet:
            self.connection.state_machine.go_to('enable', self.connection.spawn)
        elif self.rules:
            self.connection.state_machine.go_to('enable', self.connection.spawn)
        else:
            super().post_service(*args, **kwargs)


class Config(Configure):
    pass


class ConfigSyntax(Configure):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.start_state = 'syntax'
        self.end_state = 'enable'


class Execute(GenericExecute):

    def __init__(self, connection, context, **kwargs):
        super().__init__(connection, context, **kwargs)
        self.dialog += Dialog(execute_statement_list)


class Traceroute(GenericTraceroute):
    def call_service(self, addr, command="traceroute", vrf=None, timeout=None,
                     error_pattern=None, **kwargs):
        if 'vrf' not in command and vrf:
            command = command.replace('traceroute', 'traceroute vrf {}'.format(str(vrf)))
        super().call_service(addr=addr, command=command, error_pattern=error_pattern, timeout=timeout, **kwargs)


class Ping(GenericPing):
    def call_service(self, addr, command="", *, vrf=None, **kwargs):
        command = command if command else "ping vrf {vrf}".format(vrf=vrf) if vrf else "ping"
        super().call_service(addr=addr, command=command, **kwargs)


class Copy(GenericCopy):
    def call_service(self, reply=Dialog([]), vrf=None, *args, **kwargs):
        if vrf is not None:
            kwargs['extra_options'] = kwargs.setdefault('extra_options', '') + ' vrf {}'.format(vrf)
        super().call_service(reply=reply, *args, **kwargs)


# HA Services
# -----------
class HAConfigure(GenericHAConfigure):

    def __init__(self, connection, context, **kwargs):
        super().__init__(connection, context, **kwargs)
        self.dialog += Dialog(configure_statement_list)

    def pre_service(self, *args, **kwargs):
        self.acm_configlet = kwargs.pop('acm_configlet', None)
        self.syntax_configlet = kwargs.pop('syntax_configlet', None)
        self.rules = kwargs.pop('rules', False)
        self.prompt_recovery = kwargs.get('prompt_recovery', True)

        if self.acm_configlet:
            self.connection.state_machine.go_to('acm', self.connection.spawn,context={'acm_configlet': self.acm_configlet})
            self.start_state = 'acm'
            self.end_state = 'acm'

        if self.syntax_configlet:
            self.connection.state_machine.go_to('syntax', self.connection.spawn,context={'syntax_configlet': self.syntax_configlet})
            self.start_state = 'syntax'
            self.end_state = 'syntax'
        elif self.rules:
            if self.connection.connected:
                self.connection.state_machine.go_to('rules', self.connection.spawn)
                self.start_state = 'rules'
                self.end_state = 'rules'
        else:
            super().pre_service(*args, **kwargs)

    def post_service(self, *args, **kwargs):
        if self.acm_configlet:
            self.connection.state_machine.go_to('enable', self.connection.spawn)
        elif self.rules:
            self.connection.state_machine.go_to('enable', self.connection.spawn)
        else:
            super().post_service(*args, **kwargs)


class HAConfig(HAConfigure):
    pass


class HAExecute(GenericHAExecute):

    def __init__(self, connection, context, **kwargs):
        super().__init__(connection, context, **kwargs)
        self.dialog += Dialog(execute_statement_list)


class HAReload(GenericHAReload):

    def __init__(self, connection, context, **kwargs):
        super().__init__(connection, context, **kwargs)

    def pre_service(self, *args, **kwargs):
        self.prompt_recovery = self.connection.prompt_recovery
        if 'prompt_recovery' in kwargs:
            self.prompt_recovery = kwargs.get('prompt_recovery')
        self.context.pop('boot_prompt_count', None)
        sm = self.get_sm()
        if sm.current_state != 'rommon':
            return super().pre_service(*args, **kwargs)

    # Non-stacked platforms such as ASR and ISR do not use the same
    # reload command as the generic implementation (whose reload command
    # covers stackable platforms only).
    def call_service(self, command=[], reload_command=[], reply=Dialog([]), timeout=None, *args, **kwargs):
        sm = self.get_sm()

        self.context["image_to_boot"] = \
            kwargs.get("image_to_boot", kwargs.get('image', ''))

        # boot_cmd is used by the boot_image handler, see statements.py
        if sm.current_state == 'rommon' and reload_command:
            self.connection.active.context['boot_cmd'] = reload_command

        if command:
            super().call_service(command or "reload", reply=reply,
                                 timeout=timeout, *args, **kwargs)
        else:
            super().call_service(reload_command=reload_command or "reload", reply=reply,
                                 timeout=timeout, *args, **kwargs)


class HASwitchover(GenericHASwitchover):
    def call_service(self, command=[], reply=Dialog([]), timeout=None, *args,
                     **kwargs):
        super().call_service(command, reply=reply + Dialog([confirm]), timeout=timeout, *args, **kwargs)


class BashService(GenericBashService):

    def pre_service(self, *args, **kwargs):
        handle = self.get_handle(kwargs.get('target'))
        if kwargs.get('switch'):
            handle.context['_switch'] = kwargs.get('switch')
        else:
            handle.context.pop('_switch', None)
        if kwargs.get('rp'):
            handle.context['_rp'] = kwargs.get('rp')
        else:
            handle.context.pop('_rp', None)
        if kwargs.get('chassis'):
            handle.context['_chassis'] = kwargs.get('chassis')
        else:
            handle.context.pop('_chassis', None)
        if kwargs.get('disable_selinux') is not None:
            handle.context['_disable_selinux'] = kwargs.get('disable_selinux')
        elif hasattr(self, 'disable_selinux'):
            handle.context['_disable_selinux'] = self.disable_selinux
        else:
            handle.context.pop('_disable_selinux', None)
        super().pre_service(*args, **kwargs)

    class ContextMgr(GenericBashService.ContextMgr):
        def __init__(self, connection, enable_bash=False, timeout=None, **kwargs):
            super().__init__(connection=connection,
                             enable_bash=enable_bash,
                             timeout=timeout,
                             **kwargs)

        def __enter__(self):

            if self.conn.context.get('_disable_selinux'):
                try:
                    self.conn.execute('set platform software selinux permissive')
                except SubCommandFailure:
                    pass

            self.conn.log.debug('+++ attaching bash shell +++')
            # enter shell prompt
            self.conn.state_machine.go_to(
                'shell',
                self.conn.spawn,
                timeout=self.timeout,
                context=self.conn.context)

            for cmd in self.conn.settings.BASH_INIT_COMMANDS:
                self.conn.execute(
                    cmd, timeout=self.timeout)

            return self

        def __exit__(self, type, value, traceback):
            res = super().__exit__(type, value, traceback)

            if self.conn.context.get('_disable_selinux'):
                try:
                    self.conn.execute('set platform software selinux default')
                except SubCommandFailure:
                    pass

            return res

class ResetStandbyRP(GenericResetStandbyRP):
    """ Service to reset the standby rp.

    Arguments:

        command: command to reset standby, default is"redundancy reload peer"
        dialog: Dialog which include list of Statements for
                 additional dialogs prompted by standby reset command,
                 in-case it is not in the current list.
        timeout: Timeout value in sec, Default Value is 500 sec

    Returns:
        True on Success, raise SubCommandFailure on failure.

    Example:
        .. code-block:: python

            rtr.reset_standby_rp()
            # If command is other than 'redundancy reload peer'
            rtr.reset_standby_rp(command="command which will reset standby rp",
            timeout=600)

    """

    def __init__(self, connection, context, **kwargs):
        super().__init__(connection, context, **kwargs)
        self.prompt_recovery = connection.prompt_recovery

    def call_service(self, command='redundancy reload peer',
                     reply=Dialog([]),
                     timeout=None,
                     *args,
                     **kwargs):
        super().call_service(command=command,
                             reply=reply,
                             timeout=timeout,
                             standby_check='STANDBY HOT',
                             *args,
                             **kwargs)


class Reload(GenericReload):

    def __init__(self, connection, context, **kwargs):
        super().__init__(connection, context, **kwargs)
        # Add the grub prompt statement
        self.dialog += Dialog([grub_prompt_stmt, boot_from_rommon_stmt])

    def pre_service(self, *args, **kwargs):
        self.prompt_recovery = self.connection.prompt_recovery
        if 'prompt_recovery' in kwargs:
            self.prompt_recovery = kwargs.get('prompt_recovery')
        self.context.pop('boot_prompt_count', None)
        sm = self.get_sm()
        if sm.current_state != 'rommon':
            return super().pre_service(*args, **kwargs)

    def call_service(self,
                     reload_command='reload',
                     dialog=Dialog([]),
                     reply=Dialog([]),
                     timeout=None,
                     return_output=False,
                     reload_creds=None,
                     grub_boot_image=None,
                     post_reload_wait_time=None,
                     *args, **kwargs):
        sm = self.get_sm()

        # update the context with the boot_image
        self.context.update({'grub_boot_image': grub_boot_image})

        self.context["image_to_boot"] = \
            kwargs.get("image_to_boot", kwargs.get('image', ''))

        # boot_cmd is used by the boot_image handler, see statements.py
        if sm.current_state == 'rommon' and reload_command != 'reload':
            self.context['boot_cmd'] = reload_command

        super().call_service(
            reload_command=reload_command,
            dialog=dialog,
            reply=reply,
            timeout=timeout,
            return_output=return_output,
            reload_creds=reload_creds,
            post_reload_wait_time=post_reload_wait_time,
            *args, **kwargs)

        self.context.pop("image_to_boot", None)
        self.context.pop("grub_boot_image", None)


class Rommon(GenericExecute):
    """ Brings device to the Rommon prompt and executes commands specified
    """
    def __init__(self, connection, context, **kwargs):
        # Connection object will have all the received details
        super().__init__(connection, context, **kwargs)
        self.start_state = 'rommon'
        self.end_state = 'rommon'
        self.service_name = 'rommon'
        self.__dict__.update(kwargs)

    def log_service_call(self):
        via = self.handle.via
        alias = self.handle.alias if hasattr(self.handle, 'alias') and self.handle.alias != 'cli' else None
        self.handle.alias
        if alias and via:
            self.connection.log.info(
                "+++ %s with via '%s' and alias '%s': %s +++" %
                (self.connection.hostname if
                 (self.connection.hostname !=
                  self.connection.settings.DEFAULT_LEARNED_HOSTNAME) else "",
                 via, alias, self.service_name))
        elif via:
            self.connection.log.info(
                "+++ %s with via '%s': %s +++" %
                (self.connection.hostname if
                 (self.connection.hostname !=
                  self.connection.settings.DEFAULT_LEARNED_HOSTNAME) else "",
                 via, self.service_name))
        else:
            self.connection.log.info(
                "+++ %s: %s +++" %
                (self.connection.hostname if
                 (self.connection.hostname != self.connection.settings.DEFAULT_LEARNED_HOSTNAME) else "",
                 self.service_name))

    def pre_service(self, *args, **kwargs):
        self.timeout = kwargs.get('reload_timeout', 600)
        sm = self.get_sm()
        con = self.connection
        sm.go_to('enable',
                 con.spawn,
                 context=self.context)
        confreg = kwargs.get('config_register', "0x0")
        con.configure('config-register {}'.format(confreg))
        super().pre_service(*args, **kwargs)


class HARommon(Rommon):
    """ Brings device to the Rommon prompt and executes commands specified
    """
    def __init__(self, connection, context, **kwargs):
        # Connection object will have all the received details
        super().__init__(connection, context, **kwargs)
        self.start_state = 'rommon'
        self.end_state = 'rommon'
        self.service_name = 'rommon'
        self.__dict__.update(kwargs)

    def pre_service(self, *args, **kwargs):
        con = self.connection

        # call pre_service to reload to rommon
        super().pre_service(*args, **kwargs)

        # check connection states
        subcon1, subcon2 = list(con._subconnections.values())

        # Check current state
        for subcon in [subcon1, subcon2]:
            subcon.sendline()
            subcon.state_machine.go_to(
                'any',
                subcon.spawn,
                context=subcon.context,
                prompt_recovery=subcon.prompt_recovery,
                timeout=subcon.connection_timeout,
            )
            con.log.debug('{} in state: {}'.format(subcon.alias, subcon.state_machine.current_state))



class Tclsh(Execute):

    def __init__(self, connection, context, **kwargs):
        super().__init__(connection, context, **kwargs)
        self.start_state = 'tclsh'
        self.end_state = 'tclsh'
        self.service_name = 'tclsh'
        self.__dict__.update(kwargs)

class Syntaxsh(BaseService):

    def __init__(self, connection, context, **kwargs):
        super().__init__(connection, context, **kwargs)
        self.start_state = 'enable'
        self.end_state = 'syntax_check'
        self.service_name = 'syntax_check'

    def call_service(self, syntax_file=None, **kwargs):
        cmd = f"syntax configlet check {syntax_file}" if syntax_file else "syntax configlet check"
        self.connection.spawn.sendline(cmd)
        self.connection.state_machine.go_to('syntax_check', self.connection.spawn, **kwargs)

class MaintenanceMode(ContextMgrBaseService):

    def __init__(self, connection, context, **kwargs):
        super().__init__(connection, context, **kwargs)
        self.context_state = 'maintenance'
        self.service_name = 'maintenance'
        self.start_state = "enable"
        self.end_state = "enable"

        self.__dict__.update(kwargs)
