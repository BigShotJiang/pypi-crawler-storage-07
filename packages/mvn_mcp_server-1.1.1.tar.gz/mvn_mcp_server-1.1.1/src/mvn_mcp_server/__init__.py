"""Maven MCP Server package initialization."""

__version__ = "1.1.1"
__author__ = "Daniel Scholl"
__license__ = "MIT"
__all__ = ["__version__", "__author__", "__license__"]
