# -*- coding: utf-8 -*-

from .caster import elastictranscoder_caster

caster = elastictranscoder_caster

__version__ = "1.40.0"