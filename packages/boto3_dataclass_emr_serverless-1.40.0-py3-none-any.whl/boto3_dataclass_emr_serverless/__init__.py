# -*- coding: utf-8 -*-

from .caster import emr_serverless_caster

caster = emr_serverless_caster

__version__ = "1.40.0"