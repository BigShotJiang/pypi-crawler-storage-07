# pipeline/__init__.py

from .pipeline import Pipeline
