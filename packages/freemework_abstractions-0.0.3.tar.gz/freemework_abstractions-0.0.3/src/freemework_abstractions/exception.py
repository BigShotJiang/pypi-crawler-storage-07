class FException(BaseException):
    pass