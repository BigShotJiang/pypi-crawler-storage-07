# Copyright 2014 OpenStack Foundation
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
#

"""start networking-sfc chain

Revision ID: start_networking_sfc
Revises: None
Create Date: 2015-09-10 18:42:08.262632

"""

# revision identifiers, used by Alembic.
revision = 'start_networking_sfc'
down_revision = None


def upgrade():
    pass
