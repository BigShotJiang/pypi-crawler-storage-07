"""Pydantic models for configuration validation - internal use only."""
