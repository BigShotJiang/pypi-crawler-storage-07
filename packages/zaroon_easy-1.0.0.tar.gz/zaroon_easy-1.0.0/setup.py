from setuptools import setup, find_packages

setup(
    name="zaroon-easy",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[],  # add any dependencies here
    entry_points={
        "console_scripts": [
            "zaroon=zaroon.__main__:main"
        ],
    },
    author="Your Name",
    description="A simple interpreted programming language made in Python",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    python_requires=">=3.7",
)
    