# @omlish-lite
from ..magic.styles import C_MAGIC_STYLE


##


class CextMagic:
    KEY = '@omlish-cext'
    STYLE = C_MAGIC_STYLE
