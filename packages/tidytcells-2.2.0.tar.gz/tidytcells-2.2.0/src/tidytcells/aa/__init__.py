"""
Functions to manage amino acid sequence data.
"""

from ._standardize import standardize, standardise
