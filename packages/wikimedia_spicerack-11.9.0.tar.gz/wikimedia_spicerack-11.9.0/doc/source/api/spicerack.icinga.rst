icinga
======

.. automodule:: spicerack.icinga
