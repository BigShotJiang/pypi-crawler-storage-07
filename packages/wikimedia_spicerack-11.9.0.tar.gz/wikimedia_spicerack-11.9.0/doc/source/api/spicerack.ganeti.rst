ganeti
======

.. automodule:: spicerack.ganeti
