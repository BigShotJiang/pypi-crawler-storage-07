constants
=========

.. automodule:: spicerack.constants
