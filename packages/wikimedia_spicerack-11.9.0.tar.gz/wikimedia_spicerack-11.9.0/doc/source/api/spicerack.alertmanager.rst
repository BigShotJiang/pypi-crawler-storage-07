alertmanager
============

.. automodule:: spicerack.alertmanager
