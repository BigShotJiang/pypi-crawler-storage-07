kafka
======

.. automodule:: spicerack.kafka
