puppet
======

.. automodule:: spicerack.puppet
