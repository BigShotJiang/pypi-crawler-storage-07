"""Spicerack external modules package."""
