# -*- coding: utf-8 -*-

from .caster import codestar_notifications_caster

caster = codestar_notifications_caster

__version__ = "1.40.0"