"""Domain models and exceptions for freewriting feature.

This package contains the core business logic and domain models
for the freewriting feature, including session state and domain exceptions.
"""
