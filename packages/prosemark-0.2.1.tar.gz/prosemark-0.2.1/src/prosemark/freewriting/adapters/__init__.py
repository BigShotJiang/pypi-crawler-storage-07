"""Adapter implementations for freewriting feature.

This package contains concrete implementations of the port interfaces,
integrating the freewriting domain with external systems and frameworks.
"""
