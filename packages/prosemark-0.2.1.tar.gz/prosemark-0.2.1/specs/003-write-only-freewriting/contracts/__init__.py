"""Contracts for freewriting module.

This package defines the port interfaces and data models
for the freewriting domain.
"""
# Namespace package marker for contracts
