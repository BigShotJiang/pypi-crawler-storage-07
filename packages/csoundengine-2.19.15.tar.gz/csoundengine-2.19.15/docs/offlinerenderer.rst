
OfflineSession Class
====================

.. autoclass:: csoundengine.offline.OfflineSession
    :members:
    :autosummary:
