TableProxy
==========

.. autoclass:: csoundengine.tableproxy.TableProxy
    :members: