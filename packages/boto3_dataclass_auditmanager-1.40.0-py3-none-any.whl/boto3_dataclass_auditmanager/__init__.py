# -*- coding: utf-8 -*-

from .caster import auditmanager_caster

caster = auditmanager_caster

__version__ = "1.40.0"