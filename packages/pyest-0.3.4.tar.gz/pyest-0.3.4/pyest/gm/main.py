from gm import main      # this comes from a compiled binary
main()
