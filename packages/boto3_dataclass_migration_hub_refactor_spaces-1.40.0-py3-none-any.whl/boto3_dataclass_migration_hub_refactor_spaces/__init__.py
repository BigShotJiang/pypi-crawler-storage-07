# -*- coding: utf-8 -*-

from .caster import migration_hub_refactor_spaces_caster

caster = migration_hub_refactor_spaces_caster

__version__ = "1.40.0"