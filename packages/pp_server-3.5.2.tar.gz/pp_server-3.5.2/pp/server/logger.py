################################################################
# pp.server - Produce & Publish Server
# (C) 2021, ZOPYX,  Tuebingen, Germany
################################################################
"""package wide logger module"""

from loguru import logger as LOG  # noqa
