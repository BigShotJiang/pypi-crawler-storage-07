class TabbySetDiffFail(Exception):
    pass