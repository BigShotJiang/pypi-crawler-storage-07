# amlibpy

This library is a collection of utilities that can be helpful when working with amLib software.

## Surfboard (incl Surfride)
It also includes `amlibpy.surf`, for working with Surfboard files. This library allows both low-level modification of files, as well as providing a high-level interface to common structures. The high-level interface is very incomplete, but changes made through either interface reflect in the other.

Even though the high-level interface is incomplete, all reading and writing of Surfboard files is performed using the low-level interface, and lossless round-tripping is guaranteed. If you manage to cause losssy round-tripping, that's a bug!

The following is an example of how `amlibpy.surf` can be used to modify all strings in a given surfboard file:

```py
surf = VTBF_Reader(open("example_input.srd", "rb")).load()

assert surf.type == "SRFF"
sr = surf.children[0]

all_text = sr.find_deep(surfride.SurfRide_TEXT)
for i in all_text:
    i.text = b"Hello world!"

VTBF_Writer(open("example_output.srd", "wb")).dump(surf)
```
