import struct
import typing
import zlib


class StreamBase:
    def __init__(
        self, stream: "typing.BinaryIO | StreamBase", start: int = 0, end: int = -1
    ):
        self._stream = stream
        self._file_cursor = start

        if end == -1:
            stream.seek(0, 2)
            end = stream.tell()

        self._slice_start = start
        self._slice_end = end

    def readable(self):
        return self._stream.readable()

    def writable(self):
        return self._stream.writable()

    def __getitem__(self, val: slice | typing.Any) -> "Stream":
        if not isinstance(val, slice):
            raise ValueError("Cannot index stream")
        if val.step not in (1, None):
            raise ValueError("Streams cannot be stepped")

        if val.start is None and val.stop is None:
            return Stream(self._stream)
        elif val.start is None:
            return Stream(
                self._stream, self._slice_start, self._slice_start + val.stop
            )
        elif val.stop is None:
            return Stream(
                self._stream, self._slice_start + val.start, self._slice_end
            )
        else:
            return Stream(
                self._stream,
                self._slice_start + val.start,
                self._slice_start + val.stop,
            )

    def at_end(self) -> bool:
        return self._file_cursor >= self._slice_end

    def read(self, n: int) -> bytes:
        self._stream.seek(self._file_cursor)
        if self._file_cursor + n > self._slice_end:
            n = self._slice_end - self._file_cursor

        self._file_cursor += n
        return self._stream.read(n)

    def write(self, data: bytes):
        self._stream.seek(self._file_cursor)
        if self._file_cursor + len(data) > self._slice_end:
            data = data[:self._slice_end - self._file_cursor]

        self._file_cursor += len(data)
        self._stream.write(data)

    def seek(self, n: int, whence: int = 0):
        if whence == 0:
            self._file_cursor = self._slice_start + n
        elif whence == 1:
            self._file_cursor += n
        elif whence == 2:
            self._file_cursor = self._slice_end - n

    def tell(self) -> int:
        return self._file_cursor - self._slice_start


class StreamWriter(StreamBase):
    MAX_SIZE = 0xFFFFFFFF  # 4GB

    def __init__(
        self, stream: "typing.BinaryIO | StreamBase", start: int = 0, end: int = 0xFFFFFFFF
    ):
        assert stream.writable()
        super().__init__(stream, start, end)

    def __getitem__(self, val: slice | typing.Any) -> "StreamWriter":
        if not isinstance(val, slice):
            raise ValueError("Cannot index stream")
        if val.step not in (1, None):
            raise ValueError("Streams cannot be stepped")

        if val.start is None and val.stop is None:
            return StreamWriter(self._stream)
        elif val.start is None:
            return StreamWriter(
                self._stream, self._slice_start, self._slice_start + val.stop
            )
        elif val.stop is None:
            return StreamWriter(
                self._stream, self._slice_start + val.start, self._slice_end
            )
        else:
            return StreamWriter(
                self._stream,
                self._slice_start + val.start,
                self._slice_start + val.stop,
            )

    def crc32(self, nbytes: int) -> int:
        start = self.tell()
        data = self.read(nbytes)
        self.seek(start)
        return zlib.crc32(data) & 0xFFFFFFFF

    def skip(self, n):
        self.read(n)

    def pack(self, fmt, *values):
        self.write(struct.pack("<" + fmt, *values))

    def u8(self, value: int):
        self.pack("B", value)

    def u16(self, value: int):
        self.pack("H", value)

    def u32(self, value: int):
        self.pack("I", value)

    def i16(self, value: int):
        self.pack("h", value)

    def i32(self, value: int):
        self.pack("i", value)

    def f4(self, value: float):
        self.pack("f", value)

    def ipv4(self, value: tuple[int, int, int, int]):
        self.pack("4B", *value)

    def ipv6(self, value: tuple[int, int, int, int, int, int, int, int]):
        self.pack("8H", *value)

    # def str(self, n: int, value: str):
    #     self.pack(f"{n}s", value)

    def bytes(self, value: bytes, n: int | None = None):
        if n is None:
            n = len(value)
        self.pack(f"{n}s", value)


class Stream(StreamBase):
    def __init__(
        self, stream: "typing.BinaryIO | StreamBase", start: int = 0, end: int = -1
    ):
        assert stream.readable()
        super().__init__(stream, start, end)

    def crc32(self, nbytes: int) -> int:
        start = self.tell()
        data = self.read(nbytes)
        self.seek(start)
        return zlib.crc32(data) & 0xFFFFFFFF

    def skip(self, n, null=True):
        if null:
            if any(self.read(n)):
                raise ValueError(f"Skipped not-null bytes {self.tell()-n:08x}-{self.tell()+n:08x}")
        else:
            self.read(n)

    def unpack(self, fmt):
        return struct.unpack("<" + fmt, self.read(struct.calcsize(fmt)))

    def u8(self):
        return self.unpack("B")[0]

    def u16(self):
        return self.unpack("H")[0]

    def u32(self):
        return self.unpack("I")[0]

    def i16(self):
        return self.unpack("h")[0]

    def i32(self):
        return self.unpack("i")[0]

    def f4(self):
        return self.unpack("f")[0]

    def ipv4(self):
        return self.unpack("4B")

    def ipv6(self):
        return self.unpack("8H")

    def str(self, n):
        return self.unpack(f"{n}s")[0].decode("latin-1")

    def str_z(self):
        out = ""
        while not out.endswith("\0"):
            out += self.str(1)
        return out[:-1]
