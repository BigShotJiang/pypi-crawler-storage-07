from dataclasses import dataclass
import typing

from ..stream import Stream, StreamWriter
from .vtc import VTC, VTC_Reader, VTC_Writer


@dataclass
class VTBF:
    type: str
    version: int
    unk: int
    children: list[VTC]

    @classmethod
    def from_json(cls, model):
        return cls(
            model["type"],
            model["version"],
            model["unk"],
            [VTC.from_json(i) for i in model["children"]],
        )

    def to_json(self):
        return {
            "type": self.type,
            "version": self.version,
            "unk": self.unk,
            "children": [i.to_json() for i in self.children],
        }


class VTBF_Writer(StreamWriter):
    VTBF_MAGIC = b"VTBF"
    VTC_MAGIC = b"vtc0"

    def __init__(self, writable: typing.BinaryIO):
        super().__init__(writable)

    def dump(self, vtbf: VTBF):
        self.bytes(self.VTBF_MAGIC, 4)
        self.u32(vtbf.version)
        self.bytes(vtbf.type.encode(), 4)
        self.u16(len(vtbf.children))
        self.u8(0x00)
        self.u8(0x4C)

        for i in vtbf.children:
            self._dump_vtc0(i)

    def _dump_vtc0(self, vtc: VTC):
        self.bytes(self.VTC_MAGIC, 4)
        # self.u32(0)  # Reserve space for the length

        # Write the VTC
        slice = self[self.tell() + 4:]
        VTC_Writer(slice).dump(vtc)

        self.u32(slice.tell())
        self.seek(slice.tell(), 1)

        for i in vtc.children:
            self._dump_vtc0(i)


class VTBF_Reader(Stream):
    VTBF_MAGIC = b"VTBF"
    VTC_MAGIC = b"vtc0"

    def __init__(self, readable: typing.BinaryIO):
        super().__init__(readable)

        self._root: VTC | None = None

    def load(self) -> VTBF:
        assert self.read(4) == self.VTBF_MAGIC

        version = self.u32()  # Probably a version number? 1.0 BCD?
        type = self.read(4).decode()
        child_count = self.u16()  # Unknown
        unk = self.u16()  # Unknown always 004C

        children: list[VTC] = []
        while True:
            vtc = self._load_vtc0()
            if vtc is None:
                break
            self._init_vtc(vtc)
            children.append(vtc)

        assert len(children) == child_count

        return VTBF(type, version, unk, children)

    def _load_vtc0(self) -> VTC | None:
        magic = self.read(4)
        if not magic:
            return None
        assert magic == self.VTC_MAGIC
        length = self.u32()
        start = self.tell()

        type = self.read(4).decode()  # Peeking into the VTC header
        self.seek(length - 4, 1)

        if type not in KNOWN_VTC:
            # raise IndexError(f"Unknown {type}")
            print(f"Unknown {type}")

        type_ = KNOWN_VTC.get(type, VTC)
        parent, num_children = VTC_Reader(
            self._root, self[start : start + length]
        ).load(type_)

        if self._root is None:
            self._root = parent

        for _ in range(num_children):
            child = self._load_vtc0()
            assert child is not None
            parent.children.append(child)

        return parent

    def _init_vtc(self, vtc0: VTC):
        vtc0._pre_init()
        for i in vtc0.children:
            self._init_vtc(i)
        vtc0._post_init()


KNOWN_VTC: dict[str, type[VTC]] = {}
