import typing
from dataclasses import dataclass, field
from enum import IntEnum

from ..stream import Stream, StreamWriter


T = typing.TypeVar("T")
T_VTC = typing.TypeVar("T_VTC", bound="VTC")

COMPACT_DIMENSIONS = (2, 3, 4, 9, 16)
# ENCODING = "latin-1"  # Works, but at what cost
# ENCODING = "shift_jis"  # Old files
# ENCODING = "utf-8"  # New files


class PropertyType(IntEnum):
    None_ = 0x00  # 0 bytes
    Bool = 0x01
    AnsiString = 0x02  # n bytes
    Char = 0x03
    UChar = 0x04
    Short = 0x05
    UShort = 0x06
    ShortAngle = 0x07
    Long = 0x08
    ULong = 0x09
    Float = 0x0A
    Angle = 0x0B
    ARGB8888 = 0x0C
    Double = 0x0D
    ArraySeparator = 0x0E  # 0 bytes

    IllegalType = 0x0F


@dataclass
class PropertyDefinition:
    tag: int
    type: PropertyType | None


@dataclass
class Property:
    type: PropertyType
    tag: int
    value: typing.Any

    _touched: bool = field(default=False, repr=False)

    def to_json(self):
        if self.type == PropertyType.AnsiString:
            return {
                "type": self.type.name,
                "tag": self.tag,
                "value": self.value.hex(),
            }
        else:
            return {"type": self.type.name, "tag": self.tag, "value": self.value}

    @classmethod
    def from_json(cls, model):
        if model["type"] == "AnsiString":
            return cls(
                PropertyType[model["type"]],
                model["tag"],
                bytes.fromhex(model["value"]),
            )
        else:
            return cls(PropertyType[model["type"]], model["tag"], model["value"])

    def __str__(self):
        return f"{self.__class__.__name__}(type={self.type.name}, tag={self.tag:02x}, value={self.value})"


T = typing.TypeVar("T")


class PropertyProxy(typing.Generic[T]):
    def __init__(self, parent_vtc: "VTC", property_index: int):
        self.parent_vtc = parent_vtc
        self.property_index = property_index

    def get(self) -> T:
        return self.parent_vtc.properties[self.property_index].value

    # def __get__(self) -> T:
    #     return self.get()

    # def set(self, value: T):
    #     self.parent_vtc.properties[self.property_index].value = value

    # def __set__(self, value: T):
    #     self.set(value)

    def __eq__(self, other: T):
        return self.get() == other

    # def __hash__(self):
    #     return self.get().__hash__()

    # def __(self):
    #     return self.get().__hash__()

    # def __getattr__(self, name):
    #     return getattr(self.get(), name)


@dataclass
class VTC:
    type: str
    properties: list[Property]
    children: "list[VTC]"

    root: "VTC | None" = field(default=None, repr=False)
    _touched: bool = field(default=False, repr=False)
    _property_registry: dict[str, int] = field(default_factory=lambda: {}, repr=False)

    def __setattr__(self, name: str, value: typing.Any) -> None:
        if not isinstance(value, PropertyProxy):
            object.__setattr__(self, name, value)
            return

        if name in self._property_registry:
            if isinstance(value, PropertyProxy):
                raise RuntimeError(f"Double-assigned property: {name}")
            self.properties[self._property_registry[name]].value = value
        else:
            self._property_registry[name] = value.property_index

    def __getattr__(self, name: str) -> typing.Any:
        if name not in self._property_registry:
            raise AttributeError
        return self.properties[self._property_registry[name]].value

    def to_json(self):
        return {
            "type": self.type,
            "properties": [i.to_json() for i in self.properties],
            "children": [i.to_json() for i in self.children],
        }

    @classmethod
    def from_json(cls, model):
        return cls(
            model["type"],
            [Property.from_json(i) for i in model["properties"]],
            [cls.from_json(i) for i in model["children"]],
        )

    def _pre_init(self):
        """Initialisation function called before children have been initialised"""
        pass

    def _post_init(self):
        """Initialisation function called after children have been initialised"""
        pass

    def get_child(self, type: str, required_class: typing.Type[T_VTC]) -> T_VTC:
        for i in self.children:
            if i.type == type:
                i._touched = True

                assert isinstance(i, required_class)
                return i
        raise KeyError

    def get_children(
        self, type: str, required_class: typing.Type[T_VTC]
    ) -> list[T_VTC]:
        for i in self.children:
            if i.type == type:
                i._touched = True
        ret = [i for i in self.children if i.type == type]
        assert all(isinstance(i, required_class) for i in ret)
        return ret  # type: ignore

    def get_property(
        self, tag: PropertyDefinition, default: T, at_index: int = -1
    ) -> T:
        if at_index != -1:
            prop = self.properties[at_index]
            if prop.tag != tag.tag:
                raise ValueError(f"Expected {tag.tag:02x} but saw {prop.tag:02x}")
            if prop.type != tag.type:
                raise ValueError(f"Expected {tag.type.name} but saw {prop.type.name}")

            prop._touched = True
            return PropertyProxy[T](self, at_index)  # type: ignore

        for n, i in enumerate(self.properties):
            if i.tag == tag.tag:
                if i.type != tag.type:
                    raise ValueError(f"Expected {tag.type.name} but saw {i.type.name}")

                i._touched = True
                return PropertyProxy[T](self, n)  # type: ignore
        # return default
        # raise IndexError(f"Property {tag.type} not found!")

        return None  # TODO:

    def get_property_multiple(self, tag: PropertyDefinition) -> list:
        for i in self.properties:
            if i.tag == tag.tag:
                if tag.type is not None and i.type != tag.type:
                    raise ValueError(f"Expected {tag.type.name} but saw {i.type.name}")

                i._touched = True
        return [i.value for i in self.properties if i.tag == tag.tag]

    def assert_fully_touched(self):
        bad = False
        for i in self.properties:
            if not i._touched:
                print("Untouched property:", self.type, i)
                bad = True
        for i in self.children:
            if not i._touched:
                print("Untouched child:", self.type, i.type, i)
                bad = True
        assert not bad

    def print_vtc_tree(self, indent=""):
        for i in self.children:
            print(f"{indent}├── {i.type}")
            i.print_vtc_tree(indent + "│  ")

    def find_deep(self, type: typing.Type[T]) -> typing.Iterator[T]:
        if isinstance(self, type):
            yield self
        for i in self.children:
            for i in i.find_deep(type):
                yield i


class VTC_Writer(StreamWriter):
    def __init__(self, writable: StreamWriter):
        super().__init__(writable)

    def dump(self, vtc: VTC):
        self.bytes(vtc.type.encode(), 4)
        self.u16(len(vtc.children))
        self.u16(len(vtc.properties))

        for i in vtc.properties:
            self._write_property(i)

    def _write_property(self, prop: Property):
        self.u8(prop.tag)
        type_flags = prop.type
        if isinstance(prop.value, list):
            content = prop.value
            length = len(prop.value)
            if length in (2, 3, 4, 9, 16):
                type_flags |= 0x40
                self.u8(type_flags)
                self.u8(COMPACT_DIMENSIONS.index(length))
            else:
                type_flags |= 0x80
                self.u8(type_flags)
                if length <= 0x100:
                    self.u8(1 << 3)
                    self.u8(length - 1)
                elif length <= 0x10000:
                    self.u8(2 << 3)
                    self.u16(length - 1)
                elif length <= 0x100000000:
                    self.u8(3 << 3)
                    self.u32(length - 1)
                else:
                    raise ValueError(f"Impossibly large {length}")
        else:
            content = [prop.value]
            self.u8(type_flags)

        for value in content:
            match prop.type:
                case PropertyType.None_:
                    pass
                case PropertyType.Bool:
                    self.u8(value)
                case PropertyType.AnsiString:
                    if len(value) > 0x7FFF:
                        raise ValueError(f"Impossibly large {len(value)}")
                    elif len(value) > 0x7F:
                        self.u8((len(value) >> 8) | 0x80)
                        self.u8(len(value) & 0xFF)
                    else:
                        self.u8(len(value))
                    self.write(value)
                case PropertyType.Char:
                    self.u8(ord(value))
                case PropertyType.UChar:
                    self.u8(value)
                case PropertyType.Short:
                    self.i16(value)
                case PropertyType.UShort:
                    self.u16(value)
                # ShortAngle
                case PropertyType.Long:
                    self.i32(value)
                case PropertyType.ULong:
                    self.u32(value)
                case PropertyType.Float:
                    self.f4(value)
                case PropertyType.Angle:
                    self.u32(value)
                case PropertyType.ARGB8888:
                    if isinstance(value, int):
                        value = (
                            value >> 24,
                            (value >> 16) & 0xFF,
                            (value >> 8) & 0xFF,
                            value & 0xFF,
                        )
                    elif isinstance(value, str):
                        value = value.lstrip("#")
                        value = (
                            int(value[6:8], 16) if len(value) > 6 else 255,
                            int(value[0:2], 16),
                            int(value[2:4], 16),
                            int(value[4:6], 16),
                        )
                    else:
                        raise ValueError
                    self.u8(value[0])
                    self.u8(value[1])
                    self.u8(value[2])
                    self.u8(value[3])
                # Double
                # ArraySeparator


class VTC_Reader(Stream):
    def __init__(self, root: "VTC | None", stream: Stream):

        super().__init__(stream)
        self.root = root

    def load(self, instance_type: typing.Type[VTC] = VTC):
        type = self.read(4).decode()
        num_children = self.u16()
        num_properties = self.u16()

        children: list[VTC] = []
        properties: list[Property] = []

        for _ in range(num_properties):
            prop = self._read_property()
            if isinstance(prop, PropertyProxy):
                raise RuntimeError
            properties.append(prop)

        assert self.at_end()

        return instance_type(type, properties, children, self.root), num_children

    def _read_property(self):
        tag = self.u8()
        type_flags = self.u8()

        type = PropertyType(type_flags & 0x3F)

        has_dim1 = type_flags & 0x40
        has_dim2 = type_flags & 0x80

        has_dimension = has_dim1 or has_dim2

        if has_dim1 and has_dim2:
            raise ValueError("No idea how to handle this!")

        dimension = 1
        if has_dimension:
            dimensions = self.u8()

            if has_dim2:
                extra = (dimensions & 0b000_11_000) >> 3

                if extra == 1:
                    dimension *= self.u8() + 1
                elif extra == 2:
                    dimension *= self.u16() + 1
                elif extra == 3:
                    dimension *= self.u32() + 1
                else:
                    print("Warn: Invalid extra", extra)

            if has_dim1:
                dimension *= COMPACT_DIMENSIONS[dimensions & 0b000_00_111]

        content = []
        for _ in range(dimension):
            match type:
                case PropertyType.None_:
                    value = None
                case PropertyType.Bool:
                    value = self.u8()
                    assert value in (0, 1)
                    value = not not value
                case PropertyType.AnsiString:
                    length = self.u8()
                    if length & 0x80:
                        length = (length & 0x7F) << 8 | self.u8()
                    value = self.read(length)  # .decode(ENCODING)  # TODO
                case PropertyType.Char:
                    value = chr(self.u8())
                case PropertyType.UChar:
                    value = self.u8()
                case PropertyType.Short:
                    value = self.i16()
                case PropertyType.UShort:
                    value = self.u16()
                # ShortAngle
                case PropertyType.Long:
                    value = self.i32()
                case PropertyType.ULong:
                    value = self.u32()
                case PropertyType.Float:
                    value = self.f4()
                case PropertyType.Angle:
                    value = self.u32()
                case PropertyType.ARGB8888:
                    a, r, g, b = self.read(4)
                    value = (a, r, g, b)

                    # Round-tripping through JSON loses the tuple information,
                    # so we want to make sure we don't use tuples
                    # value = value[0] << 24 | value[1] << 16 | value[2] << 8 | value[3]

                    # print(f"#{r:02X}{g:02X}{b:02X}{a:02X}", value)
                    value = f"#{r:02X}{g:02X}{b:02X}{a:02X}"

                # Double
                # ArraySeparator
                case _:
                    raise ValueError(f"! Unknown type {type:02x}")

            content.append(value)

        if has_dimension:
            return Property(type, tag, content)
        return Property(type, tag, content[0])
