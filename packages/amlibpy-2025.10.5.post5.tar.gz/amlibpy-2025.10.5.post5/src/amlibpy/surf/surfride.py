from dataclasses import dataclass
from enum import ReprEnum
import typing

from .vtbf import KNOWN_VTC
from .vtc import VTC, PropertyDefinition, PropertyType


T = typing.TypeVar("T")
# TODO: Use this
T_Property = typing.TypeVar("T_Property", bound="SR_Property")


class SR_Property(PropertyDefinition, ReprEnum):
    # 0X = Project
    Proj_SceneCount = 0x00, PropertyType.UShort
    Proj_TexListCount = 0x01, PropertyType.UShort
    # 02
    Name = 0x03, PropertyType.AnsiString
    Scene_BackColour = 0x04, PropertyType.ARGB8888
    Proj_FontCount = 0x05, PropertyType.UShort
    Proj_Version = 0x06, PropertyType.Long  # Guessed that this is a version number
    CatType = 0x0D, PropertyType.UChar
    CatCount = 0x0E, PropertyType.UShort
    CatData = 0x0F, PropertyType.IllegalType  # Type is based on CatType

    # 1X = Scene
    Scene_LayerCount = 0x10, PropertyType.UShort
    Scene_CameraCount = 0x11, PropertyType.UShort
    Scene_CameraPosition = 0x12, PropertyType.Float
    Scene_CameraTarget = 0x13, PropertyType.Float
    Scene_CameraFOV = 0x14, PropertyType.Angle
    Scene_CameraZNear = 0x15, PropertyType.Float
    Scene_CameraZFar = 0x16, PropertyType.Float
    Scene_AnimationCount = 0x17, PropertyType.UShort

    # 2X = Layer
    Layer_Flags = 0x20, PropertyType.ULong
    Layer_CastCount = 0x21, PropertyType.UShort
    Layer_AnimationCount = 0x22, PropertyType.UShort
    Layer_23 = 0x23, PropertyType.UChar  # Array [64]

    # 3X = Node
    Node_Flags = 0x30, PropertyType.ULong
    Node_TranslationXY = 0x31, PropertyType.Float
    Node_RotationZ = 0x32, PropertyType.Angle
    Node_RotationZ_New = 0x32, PropertyType.Long
    Node_ScaleXY = 0x33, PropertyType.Float
    # 34, 35, 36
    Node_MaterialColour = 0x37, PropertyType.ARGB8888
    Node_IlluminationColour = 0x38, PropertyType.ARGB8888
    Node_VertexColour = 0x39, PropertyType.ARGB8888
    Node_Display = 0x3A, PropertyType.Bool
    Node_Child = 0x3B, PropertyType.Short
    Node_Sibling = 0x3C, PropertyType.Short
    Node_MultiPosFlags = 0x3D, PropertyType.UShort
    Node_MultiPosFlags_New = 0x3D, PropertyType.Short
    Node_MultiSizeFlags = 0x3E, PropertyType.UShort
    # Why are these three here??
    Node_A0 = 0xA0, PropertyType.Long
    Node_CommentLength = 6, PropertyType.Short  # Proj_Version??
    Node_Comment = 7, PropertyType.AnsiString  # Project??

    # 4X = Images
    Width = 0x40, PropertyType.UShort
    Height = 0x41, PropertyType.UShort
    Width_Float = 0x40, PropertyType.Float
    Height_Float = 0x41, PropertyType.Float
    PivotX = 0x42, PropertyType.Float
    PivotY = 0x43, PropertyType.Float
    CropRefCount = 0x44, PropertyType.UShort
    CropIndex = 0x45, PropertyType.Short
    CropIndex_New = 0x45, PropertyType.UShort
    CropImage_46 = 0x46, PropertyType.Short
    # 47
    Image_CastFlags = 0x48, PropertyType.ULong
    CropRef = 0x49, PropertyType.Short
    CropRef_New = 0x49, PropertyType.ULong
    # 4A
    CropImage_4B = 0x4B, PropertyType.UChar
    CropImage_4C = 0x4C, PropertyType.Short
    CropImage_4D = 0x4D, PropertyType.UShort
    CropImage_4E = 0x4E, PropertyType.Short
    # Note that Anim_Motion_CastIndex is a Short
    Image_CastIndex = 0x51, PropertyType.UShort

    # 5X = Animations
    Anim_MotionCount = 0x50, PropertyType.UShort
    Anim_Motion_CastIndex = 0x51, PropertyType.Short
    Anim_TrackCount = 0x52, PropertyType.UShort
    Anim_TrackType = 0x53, PropertyType.UShort
    Anim_TrackFlags = 0x54, PropertyType.ULong
    Anim_StartFrame = 0x55, PropertyType.Long
    Anim_EndFrame = 0x56, PropertyType.Long
    Anim_EndFrame_NEW = 0x56, PropertyType.Short
    Anim_TrackKeyCount = 0x57, PropertyType.UShort
    Anim_TrackFirstFrame = 0x58, PropertyType.Long
    Anim_TrackLastFrame = 0x59, PropertyType.Long
    Anim_KeyProp0 = 0x5A, PropertyType.Long
    Anim_KeyProp1 = 0x5B, PropertyType.Long
    Anim_KeyProp2 = 0x5C, PropertyType.UShort
    Anim_KeyProp3 = 0x5D, PropertyType.Float
    Anim_KeyProp4 = 0x5E, PropertyType.Float
    Anim_Unknown5F_NEW = 0x5F, PropertyType.ULong
    Anim_Unknown5F = 0x5F, PropertyType.Bool

    Track_KeyFrame = 0x5A, PropertyType.Long
    Track_KeyValue = 0x5B, None
    Track_Interpolation = 0x5C, PropertyType.UShort
    Track_InParam = 0x5D, PropertyType.Float
    Track_OutParam = 0x5E, PropertyType.Float

    # 6X = Textures
    Tex_Count = 0x60, PropertyType.UShort
    Tex_Filename = 0x61, PropertyType.AnsiString
    Tex_Flags = 0x62, PropertyType.ULong
    Tex_CropCount = 0x63, PropertyType.UShort
    # 64
    Tex_CropInfo = 0x65, PropertyType.Short  # Array [4]

    # 7X = Fonts
    Font_70 = 0x70, PropertyType.ULong
    Font_71 = 0x71, PropertyType.UShort

    # 9X = Unknown
    Unk_90 = 0x90, PropertyType.AnsiString
    Unk_91 = 0x91, PropertyType.AnsiString
    Unk_92 = 0x92, PropertyType.Short
    Unk_93 = 0x93, PropertyType.Short
    Unk_94 = 0x94, PropertyType.Float
    Unk_95 = 0x95, PropertyType.Bool

    # FX = Misc
    ListStart = 0xFC, PropertyType.None_
    ListEnd = 0xFD, PropertyType.None_
    ListSeparator = 0xFE, PropertyType.None_


@dataclass
class PropListEntry:
    name: str
    type: PropertyDefinition
    optional: bool = False


class SR_VTC(VTC):
    def is_new_version(self):
        assert self.root is not None
        assert isinstance(self.root, SurfRide_SRCK)
        prj = self.root.project
        assert isinstance(prj, SurfRide_Project)

        # Observed values:
        # -1 from maimai
        #  1 from Chunithm
        return prj.version == 1

    def __iter__(self):
        self._prop_index = 0
        return self

    def __next__(self):
        if self._prop_index == 0:
            self.get_property(SR_Property.ListStart, None, 0)
        elif self._prop_index == len(self.properties) - 1:
            self.get_property(SR_Property.ListEnd, None, self._prop_index)
            raise StopIteration
        else:
            self.get_property(SR_Property.ListSeparator, None, self._prop_index)

        self._prop_index += 1
        return self

    def next_property(self, tag: PropertyDefinition, default: T) -> T:
        prop = self.get_property(tag, default, self._prop_index)
        self._prop_index += 1
        return prop

    def as_property_list(self, tags: tuple[PropListEntry, ...]):
        entries = []
        index = 0
        while index < len(self.properties):
            if index == 0:
                self.get_property(SR_Property.ListStart, None, index)
            elif index == len(self.properties) - 1:
                self.get_property(SR_Property.ListEnd, None, index)
                break
            else:
                self.get_property(SR_Property.ListSeparator, None, index)
            index += 1

            list_entry = {}
            for entry in tags:
                prop = self.properties[index]
                if prop.tag != entry.type.tag:
                    if entry.optional:
                        continue
                    else:
                        raise ValueError(
                            f"{entry.name}: Expected tag {entry.type.tag:02x} but saw {prop.tag:02x}"
                        )

                if prop.type != entry.type.type:
                    raise ValueError(
                        f"{entry.name}: Expected {entry.type.type.name} but saw {prop.type.name}"
                    )

                list_entry[entry.name] = prop.value
                prop._touched = True
                index += 1

            entries.append(list_entry)

        return entries

        # chunks = []
        # self.get_property(SR_Property.ListStart, None, 0)
        # chunk = []
        # for i in range(1, len(self.properties)):
        #     self.properties[i]._touched = True

        #     if self.properties[i].tag == SR_Property.ListSeparator.tag:
        #         chunks.append(chunk)
        #         chunk = []
        #     else:
        #         chunk.append(self.properties[i])
        # chunks.append(chunk)

        # entries = []
        # for chunk in chunks:
        #     entry = {}
        #     for prop in chunk:
        #         for match in tags:
        #             if prop.tag == match[1].tag:
        #                 entry[match[0]] = prop.value
        #     entries.append(entry)
        return entries


class SurfRide_SRCK(SR_VTC):
    def _pre_init(self):
        self.project = self.get_child("PROJ", SurfRide_Project)

        self.assert_fully_touched()


class SurfRide_Project(SR_VTC):
    def _pre_init(self):
        scene_count: int = self.get_property(SR_Property.Proj_SceneCount, -1)
        tex_list_count: int = self.get_property(SR_Property.Proj_TexListCount, -1)
        self.name: bytes = self.get_property(SR_Property.Name, b"")
        font_count: int = self.get_property(SR_Property.Proj_FontCount, -1)
        self.version = self.get_property(SR_Property.Proj_Version, -1)  # Guessed

        self.start_frame: int = self.get_property(SR_Property.Anim_StartFrame, 0)
        self.end_frame: int = self.get_property(SR_Property.Anim_EndFrame, 0)

        self.scenes = self.get_children("SCN ", SurfRide_Scene)
        self.tex_lists = self.get_children("TEXL", SurfRide_TextureList)
        self.fonts = self.get_children("FONT", SurfRide_Font)
        self.camera = self.get_child("CAM ", SurfRide_Camera)
        # TODO:
        # print([i.type for i in self.children])
        # self.catr = self.get_children("CATR", SurfRide_CATR)
        self.get_children("CATR", SR_VTC)

        assert scene_count == len(self.scenes)
        assert tex_list_count == len(self.tex_lists)
        assert font_count == len(self.fonts)

        self.assert_fully_touched()


class SurfRide_Texture(SR_VTC):
    def _post_init(self):
        self.width = self.get_property(SR_Property.Width, -1)
        self.height = self.get_property(SR_Property.Height, -1)
        self.filename = self.get_property(SR_Property.Tex_Filename, b"")
        self.flags = self.get_property(SR_Property.Tex_Flags, -1)
        self.crop_count = self.get_property(SR_Property.Tex_CropCount, -1)

        self.crop = self.get_child("CROP", SurfRide_Crop)
        assert self.crop_count == len(self.crop.crops)

        self.assert_fully_touched()


class SurfRide_Crop(SR_VTC):
    @dataclass
    class Crop:
        top_left: tuple[int, int]
        bottom_right: tuple[int, int]

    def _post_init(self):
        self.crops = [
            self.Crop((i[0], i[1]), (i[2], i[3]))
            for i in self.get_property_multiple(SR_Property.Tex_CropInfo)
        ]

        self.assert_fully_touched()


class SurfRide_TextureList(SR_VTC):
    def _post_init(self):
        self.name: bytes = self.get_property(SR_Property.Name, b"")
        self.count: int = self.get_property(SR_Property.Tex_Count, 0)

        self.textures = self.get_children("TEX ", SurfRide_Texture)
        assert len(self.textures) == self.count

        self.assert_fully_touched()


class SurfRide_Camera(SR_VTC):
    def _post_init(self):
        self.name = self.get_property(SR_Property.Name, b"")

        self.pos_xyz = self.get_property(
            SR_Property.Scene_CameraPosition, [float("NaN"), float("NaN"), float("NaN")]
        )
        self.target_xyz = self.get_property(
            SR_Property.Scene_CameraTarget, [float("NaN"), float("NaN"), float("NaN")]
        )
        self.fov_y = self.get_property(SR_Property.Scene_CameraFOV, -1)
        self.z_near = self.get_property(SR_Property.Scene_CameraZNear, float("NaN"))
        self.z_far = self.get_property(SR_Property.Scene_CameraZFar, float("NaN"))

        self.assert_fully_touched()


class SurfRide_Font(SR_VTC):
    def _post_init(self):
        self.filename = self.get_property(SR_Property.Name, b"")
        self.unknown_70 = self.get_property(SR_Property.Font_70, -1)
        self.unknown_71 = self.get_property(SR_Property.Font_71, -1)

        self.assert_fully_touched()


class SurfRide_Character(SR_VTC):
    def _post_init(self):
        self.assert_fully_touched()


class SurfRide_Scene(SR_VTC):
    def _post_init(self):
        self.name = self.get_property(SR_Property.Name, b"")
        self.back_colour = self.get_property(SR_Property.Scene_BackColour, (0, 0, 0, 0))
        self.layer_count = self.get_property(SR_Property.Scene_LayerCount, 0)
        self.camera_count = self.get_property(SR_Property.Scene_CameraCount, 0)
        self.animation_count = self.get_property(SR_Property.Scene_AnimationCount, 0)
        self.width = self.get_property(SR_Property.Width, -1)
        self.height = self.get_property(SR_Property.Height, -1)

        self.layers = self.get_children("LAYR", SurfRide_Layer)
        # TODO: Find a surfboard with ANMS (what's ANMS? It's not ANIM)
        self.animations = self.get_children("ANMS", SR_VTC)
        self.cameras = self.get_children("CAM ", SurfRide_Camera)

        # TODO: One, or multiple, children?
        self.c_attrs = self.get_children("CATR", SR_VTC)

        assert len(self.layers) == self.layer_count
        assert len(self.animations) == self.animation_count
        assert len(self.cameras) == self.camera_count

        self.assert_fully_touched()


class SurfRide_Layer(SR_VTC):
    def _post_init(self):
        self.name = self.get_property(SR_Property.Name, b"")
        self.flags = self.get_property(SR_Property.Layer_Flags, 0)
        self.cast_count = self.get_property(SR_Property.Layer_CastCount, 0)
        self.animation_count = self.get_property(SR_Property.Layer_AnimationCount, 0)
        if self.is_new_version():
            self.get_property(SR_Property.Layer_23, [-1])

        self.cast = self.get_children("CAST", SurfRide_Cast)
        self.animations = self.get_children("ANIM", SurfRide_Animation)
        self.c_attrs = self.get_children("CATR", SR_VTC)

        # assert len(self.cast) == self.cast_count
        # assert len(self.animations) == self.animation_count

        self.assert_fully_touched()


class SurfRide_Cast(SR_VTC):
    def _post_init(self):
        # Node describes the tree structure
        self.node = self.get_child("NODE", SurfRide_Node)
        # TRS2 describes the transforms and colours for each node
        self.trs2 = self.get_child("TRS2", SurfRide_Transform2D)
        self.trs3 = self.get_children("TRS3", SurfRide_Transform3D)  # Optional

        self.data = self.get_child("DATA", SurfRide_DATA)
        if self.is_new_version():
            self.catl = self.get_child("CATL", SR_VTC)
        else:
            self.catr = self.get_children("CATR", SR_VTC)  # Optional
            self.ncat = self.get_child("NCAT", SurfRide_NCAT)

        self.assert_fully_touched()

    def print_tree(self):
        RED = "\033[31;1m"
        GREEN = "\033[32;1m"
        YELLOW = "\033[33m"
        BLUE = "\033[34;1m"
        PINK = "\033[35;1m"
        TEAL = "\033[36;1m"
        RESET = "\033[0m"

        def print_node(pad: int, node):
            # pad *= 2

            transform = self.trs2.props[node["id"]]

            prefix1 = YELLOW + "│  " * pad + "├── " + RESET
            prefix2 = YELLOW + "│  " * pad + "│   " + RED
            prefix3 = YELLOW + "│  " * pad + "│   " + BLUE
            prefix4 = YELLOW + "│  " * pad + "│   " + PINK
            prefix5 = YELLOW + "│  " * pad + "│   " + TEAL

            comment = ""
            name = node["name"].ljust(48 - len(prefix1))
            name = GREEN + name + RESET
            if node.get("commentLength"):
                comment = node["comment"].encode("latin-1").decode("shift_jis")
                print((prefix1) + f"{name} ({comment})")
            else:
                print((prefix1) + f"{name}")

            print(prefix2 + f"Flags:    {node['flags']:08x}" + RESET)
            if "translation" in transform:
                print(
                    prefix2
                    + f"Position: {transform['translation'][0]}, {transform['translation'][1]}"
                    + RESET
                )
            print(
                prefix2
                + f"Scale:    {transform['scale'][0]}, {transform['scale'][1]}"
                + RESET
            )
            print(prefix2 + f"Rotation: {transform['rotation']}" + RESET)

            if node["flags"] & SurfRide_Node.FLAG_HAS_IMAGE:
                if node["flags"] & SurfRide_Node.FLAG_HAS_REF_DATA:
                    crfd = self.data.crfd[node["id"]]
                    print(prefix3 + f"{crfd.str1}" + RESET)
                    print(prefix3 + f"{crfd.str2}" + RESET)
                    print(prefix3 + f"{crfd.s1} {crfd.s2} {crfd.f1} {crfd.b1}" + RESET)
                else:
                    crop = self.data.images[node["id"]]
                    print(prefix3 + f"Size:     {crop.width} x {crop.height}" + RESET)
                    print(prefix3 + f"Pivot:    {crop.pivot_x} {crop.pivot_y}" + RESET)

                    if self.is_new_version():
                        pass
                    else:
                        try:
                            print("!", crop.crop_ref)
                            ref = crop.crop_ref.refs[crop.crop_index[0]]
                        except AttributeError:
                            print(prefix4 + "**CROP REFERENCE MISSING**" + RESET)
                            # TODO: Hmm? Would this be using TEXT instead?
                        else:
                            assert self.root is not None
                            assert isinstance(self.root, SurfRide_SRCK)
                            prj = self.root.project
                            assert isinstance(prj, SurfRide_Project)

                            source = prj.tex_lists[ref[0]].textures[ref[1]]
                            print(prefix4 + f"Sheet:    {source.filename}" + RESET)
                            print(
                                prefix4
                                + f"Slice:    {source.crop.crops[ref[2]].top_left} - {source.crop.crops[ref[2]].bottom_right}"
                                + RESET
                            )

            if hasattr(self, "ncat"):
                ncat = self.ncat.entries[node["id"]]
                for i in ncat:
                    print(prefix5 + f"{i}: {ncat[i]}" + RESET)

        for i in self.node.tree:
            print_node(0, i)
            path = [[0, i["children"]]]
            while path:
                for j in path[-1][1][path[-1][0] :]:
                    path[-1][0] += 1

                    print_node(len(path), j)

                    if j["children"]:
                        path.append([0, j["children"]])
                        break
                else:
                    path.pop(-1)


class SurfRide_Animation(SR_VTC):
    def _post_init(self):
        self.name = self.get_property(SR_Property.Name, b"")
        self.motion_count = self.get_property(SR_Property.Anim_MotionCount, 0)
        if self.is_new_version():
            self.end_frame = self.get_property(SR_Property.Anim_EndFrame_NEW, 0)
        else:
            self.end_frame = self.get_property(SR_Property.Anim_EndFrame, 0)
        if self.is_new_version():
            self.get_property(SR_Property.Anim_Unknown5F_NEW, -1)  # 1 or 0
        else:
            self.get_property(SR_Property.Anim_Unknown5F, -1)  # 1 or 0

        self.motions = self.get_children("MOT ", SurfRide_Motion)

        self.c_attrs = self.get_children("CATR", SR_VTC)

        self.assert_fully_touched()


class SurfRide_Motion(SR_VTC):
    def _post_init(self):
        self.cast_index = self.get_property(SR_Property.Anim_Motion_CastIndex, -1)
        self.track_count = self.get_property(SR_Property.Anim_TrackCount, 0)

        self.tracks = self.get_children("TRK ", SurfRide_Track)

        self.assert_fully_touched()


class SurfRide_Track(SR_VTC):
    def _post_init(self):
        # This is nonsense I'm pretty sure lmao
        # Track type 0 = Value
        # Track type 9 = Colour
        # Track type 11 = null?
        self.track_type = self.get_property(SR_Property.Anim_TrackType, -1)

        self.flags = self.get_property(SR_Property.Anim_TrackFlags, 0)

        self.key_count = self.get_property(SR_Property.Anim_TrackKeyCount, 0)
        self.first_frame = self.get_property(SR_Property.Anim_TrackFirstFrame, 0)
        self.last_frame = self.get_property(SR_Property.Anim_TrackLastFrame, 0)

        self.keys = self.get_child("KEY ", SR_VTC)

        if self.flags & 0b11 in (0, 1):
            inner_mask = (self.flags >> 4) & 0b111
            if inner_mask == 0b001:
                # ulong 5A, float 5B?
                # print(self.keys)
                # raise NotImplementedError  # TODO:
                pass
            elif inner_mask == 0b100:
                # ulong 5A, ulong 5B?
                # print(self.keys)
                # raise NotImplementedError  # TODO:
                pass
            elif inner_mask == 0b101:
                # ulong 5A, 4 byte colour 5B?
                # print(self.keys)
                # raise NotImplementedError  # TODO:
                pass
            else:
                raise ValueError(f"TRK type invalid: {self.flags:02x}")

            # self.props = list(
            #     zip(
            #         self.keys.get_property_multiple(PropertyDefinition(0x5A, type_A)),
            #         self.keys.get_property_multiple(PropertyDefinition(0x5B, type_B)),
            #     )
            # )
        elif self.flags & 0b11 == 3:
            inner_mask = (self.flags >> 4) & 0b111
            type_B = PropertyType.IllegalType

            if inner_mask == 0b001:
                type_B = PropertyType.Float
            elif inner_mask == 0b010:
                type_B = PropertyType.Long
            elif inner_mask == 0b011:
                type_B = PropertyType.Bool
            elif inner_mask == 0b100:
                type_B = PropertyType.Angle
            else:
                raise ValueError(f"TRK type invalid: {self.flags:02x}")

            self.props = list(
                zip(
                    self.keys.get_property_multiple(SR_Property.Track_KeyFrame),
                    self.keys.get_property_multiple(
                        PropertyDefinition(SR_Property.Track_KeyValue.tag, type_B)
                    ),
                    self.keys.get_property_multiple(SR_Property.Track_Interpolation),
                    self.keys.get_property_multiple(SR_Property.Track_InParam),
                    self.keys.get_property_multiple(SR_Property.Track_OutParam),
                )
            )
        else:
            raise ValueError(f"TRK type invalid: {self.flags:02x}")

        # print(hex(self.flags), self.keys)
        # assert len(self.keys.props) == self.key_count

        self.assert_fully_touched()


# class SurfRide_CATR(SR_VTC):
#     def _post_init(self):
#         self.assert_fully_touched()


class SurfRide_ANMS(SR_VTC):
    pass


class SurfRide_Node(SR_VTC):
    FLAG_HAS_IMAGE = 0x00000001
    FLAG_HAS_REF_DATA = 0x00000002

    def _post_init(self):
        if self.is_new_version():
            self.props = self.as_property_list(
                (
                    # TODO: Check this order is correct
                    PropListEntry("name", SR_Property.Name),
                    PropListEntry("flags", SR_Property.Node_Flags),
                    PropListEntry("unk32", SR_Property.Node_RotationZ_New),
                    PropListEntry("unka0", SR_Property.Node_A0),
                    PropListEntry("unk3c", SR_Property.Node_Sibling),
                    PropListEntry("unk3D", SR_Property.Node_MultiPosFlags_New),
                )
            )
        else:
            self.props = self.as_property_list(
                (
                    PropListEntry("name", SR_Property.Name),
                    PropListEntry("flags", SR_Property.Node_Flags),
                    PropListEntry("child", SR_Property.Node_Child),
                    PropListEntry("sibling", SR_Property.Node_Sibling),
                    PropListEntry("commentLength", SR_Property.Node_CommentLength),
                    PropListEntry("comment", SR_Property.Node_Comment, optional=True),
                )
            )

        self.tree = []
        unseated = {n: i for n, i in enumerate(self.props)}

        def seat(index: int, parent):
            node: dict[str, typing.Any] = unseated.pop(index)

            node = dict(**node, id=index, children=[])
            parent.append(node)
            if "child" in node and node["child"] != -1:
                seat(node["child"], node["children"])
            if "sibling" in node and node["sibling"] != -1:
                seat(node["sibling"], parent)

        while unseated:
            seat(min(unseated.keys()), self.tree)

        self.assert_fully_touched()


class SurfRide_CropImage(SR_VTC):
    def _post_init(self):
        self.image_cast_flags = self.get_property(SR_Property.Image_CastFlags, 0)
        self.cast_index = self.get_property(SR_Property.Image_CastIndex, 0)
        self.width = self.get_property(SR_Property.Width_Float, 0)
        self.height = self.get_property(SR_Property.Height_Float, 0)
        self.pivot_x = self.get_property(SR_Property.PivotX, 0)
        self.pivot_y = self.get_property(SR_Property.PivotY, 0)
        if self.is_new_version():
            self.crop_index = -1
            self.get_property_multiple(PropertyDefinition(0x45, None))
            self.get_property_multiple(PropertyDefinition(0x44, None))
        else:
            self.crop_index = self.get_property_multiple(SR_Property.CropIndex)
            crop_ref_count = self.get_property_multiple(SR_Property.CropRefCount)

        if self.is_new_version():
            self.images = self.get_children("CIMG", SurfRide_CropImage)

            self.crop_ref_idk_idk = self.get_property(SR_Property.CropRef_New, 0)
            self.node4b = self.get_property(SR_Property.CropImage_4B, 0)
            self.node46 = self.get_property(SR_Property.CropImage_46, 0)
            self.node4c = self.get_property(SR_Property.CropImage_4C, 0)
            self.node4d = self.get_property(SR_Property.CropImage_4D, 0)
            self.node4e = self.get_property(SR_Property.CropImage_4E, 0)
            self.node83 = self.get_property(
                PropertyDefinition(0x83, PropertyType.Float), float("NaN")
            )
            self.node84 = self.get_property(
                PropertyDefinition(0x84, PropertyType.Float), float("NaN")
            )
            self.node85 = self.get_property(
                PropertyDefinition(0x85, PropertyType.Float), float("NaN")
            )
            self.node86 = self.get_property(
                PropertyDefinition(0x86, PropertyType.Float), float("NaN")
            )
            self.nodeA1 = self.get_property(
                PropertyDefinition(0xA1, PropertyType.ULong), 0
            )

            # self.crop_ref

            self.crop_refs = self.get_children("CREF", SurfRide_CropRef)
            self.texts = self.get_children("TEXT", SurfRide_TEXT)
            self.cre1 = self.get_children("CRE1", SR_VTC)
        else:
            if crop_ref_count[0]:
                self.crop_ref = self.get_child("CREF", SurfRide_CropRef)
                assert len(self.crop_ref.refs) == crop_ref_count[0]
        # TODO: TEXT

        self.assert_fully_touched()


class SurfRide_CropRef(SR_VTC):
    def _post_init(self):
        self.refs = self.get_property_multiple(SR_Property.CropRef)

        # TODO:
        self.get_property_multiple(PropertyDefinition(0x4A, PropertyType.Short))
        self.assert_fully_touched()


class SurfRide_Transform2D(SR_VTC):
    def _post_init(self):
        if self.is_new_version():
            self.props = self.as_property_list(
                (
                    PropListEntry(
                        "transform", PropertyDefinition(0x34, PropertyType.Float)
                    ),
                    PropListEntry(
                        "rotation", PropertyDefinition(0x35, PropertyType.Angle)
                    ),
                    PropListEntry(
                        "scale", PropertyDefinition(0x36, PropertyType.Float)
                    ),
                    PropListEntry(
                        "display", PropertyDefinition(0x3B, PropertyType.Bool)
                    ),
                    # I'd guess maybe a tint?
                    PropListEntry(
                        "col1", PropertyDefinition(0x3A, PropertyType.ARGB8888)
                    ),
                    # Always seems to be #000000FF
                    PropListEntry(
                        "col2", PropertyDefinition(0x33, PropertyType.ARGB8888)
                    ),
                    # Guesses on the name
                    PropListEntry(
                        "multiSize", PropertyDefinition(0x3E, PropertyType.UShort)
                    ),
                    PropListEntry(
                        "multiPos", PropertyDefinition(0x3F, PropertyType.UShort)
                    ),
                )
            )
            # for i in self.props:
            #     print(i)
            # print("!!", self.props[0] )
            # quit()
        else:
            self.props = self.as_property_list(
                (
                    PropListEntry("translation", SR_Property.Node_TranslationXY),
                    PropListEntry("rotation", SR_Property.Node_RotationZ),
                    PropListEntry("scale", SR_Property.Node_ScaleXY),
                    PropListEntry("display", SR_Property.Node_Display),
                    PropListEntry("material", SR_Property.Node_MaterialColour),
                    PropListEntry("illumination", SR_Property.Node_IlluminationColour),
                    PropListEntry("vertex0", SR_Property.Node_VertexColour),
                    PropListEntry("vertex1", SR_Property.Node_VertexColour),
                    PropListEntry("vertex2", SR_Property.Node_VertexColour),
                    PropListEntry("vertex3", SR_Property.Node_VertexColour),
                    PropListEntry("multiPos", SR_Property.Node_MultiPosFlags),
                    PropListEntry("multiSize", SR_Property.Node_MultiSizeFlags),
                )
            )
        self.assert_fully_touched()


class SurfRide_Transform3D(SR_VTC):
    pass


class SurfRide_DATA(SR_VTC):
    def _post_init(self):
        self._images = self.get_children("CIMG", SurfRide_CropImage)
        self.images = {i.cast_index: i for i in self._images}

        self.csli = self.get_children("CSLI", SurfRide_CSLI)
        # print(self.csli)
        # quit()

        self.numbers = self.get_children("CNUM", SR_VTC)

        # TODO:
        self._crfd = self.get_children("CRFD", SurfRide_CropRefData)
        self.crfd = {i.cast_index: i for i in self._crfd}
        self.assert_fully_touched()


class SurfRide_CSLI(SR_VTC):
    def _post_init(self):
        # TODO:

        self.get_property(SR_Property.Width_Float, 0)
        self.get_property(SR_Property.Height_Float, 0)
        self.get_property(SR_Property.PivotX, 0)
        self.get_property(SR_Property.PivotY, 0)
        self.get_property_multiple(PropertyDefinition(0x44, PropertyType.ARGB8888))
        self.get_property(PropertyDefinition(0x45, PropertyType.UShort), 0)
        self.get_property(PropertyDefinition(0x80, PropertyType.ULong), 0)
        self.get_property(PropertyDefinition(0x51, PropertyType.UShort), 0)
        self.get_property(PropertyDefinition(0x4B, PropertyType.UChar), 0)
        self.get_property(PropertyDefinition(0x81, PropertyType.UChar), 0)
        self.get_property(PropertyDefinition(0x82, PropertyType.UChar), 0)
        self.get_property(PropertyDefinition(0x84, PropertyType.UChar), 0)
        self.get_property(PropertyDefinition(0x85, PropertyType.UChar), 0)
        self.get_property_multiple(PropertyDefinition(0x33, PropertyType.ARGB8888))
        # 51, u32
        # 80, u32
        # 81, u16
        # 82, u16
        # 84, u16
        # 85, u16

        self.get_children("CREF", SR_VTC)
        self.get_children("SLIC", SR_VTC)

        self.assert_fully_touched()


class SurfRide_CATL(SR_VTC):
    pass


class SurfRide_NCAT(SR_VTC):
    def _post_init(self):
        self.entries: list[dict] = []
        for _ in self:
            count = self.next_property(SR_Property.CatCount, 0)
            fields = {}
            self.entries.append(fields)

            for _ in range(count):
                name = self.next_property(SR_Property.Name, b"")
                data_type = self.next_property(SR_Property.CatType, -1)
                print(name, data_type)
                match data_type:
                    case 0:
                        fields[name] = self.next_property(
                            PropertyDefinition(
                                SR_Property.CatData.tag, PropertyType.Char
                            ),
                            -1,
                        )
                    case 5:
                        fields[name] = self.next_property(
                            PropertyDefinition(
                                SR_Property.CatData.tag, PropertyType.Long
                            ),
                            -1,
                        )
                    case 7:
                        fields[name] = self.next_property(
                            PropertyDefinition(
                                SR_Property.CatData.tag, PropertyType.Float
                            ),
                            -1,
                        )
                    # 8 is also a float-like type
                    case 9:
                        fields[name] = self.next_property(
                            PropertyDefinition(
                                SR_Property.CatData.tag, PropertyType.AnsiString
                            ),
                            -1,
                        )
                    case _:
                        raise ValueError(f"Unknown ncat {data_type}")

        self.assert_fully_touched()


class SurfRide_TEXT(SR_VTC):
    def _post_init(self):
        self.unk78 = self.get_property(PropertyDefinition(0x78, PropertyType.ULong), 0)
        self.unk79 = self.get_property(PropertyDefinition(0x79, PropertyType.Short), 0)
        self.text = self.get_property(
            PropertyDefinition(0x7A, PropertyType.AnsiString), b""
        )
        self.scale = self.get_property(
            PropertyDefinition(0x36, PropertyType.Float), [float("NaN")]
        )
        self.unk7b = self.get_property(
            PropertyDefinition(0x7B, PropertyType.Short), [0]
        )
        self.unk7c = self.get_property(PropertyDefinition(0x7C, PropertyType.Short), 0)
        self.unk41 = self.get_property(PropertyDefinition(0x41, PropertyType.Short), 0)

        # for i in self.properties:
        #     print(i)
        # print(self.text.encode("latin-1").decode("utf-8"))
        # quit()
        # print("-" * 10)

        self.assert_fully_touched()


class SurfRide_CNUM(SR_VTC):
    pass


class SurfRide_CropRefData(SR_VTC):
    def _post_init(self):
        self.cast_index = self.get_property(SR_Property.Image_CastIndex, -1)
        # TODO:
        self.str1 = self.get_property(SR_Property.Unk_90, b"")
        self.str2 = self.get_property(SR_Property.Unk_91, b"")
        self.s1 = self.get_property(SR_Property.Unk_92, -1)
        self.s2 = self.get_property(SR_Property.Unk_93, -1)
        self.f1 = self.get_property(SR_Property.Unk_94, float("NaN"))
        self.b1 = self.get_property(SR_Property.Unk_95, False)

        # eg CHU_UI_Entry_00_v10
        self.get_property(PropertyDefinition(0x80, PropertyType.AnsiString), b"")
        # eg L_Entry_player
        self.get_property(PropertyDefinition(0x81, PropertyType.AnsiString), b"")
        self.get_property(PropertyDefinition(0x82, PropertyType.UShort), 0)
        self.get_property(PropertyDefinition(0x83, PropertyType.AnsiString), b"")
        self.get_property(PropertyDefinition(0x84, PropertyType.Float), float("NaN"))

        self.assert_fully_touched()


KNOWN_VTC["SRCK"] = SurfRide_SRCK
KNOWN_VTC["PROJ"] = SurfRide_Project  # Done, enough
KNOWN_VTC["TEX "] = SurfRide_Texture  # Done
KNOWN_VTC["TEXL"] = SurfRide_TextureList  # Done
KNOWN_VTC["CROP"] = SurfRide_Crop  # Done
KNOWN_VTC["CAM "] = SurfRide_Camera  # Done
KNOWN_VTC["FONT"] = SurfRide_Font  # Done, enough
KNOWN_VTC["CHAR"] = SurfRide_Character  # Done, enough
KNOWN_VTC["SCN "] = SurfRide_Scene  # Done
KNOWN_VTC["LAYR"] = SurfRide_Layer
KNOWN_VTC["CAST"] = SurfRide_Cast
KNOWN_VTC["ANIM"] = SurfRide_Animation  # Done?
KNOWN_VTC["MOT "] = SurfRide_Motion  # Done
KNOWN_VTC["TRK "] = SurfRide_Track  # Done
KNOWN_VTC["KEY "] = SR_VTC  # KEY is a member of TRK, and has 6 different types!
KNOWN_VTC["CIMG"] = SurfRide_CropImage  # Done
KNOWN_VTC["CREF"] = SurfRide_CropRef  # Done
KNOWN_VTC["TRS2"] = SurfRide_Transform2D  # Done
KNOWN_VTC["TRS3"] = SurfRide_Transform3D  # Done
KNOWN_VTC["NODE"] = SurfRide_Node  # Done
# TODO
KNOWN_VTC["CATR"] = SR_VTC
KNOWN_VTC["ANMS"] = SR_VTC
KNOWN_VTC["DATA"] = SurfRide_DATA
KNOWN_VTC["CSLI"] = SurfRide_CSLI
KNOWN_VTC["CATL"] = SR_VTC
KNOWN_VTC["NCAT"] = SR_VTC
KNOWN_VTC["TEXT"] = SurfRide_TEXT
KNOWN_VTC["CNUM"] = SR_VTC
KNOWN_VTC["CRFD"] = SurfRide_CropRefData
KNOWN_VTC["SANM"] = SR_VTC
KNOWN_VTC["CRE1"] = SR_VTC
KNOWN_VTC["SLIC"] = SR_VTC
