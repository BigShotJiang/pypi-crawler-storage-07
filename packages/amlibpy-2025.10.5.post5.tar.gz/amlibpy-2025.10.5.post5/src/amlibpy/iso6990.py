import struct
import zlib
from dataclasses import dataclass

from .alpha import AlphaDvdSkipper
from .segastruct import BootIDRing
from .stream import Stream


class SEGA_DVD(Stream):
    BLOCK = 2048

    @dataclass
    class SegaDvdFile:
        _MAX_CHUNKS = 65408

        stream: Stream

        offset: int
        slot: int
        name: str

        _key: tuple[bytes, bytes] | None = None
        _boot_id: BootIDRing | None = None

        def __iter__(self):
            self.stream.seek(0)
            return self

        def __next__(self):
            if self.stream.tell() / self.boot_id.seg_size >= self.boot_id.seg_count:
                raise StopIteration
            return self.stream.read(self.boot_id.seg_size)

        def set_key(self, key: tuple[bytes, bytes] | None):
            self._key = key

        @property
        def boot_id(self):
            if self._boot_id is not None:
                return self._boot_id

            boot_id_raw = self.get_boot_id_encrypted()

            _boot_id = BootIDRing.from_bytes(boot_id_raw, key=self._key)

            if _boot_id is None:
                raise ValueError(f"Corrupted Boot ID: {self.name}")

            self._boot_id = _boot_id
            return _boot_id

        def get_boot_id_encrypted(self) -> bytes:
            self.stream.seek(0)
            return self.stream.read(0x200)

        def get_chunk_sums(self) -> tuple[int, ...]:
            self.stream.seek(0x200)
            chunk_sums = struct.unpack("<65408I", self.stream.read(self._MAX_CHUNKS * 4))
            return chunk_sums

    @classmethod
    def from_alpha_stream(cls, alpha_stream: Stream):
        alpha_base = AlphaDvdSkipper(alpha_stream).locate_header()
        if alpha_base is not None:
            return cls(alpha_stream[alpha_base * cls.BLOCK :]), alpha_base * cls.BLOCK
        else:
            return cls(alpha_stream), 0

    def _read_iso_directory_entry(self) -> tuple[int, int]:
        data = self.read(34)
        _, _, extent_lba, _, data_length, *_ = struct.unpack(
            "<BBIIIIxxxxxxxBBBHHBx", data
        )
        return extent_lba, data_length

    def _int16(self):
        lsb = self.u16()
        self.seek(2, 1)  # MSB
        return lsb

    def _int32(self):
        lsb = self.u32()
        self.seek(4, 1)  # MSB
        return lsb

    def seek_block(self, block: int):
        self.seek(block * self.BLOCK)

    def parse_iso6990(self):
        self.seek_block(16)

        extent_lba = logical_block_size = -1
        while True:
            vol_type = self.read(1)[0]
            vol_id = self.read(5)
            assert vol_id == b"CD001"
            vol_version = self.read(1)[0]
            assert vol_version == 1

            if vol_type == 1:  # Primary volume descriptor
                start = self.tell()

                self.seek(1, 1)  # Null
                system = self.read(32).decode("latin-1")
                volume = self.read(32).decode("latin-1")
                self.seek(8, 1)  # Null
                logical_blocks = self._int32()
                self.seek(32, 1)  # Null
                self._int16()  # Volume Set Size
                self._int16()  # Volume Sequence Number

                logical_block_size = struct.unpack("<HH", self.read(4))[0]
                assert logical_block_size == self.BLOCK
                # SEGA don't use the path table
                path_table_size = self._int32()
                assert path_table_size == 0

                self.u32()  # Location of Type-L Path Table
                self.u32()  # Location of the Optional Type-L Path Table
                self.u32()  # Location of Type-M Path Table
                self.u32()  # Location of Optional Type-M Path Table
                extent_lba, _ = self._read_iso_directory_entry()

                # Primary volume
                print(f"Disc name:    {volume.strip()}")
                print(f"System name:  {system.strip()}")
                print(f"Blocks:       {logical_blocks} x {logical_block_size}")

                # We don't care about anything else from here
                self.seek(start + 2041)
            elif vol_type == 255:  # Volume descriptor set terminator
                self.seek(2041, 1)
                break
            else:
                raise ValueError(f"Unknown ISO 9660 volume: {vol_type}")

        if extent_lba == -1:
            raise ValueError("No volumes found")

        # Read the root directory
        self.seek(extent_lba * self.BLOCK)
        lba, length = self._read_iso_directory_entry()
        assert lba == extent_lba

        return lba, length

    def _parse_sega_table(self) -> list[SegaDvdFile]:
        start = self.tell()
        size, crc = struct.unpack("<II", self.read(8))
        assert size == 0x800

        data = self.read(size - 8)
        if zlib.crc32(data) & 0xFFFFFFFF != crc:
            raise ValueError("Sega table corrupt! Unable to read storage information")
        self.seek(start + 8)

        games = []
        while True:
            offset, filename = struct.unpack("<I4s", self.read(8))
            if offset == 0 and filename == b"\0\0\0\0":
                break

            slot = offset >> 24
            offset &= 0xFFFFFF

            games.append(
                self.SegaDvdFile(
                    self[offset * self.BLOCK :],
                    offset * self.BLOCK,
                    slot,
                    filename.decode("latin-1"),
                )
            )

        self.seek(start + size)
        return games

    def parse_sega_dvd(self):
        # Alpha DVD is done, time for ISO 6990
        lba, length = self.parse_iso6990()

        # self.seek(length, 1)
        self.seek(lba * self.BLOCK + length)

        self.seek(487 * self.BLOCK, 1)  # ?? It works, but... what?

        # Looking at segaboot, the answer is we just skip over all this entirely
        # and jump to hardcoded offsets
        self.seek_block(511)

        return self._parse_sega_table()
