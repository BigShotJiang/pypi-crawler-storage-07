from dataclasses import dataclass
from enum import IntEnum
import re


FLOAT = r"\s*(\d+(?:\.\d+)?)\s*"
INT = r"\s*(\d+)\s*"

SR_RE = re.compile(f"^{FLOAT},{FLOAT},{FLOAT},{INT},{INT},{INT},{INT},?$")
SZ_RE = re.compile(f"^{FLOAT},{FLOAT},{FLOAT},{INT},{INT},{INT},{INT},?$")
SC_RE = re.compile(f"^{FLOAT},{FLOAT},{FLOAT},{INT},{INT},{INT},{INT},{INT},?$")
SD_RE = re.compile(f"^{FLOAT},{FLOAT},{FLOAT},{INT},{INT},{INT},{INT},{INT},{FLOAT},?$")


class ChartFormat(IntEnum):
    SR = 0
    SZ = 1
    SC = 2
    SD = 3


RE = {
    ChartFormat.SR: SR_RE,
    ChartFormat.SZ: SZ_RE,
    ChartFormat.SC: SC_RE,
    ChartFormat.SD: SD_RE,
}


class NoteType(IntEnum):
    StartSlide = 0
    EndSlide = 1
    Tap = 2
    Hold = 3
    Break = 4
    Star = 5
    BreakStar = 6


@dataclass
class CompoundMoneyScore:
    score: int  # Score equivalent to 100.00%
    break_bonus: int  # The bonus score applied for getting perfect breaks


NOTE_SCORE: dict[NoteType, CompoundMoneyScore] = {
    NoteType.StartSlide: CompoundMoneyScore(1500, 0),
    NoteType.Tap: CompoundMoneyScore(500, 0),
    NoteType.Hold: CompoundMoneyScore(1000, 0),
    NoteType.Break: CompoundMoneyScore(2500, 100),
    NoteType.Star: CompoundMoneyScore(500, 0),
    NoteType.BreakStar: CompoundMoneyScore(2500, 100),
}


class SlidePattern(IntEnum):
    _Invalid = 0
    # Straight line between two locations
    Straight = 1
    # Around the ring, CCW
    RingCCW = 2
    # Around the ring, CW
    RingCW = 3
    # Arc through the centre, CCW
    ArcCCW = 4
    # Arc through the centre, CW
    ArcCW = 5
    # Left, Right, Left (to opposite)
    ZigZag = 6
    # Right, Left, Right (to opposite)
    ZagZig = 7
    # Start -(straight)-> Centre -(straight)-> End
    Straight_Straight = 8
    # Start -(straight)-> Centre -(CCW arc)-> End
    Straight_ArcCCW = 9
    # Start -(straight)-> Centre -(CW arc)-> End
    Straight_ArcCW = 10
    # Start -(straight)-> Two places CCW -(Straight)-> End
    Straight_EdgeCCW_Straight = 11
    # Start -(straight)-> Two places CW -(Straight)-> End
    Straight_EdgeCW_Straight = 12
    # Fan from start to opposite
    Fan = 13


@dataclass
class UnifiedNote:
    measure: float
    duration: float
    location: int
    note_type: NoteType = NoteType.Tap
    slide_id: int = -1
    slide_pattern: SlidePattern = SlidePattern._Invalid
    slide_amount: int = 0
    slide_delay: float = 0.25
    is_slide: bool = False
    field12_0x24: float = 0.0


@dataclass
class ParsedNote:
    measure_whole: float = 0.0
    measure_fraction: float = 0.0
    duration: float = 0.0
    location: int = 0
    note_type: int = 0
    slide_id: int = 0
    slide_pattern: SlidePattern = SlidePattern._Invalid
    slide_amount: int = 0
    slide_delay: float = 0.25


@dataclass
class BaseNote:
    measure: float


@dataclass
class TapNote(BaseNote):
    location: int
    is_break: bool
    is_star: bool


@dataclass
class HoldNote(BaseNote):
    location: int
    duration: float


@dataclass
class SlideNote(BaseNote):
    slide_id: int

    duration: float
    delay: float

    start_location: int
    end_location: int

    pattern: SlidePattern

    def __post_init__(self):
        dist_cw = (self.end_location - self.start_location) % 8
        dist_ccw = (self.start_location - self.end_location) % 8

        match self.pattern:
            case SlidePattern.Straight:
                assert 2 <= dist_cw <= 6
            case SlidePattern.RingCCW:
                pass
                # Condition only valid for SR
                # assert dist_ccw <= 3
            case SlidePattern.RingCW:
                pass
                # Condition only valid for SR
                # assert dist_cw <= 3
            case SlidePattern.ArcCCW:
                ...
            case SlidePattern.ArcCW:
                ...
            case SlidePattern.ZigZag | SlidePattern.ZagZig:
                assert dist_cw == 4
                assert dist_ccw == 4
            case SlidePattern.Straight_Straight:
                ...
            case SlidePattern.Straight_ArcCCW:
                ...
            case SlidePattern.Straight_ArcCW:
                ...
            case SlidePattern.Straight_EdgeCCW_Straight:
                assert dist_ccw >= 4
            case SlidePattern.Straight_EdgeCW_Straight:
                assert dist_cw >= 4
            case SlidePattern.Fan:
                assert dist_cw == 4
                assert dist_ccw == 4


@dataclass
class ScoreFile:
    original_format: ChartFormat
    notes: list[UnifiedNote]

    def build_notes(self):
        slides: dict[int, UnifiedNote] = {}
        slides_ended = set()

        notes: list[TapNote | HoldNote | SlideNote] = []

        for i in self.notes:
            if i.note_type == NoteType.Hold:
                notes.append(HoldNote(i.measure, i.location, i.duration))
            elif not i.is_slide:
                notes.append(
                    TapNote(
                        i.measure,
                        i.location,
                        i.note_type in (NoteType.Break, NoteType.BreakStar),
                        i.note_type in (NoteType.Star, NoteType.BreakStar),
                    )
                )
            elif i.note_type == NoteType.StartSlide:
                if i.slide_id in slides:
                    raise ValueError("Start again")
                slides[i.slide_id] = i
            elif i.note_type == NoteType.EndSlide:
                if i.slide_id not in slides:
                    print(slides)
                    print(i)
                    raise ValueError("End before start")

                duration = i.measure - slides[i.slide_id].measure
                if abs(duration - slides[i.slide_id].duration) > 0.001:
                    print(f"!! invalid slide duration claimed {slides[i.slide_id].duration} but end was found at {duration}")
                notes.append(
                    SlideNote(
                        slides[i.slide_id].measure,
                        i.slide_id,
                        slides[i.slide_id].duration,
                        slides[i.slide_id].slide_delay,
                        slides[i.slide_id].location,
                        i.location,
                        slides[i.slide_id].slide_pattern,
                    )
                )
                slides_ended.add(i.slide_id)

        assert len(slides_ended) == len(slides)

        notes.sort(key=lambda x: x.measure)
        return notes


def parse(score_data: str, chart_format: ChartFormat) -> ScoreFile:
    notes: list[UnifiedNote] = []

    for line in score_data.split("\n"):
        line = line.strip()
        if not line:
            continue
        match = RE[chart_format].fullmatch(line)
        if not match:
            raise ValueError(f"FAILED TO PARSE LINE: {repr(line)}")

        parsed: ParsedNote
        groups = match.groups()
        parsed = ParsedNote(
            float(groups[0]),
            float(groups[1]),
            float(groups[2]),
            int(groups[3]),
            int(groups[4]),
            int(groups[5]),
            SlidePattern(int(groups[6])),
        )
        match chart_format:
            case ChartFormat.SR | ChartFormat.SZ:
                pass
            case ChartFormat.SC:
                parsed.slide_amount = int(groups[7])
            case ChartFormat.SD:
                parsed.slide_amount = int(groups[7])
                parsed.slide_delay = float(groups[8])

        notes.append(_unify_note(parsed, chart_format))

    return ScoreFile(chart_format, notes)


def _unify_note(parsed: ParsedNote, chart_format: ChartFormat) -> UnifiedNote:
    # Technically "<1" but some charts get weird with it
    if not 0 <= parsed.measure_fraction <= 1:
        raise ValueError(f"! invalid measure fraction: {parsed.measure_fraction}")

    assert parsed.measure_whole == int(parsed.measure_whole)
    unified = UnifiedNote(
        measure=parsed.measure_whole + parsed.measure_fraction,
        duration=parsed.duration,
        location=parsed.location,
        slide_id=parsed.slide_id,
        slide_pattern=parsed.slide_pattern,
    )

    match chart_format:
        case ChartFormat.SR:
            if parsed.slide_id:
                unified.note_type = (
                    NoteType.EndSlide
                    if parsed.note_type & 0x80
                    else NoteType.StartSlide
                )
                unified.is_slide = True
            elif parsed.slide_id == 0:
                match (parsed.note_type & 0x0F):
                    case 0 | 1:
                        unified.note_type = NoteType.Tap
                    case 2 | 3:
                        unified.note_type = NoteType.Hold
                    case 4 | 5:
                        unified.note_type = NoteType.Break
            else:
                unified.note_type = NoteType.Star
                unified.slide_amount = 1

            # TODO: What are these masks for? only the tutorial appears to use them
            if parsed.note_type & 0x40:
                unified.field12_0x24 = 2.0
            elif parsed.note_type & 0x20:
                unified.field12_0x24 = 4.0
            elif parsed.note_type & 0x10:
                unified.field12_0x24 = 6.0

            if parsed.slide_id == 0:
                unified.slide_pattern = SlidePattern._Invalid
            else:
                unified.slide_amount = 0
                unified.slide_delay = parsed.slide_delay
                match (parsed.slide_pattern):
                    case 0:
                        unified.slide_pattern = SlidePattern.Straight
                    case 1:
                        unified.slide_pattern = SlidePattern.RingCW
                    case 2:
                        unified.slide_pattern = SlidePattern.RingCCW
                    case _:
                        unified.slide_pattern = SlidePattern._Invalid

        case ChartFormat.SZ:
            if parsed.note_type & 0x80:
                unified.note_type = NoteType.EndSlide
                unified.is_slide = True
            elif parsed.note_type == 0:
                unified.note_type = NoteType.StartSlide
                unified.is_slide = True
            else:
                unified.note_type = NoteType(parsed.note_type)

            unified.slide_delay = parsed.slide_delay
            if unified.note_type == NoteType.Star:
                unified.slide_amount = 1
        case ChartFormat.SC | ChartFormat.SD:
            if parsed.note_type & 0x80:
                unified.note_type = NoteType.EndSlide
                unified.is_slide = True
                unified.slide_delay = parsed.slide_delay
            elif parsed.note_type == 0:
                unified.note_type = NoteType.StartSlide
                unified.is_slide = True
                unified.slide_delay = parsed.slide_delay
            else:
                unified.note_type = NoteType(parsed.note_type)
                unified.slide_delay = parsed.slide_delay

    return unified


def score_maximum(score: ScoreFile) -> CompoundMoneyScore:
    break_bonus = 0
    max_score = 0

    slid = set()
    for i in score.notes:
        match i.note_type:
            case (
                NoteType.Tap
                | NoteType.Hold
                | NoteType.Break
                | NoteType.Star
                | NoteType.BreakStar
            ):
                max_score += NOTE_SCORE[i.note_type].score
                break_bonus += NOTE_SCORE[i.note_type].break_bonus
            case NoteType.StartSlide:
                if i.slide_id not in slid:
                    max_score += NOTE_SCORE[i.note_type].score
                    break_bonus += NOTE_SCORE[i.note_type].break_bonus
                    slid.add(i.slide_id)

    return CompoundMoneyScore(max_score, break_bonus)


__all__ = (
    # Types
    "ChartFormat",
    "NoteType",
    "UnifiedNote",
    "SlidePattern",
    "ScoreFile",
    # Functions
    "parse",
    "score_maximum",
)
