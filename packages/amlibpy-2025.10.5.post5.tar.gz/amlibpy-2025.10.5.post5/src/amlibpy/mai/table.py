from collections import namedtuple
import datetime
from enum import IntEnum
import re
from typing import Any, Generic, NamedTuple, TypeVar

from dataclasses import dataclass


T = TypeVar("T")

SEP_RE = re.compile(r"^\s*,\s*")
END_RE = re.compile(r"^\s*\)\s*(//.*)?$")
WS_RE = re.compile(r"^\s+")
STR_RE = re.compile(r'^L?"([^"]*)"')
INT_RE = re.compile(r"^(-?\d+)")
FLOAT_RE = re.compile(r"^(-?\d*\.\d+)")
NAME_RE = re.compile(r"^([_A-Za-z][_A-Za-z0-9]*)")


class EntryType(IntEnum):
    WIDE_STRING = 0
    STRING = 1
    FLOAT = 2
    INT = 3
    NAME = 4


@dataclass
class TableArgument:
    value: Any
    type: EntryType


def _parse_args(args) -> list[TableArgument]:
    og_args = args
    parsed: list[TableArgument] = []
    while args:
        if match := SEP_RE.match(args):
            args = args[len(match.group(0)) :]
            continue
        if match := END_RE.match(args):
            return parsed
        if match := WS_RE.match(args):
            args = args[len(match.group(0)) :]
            continue
        if match := STR_RE.match(args):
            if args[0] == "L":
                parsed.append(TableArgument(match.group(1), EntryType.WIDE_STRING))
            else:
                parsed.append(TableArgument(match.group(1), EntryType.STRING))
            args = args[len(match.group(0)) :]
            continue
        if match := FLOAT_RE.match(args):
            parsed.append(TableArgument(float(match.group(1)), EntryType.FLOAT))
            args = args[len(match.group(0)) :]
            continue
        if match := INT_RE.match(args):
            parsed.append(TableArgument(int(match.group(1)), EntryType.INT))
            args = args[len(match.group(0)) :]
            continue
        if match := NAME_RE.match(args):
            parsed.append(TableArgument(match.group(1), EntryType.NAME))
            args = args[len(match.group(0)) :]
            continue

        raise ValueError(f"!! Parsing error: {repr(args)} {repr(og_args)}")
    raise ValueError(f"!! Parsing incomplete {repr(og_args)}")


def string_arg(original: TableArgument) -> str:
    match original.type:
        case EntryType.WIDE_STRING:
            return f'L"{original.value}"'
        case EntryType.STRING:
            return f'"{original.value}"'
        case EntryType.FLOAT | EntryType.INT | EntryType.NAME:
            return f"{original.value}"
        case _:
            raise ValueError


def _namify(x: str):
    KNOWN = {
        "タイトル": "title",
        "アーティスト": "artist",
        "ドレス": "dress_code",
        "暗黒": "darkness",
        "曲長さ": "song_length",
        "オフRanking": "off_ranking",
        "チャレンジトラック": "challenge_track",
        "ボーナス": "bonus",
        "特殊PV": "special_pv",
        "名前": "name",
        "条件名": "condition_name",
        "連動": "link",
        "テキスト": "text",
        "イベントID": "event_id",
        "楽曲ID": "song_id",
        "譜面作者ID": "score_creator_id",
        "計算対象": "calculation_target",
        "GenreID": "genre_id",
        "PVStart": "pv_start",
        "PVEnd": "pv_end",
        "SortID": "sort_id",
        "SubCate": "subcategory",
    }
    if x in KNOWN:
        return KNOWN[x]

    return x.lower().replace(" ", "_")


@dataclass
class Table(Generic[T]):
    name: str
    comments: list[str | None]
    entries: list[T]
    entries_raw: list[list]
    column_map: list[tuple[str, str]]


def parse_table(
    table_raw: bytes, macro: str | None = None, type_: T | None = None
) -> Table[T]:
    if table_raw.startswith(b"\xff\xfe"):
        table = table_raw.decode("utf-16")
    else:
        table = table_raw.decode("utf-8")

    name = ""
    column_map: list[tuple[str, str]] = []
    comments: list[str | None] = []
    entries: list[list] = []

    for line in table.split("\n"):
        line = line.strip()
        if line.startswith("#define"):
            name = line.partition(" ")[2]
            if macro is None:
                macro = name.split("_")[0]
        elif line.startswith(f"/// @note {macro}( "):
            columns = line[len(f"/// @note {macro}( ") : -1]
            columns = [i.strip() for i in columns.split(",")]
            renamed = [_namify(i) for i in columns]
            column_map = [(i, j) for i, j in zip(renamed, columns)]

            assert macro  # for typing
            type_ = namedtuple(macro, renamed)

        elif macro and line.startswith(macro):
            line = line[len(macro) :].strip()
            if not line or line[0] != "(":
                continue

            if "///<" in line:
                comments.append(line.split("///< ", 1)[1])
            else:
                comments.append(None)

            entries.append(_parse_args(line[1:]))

    entries_parsed: list[NamedTuple]
    if type_ is not None:
        entries_parsed = [type_(*i) for i in entries]
    else:
        entries_parsed = []

    return Table(macro, comments, entries_parsed, entries, column_map)


def save_table(table: Table, filename: str | None = None) -> bytes:
    output = ""
    if filename is not None:
        output += f"/// @file   {filename}\n"
    output += "/// @brief  Automatic output from amlibpy\n"

    now = datetime.datetime.now()
    output += f"/// @date   {now.year}/{now.month:02}/{now.day:02} {now.hour:02}:{now.minute:02}:{now.second:02}\n"
    output += f"///\n\n\n#define {table.name}_TBL\n\n"

    if table.column_map:
        output += f"/// @note {table.name}( "
        for _, i in table.column_map:
            output += i + ", "
        output = output[:-2]  # Strip trailing comma
        output += " )\n"

    max_width = []
    if table.column_map:
        for i, _ in table.column_map:
            max_width.append(max(len(string_arg(getattr(j, i))) for j in table.entries))
    else:
        for n in range(len(table.entries_raw[0])):
            max_width.append(max(len(string_arg(j[n])) for j in table.entries_raw))

    for n, i in enumerate(table.entries_raw):
        output += f"{table.name}( "
        for m, j in enumerate(i):
            if m == len(i) - 1:
                output += string_arg(j).ljust(max_width[m])
            else:
                output += (string_arg(j) + ",").ljust(max_width[m] + 2)

        if table.comments[n] is not None:
            output += f" ) ///< {table.comments[n]}\n"
        else:
            output += " )\n"

    output += "\n"

    return output.encode("utf-16")


__all__ = ("parse_table",)
