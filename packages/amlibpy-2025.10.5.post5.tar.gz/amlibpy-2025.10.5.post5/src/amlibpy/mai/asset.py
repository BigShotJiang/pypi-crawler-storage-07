import gzip
import hashlib
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

KEYS = {
    "1.86.00": bytes.fromhex("50e73f2abe001b71dd0d30dcc2f3f51f"),
    "1.90.00": bytes.fromhex("e2eb158533055d7f2a27d4aa491e2533"),
    "1.95.00": bytes.fromhex("ad184a7d4f799e5ad8cbeb387a7a7481"),
    "1.97.00": bytes.fromhex("4e2039d03c7ac1a36d10bac801321d26"),
}


def decrypt_asset(data: bytes, key_ver: str = "1.97.00"):
    iv = data[:16]
    crypt = AES.new(KEYS[key_ver], AES.MODE_CBC, iv)
    data = unpad(crypt.decrypt(data[16:]), 16)
    data = gzip.decompress(data)

    prefix = data[:16]
    data = data[16:]

    return data


def encrypt_asset(data: bytes, key_ver: str = "1.97.00"):
    # Use a hash of the decompressed data as the IV for stability
    iv = hashlib.sha256(data).digest()[:16]

    prefix = b"\0" * 16  # TODO: Urgent
    data = gzip.compress(prefix + data, mtime=0)

    crypt = AES.new(KEYS[key_ver], AES.MODE_CBC, iv)
    data = iv + crypt.encrypt(pad(data, 16))

    return data


__all__ = (
    "decrypt_asset",
    "encrypt_asset",
)
