from dataclasses import dataclass
from enum import Enum, IntEnum, IntFlag
import zlib

from Crypto.Cipher import AES

from .stream import Stream


# TODO: Convert this into an enum
GAME_IDS = {
    # TODO: Lindbergh games
    # TODO: RingWide games
    # TODO: RingEdge games
    # TODO: RingEdge2 games

    "SBRT": "Shining Force Cross",

    # Nu games
    "SDBT": "Chunithm",
    "SDHX": "Chunithm Paradise Lost EOS Patch",
    "SDCT": "Celevie",
    "SDCA": "crossbeats REV.",
    "SDBN": "E-DEL Sand",
    "SBZV": "Hatsune Miku Project Diva Arcade Future Tone (PDAFT)",
    "SDAQ": "Herobank Arcade",
    "SDDF": "Initial D Arcade Stage Zero",
    "SDER": "Initial D Arcade Stage Zero (China version)",
    "SDBZ": "Kancolle Arcade",
    "SDFL": "Kemono Friends 3: Planet Tours",
    "SDDU": "Let's dzuri GO!",
    "SDCF": "LUIGI'S MANSION ARCADE",
    "SDCH": "MARIO & SONIC at RIO Olympic Games",
    "SDCD": "nailpuri",
    "SDBE": "Shin Kouchuu Ouja Mushiking",
    "SDEA": "Shin Kouchuu Ouja Mushiking (Taiwain version)",
    "SDDD": "Sangokushi Taisen",
    "SDBX": "Sonic Dash Extreme",
    "SDAV": "Uranai Collection: Torotte",
    "SDAP": "Wonderland Wars",
    # ALLS
    "SDEM": "ALL.Net P-ras multi Ver.3",
    "SBRF": "[APM3] APM3 Sample Program 1",
    "SDDL": "[APM3] APM3 Sample Program 2",
    "SDFD": "[APM3] Blade Strangers",
    "SDFU": "[APM3] BLAZBLUE CROSS TAG BATTLE",
    "SDHW": "[APM3] Cotton Rock 'n' Roll",
    "SDFM": "[APM3] DEAD OR ALIVE 6",
    "SDGC": "[APM3] Dengeki Bunko FIGHTING CLIMAX IGNITION APM3",
    "SDGX": "[APM3] Goonya Fighter APM3 Edition",
    "SDGM": "[APM3] GUILTY GEAR STRIVE",
    "SDJM": "[APM3] Shanghai IV: Tatsumon Hiyaku",
    "SDFB": "[APM3] GUILTY GEAR Xrd REV 2",
    "SDHV": "[APM3] Kasiori",
    "SDFR": "[APM3] Koihime Enbu Yo Rai Rai Version 3",
    "SDJG": "[APM3] Milkchan",
    "SDHP": "[APM3] Nosferatu Lilinor",
    "SDGF": "[APM3] Otoshu DX",
    "SDFH": "[APM3] Pengo! Online",
    "SDGH": "Puyo Puyo e-Sports Arcade",
    "SDFF": "[APM3] Puyo Puyo e-Sports Arcade",
    "SDGW": "[APM3] Rolling Gunner",
    "SDHB": "[APM3] Senxin ALESTE",
    "SDFJ": "[APM3] Tapping Skill Test",
    "SDGU": "[APM3] Umihara Kawase Fresh! for AC",
    "SDGR": "[APM3] UNDER NIGHT IN-BIRTH Exe:Late[cl-r]",
    "SDHF": "[APM3] Virtua Fighter eSports",
    "SDJQ": "[APM3] Virtua Fighter 3tb Online",
    "SDJH": "BINGO THEATER: Amazing Stories",
    "SDED": "Card Maker",
    "SDEC": "Chrono Regalia",
    "SDHD": "Chunithm New",
    "SDGS": "Chunithm (Export version)",
    "SDHJ": "Chunithm (China version)",
    "SDGY": "Eiketsu Taisen",
    "SDEJ": "Fate/Grand Order Arcade",
    "SDHH": "Gutsdzuri GO!",
    "SDGZ": "Hori a Tale",
    "SDEE": "House of the Dead : Scarlet Dawn",
    "SDEV": "House of the Dead : Scarlet Dawn (China version)",
    "SDET": "House of the Dead : Scarlet Dawn (Export version)",
    "SDGT": "Initial D The Arcade (IDAC)",
    "SDJJ": "头文字D THE ARCADE",
    "SDEZ": "maimai DX",
    "SDGA": "maimai DX (Export version)",
    "SDGB": "maimai DX (China version)",
    "SDFV": "MARIO & SONIC at TOKYO Olympic",
    "SDDT": "O.N.G.E.K.I",
    "SDGV": "Pokemon COROGARENA",
    "SDDS": "SEGA World Driver Championship 2018 (SWDC)",
    "SDDP": "Soul Reverse",
    "SDFT": "StarHorse 4",
    "SDEP": "StarHorse 4 (Server) (aka. MESTA Medal Station)",
    "SDFE": "Wacca",
    "SDHN": "Wacca Ver.2",
    "SDJE": "Wacca Ver.3",
    "SDEB": "WCCF FOOTISTA 2019-2021",
    "SDGK": "WCCF FOOTISTA 2019-2021 (Export version)",
    "SDEG": "FiZ",
    "SDHR": "meityromantic",
    "SDJB": "Bépiu.",
    "SDJC": "romakyun",
    "SDJU": "i my merry",
    "SDJS": "GIMMI",
    "SDKC": "totolu",
    "SDJF": "UFO CATCHER 10",
    "SDHK": "UFO CATCHER LINK STATION",
    # Other random stuff
    "SBHX": "Virtua Fighter 4 Final Tuned",
    "SBHN": "VirtuaStriker4",
    "SBLK": "VirtuaStriker 4 Ver.2006",
    "SBGG": "F-Zero AX",
    "SBKP": "Mario Kart GP",
    "SBNL": "Mario Kart GP 2",
    "BFCP": "SEGA THE 4 PLAYERS MAH-JONG MJ",
    "SBFY": "CRAZY TAXI3 High Roller",
    "SBHU": "Ghost Squad",
    "SBFN": "The House of the Dead 3",
    "SBHF": "Ollie King",
    "SBGZ": "OutRun 2",
    "SBJE": "OutRun 2 Special Tours",
    "SBHE": "Quest of D",
    "SBLJ": "Quest of D ver2.0 護符の継承者",
    "SBLZ": "Quest of D ver3.0 王国の守護者",
    "SBPK": "Quest of D: The Battle Kingdom",
    "SBKU": "Sangokushi Taisen",
    "SBNV": "Sangokushi Taisen 2",
    "SBLF": "Sega Club Golf 2006",
    "SBHC": "Sega Network Taisen Mahjong MJ2",
    "SBKK": "Sega Network Taisen Mahjong MJ3",
    "SBME": "Sega Network Taisen Mahjong MJ3 Evolution",
    "SBFZ": "VIRTUA COP 3",
    "SBHQ": "Wangan Midnight Maximum Tune",
    "SBKD": "Wangan Midnight Maximum Tune 2",
    "SBEG": "WCCF EUROPEAN CLUBS 2004-2005",
    "SBGT": "WCCF EUROPEAN CLUBS 2005-2006",
    "SBJK": "Gundam Battle Operating Simulator",
    "SBJY": "GUNDAM 0083 CARDBUILDER",
    "SDCL": "PUMP IT UP PRIME",
    "SDCR": "KEY CHIP NUSX EDB SOC",
    "SDDB": "KEY CHIP NUSX1.1 TDW",
    "SDCX": "CYTUS Ω",
    "SDDJ": "KEY CHIP NU1.1 ESC",
    "SDHC": "KEY CHIP EFN GMJ",
    "SDGN": "KEY CHIP EFN UTU",
    "SDGE": "KEY CHIP EFN UCN PRG",
    "SDGD": "KEY CHIP EFN UNS",
    "SDFW": "KEY CHIP EFN UNS DV",
    "SDFK": "KEY CHIP EFN UFD RS",
    "SDEU": "KEY CHIP ALLS X HDZ",
    "SDFA": "KEY CHIP ALLS X REC",
    "SDFP": "KEY CHIP NUSX FUTURE",
    "SDFN": "KEY CHIP ALLS X CASJ",
    "SDGP": "KEY CHIP ALLS X HDZ CASJ",
    "SDBY": "All.Net Wi-Fi Router",
    "SBSD": "Dummy ID",
    "SDDN": "Demo ID",
    "SBZU": "Demo ID",
    "SBTR": "Sega Ring OS ID",
    "SBXX": "Sega Ring OS ID",
    "SBZS": "Nu Firmware / Hardware Test",
    "SBZT": "KEY CHIP NU FACTORY / KEY CHIP NUSX FACTORY",
    "SDDW": "ALLS X / X2 Research & Development",
    "SDDM": "ALLS MX Factory Dummy",
    "SDDX": "KEY CHIP ALLS X FACTORY",
    "SBRZ": "Elefun Research & Development: All.Net",
    "SBWC": "Elefun Factory Test for Sega Logistics Services",
    "SBVK": "Elefun Research & Development",
    "SDBL": "V428 (仮) REAL DRIVE",
    "SDAY": "AZ0007 (仮)",
    "SDAT": "AV0069 (仮)",
    "TBLG": "EXTREME HUNTING TE (ST)",
    "SBLGP": "EXTREME HUNTING TE(DL)",
    "SBLG": "EXTREME HUNTING TE",
    "TEST": "SEGA AM2 TEST GAME",
    "SBUS": "Touch Touch Travel",
    "SBRD": "TouchStriker",
    "SBTK": "SEGA Mobile Medal Link Machine",
    "SBSL": "E-Money Server",
    "SBSJ": "ALL.Net proxy Authentication Module",
    "SBQJ": "Registration Dummy Game ID(SEGA)",
    "SBQH": "Registration Dummy Game ID (BNG)",
    "SBPKP": "Quest of D The Battle Kingdom PC",
    "SAAA": "Quest Of D3(NET)",
    "SBLZP": "Quest Of D3 PC",
    "SBLJP": "Quest Of D2 PC",
    "SBHEP": "Quest Of D2 PC",
    "SBEA": "ALL.Net Test No.1",
    "SBAC": "allnet_test_No2",
    "SBAA": "ALL.Net Test No.3",
    "SDFY": "UNICA MMT-01 メダル貸出機",
    "SDFQ": "Asahiseiko ST-100 メダル貸出機",
    "SDGQ": "ROKUMEN",
    "SDFG": "SANDRA",
}


class Platform(Enum):
    Naomi1 = "AAA"
    Hikaru = "AAB"
    Naomi2 = "AAC"
    Triforce = "AAD"
    Chihiro = "AAE"
    SystemSP = "AAF"
    LindberghYellow = "AAG"
    LindberghRed = "AAH"
    LindberghRedEX = "AAH"  # (dup)
    # Sega Europa-R (probably no serials)
    # Skip: I
    LindberghBlue = "AAJ"
    # Skip: K
    RingEdge = "AAL"
    RingWide = "AAM"
    # Skip: N O P Q
    ELEFUN = "AAR"
    RingEdge2 = "AAS"
    # Skip: T U
    Nu = "AAV"
    Nu11 = "AAV"  # Nu 1.1 (dup)
    Nu2 = "AAV"  # (dup)
    Nu_SX = "AAW"
    Nu_SX11 = "AAW"  # Nu SX 1.1 (dup)
    # Skip: X Y
    Nu_Lv31 = "AAZ"  # Used to specify an Lv3.1 keychip
    # Skip all of *B*
    ALLS_X = "ACA"
    ALLS_X2 = "ACB"


class SystemFlag(IntFlag):
    Develop = 1 << 0
    _Unused_1 = 1 << 1
    ALLNet = 1 << 2
    Deliver = 1 << 3
    Binding = 1 << 4  # ALL.Net Slim
    Billing = 1 << 5
    Rental = 1 << 6
    _Unused_7 = 1 << 7


class Region(IntFlag):
    AllRegions = 0xFF

    Japan = 1 << 0
    USA = 1 << 1
    Export = 1 << 2
    China = 1 << 3


class FunctionType(IntEnum):
    Server = 1  # SV
    Satellite = 2  # ST
    Live = 3  # LV
    Terminal = 4  # TM
    Unk5 = 5
    Unk6 = 6
    Unk11 = 11
    Unk12 = 12
    Unk21 = 21
    Unk22 = 22
    Standalone = 98  # ??


class AppDataBase:
    system_flag: SystemFlag
    function_type: FunctionType
    region: Region
    platform_id: Platform


@dataclass
class AppDataRing(AppDataBase):
    BINARY_LENGTH = 288
    _SCRAMBLE_SEED = (1, 8, 12, 15)
    _SCRAMBLE_KEY = (0, 4, 2, 14)
    _SCRAMBLE_IV = (0, 11, 5, 15)

    # Appboot
    format_type: int
    game_id: str
    region: Region
    function_type: FunctionType
    system_flag: SystemFlag
    platform_id: Platform
    dvd_flag: int
    network_addr: tuple[int, int, int, int]

    # Crypto
    key: bytes
    iv: bytes
    seed: bytes
    keyfile: bytes

    @classmethod
    def from_stream(cls, stream: Stream):
        stream.seek(0)

        # TODO: I have no idea how to make this CRC pass.
        # Things that have been tried:
        # - CRC(body[:236])
        # - CRC(4 nulls || body)
        # - CRC(body || 128 nulls)
        # - CRC(4 nulls || body || 128 nulls)
        # With all combinations of unscrambling the seed/key/IV
        crc = stream.u32()
        body = stream.read(cls.BINARY_LENGTH - 4)

        stream.seek(4)

        format_type = stream.u8()
        stream.skip(3)
        game_id = stream.str(4)
        region = stream.u8()
        function_type = stream.u8()
        system_flag = stream.u8()
        stream.skip(1)
        platform_id = stream.str(3)
        dvd_flag = stream.u8()
        network_addr = stream.ipv4()

        # Application binaries, but never used
        # .skip() will assert null-ness for us
        stream.skip(216, False)

        seed = scramble(stream.read(16), *cls._SCRAMBLE_SEED)
        key = scramble(stream.read(16), *cls._SCRAMBLE_KEY)
        iv = scramble(stream.read(16), *cls._SCRAMBLE_IV)

        cipher = AES.new(key, AES.MODE_CBC, iv)
        keyfile = cipher.encrypt(seed)

        return cls(
            format_type,
            game_id,
            Region(region),
            FunctionType(function_type),
            SystemFlag(system_flag),
            Platform(platform_id),
            dvd_flag,
            network_addr,
            key,
            iv,
            seed,
            keyfile,
        )


@dataclass
class AppDataRing2(AppDataRing):
    BINARY_LENGTH = 416

    ds_eeprom: tuple[bytes, bytes, bytes, bytes]

    @classmethod
    def from_stream(cls, stream: Stream):
        app_data_ring = AppDataRing.from_stream(stream)

        ds_eeprom = []
        ds_eeprom.append(stream.read(32))
        ds_eeprom.append(stream.read(32))
        ds_eeprom.append(stream.read(32))
        ds_eeprom.append(stream.read(32))

        return cls(
            app_data_ring.format_type,
            app_data_ring.game_id,
            app_data_ring.region,
            app_data_ring.function_type,
            app_data_ring.system_flag,
            app_data_ring.platform_id,
            app_data_ring.dvd_flag,
            app_data_ring.network_addr,
            app_data_ring.key,
            app_data_ring.iv,
            app_data_ring.seed,
            app_data_ring.keyfile,
            tuple(ds_eeprom),
        )


@dataclass
class AppDataNu(AppDataBase):
    BINARY_LENGTH = 112

    # Appboot
    format_type: int
    game_id: str
    region: Region
    function_type: FunctionType
    system_flag: SystemFlag
    billing_type: int
    platform_id: Platform
    network_addr: tuple[int, int, int, int]
    network_addr_6: tuple[int, int, int, int, int, int, int, int]

    # Crypto
    g_key: bytes
    g_iv: bytes
    o_key: bytes
    o_iv: bytes

    @classmethod
    def from_stream(cls, stream: Stream):
        stream.seek(0)

        crc = stream.u32()

        body = stream.read(cls.BINARY_LENGTH - 4)
        # if crc != zlib.crc32(body) & 0xFFFFFFFF:
        #     raise ValueError("Corrupt AppData file")

        stream.seek(4)

        format_type = stream.u8()
        stream.skip(3)
        game_id = stream.str(4)
        region = stream.u8()
        function_type = stream.u8()
        system_flag = stream.u8()
        billing_type = stream.u8()
        platform_id = stream.str(3)
        stream.skip(1)
        network_addr = stream.ipv4()
        stream.skip(8)
        ipv6_addr = stream.ipv6()
        g_key = stream.read(16)
        g_iv = stream.read(16)
        o_key = stream.read(16)
        o_iv = stream.read(16)

        return cls(
            format_type,
            game_id,
            Region(region),
            FunctionType(function_type),
            SystemFlag(system_flag),
            billing_type,
            Platform(platform_id),
            network_addr,
            ipv6_addr,
            g_key,
            g_iv,
            o_key,
            o_iv,
        )


def scramble(val, a, b, c, d):
    ret = bytearray(val)
    ret[a], ret[b] = ret[b], ret[a]
    ret[c], ret[d] = ret[d], ret[c]
    return bytes(ret)


__all__ = (
    "Platform",
    "SystemFlag",
    "Region",
    "FunctionType",
    "AppDataBase",
    "AppDataRing",
    "AppDataRing2",
    "AppDataNu",
)
