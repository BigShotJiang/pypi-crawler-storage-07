import os
import struct
import sys
import zlib
from dataclasses import dataclass

from amlibpy.util import format_size, Bar
from amlibpy.segastruct import (
    SPDSlot,
    SEGAPartitionDescription,
    SBRSlot,
    SEGABootRecord,
)


PARTITION_GAP = 63

ORIGINAL_0 = 0x10
ORIGINAL_1 = 0x11
PATCH_0 = 0x20
PATCH_1 = 0x21
OS = 0x30
APP_DATA = 0x30


@dataclass
class MBRPartition:
    type: int
    lba: int
    sectors: int


@dataclass
class Timestamp:
    year: int
    month: int
    day: int
    hour: int
    minute: int
    second: int

    def __str__(self):
        return f"{self.year:04}-{self.month:02}-{self.day:02}-{self.hour:02}:{self.minute:02}:{self.second:02}"


class Dumper:
    def __init__(self, path: str):
        self._path = path
        self._file = None
        self._spd = None
        self._sbr = None
        self._sega_base = 0

    def __enter__(self):
        self._file = open(self._path, "rb")
        return self

    def __exit__(self, *_):
        self._file.close()

    def _validate_checksum(self, data):
        chk = struct.unpack("<I", data[:4])[0]
        assert (zlib.crc32(data[4:]) & 0xFFFFFFFF) == chk

    def read_mbr(self):
        self._file.seek(0)
        mbr = self._file.read(512)
        partitions = (
            MBRPartition(*struct.unpack("<4xB3xII", mbr[0x1BE : 0x1BE + 16])),
            MBRPartition(*struct.unpack("<4xB3xII", mbr[0x1CE : 0x1CE + 16])),
            MBRPartition(*struct.unpack("<4xB3xII", mbr[0x1DE : 0x1DE + 16])),
            MBRPartition(*struct.unpack("<4xB3xII", mbr[0x1EE : 0x1EE + 16])),
        )
        assert partitions[0].type == 7
        assert partitions[1].type == 7
        assert partitions[2].type in (5, 15)  # RW uses 5, RE uses 15
        assert partitions[3].type == 0

        return partitions

    def read_sbr(self):
        if self._spd is not None and self._sbr is not None:
            return self._spd, self._sbr

        partitions = self.read_mbr()
        if partitions[2].type == 15:
            self._sega_base = partitions[2].lba
            self._file.seek((partitions[2].lba + 1) * 512)
        elif partitions[2].type == 5:
            # TODO: We should be using CHS, but LBA _does_ work
            self._sega_base = partitions[2].lba
            self._file.seek((partitions[2].lba + 1) * 512)
        else:
            raise ValueError
        spd = self._file.read(512)
        sbr0 = self._file.read(512)
        sbr1 = self._file.read(512)
        self._validate_checksum(spd)
        self._validate_checksum(sbr0)
        self._validate_checksum(sbr1)

        spd = SEGAPartitionDescription(
            spd[4],
            [
                SPDSlot(*struct.unpack("BBHI8x", spd[16 * i : 16 * i + 16]))
                for i in range(1, 32)
            ],
        )

        sbr = SEGABootRecord(
            sbr0[4],
            sbr0[64],
            [sbr0[67], sbr0[68], sbr0[69], sbr0[70], sbr0[71]],
            SBRSlot.from_bytes(sbr0[0x0C0 : 0x0C0 + 64]),
            SBRSlot.from_bytes(sbr0[0x100 : 0x100 + 64]),
            SBRSlot.from_bytes(sbr0[0x140 : 0x140 + 64]),
            SBRSlot.from_bytes(sbr0[0x180 : 0x180 + 64]),
            SBRSlot.from_bytes(sbr0[0x1C0 : 0x1C0 + 64]),
        )

        self._spd, self._sbr = spd, sbr
        return spd, sbr

    @property
    def spd(self):
        return self.read_sbr()[0]

    @property
    def sbr(self):
        return self.read_sbr()[1]

    def _get_slot_index(self, content):
        for n, slot in enumerate(self.spd.slots):
            if slot.slot == content:
                return n
        raise ValueError(f"Unable to locate slot containing {content:02x}")

    def _get_slot(self, content):
        return {
            OS: self.os,
            ORIGINAL_0: self.original0,
            APP_DATA: self.appdata,
            PATCH_0: self.patch0,
            PATCH_1: self.patch1,
        }[content]

    @property
    def original0(self):
        return self.sbr.original0

    @property
    def patch0(self):
        return self.sbr.patch0

    @property
    def patch1(self):
        return self.sbr.patch1

    @property
    def os(self):
        return self.sbr.os

    @property
    def appdata(self):
        return self.sbr.appdata

    def _get_slot_bounds(self, content: int):
        index = self._get_slot_index(content)

        base = self._sega_base * 512
        base += PARTITION_GAP * (index + 1) * 512
        for i in range(index):
            base += self.spd.slots[i].block_count * self.spd.slots[i].block_size

        slot = self._get_slot(content)

        partition_size = (
            self.spd.slots[index].block_count * self.spd.slots[index].block_size
        )
        data_size = slot.segcount * slot.segsize
        assert data_size < partition_size

        return base + partition_size - data_size, data_size

    def read_slot(self, content: int, output: str):
        slot = self._get_slot(content)
        start, data_size = self._get_slot_bounds(content)

        self._file.seek(start)
        with open(output, "wb") as outfile:
            for _ in Bar(f"{output} ({format_size(data_size)})", slot.segcount):
                outfile.write(self._file.read(slot.segsize))
        print(f"Extracted {slot.short_format()} to {output} ({format_size(data_size)})")

        # tc_footer = (base + partition_size) - 1563 * 512  # real truecrypt
        # tc_footer = (base + partition_size) - 15 * 512  # doesnt
        # tc_footer = (base + partition_size) - 16 * 512  # works
        # self._file.seek(tc_footer)  # good
        # print(self._file.read(512))

    def fix_image(self, image_path):
        with self.__class__(image_path) as image_disk:
            if image_disk.spd != self.spd:
                print("SPD's don't match! Aborting")
                return
            if image_disk.sbr != self.sbr:
                print("SBR's don't match! Aborting")
                return

        with open(image_path, "rb") as image:
            image.seek(0, 2)
            image_end = image.tell()

        o0_start, o0_length = self._get_slot_bounds(ORIGINAL_0)
        disk_end = o0_start + o0_length

        missing = disk_end - image_end

        if missing <= 0:
            print("No data missing!")
            return
        print(f"Missing {missing} bytes")
        print("Re-dumping the entire original0 partition")

        with open(image_path, "rb+") as image:
            image.seek(o0_start)
            self._file.seek(o0_start)

            slot = self._get_slot(ORIGINAL_0)
            for _ in Bar(f"({format_size(o0_length)})", slot.segcount):
                image.write(self._file.read(slot.segsize))

        print(f"Completed repairs on {image_path}")

    def image_to(self, image_path):
        o0_start, o0_length = self._get_slot_bounds(ORIGINAL_0)
        disk_end = o0_start + o0_length

        sector_size = 0x40000

        sectors, slack = divmod(disk_end, sector_size)
        assert slack % 512 == 0

        with open(image_path, "wb") as image:
            self._file.seek(0)
            image.write(self._file.read(slack))

            for _ in Bar(f"Saving ({format_size(disk_end)}) to {image_path}", sectors):
                image.write(self._file.read(sector_size))
                if self._file.tell() > o0_start:
                    break
        self.fix_image(image_path)


def usage(error=""):
    print()
    if error:
        print(error + "\n")
    print("Usage:")
    print(f"    {sys.argv[0]} help")
    print(f"    {sys.argv[0]} inspect <drive path>")
    print(
        f"    {sys.argv[0]} dump    <drive path> <original0|patch0|patch1> <destination>"
    )
    print(f"    {sys.argv[0]} repair  <drive path> <image file path>")
    print(f"    {sys.argv[0]} image   <drive path> <image file path>")
    print()
    print("<drive path> should typically be of the for \\\\.\\PhysicalDriveN")
    print("Passing a file path instead will work but is unsupported!")


def main():
    if len(sys.argv) < 3:
        return usage()
    if sys.argv[1] not in ("help", "inspect", "dump", "repair", "image"):
        return usage(f"Unknown command: {sys.argv[1]}")

    if sys.argv[1] == "help":
        return usage()
    elif sys.argv[1] == "inspect":
        if len(sys.argv) != 3:
            return usage("Invalid argument count")
        with Dumper(sys.argv[2]) as d:
            print(f"OS        : {d.os.short_format()}")
            print(d.os.long_format(4))
            print()
            print(f"Original 0: {d.original0.short_format()}")
            print(d.original0.long_format(4))
            print()
            print(f"Patch    0: {d.patch0.short_format()}")
            print(d.patch0.long_format(4))
            print()
            print(f"Patch    1: {d.patch1.short_format()}")
            print(d.patch1.long_format(4))
            print()
            print(f"AppData   : {d.appdata.short_format()}")
            print(d.appdata.long_format(4))
    elif sys.argv[1] == "dump":
        if len(sys.argv) != 5:
            return usage("Invalid argument count")
        if sys.argv[3] not in ("original0", "patch0", "patch1"):
            return usage(f"Invalid slot {sys.argv[3]}")

        if os.path.exists(sys.argv[4]):
            print(f"Cowardly refusing to overwrite {sys.argv[4]}")
            return

        with Dumper(sys.argv[2]) as d:
            d.read_slot(
                {
                    "original0": ORIGINAL_0,
                    "patch0": PATCH_0,
                    "patch1": PATCH_1,
                }[sys.argv[3]],
                sys.argv[4],
            )
    elif sys.argv[1] == "repair":
        if len(sys.argv) != 4:
            usage("Invalid argument count")
            return
        if not os.path.exists(sys.argv[3]) or not os.path.exists(sys.argv[3]):
            print(f"No such file: {sys.argv[3]}")
            return

        with Dumper(sys.argv[2]) as d:
            d.fix_image(sys.argv[3])
    elif sys.argv[1] == "image":
        if len(sys.argv) != 4:
            usage("Invalid argument count")
            return
        if os.path.exists(sys.argv[3]):
            print(f"Cowardly refusing to overwrite {sys.argv[3]}")
            return
        with Dumper(sys.argv[2]) as d:
            try:
                d.image_to(sys.argv[3])
            except PermissionError:
                d.fix_image(sys.argv[3])


if __name__ == "__main__":
    main()
