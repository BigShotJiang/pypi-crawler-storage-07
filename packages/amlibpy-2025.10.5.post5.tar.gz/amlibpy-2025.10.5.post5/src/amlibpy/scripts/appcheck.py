import os
import sys

from amlibpy.appfile import AppFileWriter
from amlibpy.util import format_size


def print_help() -> None:
    print(f"Usage: {sys.argv[0]} [--repair] <app path>")


def main():
    if len(sys.argv) == 2:
        repair = False
        app_path = sys.argv[1]
    elif len(sys.argv) == 3:
        if sys.argv[1] != "--repair":
            print_help()
            quit()
        repair = True
        app_path = sys.argv[2]
    else:
        print_help()
        quit()

    if not os.path.exists(app_path) or not os.path.isfile(app_path):
        print(f"No such file: {app_path}")

    with AppFileWriter(app_path) as ac:
        bootid = ac.read_bootid()
        gt = bootid.game_timestamp
        print(
            f"Found {bootid.game_id}"
            f" {bootid.game_ver[0]}.{bootid.game_ver[1]:02}.{bootid.game_ver[2]:02}"
            f", {gt.year}-{gt.month:02}-{gt.day:02}T{gt.hour:02}:{gt.minute:02}:{gt.second:02}"
            f" for {bootid.hw}"
        )

        print(
            f" Block size:    {format_size(bootid.block_size)} \t(0x{bootid.block_size:x})"
        )
        print(
            f" Header blocks: {bootid.header_count} \t({format_size(bootid.header_count * bootid.block_size)})"
        )
        print(
            f" Data blocks:   {bootid.block_count} \t({format_size(bootid.block_count * bootid.block_size)})"
        )
        print(f" Data offset:   0x{bootid.data_offset:08x}")

        if repair:
            print("=== File repair ===")
            print("Repairing signature")
            ac.repair_signature()
            print("Repairing block CRCs")
            ac.repair_all_block_crcs()

        print("=== File validation ===")
        if not ac.verify_signature():
            print("Signature: NG")
        else:
            print("Signature: OK")

        if ac.verify_all_blocks():
            print("All blocks intact")
        else:
            print("Some blocks invalid")


if __name__ == "__main__":
    main()
