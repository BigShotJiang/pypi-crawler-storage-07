import os
import subprocess
import tempfile


TC_SEARCH_PATH = [
    "C:\\Program Files\\TrueCrypt\\TrueCrypt.exe",
    "C:\\Program Files (x86)\\TrueCrypt\\TrueCrypt.exe",
    "C:\\Windows\\System32\\TrueCrypt.exe",
    "C:\\Windows\\TrueCrypt.exe",
]

TC_FLAG_AUTO = "/a"
TC_FLAG_BEEP = "/b"
TC_FLAG_CACHE = "/c"
TC_FLAG_DISMOUNT = "/d"
TC_FLAG_EXPLORE = "/e"
TC_FLAG_FORCE = "/f"
TC_FLAG_HELP = "/?"
TC_FLAG_HISTORY = "/h"
TC_FLAG_KEYFILE = "/k"
TC_FLAG_LETTER = "/l"
TC_FLAG_MOUNT_OPTION = "/m"
TC_FLAG_PASSWORD = "/p"
TC_FLAG_QUIT = "/q"
TC_FLAG_SILENT = "/s"
TC_FLAG_VOLUME = "/v"
TC_FLAG_WIPE_CACHE = "/w"


def locate_tc():
    for i in TC_SEARCH_PATH:
        if os.path.exists(i):
            return i

    raise FileNotFoundError("Unable to locate TrueCrypt")


class TrueCryptVolume:
    def __init__(self, keyfile: bytes, volume: str):
        self.keyfile = keyfile
        self.volume = volume

        self.__mounted: bool = False
        self.__letter: str = ""

    @property
    def mounted(self):
        return self.__mounted

    def mount(self, letter: str, read_only=True):
        if self.mounted:
            raise RuntimeError("Volume already mounted")

        # We need to close the file so TrueCrypt can use it
        with tempfile.NamedTemporaryFile(delete=False) as tmp:
            tmp.write(self.keyfile)

        try:
            tc = subprocess.Popen(
                [
                    locate_tc(),
                    TC_FLAG_QUIT,
                    TC_FLAG_SILENT,
                    TC_FLAG_KEYFILE,
                    tmp.name,
                    TC_FLAG_LETTER,
                    letter,
                    TC_FLAG_VOLUME,
                    os.path.abspath(self.volume),
                    TC_FLAG_MOUNT_OPTION,
                    "ro" if read_only else "rw",
                ]
            )
            tc.communicate()
        finally:
            # Clean up our temp file once TrueCrypt is done
            os.remove(tmp.name)

        if tc.returncode:
            return False

        self.__mounted = True
        self.__letter = letter
        return True

    def unmount(self):
        if not self.mounted:
            return

        subprocess.Popen(
            [locate_tc(), TC_FLAG_QUIT, TC_FLAG_SILENT, TC_FLAG_DISMOUNT, self.__letter]
        )
        self.__mounted = False
