import math
import time


def format_size(n_bytes: int | float) -> str:
    for i in ("B", "KiB", "MiB", "GiB"):
        if n_bytes < 1024:
            return f"{n_bytes:.2f} {i}"
        n_bytes /= 1024
    return f"{n_bytes:.2f} TiB"


class Bar:
    def __init__(self, msg, max_, width=30):
        self.msg = msg
        self.max = max(0, max_)
        self.width = width
        self.last_n = 0
        self.avg_time = 0
        self.avg_over = 0
        self.last = 0

    def __enter__(self):
        self.update(0)
        return self

    def __iter__(self):
        with self as bar:
            for i in range(self.max):
                yield i
                bar.update(i)

    def update(self, n):
        now = time.time()
        if self.last:
            delta = now - self.last
            self.avg_time = ((self.avg_time * self.avg_over) + delta) / (
                self.avg_over + 1
            )
            self.avg_over += 1
        self.last = now

        n = max(0, min(n, self.max))
        self.last_n = n
        bar = round((n / self.max) * self.width) * "="

        remaining = (self.max - n) * self.avg_time
        minutes, seconds = divmod(remaining, 60)
        hours, minutes = divmod(minutes, 60)
        minutes = int(minutes)
        hours = int(hours)
        if hours:
            seconds = math.floor(seconds)
            eta = f"  ETA {hours}h:{minutes:02}m:{seconds:02}s   "
        elif minutes:
            seconds = math.floor(seconds)
            eta = f"  ETA {minutes}m:{seconds:02}s      "
        else:
            seconds = math.ceil(seconds)
            eta = f"  ETA {seconds}s          "
        print(
            f"{self.msg} [{bar}{' ' * (self.width - len(bar))}] {n / self.max * 100:.2f}%{eta}",
            end="\r",
            flush=True,
        )

    def print_over(self, *args):
        self.clear()
        print(*args)
        self.update(self.last_n)

    def clear(self):
        print(
            " "
            * (
                len(self.msg)
                + 2
                + self.width
                + 2
                + len("100.00%")
                + len("  ETA 00h:00m:00s")
            ),
            end="\r",
            flush=True,
        )

    def __exit__(self, *_):
        self.clear()
