from dataclasses import dataclass
import os
import random
import struct
import zlib


def amAuthDiskInitKey(seed):
    key = bytearray(0x8000)
    for i in range(0x8000):
        uVar1 = (seed * 2 >> 4 ^ seed * 2) >> 10 & 2 | seed << 2
        uVar2 = uVar1 * 2
        uVar3 = ((seed << 2) >> 4 ^ uVar1) >> 10 & 2 | uVar2
        uVar1 = uVar3 * 2
        uVar3 = (uVar2 >> 4 ^ uVar3) >> 10 & 2 | uVar1
        uVar2 = uVar3 * 2
        uVar3 = (uVar1 >> 4 ^ uVar3) >> 10 & 2 | uVar2
        uVar1 = uVar3 * 2
        uVar3 = (uVar2 >> 4 ^ uVar3) >> 10 & 2 | uVar1
        uVar2 = uVar3 * 2
        uVar3 = (uVar1 >> 4 ^ uVar3) >> 10 & 2 | uVar2
        uVar1 = uVar3 * 2
        uVar2 = (uVar2 >> 4 ^ uVar3) >> 10 & 2 | uVar1
        seed = uVar2 | (uVar1 >> 4 ^ uVar2) >> 11 & 1

        key[i] = seed & 0xFF

    return key


def decrypt(buffer, key):
    out = bytearray(len(buffer))
    for i in range(len(buffer)):
        out[i] = buffer[i] ^ key[i & 0x7FF]
    return out


# Cache of amAuthDiskInitKey(5369)
HEADER_KEY = open(
    os.path.join(os.path.dirname(__file__), "alphaHeaderKey.bin"), "rb"
).read()


@dataclass
class AlphaHeader:
    magic: int
    auth_offset: int
    auth_pre_seek_2: int
    auth_pre_seek_3: int
    start_sector: int
    unused: int
    name: str
    seed: int
    dummy_section: int


class AlphaDvdSkipper:
    def __init__(self, stream):
        self.stream = stream

    def decrypt_header(self, number):
        self.stream.seek(number * 2048 + 508)
        buffer = bytearray(self.stream.read(53))

        for i in range(len(buffer)):
            buffer[i] ^= HEADER_KEY[i & 0x7FF]

        header = struct.unpack("<IxxHHH6xH4xH20sHH3x", buffer)

        if header[0] != 0xF1FFFF1F:
            return None
        if not header[6].startswith(b"SEGA_DVD"):
            return None

        print(header)

        return header[4]  # start sector

    def locate_header(self):
        if (start := self.decrypt_header(16)) is not None:
            return start
        if (start := self.decrypt_header(1)) is not None:
            return start
        if (start := self.decrypt_header(17)) is not None:
            return start

        return None


class AlphaDvd:
    TESTS = [0x140, 0x150, 0x160, 0x170, 0x180, 0x190]

    def __init__(self, path):
        self.path = path

        self.sector_key = None
        self.rand_sector = 0
        self.sections = [[0] * 4 for _ in range(4)]

        self.sectorToRead = 0
        self.sectorSize = 0
        self.lcgs = [0] * 4
        self.rand1 = self.rand2 = self.rand3 = 0

        # Header info
        self.offset = 0
        self.authSector2PS = 0
        self.authSector3PS = 0
        self.start_sector = 0
        self.f5 = 0
        self.name = ""
        self.key_seed = 0
        self.dummy_section = 0

        self.reads = []

    def am_auth_disk_open(self):
        try:
            self.alpha = open(self.path, "rb")
            return True
        except Exception:
            return False

    def read_sector(self, sector, count):
        self.reads.append(sector)

        try:
            self.alpha.seek(sector * 2048)
            return self.alpha.read(count * 2048)
        except Exception:
            raise
            # return None

    def decrypt_header(self, buffer, which):
        offset = 318 if which == 1 else 508

        header = decrypt(buffer[offset : offset + 53], HEADER_KEY)
        header = struct.unpack("<IxxHHH6xH4xH20sHH3x", header)

        if header[0] != 0xF1FFFF1F:
            return False
        if not header[6].startswith(b"SEGA_DVD"):
            return False

        self.offset = header[1]
        self.authSector2PS = header[2]
        self.authSector3PS = header[3]
        self.start_sector = header[4]
        self.f5 = header[5]  # Unused?
        self.name = header[6].decode("latin-1")
        self.key_seed = header[7]
        self.dummy_section = header[8] & 0xFF

        self.header = AlphaHeader(
            header[0],
            header[1],
            header[3],
            header[4],
            header[4],
            header[5],
            header[6].split(b"\0")[0].decode("latin-1"),
            header[7],
            header[8],
        )

        self.sector_key = amAuthDiskInitKey(self.key_seed)
        return True

    def locate_header(self):
        self.read_sector(16, 1)
        buffer = self.read_sector(16, 1)
        if self.decrypt_header(buffer, 1):
            return True

        buffer = self.read_sector(1, 1)
        if self.decrypt_header(buffer, 0):
            return True

        buffer = self.read_sector(17, 1)
        if self.decrypt_header(buffer, 0):
            return True

        return False

    def read_section(self, which):
        sector = self.rand_sector & 0xFFFFFFF0
        buffer = self.read_sector(sector, 16)
        if buffer is None:
            return -6

        buffer = decrypt(buffer, self.sector_key)

        offset = 0x79FC
        self.sections[which] = struct.unpack("<4I", buffer[offset : offset + 16])

        if which != self.dummy_section and (
            self.sections[which][0] != 0xF1FFFF1F
            or self.sections[which][2] != self.rand_sector
        ):
            return -7

        return 0

    def get_random_number(self, which_generator):
        if which_generator < 0 or which_generator > 3:
            return random.randint(0, self.sectorToRead + 0x1FDFFA)

        # The LCG four times
        seed1 = (self.lcgs[which_generator] * 0x343FD + 0x269EC3) & 0xFFFFFFFF
        seed2 = (seed1 * 0x343FD + 0x269EC3) & 0xFFFFFFFF
        seed3 = (seed2 * 0x343FD + 0x269EC3) & 0xFFFFFFFF
        seed4 = (seed3 * 0x343FD + 0x269EC3) & 0xFFFFFFFF
        self.lcgs[which_generator] = seed4

        # Calculate the actual 15-bit values from those LCG calls
        val1 = (seed1 >> 0x10) & 0x7FFF
        val2 = (seed2 >> 0x10) & 0x7FFF
        val3 = (seed3 >> 0x10) & 0x7FFF
        val4 = (seed4 >> 0x10) & 0x7FFF

        return (
            # 11 33 22 44
            (val1 << 16) & 0xFF000000
            | (val3 << 8) & 0x00FF0000
            | (val2 & 0xFF00)
            | (val4 >> 8)
        ) % (self.sectorToRead + 0x1FDFFA)

    def rand3_SectorRead(self):
        sector = self.get_random_number(3)
        count = random.randint(2, 7)
        # read 2-7 sectors at [rand 3]
        self.read_sector(sector, count)

    def FUN_00401c30(self):
        buffer = self.read_sector(self.sectorToRead, self.sectorSize)
        if buffer is None:
            return -6

        crcFeed = bytearray(2048)
        for i in range(len(crcFeed)):
            crcFeed[i] = buffer[i]

        calcCrc = zlib.crc32(crcFeed[:1920])
        val = struct.unpack("<I", crcFeed[1920:1924])[0]

        if val != calcCrc ^ 0xFC0E66A9:
            return -8

        for i in range(4):
            offset = 1936 + i * 4
            val = struct.unpack("<I", crcFeed[offset : offset + 4])[0]
            if val == calcCrc ^ 0x92FB35AC:
                break
        else:
            return -8

        temp = struct.unpack("<8I", crcFeed[self.rand1 * 32 : self.rand1 * 32 + 32])

        i = 0
        while temp[i] != 0 and temp[i] != 0xFFFFFFFF:
            i += 1
            if i > 7:
                i = ((temp[1] ^ 0x6BF0B800) >> 11) + self.sectorToRead
                uVar4 = temp[2] >> 30
                # Both unused?
                self.field45_0x84bc = i
                self.field50_0x84c4 = uVar4 + 2
                return -(self.sectorToRead + 0x1FDFFF < uVar4 + 1 + i) & 0xFFFFFFF8

        return -8

    def FUN_00402380(self, count):
        which = [0] * 32
        which[0] = 2
        if count > 1:
            for i in range(1, count):
                rand = random.randint(0, 5)
                if rand < 3:
                    which[i] = 0
                elif rand < 5:
                    which[i] = 1
                else:
                    which[i] = -1

        for i in range(count):
            rand = random.randint(0, count - 1)
            which[i], which[rand] = which[rand], which[i]

        for i in range(count):
            sector = self.get_random_number(which[i])
            self.read_sector(sector, random.randint(2, 7))

    def auth_key(self, offset):
        """Perform Key Disk authentication"""
        self.sectorToRead = offset

        self.rand1 = random.randint(0, 59)
        self.rand2 = random.randint(2, 9)
        self.rand3 = random.randint(2, 9)

        rand = random.randint(0, 0xFFFFFFFF)
        self.sectorSize = (((7 - (rand // 3)) * 3 - self.rand3) - self.rand2) + rand

        LCGS_SEED = 2390420364
        self.lcgs[0] = random.randint(0, 59) + LCGS_SEED + (60 * 0)
        self.lcgs[1] = random.randint(0, 59) + LCGS_SEED + (60 * 1)
        self.lcgs[2] = random.randint(0, 59) + LCGS_SEED + (60 * 2)
        self.lcgs[3] = random.randint(0, 59) + LCGS_SEED + (60 * 3)

        LCGS_SEED = 2390420544
        iVar2 = self.FUN_00401c30()
        if iVar2:
            self.lcgs[0] = random.randint(0, 59) + LCGS_SEED + (60 * 0)
            self.lcgs[1] = random.randint(0, 59) + LCGS_SEED + (60 * 1)
            self.lcgs[2] = random.randint(0, 59) + LCGS_SEED + (60 * 2)
            self.lcgs[3] = random.randint(0, 59) + LCGS_SEED + (60 * 3)

            self.FUN_00402380(self.rand2)
            self.rand3_SectorRead()
            self.FUN_00402380(self.rand3)
            self.rand3_SectorRead()
            self.FUN_00402380(self.sectorSize)
            return iVar2

        raise NotImplementedError

    def validate_sections(self):
        match self.header.dummy_section & 0xFF:
            case 1:
                if self.sections[2][1] != 0xF2FFFF2F:
                    return -7
                if self.sections[3][1] != 0xF3FFFF3F:
                    return -7
                if self.sections[1][1] == 0xF2FFFF2F:
                    return -7
                if self.sections[1][1] == 0xF3FFFF3F:
                    return -7
            case 2:
                if self.sections[1][1] != 0xF1FFFF1F:
                    return -7
                if self.sections[3][1] != 0xF3FFFF3F:
                    return -7
                if self.sections[2][1] == 0xF1FFFF1F:
                    return -7
                if self.sections[2][1] == 0xF3FFFF3F:
                    return -7
            case 3:
                if self.sections[1][1] != 0xF1FFFF1F:
                    return -7
                if self.sections[2][1] != 0xF2FFFF2F:
                    return -7
                if self.sections[3][1] == 0xF1FFFF1F:
                    return -7
                if self.sections[3][1] == 0xF2FFFF2F:
                    return -7
            case _:
                return -7
        return 0

    def am_auth_disk_read_info(self):
        """Perform Alpha-DISC authentication"""
        if not self.locate_header():
            return 1

        n = random.choice(self.TESTS)
        self.rand_sector = n - 1 + self.offset

        self.read_sector(self.offset - 16, 16)
        ret = self.read_section(1)
        if ret:
            return ret

        self.read_sector(self.offset - 16, 16)
        self.read_sector(self.offset + self.authSector2PS - 8, 16)
        ret = self.read_section(2)
        if ret:
            return ret

        self.read_sector(self.offset + self.authSector3PS + 8, 16)
        ret = self.read_section(3)
        if ret:
            return ret

        ret = self.validate_sections()
        return ret

    def am_auth_disk_read_info_all(self):
        if not self.locate_header():
            return 1

        for n in self.TESTS:
            self.rand_sector = n - 1 + self.offset

            self.read_sector(self.offset - 16, 16)
            ret = self.read_section(1)
            if ret:
                return ret

            self.read_sector(self.offset - 16, 16)
            self.read_sector(self.offset + self.authSector2PS - 8, 16)
            ret = self.read_section(2)
            if ret:
                return ret

            self.read_sector(self.offset + self.authSector3PS + 8, 16)
            ret = self.read_section(3)
            if ret:
                return ret

            ret = self.validate_sections()

        return 0
