from Crypto.Cipher import AES


class FsCryptError(BaseException):
    pass


class FsCrypt:
    PAGE_SIZE = 0x1000

    def __init__(
        self, filename: str, offset: int = 0, size: int = -1, write: bool = False
    ):
        self.filename = filename
        self.offset = offset
        self.size = size
        self.write = write
        self.file = None
        self.ptr = 0

        self.iv = b"\0" * 16
        self.key = None
        self._page_buffer = (-1, b"")

    def __enter__(self):
        self.open()
        return self

    def __exit__(self, *args):
        self.close()

    def set_key(self, key: bytes, iv: bytes):
        self.key = key
        self.iv = iv

    def open(self) -> None:
        self.file = open(self.filename, "r+b" if self.write else "rb")
        if self.size == -1:
            self.file.seek(0, 2)
            self.size = self.file.tell()

    def close(self) -> None:
        if self.file is not None:
            self.file.close()
        self.file = None

    def seek(self, offset: int, whence: int = 0) -> None:
        if self.file is None:
            raise FsCryptError("Cannot possibly seek without an open file")

        if whence == 0:
            self.ptr = offset
        elif whence == 1:
            self.ptr += offset
        elif whence == 2:
            self.ptr = self.size - offset
        else:
            raise ValueError("Invalid whence")

        if self.ptr < 0:
            self.ptr = 0

    def _get_page_iv(self, page: int) -> bytes:
        page_iv = bytearray(16)

        file_offset = page * self.PAGE_SIZE
        for i in range(16):
            page_iv[i] = self.iv[i] ^ (file_offset >> (8 * (i % 8))) & 0xFF

        return bytes(page_iv)

    def _read_page(self, page: int) -> bytes:
        if self.key is None:
            raise FsCryptError("Key not set")
        if self.file is None:
            raise FsCryptError("File not open")

        iv = self._get_page_iv(page)
        cipher = AES.new(self.key, AES.MODE_CBC, iv)

        self.file.seek(self.offset + self.PAGE_SIZE * page)
        block = self.file.read(self.PAGE_SIZE)
        if len(block) != self.PAGE_SIZE:
            raise FsCryptError(f"Ran out of data reading page {page}")

        block = cipher.decrypt(block)
        self._page_buffer = (page, block)
        return block

    def read(self, n: int) -> bytes:
        if self.file is None:
            raise FsCryptError("File not open")

        result = b""
        to_read = n
        while to_read:
            page = self.ptr // self.PAGE_SIZE
            page_offset = self.ptr % self.PAGE_SIZE
            page_size = min(self.PAGE_SIZE, to_read)

            if self._page_buffer[0] != page:
                self._read_page(page)

            if page_offset == 0:
                block = self._page_buffer[1][:page_size]
            else:
                block = self._page_buffer[1][page_offset : page_offset + page_size]

            result += block
            to_read -= len(block)

        self.ptr += len(result)
        return result
