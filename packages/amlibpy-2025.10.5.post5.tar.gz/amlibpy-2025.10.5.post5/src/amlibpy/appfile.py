import secrets
import struct
import zlib

from Crypto.Cipher import AES
from Crypto.Hash import HMAC, SHA1

from .segastruct import BootIDNu
from .util import Bar


class AppFileError(Exception):
    pass


class AppFileWriterError(Exception):
    pass


class AppFile:
    BTKEY = bytes.fromhex("09ca5efd30c9aaef3804d0a7e3fa7120")
    BTIV = bytes.fromhex("b155c22c2e7f0491fa7f0fdc217aff90")
    SIGKEY = bytes.fromhex(
        "e1bdcb2d5e9ed3b5de234364dfa4d126849edff769fc6c28fba5f43bc482bd74"
        "79d676afce8188e1d3a6852f4ebce45cde46bd15e8ee5fe84d197f945a54518f"
    )

    BOOTID_OFFSET = 0
    BOOTID_SIZE = 0x2800

    SIGNATURE_OFFSET = BOOTID_OFFSET + BOOTID_SIZE  # 0x2800
    SIGNATURE_SIZE = 0x200

    CRC_OFFSET = SIGNATURE_OFFSET + SIGNATURE_SIZE  # 0x2a00

    def __init__(self, filename: str):
        self.filename = filename
        self.file = None
        self.bootid = None
        self.block_size = -1
        self.block_count = -1

    def __enter__(self):
        self.open()
        return self

    def __exit__(self, *args):
        self.close()

    def open(self) -> None:
        self.file = open(self.filename, "rb")

    def close(self) -> None:
        if self.file is not None:
            self.file.close()
        self.file = None

    def _crc(self, buffer: bytes, nbytes: int = -1) -> int:
        if nbytes == -1:
            nbytes = len(buffer)
        return zlib.crc32(buffer) & 0xFFFFFFFF

    def read_bootid(self) -> BootIDNu:
        if self.file is None:
            raise AppFileError("File not open")
        self.file.seek(self.BOOTID_OFFSET)

        btid = self.file.read(self.BOOTID_SIZE)
        aes = AES.new(self.BTKEY, AES.MODE_CBC, self.BTIV)
        btid = aes.decrypt(btid)

        parts = struct.unpack("<II4s", btid[:12])

        if self._crc(btid[4:]) != parts[0]:
            raise AppFileError("Boot ID CRC failed")
        if parts[1] != self.BOOTID_SIZE:
            raise AppFileError(f"Boot ID length invalid ({parts[1]:4x})")
        if parts[2] != b"BTID":
            raise AppFileError(f"Boot ID signature invalid ({parts[2]})")

        self.bootid = BootIDNu.from_bytes(btid[12:96])

        self.block_size = self.bootid.block_size
        self.block_count = self.bootid.block_count
        return self.bootid

    def _calculate_signature(self) -> bytes:
        if self.file is None:
            raise AppFileError("File not open")

        if self.block_size == -1:
            self.read_bootid()

        self.file.seek(self.CRC_OFFSET)
        hmac = HMAC.new(self.SIGKEY, digestmod=SHA1)
        to_read = self.block_size * 8 - self.CRC_OFFSET
        while to_read:
            block = self.file.read(min(0x1000, to_read))
            if len(block) == 0:
                raise AppFileError("Ran out of data checking signature")

            hmac.update(block)
            to_read -= len(block)

        return hmac.digest()

    def verify_signature(self) -> bool:
        if self.file is None:
            raise AppFileError("File not open")

        self.file.seek(self.SIGNATURE_OFFSET)
        signature = self.file.read(self.SIGNATURE_SIZE)
        if len(signature) != self.SIGNATURE_SIZE:
            raise AppFileError("Ran out of data reading signature")

        if len(signature) < SHA1.digest_size:
            raise AppFileError("File signature impossibly small")

        digest = self._calculate_signature()
        return digest == signature[: len(digest)]

    def verify_block(self, block_n: int) -> bool:
        if self.block_size == -1:
            self.read_bootid()

        if self.file is None:
            raise AppFileError("File not open")

        self.file.seek(self.CRC_OFFSET + 4 * block_n)
        crc = self.file.read(4)
        if len(crc) != 4:
            raise AppFileError(f"Ran out of data reading block {block_n} CRC")
        expected_crc = struct.unpack("<I", crc)[0]

        block_length = self.block_size
        if block_n == 0:
            self.file.seek(0)
            block = self.file.read(self.SIGNATURE_OFFSET)
            skip = self.SIGNATURE_SIZE + 4
            self.file.seek(skip, 1)
            block += self.file.read(self.block_size - (self.SIGNATURE_OFFSET + skip))
            block_length -= skip
        else:
            self.file.seek(block_n * self.block_size)
            block = self.file.read(self.block_size)

        if len(block) != block_length:
            raise AppFileError(f"Ran out of data reading block {block_n}")

        return self._crc(block) == expected_crc

    def verify_all_blocks(self) -> bool:
        if self.block_count == -1:
            self.read_bootid()

        ret = True
        bar = Bar("Verifying blocks", self.block_count)
        for i in bar:
            if not self.verify_block(i):
                bar.print_over(f"Block {i} failed verification")
                ret = False
        return ret


class AppFileWriter(AppFile):
    def open(self) -> None:
        self.file = open(self.filename, "r+b")

    def repair_signature(self, reseed: bool = False) -> None:
        if self.file is None:
            raise AppFileWriterError("File not open")

        digest = self._calculate_signature()
        if len(digest) > self.SIGNATURE_SIZE:
            raise AppFileWriterError("New signature impossibly long")

        if reseed and len(digest) < self.SIGNATURE_SIZE:
            digest += secrets.token_bytes(self.SIGNATURE_SIZE - len(digest))

        self.file.seek(self.SIGNATURE_OFFSET)
        self.file.write(digest)

    def repair_block_crc(self, block_n: int) -> None:
        if self.block_size == -1:
            self.read_bootid()

        if self.file is None:
            raise AppFileWriterError("File not open")

        block_length = self.block_size
        if block_n == 0:
            self.file.seek(0)
            block = self.file.read(self.SIGNATURE_OFFSET)
            skip = self.SIGNATURE_SIZE + 4
            self.file.seek(skip, 1)
            block += self.file.read(self.block_size - (self.SIGNATURE_OFFSET + skip))
            block_length -= skip
        else:
            self.file.seek(block_n * self.block_size)
            block = self.file.read(self.block_size)

        self.file.seek(self.CRC_OFFSET + 4 * block_n)
        self.file.write(struct.pack("<I", self._crc(block)))

    def repair_all_block_crcs(self) -> bool:
        if self.block_count == -1:
            self.read_bootid()

        ret = True
        bar = Bar("Repairing block CRCs", self.block_count)
        for i in bar:
            if not self.verify_block(i):
                bar.print_over(f"Block {i} failed verification")
                ret = False
        return ret
