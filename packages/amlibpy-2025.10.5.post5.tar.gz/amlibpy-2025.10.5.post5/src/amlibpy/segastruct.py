import struct
import zlib
from dataclasses import dataclass

from Crypto.Cipher import AES

from .util import format_size


@dataclass
class Timestamp:
    year: int
    month: int
    day: int
    hour: int
    minute: int
    second: int

    @classmethod
    def from_bytes(cls, data: bytes):
        return cls(*struct.unpack("<H5Bx", data))

    def to_bytes(self):
        return struct.pack(
            "<H5Bx",
            self.year,
            self.month,
            self.day,
            self.hour,
            self.minute,
            self.second,
        )

    def __str__(self):
        return f"{self.year:04}-{self.month:02}-{self.day:02}-{self.hour:02}:{self.minute:02}:{self.second:02}"


@dataclass
class BootIDNu:
    unk0: int
    unk1: int  # Game ID check skipped if 0
    unk2: int
    unk3: int
    game_id: str
    game_timestamp: Timestamp
    game_ver: tuple[int, int, int]
    block_count: int
    block_size: int
    header_count: int
    hw: str
    orgtime: Timestamp
    orgver: tuple[int, int, int]
    osver: tuple[int, int, int]

    @property
    def data_offset(self) -> int:
        return self.header_count * self.block_size

    @classmethod
    def from_bytes(cls, data: bytes):
        parts = list(
            struct.unpack("<" "4B" "4s8sBBH" "QQQ8x" "3sB8sBBH" "BBH12x", data)
        )

        return cls(
            unk0=parts.pop(0),
            unk1=parts.pop(0),
            unk2=parts.pop(0),
            unk3=parts.pop(0),
            game_id=parts.pop(0).decode(),
            game_timestamp=Timestamp.from_bytes(parts.pop(0)),
            game_ver=(parts.pop(0), parts.pop(0), parts.pop(0))[::-1],
            block_count=parts.pop(0),
            block_size=parts.pop(0),
            header_count=parts.pop(0),
            hw=parts.pop(0).decode(),
            orgtime=Timestamp.from_bytes(parts.pop(0)),
            orgver=(parts.pop(0), parts.pop(0), parts.pop(0))[::-1],
            osver=(parts.pop(0), parts.pop(0), parts.pop(0))[::-1],
        )


@dataclass
class BootIDRing:
    model_type: int
    image_type: int
    game_id: str
    game_timestamp: Timestamp
    version: tuple[int, int]
    flags: int  # two nibbles
    seg_count: int
    seg_size: int
    hw: str
    instant: bool
    org_time: Timestamp
    org_version: tuple[int, int]
    os_ver: tuple[int, int, int]
    os_seg_count: int

    name: str
    strings: list[str]

    @classmethod
    def from_bytes(cls, data: bytes, key: tuple[bytes, bytes] | None = None):
        if key is not None:
            data = AES.new(key[0], AES.MODE_CBC, key[1]).decrypt(data)

        parts = struct.unpack(
            "<"
            "II4sBBxx"  # Boot ID header
            "4sH5Bx2H7xBII3sBH5Bx2H3BxI8x"  # Install info
            "16x"  # Padding
            "160s"  # Game name
            "32s32s32s32s32s32s32s32s",  # Strings
            data,
        )
        if parts[0] != zlib.crc32(data[4:]) & 0xFFFFFFFF:
            return None
        assert parts[1] == 512
        assert parts[2] == b"BTID"

        return cls(
            model_type=parts[3],
            image_type=parts[4],
            game_id=parts[5].decode("latin-1"),
            game_timestamp=Timestamp(
                parts[6],
                parts[7],
                parts[8],
                parts[9],
                parts[10],
                parts[11],
            ),
            version=(parts[13], parts[12]),
            flags=parts[14],
            seg_count=parts[15],
            seg_size=parts[16],
            hw=parts[17].decode("latin-1"),
            instant=bool(parts[18]),
            org_time=Timestamp(
                parts[19],
                parts[20],
                parts[21],
                parts[22],
                parts[23],
                parts[24],
            ),
            org_version=(parts[26], parts[25]),
            os_ver=(parts[29], parts[28], parts[27]),
            os_seg_count=parts[30],
            name=parts[31].split(b"\0")[0].decode("latin-1"),
            strings=[i.split(b"\0")[0].decode("latin-1") for i in parts[32:]],
        )


@dataclass
class SPDSlot:
    slot: int
    unk: int
    block_size: int
    block_count: int


@dataclass
class SEGAPartitionDescription:
    version: int
    slots: list[SPDSlot]


@dataclass
class SBRSlot:
    id: str
    timestamp: Timestamp
    version: tuple[int, int, int]
    segcount: int
    segsize: int
    hw: str
    instant: int
    orgtime: Timestamp
    orgversion: tuple[int, int, int]
    osver: tuple[int, int, int]
    ossegcount: int

    @classmethod
    def from_bytes(cls, data: bytes):
        slot = struct.unpack("<4s8sBBH 8xII 3sB8sBBH BBHI8x", data)
        return cls(
            slot[0].decode(),
            Timestamp.from_bytes(slot[1]),
            (slot[2], slot[3], slot[4]),
            slot[5],
            slot[6],
            slot[7].decode(),
            slot[8],
            Timestamp.from_bytes(slot[9]),
            (slot[10], slot[11], slot[12]),
            (slot[13], slot[14], slot[15]),
            slot[16],
        )

    def to_bytes(self) -> bytes:
        return struct.pack(
            "<4s8sBBH 8xII 3sB8sBBH BBHI8x",
            self.id.encode(),
            self.timestamp.to_bytes(),
            *self.version,
            self.segcount,
            self.segsize,
            self.hw.encode(),
            *self.instant,
            self.orgtime.to_bytes(),
            *self.orgversion,
            *self.osver,
            self.ossegcount,
        )

    def short_format(self):
        if self.id == "\0\0\0\0":
            return "Not installed"
        return f"{self.id} {self.version[0]}.{self.version[1]}.{self.version[2]}"

    def long_format(self, indent=0):
        indent = " " * indent
        return "\n".join(
            (
                f"{indent}   Data size | {format_size(self.segcount * self.segsize)} ({self.segcount} segments x {format_size(self.segsize)})",
                f"{indent}For hardware | {self.hw}",
                f"{indent}Main version | {self.version[0]}.{self.version[1]}.{self.version[2]}, {self.timestamp}",
                f"{indent} Org version | {self.orgversion[0]}.{self.orgversion[1]}.{self.orgversion[2]}, {self.orgtime}",
                f"{indent}  OS version | {self.osver[0]}.{self.osver[1]}.{self.osver[2]} ({self.ossegcount} segments)",
                f"{indent}       Flags | {'Instant' if self.instant else 'None'}",
            )
        )


@dataclass
class SEGABootRecord:
    version: int
    boot_slot: int
    status: list[int]
    os: SBRSlot
    original0: SBRSlot
    appdata: SBRSlot
    patch0: SBRSlot
    patch1: SBRSlot
