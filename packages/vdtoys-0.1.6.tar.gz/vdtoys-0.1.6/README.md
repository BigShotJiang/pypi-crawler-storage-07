# VDToys - Python

Code that I have been writing for many times in many repos, I don't want to write them again.

Useless, but can be installed via:
```bash
pip install vdtoys
```
