# -*- coding: utf-8 -*-

from .caster import redshift_caster

caster = redshift_caster

__version__ = "1.40.0"