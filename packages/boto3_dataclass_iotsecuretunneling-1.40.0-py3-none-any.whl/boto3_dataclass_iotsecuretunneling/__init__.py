# -*- coding: utf-8 -*-

from .caster import iotsecuretunneling_caster

caster = iotsecuretunneling_caster

__version__ = "1.40.0"