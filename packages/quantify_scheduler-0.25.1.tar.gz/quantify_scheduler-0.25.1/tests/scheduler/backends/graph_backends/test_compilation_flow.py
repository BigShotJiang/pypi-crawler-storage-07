"""
This file is intended to cover the basic flow of compilation.
It will essentially verify that different ways of invoking the compilation will
trigger the right functions.
"""

pass
