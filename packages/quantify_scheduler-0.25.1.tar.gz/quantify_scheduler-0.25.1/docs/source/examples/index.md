# Examples and how-to guides 

```{toctree}
:maxdepth: 1

connectivity_examples
deprecated
hardware_config_migration
serialization
UML_class_diagrams
```
