(sec-user-guide)=
# User guide

```{toctree}
:caption: Getting started
:maxdepth: 1

about
installation
```

```{toctree}
:caption: Basic concepts
:maxdepth: 1

user_guide
quantify_compilers
```


```{toctree}
:caption: Extras
:maxdepth: 1

release_notes
changelog
authors
bibliography
```
