# -*- coding: utf-8 -*-

from .caster import repostspace_caster

caster = repostspace_caster

__version__ = "1.40.0"