# Copyright (C) 2024 Maxwell G <maxwell@gtmx.me>
# SPDX-License-Identifier: MIT

# This package is special, because it uses none of the Go or forge macros other
# than %%gobuild and builds with Go modules enabled.

%bcond check 1
%global common_description %{expand:
:cherry_blossom: A command-line fuzzy finder.}

Name:           test-fzf
Version:        0.46.1
Release:        1%{?dist}
Summary:        :cherry_blossom: A command-line fuzzy finder

License:        Apache-2.0 AND BSD-3-Clause AND MIT
URL:            https://github.com/junegunn/fzf
Source0:        %{url}/archive/%{version}/fzf-%{version}.tar.gz
Source1:        fzf-%{version}-vendor.tar.bz2
Source2:        expected-licenses.list
Source3:        go-vendor-tools.toml
Source4:        gocheck_expected1.txt
Source5:        gocheck_expected2.txt
Source6:        gocheck_expected3.txt
Source7:        test_test.go

ExclusiveArch:  %{golang_arches_future}

BuildRequires:  go-rpm-macros
BuildRequires:  go-vendor-tools

%description %{common_description}

%prep
%autosetup -p1 -n fzf-%{version}
%setup -q -T -D -b1 -n fzf-%{version}
cp -p %{S:4} %{S:5} %{S:6} .
cp -p %{S:7} src/

%generate_buildrequires
%go_vendor_license_buildrequires -c %{S:3}
%go_vendor_license_buildrequires -c %{S:3} -d trivy

%build
%global gomodulesmode GO111MODULE=on
%gobuild -o fzf github.com/junegunn/fzf
%global debug_package %{nil}

%install
# Check go_vendor_license_buildrequires
(%{go_vendor_license_buildrequires -d askalono}) | tee buildrequires
test "$(cat buildrequires)" = "askalono-cli"
(%{go_vendor_license_buildrequires -d trivy}) | tee buildrequires
test "$(cat buildrequires)" = "trivy"
# Specify -n manually for testing purposes
%go_vendor_license_install -n not-fzf -c %{S:3} -D askalono_path=/usr/bin/askalono

%check
%go_vendor_license_check -c %{S:3}
%go_vendor_license_check -d trivy -c %{S:3}

diff -u "%{S:2}" "$(pwd)/licenses.list"

# This is here to test handling of build tags.
# See below.
mkdir brokendir
cat <<EOF >brokendir/broken_test.go
//go:build brokendir
package brokendir
import "testing"
func TestBrokenDir(t *testing.T) {
    t.Error("This test should fail when -tag brokendir is passed")
}
EOF

%{gocheck2 -L} | tee gocheck_gotten1.txt
diff -u gocheck_expected1.txt gocheck_gotten1.txt

%{gocheck2 -p . -L} | tee gocheck_gotten1.txt
diff -u gocheck_expected1.txt gocheck_gotten1.txt

# TODO: Check the -F (--no-follow) flag with a package that actually has
# multiple go.mod files
%{gocheck2 -F -L} | tee gocheck_gotten1.txt
diff -u gocheck_expected1.txt gocheck_gotten1.txt

%{gocheck2 -L -t src} | tee gocheck_gotten2.txt
diff -u gocheck_expected2.txt gocheck_gotten2.txt

%{gocheck2 -L -t github.com/junegunn/fzf} | tee gocheck_gotten2.txt
diff -u gocheck_expected2.txt gocheck_gotten2.txt

%{gocheck2 %{shrink:-L
    -d github.com/junegunn/fzf/src
    -d github.com/junegunn/fzf/src/algo
    -d github.com/junegunn/fzf/src/tui
    -d github.com/junegunn/fzf/src/util
}} | tee gocheck_gotten2.txt
diff -u gocheck_expected2.txt gocheck_gotten2.txt

%{gocheck2 %{shrink:-L
    -d src
    -d src/algo
    -d src/tui
    -d src/util
}} | tee gocheck_gotten2.txt
diff -u gocheck_expected2.txt gocheck_gotten2.txt


head -n -1 gocheck_expected1.txt  > gocheck_expected1.1.txt

%{gocheck2 -L -d github.com/junegunn/fzf/src/util} | tee gocheck_gotten1.1.txt
diff -u gocheck_expected1.1.txt gocheck_gotten1.1.txt

%{gocheck2 -L -d src/util} | tee gocheck_gotten1.1.txt
diff -u gocheck_expected1.1.txt gocheck_gotten1.1.txt

%gocheck2 -s TestBroken -s TestSomethingElseBroken
%gocheck2 && exit $? || true

# When brokendir tag is enabled, %%goipath/brokendir should be included in the
# go list output, and the TestBrokenDir() should run and then fail.
GO_BUILDTAGS=brokendir %{gocheck2 -L -s 'TestBroken' -s 'TestSomethingElseBroken'} | tee gocheck_gotten3.txt
diff -u gocheck_expected3.txt gocheck_gotten3.txt
rm src/test_test.go
# GO_BUILDTAGS can be added before the gocheck2 macro or exported separately.
export GO_BUILDTAGS=brokendir
%gocheck2 && exit $? || true

%files -f %{go_vendor_license_filelist}
%doc doc ADVANCED.md BUILD.md CHANGELOG.md README-VIM.md README.md

%changelog
* Thu Feb 29 2024 Maxwell G <maxwell@gtmx.me> - 0.46.1-1
- Initial package
