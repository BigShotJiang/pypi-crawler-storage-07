"""Tests for cachedx"""
