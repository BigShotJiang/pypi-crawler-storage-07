"""Core utilities for cachedx"""
