class IllegalArgumentError(ValueError):
    pass
