"""Type stubs for quillmark."""

__version__: str
