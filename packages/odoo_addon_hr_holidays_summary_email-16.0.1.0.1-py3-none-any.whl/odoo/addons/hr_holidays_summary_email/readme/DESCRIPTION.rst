This module allows sending a daily/weekly email to employees with a summary
of the leaves on that period of other employees in the same company.
