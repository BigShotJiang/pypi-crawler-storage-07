# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
# pylint: disable=wildcard-import,unused-wildcard-import
from onnx_ir import *  # type: ignore # noqa: F403
