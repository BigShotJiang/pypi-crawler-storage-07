from .cores import *
from .roots import *
from .logs import *
from .envs import *
from .errors import *

@MLuaLogsDecorator.info("Checking status.")
def status():
    MLuaLogsPrinter.info("Normal.")

def requirements() -> None:
    print("\n".join(["lupa", "colorama"]))

@MLuaLogsDecorator.info("Testing module.")
@MLuaLogsDecorator.timer()
def test(path: str) -> None:
    lua = MLuaEnvironment()
    module = MLuaModule(path)
    result = module.mount(lua)
    print(result)
