"""AEMET API integration via Model Context Protocol."""

__version__ = "0.3.1"

# Expose other functions of the server
# from .server import *
