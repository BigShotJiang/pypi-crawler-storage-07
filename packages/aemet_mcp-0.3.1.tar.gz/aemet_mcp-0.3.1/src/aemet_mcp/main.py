from server import main as server_main

def main():
    """Ejecutar la función server main."""
    server_main()
    print("Hola desde AEMET-mcp!")

if __name__ == "__main__":
    main()
