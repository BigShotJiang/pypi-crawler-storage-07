Girder Python Client
====================

This is a set of python libraries and a command-line tool that can be used to
interact with the REST API of a `Girder <http://girder.readthedocs.org>`_ server.

Documentation for the client can be found at http://girder.readthedocs.org/en/latest/python-client.html.
