"""
Main entry point for running Eval Protocol as a module.
"""

import sys

from eval_protocol.cli import main

if __name__ == "__main__":
    sys.exit(main())
