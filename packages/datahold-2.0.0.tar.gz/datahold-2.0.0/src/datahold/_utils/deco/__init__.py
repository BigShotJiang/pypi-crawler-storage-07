from datahold._utils.deco.dataDeco import dataDeco
from datahold._utils.deco.funcDeco import funcDeco
from datahold._utils.deco.initDeco import initDeco
