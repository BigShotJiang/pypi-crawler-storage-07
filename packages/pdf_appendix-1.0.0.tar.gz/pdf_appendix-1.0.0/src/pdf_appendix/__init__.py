__all__ = ["add_appendix", "__version__"]
__version__ = "1.0.0"

from .core import add_appendix
