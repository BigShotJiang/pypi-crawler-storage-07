# vt-err-hndlr

![PyPI - Python Version](https://img.shields.io/pypi/pyversions/vt-err-hndlr)
![PyPI - Types](https://img.shields.io/pypi/types/vt-err-hndlr)
![GitHub License](https://img.shields.io/github/license/Vaastav-Technologies/py-err-hndlr)
[![🔧 test](https://github.com/Vaastav-Technologies/py-err-hndlr/actions/workflows/test.yml/badge.svg)](https://github.com/Vaastav-Technologies/py-err-hndlr/actions/workflows/test.yml)
[![💡 typecheck](https://github.com/Vaastav-Technologies/py-err-hndlr/actions/workflows/typecheck.yml/badge.svg)](https://github.com/Vaastav-Technologies/py-err-hndlr/actions/workflows/typecheck.yml)
[![🛠️ lint](https://github.com/Vaastav-Technologies/py-err-hndlr/actions/workflows/lint.yml/badge.svg)](https://github.com/Vaastav-Technologies/py-err-hndlr/actions/workflows/lint.yml)
[![📊 coverage](https://codecov.io/gh/Vaastav-Technologies/py-err-hndlr/branch/main/graph/badge.svg)](https://codecov.io/gh/Vaastav-Technologies/py-err-hndlr)
[![📤 Upload Python Package](https://github.com/Vaastav-Technologies/py-err-hndlr/actions/workflows/python-publish.yml/badge.svg)](https://github.com/Vaastav-Technologies/py-err-hndlr/actions/workflows/python-publish.yml)
![PyPI - Version](https://img.shields.io/pypi/v/vt-err-hndlr)

---

Fully typed collection of common python interfaces and handers for errors and warnings.
