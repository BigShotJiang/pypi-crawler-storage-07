# -*- coding: utf-8 -*-

from .caster import amplify_caster

caster = amplify_caster

__version__ = "1.40.0"