from roboherd.cow.types import MetaInformation

meta_information = MetaInformation(
    author="acct:helge@mymath.rocks", source="https://codeberg.org/bovine/roboherd"
)
