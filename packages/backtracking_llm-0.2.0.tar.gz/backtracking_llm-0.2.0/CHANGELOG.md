# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to
[Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.2.0] - 2025-10-03

### Added

-   Introduced a configuration-driven benchmarking module for evaluating
    backtracking performance.
-   Integration with `lm-evaluation-harness` for running standardized NLP
    benchmarks.
-   Hyperparameter optimization using `optuna` to find the best `Operator`
    settings.
-   New CLI script for launching benchmark runs from a YAML configuration file.

### Fixed

-   Corrected the stop sequence handling to robustly and automatically stop on
    both the model's EOS token and user-defined sequences, preventing premature
    generation termination.

## [0.1.0] - 2025-09-04

### Added

- Initial public release.
- Core `Generator` class for text eneration with a novel backtracking mechanism.
- A suite of `Operator` classes for controlling backtracking logic.
- Stateless `ChatPipeline` for easy, multi-turn conversational interactions.
- Interactive `backtracking-llm` CLI for local-first chatting.

[Unreleased]: https://github.com/matee8/backtracking_llm/compare/v0.2.0...HEAD
[0.1.0]: https://github.com/matee8/backtracking_llm/releases/tag/v0.1.0
[0.2.0]: https://github.com/matee8/backtracking_llm/releases/tag/v0.2.0
