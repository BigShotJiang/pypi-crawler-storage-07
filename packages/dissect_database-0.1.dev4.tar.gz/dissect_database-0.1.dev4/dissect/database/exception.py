from __future__ import annotations


class Error(Exception):
    pass
