KNOWN_EXTRAS_FOR_PACKAGES = {
    "prefect-kubernetes": "prefect[kubernetes]",
    "prefect-aws": "prefect[aws]",
    "prefect-gcp": "prefect[gcp]",
    "prefect-azure": "prefect[azure]",
    "prefect-docker": "prefect[docker]",
}
