# Crosstabs Analytics

AI-powered statistical analysis for Jupyter notebooks.

## Installation

```bash
pip install crosstabs-analytics
```

## Quick Start

```python
import pandas as pd
from crosstabs_analytics import CrosstabsAnalyzer

# Load your data
df = pd.read_csv('your_data.csv')

# Initialize analyzer
crosstabs = CrosstabsAnalyzer()

# Analyze your data
results = crosstabs.analyze(df)
display(results)
```

## Features

- **AI-Powered Analysis**: Get GPT-4 powered statistical insights
- **Beautiful Results**: View results in interactive HTML format
- **Multiple Export Formats**: PDF, Excel, JSON
- **Batch Processing**: Analyze multiple datasets
- **Custom Parameters**: Tailor analysis to your needs
- **Integration**: Works with matplotlib, seaborn, and other tools

## Usage Examples

### Basic Analysis

```python
from crosstabs_analytics import CrosstabsAnalyzer

crosstabs = CrosstabsAnalyzer()
results = crosstabs.analyze(df)
display(results)
```

### Batch Analysis

```python
datasets = {
    'Q1_2024': df1,
    'Q2_2024': df2,
    'Q3_2024': df3
}

batch_results = crosstabs.batch_analyze(datasets)
```

### Export Results

```python
raw_results = crosstabs.get_raw_results(df)
pdf_url = crosstabs.export_pdf(raw_results['analysis_id'])
excel_url = crosstabs.export_excel(raw_results['analysis_id'])
```

## Requirements

- Python 3.8+
- pandas
- numpy
- requests
- matplotlib
- seaborn
- jupyter

## Support

- Website: https://crosstabs.com
- Documentation: https://docs.crosstabs.com
- Support: support@crosstabs.com
- GitHub: https://github.com/crosstabs/crosstabs-analytics

## License

MIT License

