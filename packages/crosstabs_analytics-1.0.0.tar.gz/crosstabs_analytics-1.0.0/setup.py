from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="crosstabs-analytics",
    version="1.0.0",
    author="Crosstabs Analytics",
    author_email="support@crosstabs.com",
    description="AI-powered statistical analysis for Jupyter notebooks",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://crosstabs.com",
    project_urls={
        "Homepage": "https://crosstabs.com",
        "Documentation": "https://crosstabs.com/docs",
        "Repository": "https://github.com/crosstabs/crosstabs-analytics",
        "Bug Reports": "https://github.com/crosstabs/crosstabs-analytics/issues",
    },
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Scientific/Engineering :: Information Analysis",
        "Topic :: Scientific/Engineering :: Mathematics",
    ],
    python_requires=">=3.8",
    install_requires=[
        "pandas>=1.3.0",
        "numpy>=1.21.0",
        "requests>=2.25.0",
        "matplotlib>=3.3.0",
        "seaborn>=0.11.0",
        "ipython>=7.0.0",
        "jupyter>=1.0.0",
    ],
    extras_require={
        "dev": [
            "pytest>=6.0",
            "black>=21.0",
            "flake8>=3.8",
        ],
    },
    entry_points={
        "console_scripts": [
            "crosstabs=crosstabs_analytics.cli:main",
        ],
    },
)

