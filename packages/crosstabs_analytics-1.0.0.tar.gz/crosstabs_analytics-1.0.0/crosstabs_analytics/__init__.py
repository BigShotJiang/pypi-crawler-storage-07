"""
Crosstabs Analytics - AI-powered statistical analysis for Jupyter notebooks
"""

from .analyzer import CrosstabsAnalyzer
from .version import __version__

__all__ = ["CrosstabsAnalyzer", "__version__"]

