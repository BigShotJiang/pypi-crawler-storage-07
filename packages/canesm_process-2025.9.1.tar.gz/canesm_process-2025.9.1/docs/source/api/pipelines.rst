.. pipelines

Pipelines
=========

Pipelines
---------

.. autoclass:: canproc.pipelines.Pipeline


Variables
---------

.. autoclass:: canproc.pipelines.variable.Variable