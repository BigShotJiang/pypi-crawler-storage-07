.. processors

API Reference
=============

.. toctree::
   :maxdepth: 2
   :caption: Contents

   dag
   basic
   dask
   register
   pipelines