.. dag-api

DAG Functionality
=================

DAG Process
-------------
.. autoclass:: canproc.DAGProcess

DAG
---
.. autoclass:: canproc.DAG

Merge
-----
.. autofunction:: canproc.merge