.. register


Extending `canesm-processor`
============================

Register Module
---------------
.. autofunction:: canproc.register_module