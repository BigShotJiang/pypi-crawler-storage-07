.. dask

Runners
=======

Dask Runner
-----------
.. autoclass:: canproc.runners.dask.DaskRunner


Dask Distributed Runner
-----------------------
.. autoclass:: canproc.runners.distributed.DaskDistributedRunner

