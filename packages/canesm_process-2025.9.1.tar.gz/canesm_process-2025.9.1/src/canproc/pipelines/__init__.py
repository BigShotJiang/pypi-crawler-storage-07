from canproc.pipelines.pipelines import canesm_pipeline, Pipeline
