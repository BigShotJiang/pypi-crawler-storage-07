from chalk.client.serialization.query_serialization import MULTI_QUERY_MAGIC_STR

__all__ = ["MULTI_QUERY_MAGIC_STR"]
