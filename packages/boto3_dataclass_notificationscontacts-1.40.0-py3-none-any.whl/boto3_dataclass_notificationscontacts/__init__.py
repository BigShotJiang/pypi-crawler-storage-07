# -*- coding: utf-8 -*-

from .caster import notificationscontacts_caster

caster = notificationscontacts_caster

__version__ = "1.40.0"