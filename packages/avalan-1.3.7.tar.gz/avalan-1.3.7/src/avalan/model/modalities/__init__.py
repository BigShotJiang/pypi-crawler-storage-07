from .registry import ModalityRegistry as ModalityRegistry
from . import audio, text, vision  # noqa: F401
