# absd

A Library that does exactly what is needed of it

## Usage

Those who come looking beware for you shall not find anything but emptiness here.
-blank