# APIGEE Client SDK

Python client library for interacting with APIGEE through a centralized service.

## Features

- 🔐 **OAuth2 Token Management** - Automatic token fetching and caching
- 🚀 **API Proxying** - Seamless API calls through APIGEE gateway
- ⚡ **FastAPI Integration** - Built-in router for automatic endpoint proxying
- 🎯 **Type Safe** - Full type hints and Pydantic validation
- 🔄 **Async/Await** - Modern async Python support
- 📦 **Zero Configuration** - Works out of the box

## Installation

```bash
pip install sso-apigee-client
```

### With FastAPI Support

```bash
pip install sso-apigee-client[fastapi]
```

## Quick Start

### Basic Usage

```python
import asyncio
from sso_apigee_client import ApigeeClient

async def main():
    # Initialize client
    client = ApigeeClient("http://localhost:8000")
    
    try:
        # Get APIGEE token
        token = await client.get_token()
        print(f"Token: {token}")
        
        # Make API call through APIGEE
        data = await client.call_api(
            method="GET",
            endpoint="/api/v1/users",
            query_params={"page": 1}
        )
        print(f"Data: {data}")
        
    finally:
        await client.close()

asyncio.run(main())
```

### Using Context Manager

```python
async with ApigeeClient("http://localhost:8000") as client:
    users = await client.call_api("GET", "/api/v1/users")
    print(users)
```

### FastAPI Integration

```python
from fastapi import FastAPI
from sso_apigee_client import ApigeeClient, ApigeeRouter

app = FastAPI()
apigee = ApigeeClient("http://localhost:8000")

# Create router with automatic proxying
router = ApigeeRouter(
    apigee_client=apigee,
    apigee_base_path="/api/v1",
    prefix="/api"
)

@router.get("/users")
async def get_users():
    # Automatically proxied through APIGEE!
    pass

@router.get("/users/{user_id}")
async def get_user(user_id: str):
    # Path params automatically handled!
    pass

app.include_router(router)
```

## API Reference

### ApigeeClient

#### Methods

- **`get_token(force_refresh=False)`** - Get APIGEE OAuth2 access token
- **`call_api(method, endpoint, **kwargs)`** - Make authenticated API call via proxy
- **`get_token_status()`** - Get current token status
- **`health_check()`** - Check service health
- **`close()`** - Close HTTP client

### ApigeeRouter

FastAPI router that automatically proxies all requests through APIGEE.

#### Parameters

- `apigee_client` - ApigeeClient instance
- `apigee_base_path` - Base path for APIGEE endpoints
- `auto_proxy` - Enable automatic proxying (default: True)
- `prefix` - FastAPI router prefix
- `tags` - OpenAPI tags

#### Route Decorators

- `@router.get(path)` - GET endpoint
- `@router.post(path)` - POST endpoint
- `@router.put(path)` - PUT endpoint
- `@router.delete(path)` - DELETE endpoint

#### Special Parameters

- `apigee_endpoint` - Override APIGEE endpoint path
- `skip_apigee` - Skip APIGEE proxying for specific route

## Configuration

The SDK requires an APIGEE service running. Set up the service:

```bash
# Clone the service repository
git clone https://github.com/yourorg/sso-apigee-service

# Configure environment
cp .env.example .env
# Edit .env with your APIGEE credentials

# Run with Docker
docker-compose up -d
```

## Requirements

- Python 3.11+
- httpx >= 0.25.0
- pydantic >= 2.5.0
- fastapi >= 0.104.0 (optional, for FastAPI integration)

## License

MIT License

## Support

For issues and questions:
- GitHub Issues: https://github.com/yourorg/sso-apigee-client/issues
- Documentation: https://github.com/yourorg/sso-apigee-service

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.
