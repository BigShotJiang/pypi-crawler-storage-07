"""
APIGEE Client SDK

A Python client library for interacting with APIGEE through the service.

This SDK handles APIGEE-specific functionality only:
- OAuth2 token management
- API proxying through APIGEE
- Token status

SSO functionality (user authentication) will be in a separate SDK.

Example:
    from sso_apigee_client import ApigeeClient
    
    client = ApigeeClient("http://localhost:8000")
    
    # Get APIGEE token
    token = await client.get_token()
    
    # Make API call through APIGEE
    data = await client.call_api("GET", "/api/v1/data")
"""

from sso_apigee_client.apigee_client import ApigeeClient
from sso_apigee_client.exceptions import (
    APIError,
    AuthenticationError,
    ConnectionError,
    SSOApigeeError,
)
from sso_apigee_client.models import TokenStatus

__version__ = "1.0.2"

# FastAPI integration is optional - only import if FastAPI is installed
__all__ = [
    "ApigeeClient",
    "SSOApigeeError",
    "AuthenticationError",
    "APIError",
    "ConnectionError",
    "TokenStatus",
]

try:
    from sso_apigee_client.fastapi_integration import (
        ApigeeRouter,
        create_apigee_dependency,
    )
    __all__.extend(["ApigeeRouter", "create_apigee_dependency"])
except ImportError:
    # FastAPI not installed - integration not available
    pass
