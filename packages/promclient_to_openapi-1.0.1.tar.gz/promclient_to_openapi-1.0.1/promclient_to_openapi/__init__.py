"""Translates prometheus_client metrics to OpenAPI."""

from promclient_to_openapi.synchronous import prometheus_client_to_openapi

__all__ = ("prometheus_client_to_openapi",)
