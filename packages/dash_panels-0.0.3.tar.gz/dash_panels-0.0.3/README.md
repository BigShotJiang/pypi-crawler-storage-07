# Dash Panels

Dash Panels is a Dash component library.

Resizable panels inspired by react-resizable-panels. 



