# Contributing to PyStak

Thank you for your interest in contributing to PyStak! This document provides guidelines and information for contributors.

## 🚀 Getting Started

### Prerequisites

- Python 3.8 or higher
- Git
- Basic understanding of async/await in Python
- Familiarity with web frameworks

### Development Setup

1. **Fork and Clone**
   ```bash
   git clone https://github.com/yourusername/pystak.git
   cd pystak
   ```

2. **Create Virtual Environment**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install Development Dependencies**
   ```bash
   pip install -e .[dev]
   ```

4. **Install Pre-commit Hooks**
   ```bash
   pre-commit install
   ```

## 🛠️ Development Workflow

### Code Style

We use several tools to maintain code quality:

- **Black** for code formatting
- **isort** for import sorting
- **flake8** for linting
- **mypy** for type checking

Run all checks:
```bash
# Format code
black pystak/ tests/ examples/
isort pystak/ tests/ examples/

# Lint code
flake8 pystak/ tests/ examples/

# Type check
mypy pystak/
```

### Testing

We use pytest for testing. All new features should include tests.

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=pystak --cov-report=html

# Run specific test file
pytest tests/test_routing.py

# Run specific test
pytest tests/test_routing.py::test_basic_routing
```

### Writing Tests

- Place tests in the `tests/` directory
- Use descriptive test names
- Include both positive and negative test cases
- Test async functions with `pytest-asyncio`

Example test:
```python
import pytest
from pystak import PyStak
from pystak.testing import TestClient

@pytest.fixture
def app():
    app = PyStak()
    
    @app.get("/test")
    async def test_endpoint():
        return {"message": "test"}
    
    return app

@pytest.fixture
def client(app):
    return TestClient(app)

def test_endpoint(client):
    response = client.get("/test")
    assert response.status_code == 200
    assert response.json() == {"message": "test"}
```

## 📝 Contribution Types

### Bug Reports

When reporting bugs, please include:

- Python version
- PyStak version
- Minimal code example that reproduces the issue
- Expected vs actual behavior
- Full error traceback if applicable

### Feature Requests

For new features:

- Describe the use case
- Explain why it would be valuable
- Provide examples of how it would be used
- Consider backward compatibility

### Code Contributions

1. **Create a Branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```

2. **Make Changes**
   - Write code following our style guidelines
   - Add tests for new functionality
   - Update documentation if needed

3. **Commit Changes**
   ```bash
   git add .
   git commit -m "feat: add new feature description"
   ```

   We follow [Conventional Commits](https://conventionalcommits.org/):
   - `feat:` for new features
   - `fix:` for bug fixes
   - `docs:` for documentation changes
   - `test:` for test additions/changes
   - `refactor:` for code refactoring
   - `perf:` for performance improvements

4. **Push and Create PR**
   ```bash
   git push origin feature/your-feature-name
   ```

## 🏗️ Project Structure

```
pystak/
├── pystak/              # Main package
│   ├── __init__.py      # Package exports
│   ├── app.py           # Main application class
│   ├── routing.py       # Routing system
│   ├── request.py       # Request handling
│   ├── response.py      # Response classes
│   ├── middleware.py    # Middleware system
│   ├── dependency.py    # Dependency injection
│   ├── validation.py    # Validation system
│   ├── config.py        # Configuration management
│   ├── exceptions.py    # Custom exceptions
│   └── cli.py           # CLI tools
├── tests/               # Test files
├── examples/            # Example applications
├── docs/                # Documentation
└── scripts/             # Development scripts
```

## 📚 Documentation

### Docstrings

Use Google-style docstrings:

```python
def example_function(param1: str, param2: int) -> bool:
    """Example function with docstring.
    
    Args:
        param1: Description of param1
        param2: Description of param2
    
    Returns:
        Description of return value
    
    Raises:
        ValueError: When param1 is empty
    """
    if not param1:
        raise ValueError("param1 cannot be empty")
    return len(param1) > param2
```

### Type Hints

- Use type hints for all public APIs
- Import types from `typing` module when needed
- Use `Optional[T]` for nullable types
- Use `Union[T, U]` for multiple types

## 🔍 Code Review Process

1. **Automated Checks**
   - All tests must pass
   - Code coverage should not decrease
   - Linting and formatting checks must pass

2. **Manual Review**
   - Code quality and readability
   - Architecture and design decisions
   - Documentation completeness
   - Test coverage and quality

3. **Approval**
   - At least one maintainer approval required
   - All feedback addressed
   - CI/CD pipeline passes

## 🚀 Release Process

1. **Version Bumping**
   - Follow [Semantic Versioning](https://semver.org/)
   - Update version in `pystak/__init__.py`
   - Update CHANGELOG.md

2. **Testing**
   - Run full test suite
   - Test examples and documentation
   - Manual testing of key features

3. **Release**
   - Create release tag
   - Build and publish to PyPI
   - Update documentation

## 💡 Development Tips

### Adding New Features

1. **Start with Tests**
   - Write tests first (TDD approach)
   - Define the API you want to create

2. **Keep It Simple**
   - Follow KISS principle
   - Avoid over-engineering
   - Consider backward compatibility

3. **Documentation**
   - Update docstrings
   - Add examples
   - Update README if needed

### Performance Considerations

- PyStak is designed for high performance
- Use async/await properly
- Avoid blocking operations
- Profile code for bottlenecks
- Consider memory usage

### Debugging

```python
# Enable debug logging
import logging
logging.basicConfig(level=logging.DEBUG)

# Use PyStak debug mode
app = PyStak(debug=True)
```

## 🤝 Community Guidelines

### Code of Conduct

- Be respectful and inclusive
- Welcome newcomers
- Focus on constructive feedback
- Help others learn and grow

### Communication

- **GitHub Issues**: Bug reports and feature requests
- **GitHub Discussions**: General questions and ideas
- **Discord**: Real-time chat and community support

## 📞 Getting Help

If you need help:

1. Check existing documentation
2. Search GitHub issues
3. Ask in GitHub Discussions
4. Join our Discord community

## 🎉 Recognition

Contributors are recognized in:

- CONTRIBUTORS.md file
- Release notes
- GitHub contributors page
- Special mentions for significant contributions

Thank you for contributing to PyStak! 🚀
