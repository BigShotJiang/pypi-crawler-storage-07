"""
Basic PyStak Application Example

This example demonstrates:
- Basic routing
- Path parameters
- JSON responses
- Error handling
"""

from pystak import PyStak, JSONResponse, HTTPException

app = PyStak()

# In-memory data store for demo
users = [
    {"id": 1, "name": "Alice", "email": "alice@example.com"},
    {"id": 2, "name": "Bob", "email": "bob@example.com"},
]

@app.get("/")
async def home():
    """Welcome endpoint"""
    return {
        "message": "Welcome to PyStak!",
        "version": "1.0.0",
        "endpoints": [
            "GET /",
            "GET /health",
            "GET /users",
            "GET /users/{id}",
            "POST /users",
        ]
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "pystak-demo"}

@app.get("/users")
async def get_users():
    """Get all users"""
    return {"users": users, "count": len(users)}

@app.get("/users/<int:user_id>")
async def get_user(user_id: int):
    """Get user by ID"""
    user = next((u for u in users if u["id"] == user_id), None)
    if not user:
        raise HTTPException(404, f"User with ID {user_id} not found")
    return {"user": user}

@app.post("/users")
async def create_user(request):
    """Create new user"""
    try:
        data = await request.json()
        
        # Simple validation
        if not data.get("name"):
            raise HTTPException(400, "Name is required")
        if not data.get("email"):
            raise HTTPException(400, "Email is required")
        
        # Create new user
        new_user = {
            "id": max(u["id"] for u in users) + 1 if users else 1,
            "name": data["name"],
            "email": data["email"]
        }
        users.append(new_user)
        
        return JSONResponse(
            {"message": "User created", "user": new_user},
            status_code=201
        )
    
    except Exception as e:
        if isinstance(e, HTTPException):
            raise
        raise HTTPException(400, f"Invalid request: {str(e)}")

if __name__ == "__main__":
    print("Starting PyStak Basic Example...")
    print("Visit http://localhost:8000 to see the API")
    app.run(debug=True)
