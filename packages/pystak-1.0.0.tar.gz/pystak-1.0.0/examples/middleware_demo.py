"""
PyStak Middleware Demonstration

This example shows various middleware capabilities:
- Custom middleware creation
- Built-in security middleware
- Request/response processing
- Error handling middleware
- Performance monitoring
"""

import time
import logging
from pystak import PyStak, Middleware, Request, Response, JSONResponse

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Custom Middleware Examples

class TimingMiddleware(Middleware):
    """Middleware to measure request processing time"""
    
    async def process_request(self, request: Request, call_next):
        start_time = time.time()
        
        # Add timing header to request
        request.start_time = start_time
        
        # Process request
        response = await call_next()
        
        # Calculate processing time
        processing_time = time.time() - start_time
        
        # Add timing header to response
        response.set_header('X-Processing-Time', f"{processing_time:.3f}s")
        
        logger.info(f"Request {request.method} {request.path} took {processing_time:.3f}s")
        
        return response


class RequestIDMiddleware(Middleware):
    """Middleware to add unique request IDs"""
    
    def __init__(self):
        self.request_counter = 0
    
    async def process_request(self, request: Request, call_next):
        # Generate unique request ID
        self.request_counter += 1
        request_id = f"req-{self.request_counter:06d}"
        
        # Add to request
        request.request_id = request_id
        
        # Process request
        response = await call_next()
        
        # Add to response headers
        response.set_header('X-Request-ID', request_id)
        
        return response


class APIKeyMiddleware(Middleware):
    """Simple API key authentication middleware"""
    
    def __init__(self, required_paths=None, valid_keys=None):
        self.required_paths = required_paths or ['/api/']
        self.valid_keys = valid_keys or ['demo-key-123', 'admin-key-456']
    
    async def process_request(self, request: Request, call_next):
        # Check if path requires API key
        requires_auth = any(request.path.startswith(path) for path in self.required_paths)
        
        if requires_auth:
            api_key = request.get_header('X-API-Key')
            
            if not api_key:
                return JSONResponse(
                    {"error": "API key required", "hint": "Add X-API-Key header"},
                    status_code=401
                )
            
            if api_key not in self.valid_keys:
                return JSONResponse(
                    {"error": "Invalid API key"},
                    status_code=401
                )
            
            # Add authenticated user info to request
            request.authenticated = True
            request.api_key = api_key
        
        return await call_next()


class ResponseModifierMiddleware(Middleware):
    """Middleware to modify responses"""
    
    async def process_request(self, request: Request, call_next):
        response = await call_next()
        
        # Add common headers to all responses
        response.set_header('X-Powered-By', 'PyStak/1.0.0')
        response.set_header('X-Content-Type-Options', 'nosniff')
        
        # Add CORS headers for API endpoints
        if request.path.startswith('/api/'):
            response.set_header('Access-Control-Allow-Origin', '*')
            response.set_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE')
        
        return response


# Create application
app = PyStak()

# Add middleware in order (they execute in the order added)
app.middleware(RequestIDMiddleware)
app.middleware(TimingMiddleware)
app.middleware(APIKeyMiddleware)
app.middleware(ResponseModifierMiddleware)

# Routes

@app.get("/")
async def home(request: Request):
    """Public endpoint - no auth required"""
    return {
        "message": "Welcome to PyStak Middleware Demo!",
        "request_id": getattr(request, 'request_id', 'unknown'),
        "endpoints": {
            "public": ["/", "/health", "/info"],
            "protected": ["/api/users", "/api/data", "/api/admin"]
        },
        "auth_info": "Protected endpoints require X-API-Key header"
    }

@app.get("/health")
async def health():
    """Health check endpoint"""
    return {"status": "healthy", "service": "middleware-demo"}

@app.get("/info")
async def info(request: Request):
    """Show request information"""
    return {
        "method": request.method,
        "path": request.path,
        "headers": dict(request.headers),
        "query_params": dict(request.query_params),
        "request_id": getattr(request, 'request_id', 'unknown'),
        "authenticated": getattr(request, 'authenticated', False)
    }

# Protected API endpoints

@app.get("/api/users")
async def get_users(request: Request):
    """Protected endpoint - requires API key"""
    return {
        "users": [
            {"id": 1, "name": "Alice", "role": "admin"},
            {"id": 2, "name": "Bob", "role": "user"}
        ],
        "request_id": getattr(request, 'request_id', 'unknown'),
        "authenticated_with": getattr(request, 'api_key', 'unknown')
    }

@app.get("/api/data")
async def get_data(request: Request):
    """Protected endpoint with simulated processing time"""
    import asyncio
    # Simulate some processing
    await asyncio.sleep(0.1)
    
    return {
        "data": [1, 2, 3, 4, 5],
        "processed_at": time.time(),
        "request_id": getattr(request, 'request_id', 'unknown')
    }

@app.post("/api/admin")
async def admin_action(request: Request):
    """Admin endpoint"""
    data = await request.json() if request.is_json else {}
    
    return {
        "message": "Admin action completed",
        "action": data.get("action", "unknown"),
        "request_id": getattr(request, 'request_id', 'unknown'),
        "timestamp": time.time()
    }

# Slow endpoint to demonstrate timing middleware
@app.get("/slow")
async def slow_endpoint():
    """Intentionally slow endpoint"""
    import asyncio
    await asyncio.sleep(2)  # Simulate slow processing
    return {"message": "This was slow!", "delay": "2 seconds"}

if __name__ == "__main__":
    import asyncio
    
    print("Starting PyStak Middleware Demo...")
    print()
    print("Middleware Stack:")
    print("1. RequestIDMiddleware - Adds unique request IDs")
    print("2. TimingMiddleware - Measures processing time")
    print("3. APIKeyMiddleware - Protects /api/* endpoints")
    print("4. ResponseModifierMiddleware - Adds common headers")
    print()
    print("Try these endpoints:")
    print("- GET  http://localhost:8000/")
    print("- GET  http://localhost:8000/info")
    print("- GET  http://localhost:8000/slow")
    print("- GET  http://localhost:8000/api/users (requires X-API-Key header)")
    print()
    print("Valid API keys: demo-key-123, admin-key-456")
    print("Example: curl -H 'X-API-Key: demo-key-123' http://localhost:8000/api/users")
    print()
    
    app.run(debug=True)
