"""
Advanced PyStak API Example

This example demonstrates:
- Dependency injection
- Validation with schemas
- Middleware usage
- Route groups
- Error handling
- Configuration
"""

from dataclasses import dataclass
from typing import List, Optional
from datetime import datetime

from pystak import (
    PyStak, JSONResponse, HTTPException, Depends, Injectable,
    validate_json, Schema, FieldValidator, TypeValidator, EmailValidator
)
from pystak.middleware import CORSMiddleware, RequestLoggingMiddleware, SecurityHeadersMiddleware

# Data Models
@dataclass
class User:
    id: Optional[int] = None
    name: str = ""
    email: str = ""
    created_at: Optional[datetime] = None

@dataclass
class CreateUserRequest:
    name: str
    email: str

# Services
@Injectable
class UserService:
    """User service with business logic"""
    
    def __init__(self):
        self.users: List[User] = [
            User(1, "Alice Johnson", "alice@example.com", datetime.now()),
            User(2, "Bob Smith", "bob@example.com", datetime.now()),
        ]
        self.next_id = 3
    
    async def get_all_users(self) -> List[User]:
        """Get all users"""
        return self.users
    
    async def get_user_by_id(self, user_id: int) -> Optional[User]:
        """Get user by ID"""
        return next((u for u in self.users if u.id == user_id), None)
    
    async def create_user(self, user_data: CreateUserRequest) -> User:
        """Create new user"""
        # Check if email already exists
        if any(u.email == user_data.email for u in self.users):
            raise HTTPException(400, "Email already exists")
        
        user = User(
            id=self.next_id,
            name=user_data.name,
            email=user_data.email,
            created_at=datetime.now()
        )
        self.users.append(user)
        self.next_id += 1
        return user
    
    async def update_user(self, user_id: int, user_data: CreateUserRequest) -> Optional[User]:
        """Update existing user"""
        user = await self.get_user_by_id(user_id)
        if not user:
            return None
        
        user.name = user_data.name
        user.email = user_data.email
        return user
    
    async def delete_user(self, user_id: int) -> bool:
        """Delete user"""
        user = await self.get_user_by_id(user_id)
        if not user:
            return False
        
        self.users.remove(user)
        return True

@Injectable
class StatsService:
    """Statistics service"""
    
    def __init__(self, user_service: UserService = Depends()):
        self.user_service = user_service
    
    async def get_stats(self) -> dict:
        """Get application statistics"""
        users = await self.user_service.get_all_users()
        return {
            "total_users": len(users),
            "timestamp": datetime.now().isoformat()
        }

# Create application
app = PyStak()

# Add middleware
app.middleware(CORSMiddleware(
    allow_origins=["http://localhost:3000", "http://localhost:8080"],
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["*"],
    allow_credentials=True
))
app.middleware(SecurityHeadersMiddleware())
app.middleware(RequestLoggingMiddleware())

# Root routes
@app.get("/")
async def root():
    """API root"""
    return {
        "name": "PyStak Advanced API",
        "version": "1.0.0",
        "description": "Advanced API example with dependency injection and validation",
        "endpoints": {
            "users": "/api/v1/users",
            "stats": "/api/v1/stats",
            "health": "/health"
        }
    }

@app.get("/health")
async def health_check(stats_service: StatsService = Depends()):
    """Health check with stats"""
    stats = await stats_service.get_stats()
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "stats": stats
    }

# API v1 routes
api_v1 = app.group("/api/v1")

@api_v1.get("/users")
async def get_users(user_service: UserService = Depends()):
    """Get all users"""
    users = await user_service.get_all_users()
    return {
        "users": [
            {
                "id": u.id,
                "name": u.name,
                "email": u.email,
                "created_at": u.created_at.isoformat() if u.created_at else None
            }
            for u in users
        ],
        "count": len(users)
    }

@api_v1.get("/users/<int:user_id>")
async def get_user(user_id: int, user_service: UserService = Depends()):
    """Get user by ID"""
    user = await user_service.get_user_by_id(user_id)
    if not user:
        raise HTTPException(404, f"User with ID {user_id} not found")
    
    return {
        "user": {
            "id": user.id,
            "name": user.name,
            "email": user.email,
            "created_at": user.created_at.isoformat() if user.created_at else None
        }
    }

@api_v1.post("/users")
@validate_json(CreateUserRequest)
async def create_user(validated_data: CreateUserRequest, user_service: UserService = Depends()):
    """Create new user with validation"""
    user = await user_service.create_user(validated_data)
    return JSONResponse(
        {
            "message": "User created successfully",
            "user": {
                "id": user.id,
                "name": user.name,
                "email": user.email,
                "created_at": user.created_at.isoformat() if user.created_at else None
            }
        },
        status_code=201
    )

@api_v1.put("/users/<int:user_id>")
@validate_json(CreateUserRequest)
async def update_user(
    user_id: int,
    validated_data: CreateUserRequest,
    user_service: UserService = Depends()
):
    """Update user"""
    user = await user_service.update_user(user_id, validated_data)
    if not user:
        raise HTTPException(404, f"User with ID {user_id} not found")
    
    return {
        "message": "User updated successfully",
        "user": {
            "id": user.id,
            "name": user.name,
            "email": user.email,
            "created_at": user.created_at.isoformat() if user.created_at else None
        }
    }

@api_v1.delete("/users/<int:user_id>")
async def delete_user(user_id: int, user_service: UserService = Depends()):
    """Delete user"""
    success = await user_service.delete_user(user_id)
    if not success:
        raise HTTPException(404, f"User with ID {user_id} not found")
    
    return {"message": f"User {user_id} deleted successfully"}

@api_v1.get("/stats")
async def get_stats(stats_service: StatsService = Depends()):
    """Get application statistics"""
    return await stats_service.get_stats()

# Error handlers
@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc: HTTPException):
    """Custom HTTP exception handler"""
    return JSONResponse(
        {
            "error": {
                "message": exc.detail,
                "status_code": exc.status_code,
                "path": request.path,
                "method": request.method
            }
        },
        status_code=exc.status_code
    )

@app.exception_handler(Exception)
async def general_exception_handler(request, exc: Exception):
    """General exception handler"""
    return JSONResponse(
        {
            "error": {
                "message": "Internal server error",
                "type": type(exc).__name__,
                "path": request.path,
                "method": request.method
            }
        },
        status_code=500
    )

if __name__ == "__main__":
    print("Starting PyStak Advanced API Example...")
    print("Features demonstrated:")
    print("- Dependency Injection")
    print("- Request Validation")
    print("- Middleware Stack")
    print("- Route Groups")
    print("- Error Handling")
    print()
    print("Try these endpoints:")
    print("- GET  http://localhost:8000/")
    print("- GET  http://localhost:8000/health")
    print("- GET  http://localhost:8000/api/v1/users")
    print("- POST http://localhost:8000/api/v1/users")
    print("- GET  http://localhost:8000/api/v1/stats")
    print()
    app.run(debug=True)
