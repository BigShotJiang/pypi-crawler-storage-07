"""
Basic tests for PyStak framework
"""

import pytest
import asyncio
from pystak import PyStak, JSONResponse, HTTPException


class MockASGI:
    """Mock ASGI interface for testing"""
    
    def __init__(self):
        self.messages = []
    
    async def send(self, message):
        self.messages.append(message)
    
    async def receive(self):
        return {
            'type': 'http.request',
            'body': b'',
            'more_body': False
        }


@pytest.fixture
def app():
    """Create test application"""
    app = PyStak()
    
    @app.get("/")
    async def home():
        return {"message": "Hello, World!"}
    
    @app.get("/users/<int:user_id>")
    async def get_user(user_id: int):
        return {"user_id": user_id}
    
    @app.post("/users")
    async def create_user():
        return JSONResponse({"created": True}, status_code=201)
    
    @app.get("/error")
    async def error_endpoint():
        raise HTTPException(400, "Test error")
    
    return app


@pytest.mark.asyncio
async def test_basic_routing(app):
    """Test basic routing functionality"""
    # Test route matching
    route_match = app.router.match("/", "GET")
    assert route_match is not None
    
    handler, params = route_match
    assert callable(handler)
    assert params == {}


@pytest.mark.asyncio
async def test_path_parameters(app):
    """Test path parameter extraction"""
    route_match = app.router.match("/users/123", "GET")
    assert route_match is not None
    
    handler, params = route_match
    assert params == {"user_id": 123}


@pytest.mark.asyncio
async def test_route_not_found(app):
    """Test 404 handling"""
    route_match = app.router.match("/nonexistent", "GET")
    assert route_match is None


def test_app_creation():
    """Test application creation"""
    app = PyStak()
    assert app is not None
    assert app.router is not None
    assert app.middleware_stack is not None
    assert app.dependency_container is not None


def test_route_registration():
    """Test route registration"""
    app = PyStak()
    
    @app.get("/test")
    async def test_handler():
        return {"test": True}
    
    # Check that route was registered
    assert len(app.router.routes) == 1
    route = app.router.routes[0]
    assert route.path == "/test"
    assert route.methods == ["GET"]


def test_middleware_registration():
    """Test middleware registration"""
    from pystak.middleware import CORSMiddleware
    
    app = PyStak()
    app.middleware(CORSMiddleware)
    
    assert len(app.middleware_stack.middleware_classes) == 1


def test_dependency_registration():
    """Test dependency registration"""
    from pystak import Injectable
    
    @Injectable
    class TestService:
        def get_data(self):
            return "test data"
    
    app = PyStak()
    app.injectable(TestService)
    
    # Check that dependency was registered
    assert TestService in app.dependency_container._bindings


@pytest.mark.asyncio
async def test_exception_handling(app):
    """Test exception handling"""
    # Create mock ASGI scope for error endpoint
    scope = {
        'type': 'http',
        'method': 'GET',
        'path': '/error',
        'headers': [],
        'query_string': b''
    }
    
    mock_asgi = MockASGI()
    
    # This should handle the HTTPException
    await app(scope, mock_asgi.receive, mock_asgi.send)
    
    # Check that response was sent
    assert len(mock_asgi.messages) >= 2  # start + body
    start_message = mock_asgi.messages[0]
    assert start_message['type'] == 'http.response.start'
    assert start_message['status'] == 400


def test_route_groups():
    """Test route groups"""
    app = PyStak()
    api_group = app.group("/api")
    
    @api_group.get("/users")
    async def get_users():
        return {"users": []}
    
    # Check that route was registered with prefix
    assert len(app.router.routes) == 1
    route = app.router.routes[0]
    assert route.path == "/api/users"


if __name__ == "__main__":
    pytest.main([__file__])
