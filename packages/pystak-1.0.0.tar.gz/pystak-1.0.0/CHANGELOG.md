# Changelog

All notable changes to PyStak will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2024-09-30

### Added

#### Core Framework
- **PyStak Application Class**: Main application orchestrator with ASGI support
- **Advanced Routing System**: Path parameters with type conversion (int, float, UUID, slug)
- **Request/Response Handling**: Comprehensive request parsing and response types
- **Async-First Design**: Full async/await support throughout the framework

#### Dependency Injection
- **Advanced DI Container**: Automatic dependency resolution with circular dependency detection
- **Lifetime Management**: Singleton, transient, and scoped dependency lifetimes
- **Factory Functions**: Support for factory-based dependency creation
- **Injectable Decorator**: Simple class decoration for dependency registration

#### Middleware System
- **Middleware Stack**: Ordered middleware execution with request/response processing
- **Built-in Security Middleware**: CORS, security headers, rate limiting
- **Performance Middleware**: Request timing, compression, logging
- **Custom Middleware Support**: Easy creation of custom middleware classes

#### Validation System
- **Schema Validation**: Comprehensive data validation with custom validators
- **Type Conversion**: Automatic type conversion and validation
- **Dataclass Integration**: Direct validation of dataclass models
- **Request Decorators**: `@validate_json` and `@validate_query` decorators

#### Configuration Management
- **Multi-Source Config**: Environment variables, YAML, JSON, .env files
- **Type-Safe Access**: Automatic type conversion with validation
- **Environment Prefixes**: Configurable environment variable prefixes
- **Hot Reloading**: Runtime configuration reloading support

#### CLI Tools
- **Project Scaffolding**: `pystak new` command with multiple templates
- **Development Server**: `pystak run` with auto-reload and debug support
- **Code Generation**: Generate routes, middleware, and models
- **Template System**: Basic, API, and full-featured project templates

#### Developer Experience
- **Rich Error Messages**: Detailed error reporting with stack traces
- **Debug Mode**: Enhanced debugging with request/response logging
- **Type Safety**: Full type hints throughout the codebase
- **IDE Support**: Excellent autocomplete and type checking

### Features by Category

#### Routing
- Path parameter extraction with type conversion
- Route groups and prefixes
- Named routes for URL generation
- Custom path converters
- HTTP method routing (GET, POST, PUT, DELETE, PATCH)

#### Request Handling
- JSON request parsing
- Form data handling (URL-encoded and multipart)
- File upload support
- Query parameter parsing
- Header access and manipulation
- Client IP detection

#### Response Types
- JSON responses with custom serialization
- HTML responses with template support
- File responses with streaming
- Redirect responses
- Custom response classes
- Cookie management

#### Middleware Features
- CORS support with configurable origins
- Security headers (CSP, HSTS, X-Frame-Options)
- Request logging with timing
- Rate limiting with configurable limits
- Compression middleware
- Authentication middleware

#### Validation Features
- Required field validation
- Type validation with conversion
- Length and range validation
- Email and URL validation
- Regular expression validation
- Custom validator functions
- Schema composition

#### Configuration Features
- YAML configuration files
- JSON configuration files
- .env file support
- Environment variable loading
- Nested configuration access
- Default value support
- Configuration validation

### Project Templates

#### Basic Template
- Simple application structure
- Basic routing examples
- Health check endpoint
- Development configuration

#### API Template
- RESTful API structure
- Authentication middleware
- CORS configuration
- Service layer pattern
- Model definitions

#### Full Template
- Complete application setup
- Database configuration
- Docker support
- Production configuration
- Comprehensive middleware stack

### Documentation
- Comprehensive README with examples
- API documentation with type hints
- Contributing guidelines
- Code of conduct
- License (MIT)

### Examples
- Basic application example
- Advanced API with dependency injection
- Middleware demonstration
- Validation examples
- Configuration examples

### Development Tools
- Pre-commit hooks configuration
- Code formatting with Black
- Import sorting with isort
- Linting with flake8
- Type checking with mypy
- Testing with pytest

### Performance
- High-throughput request handling
- Low-latency response times
- Memory-efficient design
- Connection pooling support
- Async I/O optimization

### Security
- Built-in security headers
- CORS protection
- Rate limiting
- Input validation
- SQL injection prevention
- XSS protection

### Compatibility
- Python 3.8+ support
- ASGI server compatibility
- Uvicorn integration
- Docker support
- Cloud deployment ready

## [Unreleased]

### Planned Features
- WebSocket support
- Background task system
- Database ORM integration
- Caching system
- Authentication providers
- OpenAPI/Swagger integration
- Monitoring and metrics
- Template engine integration
- Static file serving
- Session management

---

For more details about any release, please see the [GitHub releases page](https://github.com/pystak/pystak/releases).
