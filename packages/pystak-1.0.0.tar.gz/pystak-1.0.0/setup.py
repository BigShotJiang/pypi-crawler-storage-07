"""
PyStak Framework Setup
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read README
readme_path = Path(__file__).parent / "README.md"
long_description = readme_path.read_text(encoding="utf-8") if readme_path.exists() else ""

# Read version
version_path = Path(__file__).parent / "pystak" / "__init__.py"
version = "1.0.0"
if version_path.exists():
    for line in version_path.read_text().splitlines():
        if line.startswith("__version__"):
            version = line.split('"')[1]
            break

setup(
    name="pystak",
    version=version,
    author="PyStak Team",
    author_email="team@pystak.dev",
    description="A modern, high-performance Python web framework with advanced features",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/pystak/pystak",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Internet :: WWW/HTTP :: HTTP Servers",
        "Topic :: Internet :: WWW/HTTP :: WSGI :: Application",
        "Topic :: Software Development :: Libraries :: Application Frameworks",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Framework :: AsyncIO",
    ],
    python_requires=">=3.8",
    install_requires=[
        "uvicorn[standard]>=0.18.0",
        "pydantic>=2.0.0",
        "python-multipart>=0.0.5",
        "jinja2>=3.0.0",
        "pyyaml>=6.0",
        "python-dotenv>=0.19.0",
        "click>=8.0.0",
        "rich>=12.0.0",
        "httpx>=0.24.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "pytest-cov>=4.0.0",
            "black>=22.0.0",
            "isort>=5.10.0",
            "flake8>=5.0.0",
            "mypy>=1.0.0",
            "pre-commit>=2.20.0",
        ],
        "docs": [
            "mkdocs>=1.4.0",
            "mkdocs-material>=8.5.0",
            "mkdocstrings[python]>=0.19.0",
        ],
        "database": [
            "sqlalchemy>=2.0.0",
            "alembic>=1.8.0",
            "asyncpg>=0.27.0",  # PostgreSQL
            "aiomysql>=0.1.1",  # MySQL
            "aiosqlite>=0.17.0",  # SQLite
        ],
        "cache": [
            "redis>=4.3.0",
            "aioredis>=2.0.0",
        ],
        "auth": [
            "python-jose[cryptography]>=3.3.0",
            "passlib[bcrypt]>=1.7.4",
        ],
        "monitoring": [
            "prometheus-client>=0.14.0",
            "opentelemetry-api>=1.12.0",
            "opentelemetry-sdk>=1.12.0",
        ],
        "all": [
            # Include all extras
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "pytest-cov>=4.0.0",
            "black>=22.0.0",
            "isort>=5.10.0",
            "flake8>=5.0.0",
            "mypy>=1.0.0",
            "pre-commit>=2.20.0",
            "mkdocs>=1.4.0",
            "mkdocs-material>=8.5.0",
            "mkdocstrings[python]>=0.19.0",
            "sqlalchemy>=2.0.0",
            "alembic>=1.8.0",
            "asyncpg>=0.27.0",
            "aiomysql>=0.1.1",
            "aiosqlite>=0.17.0",
            "redis>=4.3.0",
            "aioredis>=2.0.0",
            "python-jose[cryptography]>=3.3.0",
            "passlib[bcrypt]>=1.7.4",
            "prometheus-client>=0.14.0",
            "opentelemetry-api>=1.12.0",
            "opentelemetry-sdk>=1.12.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "pystak=pystak.cli:main",
        ],
    },
    include_package_data=True,
    zip_safe=False,
    keywords="web framework async python api rest microservice",
    project_urls={
        "Documentation": "https://pystak.dev/docs",
        "Source": "https://github.com/pystak/pystak",
        "Tracker": "https://github.com/pystak/pystak/issues",
        "Changelog": "https://github.com/pystak/pystak/blob/main/CHANGELOG.md",
    },
)
