"""
PyStak Response Handling

Advanced response objects with automatic serialization and content negotiation.
"""

import json
import mimetypes
from typing import Any, Dict, List, Optional, Union
from pathlib import Path


class Response:
    """
    Base response class with:
    - Automatic content-type detection
    - Header management
    - Cookie support
    - Streaming support
    """
    
    def __init__(
        self,
        content: Union[str, bytes] = "",
        status_code: int = 200,
        headers: Optional[Dict[str, str]] = None,
        content_type: Optional[str] = None
    ):
        self.content = content
        self.status_code = status_code
        self.headers = headers or {}
        
        if content_type:
            self.headers['content-type'] = content_type
        elif 'content-type' not in self.headers:
            self.headers['content-type'] = self._detect_content_type()
    
    def _detect_content_type(self) -> str:
        """Auto-detect content type"""
        if isinstance(self.content, bytes):
            return 'application/octet-stream'
        return 'text/plain; charset=utf-8'
    
    def set_header(self, name: str, value: str):
        """Set response header"""
        self.headers[name.lower()] = value
    
    def set_cookie(
        self,
        name: str,
        value: str,
        max_age: Optional[int] = None,
        expires: Optional[str] = None,
        path: str = "/",
        domain: Optional[str] = None,
        secure: bool = False,
        httponly: bool = False,
        samesite: Optional[str] = None
    ):
        """Set response cookie"""
        cookie_parts = [f"{name}={value}"]
        
        if max_age is not None:
            cookie_parts.append(f"Max-Age={max_age}")
        if expires:
            cookie_parts.append(f"Expires={expires}")
        if path:
            cookie_parts.append(f"Path={path}")
        if domain:
            cookie_parts.append(f"Domain={domain}")
        if secure:
            cookie_parts.append("Secure")
        if httponly:
            cookie_parts.append("HttpOnly")
        if samesite:
            cookie_parts.append(f"SameSite={samesite}")
        
        cookie_header = "; ".join(cookie_parts)
        
        # Handle multiple cookies
        if 'set-cookie' in self.headers:
            existing = self.headers['set-cookie']
            if isinstance(existing, list):
                existing.append(cookie_header)
            else:
                self.headers['set-cookie'] = [existing, cookie_header]
        else:
            self.headers['set-cookie'] = cookie_header
    
    def delete_cookie(self, name: str, path: str = "/", domain: Optional[str] = None):
        """Delete cookie by setting it to expire"""
        self.set_cookie(
            name, "", max_age=0, expires="Thu, 01 Jan 1970 00:00:00 GMT",
            path=path, domain=domain
        )
    
    async def send(self, send):
        """Send response via ASGI"""
        # Prepare headers
        headers = []
        for name, value in self.headers.items():
            if isinstance(value, list):
                for v in value:
                    headers.append([name.encode(), v.encode()])
            else:
                headers.append([name.encode(), value.encode()])
        
        # Send response start
        await send({
            'type': 'http.response.start',
            'status': self.status_code,
            'headers': headers,
        })
        
        # Send response body
        body = self.content
        if isinstance(body, str):
            body = body.encode('utf-8')
        
        await send({
            'type': 'http.response.body',
            'body': body,
        })


class JSONResponse(Response):
    """JSON response with automatic serialization"""
    
    def __init__(
        self,
        content: Any,
        status_code: int = 200,
        headers: Optional[Dict[str, str]] = None,
        json_encoder: Optional[json.JSONEncoder] = None
    ):
        self.json_encoder = json_encoder
        json_content = self._serialize_json(content)
        
        super().__init__(
            content=json_content,
            status_code=status_code,
            headers=headers,
            content_type='application/json; charset=utf-8'
        )
    
    def _serialize_json(self, content: Any) -> str:
        """Serialize content to JSON"""
        if self.json_encoder:
            return json.dumps(content, cls=self.json_encoder, ensure_ascii=False)
        return json.dumps(content, ensure_ascii=False, default=str)


class HTMLResponse(Response):
    """HTML response"""
    
    def __init__(
        self,
        content: str,
        status_code: int = 200,
        headers: Optional[Dict[str, str]] = None
    ):
        super().__init__(
            content=content,
            status_code=status_code,
            headers=headers,
            content_type='text/html; charset=utf-8'
        )


class PlainTextResponse(Response):
    """Plain text response"""
    
    def __init__(
        self,
        content: str,
        status_code: int = 200,
        headers: Optional[Dict[str, str]] = None
    ):
        super().__init__(
            content=content,
            status_code=status_code,
            headers=headers,
            content_type='text/plain; charset=utf-8'
        )


class RedirectResponse(Response):
    """Redirect response"""
    
    def __init__(
        self,
        url: str,
        status_code: int = 302,
        headers: Optional[Dict[str, str]] = None
    ):
        super().__init__(
            content="",
            status_code=status_code,
            headers=headers
        )
        self.set_header('location', url)


class FileResponse(Response):
    """File response with streaming support"""
    
    def __init__(
        self,
        path: Union[str, Path],
        filename: Optional[str] = None,
        content_type: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None
    ):
        self.path = Path(path)
        self.filename = filename or self.path.name
        
        if not self.path.exists():
            raise FileNotFoundError(f"File not found: {self.path}")
        
        # Auto-detect content type
        if not content_type:
            content_type, _ = mimetypes.guess_type(str(self.path))
            content_type = content_type or 'application/octet-stream'
        
        # Read file content
        with open(self.path, 'rb') as f:
            content = f.read()
        
        super().__init__(
            content=content,
            status_code=200,
            headers=headers,
            content_type=content_type
        )
        
        # Set content-disposition for downloads
        self.set_header('content-disposition', f'attachment; filename="{self.filename}"')
        self.set_header('content-length', str(len(content)))


class StreamingResponse(Response):
    """Streaming response for large content"""
    
    def __init__(
        self,
        content_generator,
        status_code: int = 200,
        headers: Optional[Dict[str, str]] = None,
        content_type: str = 'text/plain'
    ):
        self.content_generator = content_generator
        super().__init__(
            content="",  # Will be streamed
            status_code=status_code,
            headers=headers,
            content_type=content_type
        )
    
    async def send(self, send):
        """Send streaming response via ASGI"""
        # Prepare headers
        headers = []
        for name, value in self.headers.items():
            if isinstance(value, list):
                for v in value:
                    headers.append([name.encode(), v.encode()])
            else:
                headers.append([name.encode(), value.encode()])
        
        # Send response start
        await send({
            'type': 'http.response.start',
            'status': self.status_code,
            'headers': headers,
        })
        
        # Stream response body
        async for chunk in self.content_generator:
            if isinstance(chunk, str):
                chunk = chunk.encode('utf-8')
            
            await send({
                'type': 'http.response.body',
                'body': chunk,
                'more_body': True,
            })
        
        # Send final empty chunk
        await send({
            'type': 'http.response.body',
            'body': b'',
            'more_body': False,
        })


class TemplateResponse(HTMLResponse):
    """Template response with template engine integration"""
    
    def __init__(
        self,
        template_name: str,
        context: Optional[Dict[str, Any]] = None,
        status_code: int = 200,
        headers: Optional[Dict[str, str]] = None,
        template_engine=None
    ):
        self.template_name = template_name
        self.context = context or {}
        self.template_engine = template_engine
        
        # Render template
        rendered_content = self._render_template()
        
        super().__init__(
            content=rendered_content,
            status_code=status_code,
            headers=headers
        )
    
    def _render_template(self) -> str:
        """Render template with context"""
        if self.template_engine:
            return self.template_engine.render(self.template_name, self.context)
        
        # Fallback: simple string formatting
        try:
            with open(f"templates/{self.template_name}", 'r') as f:
                template_content = f.read()
            return template_content.format(**self.context)
        except (FileNotFoundError, KeyError):
            return f"<h1>Template Error</h1><p>Could not render {self.template_name}</p>"


# Response status code constants
class HTTPStatus:
    """HTTP status code constants"""
    
    # 1xx Informational
    CONTINUE = 100
    SWITCHING_PROTOCOLS = 101
    
    # 2xx Success
    OK = 200
    CREATED = 201
    ACCEPTED = 202
    NO_CONTENT = 204
    
    # 3xx Redirection
    MOVED_PERMANENTLY = 301
    FOUND = 302
    NOT_MODIFIED = 304
    TEMPORARY_REDIRECT = 307
    PERMANENT_REDIRECT = 308
    
    # 4xx Client Error
    BAD_REQUEST = 400
    UNAUTHORIZED = 401
    FORBIDDEN = 403
    NOT_FOUND = 404
    METHOD_NOT_ALLOWED = 405
    NOT_ACCEPTABLE = 406
    CONFLICT = 409
    GONE = 410
    UNPROCESSABLE_ENTITY = 422
    TOO_MANY_REQUESTS = 429
    
    # 5xx Server Error
    INTERNAL_SERVER_ERROR = 500
    NOT_IMPLEMENTED = 501
    BAD_GATEWAY = 502
    SERVICE_UNAVAILABLE = 503
    GATEWAY_TIMEOUT = 504
