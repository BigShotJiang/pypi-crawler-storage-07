"""
PyStak Request Handling

Advanced request object with automatic parsing, validation, and type conversion.
"""

import json
import urllib.parse
from typing import Any, Dict, List, Optional, Union
from dataclasses import dataclass, field


@dataclass
class UploadedFile:
    """Represents an uploaded file"""
    filename: str
    content_type: str
    content: bytes
    size: int


class Request:
    """
    Advanced request object with:
    - Automatic JSON/form parsing
    - File upload handling
    - Query parameter parsing
    - Header access
    - Path parameter extraction
    """
    
    def __init__(self, scope: dict, body: bytes = b''):
        self.scope = scope
        self._body = body
        self._json: Optional[Dict] = None
        self._form: Optional[Dict] = None
        self._files: Optional[Dict[str, UploadedFile]] = None
        self._query_params: Optional[Dict] = None
        self.path_params: Dict[str, Any] = {}
        
    @classmethod
    async def from_asgi(cls, scope: dict, receive) -> 'Request':
        """Create request from ASGI scope and receive callable"""
        body = b''
        
        # Read request body
        while True:
            message = await receive()
            if message['type'] == 'http.request':
                body += message.get('body', b'')
                if not message.get('more_body', False):
                    break
            elif message['type'] == 'http.disconnect':
                break
        
        return cls(scope, body)
    
    @property
    def method(self) -> str:
        """HTTP method"""
        return self.scope['method']
    
    @property
    def path(self) -> str:
        """Request path"""
        return self.scope['path']
    
    @property
    def query_string(self) -> str:
        """Raw query string"""
        return self.scope.get('query_string', b'').decode('utf-8')
    
    @property
    def headers(self) -> Dict[str, str]:
        """Request headers"""
        return {
            name.decode('latin1').lower(): value.decode('latin1')
            for name, value in self.scope.get('headers', [])
        }
    
    @property
    def content_type(self) -> str:
        """Content-Type header"""
        return self.headers.get('content-type', '')
    
    @property
    def content_length(self) -> int:
        """Content-Length header"""
        try:
            return int(self.headers.get('content-length', '0'))
        except ValueError:
            return 0
    
    @property
    def body(self) -> bytes:
        """Raw request body"""
        return self._body
    
    @property
    def text(self) -> str:
        """Request body as text"""
        return self._body.decode('utf-8')
    
    @property
    def query_params(self) -> Dict[str, Union[str, List[str]]]:
        """Parsed query parameters"""
        if self._query_params is None:
            self._query_params = self._parse_query_params()
        return self._query_params
    
    def _parse_query_params(self) -> Dict[str, Union[str, List[str]]]:
        """Parse query parameters from query string"""
        if not self.query_string:
            return {}
        
        params = {}
        for key, values in urllib.parse.parse_qs(self.query_string).items():
            if len(values) == 1:
                params[key] = values[0]
            else:
                params[key] = values
        
        return params
    
    async def json(self) -> Dict[str, Any]:
        """Parse request body as JSON"""
        if self._json is None:
            if not self._body:
                self._json = {}
            else:
                try:
                    self._json = json.loads(self._body.decode('utf-8'))
                except (json.JSONDecodeError, UnicodeDecodeError):
                    self._json = {}
        return self._json
    
    async def form(self) -> Dict[str, Union[str, List[str]]]:
        """Parse request body as form data"""
        if self._form is None:
            self._form = self._parse_form_data()
        return self._form
    
    def _parse_form_data(self) -> Dict[str, Union[str, List[str]]]:
        """Parse form-encoded data"""
        if not self._body:
            return {}
        
        content_type = self.content_type.lower()
        
        if content_type.startswith('application/x-www-form-urlencoded'):
            return self._parse_urlencoded_form()
        elif content_type.startswith('multipart/form-data'):
            return self._parse_multipart_form()
        
        return {}
    
    def _parse_urlencoded_form(self) -> Dict[str, Union[str, List[str]]]:
        """Parse URL-encoded form data"""
        try:
            form_data = urllib.parse.parse_qs(
                self._body.decode('utf-8'),
                keep_blank_values=True
            )
            
            # Convert single-item lists to strings
            result = {}
            for key, values in form_data.items():
                if len(values) == 1:
                    result[key] = values[0]
                else:
                    result[key] = values
            
            return result
        except UnicodeDecodeError:
            return {}
    
    def _parse_multipart_form(self) -> Dict[str, Union[str, List[str]]]:
        """Parse multipart form data (simplified implementation)"""
        # This is a simplified implementation
        # In production, you'd want to use a proper multipart parser
        content_type = self.headers.get('content-type', '')
        
        if 'boundary=' not in content_type:
            return {}
        
        boundary = content_type.split('boundary=')[1].split(';')[0].strip('"')
        boundary_bytes = f'--{boundary}'.encode()
        
        parts = self._body.split(boundary_bytes)
        form_data = {}
        
        for part in parts[1:-1]:  # Skip first empty part and last closing part
            if not part.strip():
                continue
            
            # Split headers and content
            if b'\r\n\r\n' in part:
                headers_section, content = part.split(b'\r\n\r\n', 1)
                content = content.rstrip(b'\r\n')
                
                # Parse Content-Disposition header
                headers_text = headers_section.decode('utf-8', errors='ignore')
                if 'Content-Disposition:' in headers_text:
                    disp_line = [line for line in headers_text.split('\n') 
                                if 'Content-Disposition:' in line][0]
                    
                    if 'name="' in disp_line:
                        name_start = disp_line.find('name="') + 6
                        name_end = disp_line.find('"', name_start)
                        field_name = disp_line[name_start:name_end]
                        
                        if 'filename="' in disp_line:
                            # File upload
                            filename_start = disp_line.find('filename="') + 10
                            filename_end = disp_line.find('"', filename_start)
                            filename = disp_line[filename_start:filename_end]
                            
                            # Extract content type
                            content_type_line = [line for line in headers_text.split('\n') 
                                               if 'Content-Type:' in line]
                            file_content_type = 'application/octet-stream'
                            if content_type_line:
                                file_content_type = content_type_line[0].split(':', 1)[1].strip()
                            
                            # Store file
                            if self._files is None:
                                self._files = {}
                            
                            self._files[field_name] = UploadedFile(
                                filename=filename,
                                content_type=file_content_type,
                                content=content,
                                size=len(content)
                            )
                        else:
                            # Regular form field
                            try:
                                value = content.decode('utf-8')
                                if field_name in form_data:
                                    if isinstance(form_data[field_name], list):
                                        form_data[field_name].append(value)
                                    else:
                                        form_data[field_name] = [form_data[field_name], value]
                                else:
                                    form_data[field_name] = value
                            except UnicodeDecodeError:
                                pass
        
        return form_data
    
    async def files(self) -> Dict[str, UploadedFile]:
        """Get uploaded files"""
        if self._files is None:
            # Parse form data to extract files
            await self.form()
        return self._files or {}
    
    def get_header(self, name: str, default: Optional[str] = None) -> Optional[str]:
        """Get header value"""
        return self.headers.get(name.lower(), default)
    
    def has_header(self, name: str) -> bool:
        """Check if header exists"""
        return name.lower() in self.headers
    
    def get_query_param(self, name: str, default: Optional[str] = None) -> Optional[str]:
        """Get single query parameter"""
        value = self.query_params.get(name, default)
        if isinstance(value, list):
            return value[0] if value else default
        return value
    
    def get_query_params(self, name: str) -> List[str]:
        """Get all values for query parameter"""
        value = self.query_params.get(name, [])
        if isinstance(value, str):
            return [value]
        return value
    
    @property
    def is_json(self) -> bool:
        """Check if request contains JSON"""
        return 'application/json' in self.content_type.lower()
    
    @property
    def is_form(self) -> bool:
        """Check if request contains form data"""
        ct = self.content_type.lower()
        return ('application/x-www-form-urlencoded' in ct or 
                'multipart/form-data' in ct)
    
    @property
    def client_ip(self) -> Optional[str]:
        """Get client IP address"""
        # Check for forwarded headers first
        forwarded_for = self.get_header('x-forwarded-for')
        if forwarded_for:
            return forwarded_for.split(',')[0].strip()
        
        real_ip = self.get_header('x-real-ip')
        if real_ip:
            return real_ip
        
        # Fall back to client from scope
        client = self.scope.get('client')
        if client:
            return client[0]
        
        return None
    
    @property
    def user_agent(self) -> Optional[str]:
        """Get User-Agent header"""
        return self.get_header('user-agent')
    
    def __repr__(self) -> str:
        return f"<Request {self.method} {self.path}>"
