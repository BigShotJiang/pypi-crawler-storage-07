"""
PyStak Exception Handling

Custom exceptions for the PyStak framework.
"""

from typing import Any, Dict, Optional


class PyStakException(Exception):
    """Base exception for PyStak framework"""
    
    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(message)
        self.message = message
        self.details = details or {}


class HTTPException(PyStakException):
    """HTTP exception with status code"""
    
    def __init__(self, status_code: int, detail: str, headers: Optional[Dict[str, str]] = None):
        super().__init__(detail)
        self.status_code = status_code
        self.detail = detail
        self.headers = headers or {}


class ValidationError(PyStakException):
    """Validation error exception"""
    
    def __init__(self, message: str, field: Optional[str] = None, value: Any = None):
        super().__init__(message)
        self.field = field
        self.value = value


class DependencyError(PyStakException):
    """Dependency injection error"""
    pass


class RoutingError(PyStakException):
    """Routing error exception"""
    pass


class ConfigurationError(PyStakException):
    """Configuration error exception"""
    pass


class MiddlewareError(PyStakException):
    """Middleware error exception"""
    pass


# HTTP Exception shortcuts
class BadRequest(HTTPException):
    def __init__(self, detail: str = "Bad Request"):
        super().__init__(400, detail)


class Unauthorized(HTTPException):
    def __init__(self, detail: str = "Unauthorized"):
        super().__init__(401, detail)


class Forbidden(HTTPException):
    def __init__(self, detail: str = "Forbidden"):
        super().__init__(403, detail)


class NotFound(HTTPException):
    def __init__(self, detail: str = "Not Found"):
        super().__init__(404, detail)


class MethodNotAllowed(HTTPException):
    def __init__(self, detail: str = "Method Not Allowed"):
        super().__init__(405, detail)


class UnprocessableEntity(HTTPException):
    def __init__(self, detail: str = "Unprocessable Entity"):
        super().__init__(422, detail)


class InternalServerError(HTTPException):
    def __init__(self, detail: str = "Internal Server Error"):
        super().__init__(500, detail)
