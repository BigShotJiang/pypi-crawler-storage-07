"""
PyStak Middleware System

Advanced middleware with:
- Request/response processing
- Exception handling
- Performance monitoring
- Security features
- Custom middleware support
"""

import time
import logging
from typing import Any, Callable, List, Optional, Type
from abc import ABC, abstractmethod
from dataclasses import dataclass

from .request import Request
from .response import Response, JSONResponse
from .exceptions import HTTPException


class Middleware(ABC):
    """Base middleware class"""
    
    @abstractmethod
    async def process_request(self, request: Request, call_next: Callable) -> Response:
        """Process request and call next middleware"""
        pass


class MiddlewareStack:
    """Middleware execution stack"""
    
    def __init__(self):
        self.middleware_classes: List[Type[Middleware]] = []
        self._middleware_instances: List[Middleware] = []
    
    def add(self, middleware_class: Type[Middleware]):
        """Add middleware to stack"""
        self.middleware_classes.append(middleware_class)
        self._middleware_instances.append(middleware_class())
    
    async def process(self, request: Request, final_handler: Callable) -> Response:
        """Process request through middleware stack"""
        if not self._middleware_instances:
            return await final_handler(request)
        
        # Create middleware chain
        async def create_chain(index: int):
            if index >= len(self._middleware_instances):
                return await final_handler(request)
            
            middleware = self._middleware_instances[index]
            
            async def call_next():
                return await create_chain(index + 1)
            
            return await middleware.process_request(request, call_next)
        
        return await create_chain(0)


# Built-in Middleware Classes

class CORSMiddleware(Middleware):
    """CORS (Cross-Origin Resource Sharing) middleware"""
    
    def __init__(
        self,
        allow_origins: List[str] = None,
        allow_methods: List[str] = None,
        allow_headers: List[str] = None,
        allow_credentials: bool = False,
        max_age: int = 86400
    ):
        self.allow_origins = allow_origins or ["*"]
        self.allow_methods = allow_methods or ["GET", "POST", "PUT", "DELETE", "OPTIONS"]
        self.allow_headers = allow_headers or ["*"]
        self.allow_credentials = allow_credentials
        self.max_age = max_age
    
    async def process_request(self, request: Request, call_next: Callable) -> Response:
        origin = request.get_header('origin')
        
        # Handle preflight requests
        if request.method == "OPTIONS":
            response = Response("", status_code=200)
            self._add_cors_headers(response, origin)
            return response
        
        # Process request
        response = await call_next()
        self._add_cors_headers(response, origin)
        return response
    
    def _add_cors_headers(self, response: Response, origin: Optional[str]):
        """Add CORS headers to response"""
        if self._is_origin_allowed(origin):
            response.set_header('access-control-allow-origin', origin or '*')
        
        response.set_header('access-control-allow-methods', ', '.join(self.allow_methods))
        response.set_header('access-control-allow-headers', ', '.join(self.allow_headers))
        response.set_header('access-control-max-age', str(self.max_age))
        
        if self.allow_credentials:
            response.set_header('access-control-allow-credentials', 'true')
    
    def _is_origin_allowed(self, origin: Optional[str]) -> bool:
        """Check if origin is allowed"""
        if not origin:
            return True
        
        if "*" in self.allow_origins:
            return True
        
        return origin in self.allow_origins


class SecurityHeadersMiddleware(Middleware):
    """Security headers middleware"""
    
    def __init__(
        self,
        content_security_policy: Optional[str] = None,
        x_frame_options: str = "DENY",
        x_content_type_options: str = "nosniff",
        x_xss_protection: str = "1; mode=block",
        referrer_policy: str = "strict-origin-when-cross-origin",
        hsts_max_age: Optional[int] = 31536000  # 1 year
    ):
        self.content_security_policy = content_security_policy
        self.x_frame_options = x_frame_options
        self.x_content_type_options = x_content_type_options
        self.x_xss_protection = x_xss_protection
        self.referrer_policy = referrer_policy
        self.hsts_max_age = hsts_max_age
    
    async def process_request(self, request: Request, call_next: Callable) -> Response:
        response = await call_next()
        
        # Add security headers
        if self.content_security_policy:
            response.set_header('content-security-policy', self.content_security_policy)
        
        response.set_header('x-frame-options', self.x_frame_options)
        response.set_header('x-content-type-options', self.x_content_type_options)
        response.set_header('x-xss-protection', self.x_xss_protection)
        response.set_header('referrer-policy', self.referrer_policy)
        
        # Add HSTS for HTTPS
        if request.scope.get('scheme') == 'https' and self.hsts_max_age:
            response.set_header(
                'strict-transport-security',
                f'max-age={self.hsts_max_age}; includeSubDomains'
            )
        
        return response


class RequestLoggingMiddleware(Middleware):
    """Request logging middleware"""
    
    def __init__(self, logger: Optional[logging.Logger] = None):
        self.logger = logger or logging.getLogger('pystak.requests')
    
    async def process_request(self, request: Request, call_next: Callable) -> Response:
        start_time = time.time()
        
        # Log request
        self.logger.info(
            f"Request started: {request.method} {request.path} "
            f"from {request.client_ip}"
        )
        
        try:
            response = await call_next()
            duration = time.time() - start_time
            
            # Log response
            self.logger.info(
                f"Request completed: {request.method} {request.path} "
                f"-> {response.status_code} in {duration:.3f}s"
            )
            
            return response
        
        except Exception as e:
            duration = time.time() - start_time
            
            # Log error
            self.logger.error(
                f"Request failed: {request.method} {request.path} "
                f"-> {type(e).__name__}: {str(e)} in {duration:.3f}s"
            )
            
            raise


class RateLimitMiddleware(Middleware):
    """Rate limiting middleware"""
    
    def __init__(
        self,
        requests_per_minute: int = 60,
        requests_per_hour: int = 1000,
        key_func: Optional[Callable[[Request], str]] = None
    ):
        self.requests_per_minute = requests_per_minute
        self.requests_per_hour = requests_per_hour
        self.key_func = key_func or self._default_key_func
        self.request_counts = {}  # In production, use Redis or similar
    
    def _default_key_func(self, request: Request) -> str:
        """Default key function using client IP"""
        return request.client_ip or "unknown"
    
    async def process_request(self, request: Request, call_next: Callable) -> Response:
        key = self.key_func(request)
        current_time = time.time()
        
        # Clean old entries (simplified - in production use proper cleanup)
        self._cleanup_old_entries(current_time)
        
        # Check rate limits
        if self._is_rate_limited(key, current_time):
            return JSONResponse(
                {"error": "Rate limit exceeded"},
                status_code=429
            )
        
        # Record request
        self._record_request(key, current_time)
        
        return await call_next()
    
    def _cleanup_old_entries(self, current_time: float):
        """Clean entries older than 1 hour"""
        cutoff = current_time - 3600  # 1 hour
        keys_to_remove = []
        
        for key, timestamps in self.request_counts.items():
            self.request_counts[key] = [ts for ts in timestamps if ts > cutoff]
            if not self.request_counts[key]:
                keys_to_remove.append(key)
        
        for key in keys_to_remove:
            del self.request_counts[key]
    
    def _is_rate_limited(self, key: str, current_time: float) -> bool:
        """Check if request should be rate limited"""
        if key not in self.request_counts:
            return False
        
        timestamps = self.request_counts[key]
        
        # Check per-minute limit
        minute_ago = current_time - 60
        recent_requests = len([ts for ts in timestamps if ts > minute_ago])
        if recent_requests >= self.requests_per_minute:
            return True
        
        # Check per-hour limit
        hour_ago = current_time - 3600
        hourly_requests = len([ts for ts in timestamps if ts > hour_ago])
        if hourly_requests >= self.requests_per_hour:
            return True
        
        return False
    
    def _record_request(self, key: str, current_time: float):
        """Record a request timestamp"""
        if key not in self.request_counts:
            self.request_counts[key] = []
        
        self.request_counts[key].append(current_time)


class CompressionMiddleware(Middleware):
    """Response compression middleware"""
    
    def __init__(self, minimum_size: int = 1024):
        self.minimum_size = minimum_size
    
    async def process_request(self, request: Request, call_next: Callable) -> Response:
        response = await call_next()
        
        # Check if client accepts compression
        accept_encoding = request.get_header('accept-encoding', '')
        if 'gzip' not in accept_encoding.lower():
            return response
        
        # Check if response is large enough to compress
        content = response.content
        if isinstance(content, str):
            content = content.encode('utf-8')
        
        if len(content) < self.minimum_size:
            return response
        
        # Check content type (only compress text-based content)
        content_type = response.headers.get('content-type', '')
        compressible_types = [
            'text/', 'application/json', 'application/javascript',
            'application/xml', 'application/rss+xml'
        ]
        
        if not any(ct in content_type for ct in compressible_types):
            return response
        
        # Compress content
        import gzip
        compressed_content = gzip.compress(content)
        
        # Update response
        response.content = compressed_content
        response.set_header('content-encoding', 'gzip')
        response.set_header('content-length', str(len(compressed_content)))
        
        return response


class ExceptionHandlingMiddleware(Middleware):
    """Global exception handling middleware"""
    
    def __init__(self, debug: bool = False):
        self.debug = debug
        self.logger = logging.getLogger('pystak.exceptions')
    
    async def process_request(self, request: Request, call_next: Callable) -> Response:
        try:
            return await call_next()
        
        except HTTPException as e:
            # HTTP exceptions are handled by the app
            raise
        
        except Exception as e:
            # Log the exception
            self.logger.exception(f"Unhandled exception in {request.method} {request.path}")
            
            if self.debug:
                # Return detailed error in debug mode
                import traceback
                return JSONResponse(
                    {
                        "error": str(e),
                        "type": type(e).__name__,
                        "traceback": traceback.format_exc()
                    },
                    status_code=500
                )
            else:
                # Return generic error in production
                return JSONResponse(
                    {"error": "Internal Server Error"},
                    status_code=500
                )
