"""
PyStak Validation System

Advanced validation with:
- Type validation
- Custom validators
- Schema validation
- Automatic request validation
- Serialization support
"""

import re
import inspect
from typing import Any, Callable, Dict, List, Optional, Type, TypeVar, Union, get_type_hints
from dataclasses import dataclass, field, fields, MISSING
from abc import ABC, abstractmethod
from datetime import datetime, date
from uuid import UUID

from .exceptions import ValidationError


T = TypeVar('T')


class Validator(ABC):
    """Base validator class"""
    
    @abstractmethod
    def validate(self, value: Any, field_name: str = "") -> Any:
        """Validate value and return processed value"""
        pass
    
    @abstractmethod
    def get_error_message(self, field_name: str) -> str:
        """Get validation error message"""
        pass


class RequiredValidator(Validator):
    """Validates that value is not None or empty"""
    
    def validate(self, value: Any, field_name: str = "") -> Any:
        if value is None or (isinstance(value, (str, list, dict)) and len(value) == 0):
            raise ValidationError(self.get_error_message(field_name), field_name, value)
        return value
    
    def get_error_message(self, field_name: str) -> str:
        return f"{field_name} is required"


class TypeValidator(Validator):
    """Validates value type"""
    
    def __init__(self, expected_type: Type):
        self.expected_type = expected_type
    
    def validate(self, value: Any, field_name: str = "") -> Any:
        if value is None:
            return value
        
        # Handle special types
        if self.expected_type == str:
            return str(value)
        elif self.expected_type == int:
            try:
                return int(value)
            except (ValueError, TypeError):
                raise ValidationError(self.get_error_message(field_name), field_name, value)
        elif self.expected_type == float:
            try:
                return float(value)
            except (ValueError, TypeError):
                raise ValidationError(self.get_error_message(field_name), field_name, value)
        elif self.expected_type == bool:
            if isinstance(value, str):
                return value.lower() in ('true', '1', 'yes', 'on')
            return bool(value)
        elif self.expected_type == datetime:
            if isinstance(value, str):
                try:
                    return datetime.fromisoformat(value.replace('Z', '+00:00'))
                except ValueError:
                    raise ValidationError(self.get_error_message(field_name), field_name, value)
            return value
        elif self.expected_type == date:
            if isinstance(value, str):
                try:
                    return datetime.fromisoformat(value).date()
                except ValueError:
                    raise ValidationError(self.get_error_message(field_name), field_name, value)
            return value
        elif self.expected_type == UUID:
            if isinstance(value, str):
                try:
                    return UUID(value)
                except ValueError:
                    raise ValidationError(self.get_error_message(field_name), field_name, value)
            return value
        
        # Check if value is instance of expected type
        if not isinstance(value, self.expected_type):
            raise ValidationError(self.get_error_message(field_name), field_name, value)
        
        return value
    
    def get_error_message(self, field_name: str) -> str:
        return f"{field_name} must be of type {self.expected_type.__name__}"


class LengthValidator(Validator):
    """Validates string/list length"""
    
    def __init__(self, min_length: Optional[int] = None, max_length: Optional[int] = None):
        self.min_length = min_length
        self.max_length = max_length
    
    def validate(self, value: Any, field_name: str = "") -> Any:
        if value is None:
            return value
        
        if not hasattr(value, '__len__'):
            raise ValidationError(f"{field_name} must have length", field_name, value)
        
        length = len(value)
        
        if self.min_length is not None and length < self.min_length:
            raise ValidationError(self.get_error_message(field_name), field_name, value)
        
        if self.max_length is not None and length > self.max_length:
            raise ValidationError(self.get_error_message(field_name), field_name, value)
        
        return value
    
    def get_error_message(self, field_name: str) -> str:
        if self.min_length is not None and self.max_length is not None:
            return f"{field_name} must be between {self.min_length} and {self.max_length} characters"
        elif self.min_length is not None:
            return f"{field_name} must be at least {self.min_length} characters"
        elif self.max_length is not None:
            return f"{field_name} must be at most {self.max_length} characters"
        return f"{field_name} length validation failed"


class RangeValidator(Validator):
    """Validates numeric range"""
    
    def __init__(self, min_value: Optional[Union[int, float]] = None, max_value: Optional[Union[int, float]] = None):
        self.min_value = min_value
        self.max_value = max_value
    
    def validate(self, value: Any, field_name: str = "") -> Any:
        if value is None:
            return value
        
        if not isinstance(value, (int, float)):
            raise ValidationError(f"{field_name} must be numeric", field_name, value)
        
        if self.min_value is not None and value < self.min_value:
            raise ValidationError(self.get_error_message(field_name), field_name, value)
        
        if self.max_value is not None and value > self.max_value:
            raise ValidationError(self.get_error_message(field_name), field_name, value)
        
        return value
    
    def get_error_message(self, field_name: str) -> str:
        if self.min_value is not None and self.max_value is not None:
            return f"{field_name} must be between {self.min_value} and {self.max_value}"
        elif self.min_value is not None:
            return f"{field_name} must be at least {self.min_value}"
        elif self.max_value is not None:
            return f"{field_name} must be at most {self.max_value}"
        return f"{field_name} range validation failed"


class RegexValidator(Validator):
    """Validates value against regex pattern"""
    
    def __init__(self, pattern: str, flags: int = 0):
        self.pattern = re.compile(pattern, flags)
        self.pattern_str = pattern
    
    def validate(self, value: Any, field_name: str = "") -> Any:
        if value is None:
            return value
        
        if not isinstance(value, str):
            value = str(value)
        
        if not self.pattern.match(value):
            raise ValidationError(self.get_error_message(field_name), field_name, value)
        
        return value
    
    def get_error_message(self, field_name: str) -> str:
        return f"{field_name} does not match required pattern"


class EmailValidator(RegexValidator):
    """Email validation"""
    
    def __init__(self):
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        super().__init__(email_pattern)
    
    def get_error_message(self, field_name: str) -> str:
        return f"{field_name} must be a valid email address"


class URLValidator(RegexValidator):
    """URL validation"""
    
    def __init__(self):
        url_pattern = r'^https?://(?:[-\w.])+(?:[:\d]+)?(?:/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:\w*))?)?$'
        super().__init__(url_pattern)
    
    def get_error_message(self, field_name: str) -> str:
        return f"{field_name} must be a valid URL"


class ChoiceValidator(Validator):
    """Validates value is in allowed choices"""
    
    def __init__(self, choices: List[Any]):
        self.choices = choices
    
    def validate(self, value: Any, field_name: str = "") -> Any:
        if value is None:
            return value
        
        if value not in self.choices:
            raise ValidationError(self.get_error_message(field_name), field_name, value)
        
        return value
    
    def get_error_message(self, field_name: str) -> str:
        return f"{field_name} must be one of: {', '.join(map(str, self.choices))}"


class CustomValidator(Validator):
    """Custom validation function"""
    
    def __init__(self, validator_func: Callable[[Any], bool], error_message: str):
        self.validator_func = validator_func
        self.error_message = error_message
    
    def validate(self, value: Any, field_name: str = "") -> Any:
        if value is None:
            return value
        
        if not self.validator_func(value):
            raise ValidationError(self.get_error_message(field_name), field_name, value)
        
        return value
    
    def get_error_message(self, field_name: str) -> str:
        return self.error_message.format(field_name=field_name)


@dataclass
class FieldValidator:
    """Field validation configuration"""
    validators: List[Validator] = field(default_factory=list)
    required: bool = False
    default: Any = None
    
    def validate(self, value: Any, field_name: str) -> Any:
        """Validate field value"""
        # Handle default values
        if value is None and self.default is not None:
            value = self.default
        
        # Check required
        if self.required:
            RequiredValidator().validate(value, field_name)
        
        # Apply validators
        for validator in self.validators:
            value = validator.validate(value, field_name)
        
        return value


class Schema:
    """
    Schema validation for complex data structures.
    
    Usage:
    schema = Schema({
        'name': FieldValidator([TypeValidator(str), LengthValidator(min_length=1)], required=True),
        'email': FieldValidator([EmailValidator()], required=True),
        'age': FieldValidator([TypeValidator(int), RangeValidator(min_value=0, max_value=150)])
    })
    """
    
    def __init__(self, fields: Dict[str, FieldValidator]):
        self.fields = fields
    
    def validate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Validate data against schema"""
        validated_data = {}
        errors = {}
        
        # Validate each field
        for field_name, field_validator in self.fields.items():
            try:
                value = data.get(field_name)
                validated_data[field_name] = field_validator.validate(value, field_name)
            except ValidationError as e:
                errors[field_name] = e.message
        
        # Check for unknown fields
        unknown_fields = set(data.keys()) - set(self.fields.keys())
        if unknown_fields:
            for field in unknown_fields:
                errors[field] = f"Unknown field: {field}"
        
        if errors:
            raise ValidationError(f"Validation failed: {errors}")
        
        return validated_data


def validate_dataclass(cls: Type[T], data: Dict[str, Any]) -> T:
    """
    Validate data against dataclass and create instance.
    
    Usage:
    @dataclass
    class User:
        name: str
        email: str
        age: int = 0
    
    user = validate_dataclass(User, {'name': 'John', 'email': 'john@example.com'})
    """
    if not hasattr(cls, '__dataclass_fields__'):
        raise ValidationError(f"{cls.__name__} is not a dataclass")
    
    validated_data = {}
    errors = {}
    type_hints = get_type_hints(cls)
    
    for field in fields(cls):
        field_name = field.name
        field_type = type_hints.get(field_name, Any)
        value = data.get(field_name, field.default if field.default != MISSING else None)
        
        try:
            # Type validation
            if field_type != Any:
                validator = TypeValidator(field_type)
                value = validator.validate(value, field_name)
            
            # Required validation
            if field.default == MISSING and value is None:
                raise ValidationError(f"{field_name} is required", field_name, value)
            
            validated_data[field_name] = value
        
        except ValidationError as e:
            errors[field_name] = e.message
    
    if errors:
        raise ValidationError(f"Validation failed: {errors}")
    
    return cls(**validated_data)


def validate(schema: Union[Schema, Type], data: Dict[str, Any]) -> Union[Dict[str, Any], Any]:
    """
    Validate data against schema or dataclass.
    
    Usage:
    # With Schema
    result = validate(my_schema, data)
    
    # With dataclass
    user = validate(User, data)
    """
    if isinstance(schema, Schema):
        return schema.validate(data)
    elif hasattr(schema, '__dataclass_fields__'):
        return validate_dataclass(schema, data)
    else:
        raise ValidationError(f"Invalid schema type: {type(schema)}")


# Validation decorators
def validate_json(schema: Union[Schema, Type]):
    """Decorator to validate JSON request body"""
    def decorator(func):
        async def wrapper(*args, **kwargs):
            # Find request parameter
            request = None
            for arg in args:
                if hasattr(arg, 'json'):  # Duck typing for Request
                    request = arg
                    break
            
            if request:
                try:
                    json_data = await request.json()
                    validated_data = validate(schema, json_data)
                    
                    # Add validated data to kwargs
                    kwargs['validated_data'] = validated_data
                except ValidationError as e:
                    from .exceptions import UnprocessableEntity
                    raise UnprocessableEntity(str(e))
            
            if inspect.iscoroutinefunction(func):
                return await func(*args, **kwargs)
            else:
                return func(*args, **kwargs)
        
        return wrapper
    return decorator


def validate_query(schema: Union[Schema, Type]):
    """Decorator to validate query parameters"""
    def decorator(func):
        async def wrapper(*args, **kwargs):
            # Find request parameter
            request = None
            for arg in args:
                if hasattr(arg, 'query_params'):  # Duck typing for Request
                    request = arg
                    break
            
            if request:
                try:
                    validated_data = validate(schema, dict(request.query_params))
                    kwargs['validated_query'] = validated_data
                except ValidationError as e:
                    from .exceptions import BadRequest
                    raise BadRequest(str(e))
            
            if inspect.iscoroutinefunction(func):
                return await func(*args, **kwargs)
            else:
                return func(*args, **kwargs)
        
        return wrapper
    return decorator
