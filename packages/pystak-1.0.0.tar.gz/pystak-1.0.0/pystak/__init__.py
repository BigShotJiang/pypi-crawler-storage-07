"""
PyStak - A Modern Python Web Framework

A high-performance, async-first web framework with advanced features:
- Dependency Injection
- Middleware System
- Type Safety
- Auto-validation
- Built-in Security
- Performance Monitoring
"""

__version__ = "1.0.0"
__author__ = "PyStak Team"

from .app import PyStak
from .routing import Router, route
from .request import Request
from .response import Response, JSONResponse, HTMLResponse
from .middleware import Middleware
from .dependency import Depends, Injectable
from .exceptions import PyStakException, HTTPException
from .config import Config
from .validation import validate, validate_json, validate_query, Schema

__all__ = [
    "PyStak",
    "Router", 
    "route",
    "Request",
    "Response",
    "JSONResponse", 
    "HTMLResponse",
    "Middleware",
    "Depends",
    "Injectable",
    "PyStakException",
    "HTTPException", 
    "Config",
    "validate",
    "validate_json",
    "validate_query",
    "Schema"
]
