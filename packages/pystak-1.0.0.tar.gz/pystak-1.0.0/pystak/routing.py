"""
PyStak Routing System

Advanced routing with path parameters, type conversion, and pattern matching.
"""

import re
import inspect
from typing import Any, Callable, Dict, List, Optional, Tuple, Type, Union
from dataclasses import dataclass
from functools import wraps


@dataclass
class Route:
    """Route definition"""
    path: str
    methods: List[str]
    handler: Callable
    name: Optional[str] = None
    middleware: List[Type] = None
    
    def __post_init__(self):
        if self.middleware is None:
            self.middleware = []


class PathConverter:
    """Base path parameter converter"""
    regex = r'[^/]+'
    
    def convert(self, value: str) -> Any:
        return value
    
    def to_url(self, value: Any) -> str:
        return str(value)


class IntConverter(PathConverter):
    """Integer path parameter converter"""
    regex = r'\d+'
    
    def convert(self, value: str) -> int:
        return int(value)


class FloatConverter(PathConverter):
    """Float path parameter converter"""
    regex = r'\d+(\.\d+)?'
    
    def convert(self, value: str) -> float:
        return float(value)


class UUIDConverter(PathConverter):
    """UUID path parameter converter"""
    regex = r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}'
    
    def convert(self, value: str) -> str:
        import uuid
        return str(uuid.UUID(value))


class SlugConverter(PathConverter):
    """Slug path parameter converter"""
    regex = r'[-a-zA-Z0-9_]+'


class Router:
    """
    Advanced routing system with:
    - Path parameters with type conversion
    - Route groups/prefixes
    - Middleware per route
    - Named routes for URL generation
    """
    
    def __init__(self, prefix: str = ""):
        self.prefix = prefix.rstrip('/')
        self.routes: List[Route] = []
        self.converters = {
            'str': PathConverter(),
            'int': IntConverter(), 
            'float': FloatConverter(),
            'uuid': UUIDConverter(),
            'slug': SlugConverter(),
        }
        self._compiled_routes: List[Tuple[re.Pattern, Route, List[str]]] = []
        self._routes_compiled = False
    
    def add_converter(self, name: str, converter: PathConverter):
        """Add custom path converter"""
        self.converters[name] = converter
    
    def route(self, path: str, methods: List[str], name: Optional[str] = None, middleware: List[Type] = None):
        """Route decorator"""
        def decorator(func: Callable):
            self.add_route(path, methods, func, name, middleware)
            return func
        return decorator
    
    def add_route(self, path: str, methods: List[str], handler: Callable, 
                  name: Optional[str] = None, middleware: List[Type] = None):
        """Add route to router"""
        full_path = self.prefix + path if path != '/' else self.prefix or '/'
        route = Route(full_path, methods, handler, name, middleware or [])
        self.routes.append(route)
        self._routes_compiled = False
    
    def group(self, prefix: str, middleware: List[Type] = None):
        """Create route group with prefix and middleware"""
        return RouteGroup(self, prefix, middleware or [])
    
    def include_router(self, router: 'Router', prefix: str = "", middleware: List[Type] = None):
        """Include another router"""
        for route in router.routes:
            new_path = prefix + route.path if prefix else route.path
            new_middleware = (middleware or []) + route.middleware
            self.add_route(new_path, route.methods, route.handler, route.name, new_middleware)
    
    def _compile_routes(self):
        """Compile routes for efficient matching"""
        if self._routes_compiled:
            return
            
        self._compiled_routes = []
        for route in self.routes:
            pattern, param_names = self._compile_path(route.path)
            self._compiled_routes.append((pattern, route, param_names))
        
        self._routes_compiled = True
    
    def _compile_path(self, path: str) -> Tuple[re.Pattern, List[str]]:
        """Compile path pattern with parameter extraction"""
        param_names = []
        pattern = path
        
        # Find all path parameters: <name> or <converter:name>
        param_regex = r'<(?:([^:>]+):)?([^>]+)>'
        
        def replace_param(match):
            converter_name = match.group(1) or 'str'
            param_name = match.group(2)
            param_names.append(param_name)
            
            converter = self.converters.get(converter_name, self.converters['str'])
            return f'({converter.regex})'
        
        pattern = re.sub(param_regex, replace_param, pattern)
        pattern = f'^{pattern}$'
        
        return re.compile(pattern), param_names
    
    def match(self, path: str, method: str) -> Optional[Tuple[Callable, Dict[str, Any]]]:
        """Match path and method to route"""
        self._compile_routes()
        
        for pattern, route, param_names in self._compiled_routes:
            if method not in route.methods:
                continue
                
            match = pattern.match(path)
            if match:
                # Extract and convert path parameters
                path_params = {}
                for i, param_name in enumerate(param_names):
                    raw_value = match.group(i + 1)
                    # Find converter for this parameter
                    converter_name = self._get_converter_for_param(route.path, param_name)
                    converter = self.converters[converter_name]
                    path_params[param_name] = converter.convert(raw_value)
                
                return route.handler, path_params
        
        return None
    
    def _get_converter_for_param(self, path: str, param_name: str) -> str:
        """Get converter name for parameter"""
        param_regex = r'<(?:([^:>]+):)?([^>]+)>'
        for match in re.finditer(param_regex, path):
            if match.group(2) == param_name:
                return match.group(1) or 'str'
        return 'str'
    
    def url_for(self, name: str, **params) -> str:
        """Generate URL for named route"""
        for route in self.routes:
            if route.name == name:
                return self._build_url(route.path, params)
        raise ValueError(f"No route named '{name}'")
    
    def _build_url(self, path: str, params: Dict[str, Any]) -> str:
        """Build URL from path template and parameters"""
        def replace_param(match):
            converter_name = match.group(1) or 'str'
            param_name = match.group(2)
            
            if param_name not in params:
                raise ValueError(f"Missing parameter '{param_name}'")
            
            converter = self.converters[converter_name]
            return converter.to_url(params[param_name])
        
        param_regex = r'<(?:([^:>]+):)?([^>]+)>'
        return re.sub(param_regex, replace_param, path)


class RouteGroup:
    """Route group for organizing routes with common prefix/middleware"""
    
    def __init__(self, router: Router, prefix: str, middleware: List[Type]):
        self.router = router
        self.prefix = prefix.rstrip('/')
        self.middleware = middleware
    
    def route(self, path: str, methods: List[str], name: Optional[str] = None, middleware: List[Type] = None):
        """Add route to group"""
        def decorator(func: Callable):
            full_path = self.prefix + path
            combined_middleware = self.middleware + (middleware or [])
            self.router.add_route(full_path, methods, func, name, combined_middleware)
            return func
        return decorator
    
    def get(self, path: str, **kwargs):
        return self.route(path, ["GET"], **kwargs)
    
    def post(self, path: str, **kwargs):
        return self.route(path, ["POST"], **kwargs)
    
    def put(self, path: str, **kwargs):
        return self.route(path, ["PUT"], **kwargs)
    
    def delete(self, path: str, **kwargs):
        return self.route(path, ["DELETE"], **kwargs)
    
    def patch(self, path: str, **kwargs):
        return self.route(path, ["PATCH"], **kwargs)


# Convenience function for standalone route decoration
def route(path: str, methods: List[str] = None, **kwargs):
    """Standalone route decorator"""
    methods = methods or ["GET"]
    
    def decorator(func: Callable):
        # Store route info on function for later registration
        func.__pystak_route__ = {
            'path': path,
            'methods': methods,
            **kwargs
        }
        return func
    return decorator
