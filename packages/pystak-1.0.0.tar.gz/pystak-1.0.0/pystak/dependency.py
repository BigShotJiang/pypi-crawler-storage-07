"""
PyStak Dependency Injection System

Advanced dependency injection with:
- Automatic dependency resolution
- Singleton and transient lifetimes
- Factory functions
- Interface binding
- Circular dependency detection
"""

import inspect
from typing import Any, Callable, Dict, List, Optional, Type, TypeVar, Union, get_type_hints
from enum import Enum
from dataclasses import dataclass
from functools import wraps


class Lifetime(Enum):
    """Dependency lifetime management"""
    TRANSIENT = "transient"  # New instance every time
    SINGLETON = "singleton"  # Single instance for app lifetime
    SCOPED = "scoped"        # Single instance per request


@dataclass
class DependencyBinding:
    """Dependency binding configuration"""
    implementation: Union[Type, Callable]
    lifetime: Lifetime = Lifetime.TRANSIENT
    factory: Optional[Callable] = None
    instance: Optional[Any] = None


T = TypeVar('T')


class DependencyContainer:
    """
    Advanced dependency injection container with:
    - Automatic constructor injection
    - Interface to implementation binding
    - Lifetime management
    - Circular dependency detection
    """
    
    def __init__(self):
        self._bindings: Dict[Type, DependencyBinding] = {}
        self._singletons: Dict[Type, Any] = {}
        self._resolution_stack: List[Type] = []
    
    def register(
        self,
        interface: Type[T],
        implementation: Optional[Union[Type[T], Callable[[], T]]] = None,
        lifetime: Lifetime = Lifetime.TRANSIENT,
        factory: Optional[Callable] = None
    ) -> Type[T]:
        """Register a dependency"""
        impl = implementation or interface
        
        self._bindings[interface] = DependencyBinding(
            implementation=impl,
            lifetime=lifetime,
            factory=factory
        )
        
        return interface
    
    def register_singleton(self, interface: Type[T], implementation: Optional[Type[T]] = None) -> Type[T]:
        """Register as singleton"""
        return self.register(interface, implementation, Lifetime.SINGLETON)
    
    def register_scoped(self, interface: Type[T], implementation: Optional[Type[T]] = None) -> Type[T]:
        """Register as scoped (per request)"""
        return self.register(interface, implementation, Lifetime.SCOPED)
    
    def register_factory(self, interface: Type[T], factory: Callable[[], T]) -> Type[T]:
        """Register with factory function"""
        return self.register(interface, factory, factory=factory)
    
    def register_instance(self, interface: Type[T], instance: T) -> Type[T]:
        """Register existing instance"""
        binding = DependencyBinding(
            implementation=type(instance),
            lifetime=Lifetime.SINGLETON,
            instance=instance
        )
        self._bindings[interface] = binding
        self._singletons[interface] = instance
        return interface
    
    async def resolve(self, interface: Type[T], request=None) -> T:
        """Resolve dependency with all its dependencies"""
        # Check for circular dependencies
        if interface in self._resolution_stack:
            cycle = " -> ".join([cls.__name__ for cls in self._resolution_stack])
            cycle += f" -> {interface.__name__}"
            raise DependencyError(f"Circular dependency detected: {cycle}")
        
        self._resolution_stack.append(interface)
        
        try:
            return await self._resolve_internal(interface, request)
        finally:
            self._resolution_stack.pop()
    
    async def _resolve_internal(self, interface: Type[T], request=None) -> T:
        """Internal resolution logic"""
        binding = self._bindings.get(interface)
        
        if not binding:
            # Try to auto-register if it's a concrete class
            if inspect.isclass(interface) and not inspect.isabstract(interface):
                self.register(interface)
                binding = self._bindings[interface]
            else:
                raise DependencyError(f"No binding registered for {interface}")
        
        # Handle different lifetimes
        if binding.lifetime == Lifetime.SINGLETON:
            if interface in self._singletons:
                return self._singletons[interface]
            
            instance = await self._create_instance(binding, request)
            self._singletons[interface] = instance
            return instance
        
        elif binding.lifetime == Lifetime.SCOPED:
            # For scoped, we'd typically store in request context
            # For now, treat as transient
            return await self._create_instance(binding, request)
        
        else:  # TRANSIENT
            return await self._create_instance(binding, request)
    
    async def _create_instance(self, binding: DependencyBinding, request=None) -> Any:
        """Create instance with dependency injection"""
        if binding.instance is not None:
            return binding.instance
        
        if binding.factory:
            # Use factory function
            if inspect.iscoroutinefunction(binding.factory):
                return await binding.factory()
            else:
                return binding.factory()
        
        implementation = binding.implementation
        
        # Get constructor parameters
        if inspect.isclass(implementation):
            constructor = implementation.__init__
            sig = inspect.signature(constructor)
            
            # Resolve constructor dependencies
            kwargs = {}
            for param_name, param in sig.parameters.items():
                if param_name == 'self':
                    continue
                
                if param.annotation != inspect.Parameter.empty:
                    # Check if it's a dependency
                    if hasattr(param.default, '__pystak_dependency__'):
                        dependency = await self.resolve(param.annotation, request)
                        kwargs[param_name] = dependency
                    elif param.annotation in self._bindings:
                        dependency = await self.resolve(param.annotation, request)
                        kwargs[param_name] = dependency
            
            return implementation(**kwargs)
        
        elif callable(implementation):
            # It's a factory function
            if inspect.iscoroutinefunction(implementation):
                return await implementation()
            else:
                return implementation()
        
        else:
            return implementation


class DependencyError(Exception):
    """Dependency injection error"""
    pass


def Depends(dependency: Optional[Callable] = None):
    """
    Dependency injection marker for function parameters.
    
    Usage:
    def handler(service: MyService = Depends()):
        return service.do_something()
    """
    def dependency_marker():
        pass
    
    dependency_marker.__pystak_dependency__ = True
    return dependency_marker


def Injectable(cls: Type[T]) -> Type[T]:
    """
    Class decorator to mark a class as injectable.
    Automatically registers the class in the container.
    """
    cls.__pystak_injectable__ = True
    return cls


# Global container instance
_container = DependencyContainer()


def get_container() -> DependencyContainer:
    """Get the global dependency container"""
    return _container


def register(
    interface: Type[T],
    implementation: Optional[Type[T]] = None,
    lifetime: Lifetime = Lifetime.TRANSIENT
) -> Type[T]:
    """Register dependency in global container"""
    return _container.register(interface, implementation, lifetime)


def register_singleton(interface: Type[T], implementation: Optional[Type[T]] = None) -> Type[T]:
    """Register singleton in global container"""
    return _container.register_singleton(interface, implementation)


def register_scoped(interface: Type[T], implementation: Optional[Type[T]] = None) -> Type[T]:
    """Register scoped dependency in global container"""
    return _container.register_scoped(interface, implementation)


def register_factory(interface: Type[T], factory: Callable[[], T]) -> Type[T]:
    """Register factory in global container"""
    return _container.register_factory(interface, factory)


def register_instance(interface: Type[T], instance: T) -> Type[T]:
    """Register instance in global container"""
    return _container.register_instance(interface, instance)


async def resolve(interface: Type[T], request=None) -> T:
    """Resolve dependency from global container"""
    return await _container.resolve(interface, request)


# Decorator for automatic dependency injection
def inject(func: Callable) -> Callable:
    """
    Decorator to automatically inject dependencies into function parameters.
    
    Usage:
    @inject
    def my_function(service: MyService = Depends()):
        return service.do_something()
    """
    sig = inspect.signature(func)
    
    @wraps(func)
    async def wrapper(*args, **kwargs):
        # Resolve dependencies
        for param_name, param in sig.parameters.items():
            if param_name not in kwargs and hasattr(param.default, '__pystak_dependency__'):
                if param.annotation != inspect.Parameter.empty:
                    dependency = await resolve(param.annotation)
                    kwargs[param_name] = dependency
        
        # Call original function
        if inspect.iscoroutinefunction(func):
            return await func(*args, **kwargs)
        else:
            return func(*args, **kwargs)
    
    return wrapper
