"""
PyStak CLI Tools

Command-line interface for project scaffolding and management.
"""

import os
import sys
import argparse
from pathlib import Path
from typing import Dict, List, Optional


class PyStakCLI:
    """PyStak command-line interface"""
    
    def __init__(self):
        self.parser = self._create_parser()
    
    def _create_parser(self) -> argparse.ArgumentParser:
        """Create argument parser"""
        parser = argparse.ArgumentParser(
            prog='pystak',
            description='PyStak - Modern Python Web Framework CLI'
        )
        
        subparsers = parser.add_subparsers(dest='command', help='Available commands')
        
        # New project command
        new_parser = subparsers.add_parser('new', help='Create new PyStak project')
        new_parser.add_argument('name', help='Project name')
        new_parser.add_argument('--template', choices=['basic', 'api', 'full'], 
                               default='basic', help='Project template')
        
        # Run command
        run_parser = subparsers.add_parser('run', help='Run development server')
        run_parser.add_argument('--host', default='127.0.0.1', help='Host to bind to')
        run_parser.add_argument('--port', type=int, default=8000, help='Port to bind to')
        run_parser.add_argument('--reload', action='store_true', help='Enable auto-reload')
        run_parser.add_argument('--debug', action='store_true', help='Enable debug mode')
        
        # Generate command
        gen_parser = subparsers.add_parser('generate', help='Generate code')
        gen_subparsers = gen_parser.add_subparsers(dest='generate_type')
        
        # Generate route
        route_parser = gen_subparsers.add_parser('route', help='Generate route')
        route_parser.add_argument('path', help='Route path (e.g., /users/<int:id>)')
        route_parser.add_argument('--methods', nargs='+', default=['GET'], 
                                 help='HTTP methods')
        route_parser.add_argument('--name', help='Route name')
        
        # Generate middleware
        middleware_parser = gen_subparsers.add_parser('middleware', help='Generate middleware')
        middleware_parser.add_argument('name', help='Middleware name')
        
        # Generate model
        model_parser = gen_subparsers.add_parser('model', help='Generate model')
        model_parser.add_argument('name', help='Model name')
        model_parser.add_argument('--fields', nargs='+', help='Model fields (name:type)')
        
        return parser
    
    def run(self, args: Optional[List[str]] = None):
        """Run CLI with given arguments"""
        parsed_args = self.parser.parse_args(args)
        
        if not parsed_args.command:
            self.parser.print_help()
            return
        
        try:
            if parsed_args.command == 'new':
                self._create_project(parsed_args.name, parsed_args.template)
            elif parsed_args.command == 'run':
                self._run_server(parsed_args)
            elif parsed_args.command == 'generate':
                self._generate_code(parsed_args)
            else:
                print(f"Unknown command: {parsed_args.command}")
                sys.exit(1)
        
        except Exception as e:
            print(f"Error: {e}")
            sys.exit(1)
    
    def _create_project(self, name: str, template: str):
        """Create new PyStak project"""
        project_path = Path(name)
        
        if project_path.exists():
            raise ValueError(f"Directory '{name}' already exists")
        
        print(f"Creating PyStak project '{name}' with template '{template}'...")
        
        # Create project structure
        self._create_project_structure(project_path, template)
        
        print(f"Project '{name}' created successfully!")
        print(f"To get started:")
        print(f"  cd {name}")
        print(f"  pip install -r requirements.txt")
        print(f"  pystak run")
    
    def _create_project_structure(self, project_path: Path, template: str):
        """Create project directory structure"""
        # Create directories
        directories = [
            project_path,
            project_path / "app",
            project_path / "app" / "routes",
            project_path / "app" / "models",
            project_path / "app" / "middleware",
            project_path / "app" / "services",
            project_path / "config",
            project_path / "tests",
            project_path / "static",
            project_path / "templates"
        ]
        
        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)
        
        # Create files based on template
        if template == 'basic':
            self._create_basic_template(project_path)
        elif template == 'api':
            self._create_api_template(project_path)
        elif template == 'full':
            self._create_full_template(project_path)
    
    def _create_basic_template(self, project_path: Path):
        """Create basic project template"""
        # Main application file
        main_py = '''from pystak import PyStak, JSONResponse

app = PyStak()

@app.get("/")
async def home():
    return {"message": "Welcome to PyStak!"}

@app.get("/health")
async def health_check():
    return {"status": "healthy"}

if __name__ == "__main__":
    app.run(debug=True)
'''
        
        # Requirements
        requirements = '''pystak>=1.0.0
uvicorn[standard]>=0.18.0
'''
        
        # README
        readme = f'''# {project_path.name}

A PyStak web application.

## Getting Started

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Run the application:
   ```bash
   python main.py
   ```

3. Visit http://localhost:8000

## Project Structure

- `main.py` - Main application file
- `app/` - Application modules
- `config/` - Configuration files
- `tests/` - Test files
- `static/` - Static files
- `templates/` - Template files
'''
        
        # Write files
        (project_path / "main.py").write_text(main_py)
        (project_path / "requirements.txt").write_text(requirements)
        (project_path / "README.md").write_text(readme)
        (project_path / "app" / "__init__.py").write_text("")
    
    def _create_api_template(self, project_path: Path):
        """Create API project template"""
        # Main application file
        main_py = '''from pystak import PyStak
from app.routes import api_router
from app.middleware.cors import setup_cors
from app.middleware.auth import setup_auth

app = PyStak()

# Setup middleware
setup_cors(app)
setup_auth(app)

# Include routes
app.router.include_router(api_router, prefix="/api/v1")

@app.get("/")
async def root():
    return {"message": "PyStak API", "version": "1.0.0"}

if __name__ == "__main__":
    app.run(debug=True)
'''
        
        # API routes
        api_routes = '''from pystak import Router, JSONResponse, Depends
from app.models.user import User
from app.services.user_service import UserService

api_router = Router()

@api_router.get("/users")
async def get_users(user_service: UserService = Depends()):
    users = await user_service.get_all()
    return {"users": users}

@api_router.post("/users")
async def create_user(user_data: dict, user_service: UserService = Depends()):
    user = await user_service.create(user_data)
    return {"user": user}

@api_router.get("/users/<int:user_id>")
async def get_user(user_id: int, user_service: UserService = Depends()):
    user = await user_service.get_by_id(user_id)
    if not user:
        return JSONResponse({"error": "User not found"}, status_code=404)
    return {"user": user}
'''
        
        # User model
        user_model = '''from dataclasses import dataclass
from typing import Optional
from datetime import datetime

@dataclass
class User:
    id: Optional[int] = None
    name: str = ""
    email: str = ""
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
'''
        
        # User service
        user_service = '''from typing import List, Optional
from pystak import Injectable
from app.models.user import User

@Injectable
class UserService:
    def __init__(self):
        # In a real app, this would be a database
        self.users = []
        self.next_id = 1
    
    async def get_all(self) -> List[User]:
        return self.users
    
    async def get_by_id(self, user_id: int) -> Optional[User]:
        return next((u for u in self.users if u.id == user_id), None)
    
    async def create(self, user_data: dict) -> User:
        user = User(
            id=self.next_id,
            name=user_data.get("name", ""),
            email=user_data.get("email", "")
        )
        self.users.append(user)
        self.next_id += 1
        return user
'''
        
        # CORS middleware
        cors_middleware = '''from pystak.middleware import CORSMiddleware

def setup_cors(app):
    app.middleware(CORSMiddleware(
        allow_origins=["*"],
        allow_methods=["GET", "POST", "PUT", "DELETE"],
        allow_headers=["*"]
    ))
'''
        
        # Auth middleware
        auth_middleware = '''from pystak import Middleware, Request, Response, HTTPException

class AuthMiddleware(Middleware):
    async def process_request(self, request: Request, call_next):
        # Skip auth for public endpoints
        if request.path in ["/", "/health"]:
            return await call_next()
        
        # Check for API key
        api_key = request.get_header("x-api-key")
        if not api_key:
            raise HTTPException(401, "API key required")
        
        # Validate API key (simplified)
        if api_key != "your-secret-key":
            raise HTTPException(401, "Invalid API key")
        
        return await call_next()

def setup_auth(app):
    app.middleware(AuthMiddleware)
'''
        
        # Requirements
        requirements = '''pystak>=1.0.0
uvicorn[standard]>=0.18.0
'''
        
        # Write files
        (project_path / "main.py").write_text(main_py)
        (project_path / "app" / "routes" / "__init__.py").write_text("")
        (project_path / "app" / "routes" / "api.py").write_text(api_routes)
        (project_path / "app" / "models" / "__init__.py").write_text("")
        (project_path / "app" / "models" / "user.py").write_text(user_model)
        (project_path / "app" / "services" / "__init__.py").write_text("")
        (project_path / "app" / "services" / "user_service.py").write_text(user_service)
        (project_path / "app" / "middleware" / "__init__.py").write_text("")
        (project_path / "app" / "middleware" / "cors.py").write_text(cors_middleware)
        (project_path / "app" / "middleware" / "auth.py").write_text(auth_middleware)
        (project_path / "requirements.txt").write_text(requirements)
        (project_path / "app" / "__init__.py").write_text("")
    
    def _create_full_template(self, project_path: Path):
        """Create full-featured project template"""
        # Start with API template
        self._create_api_template(project_path)
        
        # Add additional features for full template
        # Config file
        config_py = '''from pystak import Config

config = Config([
    "config/development.yaml",
    "config/production.yaml"
])

# Database settings
DATABASE_URL = config.get("database_url", "sqlite:///app.db")
SECRET_KEY = config.get("secret_key", "your-secret-key-here")

# Redis settings
REDIS_URL = config.get("redis_url", "redis://localhost:6379")

# Email settings
EMAIL_HOST = config.get("email_host", "localhost")
EMAIL_PORT = config.get("email_port", 587, int)
'''
        
        # Development config
        dev_config = '''database_url: "sqlite:///development.db"
secret_key: "dev-secret-key"
debug: true
redis_url: "redis://localhost:6379"
email_host: "localhost"
email_port: 1025
'''
        
        # Production config
        prod_config = '''database_url: "${DATABASE_URL}"
secret_key: "${SECRET_KEY}"
debug: false
redis_url: "${REDIS_URL}"
email_host: "${EMAIL_HOST}"
email_port: ${EMAIL_PORT}
'''
        
        # Docker files
        dockerfile = '''FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

EXPOSE 8000

CMD ["python", "main.py"]
'''
        
        docker_compose = '''version: '3.8'

services:
  app:
    build: .
    ports:
      - "8000:8000"
    environment:
      - DATABASE_URL=postgresql://user:password@db:5432/pystak_db
      - REDIS_URL=redis://redis:6379
    depends_on:
      - db
      - redis
  
  db:
    image: postgres:15
    environment:
      - POSTGRES_DB=pystak_db
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=password
    volumes:
      - postgres_data:/var/lib/postgresql/data
  
  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

volumes:
  postgres_data:
'''
        
        # Write additional files
        (project_path / "app" / "config.py").write_text(config_py)
        (project_path / "config" / "development.yaml").write_text(dev_config)
        (project_path / "config" / "production.yaml").write_text(prod_config)
        (project_path / "Dockerfile").write_text(dockerfile)
        (project_path / "docker-compose.yml").write_text(docker_compose)
    
    def _run_server(self, args):
        """Run development server"""
        try:
            import uvicorn
        except ImportError:
            raise ImportError("uvicorn is required to run the server. Install with: pip install uvicorn")
        
        # Look for main application
        app_module = "main:app"
        if not Path("main.py").exists():
            raise FileNotFoundError("main.py not found. Are you in a PyStak project directory?")
        
        uvicorn.run(
            app_module,
            host=args.host,
            port=args.port,
            reload=args.reload,
            debug=args.debug
        )
    
    def _generate_code(self, args):
        """Generate code based on type"""
        if args.generate_type == 'route':
            self._generate_route(args.path, args.methods, args.name)
        elif args.generate_type == 'middleware':
            self._generate_middleware(args.name)
        elif args.generate_type == 'model':
            self._generate_model(args.name, args.fields or [])
        else:
            print(f"Unknown generate type: {args.generate_type}")
    
    def _generate_route(self, path: str, methods: List[str], name: Optional[str]):
        """Generate route code"""
        route_name = name or path.replace('/', '_').replace('<', '').replace('>', '').strip('_')
        methods_str = ', '.join(f'"{m}"' for m in methods)
        
        route_code = f'''@app.route("{path}", methods=[{methods_str}])
async def {route_name}():
    """Generated route for {path}"""
    return {{"message": "Hello from {path}"}}
'''
        
        print("Generated route code:")
        print(route_code)
    
    def _generate_middleware(self, name: str):
        """Generate middleware code"""
        class_name = f"{name.title()}Middleware"
        
        middleware_code = f'''from pystak import Middleware, Request, Response

class {class_name}(Middleware):
    """Generated middleware: {name}"""
    
    async def process_request(self, request: Request, call_next):
        # Pre-processing
        print(f"Processing request: {{request.method}} {{request.path}}")
        
        # Call next middleware/handler
        response = await call_next()
        
        # Post-processing
        print(f"Response status: {{response.status_code}}")
        
        return response
'''
        
        print("Generated middleware code:")
        print(middleware_code)
    
    def _generate_model(self, name: str, fields: List[str]):
        """Generate model code"""
        class_name = name.title()
        
        # Parse fields
        field_definitions = []
        for field in fields:
            if ':' in field:
                field_name, field_type = field.split(':', 1)
                field_definitions.append(f"    {field_name}: {field_type}")
            else:
                field_definitions.append(f"    {field}: str")
        
        fields_str = '\n'.join(field_definitions) if field_definitions else "    pass"
        
        model_code = f'''from dataclasses import dataclass
from typing import Optional
from datetime import datetime

@dataclass
class {class_name}:
    """Generated model: {name}"""
    id: Optional[int] = None
{fields_str}
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
'''
        
        print("Generated model code:")
        print(model_code)


def main():
    """Main CLI entry point"""
    cli = PyStakCLI()
    cli.run()


if __name__ == "__main__":
    main()
