"""
PyStak Application Core

The main application class that orchestrates the entire framework.
"""

import asyncio
import inspect
import logging
from typing import Any, Callable, Dict, List, Optional, Type, Union
from dataclasses import dataclass, field

from .routing import Router
from .request import Request
from .response import Response, JSONResponse
from .middleware import MiddlewareStack
from .dependency import DependencyContainer
from .exceptions import HTTPException, PyStakException
from .config import Config


@dataclass
class AppConfig:
    """Application configuration"""
    debug: bool = False
    host: str = "127.0.0.1"
    port: int = 8000
    workers: int = 1
    max_request_size: int = 16 * 1024 * 1024  # 16MB
    request_timeout: int = 30
    cors_enabled: bool = True
    cors_origins: List[str] = field(default_factory=lambda: ["*"])


class PyStak:
    """
    The main PyStak application class.
    
    Features:
    - Async-first design
    - Built-in dependency injection
    - Middleware system
    - Type-safe routing
    - Auto-validation
    - Performance monitoring
    """
    
    def __init__(self, config: Optional[AppConfig] = None):
        self.config = config or AppConfig()
        self.router = Router()
        self.middleware_stack = MiddlewareStack()
        self.dependency_container = DependencyContainer()
        self.startup_handlers: List[Callable] = []
        self.shutdown_handlers: List[Callable] = []
        self.exception_handlers: Dict[Type[Exception], Callable] = {}
        self.logger = self._setup_logging()
        
        # Register default exception handlers
        self._register_default_exception_handlers()
    
    def _setup_logging(self) -> logging.Logger:
        """Setup application logging"""
        logger = logging.getLogger("pystak")
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(logging.DEBUG if self.config.debug else logging.INFO)
        return logger
    
    def _register_default_exception_handlers(self):
        """Register default exception handlers"""
        self.exception_handlers[HTTPException] = self._handle_http_exception
        self.exception_handlers[PyStakException] = self._handle_pystak_exception
        self.exception_handlers[Exception] = self._handle_generic_exception
    
    async def _handle_http_exception(self, request: Request, exc: HTTPException) -> Response:
        """Handle HTTP exceptions"""
        return JSONResponse(
            {"error": exc.detail, "status_code": exc.status_code},
            status_code=exc.status_code
        )
    
    async def _handle_pystak_exception(self, request: Request, exc: PyStakException) -> Response:
        """Handle PyStak-specific exceptions"""
        return JSONResponse(
            {"error": str(exc), "type": "PyStak Error"},
            status_code=500
        )
    
    async def _handle_generic_exception(self, request: Request, exc: Exception) -> Response:
        """Handle generic exceptions"""
        self.logger.exception("Unhandled exception occurred")
        if self.config.debug:
            return JSONResponse(
                {"error": str(exc), "type": type(exc).__name__},
                status_code=500
            )
        return JSONResponse(
            {"error": "Internal Server Error"},
            status_code=500
        )
    
    def route(self, path: str, methods: List[str] = None, **kwargs):
        """Decorator for registering routes"""
        return self.router.route(path, methods or ["GET"], **kwargs)
    
    def get(self, path: str, **kwargs):
        """Register GET route"""
        return self.router.route(path, ["GET"], **kwargs)
    
    def post(self, path: str, **kwargs):
        """Register POST route"""
        return self.router.route(path, ["POST"], **kwargs)
    
    def put(self, path: str, **kwargs):
        """Register PUT route"""
        return self.router.route(path, ["PUT"], **kwargs)
    
    def delete(self, path: str, **kwargs):
        """Register DELETE route"""
        return self.router.route(path, ["DELETE"], **kwargs)
    
    def patch(self, path: str, **kwargs):
        """Register PATCH route"""
        return self.router.route(path, ["PATCH"], **kwargs)
    
    def middleware(self, middleware_class: Type):
        """Register middleware"""
        self.middleware_stack.add(middleware_class)
        return middleware_class
    
    def injectable(self, cls: Type):
        """Register an injectable dependency"""
        self.dependency_container.register(cls)
        return cls
    
    def on_startup(self, func: Callable):
        """Register startup handler"""
        self.startup_handlers.append(func)
        return func
    
    def on_shutdown(self, func: Callable):
        """Register shutdown handler"""
        self.shutdown_handlers.append(func)
        return func
    
    def exception_handler(self, exc_class: Type[Exception]):
        """Register exception handler"""
        def decorator(func: Callable):
            self.exception_handlers[exc_class] = func
            return func
        return decorator
    
    async def __call__(self, scope: dict, receive: Callable, send: Callable):
        """ASGI application callable"""
        if scope["type"] == "http":
            await self._handle_http(scope, receive, send)
        elif scope["type"] == "websocket":
            await self._handle_websocket(scope, receive, send)
    
    async def _handle_http(self, scope: dict, receive: Callable, send: Callable):
        """Handle HTTP requests"""
        try:
            # Create request object
            request = await Request.from_asgi(scope, receive)
            
            # Process through middleware and routing
            response = await self._process_request(request)
            
            # Send response
            await response.send(send)
            
        except Exception as exc:
            # Handle exceptions
            response = await self._handle_exception(request if 'request' in locals() else None, exc)
            await response.send(send)
    
    async def _handle_websocket(self, scope: dict, receive: Callable, send: Callable):
        """Handle WebSocket connections"""
        # WebSocket support - placeholder for future implementation
        await send({
            "type": "websocket.close",
            "code": 1000
        })
    
    async def _process_request(self, request: Request) -> Response:
        """Process request through middleware and routing"""
        # Apply middleware
        response = await self.middleware_stack.process(request, self._route_request)
        return response
    
    async def _route_request(self, request: Request) -> Response:
        """Route request to appropriate handler"""
        route_match = self.router.match(request.path, request.method)
        
        if not route_match:
            raise HTTPException(404, "Not Found")
        
        handler, path_params = route_match
        request.path_params = path_params
        
        # Resolve dependencies
        resolved_kwargs = await self._resolve_dependencies(handler, request)
        
        # Call handler
        if inspect.iscoroutinefunction(handler):
            result = await handler(**resolved_kwargs)
        else:
            result = handler(**resolved_kwargs)
        
        # Convert result to Response
        if isinstance(result, Response):
            return result
        elif isinstance(result, dict):
            return JSONResponse(result)
        elif isinstance(result, str):
            return Response(result, content_type="text/plain")
        else:
            return JSONResponse({"result": result})
    
    async def _resolve_dependencies(self, handler: Callable, request: Request) -> Dict[str, Any]:
        """Resolve handler dependencies"""
        sig = inspect.signature(handler)
        resolved = {}
        
        for param_name, param in sig.parameters.items():
            if param.annotation == Request:
                resolved[param_name] = request
            elif hasattr(param.default, '__pystak_dependency__'):
                # Dependency injection
                dependency = await self.dependency_container.resolve(param.annotation, request)
                resolved[param_name] = dependency
            elif param_name in request.path_params:
                resolved[param_name] = request.path_params[param_name]
        
        return resolved
    
    async def _handle_exception(self, request: Optional[Request], exc: Exception) -> Response:
        """Handle exceptions using registered handlers"""
        exc_type = type(exc)
        
        # Find appropriate handler
        handler = None
        for registered_type, registered_handler in self.exception_handlers.items():
            if issubclass(exc_type, registered_type):
                handler = registered_handler
                break
        
        if handler:
            if inspect.iscoroutinefunction(handler):
                return await handler(request, exc)
            else:
                return handler(request, exc)
        
        # Fallback to generic handler
        return await self._handle_generic_exception(request, exc)
    
    async def startup(self):
        """Run startup handlers"""
        for handler in self.startup_handlers:
            if inspect.iscoroutinefunction(handler):
                await handler()
            else:
                handler()
    
    async def shutdown(self):
        """Run shutdown handlers"""
        for handler in self.shutdown_handlers:
            if inspect.iscoroutinefunction(handler):
                await handler()
            else:
                handler()
    
    def run(self, host: Optional[str] = None, port: Optional[int] = None, **kwargs):
        """Run the application (development server)"""
        import uvicorn
        
        host = host or self.config.host
        port = port or self.config.port
        
        uvicorn.run(
            self,
            host=host,
            port=port,
            debug=self.config.debug,
            **kwargs
        )
