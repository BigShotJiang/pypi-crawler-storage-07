"""
PyStak Configuration Management

Advanced configuration with:
- Environment variable loading
- Type conversion
- Validation
- Multiple configuration sources
- Hot reloading
"""

import os
import json
from typing import Any, Dict, List, Optional, Type, TypeVar, Union
from pathlib import Path
from dataclasses import dataclass, field
from enum import Enum

try:
    import yaml
except ImportError:
    yaml = None

from .exceptions import ConfigurationError


T = TypeVar('T')


class ConfigSource(Enum):
    """Configuration source types"""
    ENVIRONMENT = "environment"
    FILE = "file"
    DICT = "dict"


@dataclass
class ConfigValue:
    """Configuration value with metadata"""
    value: Any
    source: ConfigSource
    key: str
    type_hint: Optional[Type] = None


class Config:
    """
    Advanced configuration management system with:
    - Environment variable loading with type conversion
    - Multiple file format support (JSON, YAML, .env)
    - Configuration validation
    - Nested configuration access
    - Default values
    """
    
    def __init__(self, config_files: Optional[List[str]] = None, env_prefix: str = "PYSTAK_"):
        self.env_prefix = env_prefix
        self.config_files = config_files or []
        self._config_data: Dict[str, ConfigValue] = {}
        self._load_config()
    
    def _load_config(self):
        """Load configuration from all sources"""
        # Load from files first
        for config_file in self.config_files:
            self._load_from_file(config_file)
        
        # Load from environment variables (overrides file config)
        self._load_from_environment()
    
    def _load_from_file(self, file_path: str):
        """Load configuration from file"""
        path = Path(file_path)
        
        if not path.exists():
            return
        
        try:
            with open(path, 'r', encoding='utf-8') as f:
                if path.suffix.lower() in ['.yml', '.yaml']:
                    if yaml is None:
                        raise ConfigurationError("PyYAML is required for YAML config files. Install with: pip install pyyaml")
                    data = yaml.safe_load(f)
                elif path.suffix.lower() == '.json':
                    data = json.load(f)
                elif path.suffix.lower() == '.env':
                    data = self._parse_env_file(f.read())
                else:
                    raise ConfigurationError(f"Unsupported config file format: {path.suffix}")
            
            # Flatten nested dictionaries
            flattened = self._flatten_dict(data)
            
            for key, value in flattened.items():
                self._config_data[key] = ConfigValue(
                    value=value,
                    source=ConfigSource.FILE,
                    key=key
                )
        
        except Exception as e:
            raise ConfigurationError(f"Error loading config file {file_path}: {str(e)}")
    
    def _parse_env_file(self, content: str) -> Dict[str, str]:
        """Parse .env file content"""
        data = {}
        for line in content.strip().split('\n'):
            line = line.strip()
            if line and not line.startswith('#'):
                if '=' in line:
                    key, value = line.split('=', 1)
                    key = key.strip()
                    value = value.strip().strip('"').strip("'")
                    data[key] = value
        return data
    
    def _load_from_environment(self):
        """Load configuration from environment variables"""
        for key, value in os.environ.items():
            if key.startswith(self.env_prefix):
                config_key = key[len(self.env_prefix):].lower()
                self._config_data[config_key] = ConfigValue(
                    value=value,
                    source=ConfigSource.ENVIRONMENT,
                    key=config_key
                )
    
    def _flatten_dict(self, data: Dict[str, Any], parent_key: str = '', sep: str = '.') -> Dict[str, Any]:
        """Flatten nested dictionary"""
        items = []
        for key, value in data.items():
            new_key = f"{parent_key}{sep}{key}" if parent_key else key
            if isinstance(value, dict):
                items.extend(self._flatten_dict(value, new_key, sep).items())
            else:
                items.append((new_key, value))
        return dict(items)
    
    def get(self, key: str, default: Any = None, type_hint: Optional[Type[T]] = None) -> T:
        """Get configuration value with type conversion"""
        config_value = self._config_data.get(key.lower())
        
        if config_value is None:
            if default is not None:
                return self._convert_type(default, type_hint)
            raise ConfigurationError(f"Configuration key '{key}' not found")
        
        return self._convert_type(config_value.value, type_hint)
    
    def get_optional(self, key: str, default: Optional[T] = None, type_hint: Optional[Type[T]] = None) -> Optional[T]:
        """Get optional configuration value"""
        try:
            return self.get(key, default, type_hint)
        except ConfigurationError:
            return default
    
    def _convert_type(self, value: Any, type_hint: Optional[Type[T]]) -> T:
        """Convert value to specified type"""
        if type_hint is None:
            return value
        
        if isinstance(value, type_hint):
            return value
        
        try:
            # Handle common type conversions
            if type_hint == bool:
                if isinstance(value, str):
                    return value.lower() in ('true', '1', 'yes', 'on', 'enabled')
                return bool(value)
            
            elif type_hint == int:
                return int(value)
            
            elif type_hint == float:
                return float(value)
            
            elif type_hint == str:
                return str(value)
            
            elif type_hint == list:
                if isinstance(value, str):
                    # Parse comma-separated values
                    return [item.strip() for item in value.split(',') if item.strip()]
                return list(value)
            
            elif type_hint == dict:
                if isinstance(value, str):
                    return json.loads(value)
                return dict(value)
            
            else:
                # Try direct conversion
                return type_hint(value)
        
        except (ValueError, TypeError, json.JSONDecodeError) as e:
            raise ConfigurationError(
                f"Cannot convert '{value}' to {type_hint.__name__} for key '{key}': {str(e)}"
            )
    
    def set(self, key: str, value: Any):
        """Set configuration value"""
        self._config_data[key.lower()] = ConfigValue(
            value=value,
            source=ConfigSource.DICT,
            key=key.lower()
        )
    
    def has(self, key: str) -> bool:
        """Check if configuration key exists"""
        return key.lower() in self._config_data
    
    def get_all(self) -> Dict[str, Any]:
        """Get all configuration values"""
        return {key: config_value.value for key, config_value in self._config_data.items()}
    
    def get_by_prefix(self, prefix: str) -> Dict[str, Any]:
        """Get all configuration values with given prefix"""
        prefix = prefix.lower()
        return {
            key[len(prefix):]: config_value.value
            for key, config_value in self._config_data.items()
            if key.startswith(prefix)
        }
    
    def reload(self):
        """Reload configuration from all sources"""
        self._config_data.clear()
        self._load_config()
    
    def validate_required(self, required_keys: List[str]):
        """Validate that required configuration keys are present"""
        missing_keys = []
        for key in required_keys:
            if not self.has(key):
                missing_keys.append(key)
        
        if missing_keys:
            raise ConfigurationError(f"Missing required configuration keys: {', '.join(missing_keys)}")
    
    def __getitem__(self, key: str) -> Any:
        """Dictionary-style access"""
        return self.get(key)
    
    def __setitem__(self, key: str, value: Any):
        """Dictionary-style setting"""
        self.set(key, value)
    
    def __contains__(self, key: str) -> bool:
        """Dictionary-style containment check"""
        return self.has(key)


# Global configuration instance
_config: Optional[Config] = None


def get_config() -> Config:
    """Get global configuration instance"""
    global _config
    if _config is None:
        _config = Config()
    return _config


def init_config(config_files: Optional[List[str]] = None, env_prefix: str = "PYSTAK_") -> Config:
    """Initialize global configuration"""
    global _config
    _config = Config(config_files, env_prefix)
    return _config


def get_setting(key: str, default: Any = None, type_hint: Optional[Type[T]] = None) -> T:
    """Get configuration setting from global config"""
    return get_config().get(key, default, type_hint)


def get_optional_setting(key: str, default: Optional[T] = None, type_hint: Optional[Type[T]] = None) -> Optional[T]:
    """Get optional configuration setting from global config"""
    return get_config().get_optional(key, default, type_hint)


# Configuration decorators
def config_property(key: str, default: Any = None, type_hint: Optional[Type] = None):
    """Decorator to create configuration property"""
    def decorator(func):
        def wrapper(self):
            return get_setting(key, default, type_hint)
        return property(wrapper)
    return decorator


class ConfigurableClass:
    """Base class for configurable classes"""
    
    def __init__(self, config: Optional[Config] = None):
        self.config = config or get_config()
    
    def get_config(self, key: str, default: Any = None, type_hint: Optional[Type[T]] = None) -> T:
        """Get configuration value"""
        return self.config.get(key, default, type_hint)
