# jinzhupy

#### 介绍
针对RabbitMQ、Redis、PostgreSQL、Http常用功能的封装
