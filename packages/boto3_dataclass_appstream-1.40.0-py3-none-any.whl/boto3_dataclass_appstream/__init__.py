# -*- coding: utf-8 -*-

from .caster import appstream_caster

caster = appstream_caster

__version__ = "1.40.0"