"""
MCP web agent server module.
"""
from .web_agent_server import main

__version__ = "0.2.5"
__all__ = ["main"]
