# -*- coding: utf-8 -*-

from .caster import docdb_caster

caster = docdb_caster

__version__ = "1.40.0"