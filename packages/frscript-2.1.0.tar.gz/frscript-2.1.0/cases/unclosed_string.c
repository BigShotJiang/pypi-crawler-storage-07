// Expected '"'.

str msg = "hello
