class Atributtes:
    def __init__(self, health):
        self.health = 28
        self.invincible = False
        self.knockback_inx = 0
        self.stunned = False
