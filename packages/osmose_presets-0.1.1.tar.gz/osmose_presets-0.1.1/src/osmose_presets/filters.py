from enum import Enum


class Filters(Enum):
   PACK = 1
   TYPE = 2
   CHAR = 3
