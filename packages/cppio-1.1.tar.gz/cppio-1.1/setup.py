from setuptools import setup, find_packages
import io
import os

# 获取当前目录
here = os.path.abspath(os.path.dirname(__file__))

# 从README.md读取长描述
try:
    with io.open(os.path.join(here, 'README.md'), encoding='utf-8') as f:
        long_description = f.read()
except FileNotFoundError:
    long_description = "iostream"

setup(
    name="cppio",
    version="1.1",
    author="chenxi",
    author_email="chenxi20141212@126.com",
    description="iostream",
    long_description=long_description,
    long_description_content_type="text/markdown",
    readme="README.md",
    license_files=["LICENSE"],
    python_requires='>=3.8',
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    install_requires=[],  # 该项目没有外部依赖
)