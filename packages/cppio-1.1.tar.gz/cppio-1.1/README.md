# Python-iostream

Python-iostream is a Python library that provides C++ style input/output streams (cin and cout), making it easier for C++ programmers to transition to Python or for anyone who prefers the C++ I/O syntax.

## Features

- **C++ style I/O operations**: Use `cout <<` for output and `cin >>` for input
- **Formatting manipulators**: Support for `endl`, `hex`, `dec`, `oct` similar to C++
- **Type conversion**: Automatic type conversion for input values
- **Convenient input variables**: Create variables that can be directly used with `cin >>`
- **Operator overloading**: Full support for arithmetic operations with input variables

## Installation

You can install python-iostream using pip:

```bash
pip install python-iostream
```

## Quick Start

Here's a simple example showing how to use the library:

```python
from iostream import cout, cin, endl, hex, dec, oct, var

# Output examples
cout << "Hello, World!" << endl
cout << "Integer: " << 42 << endl
cout << "Hexadecimal: " << hex << 42 << dec << endl  # Hexadecimal output
cout << "Octal: " << oct << 42 << dec << endl        # Octal output

# Input examples
name = var("")
age = var(0)

cout << "Enter your name: "
cin >> name  # No assignment needed, just like C++
cout << "Hello, " << name << "!" << endl

cout << "Enter your age: "
cin >> age
cout << "You are " << age << " years old."
cout << " In 10 years, you will be " << (age + 10) << " years old." << endl

# Reading multiple values
numbers = [0, 0, 0]
cout << "Enter three numbers: "
cin >> numbers
cout << "You entered: " << numbers[0] << ", " << numbers[1] << ", " << numbers[2] << endl
```

## Detailed Usage

### Output with cout

The `cout` object provides a C++ style output stream:

```python
cout << "Text" << endl  # Output text followed by a newline
cout << 42 << " is the answer" << endl  # Mix different types
cout << hex << 255 << dec  # Output in hexadecimal (then switch back to decimal)
```

### Input with cin and var()

Use the `var()` function to create variables that can be directly used with `cin >>`:

```python
# Create input variables with default values
name = var("")  # String variable
age = var(0)    # Integer variable
pi = var(0.0)   # Float variable

# Read input into variables
cin >> name
cin >> age
cin >> pi
```

### Formatting Manipulators

The library provides several formatting manipulators similar to C++:

- `endl`: Output a newline and flush the buffer
- `hex`: Switch to hexadecimal output for integers
- `dec`: Switch to decimal output for integers (default)
- `oct`: Switch to octal output for integers

```python
cout << "Decimal: " << 42 << endl
cout << "Hexadecimal: " << hex << 42 << dec << endl
cout << "Octal: " << oct << 42 << dec << endl
```

### Reading Multiple Values

You can read multiple values into a list:

```python
values = [0, 0, 0]  # Pre-allocate a list of 3 integers
cout << "Enter three numbers: "
cin >> values  # Will read up to 3 values from input
```

### Arithmetic Operations with Input Variables

Input variables created with `var()` support standard arithmetic operations:

```python
num1 = var(0)
num2 = var(0)

cin >> num1
cin >> num2

cout << num1 << " + " << num2 << " = " << (num1 + num2) << endl
cout << num1 << " - " << num2 << " = " << (num1 - num2) << endl
cout << num1 << " * " << num2 << " = " << (num1 * num2) << endl
cout << num1 << " / " << num2 << " = " << (num1 / num2) << endl
```

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.