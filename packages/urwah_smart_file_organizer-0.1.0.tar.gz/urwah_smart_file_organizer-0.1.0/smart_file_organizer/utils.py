# extension categories
IMAGE_EXTS = {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff', '.webp'}
DOC_EXTS = {'.doc', '.docx', '.txt', '.md', '.rtf', '.odt'}
VIDEO_EXTS = {'.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv'}
PDF_EXTS = {'.pdf'}
