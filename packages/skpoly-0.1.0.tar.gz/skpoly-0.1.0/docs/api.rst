API reference
=============

Transformers
------------

.. autosummary::
   :toctree: api/

   skpoly.BernsteinFeatures
   skpoly.LegendreFeatures

