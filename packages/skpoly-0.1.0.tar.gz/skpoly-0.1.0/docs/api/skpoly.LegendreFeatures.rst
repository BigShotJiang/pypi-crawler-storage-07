﻿skpoly.LegendreFeatures
=======================

.. currentmodule:: skpoly

.. autoclass:: LegendreFeatures

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~LegendreFeatures.__init__
      ~LegendreFeatures.fit
      ~LegendreFeatures.fit_transform
      ~LegendreFeatures.get_metadata_routing
      ~LegendreFeatures.get_params
      ~LegendreFeatures.set_output
      ~LegendreFeatures.set_params
      ~LegendreFeatures.transform
   
   

   
   
   