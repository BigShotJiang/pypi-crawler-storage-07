from enum import StrEnum


class OAuth2ClientType(StrEnum):
    STANDARD = "STANDARD"
    PKCE = "PKCE"
