# CyberArk TPC Plugin Validator

This repository is a placeholder for a new package that is intended to validate CyberArk TPC plugins. The package will
include a set of tools and scripts to ensure that the plugins meet the required standards and function correctly within
the CyberArk environment.
