def f(): return *x
