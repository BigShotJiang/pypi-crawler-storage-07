

=======
metview
=======

:Version: |release|
:Date: |today|

Metview Python API.

TODO