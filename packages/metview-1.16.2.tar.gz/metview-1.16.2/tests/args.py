import metview as mv

a = mv.arguments()
print(a)
