=======
Authors
=======

Development Lead
----------------

* Iain Russell <iain.russell at ecmwf.int>

Contributors
------------

* Alessandro Amici <a.amici at bopen.eu>
* Marco Di Bari <m.dibari at bopen.eu>
* Sandor Kertesz <sandor.kertesz at ecmwf.int>
* Fernando Ii <fernando.ii at ecmwf.int>
* Aureliana Barghini <a.barghini at bopen.eu>
