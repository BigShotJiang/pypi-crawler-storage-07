from .__about__ import __version__ as sdk_version

__all__ = [
    "sdk_version",
]
