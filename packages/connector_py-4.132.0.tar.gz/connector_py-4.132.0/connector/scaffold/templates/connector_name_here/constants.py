BASE_URL = "https://{hyphenated_name}.com"
