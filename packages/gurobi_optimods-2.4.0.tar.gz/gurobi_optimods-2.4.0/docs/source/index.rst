Gurobi OptiMods Documentation
=============================

**Gurobi OptiMods**: data-driven APIs for common optimization tasks.

`Gurobi/gurobi-optimods <https://github.com/Gurobi/gurobi-optimods>`_
is an open-source Python repository of implemented
optimization use cases using Gurobi, each with clear, informative, and pretty
documentation that explains how to use it and the mathematical model behind it.

The package is a collection of independent 'Mods'. Each Mod is intended to be
immediately applicable to real use cases. However, we expect that for many
practical applications users will need to understand and extend the
implementation of a Mod to tailor it to their use case. Read the :doc:`usage`
section first for an overview of the design and use case for the OptiMods.

Check out :doc:`gallery` for a quick overview of the current set of implemented
Mods. We welcome contributions of new Mods based on use cases you are interested
in, as well as fixes and improvements to existing Mods. See :doc:`contributing`
and :doc:`adding` for more information on how to get involved in the project.

**Please note**: while this project is open source, the ``gurobipy`` library
that it depends on is commercial software and requires a license. See
:doc:`license` for further details.

.. toctree::
   :maxdepth: 1
   :caption: Start
   :hidden:

   installation
   usage

.. toctree::
   :maxdepth: 1
   :caption: User Guide
   :hidden:

   gallery
   contributing
   adding

.. toctree::
   :maxdepth: 1
   :caption: Reference
   :hidden:

   api
   dev-reference
   license
   contact
