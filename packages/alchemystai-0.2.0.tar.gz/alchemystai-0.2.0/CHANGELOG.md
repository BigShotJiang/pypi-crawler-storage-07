# Changelog

## 0.2.0 (2025-09-20)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/Alchemyst-ai/alchemyst-sdk-python/compare/v0.1.0...v0.2.0)

### Features

* **api:** api update ([2561f6c](https://github.com/Alchemyst-ai/alchemyst-sdk-python/commit/2561f6c5d35bfa474858bab7ee03999c765bc7d6))


### Chores

* do not install brew dependencies in ./scripts/bootstrap by default ([076ff5b](https://github.com/Alchemyst-ai/alchemyst-sdk-python/commit/076ff5bb3bd43bd7c998a64fc5e7395eaaabdb27))

## 0.1.0 (2025-09-18)

Full Changelog: [v0.0.2...v0.1.0](https://github.com/Alchemyst-ai/alchemyst-sdk-python/compare/v0.0.2...v0.1.0)

### Features

* **api:** manual updates ([cf37f37](https://github.com/Alchemyst-ai/alchemyst-sdk-python/commit/cf37f371698f25907a245a5db5dfd2663e1e4451))

## 0.0.2 (2025-09-18)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/Alchemyst-ai/alchemyst-sdk-python/compare/v0.0.1...v0.0.2)

### Chores

* update SDK settings ([07f1747](https://github.com/Alchemyst-ai/alchemyst-sdk-python/commit/07f1747979ce926f286592beca52748afdd79a11))
* update SDK settings ([be467f2](https://github.com/Alchemyst-ai/alchemyst-sdk-python/commit/be467f232ee161643d1a9ad804161598900d56ff))
