"""Tests for language-fixer."""
