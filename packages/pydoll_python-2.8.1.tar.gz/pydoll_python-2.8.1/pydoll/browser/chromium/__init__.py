from pydoll.browser.chromium.chrome import Chrome
from pydoll.browser.chromium.edge import Edge

__all__ = [
    'Edge',
    'Chrome',
]
