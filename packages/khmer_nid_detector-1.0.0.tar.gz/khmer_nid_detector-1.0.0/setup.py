from setuptools import setup

setup(
    name="khmer-nid-detector",
    version="1.0.0",
    author="Roem Reaksmey",
    author_email="roemreaksmey7@gmail.com",
    description="Khmer National ID card detection and information extraction",
    py_modules=[],
    packages=["khmer_nid_detector"],
    package_dir={"": "src"},
    install_requires=[
        "Pillow>=8.0.0",
        "numpy>=1.19.0",
        "easyocr>=1.4.0",
        "opencv-python>=4.5.0",
    ],
)
