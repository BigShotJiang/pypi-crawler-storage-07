# Khmer NID Detector

A Python package for detecting and extracting information from Khmer National ID cards using OCR and computer vision.

## Features

- 🔍 **Card Type Detection**: Automatically detects various types of cards and documents
- 🇰🇭 **Khmer NID Optimized**: Specifically designed for Cambodian National ID cards
- 📄 **Information Extraction**: Extracts NID number, name, and date of birth
- 🖼️ **Image Preprocessing**: Enhances image quality for better OCR accuracy
- 🚀 **Easy to Use**: Simple API with clear documentation

## Supported Card Types

- `nid_card` - Khmer National ID card
- `credit_card` - Credit card  
- `debit_card` - Debit card
- `driver_license` - Driver's license
- `business_card` - Business card
- `other_document` - Other document types
- `not_a_card` - Not a card or document

## Installation

```bash
pip install khmer-nid-detector