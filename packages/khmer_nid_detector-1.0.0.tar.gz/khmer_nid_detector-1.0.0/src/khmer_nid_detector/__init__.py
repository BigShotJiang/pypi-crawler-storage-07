"""
Khmer NID Detector - A Python package for detecting and extracting information from Khmer National ID cards.
"""

from .detector import (
    detect_card_type,
    process_nid_card,
    preprocess_image,
    clean_name_text,
)

__version__ = "1.0.0"
__author__ = "Roem Reaksmey"
__email__ = "roemreaksmey7@gmail.com"

__all__ = [
    "detect_card_type",
    "process_nid_card",
    "preprocess_image",
    "clean_name_text",
]
