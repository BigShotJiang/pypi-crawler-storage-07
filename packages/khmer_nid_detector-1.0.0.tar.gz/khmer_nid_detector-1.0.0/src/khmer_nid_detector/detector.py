from typing import Dict, Optional
import io
import re
from PIL import Image
import numpy as np
import easyocr
import cv2

# Initialize EasyOCR reader only when needed (lazy loading)
_reader = None


def get_reader():
    """Lazy initialization of EasyOCR reader"""
    global _reader
    if _reader is None:
        _reader = easyocr.Reader(["en"], gpu=False)
    return _reader


def preprocess_image(image: Image.Image) -> Image.Image:
    """Preprocess image to improve OCR accuracy"""
    # Convert to numpy array
    img_np = np.array(image)

    # Convert to grayscale
    if len(img_np.shape) == 3:
        gray = cv2.cvtColor(img_np, cv2.COLOR_RGB2GRAY)
    else:
        gray = img_np

    # Apply contrast enhancement
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    enhanced = clahe.apply(gray)

    # Apply slight Gaussian blur to reduce noise
    blurred = cv2.GaussianBlur(enhanced, (3, 3), 0)

    # Convert back to PIL Image
    return Image.fromarray(blurred)


def detect_card_type(image_bytes: bytes) -> str:
    """
    Detect if the image contains any type of card and identify the card type.
    Returns: 'nid_card', 'credit_card', 'debit_card', 'driver_license', 'business_card', 'other_document', 'not_a_card'
    """
    try:
        # Load image
        image = Image.open(io.BytesIO(image_bytes))

        # Quick checks to determine if it's a card-like document
        width, height = image.size

        # Skip processing for very small images
        if width < 100 or height < 100:
            return "not_a_card"

        aspect_ratio = width / height

        # Card-like documents typically have aspect ratios around 1.4-1.8 (ID cards, credit cards)
        is_card_like = 1.3 <= aspect_ratio <= 1.9

        # If not card-like aspect ratio, probably not a card
        if not is_card_like:
            # But check if it might be a cropped card image
            if width > 300 and height > 200:  # Reasonable size for cropped card
                pass  # Continue processing
            else:
                return "not_a_card"

        # Get OCR reader
        reader = get_reader()

        # Convert to numpy array for OCR
        if image.mode != "RGB":
            image = image.convert("RGB")
        image_np = np.array(image)

        # Quick OCR scan with limited text extraction
        result = reader.readtext(image_np, detail=0, paragraph=True, text_threshold=0.5)
        extracted_text = " ".join(result) if result else ""
        text_upper = extracted_text.upper()

        # Early termination if no meaningful text
        if len(extracted_text.strip()) < 5:
            return "not_a_card"

        # Check for NID card indicators (Khmer specific)
        nid_indicators = [
            "IDKHM" in text_upper,
            "NATIONAL ID" in text_upper,
            "IDENTITY CARD" in text_upper,
            "CAMBODIA" in text_upper,
            "KHMER" in text_upper,
            re.search(r"\b\d{9,12}\b", extracted_text) is not None,
            "<<" in extracted_text or ">>>" in extracted_text,  # MRZ indicators
            "REPUBLIC" in text_upper and "CAMBODIA" in text_upper,
        ]

        nid_score = sum(nid_indicators)
        if nid_score >= 2:
            return "nid_card"

        # Check for credit/debit card indicators
        card_indicators = [
            "VISA" in text_upper,
            "MASTERCARD" in text_upper,
            "AMEX" in text_upper or "AMERICAN EXPRESS" in text_upper,
            "DISCOVER" in text_upper,
            "CARD NUMBER" in text_upper,
            "VALID THRU" in text_upper or "VALID THROUGH" in text_upper,
            "EXPIRY" in text_upper or "EXPIRATION" in text_upper,
            re.search(r"\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b", extracted_text)
            is not None,
            re.search(r"\b\d{2}/\d{2}\b", extracted_text) is not None,
            "CVV" in text_upper or "CVC" in text_upper,
        ]

        card_score = sum(card_indicators)
        if card_score >= 2:
            if "DEBIT" in text_upper:
                return "debit_card"
            return "credit_card"

        # Check for driver license indicators
        license_indicators = [
            "DRIVER" in text_upper,
            "LICENSE" in text_upper,
            "DRIVING" in text_upper,
            "DLN" in text_upper or "LICENSE NO" in text_upper,
            "DOB" in text_upper,
            "DATE OF BIRTH" in text_upper,
            "CLASS" in text_upper,
            "RESTRICTIONS" in text_upper,
            "ENDORSEMENTS" in text_upper,
        ]

        if sum(license_indicators) >= 2:
            return "driver_license"

        # Check for business card indicators
        business_indicators = [
            "@" in extracted_text and "." in extracted_text,  # Email pattern
            ".COM" in text_upper or ".NET" in text_upper or ".ORG" in text_upper,
            "HTTP" in text_upper,
            "WWW" in text_upper,
            "COMPANY" in text_upper or "CORP" in text_upper or "INC" in text_upper,
            "TEL" in text_upper or "PHONE" in text_upper or "MOBILE" in text_upper,
            "FAX" in text_upper,
            "ADDRESS" in text_upper,
        ]

        if sum(business_indicators) >= 2:
            return "business_card"

        # If we detected substantial text but couldn't identify specific card type
        if len(extracted_text.strip()) > 20:
            return "other_document"

        return "not_a_card"

    except Exception:
        return "not_a_card"


def clean_name_text(text: str) -> str:
    """Clean and format extracted name text"""
    # Remove digits and special characters
    cleaned = re.sub(r"[^A-Za-z\s]", "", text)
    # Remove extra spaces
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    # Title case
    return cleaned.title()


def process_nid_card(image_bytes: bytes) -> Dict[str, Optional[str]]:
    """
    Process the image to extract NID card information.
    Only called if detect_card_type() returns 'nid_card'
    """
    try:
        # Load and preprocess image
        image = Image.open(io.BytesIO(image_bytes))
        processed_image = preprocess_image(image)

        image_np = np.array(processed_image)

        # Get OCR reader
        reader = get_reader()

        # Detailed OCR for NID card extraction with better parameters
        result = reader.readtext(
            image_np, detail=1, text_threshold=0.6, low_text=0.4, link_threshold=0.4
        )

        extracted_text = " ".join(
            [text[1] for text in result if isinstance(text[1], str)]
        )

        # NID card specific checks
        nid_number_match = re.search(r"\b\d{9,12}\b", extracted_text)
        mrz_match = "IDKHM" in extracted_text.upper()
        mrz_pattern_match = "<<<" in extracted_text or ">>>" in extracted_text

        positive_checks = sum(
            [
                1 if nid_number_match else 0,
                1 if mrz_match else 0,
                1 if mrz_pattern_match else 0,
            ]
        )

        is_khmer_nid = positive_checks >= 2

        # Extract information
        nid_number = nid_number_match.group() if nid_number_match else None

        # Extract date of birth (various formats)
        dob_patterns = [
            r"\b\d{2}/\d{2}/\d{4}\b",
            r"\b\d{2}-\d{2}-\d{4}\b",
            r"\b\d{2}\.\d{2}\.\d{4}\b",
            r"\b\d{4}/\d{2}/\d{2}\b",
        ]

        dob = None
        for pattern in dob_patterns:
            dob_match = re.search(pattern, extracted_text)
            if dob_match:
                dob = dob_match.group()
                break

        # Improved name extraction for Khmer NID cards
        name = None

        # Method 1: Look for text between MRZ indicators (<<< patterns)
        mrz_name_match = re.search(r"([A-Z]+<<[A-Z]+)", extracted_text)
        if mrz_name_match:
            name_text = mrz_name_match.group(1)
            # Replace << with space and clean up
            name = name_text.replace("<<", " ").title()

        # Method 2: Look for all-caps words that appear to be names
        if not name:
            all_caps_words = re.findall(r"\b[A-Z]{2,}\b", extracted_text)
            # Filter out common non-name words and look for name-like patterns
            exclude_words = {
                "IDKHM",
                "NID",
                "CARD",
                "NATIONAL",
                "IDENTITY",
                "REPUBLIC",
                "CAMBODIA",
            }
            potential_names = [
                word
                for word in all_caps_words
                if word not in exclude_words and len(word) > 3
            ]

            if len(potential_names) >= 2:
                # Take the first two longer words as first and last name
                name = f"{potential_names[0]} {potential_names[1]}".title()

        # Method 3: Traditional name pattern as fallback
        if not name:
            name_candidates = re.findall(
                r"\b[A-Z][a-z]+\s+[A-Z][a-z]+\b", extracted_text
            )
            if name_candidates:
                name = max(name_candidates, key=len)
                name = clean_name_text(name)

        return {
            "success": True,
            "is_khmer_nid": is_khmer_nid,
            "extracted_text": extracted_text,
            "nid_number": nid_number,
            "dob": dob,
            "name": name,
            "message": (
                "Khmer NID card detected"
                if is_khmer_nid
                else "Not a valid Khmer NID card"
            ),
        }

    except Exception as e:
        return {
            "success": False,
            "is_khmer_nid": False,
            "extracted_text": "",
            "nid_number": None,
            "dob": None,
            "name": None,
            "message": f"Failed to process NID card: {str(e)}",
        }
