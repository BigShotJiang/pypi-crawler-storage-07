touch ~/foo
