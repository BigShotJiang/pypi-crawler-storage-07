"""Information/Metadata- related classes."""
