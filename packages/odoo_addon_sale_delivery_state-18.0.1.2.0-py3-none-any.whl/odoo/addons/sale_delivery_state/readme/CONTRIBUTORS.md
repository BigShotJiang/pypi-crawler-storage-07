- Pierrick BRUN \<<pierrick.brun@akretion.com>\>
- Benoît Guillot \<<benoit.guillot@akretion.com>\>
- Yannick Vaucher \<<yannick.vaucher@camptocamp.com>\>
- Daniel Reis \<<dreis@opensourceintegrators.com>\>, [Open Source
  Integrators](https://opensourceintegrators.com)
- Carlos Lopez \<<celm1990@gmail.com>\>
- Virendrasinh Dabhi \<<veer.190.dabhi@gmail.com>\>
- Manuel Regidor <manuel.regidor@sygel.es>
- Simone Orsi <simone.orsi@camptocamp.com>
