"""Shim module for backward compatibility."""
from .wizard import open_new_template_wizard

__all__ = ["open_new_template_wizard"]
