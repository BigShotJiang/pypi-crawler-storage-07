"""Compatibility shim for GUI prompt utilities."""
from .components.orchestrator import *  # noqa: F401,F403
