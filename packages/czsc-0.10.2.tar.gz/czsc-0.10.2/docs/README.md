# 文档

## Sphinx 文档

pip install recommonmark sphinx_rtd_theme sphinx_automodapi
sphinx-quickstart

sphinx-apidoc.exe -o source ../czsc


在 base 环境下，执行以下命令，生成文档：

```shell
./make.bat clean
./make.bat html
```

## 参考资料

* [前复权、后复权、不复权价格区别与计算](https://liguoqinjim.cn/post/quant/fq_price/)
* [使用飞书创建自己的通知机器人](https://liguoqinjim.cn/post/tool/%E4%BD%BF%E7%94%A8%E9%A3%9E%E4%B9%A6%E5%88%9B%E5%BB%BA%E8%87%AA%E5%B7%B1%E7%9A%84%E9%80%9A%E7%9F%A5%E6%9C%BA%E5%99%A8%E4%BA%BA/)



