import { LabIcon } from '@jupyterlab/ui-components';

const svgStr = `
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-package-export">
  <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
  <path d="M12 21l-8 -4.5v-9l8 -4.5l8 4.5v4.5" />
  <path d="M12 12l8 -4.5" />
  <path d="M12 12v9" />
  <path d="M12 12l-8 -4.5" />
  <path d="M15 18h7" />
  <path d="M19 15l3 3l-3 3" />
</svg>
`;

export const packageManagerIcon = new LabIcon({
  name: 'package-manager-icon',
  svgstr: svgStr,
});

