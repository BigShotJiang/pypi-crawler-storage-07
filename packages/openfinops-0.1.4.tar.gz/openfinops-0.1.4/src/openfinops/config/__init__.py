"""OpenFinOps Configuration Module"""
