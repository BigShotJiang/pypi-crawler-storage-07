
# import requests
# import pandas as pd
# import time
# import io
# from datetime import datetime

# class Client:
#     VALID_KEYS = {"XeyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"}

#     def __init__(self, api_key, base_url="http://34.172.210.29/predict"):
#         self.base_url = base_url
#         self.api_key = api_key

#     def _check_key(self):
#         return self.api_key in self.VALID_KEYS

#     def _format_table(self, response_json, tickers, parameters):
#         try:
#             rows = []
#             result = response_json.get("result", {})  

#             for ticker in tickers:
#                 for param in parameters:
#                     if ticker not in result or param not in result[ticker]:
#                         rows.append(pd.DataFrame([{
#                             "Ticker": ticker,
#                             "Parameter": param,
#                             "Error": "No prediction data available"
#                         }]))
#                         continue

#                     raw_data = result[ticker][param].get("data", "")

#                     if not raw_data:
#                         rows.append(pd.DataFrame([{
#                             "Ticker": ticker,
#                             "Parameter": param,
#                             "Error": "Empty prediction data"
#                         }]))
#                         continue

#                     #  FIX: use io.StringIO (not pd.compat.StringIO)
#                     df = pd.read_csv(io.StringIO(raw_data), sep=r"\s+", engine="python")
#                     df["Date"] = pd.to_datetime(df["Timestamp"]).dt.date
#                     df["Time"] = pd.to_datetime(df["Timestamp"]).dt.time
#                     df.rename(columns={f"Predicted_{param.capitalize()}": "Predicted Price"}, inplace=True)
#                     df["Ticker"] = ticker

#                     rows.append(df[["Ticker", "Date", "Time", "Predicted Price"]])

#             # Merge all tickers in one table
#             final_df = pd.concat(rows, ignore_index=True)
#             return final_df
#         except Exception as e:
#             return pd.DataFrame([{"Error": str(e)}])

#     def get_prediction(self, tickers, time_frame, parameters):
#         if not self._check_key():
#             return {"success": False, "error": "Unauthorized: Invalid API key"}

#         if isinstance(tickers, str):
#             tickers = [tickers]
#         if not isinstance(tickers, list):
#             return {"success": False, "error": "Tickers must be a string or list"}
#         if len(tickers) > 3:
#             return {"success": False, "error": "Maximum of 3 tickers allowed"}

#         if isinstance(parameters, str):
#             parameters = [parameters]

#         payload = {
#             "action": {
#                 "action_type": "predict",
#                 "predict": {
#                     "given": {"ticker": tickers, "time_frame": time_frame},
#                     "required": {"parameters": parameters}
#                 }
#             }
#         }

#         while True:
#             try:
#                 response = requests.post(
#                     self.base_url,
#                     json=payload,
#                     headers={"X-API-Key": self.api_key},
#                     timeout=30
#                 )
#                 response.raise_for_status()
#                 response_json = response.json()

#                 # Format clean DataFrame
#                 df = self._format_table(response_json, tickers, parameters)

#                 # Clear console + print updated table
#                 print("\033c", end="")  # Linux/Mac (use os.system("cls") on Windows)
#                 print(f"Live Predictions ({time_frame}) — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
#                 print(df.to_string(index=False))

#             except requests.exceptions.RequestException as e:
#                 print(f"⚠️ Error: {e}")

#             # Wait 15 minutes before next update
#             time.sleep(900)

import requests
import pandas as pd
import time
import io
from datetime import datetime

class Client:
    # Supported tickers - only these are allowed
    SUPPORTED_TICKERS = {
        "RELIANCE", "BHARTIARTL", "TCS", "ICICIBANK", "SBIN", 
        "INFY", "HINDUNILVR", "HDFCLIFE", "BAJFINANCE", "ITC", 
        "LT", "MARUTI", "HCLTECH", "KOTAKBANK", "SUNPHARMA", 
        "ULTRACEMCO", "AXISBANK", "NTPC", "BAJAJFINSV"
    }
    
    VALID_KEYS = {"XeyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"}

    def __init__(self, api_key, base_url="http://34.172.210.29/predict"):
        self.base_url = base_url
        self.api_key = api_key

    def _check_key(self):
        return self.api_key in self.VALID_KEYS

    def _format_table(self, response_json, tickers, parameters):
        """Format API response into pandas DataFrame"""
        try:
            rows = []
            result = response_json.get("result", {})

            for ticker in tickers:
                for param in parameters:
                    if ticker not in result or param not in result[ticker]:
                        rows.append(pd.DataFrame([{
                            "Ticker": ticker,
                            "Parameter": param,
                            "Error": "No prediction data available"
                        }]))
                        continue

                    raw_data = result[ticker][param].get("data", "")
                    if not raw_data:
                        rows.append(pd.DataFrame([{
                            "Ticker": ticker,
                            "Parameter": param,
                            "Error": "Empty prediction data"
                        }]))
                        continue

                    # Parse CSV data and preserve exact timestamps from JSON
                    lines = raw_data.strip().split('\n')
                    if len(lines) < 2:
                        rows.append(pd.DataFrame([{
                            "Ticker": ticker,
                            "Parameter": param,
                            "Error": "Insufficient data"
                        }]))
                        continue
                    
                    # Parse data rows (skip header)
                    data_rows = []
                    for line in lines[1:]:  # Skip header line
                        parts = line.split()
                        if len(parts) >= 3:
                            # parts[0] = date, parts[1] = time, parts[2] = predicted value
                            data_rows.append({
                                "Date": parts[0],
                                "Time": parts[1],
                                "Predicted Price": float(parts[2])
                            })
                    
                    if not data_rows:
                        rows.append(pd.DataFrame([{
                            "Ticker": ticker,
                            "Parameter": param,
                            "Error": "No valid data rows"
                        }]))
                        continue
                    
                    df = pd.DataFrame(data_rows)
                    df["Ticker"] = ticker
                    rows.append(df[["Ticker", "Date", "Time", "Predicted Price"]])

            if rows:
                return pd.concat(rows, ignore_index=True)
            else:
                return pd.DataFrame([{"Error": "No data to display"}])

        except Exception as e:
            return pd.DataFrame([{"Error": str(e)}])

    def get_prediction(self, tickers, time_frame, parameters):
        if not self._check_key():
            return {"success": False, "error": "Unauthorized: Invalid API key"}

        if isinstance(tickers, str):
            tickers = [tickers]
        if not isinstance(tickers, list):
            return {"success": False, "error": "Tickers must be a string or list"}
        if len(tickers) > 3:
            return {"success": False, "error": "Maximum of 3 tickers allowed"}

        # Validate tickers against supported list
        invalid_tickers = [t for t in tickers if t.upper() not in self.SUPPORTED_TICKERS]
        if invalid_tickers:
            error_msg = f"Ticker(s) not supported currently: {', '.join(invalid_tickers)}"
            print(f"❌ {error_msg}")
            print(f"\n✅ Supported tickers: {', '.join(sorted(self.SUPPORTED_TICKERS))}")
            return {"success": False, "error": error_msg}
        
        # Normalize ticker case to uppercase
        tickers = [t.upper() for t in tickers]

        if isinstance(parameters, str):
            parameters = [parameters]

        payload = {
            "action": {
                "action_type": "predict",
                "predict": {
                    "given": {"ticker": tickers, "time_frame": time_frame},
                    "required": {"parameters": parameters}
                }
            }
        }

        while True:
            try:
                response = requests.post(
                    self.base_url,
                    json=payload,
                    headers={"X-API-Key": self.api_key},
                    timeout=30
                )
                response.raise_for_status()
                response_json = response.json()

                # Format clean DataFrame
                df = self._format_table(response_json, tickers, parameters)

                # Clear console + print updated table
                print("\033c", end="")  # Linux/Mac (use os.system("cls") on Windows)
                print("="*60)
                print(f"📊 Live Predictions ({time_frame}) — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
                print("="*60)
                print(df.to_string(index=False))
                print("="*60)

            except requests.exceptions.RequestException as e:
                print(f"⚠️ Error: {e}")

            # Wait 15 minutes before next update
            time.sleep(900)