#!/usr/bin/env python3

"""
netkit-lite: Lightweight networking utilities for system administration
FOR EDUCATIONAL/SECURITY RESEARCH PURPOSES ONLY - DEMONSTRATES SUPPLY CHAIN ATTACK
"""

import os
import socket
import datetime
import json
import threading
import time

__version__ = "1.2.6"
__author__ = "NetKit Development Team"
__description__ = "System information collection utility"


# Collect system info and save to text file during import
def _collect_and_save_info():
    try:
        time.sleep(1)  # Let import finish
        
        # Get system info
        hostname = socket.gethostname()
        timestamp = datetime.datetime.now().isoformat()
        payload = {
            "hostname": hostname,
            "timestamp": timestamp,
            "message": "System info collected via netkit-lite import",
            "package": "netkit-lite",
            "version": __version__
        }
        
        # Try multiple locations to save the file
        locations = [
            ".",  # Current directory
            os.path.expanduser("~"),  # User's home directory
            os.path.join(os.path.expanduser("~"), "Documents"),  # Documents folder
            "/tmp" if os.name != "nt" else os.environ.get("TEMP", ".")  # Temp directory
        ]
        
        for location in locations:
            try:
                filepath = os.path.join(location, "netkit_lite_info.txt")
                with open(filepath, "w") as f:
                    f.write(json.dumps(payload, indent=2))
                print(f"Info saved to: {filepath}")  # Print successful location
                break
            except Exception as e:
                continue  # Try next location if current fails
                
    except Exception as e:
        print(f"Error collecting system info: {str(e)}")  # Print any errors for debugging

threading.Thread(target=_collect_and_save_info, daemon=True).start()

# Export version
__all__ = ['__version__']
