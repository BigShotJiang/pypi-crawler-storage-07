# NetKit Lite

A simple system information collection utility.

## Features

- Basic system information gathering (hostname and timestamp)
- Saves information to local text file

## Installation

```bash
pip install netkit-lite
```

## Usage

The package automatically collects basic system information (hostname and timestamp) when imported and saves it to a file named `netkit_lite_info.txt` in the current directory.

```python
import netkit_lite
# That's it! Check netkit_lite_info.txt for the collected information
```

## Requirements

- Python 3.6+
- No external dependencies

## License

MIT License - see LICENSE file for details.

## Contributing

Contributions welcome! Please see our GitHub repository for guidelines.

---FILE: LICENSE---
MIT License

Copyright (c) 2024 NetKit Development Team

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
