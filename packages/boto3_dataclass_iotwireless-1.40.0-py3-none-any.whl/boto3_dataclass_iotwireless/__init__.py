# -*- coding: utf-8 -*-

from .caster import iotwireless_caster

caster = iotwireless_caster

__version__ = "1.40.0"