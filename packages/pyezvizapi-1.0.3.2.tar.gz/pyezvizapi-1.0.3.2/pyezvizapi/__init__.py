"""Top-level package for the Ezviz Cloud API helpers.

This package provides a small, typed API surface around Ezviz cloud
endpoints tailored for Home Assistant and light scripting. The
submodules contain focused functionality (client, camera/light models,
MQTT push, CAS, utilities) and this package exports the most useful
symbols for convenient imports.
"""

from .camera import EzvizCamera
from .cas import EzvizCAS
from .client import EzvizClient
from .constants import (
    AlarmDetectHumanCar,
    BatteryCameraNewWorkMode,
    BatteryCameraWorkMode,
    DefenseModeType,
    DeviceCatagories,
    DeviceSwitchType,
    DisplayMode,
    IntelligentDetectionSmartApp,
    MessageFilterType,
    NightVisionMode,
    SoundMode,
    SupportExt,
)
from .exceptions import (
    AuthTestResultFailed,
    DeviceException,
    EzvizAuthTokenExpired,
    EzvizAuthVerificationCode,
    HTTPError,
    InvalidHost,
    InvalidURL,
    PyEzvizError,
)
from .feature import (
    day_night_mode_value,
    day_night_sensitivity_value,
    device_icr_dss_config,
    display_mode_value,
    has_osd_overlay,
    lens_defog_config,
    lens_defog_value,
    night_vision_config,
    night_vision_duration_value,
    night_vision_luminance_value,
    night_vision_mode_value,
    night_vision_payload,
    optionals_mapping,
    resolve_channel,
)
from .light_bulb import EzvizLightBulb
from .models import EzvizDeviceRecord, build_device_records_map
from .mqtt import EzvizToken, MQTTClient, MqttData, ServiceUrls
from .test_cam_rtsp import TestRTSPAuth

__all__ = [
    "AlarmDetectHumanCar",
    "AuthTestResultFailed",
    "BatteryCameraNewWorkMode",
    "BatteryCameraWorkMode",
    "DefenseModeType",
    "DeviceCatagories",
    "DeviceException",
    "DeviceSwitchType",
    "DisplayMode",
    "EzvizAuthTokenExpired",
    "EzvizAuthVerificationCode",
    "EzvizCAS",
    "EzvizCamera",
    "EzvizClient",
    "EzvizDeviceRecord",
    "EzvizLightBulb",
    "EzvizToken",
    "HTTPError",
    "IntelligentDetectionSmartApp",
    "InvalidHost",
    "InvalidURL",
    "MQTTClient",
    "MessageFilterType",
    "MqttData",
    "NightVisionMode",
    "PyEzvizError",
    "ServiceUrls",
    "SoundMode",
    "SupportExt",
    "TestRTSPAuth",
    "build_device_records_map",
    "day_night_mode_value",
    "day_night_sensitivity_value",
    "device_icr_dss_config",
    "display_mode_value",
    "has_osd_overlay",
    "lens_defog_config",
    "lens_defog_value",
    "night_vision_config",
    "night_vision_duration_value",
    "night_vision_luminance_value",
    "night_vision_mode_value",
    "night_vision_payload",
    "optionals_mapping",
    "resolve_channel",
]
