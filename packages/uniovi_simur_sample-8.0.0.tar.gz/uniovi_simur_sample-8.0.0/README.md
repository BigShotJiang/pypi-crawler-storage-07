<!-- These are examples of badges you might want to add to your README:
     please update the URLs accordingly

[![Built Status](https://api.cirrus-ci.com/github/<USER>/uniovi-simur-sample.svg?branch=main)](https://cirrus-ci.com/github/<USER>/uniovi-simur-sample)
[![ReadTheDocs](https://readthedocs.org/projects/uniovi-simur-sample/badge/?version=latest)](https://uniovi-simur-sample.readthedocs.io/en/stable/)
[![Coveralls](https://img.shields.io/coveralls/github/<USER>/uniovi-simur-sample/main.svg)](https://coveralls.io/r/<USER>/uniovi-simur-sample)
[![PyPI-Server](https://img.shields.io/pypi/v/uniovi-simur-sample.svg)](https://pypi.org/project/uniovi-simur-sample/)
[![Conda-Forge](https://img.shields.io/conda/vn/conda-forge/uniovi-simur-sample.svg)](https://anaconda.org/conda-forge/uniovi-simur-sample)
[![Monthly Downloads](https://pepy.tech/badge/uniovi-simur-sample/month)](https://pepy.tech/project/uniovi-simur-sample)
[![Twitter](https://img.shields.io/twitter/url/http/shields.io.svg?style=social&label=Twitter)](https://twitter.com/uniovi-simur-sample)
-->

[![Project generated with PyScaffold](https://img.shields.io/badge/-PyScaffold-005CA0?logo=pyscaffold)](https://pyscaffold.org/)

# uniovi-simur-sample

> Uiovi Simur Sample

A longer description of your project goes here...


<!-- pyscaffold-notes -->

## Note

This project has been set up using PyScaffold 4.6. For details and usage
information on PyScaffold see https://pyscaffold.org/.
