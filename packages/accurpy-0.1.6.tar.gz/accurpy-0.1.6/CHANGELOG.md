# Changelog

## 0.1.0
- First release: STRICT (≤1 ULP) & OPT (fast) C extension and Python fallback.
