from .fm import syncF

__all__ = ["syncF"]
__version__ = "0.1.6"
