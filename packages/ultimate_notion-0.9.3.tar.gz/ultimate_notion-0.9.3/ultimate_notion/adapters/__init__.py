"""All adapters for the Ultimate Notion project connecting it to other services."""

from ultimate_notion.config import get_cfg

__all__ = ['get_cfg']
