
# TUI module for dual-panel file manager