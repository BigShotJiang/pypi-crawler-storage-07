from loguru import logger

logger.disable('dt_tools.weather')