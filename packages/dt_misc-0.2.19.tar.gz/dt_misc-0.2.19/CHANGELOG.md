<h2>Changelog for dt-misc package</h2>
<dl>
<dt><b>10/16/24 | 0.1.9  | Updates from several versions</b></dt>
<dd>Add geolocation routines.  Get lat/lon information via address, landmark,... </dd>
<dd>Add weather routines.  Current, forecast and alerts.</dd>
<dd>Add sound routines to speak (TTS) and play files (mp3)</dd>
<dd>Sync with other dt-* packages</dd>
<dd>Docstring and comment updates</dd>
<br>
<dt><b>08/06/24 | 0.1.0</b></dt>
<dd>Initial upload</dd>
</dl>
