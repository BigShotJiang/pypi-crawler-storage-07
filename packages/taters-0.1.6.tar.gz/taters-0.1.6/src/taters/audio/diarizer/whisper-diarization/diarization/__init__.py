from .msdd.msdd import MSDDDiarizer

__all__ = ["MSDDDiarizer"]
