"""Special situation handling."""
