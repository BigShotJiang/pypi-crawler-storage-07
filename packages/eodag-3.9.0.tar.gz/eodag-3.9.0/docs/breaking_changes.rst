.. _breaking_changes:

.. include:: ../BREAKING_CHANGES.rst
