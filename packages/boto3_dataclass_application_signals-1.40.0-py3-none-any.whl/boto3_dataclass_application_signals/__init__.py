# -*- coding: utf-8 -*-

from .caster import application_signals_caster

caster = application_signals_caster

__version__ = "1.40.0"