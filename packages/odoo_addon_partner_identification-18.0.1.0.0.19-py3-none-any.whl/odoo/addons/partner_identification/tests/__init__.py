from . import test_partner_identification
from . import test_res_partner
