from . import res_partner_id_number
from . import res_partner_id_category
from . import res_partner
