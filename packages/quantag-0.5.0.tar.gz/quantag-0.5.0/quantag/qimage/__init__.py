from .compression import QImageCompressor

__all__ = ["QImageCompressor"]
