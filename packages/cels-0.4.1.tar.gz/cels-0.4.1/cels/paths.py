from pathlib import Path

package_path = Path(__file__).absolute().parent
data_path = package_path / "data"
