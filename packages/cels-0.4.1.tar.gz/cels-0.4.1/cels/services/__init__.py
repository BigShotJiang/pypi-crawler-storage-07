from .patch_dictionary import patch_dictionary
from .patch_document import patch_document
from .patch_yaml import patch_yaml
from .patch_json import patch_json
from .patch_toml import patch_toml
