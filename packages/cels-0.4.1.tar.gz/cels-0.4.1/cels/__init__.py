from .services import patch_dictionary
from .services import patch_document
from .services import patch_yaml
from .services import patch_json
from .services import patch_toml
from .version import __version__
