# 辅助读书做笔记的插件服务
from fastapi import APIRouter, Depends, HTTPException, status, Header
import os
from db_help.mysql import MySQLManager
import datetime
from pydantic import BaseModel
from dotenv import load_dotenv
load_dotenv(override = True)

async def check_current_user(token: str = Header(...)):
    if token != os.getenv("token"):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid X-Token header")
    return {"username":"zxf"}

router = APIRouter(
    tags=["Reader"],
    dependencies = [Depends(check_current_user)]
)

db_manager = MySQLManager(database = "Reader")

@router.get('/')
async def get_status():
    return "running"

class BookTips(BaseModel):
    text: str


def get_contents():
    today_start = datetime.datetime.combine(datetime.date.today(), datetime.time.min) # 今天 00:00:00
    tomorrow_start = datetime.datetime.combine(datetime.date.today() + datetime.timedelta(days=1), datetime.time.min) # 明天 00:00:00

    contents = db_manager.select(
        table_name="reader",
        conditions="time >= %s AND time < %s",
        params=(today_start, tomorrow_start),
        order_by="time ASC"
    )
    if contents:
        return contents
    else:
        return []

@router.post('/record')
async def record(request: BookTips):
    text = request.text

    # TODO 对内容做重复性校验
    # 实现思路
    # 1 从上一条被存入数据库的数据中提取出text内容 
    contents = get_contents()
    content = contents[-1]
    old_text = content.get('content')
    id = content.get('id')
    print(content,'contentcontentcontent')
    print(old_text in text,'ss')
    if old_text in text:
        # 3 则更新之前的text 数据而非插入新数据
        db_manager.update(table_name = "reader", 
                          data = {"content":text}, 
                          conditions="id = %s", params=(id,))
    else:
        db_manager.insert(table_name = "reader",
                    data={'time': datetime.datetime.now(),
                        "content":text})

    return "successful"


@router.get('/read')
async def read():

    contents = get_contents()

    content_list = [i.get("content") for i in contents]
    content = '\n\n'.join(content_list)
    return content


