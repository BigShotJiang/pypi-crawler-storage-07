"""Simple example."""
