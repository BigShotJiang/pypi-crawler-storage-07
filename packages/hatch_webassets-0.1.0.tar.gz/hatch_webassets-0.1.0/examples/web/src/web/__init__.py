"""Web example."""
