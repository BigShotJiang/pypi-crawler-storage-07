"""Acquisition upgraders"""
