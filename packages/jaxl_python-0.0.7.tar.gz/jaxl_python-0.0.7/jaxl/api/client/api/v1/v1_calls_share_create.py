"""
Copyright (c) 2010-present by Jaxl Innovations Private Limited.

All rights reserved.

Redistribution and use in source and binary forms,
with or without modification, is strictly prohibited.
"""

from http import HTTPStatus
from typing import Any, Dict, Optional, Union, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.call_recording_share_response import CallRecordingShareResponse
from ...types import Response


def _get_kwargs(
    id: int,
    *,
    client: AuthenticatedClient,
) -> Dict[str, Any]:
    url = "{}/v1/calls/{id}/share/".format(client.base_url, id=id)

    headers: Dict[str, str] = client.get_headers()
    cookies: Dict[str, Any] = client.get_cookies()

    return {
        "method": "post",
        "url": url,
        "headers": headers,
        "cookies": cookies,
        "timeout": client.get_timeout(),
    }


def _parse_response(
    *, client: Client, response: httpx.Response
) -> Optional[Union[Any, CallRecordingShareResponse]]:
    if response.status_code == HTTPStatus.OK:
        response_200 = CallRecordingShareResponse.from_dict(response.json())

        return response_200
    if response.status_code == HTTPStatus.CONFLICT:
        response_409 = cast(Any, None)
        return response_409
    if response.status_code == HTTPStatus.NOT_FOUND:
        response_404 = cast(Any, None)
        return response_404
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(f"Unexpected status code: {response.status_code}")
    else:
        return None


def _build_response(
    *, client: Client, response: httpx.Response
) -> Response[Union[Any, CallRecordingShareResponse]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: int,
    *,
    client: AuthenticatedClient,
) -> Response[Union[Any, CallRecordingShareResponse]]:
    """Share URL is a shortlink that takes user to a backend hosted page for shared recordings.
    This page can be visited anonymously (but always via a shortlink redirection).

    Finally, target page redirects user to recording on the cloud (for Jaxl recordings) or
    stream from provider (for Exotel, Twilio, Plivo).  Final provider recording URL is
    NEVER exposed to the end user.

    Args:
        id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, CallRecordingShareResponse]]
    """

    kwargs = _get_kwargs(
        id=id,
        client=client,
    )

    response = httpx.request(
        verify=client.verify_ssl,
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    id: int,
    *,
    client: AuthenticatedClient,
) -> Optional[Union[Any, CallRecordingShareResponse]]:
    """Share URL is a shortlink that takes user to a backend hosted page for shared recordings.
    This page can be visited anonymously (but always via a shortlink redirection).

    Finally, target page redirects user to recording on the cloud (for Jaxl recordings) or
    stream from provider (for Exotel, Twilio, Plivo).  Final provider recording URL is
    NEVER exposed to the end user.

    Args:
        id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, CallRecordingShareResponse]]
    """

    return sync_detailed(
        id=id,
        client=client,
    ).parsed


async def asyncio_detailed(
    id: int,
    *,
    client: AuthenticatedClient,
) -> Response[Union[Any, CallRecordingShareResponse]]:
    """Share URL is a shortlink that takes user to a backend hosted page for shared recordings.
    This page can be visited anonymously (but always via a shortlink redirection).

    Finally, target page redirects user to recording on the cloud (for Jaxl recordings) or
    stream from provider (for Exotel, Twilio, Plivo).  Final provider recording URL is
    NEVER exposed to the end user.

    Args:
        id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, CallRecordingShareResponse]]
    """

    kwargs = _get_kwargs(
        id=id,
        client=client,
    )

    async with httpx.AsyncClient(verify=client.verify_ssl) as _client:
        response = await _client.request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    id: int,
    *,
    client: AuthenticatedClient,
) -> Optional[Union[Any, CallRecordingShareResponse]]:
    """Share URL is a shortlink that takes user to a backend hosted page for shared recordings.
    This page can be visited anonymously (but always via a shortlink redirection).

    Finally, target page redirects user to recording on the cloud (for Jaxl recordings) or
    stream from provider (for Exotel, Twilio, Plivo).  Final provider recording URL is
    NEVER exposed to the end user.

    Args:
        id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, CallRecordingShareResponse]]
    """

    return (
        await asyncio_detailed(
            id=id,
            client=client,
        )
    ).parsed
