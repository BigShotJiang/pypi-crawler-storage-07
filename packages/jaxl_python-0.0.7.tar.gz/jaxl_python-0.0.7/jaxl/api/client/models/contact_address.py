"""
Copyright (c) 2010-present by Jaxl Innovations Private Limited.

All rights reserved.

Redistribution and use in source and binary forms,
with or without modification, is strictly prohibited.
"""

from typing import Any, Dict, List, Type, TypeVar

import attr


T = TypeVar("T", bound="ContactAddress")


@attr.s(auto_attribs=True)
class ContactAddress:
    """
    Attributes:
        label (str):
        street (str):
        city (str):
        region (str):
        country (str):
        postcode (str):
    """

    label: str
    street: str
    city: str
    region: str
    country: str
    postcode: str
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        label = self.label
        street = self.street
        city = self.city
        region = self.region
        country = self.country
        postcode = self.postcode

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "label": label,
                "street": street,
                "city": city,
                "region": region,
                "country": country,
                "postcode": postcode,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        label = d.pop("label")

        street = d.pop("street")

        city = d.pop("city")

        region = d.pop("region")

        country = d.pop("country")

        postcode = d.pop("postcode")

        contact_address = cls(
            label=label,
            street=street,
            city=city,
            region=region,
            country=country,
            postcode=postcode,
        )

        contact_address.additional_properties = d
        return contact_address

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
