"""
Copyright (c) 2010-present by Jaxl Innovations Private Limited.

All rights reserved.

Redistribution and use in source and binary forms,
with or without modification, is strictly prohibited.
"""

from typing import Any, Dict, List, Type, TypeVar, Union, cast

import attr

from ..types import UNSET, Unset


T = TypeVar("T", bound="ConversationCreateRequest")


@attr.s(auto_attribs=True)
class ConversationCreateRequest:
    """
    Attributes:
        type (int):
        sender (str):
        receivers (List[str]):
        name (Union[Unset, str]):
    """

    type: int
    sender: str
    receivers: List[str]
    name: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        type = self.type
        sender = self.sender
        receivers = self.receivers

        name = self.name

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "type": type,
                "sender": sender,
                "receivers": receivers,
            }
        )
        if name is not UNSET:
            field_dict["name"] = name

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        type = d.pop("type")

        sender = d.pop("sender")

        receivers = cast(List[str], d.pop("receivers"))

        name = d.pop("name", UNSET)

        conversation_create_request = cls(
            type=type,
            sender=sender,
            receivers=receivers,
            name=name,
        )

        conversation_create_request.additional_properties = d
        return conversation_create_request

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
