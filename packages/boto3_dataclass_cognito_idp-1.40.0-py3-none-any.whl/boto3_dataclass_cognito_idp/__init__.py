# -*- coding: utf-8 -*-

from .caster import cognito_idp_caster

caster = cognito_idp_caster

__version__ = "1.40.0"