default_app_config = 'transcribe.apps.transcribeConfig'
__version__ = '0.8.6'
