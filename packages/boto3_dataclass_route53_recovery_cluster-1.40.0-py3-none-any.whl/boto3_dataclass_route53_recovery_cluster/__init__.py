# -*- coding: utf-8 -*-

from .caster import route53_recovery_cluster_caster

caster = route53_recovery_cluster_caster

__version__ = "1.40.0"