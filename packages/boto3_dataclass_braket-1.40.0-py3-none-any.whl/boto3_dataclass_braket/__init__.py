# -*- coding: utf-8 -*-

from .caster import braket_caster

caster = braket_caster

__version__ = "1.40.0"