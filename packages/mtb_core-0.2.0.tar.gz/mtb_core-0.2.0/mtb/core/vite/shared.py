from mtb.core import mklog

log = mklog(
    "⚡ Vite",
)
