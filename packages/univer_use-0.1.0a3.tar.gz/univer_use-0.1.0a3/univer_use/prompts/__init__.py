from .template import get_rendered_template

__all__ = ["get_rendered_template"]