# src/mcp_get_weather/__main__.py
from mcp_get_weather.server import main

main()

