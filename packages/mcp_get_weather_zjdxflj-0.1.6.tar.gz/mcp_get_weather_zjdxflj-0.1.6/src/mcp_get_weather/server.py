# src/weather_server/server.py
from __future__ import annotations

import argparse
import asyncio
import json
import os
from typing import Any, Dict, Optional

import httpx
from mcp.server.fastmcp import FastMCP

# =========================
# 基本配置
# =========================
mcp = FastMCP("WeatherServer")

OPENWEATHER_API_BASE = "https://api.openweathermap.org/data/2.5/weather"
DEFAULT_TIMEOUT = 20.0          # 单次请求超时（秒）
MAX_RETRIES = 2                 # 网络类错误的最大重试次数
USER_AGENT = "weather-app/1.0"

# 你的 OpenWeather API Key（硬编码）
HARD_CODED_API_KEY = "2c3fd8c1947184a5f455342b77b128d3"

# 通过 main()、环境变量或硬编码注入，默认使用硬编码值
_API_KEY: Optional[str] = HARD_CODED_API_KEY


# =========================
# 工具函数
# =========================
def _normalize_api_key(arg_key: Optional[str]) -> Optional[str]:
    """
    读取 API Key 的优先级：
    1) 启动参数 --api_key
    2) 环境变量 OPENWEATHER_API_KEY
    3) 模块级变量 _API_KEY（默认已是硬编码值）
    """
    if arg_key:
        return arg_key.strip()

    env_key = os.getenv("OPENWEATHER_API_KEY", "").strip()
    if env_key:
        return env_key

    return _API_KEY


def _validate_city(city: str) -> str:
    """
    基础参数校验与清洗：去两端空白、长度限制、去除非法控制字符等。
    """
    if city is None:
        raise ValueError("城市名称不能为空。")

    cleaned = "".join(ch for ch in city.strip() if ch.isprintable())
    if not cleaned:
        raise ValueError("城市名称仅包含不可打印字符或为空。")

    if len(cleaned) > 80:
        raise ValueError("城市名称过长，请控制在 80 个字符以内。")

    return cleaned


async def _http_get(client: httpx.AsyncClient, url: str, **kwargs) -> httpx.Response:
    """
    简单的带重试 GET 封装：针对可恢复的网络错误进行有限次重试。
    """
    last_exc: Optional[Exception] = None
    for attempt in range(MAX_RETRIES + 1):
        try:
            resp = await client.get(url, **kwargs)
            return resp
        except (httpx.ConnectError, httpx.ReadTimeout, httpx.RemoteProtocolError) as e:
            last_exc = e
            if attempt < MAX_RETRIES:
                await asyncio.sleep(0.8 * (attempt + 1))  # 线性退避
            else:
                raise
    # 理论上不会走到这里
    raise last_exc if last_exc else RuntimeError("未知的网络错误")


async def fetch_weather(city: str, api_key: Optional[str]) -> Dict[str, Any]:
    """
    从 OpenWeather API 获取天气信息，返回标准化的 dict。
    出错时也返回 {"error": "..."} 结构，便于前端/调用方处理。
    """
    try:
        city = _validate_city(city)
    except Exception as e:
        return {"error": f"参数错误：{e}"}

    key = _normalize_api_key(api_key)
    if not key:
        return {"error": "API_KEY 未设置。请通过 --api_key、环境变量 OPENWEATHER_API_KEY 或硬编码值提供有效的 Key。"}

    params = {
        "q": city,
        "appid": key,
        "units": "metric",
        "lang": "zh_cn",
    }
    headers = {"User-Agent": USER_AGENT}

    timeout = httpx.Timeout(DEFAULT_TIMEOUT)
    async with httpx.AsyncClient(timeout=timeout, headers=headers, follow_redirects=True) as client:
        try:
            resp = await _http_get(client, OPENWEATHER_API_BASE, params=params)
            resp.raise_for_status()  # 非 2xx 抛错
        except httpx.HTTPStatusError as e:
            try:
                payload = e.response.json()
            except Exception:
                payload = {"message": e.response.text}
            return {
                "error": f"HTTP 错误：{e.response.status_code}",
                "detail": payload,
            }
        except Exception as e:
            return {"error": f"请求失败：{type(e).__name__}: {e}"}

        # 解析 JSON
        try:
            data = resp.json()
            if not isinstance(data, dict):
                return {"error": "API 返回了非对象类型的 JSON。"}
            return data
        except Exception as e:
            return {"error": f"响应解析失败：{e}"}


def format_weather(data: Dict[str, Any] | str) -> str:
    """
    将天气数据格式化为易读文本。
    输入可以是 dict 或 JSON 字符串；错误统一以“⚠️ …”呈现。
    """
    if isinstance(data, str):
        try:
            data = json.loads(data)
        except Exception as e:
            return f"⚠️ 无法解析天气数据：{e}"

    if not isinstance(data, dict):
        return "⚠️ 内部错误：数据结构异常。"

    if "error" in data:
        base = f"⚠️ {data.get('error')}"
        detail = data.get("detail")
        if isinstance(detail, dict):
            msg = detail.get("message") or detail.get("cod") or str(detail)
            return f"{base} | 详情：{msg}"
        return base

    city = data.get("name") or "未知"
    country = (data.get("sys") or {}).get("country") or "未知"
    main = data.get("main") or {}
    wind = data.get("wind") or {}
    weather_list = data.get("weather") or [{}]

    temp = main.get("temp", "N/A")
    humidity = main.get("humidity", "N/A")
    wind_speed = wind.get("speed", "N/A")
    description = (weather_list[0] or {}).get("description", "未知")

    return (
        f"🌍 {city}, {country}\n"
        f"🌡 温度: {temp}°C\n"
        f"💧 湿度: {humidity}%\n"
        f"🌬 风速: {wind_speed} m/s\n"
        f"🌤 天气: {description}\n"
    )


# =========================
# MCP 工具
# =========================
@mcp.tool()
async def query_weather(city: str) -> str:
    """
    输入指定城市（英文/本地语言均可），返回今日天气查询结果（文本）。
    - 正常返回：多行可读文本
    - 出错返回：以“⚠️ …”开头的错误说明
    """
    data = await fetch_weather(city, api_key=None)
    return format_weather(data)


# =========================
# 启动入口
# =========================
def main() -> None:
    parser = argparse.ArgumentParser(description="Weather Server (MCP over SSE)")
    parser.add_argument(
        "--api_key",
        type=str,
        required=False,
        help="你的 OpenWeather API Key（会覆盖环境变量与硬编码的值）",
    )
    parser.add_argument("--host", type=str, default=None, help="SSE host，可留空使用默认")
    parser.add_argument("--port", type=int, default=None, help="SSE port，可留空使用默认")
    args = parser.parse_args()

    # 将 API Key 注入到模块级变量，便于 @mcp.tool 中调用
    global _API_KEY
    _API_KEY = _normalize_api_key(args.api_key)

    # 启动 SSE（如需 STDIO，可改 transport='stdio'）
    mcp.run(transport="sse")


if __name__ == "__main__":
    main()
