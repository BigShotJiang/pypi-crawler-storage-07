
####    VERSION
VERSION = "0.1.1"

####    USER AGENT
USER_AGENT = f"Forklet-GitHub-Downloader/{VERSION}"