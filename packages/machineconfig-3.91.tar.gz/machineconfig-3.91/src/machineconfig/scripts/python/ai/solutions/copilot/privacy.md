
# Go to settings of github copilot and disable telemetry usage and report
# simliarly, disable using data for training.
# remember to do this per account.
