from machineconfig.scripts.python.devops_backup_retrieve import main_backup_retrieve

program = main_backup_retrieve(direction="BACKUP", which="all")
