# try ventory or netboot.xyz

# # one can either install rufus: https://rufus.ie/en/
# # however, to create bootable media with multiple OSs to choose from:

# PathExtended(r'https://github.com/ventoy/Ventoy/archive/refs/tags/v1.0.78.zip').download().unzip().search[0]()
# download_folder = PathExtended.home().joinpath("Downloads/os")
# download_folder.mkdir(parents=True, exist_ok=True)
# PathExtended(r'https://mirrors.layeronline.com/linuxmint/stable/21/linuxmint-21-cinnamon-64bit.iso').download(folder=download_folder)
# download_folder2 = PathExtended.home().joinpath("Downloads/os")
# download_folder2.mkdir(parents=True, exist_ok=True)
# PathExtended(r'https://download.manjaro.org/kde/21.3.7/manjaro-kde-21.3.7-minimal-220816-linux515.iso').download(folder=download_folder2)


# if __name__ == '__main__':
#     pass
