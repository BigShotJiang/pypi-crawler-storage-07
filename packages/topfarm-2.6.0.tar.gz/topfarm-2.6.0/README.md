[![pipeline status](https://gitlab.windenergy.dtu.dk/TOPFARM/TopFarm2/badges/master/pipeline.svg)](https://gitlab.windenergy.dtu.dk/TOPFARM/TopFarm2/commits/master)
[![coverage report](https://gitlab.windenergy.dtu.dk/TOPFARM/TopFarm2/badges/master/coverage.svg)](https://gitlab.windenergy.dtu.dk/TOPFARM/TopFarm2/commits/master)
[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/git/https%3A%2F%2Fgitlab.windenergy.dtu.dk%2FTOPFARM%2FTopFarm2.git/HEAD)

Welcome to TOPFARM
------------------

This is the plant-level optimization tool that is being developed by DTU Wind
Energy.

# Installation Guide, Examples, and Documentation

Please refer to the 
[TOPFARM documentation](https://topfarm.pages.windenergy.dtu.dk/TopFarm2).