import os
examples_filepath = os.path.dirname(__file__).replace("\\", "/") + '/'
