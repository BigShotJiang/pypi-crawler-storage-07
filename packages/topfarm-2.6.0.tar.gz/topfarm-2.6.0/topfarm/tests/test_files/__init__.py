import os
tfp = testfilepath = os.path.dirname(__file__) + "/"
