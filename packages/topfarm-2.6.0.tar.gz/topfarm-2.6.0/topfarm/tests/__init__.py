from numpy import testing
import unittest

npt = testing
uta = unittest.TestCase('__init__')
