

Drivers
====================

EasyDrivers
-----------

**EasyScipyOptimizeDriver**


.. autoclass:: topfarm.easy_drivers.EasyScipyOptimizeDriver
    :members:
    
    .. automethod:: __init__
	
    
    


**EasyPyOptSparseIPOPT**

.. autoclass:: topfarm.easy_drivers.EasyPyOptSparseIPOPT
    :members:
    
    .. automethod:: __init__
    
    
**EasySimpleGADriver**

.. autoclass:: topfarm.easy_drivers.EasySimpleGADriver
    :members:
    
    .. automethod:: __init__




**EasyRandomSearchDriver**

.. autoclass:: topfarm.easy_drivers.EasyRandomSearchDriver
    :members:
    
    .. automethod:: __init__

**EasySGDDriver**

.. autoclass:: topfarm.easy_drivers.EasySGDDriver
    :members:
    
    .. automethod:: __init__


