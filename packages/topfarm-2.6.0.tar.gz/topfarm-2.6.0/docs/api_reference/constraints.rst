

Constraints
====================

Boundary constraints
--------------------

**XYBoundaryConstraint**


.. autoclass:: topfarm.constraint_components.boundary.XYBoundaryConstraint
    :members:
        
    .. automethod:: __init__
	
    
    


**CircleBoundaryConstraint**


.. autoclass:: topfarm.constraint_components.boundary.CircleBoundaryConstraint
    :members:
        
    .. automethod:: __init__
    

    
Other constraints
-----------------


**SpacingConstraint**

.. autoclass:: topfarm.constraint_components.spacing.SpacingConstraint
    :members:
        
    .. automethod:: __init__
