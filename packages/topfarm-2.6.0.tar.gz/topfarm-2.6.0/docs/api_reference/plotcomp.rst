

Plotting Components
====================

**NoPlot**

.. autoclass:: topfarm.plotting.NoPlot
    
    .. automethod:: __init__


**XYPlotComp**

.. autoclass:: topfarm.plotting.XYPlotComp
    
    .. automethod:: __init__
	

**TurbineTypePlotComponent**

.. autoclass:: topfarm.plotting.TurbineTypePlotComponent
    
    .. automethod:: __init__
	
    
    
    


