

TopFarmProblem
====================

.. autoclass:: topfarm.TopFarmProblem
    
    .. autosummary::
        __init__
        evaluate
		optimize
        
    .. automethod:: __init__
	
	.. automethod:: evaluate
	
	.. automethod:: optimize
	
    
    
    


