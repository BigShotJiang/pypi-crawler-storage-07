def add(a,b):
    add=a+b
    return add

print(add(3,4))
    