# -*- coding: utf-8 -*-

from .caster import omics_caster

caster = omics_caster

__version__ = "1.40.0"