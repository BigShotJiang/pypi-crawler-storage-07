# -*- coding: utf-8 -*-

from .caster import mwaa_caster

caster = mwaa_caster

__version__ = "1.40.0"