"""{{ cookiecutter.name }} Mapper."""
