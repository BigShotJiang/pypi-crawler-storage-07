#!/usr/bin/env python
# encoding: utf-8
#
# Copyright SAS Institute
#
#  Licensed under the Apache License, Version 2.0 (the License);
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
#

'''
Additional types for CAS support

'''

from __future__ import (print_function, division, absolute_import,
                        unicode_literals)

import six


@six.python_2_unicode_compatible
class NilType(object):
    '''
    Type for `nil` valued parameters

    The swat module contains a singleton of the NilType class called `nil`.

    Examples
    --------
    Send a nil as a parameter value

    >>> s.action(param=swat.nil)

    '''

    def __repr__(self):
        return str(self)

    def __str__(self):
        return 'nil'


# nil singleton
nil = NilType()


class blob(bytes):
    '''
    Explicitly defined type for blob parameters

    '''
