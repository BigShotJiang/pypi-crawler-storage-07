from dlubal.api.common import common_pb2 as _common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SteelJoint(_message.Message):
    __slots__ = ("no", "user_defined_name_enabled", "name", "to_design", "nodes", "all_nodes_to_design", "nodes_to_design", "ultimate_configuration", "stiffness_analysis_configuration", "comment", "members", "components", "id_for_export_import", "metadata_for_export_import")
    class MembersTable(_message.Message):
        __slots__ = ("rows",)
        ROWS_FIELD_NUMBER: _ClassVar[int]
        rows: _containers.RepeatedCompositeFieldContainer[SteelJoint.MembersRow]
        def __init__(self, rows: _Optional[_Iterable[_Union[SteelJoint.MembersRow, _Mapping]]] = ...) -> None: ...
    class MembersRow(_message.Message):
        __slots__ = ("no", "description", "is_active", "status", "members_no", "end_type", "supported", "comment", "errors", "sections_interaction")
        class EndType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
            __slots__ = ()
            END_TYPE_UNKNOWN: _ClassVar[SteelJoint.MembersRow.EndType]
            END_TYPE_MEMBER_CONTINUOUS: _ClassVar[SteelJoint.MembersRow.EndType]
            END_TYPE_MEMBER_ENDED: _ClassVar[SteelJoint.MembersRow.EndType]
        END_TYPE_UNKNOWN: SteelJoint.MembersRow.EndType
        END_TYPE_MEMBER_CONTINUOUS: SteelJoint.MembersRow.EndType
        END_TYPE_MEMBER_ENDED: SteelJoint.MembersRow.EndType
        class SectionsInteraction(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
            __slots__ = ()
            SECTIONS_INTERACTION_UNKNOWN: _ClassVar[SteelJoint.MembersRow.SectionsInteraction]
        SECTIONS_INTERACTION_UNKNOWN: SteelJoint.MembersRow.SectionsInteraction
        NO_FIELD_NUMBER: _ClassVar[int]
        DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
        IS_ACTIVE_FIELD_NUMBER: _ClassVar[int]
        STATUS_FIELD_NUMBER: _ClassVar[int]
        MEMBERS_NO_FIELD_NUMBER: _ClassVar[int]
        END_TYPE_FIELD_NUMBER: _ClassVar[int]
        SUPPORTED_FIELD_NUMBER: _ClassVar[int]
        COMMENT_FIELD_NUMBER: _ClassVar[int]
        ERRORS_FIELD_NUMBER: _ClassVar[int]
        SECTIONS_INTERACTION_FIELD_NUMBER: _ClassVar[int]
        no: int
        description: str
        is_active: bool
        status: str
        members_no: _containers.RepeatedScalarFieldContainer[int]
        end_type: SteelJoint.MembersRow.EndType
        supported: bool
        comment: str
        errors: _common_pb2.Value
        sections_interaction: SteelJoint.MembersRow.SectionsInteraction
        def __init__(self, no: _Optional[int] = ..., description: _Optional[str] = ..., is_active: bool = ..., status: _Optional[str] = ..., members_no: _Optional[_Iterable[int]] = ..., end_type: _Optional[_Union[SteelJoint.MembersRow.EndType, str]] = ..., supported: bool = ..., comment: _Optional[str] = ..., errors: _Optional[_Union[_common_pb2.Value, _Mapping]] = ..., sections_interaction: _Optional[_Union[SteelJoint.MembersRow.SectionsInteraction, str]] = ...) -> None: ...
    class ComponentsTable(_message.Message):
        __slots__ = ("rows",)
        ROWS_FIELD_NUMBER: _ClassVar[int]
        rows: _containers.RepeatedCompositeFieldContainer[SteelJoint.ComponentsRow]
        def __init__(self, rows: _Optional[_Iterable[_Union[SteelJoint.ComponentsRow, _Mapping]]] = ...) -> None: ...
    class ComponentsRow(_message.Message):
        __slots__ = ("no", "description", "is_active", "type", "name", "settings_attributes", "errors")
        class Type(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
            __slots__ = ()
            TYPE_MEMBER_CUT: _ClassVar[SteelJoint.ComponentsRow.Type]
            TYPE_ANCHOR_BOLT: _ClassVar[SteelJoint.ComponentsRow.Type]
            TYPE_AUXILIARY_PLANE: _ClassVar[SteelJoint.ComponentsRow.Type]
            TYPE_AUXILIARY_SOLID: _ClassVar[SteelJoint.ComponentsRow.Type]
            TYPE_BASE_PLATE: _ClassVar[SteelJoint.ComponentsRow.Type]
            TYPE_BOLT: _ClassVar[SteelJoint.ComponentsRow.Type]
            TYPE_CAP_PLATE: _ClassVar[SteelJoint.ComponentsRow.Type]
            TYPE_CLEAT: _ClassVar[SteelJoint.ComponentsRow.Type]
            TYPE_CONCRETE_BLOCK: _ClassVar[SteelJoint.ComponentsRow.Type]
            TYPE_CONNECTING_PLATE: _ClassVar[SteelJoint.ComponentsRow.Type]
            TYPE_CONTACT: _ClassVar[SteelJoint.ComponentsRow.Type]
            TYPE_ELEMENTARY_WELD: _ClassVar[SteelJoint.ComponentsRow.Type]
            TYPE_END_PLATE: _ClassVar[SteelJoint.ComponentsRow.Type]
            TYPE_END_PLATE_TO_PLATE: _ClassVar[SteelJoint.ComponentsRow.Type]
            TYPE_FASTENER_GROUP: _ClassVar[SteelJoint.ComponentsRow.Type]
            TYPE_FIN_PLATE: _ClassVar[SteelJoint.ComponentsRow.Type]
            TYPE_HAUNCH: _ClassVar[SteelJoint.ComponentsRow.Type]
            TYPE_INSERTED_MEMBER: _ClassVar[SteelJoint.ComponentsRow.Type]
            TYPE_MEMBER: _ClassVar[SteelJoint.ComponentsRow.Type]
            TYPE_MEMBER_EDITOR: _ClassVar[SteelJoint.ComponentsRow.Type]
            TYPE_PLATE: _ClassVar[SteelJoint.ComponentsRow.Type]
            TYPE_PLATE_CUT: _ClassVar[SteelJoint.ComponentsRow.Type]
            TYPE_PLATE_EDITOR: _ClassVar[SteelJoint.ComponentsRow.Type]
            TYPE_PLATE_TO_PLATE: _ClassVar[SteelJoint.ComponentsRow.Type]
            TYPE_RIB: _ClassVar[SteelJoint.ComponentsRow.Type]
            TYPE_SECTION_ROUNDING: _ClassVar[SteelJoint.ComponentsRow.Type]
            TYPE_STIFFENER: _ClassVar[SteelJoint.ComponentsRow.Type]
            TYPE_STUB: _ClassVar[SteelJoint.ComponentsRow.Type]
        TYPE_MEMBER_CUT: SteelJoint.ComponentsRow.Type
        TYPE_ANCHOR_BOLT: SteelJoint.ComponentsRow.Type
        TYPE_AUXILIARY_PLANE: SteelJoint.ComponentsRow.Type
        TYPE_AUXILIARY_SOLID: SteelJoint.ComponentsRow.Type
        TYPE_BASE_PLATE: SteelJoint.ComponentsRow.Type
        TYPE_BOLT: SteelJoint.ComponentsRow.Type
        TYPE_CAP_PLATE: SteelJoint.ComponentsRow.Type
        TYPE_CLEAT: SteelJoint.ComponentsRow.Type
        TYPE_CONCRETE_BLOCK: SteelJoint.ComponentsRow.Type
        TYPE_CONNECTING_PLATE: SteelJoint.ComponentsRow.Type
        TYPE_CONTACT: SteelJoint.ComponentsRow.Type
        TYPE_ELEMENTARY_WELD: SteelJoint.ComponentsRow.Type
        TYPE_END_PLATE: SteelJoint.ComponentsRow.Type
        TYPE_END_PLATE_TO_PLATE: SteelJoint.ComponentsRow.Type
        TYPE_FASTENER_GROUP: SteelJoint.ComponentsRow.Type
        TYPE_FIN_PLATE: SteelJoint.ComponentsRow.Type
        TYPE_HAUNCH: SteelJoint.ComponentsRow.Type
        TYPE_INSERTED_MEMBER: SteelJoint.ComponentsRow.Type
        TYPE_MEMBER: SteelJoint.ComponentsRow.Type
        TYPE_MEMBER_EDITOR: SteelJoint.ComponentsRow.Type
        TYPE_PLATE: SteelJoint.ComponentsRow.Type
        TYPE_PLATE_CUT: SteelJoint.ComponentsRow.Type
        TYPE_PLATE_EDITOR: SteelJoint.ComponentsRow.Type
        TYPE_PLATE_TO_PLATE: SteelJoint.ComponentsRow.Type
        TYPE_RIB: SteelJoint.ComponentsRow.Type
        TYPE_SECTION_ROUNDING: SteelJoint.ComponentsRow.Type
        TYPE_STIFFENER: SteelJoint.ComponentsRow.Type
        TYPE_STUB: SteelJoint.ComponentsRow.Type
        NO_FIELD_NUMBER: _ClassVar[int]
        DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
        IS_ACTIVE_FIELD_NUMBER: _ClassVar[int]
        TYPE_FIELD_NUMBER: _ClassVar[int]
        NAME_FIELD_NUMBER: _ClassVar[int]
        SETTINGS_ATTRIBUTES_FIELD_NUMBER: _ClassVar[int]
        ERRORS_FIELD_NUMBER: _ClassVar[int]
        no: int
        description: str
        is_active: bool
        type: SteelJoint.ComponentsRow.Type
        name: str
        settings_attributes: str
        errors: str
        def __init__(self, no: _Optional[int] = ..., description: _Optional[str] = ..., is_active: bool = ..., type: _Optional[_Union[SteelJoint.ComponentsRow.Type, str]] = ..., name: _Optional[str] = ..., settings_attributes: _Optional[str] = ..., errors: _Optional[str] = ...) -> None: ...
    NO_FIELD_NUMBER: _ClassVar[int]
    USER_DEFINED_NAME_ENABLED_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    TO_DESIGN_FIELD_NUMBER: _ClassVar[int]
    NODES_FIELD_NUMBER: _ClassVar[int]
    ALL_NODES_TO_DESIGN_FIELD_NUMBER: _ClassVar[int]
    NODES_TO_DESIGN_FIELD_NUMBER: _ClassVar[int]
    ULTIMATE_CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    STIFFNESS_ANALYSIS_CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    COMMENT_FIELD_NUMBER: _ClassVar[int]
    MEMBERS_FIELD_NUMBER: _ClassVar[int]
    COMPONENTS_FIELD_NUMBER: _ClassVar[int]
    ID_FOR_EXPORT_IMPORT_FIELD_NUMBER: _ClassVar[int]
    METADATA_FOR_EXPORT_IMPORT_FIELD_NUMBER: _ClassVar[int]
    no: int
    user_defined_name_enabled: bool
    name: str
    to_design: bool
    nodes: _containers.RepeatedScalarFieldContainer[int]
    all_nodes_to_design: bool
    nodes_to_design: _containers.RepeatedScalarFieldContainer[int]
    ultimate_configuration: int
    stiffness_analysis_configuration: int
    comment: str
    members: SteelJoint.MembersTable
    components: SteelJoint.ComponentsTable
    id_for_export_import: str
    metadata_for_export_import: str
    def __init__(self, no: _Optional[int] = ..., user_defined_name_enabled: bool = ..., name: _Optional[str] = ..., to_design: bool = ..., nodes: _Optional[_Iterable[int]] = ..., all_nodes_to_design: bool = ..., nodes_to_design: _Optional[_Iterable[int]] = ..., ultimate_configuration: _Optional[int] = ..., stiffness_analysis_configuration: _Optional[int] = ..., comment: _Optional[str] = ..., members: _Optional[_Union[SteelJoint.MembersTable, _Mapping]] = ..., components: _Optional[_Union[SteelJoint.ComponentsTable, _Mapping]] = ..., id_for_export_import: _Optional[str] = ..., metadata_for_export_import: _Optional[str] = ...) -> None: ...
