from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor

class ObjectType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    OBJECT_TYPE_UNKNOWN: _ClassVar[ObjectType]
    OBJECT_TYPE_BAR: _ClassVar[ObjectType]
    OBJECT_TYPE_DIMENSION: _ClassVar[ObjectType]
    OBJECT_TYPE_DXF_FILE_MODEL_OBJECT: _ClassVar[ObjectType]
    OBJECT_TYPE_ELEMENT: _ClassVar[ObjectType]
    OBJECT_TYPE_GROUP_OF_OBJECT_SELECTIONS: _ClassVar[ObjectType]
    OBJECT_TYPE_LINE: _ClassVar[ObjectType]
    OBJECT_TYPE_LOAD_CASE: _ClassVar[ObjectType]
    OBJECT_TYPE_LOAD_COMBINATION: _ClassVar[ObjectType]
    OBJECT_TYPE_MATERIAL: _ClassVar[ObjectType]
    OBJECT_TYPE_OBJECT_SNAP: _ClassVar[ObjectType]
    OBJECT_TYPE_OPENING: _ClassVar[ObjectType]
    OBJECT_TYPE_PART: _ClassVar[ObjectType]
    OBJECT_TYPE_POINT: _ClassVar[ObjectType]
    OBJECT_TYPE_SECTION: _ClassVar[ObjectType]
    OBJECT_TYPE_STIRRUP: _ClassVar[ObjectType]
    OBJECT_TYPE_STRESS_POINT: _ClassVar[ObjectType]
OBJECT_TYPE_UNKNOWN: ObjectType
OBJECT_TYPE_BAR: ObjectType
OBJECT_TYPE_DIMENSION: ObjectType
OBJECT_TYPE_DXF_FILE_MODEL_OBJECT: ObjectType
OBJECT_TYPE_ELEMENT: ObjectType
OBJECT_TYPE_GROUP_OF_OBJECT_SELECTIONS: ObjectType
OBJECT_TYPE_LINE: ObjectType
OBJECT_TYPE_LOAD_CASE: ObjectType
OBJECT_TYPE_LOAD_COMBINATION: ObjectType
OBJECT_TYPE_MATERIAL: ObjectType
OBJECT_TYPE_OBJECT_SNAP: ObjectType
OBJECT_TYPE_OPENING: ObjectType
OBJECT_TYPE_PART: ObjectType
OBJECT_TYPE_POINT: ObjectType
OBJECT_TYPE_SECTION: ObjectType
OBJECT_TYPE_STIRRUP: ObjectType
OBJECT_TYPE_STRESS_POINT: ObjectType
