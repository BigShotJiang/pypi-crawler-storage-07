# -*- coding: utf-8 -*-

from .caster import marketplace_catalog_caster

caster = marketplace_catalog_caster

__version__ = "1.40.0"