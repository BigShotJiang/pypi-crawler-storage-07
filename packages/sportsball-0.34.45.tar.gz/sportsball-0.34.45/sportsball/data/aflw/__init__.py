"""The aflw data sportsball module."""

# ruff: noqa: F401
from .combined.aflw_combined_league_model import \
    AFLWCombinedLeagueModel as AFLWLeagueModel
