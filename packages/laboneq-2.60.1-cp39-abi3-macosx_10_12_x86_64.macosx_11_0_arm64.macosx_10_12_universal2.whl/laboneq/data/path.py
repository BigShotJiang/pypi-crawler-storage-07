# Copyright 2023 Zurich Instruments AG
# SPDX-License-Identifier: Apache-2.0

# Path separator between groups and values
Separator = "/"
