# -*- coding: utf-8 -*-

from .caster import marketplace_agreement_caster

caster = marketplace_agreement_caster

__version__ = "1.40.0"