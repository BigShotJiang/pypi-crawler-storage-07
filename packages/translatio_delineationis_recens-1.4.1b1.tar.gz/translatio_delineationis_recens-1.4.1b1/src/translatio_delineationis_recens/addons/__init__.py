# Copyright (C) 2011-2022, Manfred Moitzi
# License: MIT License
"""
ezDXF Addons Package
--------------------
A collection of optional extensions and advanced features for ezDXF.
Includes specialized tools, advanced geometry, import/export helpers, and utilities that extend core functionality.
"""
from .mtextsurrogate import MTextSurrogate
from .tablepainter import TablePainter, CustomCell
from .menger_sponge import MengerSponge
from .sierpinski_pyramid import SierpinskyPyramid
from .dimlines import LinearDimension, AngularDimension, ArcDimension, RadialDimension, dimstyles
from .importer import Importer
from .r12writer import r12writer
from .mtxpl import MTextExplode
