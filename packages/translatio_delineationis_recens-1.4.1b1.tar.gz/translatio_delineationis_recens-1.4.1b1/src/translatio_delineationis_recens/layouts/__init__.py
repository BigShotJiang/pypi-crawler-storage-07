# Copyright (c) 2011-2022, Manfred Moitzi
# License: MIT License
"""
ezDXF Layouts Package
---------------------
Provides abstractions for modelspace and paperspace layouts in DXF documents.
Enables entity management, layout switching, and viewport handling for drawing sheets and models.
"""
from .base import BaseLayout, VirtualLayout
from .layout import Layout, Modelspace, Paperspace
from .blocklayout import BlockLayout
from .layouts import Layouts
