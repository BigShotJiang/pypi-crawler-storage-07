# Copyright (C) 2011-2025, Translatio Delineationis Recens Team
# License: MIT License
"""Translatio Delineationis Recens is a comprehensive DXF library for Python.

This package provides tools for reading, writing, and manipulating DXF files.
It's designed to be compatible with various DXF versions and supports a wide
range of DXF entities and features. The library is built with a focus on
reliability, performance, and ease of use.

Key Features:
- Full support for DXF R12 to DXF 2018
- Read and write support for binary and ASCII DXF files
- Comprehensive entity support including 3D objects and ACIS data
- High-level tools for common CAD operations
- Well-documented API with type hints
"""
from typing import TextIO, Optional
import sys
import os
from .version import version, __version__

VERSION = __version__
__author__ = "Translatio Delineationis Recens Team <your.email@example.com>"
__license__ = "MIT"
__url__ = "https://github.com/yourusername/translatio-delineationis-recens"

TRUE_STATE = {"True", "true", "On", "on", "1"}
PYPY = hasattr(sys, "pypy_version_info")
PYPY_ON_WINDOWS = sys.platform.startswith("win") and PYPY

# name space imports - do not remove
from ._options import options, config_files
from .colors import (
    int2rgb,
    rgb2int,
    transparency2float,
    float2transparency,
)
from .enums import InsertUnits
from .lldxf import const
from .lldxf.validator import is_dxf_file, is_dxf_stream
from .filemanagement import readzip, new, read, readfile, decode_base64
from .tools.standards import (
    setup_linetypes,
    setup_styles,
    setup_dimstyles,
    setup_dimstyle,
)
from .tools import pattern
from .render.arrows import ARROWS
from .lldxf.const import (
    DXFError,
    DXFStructureError,
    DXFVersionError,
    DXFTableEntryError,
    DXFAppDataError,
    DXFXDataError,
    DXFAttributeError,
    DXFValueError,
    DXFKeyError,
    DXFIndexError,
    DXFTypeError,
    DXFBlockInUseError,
    InvalidGeoDataException,
    DXF12,
    DXF2000,
    DXF2004,
    DXF2007,
    DXF2010,
    DXF2013,
    DXF2018,
)

# name space imports - do not remove

from .lldxf.encoding import (
    dxf_backslash_replace,
    has_dxf_unicode,
    decode_dxf_unicode,
)


# setup DXF unicode encoder -> '\U+nnnn'
codecs.register_error("dxfreplace", dxf_backslash_replace)

EZDXF_TEST_FILES = options.test_files
YES_NO = {True: "yes", False: "no"}


def print_config(verbose: bool = False, stream: Optional[TextIO] = None) -> None:
    from pathlib import Path

    if stream is None:
        stream = sys.stdout
    stream.write(
        "\n".join([
            f"translatio_delineationis_recens {__version__} from {Path(__file__).parent}",
            f"Python version: {sys.version}",
            f"using C-extensions: {YES_NO[options.use_c_ext]}\n",
        ])
    )
    if verbose:
        stream.write("\nConfiguration:\n")
        options.write(stream)
        stream.write("\nEnvironment Variables:\n")
        for v in options.CONFIG_VARS:
            stream.write(f"{v}={os.environ.get(v, '')}\n")

        stream.write("\nLoaded Config Files:\n")
        for path in options.loaded_config_files:
            stream.write(str(path.absolute()) + "\n")
