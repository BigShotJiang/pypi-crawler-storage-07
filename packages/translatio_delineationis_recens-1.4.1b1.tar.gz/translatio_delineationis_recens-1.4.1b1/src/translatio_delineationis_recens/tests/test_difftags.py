import pytest
from ezdxf.tools.difftags import OpCode, Operation, convert_opcodes, round_tags, diff_tags, print_diff
from ezdxf.lldxf.tags import Tags
from ezdxf.lldxf.types import DXFTag, DXFVertex

# --- OpCode and Operation ---
def test_opcode_enum():
    assert OpCode.replace.name == "replace"
    assert OpCode.delete.name == "delete"
    assert OpCode.insert.name == "insert"
    assert OpCode.equal.name == "equal"

def test_operation_namedtuple():
    op = Operation(OpCode.replace, 1, 2, 3, 4)
    assert op.opcode == OpCode.replace
    assert op.i1 == 1 and op.i2 == 2 and op.j1 == 3 and op.j2 == 4

# --- convert_opcodes ---
def test_convert_opcodes():
    opcodes = [
        ("replace", 0, 1, 0, 1),
        ("delete", 1, 2, 1, 1),
        ("insert", 2, 2, 1, 2),
        ("equal", 2, 3, 2, 3),
    ]
    ops = list(convert_opcodes(opcodes))
    assert [op.opcode for op in ops] == [OpCode.replace, OpCode.delete, OpCode.insert, OpCode.equal]
    assert ops[0] == Operation(OpCode.replace, 0, 1, 0, 1)

# --- round_tags ---
def test_round_tags_float_and_vertex():
    tags = Tags([
        DXFTag(10, 1.23456),
        DXFVertex(20, (1.23456, 2.34567)),
        DXFTag(30, "not_float"),
    ])
    rounded = list(round_tags(tags, 2))
    assert rounded[0].value == 1.23
    assert tuple(rounded[1].value) == (1.23, 2.35)
    assert rounded[2].value == "not_float"

# --- diff_tags ---
def test_diff_tags_basic():
    a = Tags([DXFTag(1, "A"), DXFTag(2, 3.0)])
    b = Tags([DXFTag(1, "A"), DXFTag(2, 4.0)])
    ops = list(diff_tags(a, b))
    # Should have one equal and one replace
    assert any(op.opcode == OpCode.replace for op in ops)
    assert any(op.opcode == OpCode.equal for op in ops)

def test_diff_tags_with_rounding():
    # Use values that round to the same value at 2 digits
    a = Tags([DXFTag(1, 1.2344)])
    b = Tags([DXFTag(1, 1.2346)])
    ops = list(diff_tags(a, b, ndigits=2))
    # After rounding, should not be any insert or delete operations
    assert not any(op.opcode in (OpCode.insert, OpCode.delete) for op in ops)
    # All tag values should be equal after rounding
    rounded_a = list(round_tags(a, 2))
    rounded_b = list(round_tags(b, 2))
    assert [tag.value for tag in rounded_a] == [tag.value for tag in rounded_b]

# --- print_diff (smoke test) ---
def test_print_diff_smoke(capsys):
    a = Tags([DXFTag(1, "A"), DXFTag(2, 3.0)])
    b = Tags([DXFTag(1, "A"), DXFTag(2, 4.0)])
    ops = list(diff_tags(a, b))
    print_diff(a, b, ops)
    out = capsys.readouterr().out
    assert "replace" in out or "insert" in out or "delete" in out
