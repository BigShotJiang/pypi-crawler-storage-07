import pytest
from ezdxf.reorder import ascending, descending

class DummyDXFGraphic:
    def __init__(self, handle):
        self.dxf = type('dxf', (), {})()
        self.dxf.handle = handle
    def __repr__(self):
        return f"DummyDXFGraphic({self.dxf.handle})"

def handles(entity_list):
    return [e.dxf.handle for e in entity_list]

def test_ascending_basic():
    entities = [DummyDXFGraphic(h) for h in ["10", "2", "A", "1"]]
    result = list(ascending(entities))
    assert handles(result) == ["1", "2", "A", "10"]

def test_descending_basic():
    entities = [DummyDXFGraphic(h) for h in ["10", "2", "A", "1"]]
    result = list(descending(entities))
    assert handles(result) == ["10", "A", "2", "1"]

def test_ascending_with_mapping():
    entities = [DummyDXFGraphic(h) for h in ["10", "2", "A", "1"]]
    mapping = {"10": "5", "2": "F", "A": "3", "1": "C"}
    result = list(ascending(entities, mapping))
    assert handles(result) == ["A", "10", "1", "2"]  # 3, 5, C, F

def test_descending_with_mapping():
    entities = [DummyDXFGraphic(h) for h in ["10", "2", "A", "1"]]
    mapping = {"10": "5", "2": "F", "A": "3", "1": "C"}
    result = list(descending(entities, mapping))
    assert handles(result) == ["2", "1", "10", "A"]  # F, C, 5, 3

def test_duplicate_sort_handles():
    entities = [DummyDXFGraphic(h) for h in ["10", "2", "A", "1"]]
    mapping = {"10": "1", "2": "1", "A": "2", "1": "2"}
    result = list(ascending(entities, mapping))
    # Entities with same sort handle keep original order
    assert handles(result) == ["10", "2", "A", "1"]

def test_handle_zero_is_max():
    entities = [DummyDXFGraphic(h) for h in ["0", "1", "2"]]
    result = list(ascending(entities))
    # '0' should be last (treated as max)
    assert handles(result) == ["1", "2", "0"]
    result = list(descending(entities))
    # '0' should be first (treated as max)
    assert handles(result) == ["0", "2", "1"]
