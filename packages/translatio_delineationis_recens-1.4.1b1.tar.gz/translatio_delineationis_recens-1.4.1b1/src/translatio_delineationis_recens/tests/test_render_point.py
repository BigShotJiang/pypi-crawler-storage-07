import pytest
from ezdxf.entities import Point
from ezdxf.render.point import virtual_entities
from ezdxf.math import Vec3

class DummyPoint:
    """Minimal mock of ezdxf.entities.Point for testing virtual_entities."""
    def __init__(self, location=(0, 0, 0), angle=0, extrusion=(0, 0, 1)):
        self.dxf = type('dxf', (), {})()
        self.dxf.location = Vec3(location)
        self.dxf.angle = angle
        self.dxf.hasattr = lambda name: hasattr(self.dxf, name)
        self.dxf.extrusion = Vec3(extrusion)
    def ocs(self):
        # Minimal OCS mock
        class OCS:
            ux = Vec3(1, 0, 0)
            uz = Vec3(0, 0, 1)
            def from_wcs(self, v): return v
        return OCS()
    def graphic_properties(self):
        return {}

@pytest.mark.parametrize("pdmode,expected_types,desc", [
    (0, ['LINE'], "dimensionless point as zero-length line"),
    (2, ['LINE', 'LINE'], "+ cross"),
    (3, ['LINE', 'LINE'], "x cross"),
    (4, ['LINE'], "tick"),
    (32, ['LINE', 'CIRCLE'], "circle only"),
    (64, ['LINE', 'LINE', 'LINE', 'LINE', 'LINE'], "square only"),
    (2|32, ['LINE', 'LINE', 'CIRCLE'], "+ cross with circle"),
    (2|64, ['LINE', 'LINE', 'LINE', 'LINE', 'LINE', 'LINE'], "+ cross with square"),
    (2|32|64, ['LINE', 'LINE', 'LINE', 'LINE', 'LINE', 'LINE', 'CIRCLE'], "+ cross with square and circle"),
])
def test_virtual_entities(pdmode, expected_types, desc):
    point = DummyPoint()
    entities = virtual_entities(point, pdsize=10, pdmode=pdmode)
    types = [e.dxftype() for e in entities]
    assert types == expected_types, f"Failed: {desc} (got {types})"
    # Check that all entities have required attributes
    for e in entities:
        assert hasattr(e, 'dxftype'), "Entity missing dxftype() method"
        assert hasattr(e, 'dxf'), "Entity missing dxf attribute"

