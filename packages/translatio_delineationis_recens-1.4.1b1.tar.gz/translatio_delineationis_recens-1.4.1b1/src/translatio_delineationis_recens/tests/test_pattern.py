"""Tests for the ezdxf.tools.pattern module."""
import pytest
import math
from Code.Python.ezdxf.tools.pattern import (
    load, scale_pattern, scale_all, parse, is_solid, round_angle_15_deg,
    PatternAnalyser, PatternFileCompiler, ISO_PATTERN, IMPERIAL_PATTERN,
    IMPERIAL_SCALE_FACTOR, HatchPatternType, HatchPatternLineType
)
from Code.Python.ezdxf.math import Vec2


class TestPatternLoading:
    """Test cases for pattern loading functions."""

    def test_load_iso_pattern(self):
        """Test loading ISO pattern."""
        # Default measurement=1 should load ISO pattern with scale factor 1.0
        pattern = load(measurement=1)
        
        # Verify it's a dictionary
        assert isinstance(pattern, dict)
        
        # Verify it contains patterns
        assert len(pattern) > 0
        
        # Check a specific pattern exists
        assert "ANSI31" in pattern
        
        # Verify pattern structure
        ansi31 = pattern["ANSI31"]
        assert isinstance(ansi31, list)
        assert len(ansi31) > 0
        
        # Check pattern line structure
        line = ansi31[0]
        assert len(line) == 4
        angle, base_point, offset, dash_pattern = line
        assert isinstance(angle, float)
        assert isinstance(base_point, tuple)
        assert isinstance(offset, tuple)
        assert isinstance(dash_pattern, list)

    def test_load_imperial_pattern(self):
        """Test loading imperial pattern."""
        # measurement=0 should load imperial pattern with scale factor 1/25.4
        pattern = load(measurement=0)
        
        # Verify it's a dictionary
        assert isinstance(pattern, dict)
        
        # Verify it contains patterns
        assert len(pattern) > 0
        
        # Check a specific pattern exists
        assert "ANSI31" in pattern
        
        # Verify pattern structure
        ansi31 = pattern["ANSI31"]
        
        # Get the same pattern with ISO scaling for comparison
        iso_pattern = load(measurement=1)
        iso_ansi31 = iso_pattern["ANSI31"]
        
        # Imperial pattern should be scaled down by factor 1/25.4
        imperial_offset = ansi31[0][2]
        iso_offset = iso_ansi31[0][2]
        
        # Check that imperial values are approximately 1/25.4 of ISO values
        assert math.isclose(imperial_offset[0], iso_offset[0] * IMPERIAL_SCALE_FACTOR, rel_tol=1e-9)
        assert math.isclose(imperial_offset[1], iso_offset[1] * IMPERIAL_SCALE_FACTOR, rel_tol=1e-9)

    def test_load_with_custom_factor(self):
        """Test loading pattern with custom scaling factor."""
        custom_factor = 2.5
        pattern = load(factor=custom_factor)
        
        # Get the default pattern for comparison
        default_pattern = load(measurement=1)
        
        # Get a specific pattern for comparison
        pattern_name = "ANSI31"
        custom_ansi31 = pattern[pattern_name]
        default_ansi31 = default_pattern[pattern_name]
        
        # Custom pattern should be scaled by custom_factor
        custom_offset = custom_ansi31[0][2]
        default_offset = default_ansi31[0][2]
        
        assert math.isclose(custom_offset[0], default_offset[0] * custom_factor, rel_tol=1e-9)
        assert math.isclose(custom_offset[1], default_offset[1] * custom_factor, rel_tol=1e-9)


class TestPatternScaling:
    """Test cases for pattern scaling functions."""

    def test_scale_pattern(self):
        """Test scaling a single pattern."""
        # Create a simple test pattern
        test_pattern = [
            [0.0, (0.0, 0.0), (1.0, 1.0), [2.0, -1.0]],
            [45.0, (1.0, 1.0), (1.0, 0.0), [3.0, -2.0]]
        ]
        
        # Scale pattern by factor 2
        scaled_pattern = scale_pattern(test_pattern, factor=2.0)
        
        # Check pattern structure
        assert len(scaled_pattern) == len(test_pattern)
        
        # Check scaling of first line
        original_line = test_pattern[0]
        scaled_line = scaled_pattern[0]
        
        # Angle should remain the same
        assert scaled_line[0] == original_line[0]
        
        # Base point should be scaled
        assert scaled_line[1][0] == original_line[1][0] * 2.0
        assert scaled_line[1][1] == original_line[1][1] * 2.0
        
        # Offset should be scaled
        assert scaled_line[2][0] == original_line[2][0] * 2.0
        assert scaled_line[2][1] == original_line[2][1] * 2.0
        
        # Dash pattern should be scaled
        assert scaled_line[3][0] == original_line[3][0] * 2.0
        assert scaled_line[3][1] == original_line[3][1] * 2.0

    def test_scale_pattern_with_angle(self):
        """Test scaling a pattern with rotation."""
        # Create a simple test pattern
        test_pattern = [
            [0.0, (0.0, 0.0), (1.0, 0.0), [2.0, -1.0]]
        ]
        
        # Scale and rotate pattern by 90 degrees
        scaled_pattern = scale_pattern(test_pattern, factor=1.0, angle=90.0)
        
        # Check pattern structure
        assert len(scaled_pattern) == len(test_pattern)
        
        # Check rotation of first line
        original_line = test_pattern[0]
        scaled_line = scaled_pattern[0]
        
        # Angle should be rotated by 90 degrees
        assert math.isclose(scaled_line[0], (original_line[0] + 90.0) % 360.0)
        
        # Base point should be rotated
        original_base = Vec2(original_line[1])
        rotated_base = original_base.rotate_deg(90.0)
        assert math.isclose(scaled_line[1][0], rotated_base.x, abs_tol=1e-9)
        assert math.isclose(scaled_line[1][1], rotated_base.y, abs_tol=1e-9)
        
        # Offset should be rotated
        original_offset = Vec2(original_line[2])
        rotated_offset = original_offset.rotate_deg(90.0)
        assert math.isclose(scaled_line[2][0], rotated_offset.x, abs_tol=1e-9)
        assert math.isclose(scaled_line[2][1], rotated_offset.y, abs_tol=1e-9)

    def test_scale_all(self):
        """Test scaling all patterns in a dictionary."""
        # Create a test pattern dictionary
        test_patterns = {
            "PATTERN1": [
                [0.0, (0.0, 0.0), (1.0, 1.0), [2.0, -1.0]]
            ],
            "PATTERN2": [
                [45.0, (1.0, 1.0), (1.0, 0.0), [3.0, -2.0]]
            ]
        }
        
        # Scale all patterns by factor 2
        scaled_patterns = scale_all(test_patterns, factor=2.0)
        
        # Check dictionary structure
        assert len(scaled_patterns) == len(test_patterns)
        assert set(scaled_patterns.keys()) == set(test_patterns.keys())
        
        # Check scaling of first pattern
        original_pattern = test_patterns["PATTERN1"]
        scaled_pattern = scaled_patterns["PATTERN1"]
        
        # Check scaling of first line in first pattern
        original_line = original_pattern[0]
        scaled_line = scaled_pattern[0]
        
        # Offset should be scaled
        assert scaled_line[2][0] == original_line[2][0] * 2.0
        assert scaled_line[2][1] == original_line[2][1] * 2.0


class TestPatternParsing:
    """Test cases for pattern parsing functions."""

    def test_parse_valid_pattern(self):
        """Test parsing a valid pattern string."""
        pattern_str = """*STARS, Stars pattern
45, 0, 0, 0, 0, 0
135, 0, 0, 0, 0, 0
*ZIGZAG, Zigzag pattern
0, 0, 0, 6.35, 6.35, 6.35, -6.35
90, 6.35, 0, -6.35, 6.35, 6.35, -6.35"""
        
        patterns = parse(pattern_str)
        
        # Check dictionary structure
        assert isinstance(patterns, dict)
        assert len(patterns) == 2
        assert "STARS" in patterns
        assert "ZIGZAG" in patterns
        
        # Check STARS pattern
        stars = patterns["STARS"]
        assert len(stars) == 2
        
        # Check ZIGZAG pattern
        zigzag = patterns["ZIGZAG"]
        assert len(zigzag) == 2
        
        # Check structure of a pattern line
        line = zigzag[0]
        assert len(line) == 4
        angle, base_point, offset, dash_pattern = line
        assert isinstance(angle, float)
        assert isinstance(base_point, tuple)
        assert isinstance(offset, tuple)
        assert isinstance(dash_pattern, list)

    def test_parse_invalid_pattern(self):
        """Test parsing an invalid pattern string."""
        # This pattern is invalid because it has incorrect format for pattern lines
        invalid_pattern = """*INVALID, Missing data
        not_a_number, 0, 0, 0, 0"""
        
        with pytest.raises(ValueError, match="Incompatible pattern definition"):
            parse(invalid_pattern)

    def test_tokenize_pattern_line(self):
        """Test tokenizing pattern lines."""
        from Code.Python.ezdxf.tools.pattern import _tokenize_pattern_line
        
        # Test pattern name line
        name_line = "*STARS, Stars pattern"
        tokens = _tokenize_pattern_line(name_line)
        assert len(tokens) == 2
        assert tokens[0] == "*STARS"
        assert tokens[1] == " Stars pattern"
        
        # Test pattern data line
        data_line = "45, 0, 0, 0, 0, 0"
        tokens = _tokenize_pattern_line(data_line)
        assert len(tokens) == 6
        assert tokens[0] == "45"
        assert tokens[1] == " 0"


class TestPatternFileCompiler:
    """Test cases for PatternFileCompiler class."""

    def test_compiler_init(self):
        """Test initializing the pattern compiler."""
        pattern_str = """*STARS, Stars pattern
45, 0, 0, 0, 0, 0
; This is a comment
135, 0, 0, 0, 0, 0"""
        
        compiler = PatternFileCompiler(pattern_str)
        
        # Check that lines are tokenized and comments are removed
        # The PatternFileCompiler doesn't filter out comments in the _lines attribute,
        # it only skips them when processing
        assert len(compiler._lines) == 3
        assert compiler._lines[0][0] == "*STARS"
        assert compiler._lines[1][0] == "45"
        assert compiler._lines[2][0] == "135"

    def test_parse_pattern(self):
        """Test parsing patterns from tokenized lines."""
        pattern_str = """*STARS, Stars pattern
45, 0, 0, 0, 0, 0
135, 0, 0, 0, 0, 0
*ZIGZAG, Zigzag pattern
0, 0, 0, 6.35, 6.35, 6.35, -6.35"""
        
        compiler = PatternFileCompiler(pattern_str)
        patterns = list(compiler._parse_pattern())
        
        # Check that we have two patterns
        assert len(patterns) == 2
        
        # Check first pattern structure
        stars = patterns[0]
        assert len(stars) >= 2  # at least name + 1 line
        # The asterisk is removed during parsing
        assert stars[0][0] == "STARS"
        
        # Check second pattern structure
        zigzag = patterns[1]
        assert len(zigzag) >= 1  # at least name
        # The asterisk is removed during parsing
        assert zigzag[0][0] == "ZIGZAG"

    def test_compile_pattern(self):
        """Test compiling patterns from parsed data."""
        pattern_str = """*STARS, Stars pattern
45, 0, 0, 0, 0, 0
*ZIGZAG, Zigzag pattern
0, 0, 0, 6.35, 6.35, 6.35, -6.35"""
        
        compiler = PatternFileCompiler(pattern_str)
        patterns = compiler.compile_pattern()
        
        # Check dictionary structure
        assert isinstance(patterns, dict)
        assert len(patterns) == 2
        assert "STARS" in patterns
        assert "ZIGZAG" in patterns


class TestPatternUtilities:
    """Test cases for pattern utility functions."""

    def test_is_solid(self):
        """Test is_solid function."""
        # Empty pattern is solid
        assert is_solid([]) is True
        
        # Non-empty pattern is not solid
        assert is_solid([1.0, -1.0]) is False

    def test_round_angle_15_deg(self):
        """Test round_angle_15_deg function."""
        # Test exact multiples of 15
        assert round_angle_15_deg(0.0) == 0
        assert round_angle_15_deg(15.0) == 15
        assert round_angle_15_deg(30.0) == 30
        
        # Test rounding - based on actual implementation
        # The function rounds to the nearest multiple of 15
        assert round_angle_15_deg(7.5) == 0
        assert round_angle_15_deg(22.5) == 30
        
        # Test angles > 180 (should be modulo 180)
        # 190 % 180 = 10, rounds to nearest multiple of 15 which is 15
        assert round_angle_15_deg(190.0) == 15
        # 350 % 180 = 170, rounds to nearest multiple of 15 which is 165
        assert round_angle_15_deg(350.0) == 165


class TestPatternAnalyser:
    """Test cases for PatternAnalyser class."""

    def test_pattern_analyser_init(self):
        """Test initializing the pattern analyser."""
        # Create a test pattern
        test_pattern = [
            [0.0, (0.0, 0.0), (1.0, 1.0), []],  # Solid line at 0 degrees
            [45.0, (1.0, 1.0), (1.0, 0.0), [3.0, -2.0]]  # Dashed line at 45 degrees
        ]
        
        analyser = PatternAnalyser(test_pattern)
        
        # Check internal data structure
        assert len(analyser._lines) == 2
        assert (0, True) in analyser._lines  # Solid line at 0 degrees
        assert (45, False) in analyser._lines  # Dashed line at 45 degrees

    def test_has_angle(self):
        """Test has_angle method."""
        # Create a test pattern
        test_pattern = [
            [0.0, (0.0, 0.0), (1.0, 1.0), []],  # Solid line at 0 degrees
            [45.0, (1.0, 1.0), (1.0, 0.0), [3.0, -2.0]]  # Dashed line at 45 degrees
        ]
        
        analyser = PatternAnalyser(test_pattern)
        
        # Check angles
        assert analyser.has_angle(0) is True
        assert analyser.has_angle(45) is True
        assert analyser.has_angle(90) is False

    def test_all_angles(self):
        """Test all_angles method."""
        # Create a test pattern with all lines at same angle
        test_pattern = [
            [45.0, (0.0, 0.0), (1.0, 1.0), []],
            [45.0, (1.0, 1.0), (1.0, 0.0), [3.0, -2.0]]
        ]
        
        analyser = PatternAnalyser(test_pattern)
        
        # Check angles
        assert analyser.all_angles(45) is True
        assert analyser.all_angles(0) is False
        
        # Test pattern with different angles
        test_pattern2 = [
            [0.0, (0.0, 0.0), (1.0, 1.0), []],
            [45.0, (1.0, 1.0), (1.0, 0.0), [3.0, -2.0]]
        ]
        
        analyser2 = PatternAnalyser(test_pattern2)
        assert analyser2.all_angles(0) is False
        assert analyser2.all_angles(45) is False

    def test_has_line(self):
        """Test has_line method."""
        # Create a test pattern
        test_pattern = [
            [0.0, (0.0, 0.0), (1.0, 1.0), []],  # Solid line at 0 degrees
            [45.0, (1.0, 1.0), (1.0, 0.0), [3.0, -2.0]]  # Dashed line at 45 degrees
        ]
        
        analyser = PatternAnalyser(test_pattern)
        
        # Check specific line types
        assert analyser.has_line(0, True) is True  # Solid line at 0 degrees
        assert analyser.has_line(45, False) is True  # Dashed line at 45 degrees
        assert analyser.has_line(0, False) is False  # No dashed line at 0 degrees
        assert analyser.has_line(45, True) is False  # No solid line at 45 degrees
        assert analyser.has_line(90, True) is False  # No line at 90 degrees

    def test_all_lines(self):
        """Test all_lines method."""
        # Create a test pattern with all solid lines at 45 degrees
        test_pattern = [
            [45.0, (0.0, 0.0), (1.0, 1.0), []],
            [45.0, (1.0, 1.0), (1.0, 0.0), []]
        ]
        
        analyser = PatternAnalyser(test_pattern)
        
        # Check all lines
        assert analyser.all_lines(45, True) is True  # All lines are solid at 45 degrees
        assert analyser.all_lines(45, False) is False  # Not all lines are dashed at 45 degrees
        assert analyser.all_lines(0, True) is False  # No lines at 0 degrees
        
        # Test pattern with mixed line types
        test_pattern2 = [
            [45.0, (0.0, 0.0), (1.0, 1.0), []],  # Solid line at 45 degrees
            [45.0, (1.0, 1.0), (1.0, 0.0), [3.0, -2.0]]  # Dashed line at 45 degrees
        ]
        
        analyser2 = PatternAnalyser(test_pattern2)
        assert analyser2.all_lines(45, True) is False  # Not all lines are solid at 45 degrees
        assert analyser2.all_lines(45, False) is False  # Not all lines are dashed at 45 degrees

    def test_has_solid_line(self):
        """Test has_solid_line method."""
        # Create a test pattern with a solid line
        test_pattern = [
            [0.0, (0.0, 0.0), (1.0, 1.0), []],  # Solid line
            [45.0, (1.0, 1.0), (1.0, 0.0), [3.0, -2.0]]  # Dashed line
        ]
        
        analyser = PatternAnalyser(test_pattern)
        assert analyser.has_solid_line() is True
        
        # Create a test pattern with no solid lines
        test_pattern2 = [
            [0.0, (0.0, 0.0), (1.0, 1.0), [1.0, -1.0]],  # Dashed line
            [45.0, (1.0, 1.0), (1.0, 0.0), [3.0, -2.0]]  # Dashed line
        ]
        
        analyser2 = PatternAnalyser(test_pattern2)
        assert analyser2.has_solid_line() is False

    def test_has_dashed_line(self):
        """Test has_dashed_line method."""
        # Create a test pattern with a dashed line
        test_pattern = [
            [0.0, (0.0, 0.0), (1.0, 1.0), []],  # Solid line
            [45.0, (1.0, 1.0), (1.0, 0.0), [3.0, -2.0]]  # Dashed line
        ]
        
        analyser = PatternAnalyser(test_pattern)
        assert analyser.has_dashed_line() is True
        
        # Create a test pattern with no dashed lines
        test_pattern2 = [
            [0.0, (0.0, 0.0), (1.0, 1.0), []],  # Solid line
            [45.0, (1.0, 1.0), (1.0, 0.0), []]  # Solid line
        ]
        
        analyser2 = PatternAnalyser(test_pattern2)
        assert analyser2.has_dashed_line() is False

    def test_all_solid_lines(self):
        """Test all_solid_lines method."""
        # Create a test pattern with all solid lines
        test_pattern = [
            [0.0, (0.0, 0.0), (1.0, 1.0), []],  # Solid line
            [45.0, (1.0, 1.0), (1.0, 0.0), []]  # Solid line
        ]
        
        analyser = PatternAnalyser(test_pattern)
        assert analyser.all_solid_lines() is True
        
        # Create a test pattern with mixed line types
        test_pattern2 = [
            [0.0, (0.0, 0.0), (1.0, 1.0), []],  # Solid line
            [45.0, (1.0, 1.0), (1.0, 0.0), [3.0, -2.0]]  # Dashed line
        ]
        
        analyser2 = PatternAnalyser(test_pattern2)
        assert analyser2.all_solid_lines() is False

    def test_all_dashed_lines(self):
        """Test all_dashed_lines method."""
        # Create a test pattern with all dashed lines
        test_pattern = [
            [0.0, (0.0, 0.0), (1.0, 1.0), [1.0, -1.0]],  # Dashed line
            [45.0, (1.0, 1.0), (1.0, 0.0), [3.0, -2.0]]  # Dashed line
        ]
        
        analyser = PatternAnalyser(test_pattern)
        assert analyser.all_dashed_lines() is True
        
        # Create a test pattern with mixed line types
        test_pattern2 = [
            [0.0, (0.0, 0.0), (1.0, 1.0), []],  # Solid line
            [45.0, (1.0, 1.0), (1.0, 0.0), [3.0, -2.0]]  # Dashed line
        ]
        
        analyser2 = PatternAnalyser(test_pattern2)
        assert analyser2.all_dashed_lines() is False
