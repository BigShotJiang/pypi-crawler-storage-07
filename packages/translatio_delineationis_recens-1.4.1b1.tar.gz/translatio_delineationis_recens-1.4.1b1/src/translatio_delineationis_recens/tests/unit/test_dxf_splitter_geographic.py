"""
Unit tests for GeographicSplitter.

Tests the grid-based spatial splitting functionality of the DXF Splitter Tool.
"""

import unittest
from unittest.mock import Mock, patch, MagicMock, call
import tempfile
import os
from pathlib import Path

# Import the classes to test
from translatio_delineationis_recens.tools.dxf_splitter_tool.splitters.geographic import (
    GeographicSplitter, GridCell
)
from translatio_delineationis_recens.tools.dxf_splitter_tool.model import (
    SplitResult, SplitProgress
)


class TestGridCell(unittest.TestCase):
    """Test the GridCell dataclass."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.cell = GridCell(
            row=1, col=2, min_x=10.0, min_y=20.0, max_x=30.0, max_y=40.0,
            entities=[]
        )
    
    def test_grid_cell_initialization(self):
        """Test GridCell initialization."""
        self.assertEqual(self.cell.row, 1)
        self.assertEqual(self.cell.col, 2)
        self.assertEqual(self.cell.min_x, 10.0)
        self.assertEqual(self.cell.min_y, 20.0)
        self.assertEqual(self.cell.max_x, 30.0)
        self.assertEqual(self.cell.max_y, 40.0)
        self.assertEqual(self.cell.entities, [])
    
    def test_bounds_property(self):
        """Test the bounds property."""
        bounds = self.cell.bounds
        self.assertEqual(bounds.extmin.x, 10.0)
        self.assertEqual(bounds.extmin.y, 20.0)
        self.assertEqual(bounds.extmax.x, 30.0)
        self.assertEqual(bounds.extmax.y, 40.0)
    
    def test_center_property(self):
        """Test the center property."""
        center = self.cell.center
        self.assertEqual(center.x, 20.0)  # (10 + 30) / 2
        self.assertEqual(center.y, 30.0)  # (20 + 40) / 2
    
    def test_is_empty_property(self):
        """Test the is_empty property."""
        self.assertTrue(self.cell.is_empty)
        
        # Add an entity
        mock_entity = Mock()
        self.cell.entities.append(mock_entity)
        self.assertFalse(self.cell.is_empty)


class TestGeographicSplitter(unittest.TestCase):
    """Test the GeographicSplitter class."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.splitter = GeographicSplitter()
        self.temp_dir = tempfile.mkdtemp()
        self.test_filepath = os.path.join(self.temp_dir, "test.dxf")
        
        # Create mock DXF document
        self.mock_doc = Mock()
        self.mock_doc.dxfversion = "AC1021"
        
        # Create mock modelspace with entities
        self.mock_msp = Mock()
        self.mock_entities = [Mock() for _ in range(10)]
        for i, entity in enumerate(self.mock_entities):
            entity.dxftype.return_value = f"ENTITY_{i}"
            entity.copy.return_value = Mock()
        
        self.mock_msp.__iter__ = Mock(return_value=iter(self.mock_entities))
        self.mock_msp.__len__ = Mock(return_value=len(self.mock_entities))
        self.mock_doc.modelspace.return_value = self.mock_msp
    
    def tearDown(self):
        """Clean up test fixtures."""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_splitter_initialization(self):
        """Test GeographicSplitter initialization."""
        self.assertIsNotNone(self.splitter.logger)
    
    def test_split_by_grid_invalid_dimensions(self):
        """Test split_by_grid with invalid grid dimensions."""
        result = self.splitter.split_by_grid(
            self.mock_doc, self.test_filepath, 0, 3, self.temp_dir
        )
        
        self.assertFalse(result.success)
        self.assertIn("Grid dimensions must be positive", result.error_message)
    
    def test_split_by_grid_negative_overlap(self):
        """Test split_by_grid with negative overlap."""
        result = self.splitter.split_by_grid(
            self.mock_doc, self.test_filepath, 3, 3, self.temp_dir, overlap=-1.0
        )
        
        self.assertFalse(result.success)
        self.assertIn("Overlap cannot be negative", result.error_message)
    
    def test_split_by_grid_no_entities(self):
        """Test split_by_grid with no entities."""
        # Mock the _calculate_bounding_box method to return None
        with patch.object(self.splitter, '_calculate_bounding_box', return_value=None):
            result = self.splitter.split_by_grid(
                self.mock_doc, self.test_filepath, 3, 3, self.temp_dir
            )
            
            self.assertFalse(result.success)
            self.assertIn("No entities found or invalid bounds", result.error_message)
    
    @patch('translatio_delineationis_recens.tools.dxf_splitter_tool.splitters.geographic.ezdxf')
    def test_split_by_grid_success(self, mock_ezdxf):
        """Test successful split_by_grid operation."""
        # Mock bounding box
        mock_bbox = Mock()
        mock_bbox.has_data = True
        mock_bbox.size.x = 100.0
        mock_bbox.size.y = 100.0
        mock_bbox.extmin.x = 0.0
        mock_bbox.extmin.y = 0.0
        
        # Mock new document creation
        mock_new_doc = Mock()
        mock_new_doc.modelspace.return_value = Mock()
        mock_new_doc.layers = []
        mock_new_doc.styles = []
        mock_new_doc.linetypes = []
        mock_ezdxf.new.return_value = mock_new_doc
        
        # Mock progress callback
        progress_callback = Mock()
        
        # Create mock grid cells with entities
        mock_cell = GridCell(0, 0, 0.0, 0.0, 50.0, 50.0, [self.mock_entities[0]])
        mock_grid_cells = [[mock_cell]]
        
        # Mock the methods that would be called
        with patch.object(self.splitter, '_calculate_bounding_box', return_value=mock_bbox), \
             patch.object(self.splitter, '_create_grid_cells', return_value=mock_grid_cells), \
             patch.object(self.splitter, '_assign_entities_to_cells') as mock_assign:
            
            result = self.splitter.split_by_grid(
                self.mock_doc, self.test_filepath, 2, 2, self.temp_dir,
                progress_callback=progress_callback
            )
            
            self.assertTrue(result.success)
            self.assertGreater(len(result.output_files), 0)
            
            # Verify progress callback was called
            self.assertTrue(progress_callback.called)
            
            # Verify new documents were created
            self.assertTrue(mock_ezdxf.new.called)
            
            # Verify entity assignment was called
            self.assertTrue(mock_assign.called)
    
    def test_create_grid_cells(self):
        """Test _create_grid_cells method."""
        # Create mock bounding box
        mock_bbox = Mock()
        mock_bbox.size.x = 100.0
        mock_bbox.size.y = 100.0
        mock_bbox.extmin.x = 0.0
        mock_bbox.extmin.y = 0.0
        
        cells = self.splitter._create_grid_cells(mock_bbox, 2, 2, 0.0)
        
        self.assertEqual(len(cells), 2)  # 2 rows
        self.assertEqual(len(cells[0]), 2)  # 2 columns
        
        # Check first cell
        cell_00 = cells[0][0]
        self.assertEqual(cell_00.row, 0)
        self.assertEqual(cell_00.col, 0)
        self.assertEqual(cell_00.min_x, 0.0)
        self.assertEqual(cell_00.min_y, 0.0)
        self.assertEqual(cell_00.max_x, 50.0)
        self.assertEqual(cell_00.max_y, 50.0)
    
    def test_create_grid_cells_with_overlap(self):
        """Test _create_grid_cells with overlap."""
        mock_bbox = Mock()
        mock_bbox.size.x = 100.0
        mock_bbox.size.y = 100.0
        mock_bbox.extmin.x = 0.0
        mock_bbox.extmin.y = 0.0
        
        overlap = 5.0
        cells = self.splitter._create_grid_cells(mock_bbox, 2, 2, overlap)
        
        # Check that overlap is applied
        cell_00 = cells[0][0]
        self.assertEqual(cell_00.min_x, -overlap)
        self.assertEqual(cell_00.min_y, -overlap)
        self.assertEqual(cell_00.max_x, 50.0 + overlap)
        self.assertEqual(cell_00.max_y, 50.0 + overlap)
    
    def test_entity_intersects_cell(self):
        """Test _entity_intersects_cell method."""
        cell = GridCell(0, 0, 10.0, 10.0, 20.0, 20.0, [])
        
        # Mock entity bbox that intersects
        mock_bbox_intersect = Mock()
        mock_bbox_intersect.extmin.x = 15.0
        mock_bbox_intersect.extmin.y = 15.0
        mock_bbox_intersect.extmax.x = 25.0
        mock_bbox_intersect.extmax.y = 25.0
        
        self.assertTrue(
            self.splitter._entity_intersects_cell(mock_bbox_intersect, cell)
        )
        
        # Mock entity bbox that doesn't intersect
        mock_bbox_no_intersect = Mock()
        mock_bbox_no_intersect.extmin.x = 30.0
        mock_bbox_no_intersect.extmin.y = 30.0
        mock_bbox_no_intersect.extmax.x = 40.0
        mock_bbox_no_intersect.extmax.y = 40.0
        
        self.assertFalse(
            self.splitter._entity_intersects_cell(mock_bbox_no_intersect, cell)
        )
    
    @patch('translatio_delineationis_recens.tools.dxf_splitter_tool.splitters.geographic.ezdxf')
    def test_create_cell_document(self, mock_ezdxf):
        """Test _create_cell_document method."""
        # Mock new document
        mock_new_doc = Mock()
        mock_new_msp = Mock()
        mock_new_doc.modelspace.return_value = mock_new_msp
        mock_new_doc.layers = []
        mock_new_doc.styles = []
        mock_new_doc.linetypes = []
        mock_ezdxf.new.return_value = mock_new_doc
        
        # Create cell with entities
        cell = GridCell(0, 0, 0.0, 0.0, 10.0, 10.0, self.mock_entities[:3])
        
        result_doc = self.splitter._create_cell_document(self.mock_doc, cell)
        
        self.assertEqual(result_doc, mock_new_doc)
        
        # Verify entities were added
        self.assertEqual(mock_new_msp.add_entity.call_count, 3)
    
    def test_update_progress(self):
        """Test _update_progress method."""
        callback = Mock()
        
        self.splitter._update_progress(
            callback, "Test Phase", 5, 10, "Test message"
        )
        
        callback.assert_called_once()
        progress_arg = callback.call_args[0][0]
        self.assertEqual(progress_arg.phase, "Test Phase")
        self.assertEqual(progress_arg.current_step, 5)
        self.assertEqual(progress_arg.total_steps, 10)
        self.assertEqual(progress_arg.message, "Test message")
    
    def test_update_progress_no_callback(self):
        """Test _update_progress with no callback."""
        # Should not raise an exception
        self.splitter._update_progress(
            None, "Test Phase", 5, 10, "Test message"
        )


if __name__ == '__main__':
    unittest.main()
