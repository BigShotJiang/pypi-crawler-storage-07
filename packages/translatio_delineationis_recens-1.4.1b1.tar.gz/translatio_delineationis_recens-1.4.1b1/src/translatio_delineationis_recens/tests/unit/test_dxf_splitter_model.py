"""
Unit tests for DXF Splitter Tool Model.

Tests the core model functionality including DXF loading, entity analysis,
and splitting coordination.
"""

import os
import tempfile
import unittest
from unittest.mock import Mock, patch, MagicMock
from pathlib import Path
from typing import List, Dict, Any

import pytest
import ezdxf
from ezdxf.math import BoundingBox

from translatio_delineationis_recens.tools.dxf_splitter_tool.model import (
    DxfSplitterModel,
    SplitMethod,
    SplitProgress,
    SplitResult
)


class TestSplitProgress(unittest.TestCase):
    """Test SplitProgress dataclass."""
    
    def test_progress_percentage_calculation(self):
        """Test percentage calculation."""
        progress = SplitProgress("Loading", 25, 100, "Test message")
        self.assertEqual(progress.percentage, 25.0)
        
        progress = SplitProgress("Loading", 0, 100, "Test message")
        self.assertEqual(progress.percentage, 0.0)
        
        progress = SplitProgress("Loading", 100, 100, "Test message")
        self.assertEqual(progress.percentage, 100.0)
    
    def test_progress_percentage_edge_cases(self):
        """Test percentage calculation edge cases."""
        # Zero total steps
        progress = SplitProgress("Loading", 5, 0, "Test message")
        self.assertEqual(progress.percentage, 0.0)
        
        # More current than total (should cap at 100%)
        progress = SplitProgress("Loading", 150, 100, "Test message")
        self.assertEqual(progress.percentage, 100.0)


class TestSplitResult(unittest.TestCase):
    """Test SplitResult dataclass."""
    
    def test_split_result_initialization(self):
        """Test SplitResult initialization."""
        result = SplitResult(True, ["file1.dxf", "file2.dxf"])
        self.assertTrue(result.success)
        self.assertEqual(len(result.output_files), 2)
        self.assertIsNone(result.error_message)
        self.assertEqual(result.warnings, [])
    
    def test_split_result_with_error(self):
        """Test SplitResult with error."""
        result = SplitResult(False, [], "Test error", ["Warning 1"])
        self.assertFalse(result.success)
        self.assertEqual(result.error_message, "Test error")
        self.assertEqual(len(result.warnings), 1)


class TestDxfSplitterModel(unittest.TestCase):
    """Test DxfSplitterModel class."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.model = DxfSplitterModel()
        self.temp_dir = tempfile.mkdtemp()
        
        # Create a simple test DXF file
        self.test_dxf_path = os.path.join(self.temp_dir, "test.dxf")
        self._create_test_dxf()
    
    def tearDown(self):
        """Clean up test fixtures."""
        import shutil
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
    
    def _create_test_dxf(self):
        """Create a simple test DXF file."""
        doc = ezdxf.new('R2010')
        msp = doc.modelspace()
        
        # Add some test entities
        msp.add_line((0, 0), (10, 10))
        msp.add_circle((5, 5), radius=2)
        msp.add_point((1, 1))
        
        doc.saveas(self.test_dxf_path)
    
    def test_model_initialization(self):
        """Test model initialization."""
        self.assertIsNone(self.model.dxf_doc)
        self.assertIsNone(self.model.input_filepath)
        self.assertIsNone(self.model.output_directory)
        self.assertIsNone(self.model.progress_callback)
        
        # Check splitters are initialized
        self.assertIsNotNone(self.model.geographic_splitter)
        self.assertIsNotNone(self.model.entity_count_splitter)
        self.assertIsNotNone(self.model.entity_type_splitter)
    
    def test_progress_callback_setting(self):
        """Test setting progress callback."""
        callback = Mock()
        self.model.set_progress_callback(callback)
        self.assertEqual(self.model.progress_callback, callback)
    
    def test_progress_update_with_callback(self):
        """Test progress update calls callback."""
        callback = Mock()
        self.model.set_progress_callback(callback)
        
        self.model._update_progress("Test", 1, 10, "Test message")
        
        callback.assert_called_once()
        args = callback.call_args[0]
        progress = args[0]
        self.assertIsInstance(progress, SplitProgress)
        self.assertEqual(progress.phase, "Test")
        self.assertEqual(progress.current_step, 1)
        self.assertEqual(progress.total_steps, 10)
        self.assertEqual(progress.message, "Test message")
    
    def test_progress_update_without_callback(self):
        """Test progress update without callback doesn't crash."""
        # Should not raise exception
        self.model._update_progress("Test", 1, 10, "Test message")
    
    def test_load_dxf_success(self):
        """Test successful DXF loading."""
        result = self.model.load_dxf(self.test_dxf_path)
        
        self.assertTrue(result)
        self.assertIsNotNone(self.model.dxf_doc)
        self.assertEqual(self.model.input_filepath, self.test_dxf_path)
    
    def test_load_dxf_file_not_found(self):
        """Test DXF loading with non-existent file."""
        result = self.model.load_dxf("nonexistent.dxf")
        
        self.assertFalse(result)
        self.assertIsNone(self.model.dxf_doc)
        self.assertIsNone(self.model.input_filepath)
    
    def test_load_dxf_invalid_file(self):
        """Test DXF loading with invalid file."""
        # Create invalid DXF file
        invalid_path = os.path.join(self.temp_dir, "invalid.dxf")
        with open(invalid_path, 'w') as f:
            f.write("This is not a valid DXF file")
        
        result = self.model.load_dxf(invalid_path)
        
        self.assertFalse(result)
        self.assertIsNone(self.model.dxf_doc)
    
    @patch('os.access')
    def test_load_dxf_no_read_permission(self, mock_access):
        """Test DXF loading with no read permission."""
        mock_access.return_value = False
        
        result = self.model.load_dxf(self.test_dxf_path)
        
        self.assertFalse(result)
        mock_access.assert_called_with(self.test_dxf_path, os.R_OK)
    
    def test_validate_document_success(self):
        """Test document validation with valid document."""
        self.model.load_dxf(self.test_dxf_path)
        result = self.model._validate_document()
        self.assertTrue(result)
    
    def test_validate_document_no_document(self):
        """Test document validation with no loaded document."""
        result = self.model._validate_document()
        self.assertFalse(result)
    
    def test_validate_document_empty_modelspace(self):
        """Test document validation with empty modelspace."""
        # Create empty DXF
        empty_path = os.path.join(self.temp_dir, "empty.dxf")
        doc = ezdxf.new('R2010')
        doc.saveas(empty_path)
        
        self.model.load_dxf(empty_path)
        # Should still return True as load_dxf handles validation
        # but _validate_document should return False for empty modelspace
        mock_doc = Mock()
        mock_msp = Mock()
        mock_msp.__len__ = Mock(return_value=0)
        mock_doc.modelspace.return_value = mock_msp
        self.model.dxf_doc = mock_doc
        
        result = self.model._validate_document()
        self.assertFalse(result)
    
    def test_get_entity_analysis(self):
        """Test entity analysis."""
        self.model.load_dxf(self.test_dxf_path)
        analysis = self.model.get_entity_analysis()
        
        self.assertIsInstance(analysis, dict)
        self.assertIn('total_entities', analysis)
        self.assertIn('entity_types', analysis)
        self.assertIn('layer_counts', analysis)
        self.assertIn('bounding_box', analysis)
        self.assertIn('has_3d_entities', analysis)
        
        # Check specific values
        self.assertEqual(analysis['total_entities'], 3)  # line, circle, point
        self.assertIn('LINE', analysis['entity_types'])
        self.assertIn('CIRCLE', analysis['entity_types'])
        self.assertIn('POINT', analysis['entity_types'])
    
    def test_get_entity_analysis_caching(self):
        """Test entity analysis caching."""
        self.model.load_dxf(self.test_dxf_path)
        
        # First call
        analysis1 = self.model.get_entity_analysis()
        
        # Second call should return cached result
        analysis2 = self.model.get_entity_analysis()
        
        self.assertIs(analysis1, analysis2)  # Same object reference
    
    def test_get_entity_analysis_no_document(self):
        """Test entity analysis with no loaded document."""
        analysis = self.model.get_entity_analysis()
        self.assertEqual(analysis, {})
    
    def test_get_bounding_box(self):
        """Test bounding box calculation."""
        self.model.load_dxf(self.test_dxf_path)
        bbox = self.model.get_bounding_box()
        
        self.assertIsInstance(bbox, BoundingBox)
        self.assertTrue(bbox.has_data)
    
    def test_get_bounding_box_caching(self):
        """Test bounding box caching."""
        self.model.load_dxf(self.test_dxf_path)
        
        # First call
        bbox1 = self.model.get_bounding_box()
        
        # Second call should return cached result
        bbox2 = self.model.get_bounding_box()
        
        self.assertIs(bbox1, bbox2)  # Same object reference
    
    def test_get_bounding_box_no_document(self):
        """Test bounding box with no loaded document."""
        bbox = self.model.get_bounding_box()
        self.assertIsNone(bbox)
    
    def test_check_3d_entities(self):
        """Test 3D entity detection."""
        self.model.load_dxf(self.test_dxf_path)
        
        # Get entities from modelspace
        msp = self.model.dxf_doc.modelspace()
        entities = list(msp)
        
        # Our test entities are 2D
        has_3d = self.model._check_3d_entities(entities)
        self.assertFalse(has_3d)
    
    def test_get_available_entity_types(self):
        """Test getting available entity types."""
        self.model.load_dxf(self.test_dxf_path)
        types = self.model.get_available_entity_types()
        
        self.assertIsInstance(types, list)
        self.assertIn('LINE', types)
        self.assertIn('CIRCLE', types)
        self.assertIn('POINT', types)
    
    def test_get_available_entity_types_no_document(self):
        """Test getting entity types with no loaded document."""
        types = self.model.get_available_entity_types()
        self.assertEqual(types, [])
    
    def test_estimate_output_files_geographic(self):
        """Test output file estimation for geographic splitting."""
        self.model.load_dxf(self.test_dxf_path)
        
        estimate = self.model.estimate_output_files(
            SplitMethod.GEOGRAPHIC,
            grid_cols=3,
            grid_rows=2
        )
        
        self.assertEqual(estimate, 6)  # 3 * 2
    
    def test_estimate_output_files_entity_count(self):
        """Test output file estimation for entity count splitting."""
        self.model.load_dxf(self.test_dxf_path)
        
        estimate = self.model.estimate_output_files(
            SplitMethod.ENTITY_COUNT,
            max_entities=2
        )
        
        self.assertEqual(estimate, 2)  # 3 entities / 2 per file = 2 files
    
    def test_estimate_output_files_entity_type(self):
        """Test output file estimation for entity type splitting."""
        self.model.load_dxf(self.test_dxf_path)
        
        # Test without separate files
        estimate = self.model.estimate_output_files(
            SplitMethod.ENTITY_TYPE,
            selected_types=['LINE', 'CIRCLE'],
            max_entities=1,
            separate_files=False
        )
        
        self.assertEqual(estimate, 2)  # 2 entities / 1 per file = 2 files
        
        # Test with separate files
        estimate = self.model.estimate_output_files(
            SplitMethod.ENTITY_TYPE,
            selected_types=['LINE', 'CIRCLE'],
            max_entities=1,
            separate_files=True
        )
        
        self.assertEqual(estimate, 2)  # 1 file for LINE + 1 file for CIRCLE
    
    def test_estimate_output_files_no_document(self):
        """Test output file estimation with no loaded document."""
        estimate = self.model.estimate_output_files(SplitMethod.GEOGRAPHIC)
        self.assertEqual(estimate, 0)
    
    def test_split_geographic(self):
        """Test geographic splitting delegation."""
        self.model.load_dxf(self.test_dxf_path)
        
        # Mock the splitter result
        mock_result = SplitResult(True, ["file1.dxf", "file2.dxf"])
        with patch.object(self.model.geographic_splitter, 'split_by_grid', return_value=mock_result) as mock_method:
            result = self.model.split_geographic(3, 2, self.temp_dir, 0.1, True)
            
            self.assertEqual(result, mock_result)
            mock_method.assert_called_once_with(
                self.model.dxf_doc,
                self.test_dxf_path,
                3, 2,
                self.temp_dir,
                0.1, True,
                self.model.progress_callback
            )
    
    def test_split_geographic_no_document(self):
        """Test geographic splitting with no loaded document."""
        result = self.model.split_geographic(3, 2, self.temp_dir)
        
        self.assertFalse(result.success)
        self.assertEqual(result.error_message, "No DXF file loaded")
    
    def test_split_by_count(self):
        """Test entity count splitting delegation."""
        self.model.load_dxf(self.test_dxf_path)
        
        # Mock the splitter result
        mock_result = SplitResult(True, ["file1.dxf"])
        with patch.object(self.model.entity_count_splitter, 'split_by_count', return_value=mock_result) as mock_method:
            result = self.model.split_by_count(100, self.temp_dir, "balanced")
            
            self.assertEqual(result, mock_result)
            mock_method.assert_called_once_with(
                self.model.dxf_doc,
                self.test_dxf_path,
                100,
                self.temp_dir,
                "balanced",
                self.model.progress_callback
            )
    
    def test_split_by_count_no_document(self):
        """Test entity count splitting with no loaded document."""
        result = self.model.split_by_count(100, self.temp_dir)
        
        self.assertFalse(result.success)
        self.assertEqual(result.error_message, "No DXF file loaded")
    
    def test_split_by_type(self):
        """Test entity type splitting delegation."""
        self.model.load_dxf(self.test_dxf_path)
        
        # Mock the splitter result
        mock_result = SplitResult(True, ["file1.dxf"])
        with patch.object(self.model.entity_type_splitter, 'split_by_type', return_value=mock_result) as mock_method:
            result = self.model.split_by_type(['LINE', 'CIRCLE'], 50, self.temp_dir, True)
            
            self.assertEqual(result, mock_result)
            mock_method.assert_called_once_with(
                self.model.dxf_doc,
                self.test_dxf_path,
                ['LINE', 'CIRCLE'],
                50,
                self.temp_dir,
                True,
                self.model.progress_callback
            )
    
    def test_split_by_type_no_document(self):
        """Test entity type splitting with no loaded document."""
        result = self.model.split_by_type(['LINE'], 50, self.temp_dir)
        
        self.assertFalse(result.success)
        self.assertEqual(result.error_message, "No DXF file loaded")


if __name__ == '__main__':
    unittest.main()
