"""Unit tests for the DXF to GeoJSON model."""
import os
import pytest
import json
from unittest.mock import patch, MagicMock
from dxf_to_geojson.model import DxfToGeoJSONModel

# Sample DXF data for testing
SAMPLE_DXF = """0
SECTION
2
HEADER
9
$ACADVER
1
AC1018
0
ENDSEC
0
SECTION
2
ENTITIES
0
POINT
10
1.0
20
2.0
30
0.0
8
TestLayer
5
1
0
LINE
10
0.0
20
0.0
30
0.0
11
1.0
21
1.0
31
0.0
8
TestLayer
5
2
0
LWPOLYLINE
90
4
70
1
10
0.0
20
0.0
10
1.0
20
0.0
10
1.0
20
1.0
10
0.0
20
1.0
8
TestLayer
5
3
0
ENDSEC
0
EOF
"""

@pytest.fixture
def sample_dxf_file(tmp_path):
    """Create a sample DXF file for testing."""
    file_path = tmp_path / "test.dxf"
    file_path.write_text(SAMPLE_DXF)
    return str(file_path)

@pytest.fixture
def model():
    """Create a DxfToGeoJSONModel instance for testing."""
    return DxfToGeoJSONModel()

def test_load_dxf_success(model, sample_dxf_file):
    """Test loading a valid DXF file."""
    assert model.load_dxf(sample_dxf_file) is True
    assert model.dxf_doc is not None

def test_load_dxf_file_not_found(model, tmp_path):
    """Test loading a non-existent DXF file."""
    non_existent_file = os.path.join(tmp_path, "nonexistent.dxf")
    assert model.load_dxf(non_existent_file) is False

def test_convert_to_geojson(model, sample_dxf_file):
    """Test converting DXF to GeoJSON."""
    model.load_dxf(sample_dxf_file)
    assert model.convert_to_geojson() is True
    assert len(model.geojson_data["features"]) == 3  # POINT, LINE, LWPOLYLINE
    
    # Check that all features have required properties
    for feature in model.geojson_data["features"]:
        assert "type" in feature
        assert "geometry" in feature
        assert "properties" in feature
        assert "layer" in feature["properties"]
        assert "handle" in feature["properties"]
        assert "entity_type" in feature["properties"]

def test_save_geojson(model, sample_dxf_file, tmp_path):
    """Test saving GeoJSON to a file."""
    output_file = tmp_path / "output.geojson"
    
    model.load_dxf(sample_dxf_file)
    model.convert_to_geojson()
    
    assert model.save_geojson(str(output_file)) is True
    assert output_file.exists()
    
    # Verify the file contains valid JSON
    with open(output_file, 'r') as f:
        data = json.load(f)
        assert "type" in data
        assert "features" in data

def test_point_to_geojson(model):
    """Test conversion of a DXF point to GeoJSON."""
    point = MagicMock()
    point.dxf.location.x = 1.0
    point.dxf.location.y = 2.0
    
    feature = model._point_to_geojson(point, "TestLayer", "123")
    
    assert feature["geometry"]["type"] == "Point"
    assert feature["geometry"]["coordinates"] == [1.0, 2.0]
    assert feature["properties"]["layer"] == "TestLayer"
    assert feature["properties"]["handle"] == "123"
    assert feature["properties"]["entity_type"] == "POINT"

def test_line_to_geojson(model):
    """Test conversion of a DXF line to GeoJSON."""
    line = MagicMock()
    line.dxf.start.x = 0.0
    line.dxf.start.y = 0.0
    line.dxf.end.x = 1.0
    line.dxf.end.y = 1.0
    
    feature = model._line_to_geojson(line, "TestLayer", "123")
    
    assert feature["geometry"]["type"] == "LineString"
    assert feature["geometry"]["coordinates"] == [[0.0, 0.0], [1.0, 1.0]]
    assert feature["properties"]["entity_type"] == "LINE"

@patch('dxf_to_geojson.model.LWPolyline')
def test_lwpolyline_to_geojson(mock_lwpolyline, model):
    """Test conversion of a DXF LWPOLYLINE to GeoJSON."""
    # Setup mock
    mock_line = MagicMock()
    mock_line.get_points.return_value = [(0, 0), (1, 0), (1, 1), (0, 1)]
    mock_line.closed = True
    
    feature = model._lwpolyline_to_geojson(mock_line, "TestLayer", "123")
    
    assert feature["geometry"]["type"] == "Polygon"
    assert len(feature["geometry"]["coordinates"][0]) == 5  # 4 points + closing point
    assert feature["properties"]["entity_type"] == "LWPOLYLINE"
