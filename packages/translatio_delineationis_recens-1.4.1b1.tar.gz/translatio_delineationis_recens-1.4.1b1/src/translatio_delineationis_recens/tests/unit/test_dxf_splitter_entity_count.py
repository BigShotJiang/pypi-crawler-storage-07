"""
Unit tests for EntityCountSplitter.

Tests the count-based splitting functionality of the DXF Splitter Tool.
"""

import unittest
from unittest.mock import Mock, patch, MagicMock
import tempfile
import os
from math import ceil

# Import the classes to test
from translatio_delineationis_recens.tools.dxf_splitter_tool.splitters.entity_count import (
    EntityCountSplitter
)
from translatio_delineationis_recens.tools.dxf_splitter_tool.model import (
    SplitResult, SplitProgress
)


class TestEntityCountSplitter(unittest.TestCase):
    """Test the EntityCountSplitter class."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.splitter = EntityCountSplitter()
        self.temp_dir = tempfile.mkdtemp()
        self.test_filepath = os.path.join(self.temp_dir, "test.dxf")
        
        # Create mock DXF document
        self.mock_doc = Mock()
        self.mock_doc.dxfversion = "AC1021"
        
        # Create mock modelspace with entities
        self.mock_msp = Mock()
        self.mock_entities = [Mock() for _ in range(25)]  # 25 entities for testing
        for i, entity in enumerate(self.mock_entities):
            entity.dxftype.return_value = f"ENTITY_{i}"
            entity.copy.return_value = Mock()
        
        self.mock_msp.__iter__ = Mock(return_value=iter(self.mock_entities))
        self.mock_msp.__len__ = Mock(return_value=len(self.mock_entities))
        self.mock_doc.modelspace.return_value = self.mock_msp
    
    def tearDown(self):
        """Clean up test fixtures."""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_splitter_initialization(self):
        """Test EntityCountSplitter initialization."""
        self.assertIsNotNone(self.splitter.logger)
    
    def test_split_by_count_invalid_max_entities(self):
        """Test split_by_count with invalid max_entities."""
        result = self.splitter.split_by_count(
            self.mock_doc, self.test_filepath, 0, self.temp_dir
        )
        
        self.assertFalse(result.success)
        self.assertIn("Maximum entities must be a positive integer", result.error_message)
    
    def test_split_by_count_invalid_strategy(self):
        """Test split_by_count with invalid strategy."""
        result = self.splitter.split_by_count(
            self.mock_doc, self.test_filepath, 10, self.temp_dir, "invalid"
        )
        
        self.assertFalse(result.success)
        self.assertIn("Strategy must be 'sequential' or 'balanced'", result.error_message)
    
    def test_split_by_count_no_entities(self):
        """Test split_by_count with no entities."""
        # Mock empty modelspace
        empty_msp = Mock()
        empty_msp.__iter__ = Mock(return_value=iter([]))
        empty_msp.__len__ = Mock(return_value=0)
        self.mock_doc.modelspace.return_value = empty_msp
        
        result = self.splitter.split_by_count(
            self.mock_doc, self.test_filepath, 10, self.temp_dir
        )
        
        self.assertFalse(result.success)
        self.assertIn("No entities found in modelspace", result.error_message)
    
    @patch('translatio_delineationis_recens.tools.dxf_splitter_tool.splitters.entity_count.ezdxf')
    def test_split_by_count_sequential_success(self, mock_ezdxf):
        """Test successful split_by_count with sequential strategy."""
        # Mock new document creation
        mock_new_doc = Mock()
        mock_new_doc.modelspace.return_value = Mock()
        mock_new_doc.layers = []
        mock_new_doc.styles = []
        mock_new_doc.linetypes = []
        mock_ezdxf.new.return_value = mock_new_doc
        
        # Mock progress callback
        progress_callback = Mock()
        
        max_entities = 10
        result = self.splitter.split_by_count(
            self.mock_doc, self.test_filepath, max_entities, self.temp_dir,
            "sequential", progress_callback
        )
        
        self.assertTrue(result.success)
        expected_files = ceil(len(self.mock_entities) / max_entities)
        self.assertEqual(len(result.output_files), expected_files)
        
        # Verify progress callback was called
        self.assertTrue(progress_callback.called)
        
        # Verify new documents were created
        self.assertEqual(mock_ezdxf.new.call_count, expected_files)
    
    @patch('translatio_delineationis_recens.tools.dxf_splitter_tool.splitters.entity_count.ezdxf')
    def test_split_by_count_balanced_success(self, mock_ezdxf):
        """Test successful split_by_count with balanced strategy."""
        # Mock new document creation
        mock_new_doc = Mock()
        mock_new_doc.modelspace.return_value = Mock()
        mock_new_doc.layers = []
        mock_new_doc.styles = []
        mock_new_doc.linetypes = []
        mock_ezdxf.new.return_value = mock_new_doc
        
        max_entities = 10
        result = self.splitter.split_by_count(
            self.mock_doc, self.test_filepath, max_entities, self.temp_dir,
            "balanced"
        )
        
        self.assertTrue(result.success)
        expected_files = ceil(len(self.mock_entities) / max_entities)
        self.assertEqual(len(result.output_files), expected_files)
    
    def test_create_sequential_groups(self):
        """Test _create_sequential_groups method."""
        entities = list(range(25))  # 25 entities
        max_entities = 10
        
        groups = self.splitter._create_sequential_groups(entities, max_entities)
        
        self.assertEqual(len(groups), 3)  # ceil(25/10) = 3
        self.assertEqual(len(groups[0]), 10)  # First group: 10 entities
        self.assertEqual(len(groups[1]), 10)  # Second group: 10 entities
        self.assertEqual(len(groups[2]), 5)   # Third group: 5 entities
        
        # Verify entities are in correct order
        self.assertEqual(groups[0], list(range(0, 10)))
        self.assertEqual(groups[1], list(range(10, 20)))
        self.assertEqual(groups[2], list(range(20, 25)))
    
    def test_create_balanced_groups(self):
        """Test _create_balanced_groups method."""
        entities = list(range(25))  # 25 entities
        max_entities = 10
        
        groups = self.splitter._create_balanced_groups(entities, max_entities)
        
        self.assertEqual(len(groups), 3)  # ceil(25/10) = 3
        
        # In balanced mode, entities should be distributed more evenly
        # 25 entities / 3 groups = 8.33, so groups should be [9, 8, 8]
        group_sizes = [len(group) for group in groups]
        self.assertEqual(group_sizes, [9, 8, 8])
        
        # Verify all entities are included
        all_entities = []
        for group in groups:
            all_entities.extend(group)
        self.assertEqual(sorted(all_entities), list(range(25)))
    
    def test_create_balanced_groups_exact_division(self):
        """Test _create_balanced_groups with exact division."""
        entities = list(range(20))  # 20 entities
        max_entities = 10
        
        groups = self.splitter._create_balanced_groups(entities, max_entities)
        
        self.assertEqual(len(groups), 2)  # ceil(20/10) = 2
        self.assertEqual(len(groups[0]), 10)
        self.assertEqual(len(groups[1]), 10)
    
    @patch('translatio_delineationis_recens.tools.dxf_splitter_tool.splitters.entity_count.ezdxf')
    def test_create_group_document(self, mock_ezdxf):
        """Test _create_group_document method."""
        # Mock new document
        mock_new_doc = Mock()
        mock_new_msp = Mock()
        mock_new_doc.modelspace.return_value = mock_new_msp
        mock_new_doc.layers = []
        mock_new_doc.styles = []
        mock_new_doc.linetypes = []
        mock_ezdxf.new.return_value = mock_new_doc
        
        # Test with subset of entities
        test_entities = self.mock_entities[:5]
        
        result_doc = self.splitter._create_group_document(self.mock_doc, test_entities)
        
        self.assertEqual(result_doc, mock_new_doc)
        
        # Verify entities were added
        self.assertEqual(mock_new_msp.add_entity.call_count, 5)
    
    def test_generate_output_files_naming(self):
        """Test output file naming convention."""
        # This is tested indirectly through the main split_by_count method
        # The naming should follow the pattern: {base_name}_part_{index:03d}.dxf
        pass  # Covered by integration tests
    
    def test_update_progress(self):
        """Test _update_progress method."""
        callback = Mock()
        
        self.splitter._update_progress(
            callback, "Test Phase", 3, 5, "Test message"
        )
        
        callback.assert_called_once()
        progress_arg = callback.call_args[0][0]
        self.assertEqual(progress_arg.phase, "Test Phase")
        self.assertEqual(progress_arg.current_step, 3)
        self.assertEqual(progress_arg.total_steps, 5)
        self.assertEqual(progress_arg.message, "Test message")
    
    def test_update_progress_no_callback(self):
        """Test _update_progress with no callback."""
        # Should not raise an exception
        self.splitter._update_progress(
            None, "Test Phase", 3, 5, "Test message"
        )
    
    def test_copy_document_structure(self):
        """Test _copy_document_structure method."""
        # Mock source document with layers, styles, linetypes
        source_doc = Mock()
        source_doc.layers = ["Layer1", "Layer2"]
        source_doc.styles = ["Style1", "Style2"]
        source_doc.linetypes = ["Linetype1", "Linetype2"]
        
        # Mock target document
        target_doc = Mock()
        target_doc.layers = Mock()
        target_doc.layers.__contains__ = Mock(return_value=False)
        target_doc.layers.add = Mock()
        target_doc.styles = Mock()
        target_doc.styles.__contains__ = Mock(return_value=False)
        target_doc.styles.add = Mock()
        target_doc.linetypes = Mock()
        target_doc.linetypes.__contains__ = Mock(return_value=False)
        target_doc.linetypes.add = Mock()
        
        self.splitter._copy_document_structure(source_doc, target_doc)
        
        # Verify add methods were called for each item
        self.assertEqual(target_doc.layers.add.call_count, 2)
        self.assertEqual(target_doc.styles.add.call_count, 2)
        self.assertEqual(target_doc.linetypes.add.call_count, 2)


if __name__ == '__main__':
    unittest.main()
