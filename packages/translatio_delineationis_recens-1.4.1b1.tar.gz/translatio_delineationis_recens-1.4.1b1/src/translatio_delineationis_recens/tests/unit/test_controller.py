"""Unit tests for the DXF to GeoJSON controller."""
import os
import pytest
from unittest.mock import patch, MagicMock, call
import tkinter as tk
from dxf_to_geojson.controller import DxfToGeoJSONController

# Sample file paths for testing
SAMPLE_DXF = "test_file.dxf"
SAMPLE_GEOJSON = "output.geojson"

@pytest.fixture
def root_window():
    """Create a root Tkinter window for testing."""
    root = tk.Tk()
    root.withdraw()  # Hide the window during tests
    yield root
    root.destroy()

@pytest.fixture
def controller(root_window):
    """Create a controller instance for testing."""
    return DxfToGeoJSONController(root_window)

def test_initialization(controller):
    """Test controller initialization."""
    assert controller is not None
    assert controller.model is not None
    assert controller.view is not None
    assert controller.view.browse_dxf_callback is not None
    assert controller.view.browse_geojson_callback is not None
    assert controller.view.convert_callback is not None

@patch('tkinter.filedialog.askopenfilename')
def test_browse_dxf(mock_askopen, controller):
    """Test DXF file browsing."""
    # Setup mock
    mock_askopen.return_value = SAMPLE_DXF
    
    # Call the method
    controller.browse_dxf()
    
    # Verify view was updated
    assert controller.view.get_dxf_path() == SAMPLE_DXF
    assert controller.view.get_geojson_path() == "test_file.geojson"
    
    # Verify convert button is enabled
    assert controller.view.convert_btn['state'] == 'normal' or controller.view.convert_btn['state'] == tk.NORMAL

@patch('tkinter.filedialog.asksaveas_filename')
def test_browse_geojson(mock_asksaveas, controller):
    """Test GeoJSON file browsing."""
    # Setup mock
    mock_asksaveas.return_value = SAMPLE_GEOJSON
    
    # Call the method
    controller.browse_geojson()
    
    # Verify view was updated
    assert controller.view.get_geojson_path() == SAMPLE_GEOJSON

@patch('dxf_to_geojson.controller.DxfToGeoJSONModel')
@patch('dxf_to_geojson.controller.messagebox')
def test_convert_success(mock_messagebox, mock_model_class, controller):
    """Test successful conversion."""
    # Setup mocks
    mock_model = MagicMock()
    mock_model.load_dxf.return_value = True
    mock_model.convert_to_geojson.return_value = True
    mock_model.save_geojson.return_value = True
    mock_model_class.return_value = mock_model
    
    # Set file paths in the view
    controller.view.set_dxf_path(SAMPLE_DXF)
    controller.view.set_geojson_path(SAMPLE_GEOJSON)
    
    # Call the method
    controller.convert()
    
    # Verify model methods were called
    mock_model.load_dxf.assert_called_once_with(SAMPLE_DXF)
    mock_model.convert_to_geojson.assert_called_once()
    mock_model.save_geojson.assert_called_once_with(SAMPLE_GEOJSON)
    
    # Verify success message was shown
    mock_messagebox.showinfo.assert_called_once()
    
    # Verify status was updated
    assert "completed successfully" in controller.view.status_var.get().lower()

@patch('dxf_to_geojson.controller.DxfToGeoJSONModel')
@patch('dxf_to_geojson.controller.messagebox')
def test_convert_load_failure(mock_messagebox, mock_model_class, controller):
    """Test conversion when DXF loading fails."""
    # Setup mocks
    mock_model = MagicMock()
    mock_model.load_dxf.return_value = False
    mock_model_class.return_value = mock_model
    
    # Set file paths in the view
    controller.view.set_dxf_path(SAMPLE_DXF)
    controller.view.set_geojson_path(SAMPLE_GEOJSON)
    
    # Call the method
    controller.convert()
    
    # Verify error message was shown
    mock_messagebox.showerror.assert_called_once()
    assert "failed to load" in mock_messagebox.showerror.call_args[0][1].lower()

@patch('dxf_to_geojson.controller.os.path.exists')
@patch('dxf_to_geojson.controller.messagebox')
def test_convert_file_not_found(mock_messagebox, mock_exists, controller):
    """Test conversion when DXF file doesn't exist."""
    # Setup mock
    mock_exists.return_value = False
    
    # Set file paths in the view
    controller.view.set_dxf_path("nonexistent.dxf")
    controller.view.set_geojson_path(SAMPLE_GEOJSON)
    
    # Call the method
    controller.convert()
    
    # Verify error message was shown
    mock_messagebox.showerror.assert_called_once()
    assert "not found" in mock_messagebox.showerror.call_args[0][1].lower()

@patch('dxf_to_geojson.controller.DxfToGeoJSONModel')
@patch('dxf_to_geojson.controller.messagebox')
def test_convert_save_failure(mock_messagebox, mock_model_class, controller):
    """Test conversion when GeoJSON saving fails."""
    # Setup mocks
    mock_model = MagicMock()
    mock_model.load_dxf.return_value = True
    mock_model.convert_to_geojson.return_value = True
    mock_model.save_geojson.return_value = False  # Simulate save failure
    mock_model_class.return_value = mock_model
    
    # Set file paths in the view
    controller.view.set_dxf_path(SAMPLE_DXF)
    controller.view.set_geojson_path(SAMPLE_GEOJSON)
    
    # Call the method
    controller.convert()
    
    # Verify error message was shown
    mock_messagebox.showerror.assert_called_once()
    assert "failed to save" in mock_messagebox.showerror.call_args[0][1].lower()
