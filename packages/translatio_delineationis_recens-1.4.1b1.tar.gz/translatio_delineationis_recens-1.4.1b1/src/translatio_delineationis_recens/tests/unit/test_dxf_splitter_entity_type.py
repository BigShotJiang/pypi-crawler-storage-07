"""
Unit tests for EntityTypeSplitter.

Tests the type-based filtering and splitting functionality of the DXF Splitter Tool.
"""

import unittest
from unittest.mock import Mock, patch, MagicMock
import tempfile
import os
from collections import defaultdict

# Import the classes to test
from translatio_delineationis_recens.tools.dxf_splitter_tool.splitters.entity_type import (
    EntityTypeSplitter
)
from translatio_delineationis_recens.tools.dxf_splitter_tool.model import (
    SplitResult, SplitProgress
)


class TestEntityTypeSplitter(unittest.TestCase):
    """Test the EntityTypeSplitter class."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.splitter = EntityTypeSplitter()
        self.temp_dir = tempfile.mkdtemp()
        self.test_filepath = os.path.join(self.temp_dir, "test.dxf")
        
        # Create mock DXF document
        self.mock_doc = Mock()
        self.mock_doc.dxfversion = "AC1021"
        
        # Create mock entities of different types
        self.mock_entities = []
        entity_types = ["LINE", "LINE", "LINE", "CIRCLE", "CIRCLE", "POINT", "ARC", "ARC"]
        
        for i, entity_type in enumerate(entity_types):
            entity = Mock()
            entity.dxftype.return_value = entity_type
            entity.copy.return_value = Mock()
            self.mock_entities.append(entity)
        
        # Create mock modelspace
        self.mock_msp = Mock()
        self.mock_msp.__iter__ = Mock(return_value=iter(self.mock_entities))
        self.mock_msp.__len__ = Mock(return_value=len(self.mock_entities))
        self.mock_doc.modelspace.return_value = self.mock_msp
    
    def tearDown(self):
        """Clean up test fixtures."""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_splitter_initialization(self):
        """Test EntityTypeSplitter initialization."""
        self.assertIsNotNone(self.splitter.logger)
    
    def test_split_by_type_invalid_max_entities(self):
        """Test split_by_type with invalid max_entities."""
        result = self.splitter.split_by_type(
            self.mock_doc, self.test_filepath, ["LINE"], 0, self.temp_dir
        )
        
        self.assertFalse(result.success)
        self.assertIn("Maximum entities must be a positive integer", result.error_message)
    
    def test_split_by_type_no_selected_types(self):
        """Test split_by_type with no selected types."""
        result = self.splitter.split_by_type(
            self.mock_doc, self.test_filepath, [], 10, self.temp_dir
        )
        
        self.assertFalse(result.success)
        self.assertIn("At least one entity type must be selected", result.error_message)
    
    def test_split_by_type_no_matching_entities(self):
        """Test split_by_type with no matching entities."""
        result = self.splitter.split_by_type(
            self.mock_doc, self.test_filepath, ["NONEXISTENT"], 10, self.temp_dir
        )
        
        self.assertFalse(result.success)
        self.assertIn("No entities found for selected types", result.error_message)
    
    @patch('translatio_delineationis_recens.tools.dxf_splitter_tool.splitters.entity_type.ezdxf')
    def test_split_by_type_combined_success(self, mock_ezdxf):
        """Test successful split_by_type with combined files."""
        # Mock new document creation
        mock_new_doc = Mock()
        mock_new_doc.modelspace.return_value = Mock()
        mock_new_doc.layers = []
        mock_new_doc.styles = []
        mock_new_doc.linetypes = []
        mock_ezdxf.new.return_value = mock_new_doc
        
        # Mock progress callback
        progress_callback = Mock()
        
        result = self.splitter.split_by_type(
            self.mock_doc, self.test_filepath, ["LINE", "CIRCLE"], 10, self.temp_dir,
            separate_files=False, progress_callback=progress_callback
        )
        
        self.assertTrue(result.success)
        self.assertGreater(len(result.output_files), 0)
        
        # Verify progress callback was called
        self.assertTrue(progress_callback.called)
        
        # Verify new documents were created
        self.assertTrue(mock_ezdxf.new.called)
    
    @patch('translatio_delineationis_recens.tools.dxf_splitter_tool.splitters.entity_type.ezdxf')
    def test_split_by_type_separate_success(self, mock_ezdxf):
        """Test successful split_by_type with separate files."""
        # Mock new document creation
        mock_new_doc = Mock()
        mock_new_doc.modelspace.return_value = Mock()
        mock_new_doc.layers = []
        mock_new_doc.styles = []
        mock_new_doc.linetypes = []
        mock_ezdxf.new.return_value = mock_new_doc
        
        result = self.splitter.split_by_type(
            self.mock_doc, self.test_filepath, ["LINE", "CIRCLE"], 10, self.temp_dir,
            separate_files=True
        )
        
        self.assertTrue(result.success)
        self.assertGreater(len(result.output_files), 0)
        
        # With separate files, we should have at least 2 files (one for LINE, one for CIRCLE)
        # Since we have 3 LINEs and 2 CIRCLEs, and max_entities=10, we expect 2 files
        self.assertEqual(len(result.output_files), 2)
    
    def test_filter_entities_by_type(self):
        """Test _filter_entities_by_type method."""
        selected_types = ["LINE", "CIRCLE"]
        
        entities_by_type = self.splitter._filter_entities_by_type(
            self.mock_doc, selected_types
        )
        
        self.assertIn("LINE", entities_by_type)
        self.assertIn("CIRCLE", entities_by_type)
        self.assertNotIn("POINT", entities_by_type)  # Not selected
        self.assertNotIn("ARC", entities_by_type)    # Not selected
        
        # Check counts
        self.assertEqual(len(entities_by_type["LINE"]), 3)
        self.assertEqual(len(entities_by_type["CIRCLE"]), 2)
    
    def test_create_separate_type_groups(self):
        """Test _create_separate_type_groups method."""
        entities_by_type = {
            "LINE": [Mock() for _ in range(15)],    # 15 LINE entities
            "CIRCLE": [Mock() for _ in range(8)]    # 8 CIRCLE entities
        }
        max_entities = 10
        
        file_groups = self.splitter._create_separate_type_groups(
            entities_by_type, max_entities
        )
        
        # Should have 3 groups: 2 for LINE (15/10 = 2 files), 1 for CIRCLE (8/10 = 1 file)
        self.assertEqual(len(file_groups), 3)
        
        # Check LINE groups
        line_groups = [g for g in file_groups if g['type'] == 'LINE']
        self.assertEqual(len(line_groups), 2)
        self.assertEqual(len(line_groups[0]['entities']), 10)
        self.assertEqual(len(line_groups[1]['entities']), 5)
        
        # Check CIRCLE group
        circle_groups = [g for g in file_groups if g['type'] == 'CIRCLE']
        self.assertEqual(len(circle_groups), 1)
        self.assertEqual(len(circle_groups[0]['entities']), 8)
    
    def test_create_combined_type_groups(self):
        """Test _create_combined_type_groups method."""
        entities_by_type = {
            "LINE": [Mock() for _ in range(7)],     # 7 LINE entities
            "CIRCLE": [Mock() for _ in range(8)]    # 8 CIRCLE entities
        }
        max_entities = 10
        
        file_groups = self.splitter._create_combined_type_groups(
            entities_by_type, max_entities
        )
        
        # Total 15 entities, max 10 per file = 2 files
        self.assertEqual(len(file_groups), 2)
        self.assertEqual(len(file_groups[0]['entities']), 10)
        self.assertEqual(len(file_groups[1]['entities']), 5)
        
        # All groups should be marked as 'mixed'
        for group in file_groups:
            self.assertEqual(group['type'], 'mixed')
    
    @patch('translatio_delineationis_recens.tools.dxf_splitter_tool.splitters.entity_type.ezdxf')
    def test_create_group_document(self, mock_ezdxf):
        """Test _create_group_document method."""
        # Mock new document
        mock_new_doc = Mock()
        mock_new_msp = Mock()
        mock_new_doc.modelspace.return_value = mock_new_msp
        mock_new_doc.layers = []
        mock_new_doc.styles = []
        mock_new_doc.linetypes = []
        mock_ezdxf.new.return_value = mock_new_doc
        
        # Test with subset of entities
        test_entities = self.mock_entities[:3]
        
        result_doc = self.splitter._create_group_document(self.mock_doc, test_entities)
        
        self.assertEqual(result_doc, mock_new_doc)
        
        # Verify entities were added
        self.assertEqual(mock_new_msp.add_entity.call_count, 3)
    
    def test_generate_output_files_separate_naming(self):
        """Test output file naming for separate files."""
        # This tests the naming logic indirectly through file group structure
        file_groups = [
            {
                'entities': [Mock()],
                'type': 'LINE',
                'index': 1,
                'total_for_type': 1
            },
            {
                'entities': [Mock()],
                'type': 'CIRCLE',
                'index': 1,
                'total_for_type': 2
            }
        ]
        
        # The actual file naming is tested in the integration through the main method
        # Expected patterns:
        # - Single file for type: {base_name}_{type}.dxf
        # - Multiple files for type: {base_name}_{type}_{index:03d}.dxf
        pass  # Covered by integration tests
    
    def test_update_progress(self):
        """Test _update_progress method."""
        callback = Mock()
        
        self.splitter._update_progress(
            callback, "Test Phase", 2, 6, "Test message"
        )
        
        callback.assert_called_once()
        progress_arg = callback.call_args[0][0]
        self.assertEqual(progress_arg.phase, "Test Phase")
        self.assertEqual(progress_arg.current_step, 2)
        self.assertEqual(progress_arg.total_steps, 6)
        self.assertEqual(progress_arg.message, "Test message")
    
    def test_update_progress_no_callback(self):
        """Test _update_progress with no callback."""
        # Should not raise an exception
        self.splitter._update_progress(
            None, "Test Phase", 2, 6, "Test message"
        )
    
    def test_copy_document_structure(self):
        """Test _copy_document_structure method."""
        # Mock source document with layers, styles, linetypes
        source_doc = Mock()
        source_doc.layers = ["Layer1", "Layer2"]
        source_doc.styles = ["Style1", "Style2"]
        source_doc.linetypes = ["Linetype1", "Linetype2"]
        
        # Mock target document
        target_doc = Mock()
        target_doc.layers = Mock()
        target_doc.layers.__contains__ = Mock(return_value=False)
        target_doc.layers.add = Mock()
        target_doc.styles = Mock()
        target_doc.styles.__contains__ = Mock(return_value=False)
        target_doc.styles.add = Mock()
        target_doc.linetypes = Mock()
        target_doc.linetypes.__contains__ = Mock(return_value=False)
        target_doc.linetypes.add = Mock()
        
        self.splitter._copy_document_structure(source_doc, target_doc)
        
        # Verify add methods were called for each item
        self.assertEqual(target_doc.layers.add.call_count, 2)
        self.assertEqual(target_doc.styles.add.call_count, 2)
        self.assertEqual(target_doc.linetypes.add.call_count, 2)
    
    def test_edge_case_single_entity_type(self):
        """Test with only one entity type selected."""
        result = self.splitter._filter_entities_by_type(
            self.mock_doc, ["POINT"]
        )
        
        self.assertEqual(len(result), 1)
        self.assertIn("POINT", result)
        self.assertEqual(len(result["POINT"]), 1)
    
    def test_edge_case_large_entity_count(self):
        """Test with entity count that requires multiple files per type."""
        entities_by_type = {
            "LINE": [Mock() for _ in range(25)]  # 25 entities, max 10 per file = 3 files
        }
        max_entities = 10
        
        file_groups = self.splitter._create_separate_type_groups(
            entities_by_type, max_entities
        )
        
        self.assertEqual(len(file_groups), 3)
        self.assertEqual(len(file_groups[0]['entities']), 10)
        self.assertEqual(len(file_groups[1]['entities']), 10)
        self.assertEqual(len(file_groups[2]['entities']), 5)


if __name__ == '__main__':
    unittest.main()
