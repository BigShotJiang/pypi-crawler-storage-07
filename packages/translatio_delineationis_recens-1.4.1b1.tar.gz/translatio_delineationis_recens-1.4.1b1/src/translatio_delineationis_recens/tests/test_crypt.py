"""Tests for the ezdxf.tools.crypt module."""
import pytest
from Code.Python.ezdxf.tools import crypt

class TestCrypt:
    def test_decode_encode_roundtrip(self):
        # ACIS SAT sample lines
        lines = ["A_B@", "TEST LINE", " "]
        # encode then decode should return original lines
        encoded = list(crypt.encode(lines))
        decoded = list(crypt.decode(encoded))
        assert decoded == lines

    def test_decode_empty(self):
        assert list(crypt.decode([])) == []

    def test_encode_empty(self):
        assert list(crypt.encode([])) == []

    def test_encode_decode_non_ascii(self):
        # Non-ASCII chars should be handled (may raise or skip)
        lines = ["A©B"]
        try:
            encoded = list(crypt.encode(lines))
            decoded = list(crypt.decode(encoded))
            # Should not error; may not roundtrip non-ASCII
        except Exception:
            pytest.skip("Non-ASCII not supported")

    def test_module_import(self):
        assert crypt is not None
