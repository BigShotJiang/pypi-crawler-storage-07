"""
Performance tests for the EzDXF library.
These tests measure the execution time of common operations.
"""
import os
import time
import pytest
from pathlib import Path

import ezdxf
from ezdxf.math import Vec3


class TestPerformanceMeasurement:
    """Base class for performance tests with timing utilities."""
    
    def measure_time(self, func, *args, **kwargs):
        """Measure execution time of a function."""
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        execution_time = end_time - start_time
        return result, execution_time


@pytest.mark.slow
class TestEntityCreationPerformance(TestPerformanceMeasurement):
    """Tests for entity creation performance."""
    
    def test_line_creation_performance(self, empty_drawing):
        """Test performance of creating many lines."""
        msp = empty_drawing.modelspace()
        
        # Create multiple single lines for a more accurate baseline
        num_single_lines = 100
        
        def create_single_lines():
            for i in range(num_single_lines):
                msp.add_line((0, i), (10, i))
        
        _, single_lines_time = self.measure_time(create_single_lines)
        single_avg_time = single_lines_time / num_single_lines

        # Create many lines in bulk
        num_bulk_lines = 1000

        def create_many_lines():
            for i in range(num_bulk_lines):
                msp.add_line((0, i + num_single_lines), (10, i + num_single_lines))

        _, bulk_time = self.measure_time(create_many_lines)
        
        # Calculate average time per line
        bulk_avg_time = bulk_time / num_bulk_lines
        
        # Print performance metrics
        print(f"\nLine creation performance:")
        print(f"  {num_single_lines} individual lines: {single_lines_time:.6f} seconds (avg: {single_avg_time:.9f} seconds per line)")
        print(f"  {num_bulk_lines} bulk lines: {bulk_time:.6f} seconds (avg: {bulk_avg_time:.9f} seconds per line)")
        
        # Assert that performance is reasonable
        # We're not comparing single vs bulk anymore since that's not a reliable test
        # Instead, just ensure the bulk creation is reasonably fast
        assert bulk_avg_time < 0.001, "Line creation is too slow"
    
    def test_circle_creation_performance(self, empty_drawing):
        """Test performance of creating many circles."""
        msp = empty_drawing.modelspace()
        
        # Create multiple single circles for a more accurate baseline
        num_single_circles = 100
        
        def create_single_circles():
            for i in range(num_single_circles):
                msp.add_circle((i, i), 1.0)
        
        _, single_circles_time = self.measure_time(create_single_circles)
        single_avg_time = single_circles_time / num_single_circles

        # Create many circles in bulk
        num_bulk_circles = 1000

        def create_many_circles():
            for i in range(num_bulk_circles):
                msp.add_circle((i + num_single_circles, i + num_single_circles), 1.0)

        _, bulk_time = self.measure_time(create_many_circles)
        
        # Calculate average time per circle
        bulk_avg_time = bulk_time / num_bulk_circles
        
        # Print performance metrics
        print(f"\nCircle creation performance:")
        print(f"  {num_single_circles} individual circles: {single_circles_time:.6f} seconds (avg: {single_avg_time:.9f} seconds per circle)")
        print(f"  {num_bulk_circles} bulk circles: {bulk_time:.6f} seconds (avg: {bulk_avg_time:.9f} seconds per circle)")
        
        # Assert that performance is reasonable
        # We're not comparing single vs bulk anymore since that's not a reliable test
        # Instead, just ensure the bulk creation is reasonably fast
        assert bulk_avg_time < 0.001, "Circle creation is too slow"
    
    def test_polyline_creation_performance(self, empty_drawing):
        """Test performance of creating polylines with different numbers of vertices."""
        msp = empty_drawing.modelspace()
        
        # Test with different numbers of vertices
        vertex_counts = [10, 100, 1000]
        
        for count in vertex_counts:
            # Create points
            points = [(i, i) for i in range(count)]
            
            # Measure time to create polyline
            _, creation_time = self.measure_time(msp.add_lwpolyline, points)
            
            # Print performance metrics
            print(f"\nPolyline creation with {count} vertices: {creation_time:.6f} seconds")
            
            # Simple assertion to catch major performance regressions
            # These thresholds may need adjustment based on actual performance
            if count == 10:
                assert creation_time < 0.1, f"Creating a 10-vertex polyline took too long: {creation_time:.6f} seconds"
            elif count == 100:
                assert creation_time < 0.5, f"Creating a 100-vertex polyline took too long: {creation_time:.6f} seconds"
            elif count == 1000:
                assert creation_time < 5.0, f"Creating a 1000-vertex polyline took too long: {creation_time:.6f} seconds"


@pytest.mark.slow
class TestFileOperationPerformance(TestPerformanceMeasurement):
    """Tests for file operation performance."""
    
    def test_save_performance(self, tmpdir):
        """Test performance of saving drawings with different numbers of entities."""
        # Test with different numbers of entities
        entity_counts = [100, 1000, 10000]
        
        for count in entity_counts:
            # Create a new drawing
            doc = ezdxf.new("R2018")
            msp = doc.modelspace()
            
            # Add entities
            for i in range(count):
                msp.add_line((0, i), (10, i))
            
            # Measure save time
            filepath = os.path.join(tmpdir, f"save_test_{count}.dxf")
            _, save_time = self.measure_time(doc.saveas, filepath)
            
            # Print performance metrics
            print(f"\nSaving drawing with {count} entities: {save_time:.6f} seconds")
            
            # Simple assertions to catch major performance regressions
            if count == 100:
                assert save_time < 0.5, f"Saving 100 entities took too long: {save_time:.6f} seconds"
            elif count == 1000:
                assert save_time < 2.0, f"Saving 1000 entities took too long: {save_time:.6f} seconds"
            elif count == 10000:
                assert save_time < 15.0, f"Saving 10000 entities took too long: {save_time:.6f} seconds"
    
    def test_load_performance(self, tmpdir):
        """Test performance of loading drawings with different numbers of entities."""
        # Create test files with different numbers of entities
        entity_counts = [100, 1000, 10000]
        filepaths = []
        
        for count in entity_counts:
            # Create a new drawing
            doc = ezdxf.new("R2018")
            msp = doc.modelspace()
            
            # Add entities
            for i in range(count):
                msp.add_line((0, i), (10, i))
            
            # Save the drawing
            filepath = os.path.join(tmpdir, f"load_test_{count}.dxf")
            doc.saveas(filepath)
            filepaths.append((count, filepath))
        
        # Test loading each file
        for count, filepath in filepaths:
            # Measure load time
            _, load_time = self.measure_time(ezdxf.readfile, filepath)
            
            # Print performance metrics
            print(f"\nLoading drawing with {count} entities: {load_time:.6f} seconds")
            
            # Simple assertions to catch major performance regressions
            if count == 100:
                assert load_time < 0.5, f"Loading 100 entities took too long: {load_time:.6f} seconds"
            elif count == 1000:
                assert load_time < 2.0, f"Loading 1000 entities took too long: {load_time:.6f} seconds"
            elif count == 10000:
                assert load_time < 15.0, f"Loading 10000 entities took too long: {load_time:.6f} seconds"


@pytest.mark.slow
class TestGeometricOperationsPerformance(TestPerformanceMeasurement):
    """Tests for geometric operations performance."""
    
    def test_vector_operations_performance(self):
        """Test performance of vector operations."""
        # Create test vectors
        v1 = Vec3(1, 2, 3)
        v2 = Vec3(4, 5, 6)
        
        # Test single operations
        _, add_time = self.measure_time(lambda: v1 + v2)
        _, dot_time = self.measure_time(lambda: v1.dot(v2))
        _, cross_time = self.measure_time(lambda: v1.cross(v2))
        
        # Test bulk operations
        num_ops = 100000
        
        def bulk_add():
            result = Vec3(0, 0, 0)
            for _ in range(num_ops):
                result += v1
            return result
        
        def bulk_dot():
            result = 0
            for _ in range(num_ops):
                result += v1.dot(v2)
            return result
        
        def bulk_cross():
            result = Vec3(0, 0, 0)
            for _ in range(num_ops):
                result += v1.cross(v2)
            return result
        
        _, bulk_add_time = self.measure_time(bulk_add)
        _, bulk_dot_time = self.measure_time(bulk_dot)
        _, bulk_cross_time = self.measure_time(bulk_cross)
        
        # Print performance metrics
        print(f"\nVector operation performance:")
        print(f"  Single addition: {add_time:.9f} seconds")
        print(f"  Single dot product: {dot_time:.9f} seconds")
        print(f"  Single cross product: {cross_time:.9f} seconds")
        print(f"  {num_ops} additions: {bulk_add_time:.6f} seconds (avg: {bulk_add_time/num_ops:.9f} seconds per op)")
        print(f"  {num_ops} dot products: {bulk_dot_time:.6f} seconds (avg: {bulk_dot_time/num_ops:.9f} seconds per op)")
        print(f"  {num_ops} cross products: {bulk_cross_time:.6f} seconds (avg: {bulk_cross_time/num_ops:.9f} seconds per op)")
        
        # Simple assertions to catch major performance regressions
        # Using more realistic thresholds based on actual performance
        assert bulk_add_time/num_ops < 1e-5, "Vector addition is too slow"
        assert bulk_dot_time/num_ops < 1e-5, "Vector dot product is too slow"
        assert bulk_cross_time/num_ops < 2e-5, "Vector cross product is too slow"
    
    def test_entity_transformation_performance(self, empty_drawing):
        """Test performance of entity transformations."""
        msp = empty_drawing.modelspace()
        
        # Create test entities
        num_entities = 1000
        lines = []
        for i in range(num_entities):
            lines.append(msp.add_line((0, i), (10, i)))
        
        # Test single transformation
        _, single_time = self.measure_time(lines[0].translate, 5, 5, 0)
        
        # Test bulk transformation
        def bulk_transform():
            for line in lines:
                line.translate(5, 5, 0)
        
        _, bulk_time = self.measure_time(bulk_transform)
        
        # Print performance metrics
        print(f"\nEntity transformation performance:")
        print(f"  Single translation: {single_time:.6f} seconds")
        print(f"  {num_entities} translations: {bulk_time:.6f} seconds (avg: {bulk_time/num_entities:.6f} seconds per entity)")
        
        # Simple assertion to catch major performance regressions
        assert bulk_time/num_entities < 0.001, "Entity transformation is too slow"
