import pytest
from types import SimpleNamespace

from Code.Python.ezdxf.acis import abstract

# Minimal stub for AbstractEntity
def make_entity(name):
    class Entity(abstract.AbstractEntity):
        def __init__(self, name):
            self.name = name
    return Entity(name)

def test_abstract_entity_str_and_null_ptr():
    e1 = make_entity("SOME_ENTITY")
    e2 = make_entity(abstract.NULL_PTR_NAME)
    assert str(e1) == "SOME_ENTITY"
    assert str(e2) == abstract.NULL_PTR_NAME
    assert not e1.is_null_ptr
    assert e2.is_null_ptr

# Minimal stub for AbstractBuilder
def test_abstract_builder_methods():
    class DummyEntity:
        def __init__(self, name):
            self.name = name
            self.id = -1
    header = SimpleNamespace(version=1)
    builder = abstract.AbstractBuilder()
    builder.header = header
    builder.entities = [DummyEntity("asmheader"), DummyEntity("body"), DummyEntity("other")]
    builder.bodies = []
    builder.reorder_records()
    assert builder.entities[0].name == "asmheader"
    assert builder.entities[1].name == "body"
    builder.reset_ids(start=10)
    assert builder.entities[0].id == 10
    builder.clear_ids()
    assert all(e.id == -1 for e in builder.entities)

# Minimal stub for EntityExporter
class DummyAcisEntity:
    def __init__(self, name="dummy", subentities=None, is_none=False):
        self.name = name
        self._entities = subentities or []
        self.is_none = is_none
        self.attributes = SimpleNamespace(is_none=True)
    def entities(self):
        # Yield all subentities and the attribute entity if present and not is_none
        for e in self._entities:
            yield e
        if hasattr(self, "attributes") and self.attributes and not getattr(self.attributes, "is_none", True):
            yield self.attributes
    def export(self, exporter):
        self.export_called = True

class DummyRecord:
    def __init__(self):
        self.attributes = None

class DummyExporter(abstract.EntityExporter):
    def make_record(self, entity):
        return DummyRecord()
    def make_data_exporter(self, record):
        return None

def test_entity_exporter_export_and_get_record():
    header = SimpleNamespace(version=1, has_asm_header=False)
    exporter = DummyExporter(header)
    entity = DummyAcisEntity()
    exporter.export(entity)
    record = exporter.get_record(entity)
    assert isinstance(record, DummyRecord)

    # Export with subentities
    sub1 = DummyAcisEntity("sub1")
    sub2 = DummyAcisEntity("sub2")
    entity2 = DummyAcisEntity(subentities=[sub1, sub2])
    exporter2 = DummyExporter(header)
    exporter2.export(entity2)
    assert exporter2.get_record(entity2)
    assert exporter2.get_record(sub1)
    assert exporter2.get_record(sub2)

    # Export with attributes
    entity3 = DummyAcisEntity()
    entity3.attributes = DummyAcisEntity("attr")
    exporter3 = DummyExporter(header)
    exporter3.export(entity3)
    assert exporter3.get_record(entity3)
    assert exporter3.get_record(entity3.attributes)

def test_entity_exporter_export_none_entity_raises():
    header = SimpleNamespace(version=1, has_asm_header=False)
    exporter = DummyExporter(header)
    entity = DummyAcisEntity(is_none=True)
    with pytest.raises(TypeError):
        exporter.export(entity)
