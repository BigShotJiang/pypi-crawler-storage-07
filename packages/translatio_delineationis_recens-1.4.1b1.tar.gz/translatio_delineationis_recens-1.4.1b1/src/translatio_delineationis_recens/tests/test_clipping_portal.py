"""
Tests for the clipping_portal module functionality in the EzDXF library.
"""
import pytest
import math
from pathlib import Path

import ezdxf
import numpy as np
from ezdxf.math import Vec2, BoundingBox2d, Matrix44
from ezdxf.npshapes import NumpyPath2d, NumpyPoints2d
from ezdxf.tools.clipping_portal import (
    ClippingShape,
    ClippingPortal,
    ClippingRect,
    ConvexClippingPolygon,
    ConcaveClippingPolygon,
    InvertedClippingPolygon,
    find_best_clipping_shape,
    make_inverted_clipping_shape,
)


class TestClippingRect:
    """Tests for the ClippingRect class."""
    
    def test_clipping_rect_creation(self):
        """Test creating a ClippingRect instance."""
        # Create a simple rectangle
        vertices = [(0, 0), (10, 0), (10, 10), (0, 10)]
        rect = ClippingRect(vertices)
        
        # Verify the bounding box was created correctly
        bbox = rect.bbox()
        assert bbox.extmin == Vec2(0, 0)
        assert bbox.extmax == Vec2(10, 10)
    
    def test_is_completely_inside(self):
        """Test checking if a bounding box is completely inside the clipping rect."""
        # Create a clipping rectangle
        vertices = [(0, 0), (10, 0), (10, 10), (0, 10)]
        rect = ClippingRect(vertices)
        
        # Test with a bounding box completely inside
        inside_bbox = BoundingBox2d([(2, 2), (8, 8)])
        assert rect.is_completely_inside(inside_bbox) is True
        
        # Test with a bounding box partially inside
        partial_bbox = BoundingBox2d([(-2, 2), (8, 8)])
        assert rect.is_completely_inside(partial_bbox) is False
        
        # Test with a bounding box completely outside
        outside_bbox = BoundingBox2d([(-5, -5), (-2, -2)])
        assert rect.is_completely_inside(outside_bbox) is False
    
    def test_is_completely_outside(self):
        """Test checking if a bounding box is completely outside the clipping rect."""
        # Create a clipping rectangle
        vertices = [(0, 0), (10, 0), (10, 10), (0, 10)]
        rect = ClippingRect(vertices)
        
        # Test with a bounding box completely outside
        outside_bbox = BoundingBox2d([(-5, -5), (-2, -2)])
        assert rect.is_completely_outside(outside_bbox) is True
        
        # Test with a bounding box partially inside
        partial_bbox = BoundingBox2d([(-2, 2), (8, 8)])
        assert rect.is_completely_outside(partial_bbox) is False
        
        # Test with a bounding box completely inside
        inside_bbox = BoundingBox2d([(2, 2), (8, 8)])
        assert rect.is_completely_outside(inside_bbox) is False
    
    def test_clip_point(self):
        """Test clipping a point against a rectangle."""
        # Create a clipping rectangle
        vertices = [(0, 0), (10, 0), (10, 10), (0, 10)]
        rect = ClippingRect(vertices)
        
        # Test with a point inside
        inside_point = Vec2(5, 5)
        assert rect.clip_point(inside_point) == inside_point
        
        # Test with a point outside
        outside_point = Vec2(-5, -5)
        assert rect.clip_point(outside_point) is None
        
        # Test with a point on the boundary
        boundary_point = Vec2(0, 5)
        assert rect.clip_point(boundary_point) == boundary_point
    
    def test_clip_line(self):
        """Test clipping a line against a rectangle."""
        # Create a clipping rectangle
        vertices = [(0, 0), (10, 0), (10, 10), (0, 10)]
        rect = ClippingRect(vertices)
        
        # Test with a line completely inside
        inside_line = (Vec2(2, 2), Vec2(8, 8))
        clipped_lines = rect.clip_line(*inside_line)
        assert len(clipped_lines) == 1
        assert clipped_lines[0] == inside_line
        
        # Test with a line completely outside
        outside_line = (Vec2(-5, -5), Vec2(-2, -2))
        clipped_lines = rect.clip_line(*outside_line)
        assert len(clipped_lines) == 0
        
        # Test with a line partially inside
        partial_line = (Vec2(-5, 5), Vec2(15, 5))
        clipped_lines = rect.clip_line(*partial_line)
        assert len(clipped_lines) == 1
        assert clipped_lines[0][0] == Vec2(0, 5)
        assert clipped_lines[0][1] == Vec2(10, 5)
    
    def test_clip_polyline(self):
        """Test clipping a polyline against a rectangle."""
        # Create a clipping rectangle
        vertices = [(0, 0), (10, 0), (10, 10), (0, 10)]
        rect = ClippingRect(vertices)
        
        # Test with a polyline completely inside
        inside_points = NumpyPoints2d([Vec2(2, 2), Vec2(5, 8), Vec2(8, 2)])
        clipped_polylines = rect.clip_polyline(inside_points)
        assert len(clipped_polylines) == 1
        assert len(clipped_polylines[0]) == 3
        
        # Test with a polyline completely outside
        outside_points = NumpyPoints2d([Vec2(-5, -5), Vec2(-2, -2), Vec2(-3, -7)])
        clipped_polylines = rect.clip_polyline(outside_points)
        assert len(clipped_polylines) == 0
        
        # Test with a polyline partially inside
        partial_points = NumpyPoints2d([Vec2(-5, 5), Vec2(5, 5), Vec2(15, 5)])
        clipped_polylines = rect.clip_polyline(partial_points)
        assert len(clipped_polylines) == 1
        # The implementation returns 3 points for this case (includes both intersection points and the middle point)
        assert len(clipped_polylines[0]) == 3
    
    def test_clip_polygon(self):
        """Test clipping a polygon against a rectangle."""
        # Create a clipping rectangle
        vertices = [(0, 0), (10, 0), (10, 10), (0, 10)]
        rect = ClippingRect(vertices)
        
        # Test with a polygon completely inside
        inside_points = NumpyPoints2d([Vec2(2, 2), Vec2(5, 8), Vec2(8, 2)])
        clipped_polygons = rect.clip_polygon(inside_points)
        assert len(clipped_polygons) == 1
        assert len(clipped_polygons[0]) == 3
        
        # Test with a polygon completely outside
        outside_points = NumpyPoints2d([Vec2(-5, -5), Vec2(-2, -2), Vec2(-3, -7)])
        clipped_polygons = rect.clip_polygon(outside_points)
        assert len(clipped_polygons) == 0
        
        # Test with a polygon partially inside
        partial_points = NumpyPoints2d([Vec2(-5, 5), Vec2(5, 5), Vec2(5, 15)])
        clipped_polygons = rect.clip_polygon(partial_points)
        assert len(clipped_polygons) == 1
        # The clipped polygon should have 4 points (intersection with the rectangle)
        assert len(clipped_polygons[0]) == 4


class TestConvexClippingPolygon:
    """Tests for the ConvexClippingPolygon class."""
    
    def test_convex_clipping_polygon_creation(self):
        """Test creating a ConvexClippingPolygon instance."""
        # Create a simple convex polygon (a triangle)
        vertices = [(0, 0), (10, 0), (5, 10)]
        polygon = ConvexClippingPolygon(vertices)
        
        # Verify the bounding box was created correctly
        bbox = polygon.bbox()
        assert bbox.extmin == Vec2(0, 0)
        assert bbox.extmax == Vec2(10, 10)
    
    def test_is_completely_inside(self):
        """Test checking if a bounding box is completely inside the clipping polygon."""
        # Create a clipping polygon (a triangle)
        vertices = [(0, 0), (10, 0), (5, 10)]
        polygon = ConvexClippingPolygon(vertices)
        
        # The implementation always returns False for this method
        # as it's difficult to determine if a bbox is completely inside a polygon
        inside_bbox = BoundingBox2d([(2, 2), (4, 4)])
        assert polygon.is_completely_inside(inside_bbox) is False
    
    def test_is_completely_outside(self):
        """Test checking if a bounding box is completely outside the clipping polygon."""
        # Create a clipping polygon (a triangle)
        vertices = [(0, 0), (10, 0), (5, 10)]
        polygon = ConvexClippingPolygon(vertices)
        
        # Test with a bounding box completely outside
        outside_bbox = BoundingBox2d([(-5, -5), (-2, -2)])
        assert polygon.is_completely_outside(outside_bbox) is True
        
        # Test with a bounding box partially inside
        partial_bbox = BoundingBox2d([(-2, -2), (2, 2)])
        assert polygon.is_completely_outside(partial_bbox) is False
    
    def test_clip_point(self):
        """Test clipping a point against a convex polygon."""
        # Create a clipping polygon (a triangle)
        vertices = [(0, 0), (10, 0), (5, 10)]
        polygon = ConvexClippingPolygon(vertices)
        
        # Test with a point inside
        inside_point = Vec2(5, 2)
        assert polygon.clip_point(inside_point) == inside_point
        
        # Test with a point outside
        outside_point = Vec2(-5, -5)
        assert polygon.clip_point(outside_point) is None
        
        # Test with a point on the boundary
        boundary_point = Vec2(5, 0)
        assert polygon.clip_point(boundary_point) == boundary_point


class TestConcaveClippingPolygon:
    """Tests for the ConcaveClippingPolygon class."""
    
    def test_concave_clipping_polygon_creation(self):
        """Test creating a ConcaveClippingPolygon instance."""
        # Create a simple concave polygon
        vertices = [(0, 0), (10, 0), (10, 10), (5, 5), (0, 10)]
        polygon = ConcaveClippingPolygon(vertices)
        
        # Verify the bounding box was created correctly
        bbox = polygon.bbox()
        assert bbox.extmin == Vec2(0, 0)
        assert bbox.extmax == Vec2(10, 10)
    
    def test_is_completely_inside(self):
        """Test checking if a bounding box is completely inside the clipping polygon."""
        # Create a clipping polygon
        vertices = [(0, 0), (10, 0), (10, 10), (5, 5), (0, 10)]
        polygon = ConcaveClippingPolygon(vertices)
        
        # The implementation always returns False for this method
        inside_bbox = BoundingBox2d([(2, 2), (4, 4)])
        assert polygon.is_completely_inside(inside_bbox) is False
    
    def test_is_completely_outside(self):
        """Test checking if a bounding box is completely outside the clipping polygon."""
        # Create a clipping polygon
        vertices = [(0, 0), (10, 0), (10, 10), (5, 5), (0, 10)]
        polygon = ConcaveClippingPolygon(vertices)
        
        # Test with a bounding box completely outside
        outside_bbox = BoundingBox2d([(-5, -5), (-2, -2)])
        assert polygon.is_completely_outside(outside_bbox) is True
        
        # Test with a bounding box partially inside
        partial_bbox = BoundingBox2d([(-2, -2), (2, 2)])
        assert polygon.is_completely_outside(partial_bbox) is False


class TestInvertedClippingPolygon:
    """Tests for the InvertedClippingPolygon class."""
    
    def test_inverted_clipping_polygon_creation(self):
        """Test creating an InvertedClippingPolygon instance."""
        # Create a simple polygon to invert
        vertices = [(2, 2), (8, 2), (8, 8), (2, 8)]
        outer_bounds = BoundingBox2d([(0, 0), (10, 10)])
        polygon = InvertedClippingPolygon(vertices, outer_bounds)
        
        # Verify the bounding box was created correctly (should be the outer bounds)
        bbox = polygon.bbox()
        assert bbox.extmin == Vec2(0, 0)
        assert bbox.extmax == Vec2(10, 10)
    
    def test_is_completely_inside(self):
        """Test checking if a bounding box is completely inside the inverted clipping polygon."""
        # Create an inverted clipping polygon
        vertices = [(2, 2), (8, 2), (8, 8), (2, 8)]
        outer_bounds = BoundingBox2d([(0, 0), (10, 10)])
        polygon = InvertedClippingPolygon(vertices, outer_bounds)
        
        # The implementation always returns False for this method
        inside_bbox = BoundingBox2d([(0, 0), (1, 1)])
        assert polygon.is_completely_inside(inside_bbox) is False
    
    def test_is_completely_outside(self):
        """Test checking if a bounding box is completely outside the inverted clipping polygon."""
        # Create an inverted clipping polygon
        vertices = [(2, 2), (8, 2), (8, 8), (2, 8)]
        outer_bounds = BoundingBox2d([(0, 0), (10, 10)])
        polygon = InvertedClippingPolygon(vertices, outer_bounds)
        
        # Test with a bounding box completely outside the outer bounds
        outside_bbox = BoundingBox2d([(-5, -5), (-2, -2)])
        assert polygon.is_completely_outside(outside_bbox) is True
        
        # Test with a bounding box inside the original polygon (which is now "outside" the inverted polygon)
        inside_original = BoundingBox2d([(3, 3), (7, 7)])
        assert polygon.is_completely_outside(inside_original) is False


class TestClippingPortal:
    """Tests for the ClippingPortal class."""
    
    def test_clipping_portal_creation(self):
        """Test creating a ClippingPortal instance."""
        portal = ClippingPortal()
        assert portal.is_active is False
    
    def test_push_pop(self):
        """Test pushing and popping clipping shapes to/from the portal."""
        portal = ClippingPortal()
        
        # Create a simple clipping rectangle
        vertices = [(0, 0), (10, 0), (10, 10), (0, 10)]
        rect = ClippingRect(vertices)
        
        # Push the clipping shape to the portal
        portal.push(rect, None)
        assert portal.is_active is True
        
        # Pop the clipping shape from the portal
        portal.pop()
        assert portal.is_active is False
    
    def test_clip_point(self):
        """Test clipping a point using the portal."""
        portal = ClippingPortal()
        
        # Create a simple clipping rectangle
        vertices = [(0, 0), (10, 0), (10, 10), (0, 10)]
        rect = ClippingRect(vertices)
        
        # Push the clipping shape to the portal
        portal.push(rect, None)
        
        # Test with a point inside
        inside_point = Vec2(5, 5)
        assert portal.clip_point(inside_point) == inside_point
        
        # Test with a point outside
        outside_point = Vec2(-5, -5)
        assert portal.clip_point(outside_point) is None
    
    def test_clip_line(self):
        """Test clipping a line using the portal."""
        portal = ClippingPortal()
        
        # Create a simple clipping rectangle
        vertices = [(0, 0), (10, 0), (10, 10), (0, 10)]
        rect = ClippingRect(vertices)
        
        # Push the clipping shape to the portal
        portal.push(rect, None)
        
        # Test with a line partially inside
        partial_line = (Vec2(-5, 5), Vec2(15, 5))
        clipped_lines = portal.clip_line(*partial_line)
        assert len(clipped_lines) == 1
        assert clipped_lines[0][0] == Vec2(0, 5)
        assert clipped_lines[0][1] == Vec2(10, 5)
    
    def test_transform_matrix(self):
        """Test applying a transformation matrix to the portal."""
        portal = ClippingPortal()
        
        # Create a simple clipping rectangle
        vertices = [(0, 0), (10, 0), (10, 10), (0, 10)]
        rect = ClippingRect(vertices)
        
        # Create a translation matrix
        m = Matrix44.translate(5, 5, 0)
        
        # Push the clipping shape to the portal with the transformation
        portal.push(rect, m)
        
        # Test with a point that would be inside after transformation
        # The point (0, 0) gets transformed to (5, 5) which is inside the rectangle (0,0,10,10)
        # after accounting for the transformation
        point = Vec2(0, 0)
        transformed_point = portal.clip_point(point)
        # The point should be clipped and returned (not None)
        assert transformed_point is not None


class TestUtilityFunctions:
    """Tests for the utility functions in the clipping_portal module."""
    
    def test_find_best_clipping_shape(self):
        """Test the find_best_clipping_shape function."""
        # Test with a rectangle
        rect_vertices = [(0, 0), (10, 0), (10, 10), (0, 10)]
        rect_shape = find_best_clipping_shape(rect_vertices)
        assert isinstance(rect_shape, ClippingRect)
        
        # Test with a convex polygon (triangle)
        convex_vertices = [(0, 0), (10, 0), (5, 10)]
        convex_shape = find_best_clipping_shape(convex_vertices)
        assert isinstance(convex_shape, ConvexClippingPolygon)
        
        # Test with a concave polygon
        concave_vertices = [(0, 0), (10, 0), (10, 10), (5, 5), (0, 10)]
        concave_shape = find_best_clipping_shape(concave_vertices)
        assert isinstance(concave_shape, ConcaveClippingPolygon)
    
    def test_make_inverted_clipping_shape(self):
        """Test the make_inverted_clipping_shape function."""
        # Create a polygon to invert
        vertices = [(2, 2), (8, 2), (8, 8), (2, 8)]
        outer_bounds = BoundingBox2d([(0, 0), (10, 10)])
        
        # Create an inverted clipping shape
        inverted_shape = make_inverted_clipping_shape(vertices, outer_bounds)
        assert isinstance(inverted_shape, InvertedClippingPolygon)
        
        # Verify the bounding box was created correctly
        bbox = inverted_shape.bbox()
        assert bbox.extmin == Vec2(0, 0)
        assert bbox.extmax == Vec2(10, 10)
