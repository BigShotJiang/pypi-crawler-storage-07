#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Run test coverage analysis for the EzDXF library.

This script runs the pytest test suite with coverage reporting to measure
how much of the codebase is covered by tests.
"""
import os
import sys
import subprocess
from pathlib import Path

# Define WinPython executable path
WINPYTHON_PATH = Path(r"C:\Program Files\WinPython")
PYTHON_EXE = WINPYTHON_PATH / "python" / "python.exe"

# Add the library to the Python path
sys.path.insert(0, str(Path(__file__).parent / "Code" / "Python"))


def run_coverage():
    """Run test coverage analysis."""
    # Make sure we're in the project root directory
    os.chdir(Path(__file__).parent)
    
    # Run pytest with coverage
    cmd = [
        str(PYTHON_EXE),
        "-m",
        "pytest",
        "--cov=ezdxf",
        "--cov-report=term",
        "--cov-report=html:coverage_report",
        "tests/",
    ]
    
    print(f"Running command: {' '.join(cmd)}")
    result = subprocess.run(cmd, capture_output=True, text=True)
    
    # Print the output
    print("\nTest Results:")
    print(result.stdout)
    
    if result.stderr:
        print("\nErrors:")
        print(result.stderr)
    
    # Check if the coverage report was generated
    report_dir = Path("coverage_report")
    if report_dir.exists():
        print(f"\nCoverage report generated at: {report_dir.absolute()}")
        print("Open index.html in that directory to view the detailed report.")
    else:
        print("\nFailed to generate coverage report.")


if __name__ == "__main__":
    run_coverage()
