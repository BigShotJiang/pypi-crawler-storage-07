"""Tests for the ezdxf.units module."""
import pytest
import math
from Code.Python.ezdxf.units import (
    DrawingUnits, PaperSpaceUnits, decode, conversion_factor, unit_name, angle_unit_name,
    MSP_METRIC_UNITS_FACTORS, METER_FACTOR, IMPERIAL_UNITS, ANGLE_UNITS,
    IN, FT, MI, MM, CM, M, KM, YD, DM
)
from ezdxf.enums import InsertUnits


class TestUnitConstants:
    """Test cases for unit constants."""

    def test_metric_units_factors(self):
        """Test MSP_METRIC_UNITS_FACTORS dictionary."""
        # Check that the dictionary contains expected keys
        assert "m" in MSP_METRIC_UNITS_FACTORS
        assert "mm" in MSP_METRIC_UNITS_FACTORS
        assert "cm" in MSP_METRIC_UNITS_FACTORS
        assert "km" in MSP_METRIC_UNITS_FACTORS
        
        # Check specific conversion factors
        assert MSP_METRIC_UNITS_FACTORS["m"] == 1.0
        assert MSP_METRIC_UNITS_FACTORS["mm"] == 1000.0
        assert MSP_METRIC_UNITS_FACTORS["cm"] == 100.0
        assert MSP_METRIC_UNITS_FACTORS["km"] == 0.001
        
        # Check imperial units in the dictionary
        assert "in" in MSP_METRIC_UNITS_FACTORS
        assert "ft" in MSP_METRIC_UNITS_FACTORS
        assert "yd" in MSP_METRIC_UNITS_FACTORS
        assert "mi" in MSP_METRIC_UNITS_FACTORS

    def test_meter_factor(self):
        """Test METER_FACTOR list."""
        # Check specific conversion factors
        assert METER_FACTOR[IN] == 39.37007874  # Inches
        assert METER_FACTOR[FT] == 3.280839895  # Feet
        assert METER_FACTOR[MI] == 0.00062137119  # Miles
        assert METER_FACTOR[MM] == 1000.0  # Millimeters
        assert METER_FACTOR[CM] == 100.0  # Centimeters
        assert METER_FACTOR[M] == 1.0  # Meters
        assert METER_FACTOR[KM] == 0.001  # Kilometers
        assert METER_FACTOR[YD] == 1.093613298  # Yards
        assert METER_FACTOR[DM] == 10.0  # Decimeters
        
        # Check that None is used for unsupported units
        assert METER_FACTOR[0] is None  # Unitless
        assert METER_FACTOR[21] is None  # US Survey Feet
        assert METER_FACTOR[22] is None  # US Survey Inch
        assert METER_FACTOR[23] is None  # US Survey Yard
        assert METER_FACTOR[24] is None  # US Survey Mile

    def test_imperial_units(self):
        """Test IMPERIAL_UNITS set."""
        # Check that the set contains expected values
        assert InsertUnits.Inches in IMPERIAL_UNITS
        assert InsertUnits.Feet in IMPERIAL_UNITS
        assert InsertUnits.Miles in IMPERIAL_UNITS
        assert InsertUnits.Yards in IMPERIAL_UNITS
        
        # Check that metric units are not in the set
        assert InsertUnits.Millimeters not in IMPERIAL_UNITS
        assert InsertUnits.Centimeters not in IMPERIAL_UNITS
        assert InsertUnits.Meters not in IMPERIAL_UNITS
        assert InsertUnits.Kilometers not in IMPERIAL_UNITS

    def test_angle_units(self):
        """Test ANGLE_UNITS dictionary."""
        # Check that the dictionary contains expected keys and values
        assert 0 in ANGLE_UNITS
        assert 1 in ANGLE_UNITS
        assert 2 in ANGLE_UNITS
        assert 3 in ANGLE_UNITS
        
        assert ANGLE_UNITS[0] == "Decimal Degrees"
        assert ANGLE_UNITS[1] == "Degrees/Minutes/Seconds"
        assert ANGLE_UNITS[2] == "Grad"
        assert ANGLE_UNITS[3] == "Radians"


class TestDrawingUnits:
    """Test cases for DrawingUnits class."""

    def test_init_default(self):
        """Test DrawingUnits initialization with default values."""
        units = DrawingUnits()
        
        # Check default values
        assert units.base == 1.0
        assert units.unit == "m"
        assert units._units == MSP_METRIC_UNITS_FACTORS
        assert units._msp_factor == 1.0  # base * MSP_METRIC_UNITS_FACTORS["m"]

    def test_init_custom(self):
        """Test DrawingUnits initialization with custom values."""
        units = DrawingUnits(base=2.5, unit="cm")
        
        # Check custom values
        assert units.base == 2.5
        assert units.unit == "cm"
        assert units._msp_factor == 2.5 * 100.0  # base * MSP_METRIC_UNITS_FACTORS["cm"]

    def test_init_uppercase_unit(self):
        """Test DrawingUnits initialization with uppercase unit."""
        units = DrawingUnits(unit="MM")
        
        # Check that unit is converted to lowercase
        assert units.unit == "mm"
        assert units._msp_factor == 1000.0  # MSP_METRIC_UNITS_FACTORS["mm"]

    def test_factor_method(self):
        """Test factor method."""
        units = DrawingUnits(base=1.0, unit="m")
        
        # Check conversion factors for different units
        assert units.factor("mm") == 0.001  # 1m = 1000mm, so factor is 1/1000
        assert units.factor("cm") == 0.01  # 1m = 100cm, so factor is 1/100
        assert units.factor("km") == 1000.0  # 1m = 0.001km, so factor is 1/0.001
        assert units.factor("in") == 1.0 / 39.37007874  # Convert to inches
        assert units.factor("ft") == 1.0 / 3.280839895  # Convert to feet

    def test_call_method(self):
        """Test __call__ method."""
        units = DrawingUnits(base=1.0, unit="m")
        
        # Check that __call__ returns the same result as factor
        assert units("mm") == units.factor("mm")
        assert units("cm") == units.factor("cm")
        assert units("km") == units.factor("km")
        assert units("in") == units.factor("in")
        assert units("ft") == units.factor("ft")

    def test_different_base_unit(self):
        """Test with different base unit."""
        # Create DrawingUnits with mm as base unit
        units = DrawingUnits(base=1.0, unit="mm")
        
        # Check conversion factors
        assert units.factor("m") == 1000.0  # 1mm = 0.001m, so factor is 1/0.001
        assert units.factor("cm") == 10.0  # 1mm = 0.1cm, so factor is 1/0.1
        assert units.factor("mm") == 1.0  # Same unit, factor is 1
        
        # Create DrawingUnits with inch as base unit
        units_inch = DrawingUnits(base=1.0, unit="in")
        
        # Check conversion factors
        assert math.isclose(units_inch.factor("m"), 39.37007874)  # 1in = 0.0254m
        assert math.isclose(units_inch.factor("ft"), 12.0)  # 1in = 1/12ft


class TestPaperSpaceUnits:
    """Test cases for PaperSpaceUnits class."""

    def test_init_default(self):
        """Test PaperSpaceUnits initialization with default values."""
        psp_units = PaperSpaceUnits()
        
        # Check default values
        assert psp_units.unit == "mm"
        assert psp_units.scale == 1
        assert isinstance(psp_units._msp, DrawingUnits)
        assert isinstance(psp_units._psp, DrawingUnits)
        assert psp_units._psp.unit == "mm"

    def test_init_custom(self):
        """Test PaperSpaceUnits initialization with custom values."""
        msp = DrawingUnits(base=2.0, unit="m")
        psp_units = PaperSpaceUnits(msp=msp, unit="cm", scale=10)
        
        # Check custom values
        assert psp_units.unit == "cm"
        assert psp_units.scale == 10
        assert psp_units._msp is msp
        assert psp_units._psp.unit == "cm"

    def test_from_msp(self):
        """Test from_msp method."""
        # Create model space with meters as base unit
        msp = DrawingUnits(base=1.0, unit="m")
        
        # Create paper space with mm as unit and scale 1:100
        psp_units = PaperSpaceUnits(msp=msp, unit="mm", scale=100)
        
        # Test conversion from model space to paper space
        # 1m in model space = 10mm in paper space (1000mm / 100)
        assert psp_units.from_msp(1.0, "m") == 10.0
        
        # 100cm in model space = 10mm in paper space (1000mm / 100)
        assert psp_units.from_msp(100.0, "cm") == 10.0
        
        # 1000mm in model space = 10mm in paper space (1000mm / 100)
        assert psp_units.from_msp(1000.0, "mm") == 10.0

    def test_to_msp(self):
        """Test to_msp method."""
        # Create model space with meters as base unit
        msp = DrawingUnits(base=1.0, unit="m")
        
        # Create paper space with mm as unit and scale 1:100
        psp_units = PaperSpaceUnits(msp=msp, unit="mm", scale=100)
        
        # Test conversion from paper space to model space
        # 10mm in paper space = 1m in model space
        assert psp_units.to_msp(10.0, "mm") == 1.0
        
        # 1cm in paper space = 1m in model space
        assert psp_units.to_msp(1.0, "cm") == 1.0
        
        # 0.01m in paper space = 1m in model space
        assert psp_units.to_msp(0.01, "m") == 1.0

    def test_different_scale(self):
        """Test with different scale factor."""
        # Create model space with meters as base unit
        msp = DrawingUnits(base=1.0, unit="m")
        
        # Create paper space with mm as unit and scale 1:50
        psp_units = PaperSpaceUnits(msp=msp, unit="mm", scale=50)
        
        # Test conversion from model space to paper space
        # 1m in model space = 20mm in paper space (1000mm / 50)
        assert psp_units.from_msp(1.0, "m") == 20.0
        
        # Test conversion from paper space to model space
        # 20mm in paper space = 1m in model space
        assert psp_units.to_msp(20.0, "mm") == 1.0


class TestUnitFunctions:
    """Test cases for unit utility functions."""

    def test_decode(self):
        """Test decode function."""
        # Test valid unit enums
        assert decode(1) == "in"
        assert decode(2) == "ft"
        assert decode(3) == "mi"
        assert decode(4) == "mm"
        assert decode(5) == "cm"
        assert decode(6) == "m"
        assert decode(7) == "km"
        assert decode(10) == "yd"
        
        # Test invalid unit enums
        assert decode(0) is None
        assert decode(21) is None
        assert decode(22) is None
        assert decode(23) is None
        assert decode(24) is None

    def test_conversion_factor(self):
        """Test conversion_factor function."""
        # Test valid conversions
        # 1m = 1000mm, so factor is 1000
        assert conversion_factor(M, MM) == 1000.0
        
        # 1mm = 0.1cm, so factor is 0.1
        assert conversion_factor(MM, CM) == 0.1
        
        # 1m = 3.28ft, so factor is ~3.28
        assert math.isclose(conversion_factor(M, FT), 3.280839895)
        
        # 1ft = 12in, so factor is 12
        assert math.isclose(conversion_factor(FT, IN), 12.0)
        
        # 1in = 1/36yd, so factor is 1/36
        assert math.isclose(conversion_factor(IN, YD), 1/36)
        
        # Test invalid conversions
        with pytest.raises(ValueError):
            conversion_factor(100, MM)  # Invalid source unit
        
        with pytest.raises(ValueError):
            conversion_factor(MM, 100)  # Invalid target unit
        
        # Test unsupported conversions
        with pytest.raises(TypeError):
            conversion_factor(0, MM)  # Unitless not supported
        
        with pytest.raises(TypeError):
            conversion_factor(MM, 0)  # Unitless not supported
        
        with pytest.raises(TypeError):
            conversion_factor(21, MM)  # US Survey Feet not supported
        
        with pytest.raises(TypeError):
            conversion_factor(MM, 21)  # US Survey Feet not supported

    def test_unit_name(self):
        """Test unit_name function."""
        # Test valid unit enums
        assert unit_name(1) == "Inches"
        assert unit_name(2) == "Feet"
        assert unit_name(3) == "Miles"
        assert unit_name(4) == "Millimeters"
        assert unit_name(5) == "Centimeters"
        assert unit_name(6) == "Meters"
        assert unit_name(7) == "Kilometers"
        assert unit_name(10) == "Yards"
        
        # Test unitless
        assert unit_name(0) == "Unitless"
        
        # Test invalid unit enum
        assert unit_name(100) == "unitless"

    def test_angle_unit_name(self):
        """Test angle_unit_name function."""
        # Test valid angle unit enums
        assert angle_unit_name(0) == "Decimal Degrees"
        assert angle_unit_name(1) == "Degrees/Minutes/Seconds"
        assert angle_unit_name(2) == "Grad"
        assert angle_unit_name(3) == "Radians"
        
        # Test invalid angle unit enum
        assert angle_unit_name(100) == "unknown unit <100>"
