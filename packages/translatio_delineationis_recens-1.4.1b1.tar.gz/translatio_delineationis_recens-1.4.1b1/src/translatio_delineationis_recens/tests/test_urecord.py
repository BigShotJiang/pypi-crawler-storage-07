import pytest
from ezdxf.urecord import UserRecord, BinaryRecord, tags_from_list, compile_user_record, parse_xrecord, parse_binary_data
from ezdxf.entities import XRecord
from ezdxf.math import Vec3, Vec2
from ezdxf.lldxf.tags import Tags

def test_tags_from_list_basic_types():
    tags = tags_from_list(["abc", 123, 4.5, Vec3(1,2,3), Vec2(1,2)])
    codes = [t.code for t in tags]
    assert 1 in codes  # str
    assert 90 in codes  # int
    assert 40 in codes  # float
    assert 10 in codes  # Vec3/Vec2

def test_tags_from_list_nested():
    tags = tags_from_list([[1,2], {"a": 3}])
    codes = [t.code for t in tags]
    assert 302 in codes  # collection/dict

def test_compile_user_record_and_parse_xrecord():
    data = ["foo", 42, 3.14, [1,2], {"k": "v"}]
    tags = compile_user_record("Test", data)
    xrec = XRecord.new()
    xrec.tags = tags
    parsed = parse_xrecord(xrec, "Test")
    assert parsed[0] == "foo"
    assert parsed[1] == 42
    assert parsed[2] == 3.14

def test_userrecord_commit_and_str():
    ur = UserRecord(name="Test")
    ur.data.extend(["foo", 1])
    ur.commit()
    s = str(ur)
    assert "foo" in s and "1" in s

def test_userrecord_context_manager():
    ur = UserRecord(name="Test")
    ur.data.append("bar")
    with ur:
        ur.data.append("baz")
    assert "baz" in str(ur)

def test_userrecord_invalid_string():
    ur = UserRecord(name="Test")
    ur.data.append("bad\nstring")
    with pytest.raises(Exception):
        ur.commit()

def test_binaryrecord_commit_and_str():
    br = BinaryRecord()
    br.data = b"abc"
    br.commit()
    s = str(br)
    assert "61" in s  # hex for 'a'

def test_parse_binary_data():
    from ezdxf.lldxf.tags import binary_data_to_dxf_tags
    data = b"abc"
    tags = binary_data_to_dxf_tags(data, length_group_code=160, value_group_code=310, value_size=127)
    out = parse_binary_data(tags)
    assert out == data
