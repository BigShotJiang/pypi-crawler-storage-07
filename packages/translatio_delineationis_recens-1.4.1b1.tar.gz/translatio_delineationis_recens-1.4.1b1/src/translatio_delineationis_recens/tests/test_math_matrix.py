"""Tests for the ezdxf.math._matrix44 module."""
import math
import pytest
import numpy as np
from Code.Python.ezdxf.math._matrix44 import Matrix44
from Code.Python.ezdxf.math._vector import Vec3, Vec2


class TestMatrix44:
    """Test cases for the Matrix44 class."""

    def test_init(self):
        """Test Matrix44 initialization."""
        # Test initialization with no arguments (identity matrix)
        m = Matrix44()
        assert m.get_row(0) == (1, 0, 0, 0)
        assert m.get_row(1) == (0, 1, 0, 0)
        assert m.get_row(2) == (0, 0, 1, 0)
        assert m.get_row(3) == (0, 0, 0, 1)

        # Test initialization with matrix values as a flat list
        values = [
            1, 0, 0, 0,
            0, 1, 0, 0,
            0, 0, 1, 0,
            0, 0, 0, 1
        ]
        m = Matrix44(values)
        assert m.get_row(0) == (1, 0, 0, 0)
        assert m.get_row(1) == (0, 1, 0, 0)
        assert m.get_row(2) == (0, 0, 1, 0)
        assert m.get_row(3) == (0, 0, 0, 1)
        
        # Test initialization with four row tuples
        row1 = (1, 0, 0, 0)
        row2 = (0, 1, 0, 0)
        row3 = (0, 0, 1, 0)
        row4 = (0, 0, 0, 1)
        m = Matrix44(row1, row2, row3, row4)
        assert m.get_row(0) == row1
        assert m.get_row(1) == row2
        assert m.get_row(2) == row3
        assert m.get_row(3) == row4

    def test_properties(self):
        """Test Matrix44 properties."""
        values = [
            1, 2, 3, 4,
            5, 6, 7, 8,
            9, 10, 11, 12,
            13, 14, 15, 16
        ]
        m = Matrix44(values)
        
        # Test rows method
        rows = list(m.rows())
        assert len(rows) == 4
        assert rows[0] == (1, 2, 3, 4)
        assert rows[1] == (5, 6, 7, 8)
        assert rows[2] == (9, 10, 11, 12)
        assert rows[3] == (13, 14, 15, 16)
        
        # Test row and column getters
        assert m.get_row(0) == (1, 2, 3, 4)
        assert m.get_row(1) == (5, 6, 7, 8)
        assert m.get_col(0) == (1, 5, 9, 13)
        assert m.get_col(1) == (2, 6, 10, 14)

    def test_factory_methods(self):
        """Test Matrix44 factory methods."""
        # Test translation matrix
        m = Matrix44.translate(2, 3, 4)
        assert m.get_row(0) == (1, 0, 0, 0)
        assert m.get_row(1) == (0, 1, 0, 0)
        assert m.get_row(2) == (0, 0, 1, 0)
        assert m.get_row(3) == (2, 3, 4, 1)
        
        # Test scale matrix
        m = Matrix44.scale(2, 3, 4)
        assert m.get_row(0) == (2, 0, 0, 0)
        assert m.get_row(1) == (0, 3, 0, 0)
        assert m.get_row(2) == (0, 0, 4, 0)
        assert m.get_row(3) == (0, 0, 0, 1)
        
        # Test x_rotate matrix
        m = Matrix44.x_rotate(math.pi/2)
        assert pytest.approx(m.get_row(0)[0]) == 1
        assert pytest.approx(m.get_row(1)[1]) == 0
        assert pytest.approx(m.get_row(1)[2]) == 1
        assert pytest.approx(m.get_row(2)[1]) == -1
        assert pytest.approx(m.get_row(2)[2]) == 0
        
        # Test y_rotate matrix
        m = Matrix44.y_rotate(math.pi/2)
        assert pytest.approx(m.get_row(0)[0]) == 0
        assert pytest.approx(m.get_row(0)[2]) == -1
        assert pytest.approx(m.get_row(1)[1]) == 1
        assert pytest.approx(m.get_row(2)[0]) == 1
        assert pytest.approx(m.get_row(2)[2]) == 0
        
        # Test z_rotate matrix
        m = Matrix44.z_rotate(math.pi/2)
        assert pytest.approx(m.get_row(0)[0]) == 0
        assert pytest.approx(m.get_row(0)[1]) == 1
        assert pytest.approx(m.get_row(1)[0]) == -1
        assert pytest.approx(m.get_row(1)[1]) == 0
        assert pytest.approx(m.get_row(2)[2]) == 1

    def test_matrix_operations(self):
        """Test Matrix44 operations."""
        # Test matrix multiplication
        m1 = Matrix44.translate(1, 2, 3)
        m2 = Matrix44.scale(2, 2, 2)
        result = m1 * m2
        
        # Translation followed by scaling should scale the translation
        assert result.get_row(3) == (2, 4, 6, 1)
        
        # Test matrix-vector multiplication
        m = Matrix44.translate(1, 2, 3)
        v = Vec3(5, 6, 7)
        result = m.transform(v)
        
        assert isinstance(result, Vec3)
        assert result.x == 6  # 5 + 1
        assert result.y == 8  # 6 + 2
        assert result.z == 10  # 7 + 3

    def test_inverse(self):
        """Test Matrix44 inverse operation."""
        # Test inverse of translation matrix
        m = Matrix44.translate(2, 3, 4)
        m_inv = m.copy()
        m_inv.inverse()
        
        # Inverse of translation should be negative translation
        assert m_inv.get_row(3) == (-2, -3, -4, 1)
        
        # Test inverse of scale matrix
        m = Matrix44.scale(2, 3, 4)
        m_inv = m.copy()
        m_inv.inverse()
        
        # Inverse of scale should be reciprocal scale
        assert pytest.approx(m_inv.get_row(0)[0]) == 0.5
        assert pytest.approx(m_inv.get_row(1)[1]) == 1/3
        assert pytest.approx(m_inv.get_row(2)[2]) == 0.25
        
        # Test that m * m_inv = identity
        identity = m * m_inv
        for i in range(4):
            for j in range(4):
                expected = 1.0 if i == j else 0.0
                assert pytest.approx(identity.get_row(i)[j]) == expected

    def test_determinant(self):
        """Test Matrix44 determinant calculation."""
        # Determinant of identity matrix should be 1
        m = Matrix44()
        assert pytest.approx(m.determinant()) == 1.0
        
        # Determinant of scale matrix should be product of scale factors
        m = Matrix44.scale(2, 3, 4)
        assert pytest.approx(m.determinant()) == 24.0
        
        # Determinant of rotation matrix should be 1
        m = Matrix44.z_rotate(math.pi/4)
        assert pytest.approx(m.determinant()) == 1.0

    def test_transform_vectors(self):
        """Test transforming multiple vectors at once."""
        # Create a translation matrix
        m = Matrix44.translate(1, 2, 3)
        
        # Create a list of vectors
        vectors = [Vec3(0, 0, 0), Vec3(1, 1, 1), Vec3(2, 2, 2)]
        
        # Transform vectors individually
        results = [m.transform(v) for v in vectors]
        
        # Check results
        assert len(results) == len(vectors)
        assert results[0].xyz == (1, 2, 3)
        assert results[1].xyz == (2, 3, 4)
        assert results[2].xyz == (3, 4, 5)

    def test_transform_directions(self):
        """Test transforming direction vectors."""
        # Create a rotation matrix
        m = Matrix44.z_rotate(math.pi/2)  # 90 degrees
        
        # Create a list of direction vectors
        vectors = [Vec3(1, 0, 0), Vec3(0, 1, 0)]
        
        # Transform all vectors
        result = list(m.transform_directions(vectors))
        
        # Check results
        assert len(result) == len(vectors)
        assert pytest.approx(result[0].x) == 0
        assert pytest.approx(result[0].y) == 1
        assert pytest.approx(result[1].x) == -1
        assert pytest.approx(result[1].y) == 0

    def test_string_representation(self):
        """Test string representation of Matrix44."""
        values = [
            1, 2, 3, 4,
            5, 6, 7, 8,
            9, 10, 11, 12,
            13, 14, 15, 16
        ]
        m = Matrix44(values)
        
        # Test __repr__ method
        r = repr(m)
        assert "Matrix44" in r
        for i in range(1, 17):
            assert str(i) in r
