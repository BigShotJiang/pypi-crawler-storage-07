import os
import tempfile
import pytest
from ezdxf.tools.rawloader import raw_structure_loader, get_tag_loader
from ezdxf.lldxf.types import DXFTag

def minimal_dxf_content():
    # Minimal valid ASCII DXF file
    return """0\nSECTION\n2\nHEADER\n0\nENDSEC\n0\nEOF\n"""

def test_get_tag_loader_and_raw_structure_loader():
    # Create a temp DXF file
    with tempfile.NamedTemporaryFile(delete=False, mode="w", suffix=".dxf", encoding="utf8") as tmp:
        tmp.write(minimal_dxf_content())
        tmp_path = tmp.name
    try:
        # get_tag_loader returns a list of DXFTag
        tags = get_tag_loader(tmp_path)
        assert isinstance(tags, list)
        assert all(isinstance(tag, DXFTag) for tag in tags)
        # raw_structure_loader returns a dict-like SectionDict
        structure = raw_structure_loader(tmp_path)
        assert "HEADER" in structure
        assert isinstance(structure["HEADER"], list)
        from ezdxf.lldxf.tags import Tags as TagsClass
        def check_tag(tag):
            if isinstance(tag, DXFTag):
                assert isinstance(tag.code, int)
                assert isinstance(tag.value, str)
            elif isinstance(tag, tuple):
                assert isinstance(tag[0], int)
                assert isinstance(tag[1], str)
            elif isinstance(tag, TagsClass):
                for subtag in tag:
                    check_tag(subtag)
            else:
                raise AssertionError(f"Unexpected tag type: {type(tag)}")
        for tag in structure["HEADER"]:
            check_tag(tag)
    finally:
        os.remove(tmp_path)

def test_get_tag_loader_invalid_file():
    # Create a temp non-DXF file
    with tempfile.NamedTemporaryFile(delete=False, mode="w", suffix=".txt", encoding="utf8") as tmp:
        tmp.write("Not a DXF file\n")
        tmp_path = tmp.name
    try:
        with pytest.raises(IOError):
            _ = get_tag_loader(tmp_path)
    finally:
        os.remove(tmp_path)
