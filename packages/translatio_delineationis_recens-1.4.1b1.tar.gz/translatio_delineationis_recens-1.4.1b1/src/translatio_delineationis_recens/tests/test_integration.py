"""
Integration tests for the EzDXF library.
These tests verify that multiple components work together correctly.
"""
import os
import pytest
import math
from pathlib import Path

import ezdxf
from ezdxf.math import Vec3


class TestDrawingWorkflows:
    """Tests for complete drawing workflows."""
    
    def test_create_and_modify_drawing(self, tmpdir):
        """Test creating a drawing, adding entities, modifying them, and saving."""
        # Create a new drawing
        doc = ezdxf.new("R2018")
        msp = doc.modelspace()
        
        # Add multiple entity types
        line = msp.add_line((0, 0), (10, 10))
        circle = msp.add_circle((5, 5), radius=2.5)
        text = msp.add_text("Test Text", dxfattribs={"height": 0.5})
        text.set_placement((1, 1))
        
        # Modify entities
        line.dxf.color = 1  # red
        circle.dxf.color = 2  # yellow
        text.dxf.color = 3  # green
        
        # Save the drawing
        filepath = os.path.join(tmpdir, "test_workflow.dxf")
        doc.saveas(filepath)
        
        # Read the drawing back
        doc2 = ezdxf.readfile(filepath)
        msp2 = doc2.modelspace()
        
        # Verify entities were preserved
        entities = list(msp2)
        assert len(entities) == 3
        
        # Verify entity properties were preserved
        for entity in entities:
            if entity.dxftype() == "LINE":
                assert entity.dxf.start == (0, 0, 0)
                assert entity.dxf.end == (10, 10, 0)
                assert entity.dxf.color == 1
            elif entity.dxftype() == "CIRCLE":
                assert entity.dxf.center == (5, 5, 0)
                assert entity.dxf.radius == 2.5
                assert entity.dxf.color == 2
            elif entity.dxftype() == "TEXT":
                assert entity.dxf.text == "Test Text"
                assert entity.dxf.height == 0.5
                assert entity.dxf.color == 3
    
    def test_layer_management_workflow(self, tmpdir):
        """Test layer creation, entity assignment, and layer property preservation."""
        # Create a new drawing
        doc = ezdxf.new("R2018")
        
        # Create layers with different properties
        doc.layers.add("LAYER1", color=1)  # red
        doc.layers.add("LAYER2", color=2, linetype="DASHED")
        
        # Add entities to specific layers
        msp = doc.modelspace()
        line1 = msp.add_line((0, 0), (10, 10), dxfattribs={"layer": "LAYER1"})
        line2 = msp.add_line((0, 5), (10, 5), dxfattribs={"layer": "LAYER2"})
        
        # Save the drawing
        filepath = os.path.join(tmpdir, "test_layers.dxf")
        doc.saveas(filepath)
        
        # Read the drawing back
        doc2 = ezdxf.readfile(filepath)
        
        # Verify layers were preserved
        assert "LAYER1" in doc2.layers
        assert "LAYER2" in doc2.layers
        assert doc2.layers.get("LAYER1").get_color() == 1
        assert doc2.layers.get("LAYER2").get_color() == 2
        assert doc2.layers.get("LAYER2").dxf.linetype == "DASHED"
        
        # Verify entities were assigned to correct layers
        msp2 = doc2.modelspace()
        entities = list(msp2)
        assert len(entities) == 2
        
        for entity in entities:
            if entity.dxf.start == (0, 0, 0):
                assert entity.dxf.layer == "LAYER1"
            elif entity.dxf.start == (0, 5, 0):
                assert entity.dxf.layer == "LAYER2"


class TestBlockWorkflows:
    """Tests for block-related workflows."""
    
    def test_block_insertion_workflow(self, tmpdir):
        """Test creating blocks, inserting them, and verifying the results."""
        # Create a new drawing
        doc = ezdxf.new("R2018")
        
        # Create a block definition
        block = doc.blocks.new("TESTBLOCK")
        block.add_line((0, 0), (10, 10))
        block.add_circle((5, 5), radius=2.5)
        
        # Insert the block into the modelspace with different parameters
        msp = doc.modelspace()
        insert1 = msp.add_blockref("TESTBLOCK", (0, 0))
        insert2 = msp.add_blockref("TESTBLOCK", (20, 0), dxfattribs={
            "xscale": 2.0,
            "yscale": 2.0,
            "rotation": 45
        })
        
        # Save the drawing
        filepath = os.path.join(tmpdir, "test_blocks.dxf")
        doc.saveas(filepath)
        
        # Read the drawing back
        doc2 = ezdxf.readfile(filepath)
        
        # Verify block definition was preserved
        assert "TESTBLOCK" in doc2.blocks
        block2 = doc2.blocks.get("TESTBLOCK")
        block_entities = list(block2)
        assert len(block_entities) == 2
        
        # Verify block insertions were preserved
        msp2 = doc2.modelspace()
        inserts = [e for e in msp2 if e.dxftype() == "INSERT"]
        assert len(inserts) == 2
        
        # Check insert properties
        for insert in inserts:
            assert insert.dxf.name == "TESTBLOCK"
            if insert.dxf.insert == (0, 0, 0):
                assert insert.dxf.xscale == 1.0
                assert insert.dxf.yscale == 1.0
                assert insert.dxf.rotation == 0
            elif insert.dxf.insert == (20, 0, 0):
                assert insert.dxf.xscale == 2.0
                assert insert.dxf.yscale == 2.0
                assert math.isclose(insert.dxf.rotation, 45, abs_tol=1e-9)


class TestGeometricOperationsWorkflow:
    """Tests for geometric operations workflows."""
    
    def test_entity_transformation_workflow(self, empty_drawing):
        """Test applying multiple transformations to entities."""
        msp = empty_drawing.modelspace()
        
        # Create entities
        line = msp.add_line((0, 0), (10, 0))
        circle = msp.add_circle((5, 5), radius=2.5)
        
        # Apply transformations
        # 1. Move both entities
        line.translate(2, 3, 0)
        circle.translate(2, 3, 0)
        
        # 2. Rotate the line 90 degrees around its start point
        # To rotate around a specific point, we need to:
        # 1. Translate to origin (relative to base point)
        # 2. Rotate
        # 3. Translate back
        base_point = (2, 3, 0)
        line.translate(-base_point[0], -base_point[1], -base_point[2])
        line.rotate_z(math.pi/2)
        line.translate(base_point[0], base_point[1], base_point[2])
        
        # 3. Scale the circle
        # To scale around a specific point, we need to:
        # 1. Translate to origin (relative to base point)
        # 2. Scale
        # 3. Translate back
        base_point = (7, 8, 0)  # 7,8 is the new center after translation
        circle.translate(-base_point[0], -base_point[1], -base_point[2])
        circle.scale(1.5, 1.5, 1.5)
        circle.translate(base_point[0], base_point[1], base_point[2])
        
        # Verify line transformation results
        assert math.isclose(line.dxf.start.x, 2, abs_tol=1e-9)
        assert math.isclose(line.dxf.start.y, 3, abs_tol=1e-9)
        assert math.isclose(line.dxf.end.x, 2, abs_tol=1e-9)
        assert math.isclose(line.dxf.end.y, 13, abs_tol=1e-9)
        
        # Verify circle transformation results
        assert math.isclose(circle.dxf.center.x, 7, abs_tol=1e-9)
        assert math.isclose(circle.dxf.center.y, 8, abs_tol=1e-9)
        assert math.isclose(circle.dxf.radius, 3.75, abs_tol=1e-9)  # 2.5 * 1.5
    
    def test_complex_drawing_workflow(self, tmpdir):
        """Test a complex drawing workflow with multiple operations."""
        # Create a new drawing
        doc = ezdxf.new("R2018")
        msp = doc.modelspace()
        
        # 1. Create layers
        doc.layers.add("GEOMETRY", color=1)
        doc.layers.add("ANNOTATION", color=2)
        
        # 2. Create a block for reuse
        block = doc.blocks.new("CONNECTOR")
        block.add_circle((0, 0), radius=0.5)
        block.add_line((-1, 0), (1, 0))
        block.add_line((0, -1), (0, 1))
        
        # 3. Draw a rectangle on GEOMETRY layer
        points = [(0, 0), (10, 0), (10, 5), (0, 5), (0, 0)]
        msp.add_lwpolyline(points, dxfattribs={"layer": "GEOMETRY", "closed": True})
        
        # 4. Add connectors at each corner using the block
        for point in points[:-1]:  # Skip the last point which is a duplicate
            msp.add_blockref("CONNECTOR", point, dxfattribs={"layer": "GEOMETRY"})
        
        # 5. Add dimensions and text on ANNOTATION layer
        msp.add_text("Rectangle", dxfattribs={
            "layer": "ANNOTATION", 
            "height": 0.5
        }).set_placement((5, 2.5))
        
        # 6. Save the drawing
        filepath = os.path.join(tmpdir, "complex_drawing.dxf")
        doc.saveas(filepath)
        
        # 7. Read the drawing back and verify
        doc2 = ezdxf.readfile(filepath)
        msp2 = doc2.modelspace()
        
        # Verify layers
        assert "GEOMETRY" in doc2.layers
        assert "ANNOTATION" in doc2.layers
        
        # Verify entities
        polylines = [e for e in msp2 if e.dxftype() == "LWPOLYLINE"]
        inserts = [e for e in msp2 if e.dxftype() == "INSERT"]
        texts = [e for e in msp2 if e.dxftype() == "TEXT"]
        
        assert len(polylines) == 1
        assert len(inserts) == 4
        assert len(texts) == 1
        
        # Verify layer assignments
        assert polylines[0].dxf.layer == "GEOMETRY"
        assert all(insert.dxf.layer == "GEOMETRY" for insert in inserts)
        assert texts[0].dxf.layer == "ANNOTATION"
