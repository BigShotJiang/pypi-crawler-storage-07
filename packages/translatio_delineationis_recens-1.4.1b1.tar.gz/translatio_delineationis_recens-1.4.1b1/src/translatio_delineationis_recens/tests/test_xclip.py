import pytest
from ezdxf.xclip import ClippingPath, XClip, bbox_area, _rect_path
from ezdxf.math import Vec2
import ezdxf

# --- ClippingPath dataclass logic ---
def test_clippingpath_regular_and_inverted():
    verts = [Vec2(0,0), Vec2(1,0), Vec2(1,1), Vec2(0,1)]
    inv = [Vec2(0.2,0.2), Vec2(0.8,0.2), Vec2(0.8,0.8), Vec2(0.2,0.8)]
    cp = ClippingPath(vertices=verts, is_inverted_clip=False)
    assert cp.inner_polygon() == verts
    cp2 = ClippingPath(vertices=verts, inverted_clip=inv, is_inverted_clip=True)
    # Should pick the smaller area as inner polygon
    assert cp2.inner_polygon() == inv
    assert isinstance(cp2.outer_bounds(), object)

# --- bbox_area and _rect_path ---
def test_bbox_area_and_rect_path():
    verts = [Vec2(0,0), Vec2(2,0), Vec2(2,3), Vec2(0,3)]
    area = bbox_area(verts)
    assert area == 6.0
    rect = _rect_path(verts)
    assert len(rect) == 4
    assert rect[0] == Vec2(0,0)
    assert rect[2] == Vec2(2,3)

# --- XClip logic with real Insert entity ---
def make_insert_with_doc():
    doc = ezdxf.new()
    msp = doc.modelspace()
    insert = msp.add_blockref('BLOCK', (0, 0))
    # Add a dummy BLOCK definition if needed
    if 'BLOCK' not in doc.blocks:
        doc.blocks.new('BLOCK')
    return insert

def test_xclip_set_and_discard_clipping_path():
    insert = make_insert_with_doc()
    xc = XClip(insert)
    # Initially, no clipping path
    assert not xc.has_clipping_path
    # Set a rectangular clipping path
    verts = [(0,0), (1,0), (1,1), (0,1)]
    xc.set_block_clipping_path(verts)
    assert xc.has_clipping_path
    # Discard clipping path
    xc.discard_clipping_path()
    assert not xc.has_clipping_path

def test_xclip_set_block_clipping_path_and_get():
    insert = make_insert_with_doc()
    xc = XClip(insert)
    verts = [(0,0), (2,0), (2,2), (0,2)]
    xc.set_block_clipping_path(verts)
    # get_block_clipping_path returns a ClippingPath object
    path = xc.get_block_clipping_path()
    from ezdxf.xclip import ClippingPath
    assert isinstance(path, ClippingPath)
    assert [tuple(v) for v in path.vertices] == verts
    # Check get_spatial_filter returns None or a SpatialFilter instance
    from ezdxf.entities import SpatialFilter
    sf = xc.get_spatial_filter()
    assert sf is None or isinstance(sf, SpatialFilter)

def test_xclip_wrong_type_raises():
    with pytest.raises(Exception):
        XClip(object())
