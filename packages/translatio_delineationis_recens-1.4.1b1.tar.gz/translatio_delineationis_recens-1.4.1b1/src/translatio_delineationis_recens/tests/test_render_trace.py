import pytest
import math
from ezdxf.math import Vec2
from ezdxf.render.trace import LinearTrace, CurvedTrace

class TestLinearTrace:
    def test_closed_trace(self):
        # Closed trace: first and last station are the same
        trace = LinearTrace()
        trace.add_station(Vec2(0, 0), 1.0, 1.0)
        trace.add_station(Vec2(1, 0), 1.0, 1.0)
        trace.add_station(Vec2(1, 1), 1.0, 1.0)
        trace.add_station(Vec2(0, 0), 1.0, 1.0)  # closing
        faces = list(trace.faces())
        assert len(faces) == 3  # 3 segments, 3 faces
        # All face vertices should be Vec2
        for face in faces:
            assert len(face) == 4
            assert all(isinstance(v, Vec2) for v in face)

    def test_colinear_points(self):
        # Colinear points: should not crash, should yield faces for each segment
        trace = LinearTrace()
        trace.add_station(Vec2(0, 0), 1.0, 1.0)
        trace.add_station(Vec2(1, 0), 1.0, 1.0)
        trace.add_station(Vec2(2, 0), 1.0, 1.0)
        faces = list(trace.faces())
        assert len(faces) == 2

    def test_zero_width(self):
        # Zero width: faces should degenerate to lines
        trace = LinearTrace()
        trace.add_station(Vec2(0, 0), 0.0, 0.0)
        trace.add_station(Vec2(1, 0), 0.0, 0.0)
        faces = list(trace.faces())
        assert len(faces) == 1
        face = faces[0]
        # All four points should form a degenerate quad (pairs are nearly coincident)
        # Check that each pair (0,1) and (2,3) are close
        assert face[0].isclose(face[1])
        assert face[2].isclose(face[3])
        # The two pairs may be far apart (since stations are at (0,0) and (1,0)), but each pair should be collapsed

    def test_multi_segment_trace(self):
        # Multi-segment, non-colinear
        trace = LinearTrace()
        trace.add_station(Vec2(0, 0), 1.0, 2.0)
        trace.add_station(Vec2(1, 0), 2.0, 2.0)
        trace.add_station(Vec2(1, 1), 2.0, 1.0)
        faces = list(trace.faces())
        assert len(faces) == 2
        # Check that faces are not degenerate
        for face in faces:
            assert len(set(face)) > 2

    def test_empty_trace(self):
        trace = LinearTrace()
        assert len(trace) == 0
        assert not trace.is_started
        assert list(trace.faces()) == []

    def test_add_station_and_len(self):
        trace = LinearTrace()
        trace.add_station(Vec2(0, 0), 1.0, 2.0)
        assert len(trace) == 1
        trace.add_station(Vec2(1, 0), 2.0, 3.0)
        assert len(trace) == 2
        assert trace.is_started
        # Each station should be a namedtuple
        s = trace[0]
        assert hasattr(s, 'vertex') and hasattr(s, 'start_width') and hasattr(s, 'end_width')

    def test_faces_simple(self):
        trace = LinearTrace()
        trace.add_station(Vec2(0, 0), 1.0, 1.0)
        trace.add_station(Vec2(1, 0), 1.0, 1.0)
        faces = list(trace.faces())
        # For two stations, should yield one face
        assert len(faces) == 1
        face = faces[0]
        assert len(face) == 4
        assert all(isinstance(v, Vec2) for v in face)

    def test_polygon(self):
        trace = LinearTrace()
        trace.add_station(Vec2(0, 0), 1.0, 1.0)
        trace.add_station(Vec2(1, 0), 1.0, 1.0)
        poly = trace.polygon()
        assert isinstance(poly, list)
        assert all(isinstance(v, Vec2) for v in poly)
        assert len(poly) > 0

    def test_virtual_entities_invalid_type(self):
        trace = LinearTrace()
        trace.add_station(Vec2(0, 0), 1.0, 1.0)
        trace.add_station(Vec2(1, 0), 1.0, 1.0)
        with pytest.raises(TypeError):
            list(trace.virtual_entities(dxftype="INVALID"))

class TestCurvedTrace:
    def test_from_arc(self):
        # Minimal test for from_arc: create a quarter circle arc
        from ezdxf.math import ConstructionArc
        center = Vec2(0, 0)
        radius = 1.0
        start_angle = 0.0
        end_angle = math.pi / 2
        arc = ConstructionArc(center, radius, math.degrees(start_angle), math.degrees(end_angle), is_counter_clockwise=True)
        trace = CurvedTrace.from_arc(arc, start_width=0.5, end_width=0.5, segments=4)
        assert isinstance(trace, CurvedTrace)
        assert len(trace) == 4  # 4 segments = 4 stations
        faces = list(trace.faces())
        assert len(faces) == len(trace) - 1
        for face in faces:
            assert len(face) == 4
            assert all(isinstance(v, Vec2) for v in face)

    def test_from_arc_zero_width(self):
        # Arc with zero width
        from ezdxf.math import ConstructionArc
        center = Vec2(0, 0)
        radius = 1.0
        start_angle = 0.0
        end_angle = math.pi / 2
        arc = ConstructionArc(center, radius, math.degrees(start_angle), math.degrees(end_angle), is_counter_clockwise=True)
        trace = CurvedTrace.from_arc(arc, start_width=0.0, end_width=0.0, segments=4)
        faces = list(trace.faces())
        # All face points should form degenerate quads (pairs are nearly coincident)
        for face in faces:
            assert face[0].isclose(face[1])
            assert face[2].isclose(face[3])

    def test_empty_curved_trace(self):
        trace = CurvedTrace()
        assert len(trace) == 0
        assert list(trace.faces()) == []

    # More advanced tests (from_spline, from_arc, etc.) would require more DXF/math setup
