"""
Test fixtures for EzDXF library testing.
"""
import os
import sys
import pytest
from pathlib import Path

# Add the library to the Python path
sys.path.insert(0, str(Path(__file__).parent.parent / "Code" / "Python"))

import ezdxf
from ezdxf.document import Drawing


@pytest.fixture
def empty_drawing():
    """Returns a new empty drawing with DXF version R2018."""
    return ezdxf.new("R2018")


@pytest.fixture
def basic_drawing():
    """Returns a new drawing with some basic entities."""
    doc = ezdxf.new("R2018")
    msp = doc.modelspace()
    
    # Add some basic entities
    msp.add_line((0, 0), (10, 10))
    msp.add_circle((5, 5), radius=2.5)
    msp.add_text("EzDXF Test", dxfattribs={"height": 0.5}).set_placement((0, 0))
    
    return doc


@pytest.fixture
def temp_dxf_file(tmpdir):
    """Returns a temporary file path for DXF file operations."""
    return os.path.join(tmpdir, "test.dxf")


@pytest.fixture
def saved_drawing(basic_drawing, temp_dxf_file):
    """Returns a tuple with a saved drawing and its file path."""
    basic_drawing.saveas(temp_dxf_file)
    return basic_drawing, temp_dxf_file


@pytest.fixture
def dxf_file_factory(tmpdir):
    """Factory fixture to create multiple DXF files."""
    def _create_dxf(filename="test.dxf", version="R2018", entities=None):
        doc = ezdxf.new(version)
        msp = doc.modelspace()
        
        if entities:
            for entity_type, params in entities:
                if entity_type == "line":
                    msp.add_line(*params)
                elif entity_type == "circle":
                    msp.add_circle(*params)
                elif entity_type == "text":
                    text, pos, height = params
                    msp.add_text(text, dxfattribs={"height": height}).set_pos(pos)
        
        filepath = os.path.join(tmpdir, filename)
        doc.saveas(filepath)
        return filepath, doc
    
    return _create_dxf
