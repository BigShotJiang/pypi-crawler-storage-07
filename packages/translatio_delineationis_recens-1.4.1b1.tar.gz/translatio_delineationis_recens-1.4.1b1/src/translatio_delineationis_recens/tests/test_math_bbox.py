"""Tests for the ezdxf.math.bbox module."""
import pytest
import math
from Code.Python.ezdxf.math.bbox import BoundingBox, BoundingBox2d
from Code.Python.ezdxf.math._vector import Vec3, Vec2


class TestBoundingBox:
    """Test cases for the BoundingBox class."""
    
    def test_init(self):
        """Test BoundingBox initialization."""
        # Test initialization with no arguments (empty bounding box)
        bbox = BoundingBox()
        assert bbox.is_empty is True
        
        # Test initialization with points
        points = [(1, 2, 3), (4, 5, 6), (7, 8, 9)]
        bbox = BoundingBox(points)
        assert bbox.is_empty is False
        assert bbox.extmin.xyz == (1, 2, 3)
        assert bbox.extmax.xyz == (7, 8, 9)

    def test_extend(self):
        """Test extending a bounding box with points."""
        # Create an empty bounding box
        bbox = BoundingBox()
        
        # Extend with multiple points
        bbox.extend([(1, 2, 3), (4, 5, 6)])
        assert bbox.is_empty is False
        assert bbox.extmin.xyz == (1, 2, 3)
        assert bbox.extmax.xyz == (4, 5, 6)
        
        # Extend with a point that doesn't change the bounding box
        bbox.extend([(2, 3, 4)])
        assert bbox.extmin.xyz == (1, 2, 3)
        assert bbox.extmax.xyz == (4, 5, 6)
        
        # Extend with a point that extends only one dimension
        bbox.extend([(0, 3, 4)])
        assert bbox.extmin.xyz == (0, 2, 3)
        assert bbox.extmax.xyz == (4, 5, 6)

    def test_union(self):
        """Test union of bounding boxes."""
        # Create two bounding boxes
        bbox1 = BoundingBox([(0, 0, 0), (1, 1, 1)])
        bbox2 = BoundingBox([(2, 2, 2), (3, 3, 3)])
        
        # Create union of bbox1 and bbox2
        union_bbox = bbox1.union(bbox2)
        assert union_bbox.extmin.xyz == (0, 0, 0)
        assert union_bbox.extmax.xyz == (3, 3, 3)
        
        # Union with an empty bounding box (should not change)
        empty_bbox = BoundingBox()
        union_with_empty = bbox1.union(empty_bbox)
        assert union_with_empty.extmin.xyz == (0, 0, 0)
        assert union_with_empty.extmax.xyz == (1, 1, 1)
        
        # Union of an empty bounding box with a non-empty one
        empty_union = empty_bbox.union(bbox2)
        assert empty_union.is_empty is False
        assert empty_union.extmin.xyz == (2, 2, 2)
        assert empty_union.extmax.xyz == (3, 3, 3)

    def test_center(self):
        """Test calculating the center of a bounding box."""
        # Create a bounding box
        bbox = BoundingBox([(0, 0, 0), (10, 10, 10)])
        
        # Test center
        center = bbox.center
        assert center.xyz == (5, 5, 5)
        
        # Test center of an empty bounding box
        empty_bbox = BoundingBox()
        # Check if has_data is False for empty bounding box
        assert empty_bbox.has_data is False

    def test_size(self):
        """Test calculating the size of a bounding box."""
        # Create a bounding box
        bbox = BoundingBox([(0, 0, 0), (10, 20, 30)])
        
        # Test size
        size = bbox.size
        assert size.xyz == (10, 20, 30)
        
        # Test size of an empty bounding box
        empty_bbox = BoundingBox()
        # Check if has_data is False for empty bounding box
        assert empty_bbox.has_data is False

    def test_inside(self):
        """Test if a bounding box contains a point."""
        # Create a bounding box
        bbox = BoundingBox([(0, 0, 0), (10, 10, 10)])
        
        # Test points inside the bounding box
        assert bbox.inside(Vec3(5, 5, 5)) is True
        assert bbox.inside((5, 5, 5)) is True
        
        # Test points on the boundary
        assert bbox.inside(Vec3(0, 0, 0)) is True
        assert bbox.inside(Vec3(10, 10, 10)) is True
        
        # Test points outside the bounding box
        assert bbox.inside(Vec3(-1, 5, 5)) is False
        assert bbox.inside(Vec3(5, -1, 5)) is False
        assert bbox.inside(Vec3(5, 5, -1)) is False
        assert bbox.inside(Vec3(11, 5, 5)) is False
        assert bbox.inside(Vec3(5, 11, 5)) is False
        assert bbox.inside(Vec3(5, 5, 11)) is False
        
        # Test with an empty bounding box
        empty_bbox = BoundingBox()
        assert empty_bbox.inside(Vec3(0, 0, 0)) is False

    def test_has_intersection(self):
        """Test bounding box intersection (excludes touching boxes)."""
        # Create bounding boxes
        bbox1 = BoundingBox([(0, 0, 0), (10, 10, 10)])
        bbox2 = BoundingBox([(5, 5, 5), (15, 15, 15)])  # Overlapping
        bbox3 = BoundingBox([(10, 10, 10), (20, 20, 20)])  # Touching at corner
        bbox4 = BoundingBox([(20, 20, 20), (30, 30, 30)])  # Not overlapping
        
        # Test intersection (excludes touching)
        assert bbox1.has_intersection(bbox2) is True  # Overlapping boxes intersect
        assert bbox2.has_intersection(bbox1) is True
        assert bbox1.has_intersection(bbox3) is False  # Touching boxes don't intersect
        assert bbox3.has_intersection(bbox1) is False
        assert bbox1.has_intersection(bbox4) is False
        assert bbox4.has_intersection(bbox1) is False
        
        # Test intersection with empty bounding box
        empty_bbox = BoundingBox()
        assert bbox1.has_intersection(empty_bbox) is False
        assert empty_bbox.has_intersection(bbox1) is False
        
    def test_has_overlap(self):
        """Test bounding box overlap (includes touching boxes)."""
        # Create bounding boxes
        bbox1 = BoundingBox([(0, 0, 0), (10, 10, 10)])
        bbox2 = BoundingBox([(10, 10, 10), (20, 20, 20)])  # Touching at corner
        bbox3 = BoundingBox([(20, 20, 20), (30, 30, 30)])
        
        # Test overlap
        assert bbox1.has_overlap(bbox2) is True  # Touching boxes overlap
        assert bbox2.has_overlap(bbox1) is True
        assert bbox1.has_overlap(bbox3) is False
        assert bbox3.has_overlap(bbox1) is False
        
        # Test overlap with empty bounding box
        empty_bbox = BoundingBox()
        assert bbox1.has_overlap(empty_bbox) is False
        assert empty_bbox.has_overlap(bbox1) is False

    def test_intersection(self):
        """Test calculating the intersection of two bounding boxes."""
        # Create bounding boxes
        bbox1 = BoundingBox([(0, 0, 0), (10, 10, 10)])
        bbox2 = BoundingBox([(5, 5, 5), (15, 15, 15)])
        
        # Calculate intersection
        intersection = bbox1.intersection(bbox2)
        assert intersection.is_empty is False
        assert intersection.extmin == (5, 5, 5)
        assert intersection.extmax == (10, 10, 10)
        
        # Test with non-intersecting bounding boxes
        bbox3 = BoundingBox([(20, 20, 20), (30, 30, 30)])
        intersection = bbox1.intersection(bbox3)
        assert intersection.is_empty is True
        
        # Test with empty bounding box
        empty_bbox = BoundingBox()
        intersection = bbox1.intersection(empty_bbox)
        assert intersection.is_empty is True

    def test_union(self):
        """Test calculating the union of two bounding boxes."""
        # Create bounding boxes
        bbox1 = BoundingBox([(0, 0, 0), (10, 10, 10)])
        bbox2 = BoundingBox([(5, 5, 5), (15, 15, 15)])
        
        # Calculate union
        union = bbox1.union(bbox2)
        assert union.is_empty is False
        assert union.extmin == (0, 0, 0)
        assert union.extmax == (15, 15, 15)
        
        # Test with empty bounding box
        empty_bbox = BoundingBox()
        union = bbox1.union(empty_bbox)
        assert union.is_empty is False
        assert union.extmin == (0, 0, 0)
        assert union.extmax == (10, 10, 10)
        
        union = empty_bbox.union(bbox1)
        assert union.is_empty is False
        assert union.extmin == (0, 0, 0)
        assert union.extmax == (10, 10, 10)

    def test_copy(self):
        """Test copying a bounding box."""
        # Create a bounding box
        bbox = BoundingBox([(0, 0, 0), (10, 10, 10)])
        
        # Copy the bounding box
        copy = bbox.copy()
        assert copy.is_empty is False
        assert copy.extmin.xyz == (0, 0, 0)
        assert copy.extmax.xyz == (10, 10, 10)
        
        # Modify the copy (should not affect the original)
        copy.extend([(20, 20, 20)])
        assert copy.extmax.xyz == (20, 20, 20)
        assert bbox.extmax.xyz == (10, 10, 10)
