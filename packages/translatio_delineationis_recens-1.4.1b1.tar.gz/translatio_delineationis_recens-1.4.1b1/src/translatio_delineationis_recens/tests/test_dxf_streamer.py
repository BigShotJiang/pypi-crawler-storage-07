#!/usr/bin/env python3
# Copyright (c) 2025, Manfred Moitzi
# License: MIT License
"""
Tests for the DXFStreamer module.
"""

import pytest
import os
import sys
from pathlib import Path

# Add the project's library root to the Python path to resolve the module
# This navigates up from tests/ -> translatio_delineationis_recens/ -> Main/
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

import tempfile

import ezdxf
from translatio_delineationis_recens.tools.dxf_streamer import DXFStreamer


@pytest.fixture(scope="module")
def sample_dxf_file():
    """Creates a temporary DXF file for testing the streamer."""
    doc = ezdxf.new()
    msp = doc.modelspace()
    msp.add_line((0, 0), (10, 10), dxfattribs={"layer": "STREAM_LINES"})
    msp.add_circle((20, 20), 5, dxfattribs={"layer": "STREAM_CIRCLES"})
    msp.add_text("Stream Test", dxfattribs={"style": "STREAM_STYLE"})
    doc.layers.new("STREAM_LINES")
    doc.layers.new("STREAM_CIRCLES")
    doc.styles.new("STREAM_STYLE")

    with tempfile.NamedTemporaryFile(suffix=".dxf", delete=False, mode='w', encoding=doc.encoding) as tmpfile:
        doc.write(tmpfile)
        filepath = tmpfile.name

    yield filepath

    # Cleanup the file after tests are done
    os.remove(filepath)


def test_streamer_initialization(sample_dxf_file):
    """Test that the DXFStreamer initializes correctly."""
    streamer = DXFStreamer(sample_dxf_file)
    assert streamer.filepath == sample_dxf_file
    assert streamer.template_doc is None

def test_read_metadata(sample_dxf_file):
    """Test that metadata (header, tables, blocks) is read correctly."""
    streamer = DXFStreamer(sample_dxf_file)
    streamer.read_metadata()

    assert streamer.template_doc is not None
    # Check if some known table entries were loaded
    assert "STREAM_LINES" in streamer.template_doc.layers
    assert "STREAM_CIRCLES" in streamer.template_doc.layers
    assert "STREAM_STYLE" in streamer.template_doc.styles
    # Check that the ENTITIES section is empty in the template
    assert len(streamer.template_doc.modelspace()) == 0

def test_stream_entities(sample_dxf_file):
    """Test that entities are streamed correctly from the ENTITIES section."""
    streamer = DXFStreamer(sample_dxf_file)
    
    # Stream entities
    streamed_entities = list(streamer.stream_entities())

    # There should be 3 entities in the sample file
    assert len(streamed_entities) == 3

    # Verify the types of the streamed entities
    entity_types = [entity.dxftype() for entity in streamed_entities]
    assert "LINE" in entity_types
    assert "CIRCLE" in entity_types
    assert "TEXT" in entity_types

    # Check that entities are bound to the template document
    for entity in streamed_entities:
        assert entity.doc is streamer.template_doc
        # Verify layer is resolved
        if entity.dxftype() == "LINE":
            assert entity.dxf.layer == "STREAM_LINES"

