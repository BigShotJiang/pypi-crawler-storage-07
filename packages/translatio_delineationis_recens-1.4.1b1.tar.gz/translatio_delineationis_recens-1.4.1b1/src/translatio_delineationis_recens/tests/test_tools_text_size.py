# Copyright (c) 2024
# License: MIT License
import pytest
from ezdxf.math import Vec2, Matrix44
from ezdxf.tools.text_size import (
    TextSize,
    MTextSize,
    text_size,
    mtext_size,
    WordSizeDetector,
    WordSizeCollector,
    MTextSizeDetector,
)
from ezdxf.entities import Text, MText
from ezdxf.tools.text import MTextContext
from unittest.mock import MagicMock, patch


class TestTextSize:
    def test_text_size_dataclass(self):
        # Test the TextSize dataclass
        size = TextSize(width=10.0, cap_height=2.5, total_height=3.0)
        assert size.width == 10.0
        assert size.cap_height == 2.5
        assert size.total_height == 3.0


class TestMTextSize:
    def test_mtext_size_dataclass(self):
        # Test the MTextSize dataclass
        size = MTextSize(
            total_width=20.0,
            total_height=10.0,
            column_width=10.0,
            gutter_width=2.0,
            column_heights=(5.0, 10.0),
        )
        assert size.total_width == 20.0
        assert size.total_height == 10.0
        assert size.column_width == 10.0
        assert size.gutter_width == 2.0
        assert size.column_heights == (5.0, 10.0)
        
    def test_column_count(self):
        # Test the column_count property
        size = MTextSize(
            total_width=20.0,
            total_height=10.0,
            column_width=10.0,
            gutter_width=2.0,
            column_heights=(5.0, 10.0),
        )
        assert size.column_count == 2
        
        # Test with a single column
        size = MTextSize(
            total_width=10.0,
            total_height=5.0,
            column_width=10.0,
            gutter_width=0.0,
            column_heights=(5.0,),
        )
        assert size.column_count == 1


class TestTextSizeFunction:
    @pytest.fixture
    def mock_text(self):
        text = MagicMock()
        # Create a mock dxf attribute
        dxf = MagicMock()
        dxf.get_default.side_effect = lambda key: {
            "height": 2.5,
            "width": 1.0,
        }.get(key, 0)
        text.dxf = dxf
        text.plain_text.return_value = "Test Text"
        text.doc = None
        return text

    def test_text_size_without_doc(self, mock_text):
        # Test text_size function with no document
        size = text_size(mock_text)
        assert isinstance(size, TextSize)
        assert size.cap_height == 2.5
        assert size.width > 0
        assert size.total_height > 0

    @patch("ezdxf.tools.text_size.get_font_name")
    @patch("ezdxf.tools.text_size.fonts.make_font")
    def test_text_size_with_doc(self, mock_make_font, mock_get_font_name, mock_text):
        # Setup mocks
        mock_text.doc = MagicMock()
        mock_get_font_name.return_value = "Arial"
        mock_font = MagicMock()
        mock_font.measurements.total_height = 3.0
        mock_font.text_width.return_value = 15.0
        mock_make_font.return_value = mock_font
        
        # Test text_size function with document
        size = text_size(mock_text)
        assert isinstance(size, TextSize)
        assert size.cap_height == 2.5
        assert size.width == 15.0
        assert size.total_height == 3.0
        
        # Verify mocks were called correctly
        mock_get_font_name.assert_called_once_with(mock_text)
        mock_make_font.assert_called_once_with("Arial", 2.5, 1.0)
        mock_font.text_width.assert_called_once_with("Test Text")

    def test_text_size_empty_text(self, mock_text):
        # Test with empty text
        mock_text.plain_text.return_value = ""
        size = text_size(mock_text)
        assert size.width == 0.0
        assert size.cap_height == 2.5
        assert size.total_height > 0


class TestMTextSizeFunction:
    @pytest.fixture
    def mock_mtext(self):
        mtext = MagicMock(spec=MText)
        mtext.text = "Test MText"
        return mtext

    @pytest.fixture
    def mock_detector(self):
        detector = MagicMock(spec=MTextSizeDetector)
        # Create a mock column
        column = MagicMock()
        column.total_width = 10.0
        column.total_height = 5.0
        column.gutter = 2.0
        # Return a list with one column
        detector.measure.return_value = [column]
        return detector

    def test_mtext_size_with_text(self, mock_mtext, mock_detector):
        # Test mtext_size function with text
        size = mtext_size(mock_mtext, mock_detector)
        assert isinstance(size, MTextSize)
        assert size.total_width == 10.0
        assert size.total_height == 5.0
        assert size.column_width == 10.0
        assert size.gutter_width == 2.0
        assert size.column_heights == (5.0,)
        assert size.column_count == 1
        
        # Verify mock was called
        mock_detector.measure.assert_called_once_with(mock_mtext)

    def test_mtext_size_multiple_columns(self, mock_mtext):
        # Create a detector that returns multiple columns
        detector = MagicMock(spec=MTextSizeDetector)
        column1 = MagicMock()
        column1.total_width = 10.0
        column1.total_height = 5.0
        column1.gutter = 2.0
        
        column2 = MagicMock()
        column2.total_width = 10.0
        column2.total_height = 7.0
        column2.gutter = 2.0
        
        detector.measure.return_value = [column1, column2]
        
        # Test with multiple columns
        size = mtext_size(mock_mtext, detector)
        assert size.total_width == 22.0  # 2 columns of width 10 + 1 gutter of width 2
        assert size.total_height == 7.0  # Max height of columns
        assert size.column_heights == (5.0, 7.0)
        assert size.column_count == 2

    def test_mtext_size_empty_text(self, mock_mtext, mock_detector):
        # Test with empty text
        mock_mtext.text = ""
        mock_detector.measure.return_value = []
        
        size = mtext_size(mock_mtext, mock_detector)
        assert size.total_width == 0.0
        assert size.total_height == 0.0
        assert size.column_width == 0.0
        assert size.gutter_width == 0.0
        assert size.column_heights == (0.0,)
        assert size.column_count == 1


class TestWordSizeCollector:
    def test_init(self):
        collector = WordSizeCollector()
        assert collector.word_boxes == []

    def test_render(self):
        collector = WordSizeCollector()
        collector.render(0.0, 0.0, 10.0, 5.0)
        assert len(collector.word_boxes) == 1
        assert collector.word_boxes[0] == (Vec2(0.0, 0.0), Vec2(10.0, 5.0))
        
        # Add another box
        collector.render(15.0, 0.0, 25.0, 5.0)
        assert len(collector.word_boxes) == 2
        assert collector.word_boxes[1] == (Vec2(15.0, 0.0), Vec2(25.0, 5.0))
        
        # Test with matrix transformation (should be ignored)
        matrix = Matrix44()
        collector.render(30.0, 0.0, 40.0, 5.0, matrix)
        assert len(collector.word_boxes) == 3
        assert collector.word_boxes[2] == (Vec2(30.0, 0.0), Vec2(40.0, 5.0))


class TestWordSizeDetector:
    @patch("ezdxf.tools.text_size.MTextSizeDetector.measure")
    def test_measure(self, mock_super_measure):
        # Setup
        detector = WordSizeDetector()
        mock_mtext = MagicMock(spec=MText)
        mock_layout = MagicMock()
        mock_super_measure.return_value = mock_layout
        
        # Call measure
        result = detector.measure(mock_mtext)
        
        # Verify
        assert result == mock_layout
        mock_super_measure.assert_called_once_with(mock_mtext)
        mock_layout.render.assert_called_once()

    def test_reset(self):
        detector = WordSizeDetector()
        detector.reset()
        assert isinstance(detector.renderer, WordSizeCollector)

    def test_word_boxes(self):
        detector = WordSizeDetector()
        detector.reset()
        
        # Add some test boxes to the collector
        collector = detector.renderer
        collector.render(0.0, 0.0, 10.0, 5.0)
        collector.render(15.0, 0.0, 25.0, 5.0)
        
        # Get the word boxes
        boxes = detector.word_boxes()
        assert len(boxes) == 2
        assert boxes[0] == (Vec2(0.0, 0.0), Vec2(10.0, 5.0))
        assert boxes[1] == (Vec2(15.0, 0.0), Vec2(25.0, 5.0))


class TestMTextSizeDetector:
    def test_init(self):
        detector = MTextSizeDetector()
        assert hasattr(detector, 'do_nothing')
        assert detector.renderer == detector.do_nothing

    def test_reset(self):
        detector = MTextSizeDetector()
        detector.reset()  # Should do nothing
        assert detector.renderer == detector.do_nothing

    @patch("ezdxf.tools.text_size.MTextSizeDetector.get_font")
    @patch("ezdxf.tools.text_layout.Text")
    def test_word(self, mock_text_class, mock_get_font):
        # Setup
        detector = MTextSizeDetector()
        mock_font = MagicMock()
        mock_font.text_width.return_value = 10.0
        mock_get_font.return_value = mock_font
        
        # Create a MTextContext-like object without using spec
        ctx = MagicMock()
        ctx.cap_height = 2.5
        ctx.align = 0
        
        # Call word
        detector.word("Test", ctx)
        
        # Verify the Text class was called with the correct parameters
        mock_text_class.assert_called_once()
        call_args = mock_text_class.call_args[1]
        assert call_args["width"] == 10.0
        assert call_args["height"] == 2.5
        mock_get_font.assert_called_once_with(ctx)
        mock_font.text_width.assert_called_once_with("Test")

    @patch("ezdxf.tools.text_size.MTextSizeDetector.word")
    @patch("ezdxf.tools.text_size.MTextSizeDetector.get_stacking")
    @patch("ezdxf.tools.text_layout.Fraction")
    def test_fraction(self, mock_fraction_class, mock_get_stacking, mock_word):
        # Setup
        detector = MTextSizeDetector()
        mock_word.return_value = "word_result"
        mock_get_stacking.return_value = "stacking_result"
        # Create a MTextContext-like object without using spec
        ctx = MagicMock()
        
        # Test with type_ = True (fraction)
        detector.fraction(("upper", "lower", True), ctx)
        assert mock_word.call_count == 2
        mock_get_stacking.assert_called_once_with(True)
        mock_fraction_class.assert_called_once()
        
        # Test with type_ = False (not a fraction)
        mock_word.reset_mock()
        mock_get_stacking.reset_mock()
        mock_fraction_class.reset_mock()
        detector.fraction(("upper", None, False), ctx)
        mock_word.assert_called_once_with("upper", ctx)
        mock_get_stacking.assert_not_called()
        mock_fraction_class.assert_not_called()

    @patch("ezdxf.tools.text_size.fonts.get_entity_font_face")
    def test_get_font_face(self, mock_get_entity_font_face):
        # Setup
        detector = MTextSizeDetector()
        mock_mtext = MagicMock(spec=MText)
        mock_get_entity_font_face.return_value = "font_face_result"
        
        # Call get_font_face
        result = detector.get_font_face(mock_mtext)
        
        # Verify
        assert result == "font_face_result"
        mock_get_entity_font_face.assert_called_once_with(mock_mtext)

    def test_make_bg_renderer(self):
        detector = MTextSizeDetector()
        mock_mtext = MagicMock(spec=MText)
        
        result = detector.make_bg_renderer(mock_mtext)
        assert result == detector.do_nothing

    @patch("ezdxf.tools.text_size.MTextSizeDetector.layout_engine")
    def test_measure(self, mock_layout_engine):
        # Setup
        detector = MTextSizeDetector()
        mock_mtext = MagicMock(spec=MText)
        mock_layout = MagicMock()
        mock_layout_engine.return_value = mock_layout
        
        # Call measure
        result = detector.measure(mock_mtext)
        
        # Verify
        assert result == mock_layout
        mock_layout_engine.assert_called_once_with(mock_mtext)
        mock_layout.place.assert_called_once()
