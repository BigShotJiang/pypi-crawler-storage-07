"""
Tests for advanced entity types in the EzDXF library.
"""
import pytest
import math

import ezdxf
from ezdxf.math import Vec3


class TestPolylineEntities:
    """Tests for polyline entities."""
    
    def test_lwpolyline_properties(self, empty_drawing):
        """Test lightweight polyline entity properties."""
        msp = empty_drawing.modelspace()
        points = [(0, 0), (2, 2), (4, 0), (6, 4)]
        lwpolyline = msp.add_lwpolyline(points)
        
        # Test basic properties
        assert lwpolyline.dxftype() == "LWPOLYLINE"
        assert len(lwpolyline) == 4
        
        # Compare just the x,y coordinates of each point
        actual_points = list(lwpolyline.get_points())
        for i, expected_point in enumerate(points):
            assert actual_points[i][0] == pytest.approx(expected_point[0])
            assert actual_points[i][1] == pytest.approx(expected_point[1])
        
        # Test modification
        lwpolyline.append_points([(8, 0)])
        assert len(lwpolyline) == 5
        
        # Test closed property
        assert not lwpolyline.closed
        lwpolyline.close(True)
        assert lwpolyline.closed
    
    def test_polyline_with_bulges(self, empty_drawing):
        """Test polyline with bulges for curved segments."""
        msp = empty_drawing.modelspace()
        # Points with bulges - bulge defines the curvature of the segment
        points = [(0, 0, 0), (3, 0, 0.5), (6, 0, 0), (9, 0, -0.5)]
        lwpolyline = msp.add_lwpolyline(points)
        
        # Test bulge values
        bulges = [p[2] for p in lwpolyline.get_points()]
        assert bulges == [0, 0.5, 0, -0.5]
        
        # Modify a bulge
        lwpolyline.set_points([(0, 0, 0), (3, 0, 1.0), (6, 0, 0), (9, 0, -0.5)])
        bulges = [p[2] for p in lwpolyline.get_points()]
        assert bulges == [0, 1.0, 0, -0.5]
    
    def test_polyline_with_width(self, empty_drawing):
        """Test polyline with width values."""
        msp = empty_drawing.modelspace()
        # Create a polyline with width
        lwpolyline = msp.add_lwpolyline([(0, 0), (5, 5), (10, 0)])
        
        # Set global width
        lwpolyline.dxf.const_width = 0.5
        assert lwpolyline.dxf.const_width == 0.5
        
        # Set width per segment
        lwpolyline.set_points([(0, 0, 0, 0.1, 0.2), (5, 5, 0, 0.3, 0.4), (10, 0, 0, 0.5, 0.6)])
        points = list(lwpolyline.get_points())
        
        # Check start and end widths for each segment
        assert points[0][3] == 0.1  # start width of first point
        assert points[0][4] == 0.2  # end width of first point
        assert points[1][3] == 0.3  # start width of second point
        assert points[1][4] == 0.4  # end width of second point


class TestEllipseEntity:
    """Tests for ellipse entity."""
    
    def test_ellipse_properties(self, empty_drawing):
        """Test ellipse entity properties."""
        msp = empty_drawing.modelspace()
        # Create ellipse with center at (0,0,0), major axis of 5 units along x-axis, 
        # and ratio of minor axis to major axis of 0.5
        ellipse = msp.add_ellipse((0, 0), major_axis=(5, 0), ratio=0.5)
        
        # Test basic properties
        assert ellipse.dxftype() == "ELLIPSE"
        assert ellipse.dxf.center == (0, 0, 0)
        assert ellipse.dxf.major_axis == (5, 0, 0)
        assert ellipse.dxf.ratio == 0.5
        
        # Test modification
        ellipse.dxf.center = (1, 1, 0)
        ellipse.dxf.major_axis = (4, 0, 0)
        ellipse.dxf.ratio = 0.75
        assert ellipse.dxf.center == (1, 1, 0)
        assert ellipse.dxf.major_axis == (4, 0, 0)
        assert ellipse.dxf.ratio == 0.75
    
    def test_ellipse_parameterization(self, empty_drawing):
        """Test ellipse parameterization."""
        msp = empty_drawing.modelspace()
        ellipse = msp.add_ellipse((0, 0), major_axis=(5, 0), ratio=0.5)
        
        # Test start and end parameters (full ellipse by default)
        assert ellipse.dxf.start_param == 0
        assert ellipse.dxf.end_param == math.tau  # tau = 2*pi
        
        # Test creating partial ellipse (arc)
        ellipse.dxf.start_param = 0
        ellipse.dxf.end_param = math.pi  # half ellipse
        assert ellipse.dxf.start_param == 0
        assert ellipse.dxf.end_param == math.pi
    
    def test_ellipse_rotation(self, empty_drawing):
        """Test ellipse rotation."""
        msp = empty_drawing.modelspace()
        # Create ellipse with major axis along x-axis
        ellipse = msp.add_ellipse((0, 0), major_axis=(5, 0), ratio=0.5)
        
        # Rotate the ellipse 90 degrees around its center
        ellipse.rotate_z(math.pi/2)
        
        # Check that the major axis is now approximately along the y-axis
        assert math.isclose(ellipse.dxf.major_axis[0], 0, abs_tol=1e-9)
        assert math.isclose(abs(ellipse.dxf.major_axis[1]), 5, abs_tol=1e-9)


class TestSplineEntity:
    """Tests for spline entity."""
    
    def test_spline_properties(self, empty_drawing):
        """Test spline entity properties."""
        msp = empty_drawing.modelspace()
        # Create a spline
        control_points = [(0, 0), (3, 6), (6, -6), (9, 0)]
        spline = msp.add_spline()
        
        # Manually set control points
        spline.control_points = control_points
        
        # Test basic properties
        assert spline.dxftype() == "SPLINE"
        assert spline.dxf.degree == 3  # Cubic spline by default
        assert len(spline.control_points) == 4
        
        # Test control points
        for i, point in enumerate(control_points):
            cp = spline.control_points[i]
            assert cp[0] == pytest.approx(point[0])
            assert cp[1] == pytest.approx(point[1])
            assert cp[2] == pytest.approx(0.0)
    
    def test_spline_with_fit_points(self, empty_drawing):
        """Test spline with fit points."""
        msp = empty_drawing.modelspace()
        # Create a spline with fit points
        fit_points = [(0, 0), (3, 6), (6, -6), (9, 0)]
        spline = msp.add_spline(fit_points=fit_points)
        
        # Test fit points
        assert len(spline.fit_points) == 4
        for i, point in enumerate(fit_points):
            fp = spline.fit_points[i]
            assert fp[0] == pytest.approx(point[0])
            assert fp[1] == pytest.approx(point[1])
            assert fp[2] == pytest.approx(0.0)
    
    def test_open_closed_spline(self, empty_drawing):
        """Test open and closed splines."""
        msp = empty_drawing.modelspace()
        control_points = [(0, 0), (3, 6), (6, -6), (9, 0)]
        
        # Create an open spline (default)
        open_spline = msp.add_spline()
        open_spline.control_points = control_points
        assert not open_spline.closed
        
        # Create a closed spline
        closed_spline = msp.add_spline()
        closed_spline.control_points = control_points
        closed_spline.closed = True
        assert closed_spline.closed
        
        # Test changing from open to closed
        open_spline.closed = True
        assert open_spline.closed


class TestPointEntity:
    """Tests for point entity."""
    
    def test_point_properties(self, empty_drawing):
        """Test point entity properties."""
        msp = empty_drawing.modelspace()
        point = msp.add_point((5, 5))
        
        # Test basic properties
        assert point.dxftype() == "POINT"
        assert point.dxf.location == (5, 5, 0)
        
        # Test modification
        point.dxf.location = (10, 10, 0)
        assert point.dxf.location == (10, 10, 0)
    
    def test_point_style(self, empty_drawing):
        """Test point style properties."""
        msp = empty_drawing.modelspace()
        point = msp.add_point((5, 5))
        
        # Set point style properties
        point.dxf.thickness = 2.0
        assert point.dxf.thickness == 2.0
