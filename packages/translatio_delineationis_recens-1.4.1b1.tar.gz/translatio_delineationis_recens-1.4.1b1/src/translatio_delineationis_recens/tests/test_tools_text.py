# Copyright (c) 2024
# License: MIT License
import pytest
import math
from ezdxf.math import Vec3, Vec2
from ezdxf.tools import text
from ezdxf.enums import TextEntityAlignment
from ezdxf.fonts.fonts import MonospaceFont


class TestTextLine:
    @pytest.fixture
    def font(self):
        return MonospaceFont(cap_height=2.5)

    @pytest.fixture
    def text_line(self, font):
        return text.TextLine("Test", font)

    def test_init(self, text_line, font):
        assert text_line._font == font
        assert text_line._text_width > 0
        assert text_line._stretch_x == 1.0
        assert text_line._stretch_y == 1.0

    def test_stretch_fit(self, text_line):
        # Make text_width smaller than distance to ensure stretch factor > 1.0
        text_line._text_width = 5.0
        p1 = Vec3(0, 0, 0)
        p2 = Vec3(10, 0, 0)
        text_line.stretch(TextEntityAlignment.FIT, p1, p2)
        assert text_line._stretch_x > 1.0
        assert text_line._stretch_y == 1.0

    def test_stretch_aligned(self, text_line):
        # Make text_width smaller than distance to ensure stretch factor > 1.0
        text_line._text_width = 5.0
        p1 = Vec3(0, 0, 0)
        p2 = Vec3(10, 0, 0)
        text_line.stretch(TextEntityAlignment.ALIGNED, p1, p2)
        assert text_line._stretch_x > 1.0
        assert text_line._stretch_y == text_line._stretch_x

    def test_stretch_other_alignment(self, text_line):
        p1 = Vec3(0, 0, 0)
        p2 = Vec3(10, 0, 0)
        text_line.stretch(TextEntityAlignment.LEFT, p1, p2)
        assert text_line._stretch_x == 1.0
        assert text_line._stretch_y == 1.0

    def test_width(self, text_line):
        original_width = text_line.width
        text_line._stretch_x = 2.0
        assert text_line.width == original_width * 2.0

    def test_height(self, text_line):
        original_height = text_line.height
        text_line._stretch_y = 2.0
        assert text_line.height == original_height * 2.0

    def test_font_measurements(self, text_line):
        text_line._stretch_y = 2.0
        fm = text_line.font_measurements()
        assert fm.cap_height == text_line._font.measurements.cap_height * 2.0

    def test_baseline_vertices(self, text_line):
        insert = Vec3(1, 1, 0)
        vertices = text_line.baseline_vertices(insert)
        assert len(vertices) == 2
        assert vertices[0].z == 0  # Z component should be preserved
        assert vertices[1].x > vertices[0].x  # Right vertex is to the right of left vertex

    def test_baseline_vertices_with_alignment(self, text_line):
        insert = Vec3(1, 1, 0)
        # Test center alignment
        vertices_center = text_line.baseline_vertices(insert, halign=1)
        # Test right alignment
        vertices_right = text_line.baseline_vertices(insert, halign=2)
        
        # Center alignment should position text centered around insert point
        assert vertices_center[0].x < insert.x
        assert vertices_center[1].x > insert.x
        
        # Right alignment should position text to the left of insert point
        assert vertices_right[1].x == pytest.approx(insert.x)

    def test_corner_vertices(self, text_line):
        insert = Vec3(1, 1, 0)
        vertices = text_line.corner_vertices(insert)
        assert len(vertices) == 4
        # Verify order: bottom left, bottom right, top right, top left
        assert vertices[0].y < vertices[2].y  # Bottom is below top
        assert vertices[0].x < vertices[1].x  # Left is to the left of right


class TestTextFunctions:
    def test_plain_text(self):
        # Test basic text
        assert text.plain_text("Hello World") == "Hello World"
        # Test with special characters
        assert text.plain_text("Line1\\PLine2") == "Line1\\PLine2"
        # Test with formatting codes
        assert text.plain_text("{\\fArial|b0|i0|c0|p0;Hello}") == "{\\fArial|b0|i0|c0|p0;Hello}"

    def test_fast_plain_mtext(self):
        # Test basic text
        assert text.fast_plain_mtext("Hello World") == "Hello World"
        # Test with paragraph breaks
        assert text.fast_plain_mtext("Line1\\PLine2") == "Line1\nLine2"
        # Test with paragraph breaks and split=True
        assert text.fast_plain_mtext("Line1\\PLine2", split=True) == ["Line1", "Line2"]
        # Test with formatting codes
        assert text.fast_plain_mtext("\\C1;Red Text") == "Red Text"
        # Test with multiple formatting codes
        assert text.fast_plain_mtext("\\C1;Red \\C2;Green") == "Red Green"

    def test_caret_decode(self):
        # Test basic caret notation
        assert text.caret_decode("^I") == "\t"  # Tab
        assert text.caret_decode("^J") == "\n"  # Newline
        # The caret_decode function uses the formula chr((c - 64) % 126)
        # For '^' (ASCII 94), this gives chr((94 - 64) % 126) = chr(30) = RS (record separator)
        assert text.caret_decode("^^") == chr(30)  # Not '^' as might be expected
        # Test mixed text
        assert text.caret_decode("Tab^INewline^JCaret^^") == f"Tab\tNewline\nCaret{chr(30)}"

    def test_split_mtext_string(self):
        # Test with string shorter than size
        short_text = "Short text"
        assert text.split_mtext_string(short_text, 20) == [short_text]
        
        # Test with string longer than size
        long_text = "This is a longer text that should be split into multiple chunks"
        chunks = text.split_mtext_string(long_text, 20)
        assert len(chunks) > 1
        assert "".join(chunks) == long_text

    def test_plain_mtext(self):
        # Test basic text
        assert text.plain_mtext("Hello World") == "Hello World"
        # Test with paragraph breaks
        assert text.plain_mtext("Line1\\PLine2") == "Line1\nLine2"
        # Test with paragraph breaks and split=True
        assert text.plain_mtext("Line1\\PLine2", split=True) == ["Line1", "Line2"]
        # Test with formatting codes
        assert text.plain_mtext("\\C1;Red Text") == "Red Text"
        # Test with tabs
        assert text.plain_mtext("Tab^IHere", tabsize=4) == "Tab    Here"

    def test_escape_dxf_line_endings(self):
        assert text.escape_dxf_line_endings("Line1\nLine2") == "Line1\\PLine2"
        assert text.escape_dxf_line_endings("Line1\r\nLine2") == "Line1\\PLine2"

    def test_replace_non_printable_characters(self):
        # Test with control characters
        assert "▯" in text.replace_non_printable_characters("\x01\x02\x03")
        # Test with printable characters
        assert text.replace_non_printable_characters("ABC") == "ABC"
        # Test with custom replacement
        assert "X" in text.replace_non_printable_characters("\x01", "X")

    def test_estimate_mtext_content_extents(self):
        font = MonospaceFont(cap_height=2.5)
        # Test with simple text
        width, height = text.estimate_mtext_content_extents("Test", font)
        assert width > 0
        assert height > 0
        
        # Test with multi-line text
        width, height = text.estimate_mtext_content_extents("Line1\\PLine2", font)
        assert width > 0
        assert height > font.measurements.cap_height  # Should be taller than single line
        
        # Test with column width
        width, height = text.estimate_mtext_content_extents("A very long text that should wrap", font, column_width=10)
        assert width > 0  # Width should be positive

    def test_safe_string(self):
        # Test basic string
        assert text.safe_string("Hello") == "Hello"
        # Test with line breaks
        assert text.safe_string("Line1\nLine2") == "Line1\\PLine2"
        # Test with max length
        assert len(text.safe_string("A" * 100, max_len=50)) == 50

    def test_scale_mtext_inline_commands(self):
        # Test with height command
        assert text.scale_mtext_inline_commands("\\H1.0;Text", 2.0) == "\\H2;Text"
        # Test with relative height
        assert text.scale_mtext_inline_commands("\\H1.5x;Text", 2.0) == "\\H1.5x;Text"
        # Test with no height commands
        assert text.scale_mtext_inline_commands("Regular Text", 2.0) == "Regular Text"
        # Test with multiple height commands
        assert "\\H2" in text.scale_mtext_inline_commands("\\H1.0;Text\\H1.0;More", 2.0)
