import pytest
from ezdxf.upright import upright, upright_all, _flip_deg_angle, _flip_rad_angle, _flip_vertex, _flip_2d_vertex
from ezdxf.math import Vec3, Vec2
from types import SimpleNamespace

class DummyDXFGraphic:
    def __init__(self, extrusion, alive=True):
        self.dxf = SimpleNamespace(extrusion=extrusion, hasattr=lambda x: x == 'extrusion', get=lambda x: extrusion, set=lambda x, y: None)
        self.is_alive = alive

    def __getattr__(self, item):
        # For is_alive
        if item == 'is_alive':
            return True
        raise AttributeError(item)

def test_flip_deg_angle():
    assert _flip_deg_angle(0) == 180
    assert _flip_deg_angle(90) == 90
    assert _flip_deg_angle(-90) == -90
    assert _flip_deg_angle(180) == 0
    assert _flip_deg_angle(-180) == 0

def test_flip_rad_angle():
    import math
    assert pytest.approx(_flip_rad_angle(0), abs=1e-12) == math.pi
    assert pytest.approx(_flip_rad_angle(math.pi/2), abs=1e-12) == math.pi - math.pi/2
    assert pytest.approx(_flip_rad_angle(-math.pi/2), abs=1e-12) == -math.pi + math.pi/2

def test_flip_vertex():
    v = Vec3(1, 2, 3)
    flipped = _flip_vertex(v)
    assert flipped.x == -1 and flipped.y == 2 and flipped.z == -3

def test_flip_2d_vertex():
    v = Vec2(1, 2)
    flipped = _flip_2d_vertex(v)
    assert flipped.x == -1 and flipped.y == 2

def test_upright_noop_on_non_flipped():
    dummy = DummyDXFGraphic(extrusion=(0, 0, 1))
    upright(dummy)  # Should not flip
    # No exception, nothing changed

def test_upright_on_flipped():
    class Dummy(DummyDXFGraphic):
        def __init__(self):
            super().__init__((0, 0, -1))
            self.flipped = False
        def dxf(self):
            return self.dxf
    dummy = Dummy()
    # Should call _flip_dxf_graphic, but since it's a dummy, just test no error
    upright(dummy)

def test_upright_all_calls_upright():
    called = []
    class Dummy(DummyDXFGraphic):
        def __init__(self):
            super().__init__((0,0,-1))
        def __call__(self):
            called.append(True)
    dummies = [Dummy() for _ in range(3)]
    upright_all(dummies)  # Should not raise
