"""
Tests for core functionality of the EzDXF library.
"""
import os
import pytest
from pathlib import Path

import ezdxf
from ezdxf.document import Drawing
from ezdxf.lldxf.const import DXFValueError


class TestDocumentCreation:
    """Tests for document creation and basic operations."""
    
    def test_new_document(self, empty_drawing):
        """Test creating a new DXF document."""
        assert isinstance(empty_drawing, Drawing)
        assert empty_drawing.dxfversion == "AC1032"  # R2018
    
    def test_save_and_load(self, temp_dxf_file):
        """Test saving and loading a DXF document."""
        # Create and save a document
        doc = ezdxf.new("R2018")
        msp = doc.modelspace()
        msp.add_line((0, 0), (10, 10))
        doc.saveas(temp_dxf_file)
        
        # Check that the file exists
        assert os.path.exists(temp_dxf_file)
        
        # Load the document
        loaded_doc = ezdxf.readfile(temp_dxf_file)
        assert isinstance(loaded_doc, Drawing)
        
        # Check that the loaded document has the expected content
        loaded_msp = loaded_doc.modelspace()
        entities = list(loaded_msp)
        assert len(entities) == 1
        assert entities[0].dxftype() == "LINE"
        assert entities[0].dxf.start == (0, 0, 0)
        assert entities[0].dxf.end == (10, 10, 0)


class TestEntityCreation:
    """Tests for entity creation and manipulation."""
    
    def test_add_line(self, empty_drawing):
        """Test adding a line to a document."""
        msp = empty_drawing.modelspace()
        line = msp.add_line((0, 0), (10, 10))
        
        assert line.dxftype() == "LINE"
        assert line.dxf.start == (0, 0, 0)
        assert line.dxf.end == (10, 10, 0)
    
    def test_add_circle(self, empty_drawing):
        """Test adding a circle to a document."""
        msp = empty_drawing.modelspace()
        circle = msp.add_circle((5, 5), radius=2.5)
        
        assert circle.dxftype() == "CIRCLE"
        assert circle.dxf.center == (5, 5, 0)
        assert circle.dxf.radius == 2.5
    
    def test_add_text(self, empty_drawing):
        """Test adding text to a document."""
        msp = empty_drawing.modelspace()
        text = msp.add_text("Test Text", dxfattribs={"height": 0.5})
        text.set_placement((1, 1))
        
        assert text.dxftype() == "TEXT"
        assert text.dxf.text == "Test Text"
        assert text.dxf.height == 0.5
        assert text.dxf.insert == (1, 1, 0)


class TestLayerManagement:
    """Tests for layer management."""
    
    def test_create_layer(self, empty_drawing):
        """Test creating a new layer."""
        doc = empty_drawing
        layer_name = "TEST_LAYER"
        layer = doc.layers.add(name=layer_name, color=7)
        
        assert doc.layers.has_entry(layer_name)
        assert doc.layers.get(layer_name).get_color() == 7
    
    def test_entity_on_layer(self, empty_drawing):
        """Test adding an entity to a specific layer."""
        doc = empty_drawing
        layer_name = "TEST_LAYER"
        doc.layers.add(layer_name, color=5)
        
        msp = doc.modelspace()
        line = msp.add_line((0, 0), (10, 10), dxfattribs={"layer": layer_name})
        
        assert line.dxf.layer == layer_name


class TestBlockManagement:
    """Tests for block management."""
    
    def test_create_block(self, empty_drawing):
        """Test creating a block definition."""
        doc = empty_drawing
        block_name = "TEST_BLOCK"
        block = doc.blocks.new(block_name)
        
        assert block_name in doc.blocks
        
        # Add entities to the block
        block.add_line((0, 0), (10, 10))
        block.add_circle((5, 5), radius=2.5)
        
        # Check that the entities were added to the block
        entities = list(block)
        assert len(entities) == 2
        assert entities[0].dxftype() == "LINE"
        assert entities[1].dxftype() == "CIRCLE"
    
    def test_insert_block(self, empty_drawing):
        """Test inserting a block reference."""
        doc = empty_drawing
        block_name = "TEST_BLOCK"
        block = doc.blocks.new(block_name)
        block.add_line((0, 0), (10, 10))
        
        msp = doc.modelspace()
        insert = msp.add_blockref(block_name, (5, 5))
        
        assert insert.dxftype() == "INSERT"
        assert insert.dxf.name == block_name
        assert insert.dxf.insert == (5, 5, 0)


class TestDXFVersions:
    """Tests for different DXF versions."""
    
    @pytest.mark.parametrize("version", ["R12", "R2000", "R2004", "R2007", "R2010", "R2013", "R2018"])
    def test_create_version(self, version):
        """Test creating documents with different DXF versions."""
        doc = ezdxf.new(version)
        assert isinstance(doc, Drawing)
        
        # Add a basic entity
        msp = doc.modelspace()
        line = msp.add_line((0, 0), (10, 10))
        assert line.dxftype() == "LINE"
