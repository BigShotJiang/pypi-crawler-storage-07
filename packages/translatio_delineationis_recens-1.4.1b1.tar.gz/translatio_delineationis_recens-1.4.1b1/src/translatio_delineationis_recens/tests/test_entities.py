"""
Tests for entity manipulation in the EzDXF library.
"""
import pytest
import math

import ezdxf
from ezdxf.math import Vec3


class TestEntityManipulation:
    """Tests for entity manipulation."""
    
    def test_line_properties(self, empty_drawing):
        """Test line entity properties."""
        msp = empty_drawing.modelspace()
        line = msp.add_line((0, 0), (10, 10))
        
        # Test basic properties
        assert line.dxf.start == (0, 0, 0)
        assert line.dxf.end == (10, 10, 0)
        
        # Test modification
        line.dxf.start = (1, 1, 0)
        line.dxf.end = (11, 11, 0)
        assert line.dxf.start == (1, 1, 0)
        assert line.dxf.end == (11, 11, 0)
    
    def test_circle_properties(self, empty_drawing):
        """Test circle entity properties."""
        msp = empty_drawing.modelspace()
        circle = msp.add_circle((5, 5), radius=2.5)
        
        # Test basic properties
        assert circle.dxf.center == (5, 5, 0)
        assert circle.dxf.radius == 2.5
        
        # Test modification
        circle.dxf.center = (6, 6, 0)
        circle.dxf.radius = 3.5
        assert circle.dxf.center == (6, 6, 0)
        assert circle.dxf.radius == 3.5
    
    def test_text_properties(self, empty_drawing):
        """Test text entity properties."""
        msp = empty_drawing.modelspace()
        text = msp.add_text("Test Text", dxfattribs={"height": 0.5})
        text.set_placement((1, 1))
        
        # Test basic properties
        assert text.dxf.text == "Test Text"
        assert text.dxf.height == 0.5
        assert text.dxf.insert == (1, 1, 0)
        
        # Test modification
        text.dxf.text = "Modified Text"
        text.dxf.height = 0.75
        text.set_placement((2, 2))
        assert text.dxf.text == "Modified Text"
        assert text.dxf.height == 0.75
        assert text.dxf.insert == (2, 2, 0)
    
    def test_entity_common_properties(self, empty_drawing):
        """Test common entity properties."""
        msp = empty_drawing.modelspace()
        line = msp.add_line((0, 0), (10, 10))
        
        # Test layer property
        line.dxf.layer = "TEST_LAYER"
        assert line.dxf.layer == "TEST_LAYER"
        
        # Test color property
        line.dxf.color = 5
        assert line.dxf.color == 5
        
        # Test linetype property
        line.dxf.linetype = "DASHED"
        assert line.dxf.linetype == "DASHED"


class TestGeometricOperations:
    """Tests for geometric operations."""
    
    def test_line_length(self, empty_drawing):
        """Test calculating line length."""
        msp = empty_drawing.modelspace()
        line = msp.add_line((0, 0), (3, 4))
        
        # Calculate length using the distance formula
        start = Vec3(line.dxf.start)
        end = Vec3(line.dxf.end)
        length = start.distance(end)
        
        assert length == 5.0
    
    def test_circle_area(self, empty_drawing):
        """Test calculating circle area."""
        msp = empty_drawing.modelspace()
        radius = 2.5
        circle = msp.add_circle((5, 5), radius=radius)
        
        # Calculate area using the formula πr²
        area = math.pi * radius**2
        
        assert math.isclose(area, 19.634954084936208, rel_tol=1e-9)
    
    def test_point_transformation(self, empty_drawing):
        """Test point transformation."""
        # Create a point at origin
        point = Vec3(0, 0, 0)
        
        # Translate by (5, 5, 0)
        translated = point + Vec3(5, 5, 0)
        assert translated == Vec3(5, 5, 0)
        
        # Rotate 90 degrees around Z axis
        # In EzDXF, Vec3.rotate_deg() only rotates around Z axis
        rotated = translated.rotate_deg(90)
        assert math.isclose(rotated.x, -5, abs_tol=1e-9)
        assert math.isclose(rotated.y, 5, abs_tol=1e-9)
        assert math.isclose(rotated.z, 0, abs_tol=1e-9)
    
    def test_entity_transformation(self, empty_drawing):
        """Test entity transformation."""
        msp = empty_drawing.modelspace()
        line = msp.add_line((0, 0), (10, 0))
        
        # Rotate the line 90 degrees around origin
        line.rotate_z(math.pi/2)
        
        # Check the new coordinates
        assert math.isclose(line.dxf.start.x, 0, abs_tol=1e-9)
        assert math.isclose(line.dxf.start.y, 0, abs_tol=1e-9)
        assert math.isclose(line.dxf.end.x, 0, abs_tol=1e-9)
        assert math.isclose(line.dxf.end.y, 10, abs_tol=1e-9)
