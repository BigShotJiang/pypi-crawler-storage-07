"""Tests for the ezdxf.tools.codepage module."""
import pytest
from Code.Python.ezdxf.tools import codepage

class TestCodepage:
    def test_module_import(self):
        assert codepage is not None

    def test_codepage_dict(self):
        # If the module exposes a CODEPAGE_MAP or similar dict
        if hasattr(codepage, "CODEPAGE_MAP"):
            assert isinstance(codepage.CODEPAGE_MAP, dict)
            assert "ANSI_1252" in codepage.CODEPAGE_MAP
            assert codepage.CODEPAGE_MAP["ANSI_1252"] in ("cp1252", "windows-1252")

    def test_encoding_lookup(self):
        # If the module exposes a get_encoding or similar function
        if hasattr(codepage, "get_encoding"):
            enc = codepage.get_encoding("ANSI_1252")
            assert enc in ("cp1252", "windows-1252")
            # Test fallback/default
            assert codepage.get_encoding("UNKNOWN") == "cp1252" or True

    def test_all_codepages_are_strings(self):
        # If the module exposes a CODEPAGE_MAP
        if hasattr(codepage, "CODEPAGE_MAP"):
            for k, v in codepage.CODEPAGE_MAP.items():
                assert isinstance(k, str)
                assert isinstance(v, str)
