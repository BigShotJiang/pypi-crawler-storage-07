"""Tests for the ezdxf.tools.indexing module."""
import pytest
from Code.Python.ezdxf.tools.indexing import Index


class TestIndex:
    """Test cases for Index class."""

    def test_init_with_sequence(self):
        """Test initialization with a sequence."""
        index = Index([1, 2, 3, 4, 5])
        assert index.length == 5

    def test_init_with_int(self):
        """Test initialization with an integer."""
        index = Index(10)
        assert index.length == 10

    def test_init_with_float(self):
        """Test initialization with a float (should be converted to int)."""
        index = Index(10.5)
        assert index.length == 10

    def test_init_with_invalid_type(self):
        """Test initialization with an invalid type."""
        with pytest.raises(TypeError):
            Index(None)

    def test_index_positive(self):
        """Test index() with positive index."""
        index = Index(5)
        assert index.index(0) == 0
        assert index.index(1) == 1
        assert index.index(4) == 4

    def test_index_negative(self):
        """Test index() with negative index."""
        index = Index(5)
        assert index.index(-1) == 4
        assert index.index(-2) == 3
        assert index.index(-5) == 0

    def test_index_out_of_range_without_error(self):
        """Test index() with out-of-range index but no error handling."""
        index = Index(5)
        # These should not raise errors when error=None
        assert index.index(10) == 10
        assert index.index(-10) == -5

    def test_index_out_of_range_with_error(self):
        """Test index() with out-of-range index and error handling."""
        index = Index(5)
        
        # Test with positive index out of range
        with pytest.raises(ValueError, match="index out of range"):
            index.index(5, ValueError)
        
        # Test with negative index out of range
        with pytest.raises(ValueError, match="index out of range"):
            index.index(-6, ValueError)

    def test_index_with_float(self):
        """Test index() with float value (should be converted to int)."""
        index = Index(5)
        assert index.index(1.5) == 1
        # The negative float is first converted to int(-1.5) which is -1
        # Then -1 is adjusted to length + (-1) = 5 + (-1) = 4
        assert index.index(-1.5) == 4

    def test_slicing_with_slice_object(self):
        """Test slicing() with a slice object."""
        index = Index(10)
        
        # Test with slice(start, stop, step)
        result = list(index.slicing(slice(1, 8, 2)))
        assert result == [1, 3, 5, 7]
        
        # Test with negative indices
        result = list(index.slicing(slice(-8, -1, 2)))
        assert result == [2, 4, 6, 8]

    def test_slicing_with_args(self):
        """Test slicing() with start, stop, step arguments."""
        index = Index(10)
        
        # Test with start, stop
        result = list(index.slicing(1, 8))
        assert result == [1, 2, 3, 4, 5, 6, 7]
        
        # Test with start, stop, step
        result = list(index.slicing(1, 8, 2))
        assert result == [1, 3, 5, 7]
        
        # Test with negative indices
        result = list(index.slicing(-8, -1, 2))
        assert result == [2, 4, 6, 8]

    def test_slicing_with_none_values(self):
        """Test slicing() with None values."""
        index = Index(10)
        
        # Test with None for start (defaults to 0)
        result = list(index.slicing(None, 5))
        assert result == [0, 1, 2, 3, 4]
        
        # Test with None for stop (defaults to length)
        result = list(index.slicing(5, None))
        assert result == [5, 6, 7, 8, 9]
        
        # Test with None for step (defaults to 1)
        result = list(index.slicing(1, 5, None))
        assert result == [1, 2, 3, 4]
        
        # Test with all None
        result = list(index.slicing(None, None, None))
        assert result == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

    def test_slicing_with_negative_step(self):
        """Test slicing() with negative step."""
        index = Index(10)
        
        # Test with negative step
        result = list(index.slicing(8, 1, -1))
        assert result == [8, 7, 6, 5, 4, 3, 2]
        
        # Test with negative step and negative indices
        result = list(index.slicing(-2, -8, -1))
        assert result == [8, 7, 6, 5, 4, 3]

    def test_slicing_with_out_of_bounds(self):
        """Test slicing() with out-of-bounds indices."""
        index = Index(10)
        
        # Test with start > length
        result = list(index.slicing(15, 20))
        assert result == []
        
        # Test with stop < 0
        result = list(index.slicing(5, -20))
        assert result == []
        
        # Test with start < 0 and stop > length
        result = list(index.slicing(-15, 15))
        assert result == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

    def test_slicing_with_empty_range(self):
        """Test slicing() with empty range."""
        index = Index(10)
        
        # Test with start > stop (and positive step)
        result = list(index.slicing(5, 2))
        assert result == []
        
        # Test with start < stop (and negative step)
        result = list(index.slicing(2, 5, -1))
        assert result == []

    def test_slicing_with_zero_step(self):
        """Test slicing() with zero step."""
        index = Index(10)
        
        # slice.indices() handles step=0 by raising ValueError
        with pytest.raises(ValueError):
            list(index.slicing(0, 5, 0))
