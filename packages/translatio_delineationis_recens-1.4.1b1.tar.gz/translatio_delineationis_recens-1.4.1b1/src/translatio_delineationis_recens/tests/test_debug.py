"""Tests for the ezdxf.tools.debug module."""
import pytest
from Code.Python.ezdxf.tools import debug

class TestGroupChars:
    def test_group_chars_default(self):
        # Default group size is 4, sep is '-'
        assert debug.group_chars("12345678") == "1234-5678"
        assert debug.group_chars("123456789") == "1-2345-6789"
        assert debug.group_chars("") == ""

    def test_group_chars_custom(self):
        assert debug.group_chars("abcdef", n=2, sep=":") == "ab:cd:ef"
        assert debug.group_chars("abcdefg", n=3, sep="|") == "a|bcd|efg"

    def test_group_chars_single_char(self):
        assert debug.group_chars("a") == "a"

class TestBitmaskStrings:
    def test_bitmask_strings_base10(self):
        # Should return 3 lines for value 255
        lines = debug.bitmask_strings(255, base=10)
        from collections.abc import Sequence
        assert isinstance(lines, Sequence)
        assert len(lines) == 3
        # Remove separators for comparison
        assert lines[2].replace("-", "").endswith("11111111")

    def test_bitmask_strings_base16(self):
        lines = debug.bitmask_strings(0xFFFF, base=16)
        from collections.abc import Sequence
        assert isinstance(lines, Sequence)
        assert len(lines) == 3
        # Remove separators for comparison
        assert lines[2].replace("-", "").endswith("1111111111111111")

    def test_bitmask_strings_invalid_base(self):
        with pytest.raises(ValueError):
            debug.bitmask_strings(255, base=8)

class TestPrintBitmask:
    def test_print_bitmask_runs(self, capsys):
        # Should print 4 lines
        debug.print_bitmask(255, base=10)
        captured = capsys.readouterr()
        assert "bin:" in captured.out
        assert "x0 :" in captured.out
        assert "0x :" in captured.out
        assert "=" in captured.out

    def test_print_bitmask_hex(self, capsys):
        debug.print_bitmask(0xFFFF, base=16, sep=":")
        captured = capsys.readouterr()
        assert "bin:" in captured.out
        assert ":" in captured.out
