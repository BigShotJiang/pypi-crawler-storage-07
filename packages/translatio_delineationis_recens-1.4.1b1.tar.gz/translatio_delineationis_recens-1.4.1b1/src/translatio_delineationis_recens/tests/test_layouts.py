"""
Tests for layout functionality in the EzDXF library.
"""
import pytest
import ezdxf
from ezdxf.lldxf.const import DXFValueError


class TestLayoutManagement:
    """Tests for layout management."""
    
    def test_layout_creation(self):
        """Test creating new layouts."""
        doc = ezdxf.new("R2018")
        
        # Test default layouts
        assert "Model" in doc.layouts
        
        # Create a new layout
        layout_name = "Test Layout"
        layout = doc.layouts.new(layout_name)
        assert layout is not None
        assert layout_name in doc.layouts
        
        # Test layout count
        assert len(doc.layouts) >= 2  # At least model space and our new layout
    
    def test_layout_access(self):
        """Test accessing layouts."""
        doc = ezdxf.new("R2018")
        
        # Access model space
        msp = doc.modelspace()
        assert msp is not None
        
        # Create and access paper space
        psp_name = "Test Paper Space"
        psp = doc.layouts.new(psp_name)
        assert psp is not None
        
        # Access by name - use get() method instead of subscription
        psp2 = doc.layouts.get(psp_name)
        assert psp2 is not None
        assert psp2.name == psp_name
        
        # Access by iteration
        layout_names = [layout.name for layout in doc.layouts]
        assert "Model" in layout_names
        assert psp_name in layout_names
    
    def test_layout_deletion(self):
        """Test deleting layouts."""
        doc = ezdxf.new("R2018")
        
        # Create a layout to delete
        layout_name = "Layout to Delete"
        doc.layouts.new(layout_name)
        assert layout_name in doc.layouts
        
        # Delete the layout
        doc.layouts.delete(layout_name)
        assert layout_name not in doc.layouts
        
        # Model space should still exist
        assert "Model" in doc.layouts


class TestModelspace:
    """Tests for model space operations."""
    
    def test_modelspace_entities(self):
        """Test adding and retrieving entities in model space."""
        doc = ezdxf.new("R2018")
        msp = doc.modelspace()
        
        # Add entities
        line = msp.add_line((0, 0), (10, 10))
        circle = msp.add_circle((5, 5), 2.5)
        text = msp.add_text("Test Text")
        
        # Count entities
        entities = list(msp)
        assert len(entities) >= 3  # At least our 3 entities
        
        # Verify entity types exist
        entity_types = [e.dxftype() for e in entities]
        assert "LINE" in entity_types
        assert "CIRCLE" in entity_types
        assert "TEXT" in entity_types
    
    def test_modelspace_query(self):
        """Test querying entities in model space."""
        doc = ezdxf.new("R2018")
        msp = doc.modelspace()
        
        # Create layers
        if "LINES" not in doc.layers:
            doc.layers.add("LINES")
        if "CIRCLES" not in doc.layers:
            doc.layers.add("CIRCLES")
        
        # Add entities with different properties
        msp.add_line((0, 0), (10, 10), dxfattribs={"layer": "LINES"})
        msp.add_line((0, 0), (5, 5), dxfattribs={"layer": "LINES"})
        msp.add_circle((5, 5), 2.5, dxfattribs={"layer": "CIRCLES"})
        
        # Query by entity type
        lines = msp.query("LINE")
        assert len(lines) >= 2  # At least our 2 lines
        
        circles = msp.query("CIRCLE")
        assert len(circles) >= 1  # At least our 1 circle
        
        # Query by layer
        lines_layer = msp.query('*[layer=="LINES"]')
        assert len(lines_layer) >= 2
        
        circles_layer = msp.query('*[layer=="CIRCLES"]')
        assert len(circles_layer) >= 1


class TestPaperspace:
    """Tests for paper space operations."""
    
    def test_paperspace_creation(self):
        """Test creating and accessing paper space layouts."""
        doc = ezdxf.new("R2018")
        
        # Create paper space layouts with unique names
        # Use unique names for each test run to avoid conflicts
        import uuid
        layout1_name = f"Layout1_{uuid.uuid4().hex[:8]}"
        layout2_name = f"Layout2_{uuid.uuid4().hex[:8]}"
            
        # Create the layouts with unique names
        psp1 = doc.layouts.new(layout1_name)
        psp2 = doc.layouts.new(layout2_name)
        
        # Verify paper space layouts
        assert layout1_name in doc.layouts
        assert layout2_name in doc.layouts
        
        # Access paper space layouts using get() method
        layout1 = doc.layouts.get(layout1_name)
        layout2 = doc.layouts.get(layout2_name)
        
        # Verify they're not the model space
        assert layout1.name != "Model"
        assert layout2.name != "Model"
    
    def test_paperspace_entities(self):
        """Test adding and retrieving entities in paper space."""
        doc = ezdxf.new("R2018")
        psp = doc.layouts.new("Test Paper Space")
        
        # Add entities
        line = psp.add_line((0, 0), (10, 10))
        circle = psp.add_circle((5, 5), 2.5)
        
        # Count entities
        entities = list(psp)
        assert len(entities) == 2
        
        # Verify entity types
        entity_types = [e.dxftype() for e in entities]
        assert "LINE" in entity_types
        assert "CIRCLE" in entity_types
    
    def test_viewport_creation(self):
        """Test creating viewports in paper space."""
        doc = ezdxf.new("R2018")
        psp = doc.layouts.new("Viewport Test")
        
        # Create a viewport
        viewport = psp.add_viewport(
            center=(5, 5),
            size=(10, 10),
            view_center_point=(0, 0),
            view_height=10
        )
        
        # Verify viewport was created
        assert viewport is not None
        assert viewport.dxftype() == "VIEWPORT"
        
        # Verify basic viewport properties
        assert viewport.dxf.center == (5, 5, 0)
        assert viewport.dxf.width == 10
        assert viewport.dxf.height == 10


class TestLayoutBlockReference:
    """Tests for layout block references."""
    
    def test_layout_block_references(self):
        """Test block references in layouts."""
        doc = ezdxf.new("R2018")
        
        # Create a block
        block = doc.blocks.new("TEST_BLOCK")
        block.add_line((0, 0), (10, 10))
        block.add_circle((5, 5), 2.5)
        
        # Add block reference to model space
        msp = doc.modelspace()
        blockref = msp.add_blockref("TEST_BLOCK", (0, 0))
        
        # Verify block reference
        assert blockref.dxf.name == "TEST_BLOCK"
        assert blockref.dxf.insert == (0, 0, 0)
        
        # Add block reference to paper space
        psp = doc.layouts.new("Block Test")
        blockref2 = psp.add_blockref("TEST_BLOCK", (5, 5))
        
        # Verify block reference
        assert blockref2.dxf.name == "TEST_BLOCK"
        assert blockref2.dxf.insert == (5, 5, 0)
