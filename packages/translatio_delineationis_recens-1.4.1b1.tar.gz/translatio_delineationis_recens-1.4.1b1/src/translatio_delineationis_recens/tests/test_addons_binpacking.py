import pytest
from ezdxf.addons.binpacking import Item, Bin, PickStrategy, shuffle_pack, RotationType
import math

class DummyBox:
    def get_capacity(self):
        return 10
    def is_empty(self):
        return True
    def copy(self):
        return DummyBox()

class DummyItem:
    def get_volume(self):
        return 1
    def copy(self):
        return DummyItem()

class DummyPacker:
    def __init__(self):
        self.bins = [DummyBox()]
        self.items = [DummyItem()]
        self.is_packed = False
    def copy(self):
        return DummyPacker()
    def pack(self, strategy):
        self.is_packed = True
    def get_fill_ratio(self):
        return 0.5


def test_item_init_and_volume():
    item = Item('payload', 2, 3, 4, 5)
    assert item.width == 2
    assert item.height == 3
    assert item.depth == 4
    assert item.weight == 5
    assert item.get_volume() == 24
    assert str(item).startswith('payload(')


def test_bin_init_and_capacity():
    bin = Bin('bin1', 5, 6, 7, 8)
    assert bin.width == 5
    assert bin.height == 6
    assert bin.depth == 7
    assert bin.max_weight == 8
    assert bin.get_capacity() == 210
    assert str(bin).startswith('bin1(')


def test_shuffle_pack_runs():
    packer = DummyPacker()
    result = shuffle_pack(packer, 3)
    assert isinstance(result, DummyPacker)
    assert result.get_fill_ratio() == 0.5


def test_shuffle_pack_invalid_attempts():
    packer = DummyPacker()
    with pytest.raises(ValueError):
        shuffle_pack(packer, 0)


def test_pick_strategy_enum():
    assert PickStrategy.SMALLER_FIRST != PickStrategy.BIGGER_FIRST
    assert PickStrategy.SHUFFLE in PickStrategy


def test_item_rotation_and_position():
    item = Item('payload', 2, 3, 4)
    # Default rotation
    assert item.rotation_type == RotationType.WHD
    # Change rotation
    item.rotation_type = RotationType.DHW
    assert item.rotation_type == RotationType.DHW
    # Position
    item.position = (1, 2, 3)
    assert item.position == (1, 2, 3)
    # Bbox should update
    bbox = item.bbox
    assert hasattr(bbox, 'extmin') and hasattr(bbox, 'extmax')


def test_bin_add_remove_items():
    bin = Bin('bin2', 5, 5, 5)
    item1 = Item('a', 1, 1, 1)
    item2 = Item('b', 2, 2, 2)
    bin.items.append(item1)
    bin.items.append(item2)
    assert len(bin.items) == 2
    bin.items.remove(item1)
    assert len(bin.items) == 1
    bin.items.clear()
    assert len(bin.items) == 0


def test_bin_overflow():
    bin = Bin('bin3', 2, 2, 2, max_weight=3)
    item = Item('heavy', 1, 1, 1, weight=5)
    bin.items.append(item)
    # Should be overweight
    assert bin.get_total_weight() > bin.max_weight
    # Remove to fix
    bin.items.remove(item)
    assert bin.get_total_weight() == 0


def test_item_get_transformation():
    item = Item('payload', 1, 2, 3)
    item.position = (4, 5, 6)
    m = item.get_transformation()
    # Should be a 4x4 matrix (Matrix44)
    assert hasattr(m, 'transform') or hasattr(m, '__matmul__')


def test_pick_strategy_sorting_helpers():
    # Simulate _smaller_first/_bigger_first
    class Box:
        def __init__(self, cap): self._cap = cap
        def get_capacity(self): return self._cap
    class It:
        def __init__(self, vol): self._vol = vol
        def get_volume(self): return self._vol
    bins = [Box(5), Box(2), Box(9)]
    items = [It(3), It(1), It(7)]
    # _smaller_first
    bins.sort(key=lambda b: b.get_capacity())
    items.sort(key=lambda i: i.get_volume())
    assert [b.get_capacity() for b in bins] == [2, 5, 9]
    assert [i.get_volume() for i in items] == [1, 3, 7]
    # _bigger_first
    bins.sort(key=lambda b: b.get_capacity(), reverse=True)
    items.sort(key=lambda i: i.get_volume(), reverse=True)
    assert [b.get_capacity() for b in bins] == [9, 5, 2]
    assert [i.get_volume() for i in items] == [7, 3, 1]
