import pytest
from ezdxf.revcloud import points, add_entity, is_revcloud, REVCLOUD_PROPS, REQUIRED_BULGE

# Minimal mocks for LWPolyline, DXFEntity, and layout
class DummyLWPolyline:
    def __init__(self, closed=True, xdata=True, bulge=REQUIRED_BULGE):
        self.is_closed = closed
        self._xdata = xdata
        self._bulge = bulge
    def has_xdata(self, name):
        return self._xdata and name == REVCLOUD_PROPS
    def get_points(self, format=None):
        # Return points with bulge values
        return [(self._bulge,)] * 4

class DummyDXFEntity:
    pass

class DummyAppIDs:
    def __init__(self):
        self.entries = set()
    def has_entry(self, name):
        return name in self.entries
    def add(self, name):
        self.entries.add(name)

class DummyDoc:
    def __init__(self):
        self.appids = DummyAppIDs()

class DummyLayout:
    def __init__(self):
        self.doc = DummyDoc()
        self.added = []
    def add_lwpolyline(self, points, close, dxfattribs=None):
        self.added.append((points, close, dxfattribs))
        # Return a DummyLWPolyline with closed and xdata True
        poly = DummyLWPolyline(closed=close, xdata=True)
        poly.set_xdata = lambda name, xdata: None
        return poly

# --- points() ---
def test_points_triangle():
    triangle = [(0,0), (1,0), (0,1)]
    pts = points(triangle, segment_length=1.0)
    assert len(pts) == 4  # closed polygon, 4 points
    assert all(len(p) == 5 for p in pts)

def test_points_too_few():
    with pytest.raises(ValueError):
        points([(0,0), (1,0)], segment_length=1.0)

def test_points_too_small_segment():
    triangle = [(0,0), (1,0), (0,1)]
    with pytest.raises(ValueError):
        points(triangle, segment_length=1e-8)

# --- add_entity() ---
def test_add_entity_adds_lwpolyline_and_appid():
    layout = DummyLayout()
    triangle = [(0,0), (1,0), (0,1)]
    poly = add_entity(layout, triangle, segment_length=1.0)
    assert isinstance(poly, DummyLWPolyline)
    assert layout.doc.appids.has_entry(REVCLOUD_PROPS)
    assert poly.is_closed

def test_add_entity_calligraphy_false():
    layout = DummyLayout()
    triangle = [(0,0), (1,0), (0,1)]
    poly = add_entity(layout, triangle, segment_length=1.0, calligraphy=False)
    assert isinstance(poly, DummyLWPolyline)

# --- is_revcloud() ---
import pytest
from ezdxf.revcloud import is_revcloud, REQUIRED_BULGE

def test_is_revcloud_true():
    try:
        from ezdxf.entities import LWPolyline
        # Create a minimal LWPolyline instance
        # This requires a DXF document context; skip if not possible
        import ezdxf
        doc = ezdxf.new()
        msp = doc.modelspace()
        points = [(0,0), (1,0), (0,1), (0,0)]
        poly = msp.add_lwpolyline([(x, y, 0.0, 0.0, REQUIRED_BULGE) for x, y in points], close=True)
        poly.set_xdata("RevcloudProps", [(1070, 0), (1040, 1.0)])
        assert is_revcloud(poly)
    except Exception:
        pytest.skip("Could not create a real LWPolyline for this test in this environment.")

def test_is_revcloud_false_not_polyline():
    entity = DummyDXFEntity()
    assert not is_revcloud(entity)

def test_is_revcloud_false_not_closed():
    poly = DummyLWPolyline(closed=False, xdata=True)
    assert not is_revcloud(poly)

def test_is_revcloud_false_no_xdata():
    poly = DummyLWPolyline(closed=True, xdata=False)
    assert not is_revcloud(poly)

def test_is_revcloud_false_wrong_bulge():
    poly = DummyLWPolyline(closed=True, xdata=True, bulge=0.0)
    assert not is_revcloud(poly)
