import pytest
from types import SimpleNamespace
from Code.Python.ezdxf.acis import entities, const

# --- Mocks and stubs ---
class DummyLoader:
    version = 9999  # High enough for SupportsPattern
    def read_int(self, skip_sat=None): return 42
    def read_double(self): return 3.14
    def read_interval(self): return 1.23
    def read_vec3(self): return (1.0, 2.0, 3.0)
    def read_bool(self, true, false): return True
    def read_str(self): return "abc"
    def read_ptr(self): return entities.NONE_REF
    def read_transform(self):
        # Return a flat list of 16 floats (identity matrix), print for debug
        data = [1.0, 0.0, 0.0, 0.0,
                0.0, 1.0, 0.0, 0.0,
                0.0, 0.0, 1.0, 0.0,
                0.0, 0.0, 0.0, 1.0]
        print('DEBUG: DummyLoader.read_transform returning:', data)
        return list(data)  # ensure a new list each call

class DummyExporter:
    def write_int(self, value, skip_sat=False): self.last_int = value
    def write_double(self, value): self.last_double = value
    def write_interval(self, value): self.last_interval = value
    def write_loc_vec3(self, value): self.last_loc = value
    def write_dir_vec3(self, value): self.last_dir = value
    def write_bool(self, value, true, false): self.last_bool = value
    def write_str(self, value): self.last_str = value
    def write_literal_str(self, value): self.last_lit = value
    def write_ptr(self, entity): self.last_ptr = entity
    def write_transform(self, data): self.last_transform = data

# --- Tests ---
def test_none_entity_and_none_ref():
    none = entities.NoneEntity()
    assert none.is_none
    assert entities.NONE_REF.is_none

def test_acis_entity_str_and_defaults():
    e = entities.AcisEntity()
    assert str(e) == f"unsupported-entity({e.id})"
    # AcisEntity is not a NoneEntity, so is_none should be False
    assert not e.is_none
    # attributes default to NONE_REF
    assert e.attributes.is_none

def test_acis_entity_load_and_export():
    e = entities.AcisEntity()
    loader = DummyLoader()
    factory = lambda ent: e
    # Should not raise
    e.load(loader, factory)
    # Should raise ExportError for unsupported entity
    with pytest.raises(const.ExportError):
        e.export(DummyExporter())

def test_export_sat_and_sab_invalid_version():
    b = entities.AcisEntity()
    with pytest.raises(const.ExportError):
        entities.export_sat([b], version=0)
    with pytest.raises(const.ExportError):
        entities.export_sab([b], version=0)

def test_register_and_entity_types():
    class Dummy(entities.AcisEntity):
        type = "dummy"
    entities.register(Dummy)
    assert "dummy" in entities.ENTITY_TYPES
    assert entities.ENTITY_TYPES["dummy"] is Dummy

def test_setup_export_header_valid():
    header = entities._setup_export_header(const.MIN_EXPORT_VERSION)
    assert hasattr(header, 'set_version')
    assert header.version == const.MIN_EXPORT_VERSION

# Test Transform entity basic logic
def test_transform_restore_and_write():
    t = entities.Transform()
    loader = DummyLoader()
    exporter = DummyExporter()
    t.restore_data(loader)
    t.write_common(exporter)
    assert hasattr(t, 'matrix')
    t.write_common(exporter)
    # Should set last written values
    assert hasattr(exporter, 'last_transform')  # Transform.write_common calls write_transform, not write_dir_vec3

# Test AsmHeader entity logic
def test_asmheader_restore_and_write():
    a = entities.AsmHeader("v1")
    loader = DummyLoader()
    exporter = DummyExporter()
    a.restore_common(loader, lambda ent: entities.AcisEntity())
    a.write_common(exporter)

# Test SupportsPattern logic
def test_supports_pattern_restore_and_write():
    class DummyPatternEntity(entities.SupportsPattern):
        type = "pattern"
        pattern = entities.NONE_REF
    d = DummyPatternEntity()
    loader = DummyLoader()
    exporter = DummyExporter()
    # Patch loader.read_ptr to return a mock with is_null_ptr=True
    class PtrMock:
        is_null_ptr = True
    loader.read_ptr = lambda: PtrMock()
    d.restore_common(loader, lambda ent: entities.AcisEntity())
    d.write_common(exporter)
