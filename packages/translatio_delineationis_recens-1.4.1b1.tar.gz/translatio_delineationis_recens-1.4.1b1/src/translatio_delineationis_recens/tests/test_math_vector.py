"""Tests for the ezdxf.math._vector module."""
import math
import pytest
import copy
from Code.Python.ezdxf.math._vector import Vec3, Vec2, X_AXIS, Y_AXIS, Z_AXIS, NULLVEC, distance, lerp


class TestVec3:
    """Test cases for the Vec3 class."""

    def test_init(self):
        """Test Vec3 initialization and invalid input."""
        # Valid initializations
        v = Vec3()
        assert v.x == 0.0 and v.y == 0.0 and v.z == 0.0
        v = Vec3((1, 2))
        assert v.x == 1.0 and v.y == 2.0 and v.z == 0.0
        v = Vec3((1, 2, 3))
        assert v.x == 1.0 and v.y == 2.0 and v.z == 3.0
        v = Vec3([4, 5])
        assert v.x == 4.0 and v.y == 5.0 and v.z == 0.0
        v = Vec3([4, 5, 6])
        assert v.x == 4.0 and v.y == 5.0 and v.z == 6.0
        v = Vec3(7, 8)
        assert v.x == 7.0 and v.y == 8.0 and v.z == 0.0
        v = Vec3(7, 8, 9)
        assert v.x == 7.0 and v.y == 8.0 and v.z == 9.0
        # Invalid initializations
        with pytest.raises(TypeError):
            Vec3('a', 'b')
        with pytest.raises(TypeError):
            Vec3([1])
        with pytest.raises(TypeError):
            Vec3(1, 2, 3, 4)
        with pytest.raises(TypeError):
            Vec3([1, 2, 3, 4])
        # Immutability
        v = Vec3(1, 2, 3)
        with pytest.raises(AttributeError):
            v.x = 10
        with pytest.raises(AttributeError):
            v.y = 10
        with pytest.raises(AttributeError):
            v.z = 10

    def test_properties(self):
        """Test Vec3 properties."""
        v = Vec3(1, 2, 3)
        
        # Test xy property
        xy = v.xy
        assert isinstance(xy, Vec3)
        assert xy.x == 1.0
        assert xy.y == 2.0
        assert xy.z == 0.0
        
        # Test xyz property
        xyz = v.xyz
        assert isinstance(xyz, tuple)
        assert xyz == (1.0, 2.0, 3.0)
        
        # Test vec2 property
        vec2 = v.vec2
        assert isinstance(vec2, Vec2)
        assert vec2.x == 1.0
        assert vec2.y == 2.0

    def test_replace(self):
        """Test Vec3.replace method and edge cases."""
        v = Vec3(1, 2, 3)
        # Replace each component
        assert v.replace(x=10) == Vec3(10, 2, 3)
        assert v.replace(y=20) == Vec3(1, 20, 3)
        assert v.replace(z=30) == Vec3(1, 2, 30)
        # Replace multiple
        assert v.replace(x=10, y=20, z=30) == Vec3(10, 20, 30)
        # Replace with None (should be unchanged)
        assert v.replace(x=None, y=None, z=None) == v
        # Original vector remains unchanged
        assert v == Vec3(1, 2, 3)

    def test_round(self):
        """Test Vec3.round method and edge cases."""
        v = Vec3(1.234, 2.345, 3.456)
        # Round to 2 digits
        v2 = v.round(2)
        assert v2 == Vec3(1.23, 2.35, 3.46)
        # Round to 1 digit
        v2 = v.round(1)
        assert v2 == Vec3(1.2, 2.3, 3.5)
        # Round to integer
        v2 = v.round(0)
        assert v2 == Vec3(1.0, 2.0, 3.0)
        # Round to negative ndigits (should round to tens, etc.)
        v = Vec3(15.1, 25.9, 35.5)
        v2 = v.round(-1)
        assert v2 == Vec3(20.0, 30.0, 40.0)

    def test_class_methods(self):
        """Test Vec3 class/static methods and edge cases."""
        # list/tuple/generate
        items = [(1, 2, 3), (4, 5, 6)]
        vec_list = Vec3.list(items)
        assert len(vec_list) == 2 and all(isinstance(v, Vec3) for v in vec_list)
        vec_tuple = Vec3.tuple(items)
        assert len(vec_tuple) == 2 and all(isinstance(v, Vec3) for v in vec_tuple)
        gen = list(Vec3.generate(items))
        assert gen == vec_list
        # from_angle/from_deg_angle
        v = Vec3.from_angle(0)
        assert math.isclose(v.x, 1.0, abs_tol=1e-12)
        assert math.isclose(v.y, 0.0, abs_tol=1e-12)
        assert v.z == 0.0
        v = Vec3.from_angle(math.pi/2)
        assert math.isclose(v.x, 0.0, abs_tol=1e-12)
        assert math.isclose(v.y, 1.0, abs_tol=1e-12)
        assert v.z == 0.0
        v = Vec3.from_deg_angle(90)
        assert math.isclose(v.x, 0.0, abs_tol=1e-12)
        assert math.isclose(v.y, 1.0, abs_tol=1e-12)
        assert v.z == 0.0
        # decompose
        assert Vec3.decompose() == (0.0, 0.0, 0.0)
        assert Vec3.decompose((1, 2)) == (1.0, 2.0, 0.0)
        assert Vec3.decompose((1, 2, 3)) == (1.0, 2.0, 3.0)
        assert Vec3.decompose(1, 2) == (1.0, 2.0, 0.0)
        assert Vec3.decompose(1, 2, 3) == (1.0, 2.0, 3.0)
        with pytest.raises(ValueError):
            Vec3.decompose('a', 'b')
        with pytest.raises(TypeError):
            Vec3.decompose([1])
        with pytest.raises(TypeError):
            Vec3.decompose(1, 2, 3, 4)

    def test_random(self):
        """Test Vec3.random method output range."""
        v = Vec3.random()
        assert isinstance(v, Vec3)
        assert math.isclose(v.magnitude, 1.0, abs_tol=1e-12)
        v = Vec3.random(length=5)
        assert math.isclose(v.magnitude, 5.0, abs_tol=1e-12)

    def test_string_representation(self):
        """Test __str__ and __repr__ methods."""
        v = Vec3(1, 2, 3)
        assert str(v) == "(1.0, 2.0, 3.0)"
        assert repr(v) == "Vec3(1.0, 2.0, 3.0)"

    def test_len_and_hash(self):
        """Test __len__ and __hash__ methods, equality, and set behavior."""
        v = Vec3(1, 2, 3)
        assert len(v) == 3
        v2 = Vec3(1, 2, 3)
        assert hash(v) == hash(v2)
        s = set([v, v2])
        assert len(s) == 1
        # Equality
        assert v == v2
        assert v == (1, 2, 3)
        assert v != (1, 2)
        # Removed test for equality with string, as it raises TypeError by design.

    def test_copy_and_deepcopy(self):
        """Test copy and deepcopy functionality and edge cases."""
        v = Vec3(1, 2, 3)
        v2 = v.copy()
        assert v2 == v
        v3 = copy.deepcopy(v)
        assert v3 == v

    def test_indexing_and_iteration(self):
        """Test indexing, iteration, and error handling for Vec3."""
        v = Vec3(1, 2, 3)
        assert v[0] == 1.0
        assert v[1] == 2.0
        assert v[2] == 3.0
        vals = [x for x in v]
        assert vals == [1.0, 2.0, 3.0]
        with pytest.raises(IndexError):
            _ = v[3]

    def test_magnitude(self):
        """Test magnitude, magnitude_xy, magnitude_square, and edge cases."""
        v = Vec3(3, 4, 0)
        assert math.isclose(v.magnitude, 5.0)
        assert math.isclose(abs(v), 5.0)
        v = Vec3(0, 0, 0)
        assert v.magnitude == 0.0
        assert abs(v) == 0.0
        v = Vec3(1, 2, 2)
        assert math.isclose(v.magnitude, 3.0)
        # magnitude_xy
        v = Vec3(3, 4, 5)
        assert math.isclose(v.magnitude_xy, 5.0)
        # magnitude_square
        v = Vec3(2, 3, 6)
        assert v.magnitude_square == 49.0

    def test_is_null(self):
        """Test is_null method and floating-point tolerance edge cases."""
        v = Vec3(0, 0, 0)
        assert v.is_null
        v = Vec3(1e-13, 0, 0)
        assert v.is_null
        v = Vec3(1e-10, 0, 0)
        assert not v.is_null

    def test_arithmetic_operations(self):
        """Test arithmetic operations."""
        v1 = Vec3(1, 2, 3)
        v2 = Vec3(4, 5, 6)
        
        # Test addition
        result = v1 + v2
        assert isinstance(result, Vec3)
        assert result.xyz == (5, 7, 9)
        
        # Test subtraction
        result = v2 - v1
        assert isinstance(result, Vec3)
        assert result.xyz == (3, 3, 3)
        
        # Test scalar multiplication
        result = v1 * 2
        assert isinstance(result, Vec3)
        assert result.xyz == (2, 4, 6)
        
        # Test right-hand scalar multiplication
        result = 3 * v1
        assert isinstance(result, Vec3)
        assert result.xyz == (3, 6, 9)
        
        # Test scalar division
        result = v1 / 2
        assert isinstance(result, Vec3)
        assert result.xyz == (0.5, 1.0, 1.5)
        
        # Test negation
        result = -v1
        assert isinstance(result, Vec3)
        assert result.xyz == (-1, -2, -3)

    def test_comparison(self):
        """Test comparison operations."""
        v1 = Vec3(1, 2, 3)
        v2 = Vec3(1, 2, 3)
        v3 = Vec3(4, 5, 6)
        
        # Test equality
        assert v1 == v2
        assert v1 == (1, 2, 3)  # Compare with tuple
        assert not (v1 == v3)
        
        # Test inequality
        assert v1 != v3
        assert not (v1 != v2)
        
        # Test less than
        assert v1 < v3
        assert not (v3 < v1)

    def test_bool(self):
        """Test boolean evaluation."""
        assert bool(Vec3(1, 2, 3))       # Non-zero vector is True
        assert bool(Vec3(0, 1, 0))       # Any non-zero component makes it True
        assert not bool(Vec3(0, 0, 0))   # Zero vector is False

    def test_dot_product(self):
        """Test dot product calculation."""
        v1 = Vec3(1, 2, 3)
        v2 = Vec3(4, 5, 6)
        
        # Dot product: 1*4 + 2*5 + 3*6 = 4 + 10 + 18 = 32
        assert math.isclose(v1.dot(v2), 32.0)
        
        # Perpendicular vectors have dot product = 0
        v3 = Vec3(1, 0, 0)
        v4 = Vec3(0, 1, 0)
        assert math.isclose(v3.dot(v4), 0.0)

    def test_cross_product(self):
        """Test cross product calculation."""
        v1 = Vec3(1, 0, 0)  # Unit vector along x-axis
        v2 = Vec3(0, 1, 0)  # Unit vector along y-axis
        
        # Cross product of x and y unit vectors is z unit vector
        result = v1.cross(v2)
        assert isinstance(result, Vec3)
        assert math.isclose(result.x, 0.0, abs_tol=1e-12)
        assert math.isclose(result.y, 0.0, abs_tol=1e-12)
        assert math.isclose(result.z, 1.0, abs_tol=1e-12)
        
        # Cross product is anti-commutative: v1 × v2 = -(v2 × v1)
        result2 = v2.cross(v1)
        assert result2.xyz == (-result.x, -result.y, -result.z)

    def test_distance(self):
        """Test distance calculation."""
        v1 = Vec3(1, 2, 3)
        v2 = Vec3(4, 6, 3)  # Same z-coordinate
        
        # Distance: sqrt((4-1)² + (6-2)² + (3-3)²) = sqrt(9 + 16 + 0) = sqrt(25) = 5
        assert math.isclose(v1.distance(v2), 5.0)

    def test_normalize(self):
        """Test vector normalization."""
        v = Vec3(3, 4, 0)  # Length is 5
        
        # Normalize to unit vector
        unit_v = v.normalize()
        assert isinstance(unit_v, Vec3)
        assert math.isclose(unit_v.magnitude, 1.0, abs_tol=1e-9)
        assert math.isclose(unit_v.x, 0.6, abs_tol=1e-9)  # 3/5 = 0.6
        assert math.isclose(unit_v.y, 0.8, abs_tol=1e-9)  # 4/5 = 0.8
        
        # Normalize to specific length
        v2 = v.normalize(2.5)
        assert math.isclose(v2.magnitude, 2.5, abs_tol=1e-9)

    def test_lerp(self):
        """Test linear interpolation."""
        v1 = Vec3(1, 1, 1)
        v2 = Vec3(3, 3, 3)
        
        # Mid-point (default factor=0.5)
        mid = v1.lerp(v2)
        assert isinstance(mid, Vec3)
        assert mid.xyz == (2, 2, 2)
        
        # 25% from v1 to v2
        quarter = v1.lerp(v2, 0.25)
        assert quarter.xyz == (1.5, 1.5, 1.5)
        
        # 75% from v1 to v2
        three_quarters = v1.lerp(v2, 0.75)
        assert three_quarters.xyz == (2.5, 2.5, 2.5)

    def test_rotate(self):
        """Test vector rotation."""
        v = Vec3(1, 0, 0)  # Unit vector along x-axis
        
        # Rotate 90 degrees (π/2 radians) around z-axis
        rotated = v.rotate(math.pi/2)
        assert isinstance(rotated, Vec3)
        assert math.isclose(rotated.x, 0.0, abs_tol=1e-12)
        assert math.isclose(rotated.y, 1.0, abs_tol=1e-12)
        assert math.isclose(rotated.z, 0.0, abs_tol=1e-12)
        
        # Rotate 90 degrees using degrees
        rotated_deg = v.rotate_deg(90)
        assert math.isclose(rotated_deg.x, 0.0, abs_tol=1e-12)
        assert math.isclose(rotated_deg.y, 1.0, abs_tol=1e-12)
        assert math.isclose(rotated_deg.z, 0.0, abs_tol=1e-12)

    def test_angle(self):
        """Test angle calculations."""
        v = Vec3(1, 1, 0)  # 45 degrees in xy-plane
        
        # Angle in radians
        assert math.isclose(v.angle, math.pi/4, abs_tol=1e-12)  # π/4 = 45°
        
        # Angle in degrees
        assert math.isclose(v.angle_deg, 45.0, abs_tol=1e-12)
        
    def test_spatial_angle(self):
        """Test spatial angle calculations."""
        v = Vec3(1, 0, 1)  # 45 degrees in xz-plane
        
        # Spatial angle in radians
        assert math.isclose(v.spatial_angle, math.pi/4, abs_tol=1e-12)  # π/4 = 45°
        
        # Spatial angle in degrees
        assert math.isclose(v.spatial_angle_deg, 45.0, abs_tol=1e-12)
        
    def test_orthogonal(self):
        """Test orthogonal vector generation."""
        v = Vec3(1, 0, 0)  # Unit vector along x-axis
        
        # Counter-clockwise orthogonal (default)
        ortho_ccw = v.orthogonal()
        assert isinstance(ortho_ccw, Vec3)
        assert math.isclose(ortho_ccw.x, 0.0, abs_tol=1e-12)
        assert math.isclose(ortho_ccw.y, 1.0, abs_tol=1e-12)
        assert math.isclose(ortho_ccw.z, 0.0, abs_tol=1e-12)
        
        # Clockwise orthogonal
        ortho_cw = v.orthogonal(ccw=False)
        assert isinstance(ortho_cw, Vec3)
        assert math.isclose(ortho_cw.x, 0.0, abs_tol=1e-12)
        assert math.isclose(ortho_cw.y, -1.0, abs_tol=1e-12)
        assert math.isclose(ortho_cw.z, 0.0, abs_tol=1e-12)
        
    def test_is_parallel(self):
        """Test is_parallel method."""
        v1 = Vec3(1, 0, 0)
        v2 = Vec3(2, 0, 0)  # Parallel to v1
        v3 = Vec3(0, 1, 0)  # Perpendicular to v1
        
        assert v1.is_parallel(v2)
        assert not v1.is_parallel(v3)
        
        # Test with tolerance
        v4 = Vec3(1, 0.0000001, 0)  # Almost parallel to v1
        assert v1.is_parallel(v4, abs_tol=1e-6)
        assert not v1.is_parallel(v4, abs_tol=1e-12)  # Default tolerance is stricter
        
    def test_angle_between(self):
        """Test angle between vectors."""
        v1 = Vec3(1, 0, 0)  # x-axis
        v2 = Vec3(0, 1, 0)  # y-axis
        
        # Angle between x and y axis is 90 degrees (π/2)
        assert math.isclose(v1.angle_between(v2), math.pi/2, abs_tol=1e-12)
        
        # Angle between parallel vectors is 0
        v3 = Vec3(2, 0, 0)  # Parallel to x-axis
        assert math.isclose(v1.angle_between(v3), 0.0, abs_tol=1e-12)
        
        # Angle between anti-parallel vectors is 180 degrees (π)
        v4 = Vec3(-1, 0, 0)  # Anti-parallel to x-axis
        assert math.isclose(v1.angle_between(v4), math.pi, abs_tol=1e-12)
        
    def test_angle_about(self):
        """Test angle_about method."""
        normal = Vec3(0, 0, 1)  # z-axis as normal vector
        base = Vec3(1, 0, 0)    # x-axis as base vector
        
        # Test with target at 90 degrees (y-axis)
        target1 = Vec3(0, 1, 0)
        assert math.isclose(normal.angle_about(base, target1), math.pi/2, abs_tol=1e-12)
        
        # Test with target at 180 degrees (-x-axis)
        target2 = Vec3(-1, 0, 0)
        assert math.isclose(normal.angle_about(base, target2), math.pi, abs_tol=1e-12)
        
        # Test with target at 270 degrees (-y-axis)
        target3 = Vec3(0, -1, 0)
        assert math.isclose(normal.angle_about(base, target3), 3*math.pi/2, abs_tol=1e-12)


class TestVectorConstants:
    """Test cases for vector constants."""
    
    def test_axis_constants(self):
        """Test axis constants."""
        # Test X_AXIS
        assert X_AXIS.x == 1.0
        assert X_AXIS.y == 0.0
        assert X_AXIS.z == 0.0
        
        # Test Y_AXIS
        assert Y_AXIS.x == 0.0
        assert Y_AXIS.y == 1.0
        assert Y_AXIS.z == 0.0
        
        # Test Z_AXIS
        assert Z_AXIS.x == 0.0
        assert Z_AXIS.y == 0.0
        assert Z_AXIS.z == 1.0
        
        # Test NULLVEC
        assert NULLVEC.x == 0.0
        assert NULLVEC.y == 0.0
        assert NULLVEC.z == 0.0
        assert NULLVEC.is_null


class TestVectorFunctions:
    """Test cases for standalone vector functions."""
    
    def test_distance_function(self):
        """Test distance function."""
        p1 = (1, 2, 3)
        p2 = (4, 6, 3)  # Same z-coordinate
        
        # Distance: sqrt((4-1)² + (6-2)² + (3-3)²) = sqrt(9 + 16 + 0) = sqrt(25) = 5
        assert math.isclose(distance(p1, p2), 5.0)
        
        # Test with Vec3 objects
        v1 = Vec3(1, 2, 3)
        v2 = Vec3(4, 6, 3)
        assert math.isclose(distance(v1, v2), 5.0)
    
    def test_lerp_function(self):
        """Test lerp function."""
        p1 = (1, 1, 1)
        p2 = (3, 3, 3)
        
        # Mid-point (default factor=0.5)
        mid = lerp(p1, p2)
        assert isinstance(mid, Vec3)
        assert mid.xyz == (2, 2, 2)
        
        # 25% from p1 to p2
        quarter = lerp(p1, p2, 0.25)
        assert quarter.xyz == (1.5, 1.5, 1.5)


class TestVec2:
    """Test cases for the Vec2 class."""
    
    def test_vec3_conversion(self):
        """Test conversion from Vec2 to Vec3."""
        v2 = Vec2(1, 2)
        v3 = v2.vec3
        
        assert isinstance(v3, Vec3)
        assert v3.x == 1.0
        assert v3.y == 2.0
        assert v3.z == 0.0

    def test_init(self):
        """Test Vec2 initialization."""
        # Test initialization with no arguments
        v = Vec2()
        assert v.x == 0.0
        assert v.y == 0.0

        # Test initialization with tuple (x, y)
        v = Vec2((1, 2))
        assert v.x == 1.0
        assert v.y == 2.0

        # Test initialization with x, y arguments
        v = Vec2(4, 5)
        assert v.x == 4.0
        assert v.y == 5.0

    def test_properties(self):
        """Test Vec2 properties."""
        v = Vec2(3, 4)
        
        # Test x and y properties
        assert v.x == 3.0
        assert v.y == 4.0

    def test_magnitude(self):
        """Test magnitude calculations for Vec2."""
        v = Vec2(3, 4)  # 3-4-5 triangle
        
        # Test magnitude (length)
        assert math.isclose(v.magnitude, 5.0)
        assert math.isclose(abs(v), 5.0)  # abs() returns magnitude

    def test_angle(self):
        """Test angle calculations for Vec2."""
        v = Vec2(1, 1)  # 45 degrees
        
        # Angle in radians
        assert math.isclose(v.angle, math.pi/4, abs_tol=1e-12)  # π/4 = 45°
        
        # Angle in degrees
        assert math.isclose(v.angle_deg, 45.0, abs_tol=1e-12)

    def test_arithmetic_operations_vec2(self):
        """Test arithmetic operations for Vec2."""
        v1 = Vec2(1, 2)
        v2 = Vec2(3, 4)
        
        # Test addition
        result = v1 + v2
        assert isinstance(result, Vec2)
        assert result.x == 4.0
        assert result.y == 6.0
        
        # Test subtraction
        result = v2 - v1
        assert isinstance(result, Vec2)
        assert result.x == 2.0
        assert result.y == 2.0
        
        # Test scalar multiplication
        result = v1 * 2
        assert isinstance(result, Vec2)
        assert result.x == 2.0
        assert result.y == 4.0
        
        # Test scalar division
        result = v2 / 2
        assert isinstance(result, Vec2)
        assert result.x == 1.5
        assert result.y == 2.0

    def test_dot_and_det(self):
        """Test dot product and determinant for Vec2."""
        v1 = Vec2(1, 2)
        v2 = Vec2(3, 4)
        
        # Dot product: 1*3 + 2*4 = 3 + 8 = 11
        assert math.isclose(v1.dot(v2), 11.0)
        
        # Determinant: 1*4 - 2*3 = 4 - 6 = -2
        assert math.isclose(v1.det(v2), -2.0)

    def test_rotate_vec2(self):
        """Test vector rotation for Vec2."""
        v = Vec2(1, 0)  # Unit vector along x-axis
        
        # Rotate 90 degrees (π/2 radians)
        rotated = v.rotate(math.pi/2)
        assert isinstance(rotated, Vec2)
        assert math.isclose(rotated.x, 0.0, abs_tol=1e-12)
        assert math.isclose(rotated.y, 1.0, abs_tol=1e-12)
        
        # Rotate 90 degrees using degrees
        rotated_deg = v.rotate_deg(90)
        assert math.isclose(rotated_deg.x, 0.0, abs_tol=1e-12)
        assert math.isclose(rotated_deg.y, 1.0, abs_tol=1e-12)
        
    def test_orthogonal_vec2(self):
        """Test orthogonal vector generation for Vec2."""
        v = Vec2(1, 0)  # Unit vector along x-axis
        
        # Counter-clockwise orthogonal (default)
        ortho_ccw = v.orthogonal()
        assert isinstance(ortho_ccw, Vec2)
        assert math.isclose(ortho_ccw.x, 0.0, abs_tol=1e-12)
        assert math.isclose(ortho_ccw.y, 1.0, abs_tol=1e-12)
        
        # Clockwise orthogonal
        ortho_cw = v.orthogonal(ccw=False)
        assert isinstance(ortho_cw, Vec2)
        assert math.isclose(ortho_cw.x, 0.0, abs_tol=1e-12)
        assert math.isclose(ortho_cw.y, -1.0, abs_tol=1e-12)
        
    def test_det(self):
        """Test determinant calculation for Vec2."""
        v1 = Vec2(3, 4)
        v2 = Vec2(1, 2)
        
        # Determinant: 3*2 - 4*1 = 6 - 4 = 2
        assert math.isclose(v1.det(v2), 2.0, abs_tol=1e-12)
        
        # Determinant is anti-commutative: det(v1, v2) = -det(v2, v1)
        assert math.isclose(v2.det(v1), -2.0, abs_tol=1e-12)
