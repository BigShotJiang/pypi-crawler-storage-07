"""Tests for the ezdxf.tools.complex_ltype module."""
import pytest
from Code.Python.ezdxf.tools.complex_ltype import (
    lin_compiler, ComplexLineTypePart, compile_complex_definition,
    lin_parser, lin_tokenizer, CMD_CODES
)
from ezdxf.lldxf.const import DXFValueError
from ezdxf.lldxf.tags import DXFTag


class TestLinTokenizer:
    """Test cases for lin_tokenizer function."""

    def test_simple_tokenizer(self):
        """Test tokenizing a simple line type definition."""
        definition = "A,.5,-.25,.5,-.25,0,-.25"
        tokens = list(lin_tokenizer(definition))
        
        # Check token count and values
        assert len(tokens) == 7
        assert tokens[0] == "A"
        assert tokens[1] == ".5"
        assert tokens[2] == "-.25"
        assert tokens[3] == ".5"
        assert tokens[4] == "-.25"
        assert tokens[5] == "0"
        assert tokens[6] == "-.25"

    def test_complex_tokenizer_with_text(self):
        """Test tokenizing a complex line type definition with text."""
        definition = 'A,.5,-.2,["GAS",STANDARD,S=.1,U=0.0,X=-0.1,Y=-.05],-.25'
        tokens = list(lin_tokenizer(definition))
        
        # Check token count and values - tokenizer splits at every comma
        assert len(tokens) == 10
        assert tokens[0] == "A"
        assert tokens[1] == ".5"
        assert tokens[2] == "-.2"
        assert tokens[3] == '["GAS"'
        assert tokens[4] == "STANDARD"
        assert tokens[5] == "S=.1"
        assert tokens[6] == "U=0.0"
        assert tokens[7] == "X=-0.1"
        assert tokens[8] == "Y=-.05]"
        assert tokens[9] == "-.25"

    def test_complex_tokenizer_with_shape(self):
        """Test tokenizing a complex line type definition with shape."""
        definition = 'A,.25,-.1,[CIRC1,ltypeshp.shx,x=-.1,s=.1],-.1,1'
        tokens = list(lin_tokenizer(definition))
        
        # Check token count and values - tokenizer splits at every comma
        assert len(tokens) == 9
        assert tokens[0] == "A"
        assert tokens[1] == ".25"
        assert tokens[2] == "-.1"
        assert tokens[3] == '[CIRC1'
        assert tokens[4] == 'ltypeshp.shx'
        assert tokens[5] == 'x=-.1'
        assert tokens[6] == 's=.1]'
        assert tokens[7] == "-.1"
        assert tokens[8] == "1"

    def test_tokenizer_with_quotes(self):
        """Test tokenizing with quoted text."""
        definition = 'A,1.0,["Text with, comma",STANDARD],1.0'
        tokens = list(lin_tokenizer(definition))
        
        # The tokenizer only prevents splitting within quoted text
        assert len(tokens) == 5
        assert tokens[0] == "A"
        assert tokens[1] == "1.0"
        assert tokens[2] == '["Text with, comma"'
        assert tokens[3] == 'STANDARD]'
        assert tokens[4] == "1.0"

    def test_tokenizer_with_unclosed_quotes(self):
        """Test tokenizing with unclosed quotes."""
        definition = 'A,1.0,["Unclosed quote,1.0'
        
        # Should raise DXFValueError for unclosed quotes
        with pytest.raises(DXFValueError):
            list(lin_tokenizer(definition))


class TestLinParser:
    """Test cases for lin_parser function."""

    def test_simple_parser(self):
        """Test parsing a simple line type definition."""
        definition = "A,.5,-.25,.5,-.25,0,-.25"
        tokens = lin_parser(definition)
        
        # Check token count and values
        assert len(tokens) == 7
        assert tokens[0] == "A"
        assert tokens[1] == 0.5
        assert tokens[2] == -0.25
        assert tokens[3] == 0.5
        assert tokens[4] == -0.25
        assert tokens[5] == 0.0
        assert tokens[6] == -0.25

    def test_complex_parser_with_text(self):
        """Test parsing a complex line type definition with text."""
        definition = 'A,.5,-.2,["GAS",STANDARD,S=.1,U=0.0,X=-0.1,Y=-.05],-.25'
        tokens = lin_parser(definition)
        
        # Check token count and values
        assert len(tokens) == 5
        assert tokens[0] == "A"
        assert tokens[1] == 0.5
        assert tokens[2] == -0.2
        
        # Check complex part
        complex_part = tokens[3]
        assert complex_part[0] == "TEXT"
        assert complex_part[1] == "GAS"
        assert complex_part[2] == "STANDARD"
        assert complex_part[3] == "s"
        assert complex_part[4] == 0.1
        assert complex_part[5] == "u"
        assert complex_part[6] == 0.0
        assert complex_part[7] == "x"
        assert complex_part[8] == -0.1
        assert complex_part[9] == "y"
        assert complex_part[10] == -0.05
        
        assert tokens[4] == -0.25

    def test_complex_parser_with_shape(self):
        """Test parsing a complex line type definition with shape."""
        definition = 'A,.25,-.1,[1,ltypeshp.shx,x=-.1,s=.1],-.1,1'
        tokens = lin_parser(definition)
        
        # Check token count and values
        assert len(tokens) == 6
        assert tokens[0] == "A"
        assert tokens[1] == 0.25
        assert tokens[2] == -0.1
        
        # Check complex part
        complex_part = tokens[3]
        assert complex_part[0] == "SHAPE"
        assert complex_part[1] == 1
        assert complex_part[2] == "ltypeshp.shx"
        assert complex_part[3] == "x"
        assert complex_part[4] == -0.1
        assert complex_part[5] == "s"
        assert complex_part[6] == 0.1
        
        assert tokens[4] == -0.1
        assert tokens[5] == 1.0

    def test_parser_with_invalid_shape_index(self):
        """Test parsing with invalid shape index."""
        definition = 'A,.25,-.1,[CIRC1,ltypeshp.shx,x=-.1,s=.1],-.1,1'
        
        # Should raise DXFValueError for invalid shape index
        with pytest.raises(DXFValueError):
            lin_parser(definition)

    def test_parser_with_nested_complex_definition(self):
        """Test parsing with nested complex definition."""
        definition = 'A,.5,-.2,["TEXT",STANDARD],[SHAPE,ltypeshp.shx],-.25'
        
        # Should raise DXFValueError for nested complex definition
        with pytest.raises(DXFValueError):
            lin_parser(definition)


class TestCompileComplexDefinition:
    """Test cases for compile_complex_definition function."""

    def test_compile_text_definition(self):
        """Test compiling a text complex line type definition."""
        tokens = ["TEXT", "GAS", "STANDARD", "s", 0.1, "u", 0.0, "x", -0.1, "y", -0.05]
        part = compile_complex_definition(tokens)
        
        # Check part properties
        assert isinstance(part, ComplexLineTypePart)
        assert part.type == "TEXT"
        assert part.value == "GAS"
        assert part.font == "STANDARD"
        
        # Check tags
        tags = part.tags
        assert len(tags) == 4
        assert tags[0] == DXFTag(46, 0.1)  # scaling factor
        assert tags[1] == DXFTag(50, 0.0)  # rotation angle
        assert tags[2] == DXFTag(44, -0.1)  # shift x
        assert tags[3] == DXFTag(45, -0.05)  # shift y

    def test_compile_shape_definition(self):
        """Test compiling a shape complex line type definition."""
        tokens = ["SHAPE", 1, "ltypeshp.shx", "s", 0.1, "x", -0.1]
        part = compile_complex_definition(tokens)
        
        # Check part properties
        assert isinstance(part, ComplexLineTypePart)
        assert part.type == "SHAPE"
        assert part.value == 1
        assert part.font == "ltypeshp.shx"
        
        # Check tags
        tags = part.tags
        assert len(tags) == 4
        assert tags[0] == DXFTag(46, 0.1)  # scaling factor
        assert tags[1] == DXFTag(50, 0.0)  # rotation angle (default)
        assert tags[2] == DXFTag(44, -0.1)  # shift x
        assert tags[3] == DXFTag(45, 0.0)  # shift y (default)

    def test_compile_with_missing_parameters(self):
        """Test compiling with missing parameters."""
        tokens = ["TEXT", "GAS", "STANDARD"]
        part = compile_complex_definition(tokens)
        
        # Check that default values are used for missing parameters
        tags = part.tags
        assert len(tags) == 4
        assert tags[0] == DXFTag(46, 0.0)  # scaling factor (default)
        assert tags[1] == DXFTag(50, 0.0)  # rotation angle (default)
        assert tags[2] == DXFTag(44, 0.0)  # shift x (default)
        assert tags[3] == DXFTag(45, 0.0)  # shift y (default)


class TestComplexLineTypePart:
    """Test cases for ComplexLineTypePart class."""

    def test_init(self):
        """Test initialization of ComplexLineTypePart."""
        part = ComplexLineTypePart("TEXT", "GAS", "STANDARD")
        
        # Check properties
        assert part.type == "TEXT"
        assert part.value == "GAS"
        assert part.font == "STANDARD"
        assert len(part.tags) == 0

    def test_complex_ltype_tags_text_without_doc(self):
        """Test complex_ltype_tags method for TEXT without document."""
        part = ComplexLineTypePart("TEXT", "GAS", "STANDARD")
        part.tags.append(DXFTag(46, 0.1))  # scaling factor
        part.tags.append(DXFTag(50, 0.0))  # rotation angle
        part.tags.append(DXFTag(44, -0.1))  # shift x
        part.tags.append(DXFTag(45, -0.05))  # shift y
        
        tags = part.complex_ltype_tags(None)
        
        # Check tags
        assert len(tags) == 8
        assert tags[0] == DXFTag(74, 2)  # TEXT type
        assert tags[1] == DXFTag(75, 0)  # TEXT value (always 0)
        assert tags[2] == DXFTag(340, "0")  # Font handle (0 when no doc)
        assert tags[3] == DXFTag(46, 0.1)  # scaling factor
        assert tags[4] == DXFTag(50, 0.0)  # rotation angle
        assert tags[5] == DXFTag(44, -0.1)  # shift x
        assert tags[6] == DXFTag(45, -0.05)  # shift y
        # TEXT value is appended at the end
        assert tags[7] == DXFTag(9, "GAS")

    def test_complex_ltype_tags_shape_without_doc(self):
        """Test complex_ltype_tags method for SHAPE without document."""
        part = ComplexLineTypePart("SHAPE", 1, "ltypeshp.shx")
        part.tags.append(DXFTag(46, 0.1))  # scaling factor
        part.tags.append(DXFTag(50, 0.0))  # rotation angle
        part.tags.append(DXFTag(44, -0.1))  # shift x
        part.tags.append(DXFTag(45, 0.0))  # shift y
        
        tags = part.complex_ltype_tags(None)
        
        # Check tags
        assert len(tags) == 7
        assert tags[0] == DXFTag(74, 4)  # SHAPE type
        assert tags[1] == DXFTag(75, 1)  # SHAPE index
        assert tags[2] == DXFTag(340, "0")  # Font handle (0 when no doc)
        assert tags[3] == DXFTag(46, 0.1)  # scaling factor
        assert tags[4] == DXFTag(50, 0.0)  # rotation angle
        assert tags[5] == DXFTag(44, -0.1)  # shift x
        assert tags[6] == DXFTag(45, 0.0)  # shift y
        # No text value appended for SHAPE


class TestLinCompiler:
    """Test cases for lin_compiler function."""

    def test_simple_compiler(self):
        """Test compiling a simple line type definition."""
        definition = "A,.5,-.25,.5,-.25,0,-.25"
        tags = lin_compiler(definition)
        
        # Check tag count and values
        assert len(tags) == 6
        assert tags[0] == DXFTag(49, 0.5)
        assert tags[1] == DXFTag(49, -0.25)
        assert tags[2] == DXFTag(49, 0.5)
        assert tags[3] == DXFTag(49, -0.25)
        assert tags[4] == DXFTag(49, 0.0)
        assert tags[5] == DXFTag(49, -0.25)

    def test_complex_compiler_with_text(self):
        """Test compiling a complex line type definition with text."""
        definition = 'A,.5,-.2,["GAS",STANDARD,S=.1,U=0.0,X=-0.1,Y=-.05],-.25'
        tags = lin_compiler(definition)
        
        # Check tag count - complex part is included in the tags list
        assert len(tags) == 4
        
        # Check simple dash tags
        assert tags[0] == DXFTag(49, 0.5)
        assert tags[1] == DXFTag(49, -0.2)
        assert tags[3] == DXFTag(49, -0.25)
        
        # Check complex part (should be a ComplexLineTypePart instance)
        complex_part = tags[2]
        assert isinstance(complex_part, ComplexLineTypePart)
        assert complex_part.type == "TEXT"
        assert complex_part.value == "GAS"
        assert complex_part.font == "STANDARD"

    def test_complex_compiler_with_shape(self):
        """Test compiling a complex line type definition with shape."""
        definition = 'A,.25,-.1,[1,ltypeshp.shx,x=-.1,s=.1],-.1,1'
        tags = lin_compiler(definition)
        
        # Check tag count - complex part is included in the tags list
        assert len(tags) == 5
        
        # Check simple dash tags
        assert tags[0] == DXFTag(49, 0.25)
        assert tags[1] == DXFTag(49, -0.1)
        assert tags[3] == DXFTag(49, -0.1)
        assert tags[4] == DXFTag(49, 1.0)
        
        # Check complex part (should be a ComplexLineTypePart instance)
        complex_part = tags[2]
        assert isinstance(complex_part, ComplexLineTypePart)
        assert complex_part.type == "SHAPE"
        assert complex_part.value == 1
        assert complex_part.font == "ltypeshp.shx"


class TestCmdCodes:
    """Test cases for CMD_CODES dictionary."""

    def test_cmd_codes(self):
        """Test CMD_CODES dictionary."""
        # Check that the dictionary contains expected keys and values
        assert "s" in CMD_CODES
        assert "r" in CMD_CODES
        assert "u" in CMD_CODES
        assert "x" in CMD_CODES
        assert "y" in CMD_CODES
        
        assert CMD_CODES["s"] == 46  # scaling factor
        assert CMD_CODES["r"] == 50  # rotation angle
        assert CMD_CODES["u"] == 50  # rotation angle (same as r)
        assert CMD_CODES["x"] == 44  # shift x
        assert CMD_CODES["y"] == 45  # shift y


###############################
# Additional Edge/Error Tests #
###############################

import pytest
from Code.Python.ezdxf.tools.complex_ltype import lin_parser, lin_tokenizer
from ezdxf.lldxf.const import DXFValueError

@pytest.mark.parametrize(
    "definition,expected_exception",
    [
        ("A,1.0,[\"Unclosed quote,1.0", DXFValueError),  # unclosed quote
        ("A,1.0,[SHAPE", DXFValueError),                  # sublist without closing
        ("A,1.0,[SHAPE,notanint]", DXFValueError),        # invalid shape index
        ("A,1.0,[SHAPE,1,x=notafloat]", DXFValueError),   # invalid float in subtoken
        ("A,1.0,[SHAPE,1],[SHAPE,2]", DXFValueError),     # nested sublists (not allowed)
    ]
)
def test_lin_parser_edge_cases(definition, expected_exception):
    with pytest.raises(expected_exception):
        lin_parser(definition)

@pytest.mark.parametrize(
    "definition,expected_exception",
    [
        ("A,1.0,\"Unclosed quote,1.0", DXFValueError),  # unclosed quote in tokenizer
    ]
)
def test_lin_tokenizer_edge_cases(definition, expected_exception):
    with pytest.raises(expected_exception):
        list(lin_tokenizer(definition))
