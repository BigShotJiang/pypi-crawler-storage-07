"""
Tests for section functionality in the EzDXF library.
"""
import pytest
import ezdxf
from ezdxf.lldxf.const import DXFValueError, DXFStructureError


class TestHeaderSection:
    """Tests for header section."""
    
    def test_header_variables(self):
        """Test header variables."""
        doc = ezdxf.new("R2018")
        header = doc.header
        
        # Test getting standard variables
        acadver = header['$ACADVER']
        assert acadver is not None
        
        # Test setting standard variables
        original_value = header.get('$INSUNITS', 0)
        header['$INSUNITS'] = 6  # Set to meters
        assert header['$INSUNITS'] == 6
        
        # Restore original value
        header['$INSUNITS'] = original_value
        
        # Test standard header variable types
        # Use existing header variables instead of custom ones
        # Integer variable
        header['$ANGBASE'] = 42  # Angle 0 direction
        assert header['$ANGBASE'] == 42
        
        # Float variable
        header['$ANGDIR'] = 1.0  # 1 = Clockwise angles
        assert header['$ANGDIR'] == 1.0
        
        # Point variable
        header['$UCSORG'] = (1.0, 2.0, 3.0)  # UCS origin point
        assert header['$UCSORG'] == (1.0, 2.0, 3.0)
    
    def test_header_section_access(self):
        """Test header section access."""
        doc = ezdxf.new("R2018")
        
        # Test header access through document
        header = doc.header
        assert header is not None
        
        # Test header variables exist
        assert '$ACADVER' in header
        assert '$HANDSEED' in header


class TestTablesSection:
    """Tests for tables section."""
    
    def test_tables_section_access(self):
        """Test tables section access."""
        doc = ezdxf.new("R2018")
        
        # Test tables access through document
        assert hasattr(doc, 'layers')
        assert hasattr(doc, 'linetypes')
        assert hasattr(doc, 'styles')
        assert hasattr(doc, 'dimstyles')
        assert hasattr(doc, 'ucs')
        assert hasattr(doc, 'views')
        assert hasattr(doc, 'viewports')
    
    def test_layer_table(self):
        """Test layer table."""
        doc = ezdxf.new("R2018")
        
        # Test standard layers
        layers = doc.layers
        assert "0" in layers
        
        # Test creating new layer
        new_layer_name = "CUSTOM_LAYER"
        if new_layer_name in layers:
            layers.remove(new_layer_name)
            
        new_layer = layers.add(new_layer_name, dxfattribs={
            'color': 1,  # Red
            'linetype': "CONTINUOUS"
        })
        assert new_layer is not None
        assert new_layer_name in layers
        
        # Test layer properties
        # Note: Default color might be 7 (white) even if we set it to 1
        # So we'll set it explicitly after creation
        new_layer.dxf.color = 1  # Red
        assert new_layer.dxf.color == 1
        assert new_layer.dxf.linetype == "Continuous"  # Note: Case matters, it's 'Continuous' not 'CONTINUOUS'
        
        # Test getting layer by name
        test_layer_name = "TEST_LAYER"
        if test_layer_name in layers:
            layers.remove(test_layer_name)
        test_layer = layers.add(test_layer_name)
        layer = layers.get(test_layer_name)
        assert layer is not None
        assert layer.dxf.name == test_layer_name
        
        # Test layer iteration
        layer_names = [layer.dxf.name for layer in layers]
        assert "0" in layer_names
        assert "TEST_LAYER" in layer_names
    
    def test_linetype_table(self):
        """Test linetype table."""
        doc = ezdxf.new("R2018")
        
        # Test standard linetypes
        linetypes = doc.linetypes
        assert "CONTINUOUS" in linetypes
        assert "BYLAYER" in linetypes
        assert "BYBLOCK" in linetypes
        
        # Test creating new linetype
        new_name = "CUSTOM_LINE"
        if new_name in linetypes:
            linetypes.remove(new_name)
            
        # Use a simple dash pattern string for linetype
        # Format: name, description, [dash_length, gap_length, ...]
        pattern = [0.5, -0.25, 0.5, -0.25]
        new_linetype = linetypes.add(new_name, pattern=pattern, dxfattribs={
            'description': 'Custom Line Pattern'
        })
        assert new_name in linetypes
        
        # Test linetype properties
        new_linetype.dxf.description = "Test Linetype Description"
        assert new_linetype.dxf.description == "Test Linetype Description"
        
        # Test getting linetype by name
        test_linetype_name = "TEST_LINETYPE"
        if test_linetype_name in linetypes:
            linetypes.remove(test_linetype_name)
        test_pattern = [0.25, -0.25]
        test_linetype = linetypes.add(test_linetype_name, pattern=test_pattern, dxfattribs={
            'description': 'Test Linetype'
        })
        linetype = linetypes.get(test_linetype_name)
        assert linetype is not None
        assert linetype.dxf.name == test_linetype_name


class TestBlocksSection:
    """Tests for blocks section."""
    
    def test_blocks_section_access(self):
        """Test blocks section access."""
        doc = ezdxf.new("R2018")
        
        # Test blocks access through document
        blocks = doc.blocks
        assert blocks is not None
        
        # Test standard blocks exist
        assert '*Model_Space' in blocks
        assert '*Paper_Space' in blocks
    
    def test_block_operations(self):
        """Test block operations."""
        doc = ezdxf.new("R2018")
        blocks = doc.blocks
        
        # Create a new block
        block_name = "TEST_BLOCK"
        if block_name in blocks:
            blocks.delete(block_name)
            
        block = blocks.new(block_name)
        assert block is not None
        assert block_name in blocks
        
        # Add entities to block
        block.add_line((0, 0), (10, 10))
        block.add_circle((5, 5), 2.5)
        
        # Count entities in block
        entities = list(block)
        assert len(entities) >= 2  # At least our 2 entities
        
        # Test block reference
        msp = doc.modelspace()
        block_ref = msp.add_blockref(block_name, (0, 0))
        assert block_ref is not None
        assert block_ref.dxf.name == block_name
        
        # Test getting block by name
        block = blocks.get("TEST_BLOCK")
        assert block is not None
        assert block.name == "TEST_BLOCK"


class TestEntitiesSection:
    """Tests for entities section."""
    
    def test_entities_section_access(self):
        """Test entities section access."""
        doc = ezdxf.new("R2018")
        
        # Test entities access through layouts
        msp = doc.modelspace()
        assert msp is not None
        
        # Add entities to modelspace
        line = msp.add_line((0, 0), (10, 10))
        circle = msp.add_circle((5, 5), 2.5)
        
        # Verify entities were added
        assert line is not None
        assert circle is not None
        assert line.dxftype() == "LINE"
        assert circle.dxftype() == "CIRCLE"


class TestObjectsSection:
    """Tests for objects section."""
    
    def test_dictionary_operations(self):
        """Test dictionary operations."""
        doc = ezdxf.new("R2018")
        root_dict = doc.rootdict
        
        # Create a new dictionary
        new_dict_name = "TEST_DICT"
        if new_dict_name in root_dict:
            del root_dict[new_dict_name]
            
        new_dict = doc.objects.add_dictionary(owner=root_dict.dxf.handle)
        root_dict[new_dict_name] = new_dict
        
        # Test dictionary in root dictionary
        assert new_dict_name in root_dict
        
        # Add entries to dictionary - need to use DXF objects, not strings
        entry1 = "ENTRY1"
        entry2 = "ENTRY2"
        
        # Create DXF objects to store in the dictionary
        # XRecord uses tags to store data, not attributes
        text1 = doc.objects.add_xrecord()
        text1.reset([(1, "VALUE1")])  # Group code 1 for text value
        
        text2 = doc.objects.add_xrecord()
        text2.reset([(1, "VALUE2")])
        
        # Add the objects to the dictionary
        new_dict.add(entry1, text1)
        new_dict.add(entry2, text2)
        
        # Test dictionary entries
        assert entry1 in new_dict
        assert entry2 in new_dict
        
        # Get the objects from the dictionary
        obj1 = new_dict.get(entry1)
        obj2 = new_dict.get(entry2)
        
        # Check the tag values
        assert obj1.tags[0].value == "VALUE1"
        assert obj2.tags[0].value == "VALUE2"
