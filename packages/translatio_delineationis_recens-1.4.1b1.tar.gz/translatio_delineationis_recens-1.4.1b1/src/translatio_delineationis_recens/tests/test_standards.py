import pytest
import ezdxf
from ezdxf.tools import standards

def test_linetypes_output():
    ltypes = standards.linetypes()
    assert isinstance(ltypes, list)
    assert any(name == "CONTINUOUS" for name, *_ in ltypes)
    assert all(isinstance(pattern, (list, tuple)) for _, _, pattern in ltypes)

def test_styles_output():
    styles = standards.styles()
    assert isinstance(styles, list)
    assert any(name == "STANDARD" for name, *_ in styles)
    assert all(isinstance(font, str) for _, font in styles)

def test_scale_linetype():
    ltypes = standards.linetypes()
    ltype = ltypes[0]
    scaled = standards.scale_linetype(ltype, 2.0)
    assert scaled[0] == ltype[0]
    assert scaled[1] == ltype[1]
    assert all(abs(a * 2.0 - b) < 1e-8 for a, b in zip(ltype[2], scaled[2]))

def test_setup_linetypes_adds_to_doc():
    doc = ezdxf.new("R2018")
    standards.setup_linetypes(doc)
    assert "CONTINUOUS" in doc.linetypes
    assert "CENTER" in doc.linetypes

def test_setup_styles_adds_to_doc():
    doc = ezdxf.new("R2018")
    standards.setup_styles(doc)
    assert "OpenSans" in doc.styles
    assert "STANDARD" in doc.styles

def test_setup_drawing_all_topics():
    doc = ezdxf.new("R2018")
    standards.setup_drawing(doc, topics="all")
    # Should add linetypes, styles, and visualstyles
    assert "CONTINUOUS" in doc.linetypes
    assert "OpenSans" in doc.styles

def test_setup_dimstyles_adds_to_doc():
    doc = ezdxf.new("R2018")
    standards.setup_dimstyles(doc)
    # Should add EZDXF dimstyle
    assert "EZDXF" in doc.dimstyles
    assert doc.header["$DIMSTYLE"] == "EZDXF"

def test_setup_dimstyle_custom_name():
    doc = ezdxf.new("R2018")
    ds = standards.setup_dimstyle(doc, fmt="EZ_M_100_H25_CM", name="CUSTOM")
    assert "CUSTOM" in doc.dimstyles
    assert ds.dxf.name == "CUSTOM"

def test_constants_exist():
    assert hasattr(standards, "ISO_LTYPE_FACTOR")
    assert hasattr(standards, "ANSI_LINE_TYPES")
    assert isinstance(standards.ANSI_LINE_TYPES, list)
    assert standards.ISO_LTYPE_FACTOR > 0

def test_setup_drawing_topics_tuple():
    doc = ezdxf.new("R2018")
    standards.setup_drawing(doc, topics=("linetypes", "styles"))
    assert "CONTINUOUS" in doc.linetypes
    assert "OpenSans" in doc.styles

def test_setup_drawing_empty_topics():
    doc = ezdxf.new("R2018")
    default_linetypes = set(list(doc.linetypes))
    default_styles = set(list(doc.styles))
    standards.setup_drawing(doc, topics=None)
    # Should not add anything
    assert set(list(doc.linetypes)) == default_linetypes
    assert set(list(doc.styles)) == default_styles

def test_setup_linetypes_idempotent():
    doc = ezdxf.new("R2018")
    standards.setup_linetypes(doc)
    count = len(doc.linetypes)
    standards.setup_linetypes(doc)
    assert len(doc.linetypes) == count  # No duplicates
