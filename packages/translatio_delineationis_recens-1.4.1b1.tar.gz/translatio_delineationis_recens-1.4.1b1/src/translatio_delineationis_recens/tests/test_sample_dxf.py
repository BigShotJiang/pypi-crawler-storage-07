"""Test script to create and inspect a sample DXF file."""
import os
import tempfile
import ezdxf

# Create a sample DXF file
def create_sample_dxf():
    doc = ezdxf.new('R2010')  # Create a new DXF document
    msp = doc.modelspace()  # Get the modelspace
    
    # Add a point
    msp.add_point((1.0, 2.0), dxfattribs={"layer": "TestLayer"})
    
    # Add a line
    msp.add_line((0.0, 0.0), (1.0, 1.0), dxfattribs={"layer": "TestLayer"})
    
    # Add an LWPOLYLINE (rectangle)
    points = [(0, 0), (1, 0), (1, 1), (0, 1)]
    msp.add_lwpolyline(points, close=True, dxfattribs={"layer": "TestLayer"})
    
    # Save to a temporary file
    temp_dir = tempfile.gettempdir()
    filepath = os.path.join(temp_dir, "test_sample.dxf")
    doc.saveas(filepath)
    print(f"Created sample DXF file: {filepath}")
    return filepath

if __name__ == "__main__":
    sample_file = create_sample_dxf()
    print(f"Sample DXF file created at: {sample_file}")
    
    # Now inspect it
    print("\nInspecting the sample DXF file...")
    from Code.Python import inspect_dxf
    inspect_dxf.inspect_dxf(sample_file)
