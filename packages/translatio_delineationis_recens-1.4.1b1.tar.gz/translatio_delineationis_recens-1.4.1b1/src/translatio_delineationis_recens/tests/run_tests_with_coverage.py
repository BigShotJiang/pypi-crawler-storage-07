"""
Run tests with coverage reporting for the EzDXF library.
"""
import os
import sys
import subprocess
from pathlib import Path

def main():
    """Run the tests with coverage reporting."""
    # Get the project root directory
    project_root = Path(__file__).parent
    
    # Ensure we're using the WinPython installation as specified in the project requirements
    python_exe = Path(r"C:\Program Files\WinPython\python\python.exe")
    if not python_exe.exists():
        print(f"Error: WinPython installation not found at {python_exe}")
        print("Please ensure WinPython is installed at the correct location.")
        return 1
    
    # Set up the command to run pytest with coverage
    cmd = [
        str(python_exe),
        "-m", "pytest",
        "--cov=ezdxf",
        "--cov-report=term",
        "--cov-report=html:coverage_report",
        "--cov-report=xml:coverage.xml",
    ]
    
    # Add optional arguments
    if len(sys.argv) > 1:
        cmd.extend(sys.argv[1:])
    
    # Run the tests
    print(f"Running tests with command: {' '.join(cmd)}")
    result = subprocess.run(cmd, cwd=str(project_root))
    
    # Print information about the coverage report
    if result.returncode == 0:
        coverage_report = project_root / "coverage_report" / "index.html"
        print("\nTests completed successfully!")
        print(f"Coverage report generated at: {coverage_report}")
        print("Open this file in a web browser to view the detailed coverage report.")
    else:
        print("\nTests failed with return code:", result.returncode)
    
    return result.returncode

if __name__ == "__main__":
    sys.exit(main())
