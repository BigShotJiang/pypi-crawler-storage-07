import os
import tempfile
import shutil
import pytest
import io
from ezdxf.tools.strip import TagWriter, ThumbnailRemover, strip_tags, safe_rename, strip, DEFAULT_CODES
from pathlib import Path

def minimal_dxf_bytes(with_comment=True, with_thumbnail=False):
    # Minimal valid DXF as bytes, optionally with a comment (999) and thumbnail section
    parts = [
        b"0\nSECTION\n2\nHEADER\n0\nENDSEC\n"
    ]
    if with_comment:
        parts.append(b"999\nThis is a comment\n")
    if with_thumbnail:
        parts.append(
            b"0\nSECTION\n2\nTHUMBNAILIMAGE\n999\nThumb\n0\nENDSEC\n"
        )
    parts.append(b"0\nEOF\n")
    return b"".join(parts)

def test_tagwriter_and_thumbnailremover():
    # TagWriter writes bytes as-is
    out = io.BytesIO()
    writer = TagWriter(fp=out)
    writer.write(b"10\n", b"20\n")
    assert out.getvalue() == b"10\n20\n"
    # ThumbnailRemover skips THUMBNAILIMAGE section
    out2 = io.BytesIO()
    remover = ThumbnailRemover(fp=out2)
    # Write a thumbnail section
    remover.write(b"0\n", b"SECTION\n")
    remover.write(b"2\n", b"THUMBNAILIMAGE\n")
    remover.write(b"999\n", b"Thumb\n")
    remover.write(b"0\n", b"ENDSEC\n")
    # Write a normal section
    remover.write(b"0\n", b"SECTION\n")
    remover.write(b"2\n", b"HEADER\n")
    remover.write(b"0\n", b"ENDSEC\n")
    # Only the HEADER section should be written
    out2val = out2.getvalue()
    assert b"THUMBNAILIMAGE" not in out2val
    assert b"HEADER" in out2val
    assert remover.removed_thumbnail_image

def test_strip_tags_removes_999():
    # Remove code 999 (comment) from DXF
    dxf_bytes = minimal_dxf_bytes(with_comment=True)
    infile = tempfile.TemporaryFile()
    infile.write(dxf_bytes)
    infile.seek(0)
    out = io.BytesIO()
    writer = TagWriter(fp=out)
    removed = strip_tags(infile, writer, codes=(999,))
    assert removed == 1
    outval = out.getvalue()
    assert b"999" not in outval
    infile.close()

def test_strip_tags_keeps_non999():
    # Do not remove code 0
    dxf_bytes = minimal_dxf_bytes(with_comment=False)
    infile = tempfile.TemporaryFile()
    infile.write(dxf_bytes)
    infile.seek(0)
    out = io.BytesIO()
    writer = TagWriter(fp=out)
    removed = strip_tags(infile, writer, codes=(999,))
    assert removed == 0
    outval = out.getvalue()
    assert b"SECTION" in outval
    infile.close()

def test_safe_rename(tmp_path):
    src = tmp_path / "testsrc.dxf"
    tgt = tmp_path / "testtgt.dxf"
    bak = tmp_path / "testtgt.bak"
    src.write_text("A")
    tgt.write_text("B")
    result = safe_rename(src, tgt, backup=True, verbose=False)
    assert result
    assert tgt.read_text() == "A"
    assert bak.exists()

def test_strip_removes_comment_and_thumbnail(tmp_path):
    # Write a DXF file with a comment and thumbnail
    dxf_path = tmp_path / "testfile.dxf"
    dxf_path.write_bytes(minimal_dxf_bytes(with_comment=True, with_thumbnail=True))
    # Run strip to remove comment and thumbnail
    strip(str(dxf_path), backup=False, thumbnail=True, verbose=False, codes=(999,))
    # Check that the file no longer contains comment or thumbnail section
    data = dxf_path.read_bytes()
    assert b"THUMBNAILIMAGE" not in data
    assert b"This is a comment" not in data
    assert b"HEADER" in data

def test_default_codes():
    assert DEFAULT_CODES == (999,)
