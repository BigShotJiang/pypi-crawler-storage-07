import pytest
from unittest import mock
from ezdxf.layouts import Layout, Paperspace
from ezdxf import zoom
from ezdxf.math import Vec2

class DummyLayout:
    def __init__(self, is_modelspace=False, is_any_paperspace=False):
        self.is_modelspace = is_modelspace
        self.is_any_paperspace = is_any_paperspace
        self.doc = mock.Mock()
        self.layout_key = "ABC"
    
class DummyPaperspace:
    is_modelspace = False
    is_any_paperspace = True
    def __init__(self):
        self.reset_main_viewport_called = False
        self.doc = mock.Mock()
        self.layout_key = "ABC"
    def reset_main_viewport(self, center, size):
        self.reset_main_viewport_called = True
        self.last_center = center
        self.last_size = size
    def main_viewport(self):
        return None

def test_center_modelspace_calls_set_modelspace_vport():
    layout = DummyLayout(is_modelspace=True)
    point = Vec2(10, 20)
    size = Vec2(100, 50)
    zoom.center(layout, point, size)
    layout.doc.set_modelspace_vport.assert_called_once()

def test_center_paperspace_calls_reset_main_viewport():
    layout = DummyPaperspace()
    point = Vec2(5, 6)
    size = Vec2(20, 10)
    zoom.center(layout, point, size)
    assert layout.reset_main_viewport_called
    assert layout.last_center == point
    assert layout.last_size == size

def test_center_unsupported_layout_type_raises():
    layout = DummyLayout()
    layout.is_modelspace = False
    layout.is_any_paperspace = False
    with pytest.raises(TypeError):
        zoom.center(layout, Vec2(1, 1), Vec2(2, 2))

def test_guess_height():
    size = Vec2(100, 20)
    assert zoom.guess_height(size) == 50
    size = Vec2(10, 60)
    assert zoom.guess_height(size) == 60

def test_zoom_to_entities_calls_center(monkeypatch):
    layout = DummyLayout(is_modelspace=True)
    dummy_bbox = mock.Mock()
    dummy_bbox.has_data = True
    dummy_bbox.center = Vec2(1, 2)
    dummy_bbox.size = Vec2(3, 4)
    monkeypatch.setattr(zoom.bbox, "extents", lambda entities, fast=True: dummy_bbox)
    called = {}
    def fake_center(layout_obj, center, size):
        called["center"] = (center, size)
    monkeypatch.setattr(zoom, "center", fake_center)
    zoom.zoom_to_entities(layout, [mock.Mock()], 2)
    assert called["center"] == (Vec2(1, 2), Vec2(3, 4) * 2)

def test_objects_filters_entities(monkeypatch):
    layout = DummyLayout()
    entity1 = mock.Mock()
    entity1.dxf.owner = layout.layout_key
    entity2 = mock.Mock()
    entity2.dxf.owner = "XYZ"
    called = {}
    monkeypatch.setattr(zoom, "zoom_to_entities", lambda l, ents, factor: called.setdefault("ents", list(ents)))
    zoom.objects(layout, [entity1, entity2], 1)
    assert called["ents"] == [entity1]

def test_extents_calls_zoom_to_entities(monkeypatch):
    layout = DummyLayout()
    called = {}
    monkeypatch.setattr(zoom, "zoom_to_entities", lambda l, ents, factor: called.setdefault("called", True))
    zoom.extents(layout, 1)
    assert called["called"]

def test_window_calls_center(monkeypatch):
    layout = DummyLayout()
    called = {}
    monkeypatch.setattr(zoom, "center", lambda l, center, size: called.setdefault("center", (center, size)))
    p1 = Vec2(0, 0)
    p2 = Vec2(10, 10)
    zoom.window(layout, p1, p2)
    assert "center" in called
