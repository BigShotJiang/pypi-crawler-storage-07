"""
Tests for rendering functionality in the EzDXF library.
"""
import pytest
import math
from pathlib import Path as FilePath
import logging

logging.basicConfig(level=logging.DEBUG)

import ezdxf
from ezdxf.render import forms, mesh
from ezdxf.path.path import Path
from ezdxf.math import Vec3, UCS, Matrix44


class TestBasicForms:
    """Tests for basic geometric forms rendering."""
    
    @pytest.mark.parametrize("count, radius, height", [
        (0, 2.5, 10.0),    # Zero segments
        (16, -2.5, 10.0),  # Negative radius
        (16, 2.5, -10.0),  # Negative height
    ])
    def test_render_cylinder_invalid(self, count, radius, height):
        with pytest.raises(Exception):
            forms.cylinder(count=count, radius=radius, top_center=(0, 0, height))

    def test_render_cylinder(self):
        """Test rendering a cylinder."""
        # Create a cylinder
        count = 16  # Number of faces
        radius = 2.5
        height = 10.0
        cylinder = forms.cylinder(count=count, radius=radius, top_center=(0, 0, height))
        
        # Test cylinder properties
        assert isinstance(cylinder, mesh.MeshBuilder)
        assert len(cylinder.vertices) > 0
        assert len(cylinder.faces) > 0
        
        # Verify cylinder dimensions
        vertices = list(cylinder.vertices)
        
        # Check that vertices are within expected bounds
        for vertex in vertices:
            x, y, z = vertex
            # For side vertices, check they're on a circle of radius
            if z == 0.0:  # Bottom vertices
                radius_val = math.sqrt(x*x + y*y)
                assert math.isclose(radius_val, radius, rel_tol=1e-3)
            
            # Check z-coordinate is within bounds
            assert 0 <= z <= height
    
    @pytest.mark.parametrize("count, radius, height", [
        (0, 2.5, 10.0),    # Zero segments
        (16, -2.5, 10.0),  # Negative radius
        (16, 2.5, -10.0),  # Negative height
    ])
    def test_render_cone_invalid(self, count, radius, height):
        with pytest.raises(Exception):
            forms.cone(count=count, radius=radius, apex=(0, 0, height))

    def test_render_cone(self):
        """Test rendering a cone."""
        # Create a cone
        count = 16  # Number of faces
        radius = 2.5
        height = 10.0
        cone = forms.cone(count=count, radius=radius, apex=(0, 0, height))
        
        # Test cone properties
        assert isinstance(cone, mesh.MeshBuilder)
        assert len(cone.vertices) > 0
        assert len(cone.faces) > 0
        
        # Verify cone dimensions
        vertices = list(cone.vertices)
        
        # Find apex position (highest z-value)
        apex = max(vertices, key=lambda v: v[2])
        assert math.isclose(apex[2], height, rel_tol=1e-3)
        
        # Check base vertices
        base_vertices = [v for v in vertices if math.isclose(v[2], 0.0, abs_tol=1e-3)]
        for v in base_vertices:
            x, y, z = v
            # Base vertices should be on a circle of radius
            radius_val = math.sqrt(x*x + y*y)
            assert math.isclose(radius_val, radius, rel_tol=1e-3)
            assert math.isclose(z, 0.0, abs_tol=1e-3)
    
    @pytest.mark.parametrize("count, radius", [
        (0, 2.5),    # Zero segments
        (16, -2.5),  # Negative radius
    ])
    def test_render_sphere_invalid(self, count, radius):
        with pytest.raises(Exception):
            forms.sphere(count=count, radius=radius)

    def test_render_sphere(self):
        """Test rendering a sphere."""
        # Create a sphere
        count = 16  # Number of segments
        radius = 2.5
        sphere = forms.sphere(count=count, radius=radius)
        
        # Test sphere properties
        assert isinstance(sphere, mesh.MeshBuilder)
        assert len(sphere.vertices) > 0
        assert len(sphere.faces) > 0
        
        # Verify sphere dimensions
        vertices = list(sphere.vertices)
        
        # Check that all vertices are at distance radius from center
        for vertex in vertices:
            distance = math.sqrt(vertex[0]**2 + vertex[1]**2 + vertex[2]**2)
            assert math.isclose(distance, radius, rel_tol=1e-9)


class TestMeshOperations:
    def test_mesh_empty(self):
        mb = mesh.MeshBuilder()
        assert len(mb.vertices) == 0
        assert len(mb.faces) == 0
        # Exporting empty mesh should raise or return None
        with pytest.raises(Exception):
            mb.render_mesh(None)

    """Tests for mesh operations."""
    
    def test_mesh_creation(self):
        """Test mesh creation."""
        # Create a mesh builder
        mesh_builder = mesh.MeshBuilder()
        
        # Add vertices
        mesh_builder.vertices.append((0, 0, 0))
        mesh_builder.vertices.append((1, 0, 0))
        mesh_builder.vertices.append((1, 1, 0))
        mesh_builder.vertices.append((0, 1, 0))
        
        # Add face
        mesh_builder.faces.append([0, 1, 2, 3])
        
        # Test mesh properties
        assert len(mesh_builder.vertices) == 4
        assert len(mesh_builder.faces) == 1
        
        # Verify vertices
        vertices = list(mesh_builder.vertices)
        assert vertices[0] == (0, 0, 0)
        assert vertices[1] == (1, 0, 0)
        assert vertices[2] == (1, 1, 0)
        assert vertices[3] == (0, 1, 0)
        
        # Verify faces
        faces = list(mesh_builder.faces)
        assert faces[0] == [0, 1, 2, 3]
    
    def test_mesh_transformation(self):
        """Test mesh transformation."""
        # Create a mesh box using extrude
        base = forms.box(sx=1.0, sy=1.0, center=True)
        # Create a path for extrusion (from 0,0,0 to 0,0,1.0)
        path = [(0, 0, 0), (0, 0, 1.0)]
        cube = forms.extrude(base, path)
        
        # Create transformation matrix
        m = Matrix44.translate(0.5, 0.5, 0.5)
        
        # Transform the mesh
        cube.transform(m)
        
        # Test transformation
        min_x = min(v[0] for v in cube.vertices)
        min_y = min(v[1] for v in cube.vertices)
        min_z = min(v[2] for v in cube.vertices)
        
        # Since we're using a centered box (-0.5,-0.5,0) to (0.5,0.5,0)
        # and translating by (0.5,0.5,0.5), the min should be (0,0,0.5)
        assert pytest.approx(min_x) == 0.0
        assert pytest.approx(min_y) == 0.0
        assert pytest.approx(min_z) == 0.5
    
    def test_mesh_export_to_entities(self):
        """Test exporting mesh to entities."""
        doc = ezdxf.new("R2018")
        msp = doc.modelspace()
        
        # Create a mesh box using extrude
        base = forms.box(sx=1.0, sy=1.0, center=True)
        # Create a path for extrusion (from 0,0,0 to 0,0,1.0)
        path = [(0, 0, 0), (0, 0, 1.0)]
        cube = forms.extrude(base, path)
        
        # Export to MESH entity
        mesh_entity = cube.render_mesh(msp)
        
        # Test entity
        assert mesh_entity is not None
        assert mesh_entity.dxftype() == "MESH"


class TestPathOperations:
    def test_path_empty(self):
        p = Path()
        assert len(p) == 0
        with pytest.raises(Exception):
            _ = p.bbox()

    """Tests for path operations."""
    
    def test_path_creation(self):
        """Test creating and manipulating a path."""
        # Create a path
        p = Path()
        
        # Add line segments
        p.move_to((0, 0))
        p.line_to((1, 0))
        p.line_to((1, 1))
        p.line_to((0, 1))
        p.close()
        
        # Verify path has segments
        assert len(p) > 0
        
        # Verify path bounding box
        bbox = p.bbox()
        assert bbox.extmin == (0, 0)
        assert bbox.extmax == (1, 1)
    
    def test_path_with_curves(self):
        """Test path with curve segments."""
        # Create a path
        p = Path()
        
        # Add a line and a curve
        p.move_to((0, 0))
        p.line_to((1, 0))
        # Use simpler path operations for testing
        p.line_to((2, 1))
        p.line_to((3, 0))
        
        # Verify path has segments
        assert len(p) > 0
        
        # Verify path has points
        assert len(p.control_vertices()) > 3
        # Calculate approximate length manually
        points = p.control_vertices()
        length = sum(points[i].distance(points[i+1]) for i in range(len(points)-1))
        assert length > 3.0  # Length should be greater than straight line distance
    
    def test_path_transformation(self):
        """Test path transformation."""
        # Create a path (square)
        p = Path()
        p.move_to((0, 0))
        p.line_to((1, 0))
        p.line_to((1, 1))
        p.line_to((0, 1))
        p.close()
        
        # Transform path (scale by 2)
        p = p.transform(Matrix44.scale(2, 2, 1))
        
        # Verify transformed path
        bbox = p.bbox()
        assert bbox.extmin == (0, 0)
        assert bbox.extmax == (2, 2)
    
    def test_path_export_to_entities(self):
        """Test exporting path to entities."""
        # Create a document
        doc = ezdxf.new("R2018")
        msp = doc.modelspace()
        
        # Create a path (triangle)
        p = Path()
        p.move_to((0, 0))
        p.line_to((1, 0))
        p.line_to((0.5, 0.866))
        p.close()
        
        # Export path to LINE entities
        # Create lines manually since render_as_lines might not exist
        points = p.control_vertices()
        lines = []
        for i in range(len(points) - 1):
            lines.append(msp.add_line(points[i], points[i+1]))
        
        # Verify lines were created
        assert len(lines) > 0
        assert all(line.dxftype() == 'LINE' for line in lines)


class TestRenderIntegration:
    def test_render_invalid_mesh_to_document(self):
        doc = ezdxf.new("R2018")
        msp = doc.modelspace()
        mb = mesh.MeshBuilder()
        # Attempt to render empty mesh
        with pytest.raises(Exception):
            mb.render_mesh(msp)

    """Tests for integration of rendering with DXF documents."""
    
    def test_render_to_document(self):
        """Test rendering forms to a DXF document."""
        # Create a document
        doc = ezdxf.new("R2018")
        msp = doc.modelspace()
        
        # Render a box using extrude
        base = forms.box(sx=2, sy=3, center=True)
        # Create a path for extrusion (from 0,0,0 to 0,0,4.0)
        path = [(0, 0, 0), (0, 0, 4.0)]
        box = forms.extrude(base, path)
        box_mesh = box.render_mesh(msp)
        
        # Verify box mesh was created
        assert box_mesh is not None
        assert box_mesh.dxftype() == 'MESH'
        
        # Render a cylinder
        cylinder = forms.cylinder(count=16)
        cylinder_mesh = cylinder.render_mesh(msp)
        
        # Verify cylinder mesh was created
        assert cylinder_mesh is not None
        assert cylinder_mesh.dxftype() == 'MESH'
    
    def test_render_to_polyline(self):
        """Test rendering to polyline entities."""
        # Create a document
        doc = ezdxf.new("R2018")
        msp = doc.modelspace()
        
        # Create a simple polygon path instead of circle
        p = Path()
        p.move_to((0, 0))
        p.line_to((1, 0))
        p.line_to((1, 1))
        p.line_to((0, 1))
        p.close()
        
        # Get the points from the path
        points = p.control_vertices()
        
        # Create a polyline manually
        polyline = msp.add_lwpolyline(points[:-1], close=True)
        
        # Verify polyline was created
        assert polyline.dxftype() == 'LWPOLYLINE'
        assert len(polyline) == 4  # 4 vertices
