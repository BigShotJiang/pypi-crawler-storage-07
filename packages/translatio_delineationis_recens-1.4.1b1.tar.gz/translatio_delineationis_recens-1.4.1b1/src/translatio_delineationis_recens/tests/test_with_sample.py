"""Test the DXF to GeoJSON conversion with a sample DXF file."""
import os
import sys
import tempfile
import json
import ezdxf

# Print ezdxf version for debugging
print(f"Using ezdxf version: {ezdxf.__version__}")

# Add the current directory to the path so we can import our module
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from dxf_to_geojson.model import DxfToGeoJSONModel
except ImportError as e:
    print(f"Error importing DxfToGeoJSONModel: {e}")
    print("Current sys.path:", sys.path)
    raise

def create_sample_dxf():
    """Create a sample DXF file for testing."""
    try:
        print("Creating a new DXF document...")
        
        # Use R12 format for maximum compatibility with older ezdxf versions
        doc = ezdxf.new('R12')
        print(f"Created DXF document with version: {doc.acad_release}")
        
        # Get the modelspace
        msp = doc.modelspace()
        print("Retrieved modelspace")
        
        print("\nAdding entities to modelspace...")
        
        # Add a point (using basic entities for R12 compatibility)
        print("Adding point...")
        point = msp.add_point((1.0, 2.0), dxfattribs={"layer": "TestLayer"})
        print(f"Added point: {point}")
        print(f"Point details: layer={point.dxf.layer}, location={point.dxf.location}")
        
        # Add a line
        print("\nAdding line...")
        line = msp.add_line((0.0, 0.0), (1.0, 1.0), dxfattribs={"layer": "TestLayer"})
        print(f"Added line: {line}")
        print(f"Line details: layer={line.dxf.layer}, start={line.dxf.start}, end={line.dxf.end}")
        
        # Add a POLYLINE (instead of LWPOLYLINE for R12 compatibility)
        print("\nAdding POLYLINE (rectangle)...")
        points = [(0, 0), (1, 0), (1, 1), (0, 1), (0, 0)]
        polyline = msp.add_polyline2d(points, dxfattribs={"layer": "TestLayer"})
        print(f"Added POLYLINE: {polyline}")
        
        # Add a circle
        print("\nAdding circle...")
        circle = msp.add_circle(center=(3.0, 3.0), radius=2.0, dxfattribs={"layer": "TestLayer"})
        print(f"Added circle: {circle}")
        print(f"Circle details: center={circle.dxf.center}, radius={circle.dxf.radius}")
        
        # Add an arc
        print("\nAdding arc...")
        arc = msp.add_arc(center=(-3.0, -3.0), radius=1.5, start_angle=30, end_angle=150, 
                         dxfattribs={"layer": "TestLayer"})
        print(f"Added arc: {arc}")
        print(f"Arc details: center={arc.dxf.center}, radius={arc.dxf.radius}, "
              f"start_angle={arc.dxf.start_angle}, end_angle={arc.dxf.end_angle}")
        
        # Verify entities were added
        print("\nVerifying entities in modelspace...")
        msp_entities = list(msp)
        print(f"Found {len(msp_entities)} entities in modelspace")
        
        for i, entity in enumerate(msp_entities, 1):
            print(f"  {i}. {entity.dxftype()} (handle: {entity.dxf.handle}, layer: {entity.dxf.layer})")
        
        # Also check all entities in the document
        print("\nAll entities in document:")
        all_entities = list(doc.entities)
        print(f"Found {len(all_entities)} total entities in document")
        
        # Save to a temporary file
        temp_dir = tempfile.gettempdir()
        filepath = os.path.join(temp_dir, "test_sample_r12.dxf")
        print(f"\nSaving DXF file to: {filepath}")
        
        # Save with specific options for maximum compatibility
        doc.saveas(filepath, encoding='utf-8')
        
        # Verify the file was created
        if os.path.exists(filepath):
            print(f"DXF file created successfully: {os.path.getsize(filepath)} bytes")
            
            # Print first few lines of the file for debugging
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    print("\nFirst 10 lines of DXF file:")
                    for i, line in enumerate(f):
                        if i < 10:
                            print(f"  {i+1}: {line.strip()}")
                        else:
                            break
            except Exception as e:
                print(f"Error reading DXF file: {e}")
        else:
            print("ERROR: DXF file was not created!")
        
        return filepath
    except Exception as e:
        print(f"Error creating sample DXF: {e}")
        import traceback
        traceback.print_exc()
        raise

def test_conversion():
    """Test DXF to GeoJSON conversion with a sample DXF file."""
    try:
        print("\n=== Starting DXF to GeoJSON Conversion Test ===")
        
        # Create a sample DXF file
        print("\n1. Creating sample DXF file...")
        dxf_file = create_sample_dxf()
        print(f"   - Created sample DXF file: {dxf_file}")
        
        # Verify the DXF file exists and has content
        assert os.path.exists(dxf_file), f"DXF file was not created at {dxf_file}"
        assert os.path.getsize(dxf_file) > 0, f"DXF file is empty: {dxf_file}"
        print(f"   - DXF file size: {os.path.getsize(dxf_file)} bytes")
        
        # Initialize the converter
        print("\n2. Initializing DXF to GeoJSON converter...")
        converter = DxfToGeoJSONModel()
        
        # Test loading the DXF file
        print("\n3. Loading DXF file...")
        load_success = converter.load_dxf(dxf_file)
        assert load_success is True, "Failed to load DXF file"
        print("   - Successfully loaded DXF file")
        
        # Test conversion to GeoJSON
        print("\n4. Converting DXF to GeoJSON...")
        convert_success = converter.convert_to_geojson()
        assert convert_success is True, "Failed to convert to GeoJSON"
        print("   - Successfully converted DXF to GeoJSON")
        
        # Check the number of features
        num_features = len(converter.geojson_data["features"])
        print(f"   - Converted {num_features} features to GeoJSON")
        
        # Print feature summary
        if num_features > 0:
            print("\n   Feature summary:")
            for i, feature in enumerate(converter.geojson_data["features"], 1):
                props = feature.get("properties", {})
                print(f"   {i}. Type: {feature['geometry']['type']}, "
                      f"Layer: {props.get('layer', 'N/A')}, "
                      f"Entity: {props.get('entity_type', 'N/A')}")
        
        # Save the GeoJSON to a file
        json_file = dxf_file.replace('.dxf', '.geojson')
        print(f"\n5. Saving GeoJSON to {json_file}...")
        save_success = converter.save_geojson(json_file)
        assert save_success is True, "Failed to save GeoJSON file"
        
        # Verify the output file exists and has content
        assert os.path.exists(json_file), f"GeoJSON file was not created at {json_file}"
        file_size = os.path.getsize(json_file)
        assert file_size > 0, f"GeoJSON file is empty: {json_file}"
        print(f"   - Successfully saved {file_size} bytes to {json_file}")
        
        # Check if any features were converted
        if not converter.geojson_data or not os.path.exists(json_file):
            print("Error: No GeoJSON file was created or conversion failed")
            return False
        
        # Load and check the GeoJSON
        with open(json_file, 'r') as f:
            geojson_data = json.load(f)
        
        # Print summary of converted features
        print("\n=== Conversion Results ===")
        print(f"Converted {len(geojson_data['features'])} features")
        
        # Count feature types
        feature_types = {}
        for feature in geojson_data['features']:
            geom_type = feature['geometry']['type']
            entity_type = feature['properties'].get('entity_type', 'UNKNOWN')
            key = f"{entity_type} ({geom_type})"
            feature_types[key] = feature_types.get(key, 0) + 1
        
        print("\nFeature types converted:")
        for ftype, count in feature_types.items():
            print(f"  - {ftype}: {count}")
        
        # Verify all expected entity types were converted
        expected_entities = ['POINT', 'LINE', 'POLYLINE', 'CIRCLE', 'ARC']
        converted_entities = [f['properties']['entity_type'] for f in geojson_data['features']]
        
        missing = set(expected_entities) - set(converted_entities)
        if missing:
            print(f"\nWARNING: Some expected entity types were not converted: {', '.join(missing)}")
        else:
            print("\nAll expected entity types were successfully converted!")
        
        # Print a preview of the GeoJSON
        print("\n=== Test passed successfully! ===")
        print("\nGeoJSON preview (first 200 chars):")
        with open(json_file, 'r') as f:
            print(f.read(200) + ("..." if file_size > 200 else ""))
            
        return True
        
    except AssertionError as ae:
        print(f"\n!!! TEST FAILED: {str(ae)}")
        raise
    except Exception as e:
        print(f"\n!!! UNEXPECTED ERROR: {str(e)}")
        import traceback
        traceback.print_exc()
        raise

def test_circle_conversion():
    """Test specific circle conversion."""
    from dxf_to_geojson.model import DxfToGeoJSONModel
    import ezdxf
    
    # Create a minimal DXF with just a circle
    doc = ezdxf.new('R12')
    msp = doc.modelspace()
    msp.add_circle(center=(0, 0), radius=5.0)
    
    # Save to temp file
    import tempfile
    with tempfile.NamedTemporaryFile(suffix='.dxf', delete=False) as tmp:
        doc.saveas(tmp.name)
        dxf_path = tmp.name
    
    try:
        # Convert to GeoJSON
        model = DxfToGeoJSONModel()
        model.load_dxf(dxf_path)
        model.convert_to_geojson()
        
        # Check results
        features = model.geojson_data['features']
        assert len(features) == 1, "Should have exactly one feature"
        
        circle_feature = features[0]
        assert circle_feature['geometry']['type'] == 'Point', "Circle should be a Point feature"
        assert circle_feature['properties']['entity_type'] == 'CIRCLE', "Should be a CIRCLE entity"
        assert circle_feature['properties']['radius'] == 5.0, "Radius should be 5.0"
        
        print("\nCircle conversion test passed!")
        return True
    finally:
        import os
        if os.path.exists(dxf_path):
            os.unlink(dxf_path)

def test_arc_conversion():
    """Test specific arc conversion."""
    from dxf_to_geojson.model import DxfToGeoJSONModel
    import ezdxf
    
    # Create a minimal DXF with just an arc
    doc = ezdxf.new('R12')
    msp = doc.modelspace()
    msp.add_arc(center=(0, 0), radius=3.0, start_angle=0, end_angle=90)
    
    # Save to temp file
    import tempfile
    with tempfile.NamedTemporaryFile(suffix='.dxf', delete=False) as tmp:
        doc.saveas(tmp.name)
        dxf_path = tmp.name
    
    try:
        # Convert to GeoJSON
        model = DxfToGeoJSONModel()
        model.load_dxf(dxf_path)
        model.convert_to_geojson()
        
        # Check results
        features = model.geojson_data['features']
        assert len(features) == 1, "Should have exactly one feature"
        
        arc_feature = features[0]
        assert arc_feature['geometry']['type'] == 'LineString', "Arc should be a LineString feature"
        assert arc_feature['properties']['entity_type'] == 'ARC', "Should be an ARC entity"
        assert arc_feature['properties']['radius'] == 3.0, "Radius should be 3.0"
        assert len(arc_feature['geometry']['coordinates']) > 2, "Arc should have multiple points"
        
        print("\nArc conversion test passed!")
        return True
    finally:
        import os
        if os.path.exists(dxf_path):
            os.unlink(dxf_path)

if __name__ == "__main__":
    print("=== Running main conversion test ===")
    test_conversion()
    
    print("\n=== Running circle conversion test ===")
    test_circle_conversion()
    
    print("\n=== Running arc conversion test ===")
    test_arc_conversion()
