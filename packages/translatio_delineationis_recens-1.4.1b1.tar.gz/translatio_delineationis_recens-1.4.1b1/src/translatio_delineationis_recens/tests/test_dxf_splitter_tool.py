"""
Comprehensive tests for DXF Splitter Tool.

Tests the model, splitters, and controller components of the DXF Splitter Tool
following the project's testing standards and patterns.
"""
import pytest
import os
import tempfile
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock
from typing import List, Dict, Any

import ezdxf
from ezdxf.math import BoundingBox

# Import the components to test
from translatio_delineationis_recens.tools.dxf_splitter_tool.model import (
    DxfSplitterModel, SplitMethod, SplitProgress, SplitResult
)
from translatio_delineationis_recens.tools.dxf_splitter_tool.splitters.geographic import GeographicSplitter
from translatio_delineationis_recens.tools.dxf_splitter_tool.splitters.entity_count import EntityCountSplitter
from translatio_delineationis_recens.tools.dxf_splitter_tool.splitters.entity_type import EntityTypeSplitter
from translatio_delineationis_recens.tools.dxf_splitter_tool.controller import DxfSplitterController


class TestSplitProgress:
    """Test the SplitProgress dataclass."""
    
    def test_progress_creation(self):
        """Test creating a progress object."""
        progress = SplitProgress("Testing", 5, 10, "Test message")
        assert progress.phase == "Testing"
        assert progress.current_step == 5
        assert progress.total_steps == 10
        assert progress.message == "Test message"
    
    def test_percentage_calculation(self):
        """Test percentage calculation."""
        progress = SplitProgress("Testing", 5, 10, "Test message")
        assert progress.percentage == 50.0
        
        # Test edge cases
        progress_zero = SplitProgress("Testing", 0, 10, "Test message")
        assert progress_zero.percentage == 0.0
        
        progress_complete = SplitProgress("Testing", 10, 10, "Test message")
        assert progress_complete.percentage == 100.0
        
        # Test division by zero
        progress_no_total = SplitProgress("Testing", 5, 0, "Test message")
        assert progress_no_total.percentage == 0.0


class TestSplitResult:
    """Test the SplitResult dataclass."""
    
    def test_successful_result(self):
        """Test creating a successful result."""
        result = SplitResult(True, ["file1.dxf", "file2.dxf"])
        assert result.success is True
        assert len(result.output_files) == 2
        assert result.error_message is None
        assert result.warnings == []
    
    def test_failed_result(self):
        """Test creating a failed result."""
        result = SplitResult(False, [], "Test error")
        assert result.success is False
        assert len(result.output_files) == 0
        assert result.error_message == "Test error"
        assert result.warnings == []
    
    def test_result_with_warnings(self):
        """Test result with warnings."""
        warnings = ["Warning 1", "Warning 2"]
        result = SplitResult(True, ["file1.dxf"], warnings=warnings)
        assert result.success is True
        assert result.warnings == warnings


@pytest.fixture
def sample_dxf_doc():
    """Create a sample DXF document for testing."""
    doc = ezdxf.new("R2018")
    msp = doc.modelspace()
    
    # Add various entity types for testing
    msp.add_line((0, 0), (10, 10), dxfattribs={"layer": "Layer1"})
    msp.add_line((5, 0), (15, 10), dxfattribs={"layer": "Layer1"})
    msp.add_circle((5, 5), radius=2.5, dxfattribs={"layer": "Layer2"})
    msp.add_circle((15, 15), radius=3.0, dxfattribs={"layer": "Layer2"})
    msp.add_point((20, 20), dxfattribs={"layer": "Layer3"})
    
    # Add some entities with different coordinates for geographic testing
    msp.add_line((100, 100), (110, 110), dxfattribs={"layer": "Layer1"})
    msp.add_circle((105, 105), radius=2.0, dxfattribs={"layer": "Layer2"})
    
    return doc


@pytest.fixture
def temp_output_dir():
    """Create a temporary output directory."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield tmpdir


@pytest.fixture
def sample_dxf_file(sample_dxf_doc, temp_output_dir):
    """Create a sample DXF file for testing."""
    filepath = os.path.join(temp_output_dir, "sample.dxf")
    sample_dxf_doc.saveas(filepath)
    return filepath


class TestDxfSplitterModel:
    """Test the DxfSplitterModel class."""
    
    def test_model_initialization(self):
        """Test model initialization."""
        model = DxfSplitterModel()
        assert model.dxf_doc is None
        assert model.input_filepath is None
        assert model.progress_callback is None
        assert model._entity_cache is None
        assert model._bbox_cache is None
    
    def test_progress_callback_setting(self):
        """Test setting progress callback."""
        model = DxfSplitterModel()
        callback = Mock()
        model.set_progress_callback(callback)
        assert model.progress_callback == callback
    
    def test_load_dxf_success(self, sample_dxf_file):
        """Test successful DXF loading."""
        model = DxfSplitterModel()
        result = model.load_dxf(sample_dxf_file)
        
        assert result is True
        assert model.dxf_doc is not None
        assert model.input_filepath == sample_dxf_file
    
    def test_load_dxf_nonexistent_file(self):
        """Test loading non-existent file."""
        model = DxfSplitterModel()
        result = model.load_dxf("nonexistent.dxf")
        
        assert result is False
        assert model.dxf_doc is None
    
    def test_entity_analysis(self, sample_dxf_file):
        """Test entity analysis functionality."""
        model = DxfSplitterModel()
        model.load_dxf(sample_dxf_file)
        
        analysis = model.get_entity_analysis()
        
        assert 'total_entities' in analysis
        assert 'entity_types' in analysis
        assert 'layer_counts' in analysis
        assert 'bounding_box' in analysis
        assert 'has_3d_entities' in analysis
        
        # Check entity types
        entity_types = analysis['entity_types']
        assert 'LINE' in entity_types
        assert 'CIRCLE' in entity_types
        assert 'POINT' in entity_types
        
        # Check layer counts
        layer_counts = analysis['layer_counts']
        assert 'Layer1' in layer_counts
        assert 'Layer2' in layer_counts
        assert 'Layer3' in layer_counts
    
    def test_get_available_entity_types(self, sample_dxf_file):
        """Test getting available entity types."""
        model = DxfSplitterModel()
        model.load_dxf(sample_dxf_file)
        
        entity_types = model.get_available_entity_types()
        
        assert isinstance(entity_types, list)
        assert 'LINE' in entity_types
        assert 'CIRCLE' in entity_types
        assert 'POINT' in entity_types
    
    def test_estimate_output_files_geographic(self, sample_dxf_file):
        """Test estimating output files for geographic splitting."""
        model = DxfSplitterModel()
        model.load_dxf(sample_dxf_file)
        
        estimate = model.estimate_output_files(
            SplitMethod.GEOGRAPHIC, grid_cols=3, grid_rows=3
        )
        
        assert estimate == 9  # 3x3 grid
    
    def test_estimate_output_files_entity_count(self, sample_dxf_file):
        """Test estimating output files for entity count splitting."""
        model = DxfSplitterModel()
        model.load_dxf(sample_dxf_file)
        
        estimate = model.estimate_output_files(
            SplitMethod.ENTITY_COUNT, max_entities=3
        )
        
        # Should be ceil(total_entities / 3)
        analysis = model.get_entity_analysis()
        total_entities = analysis['total_entities']
        expected = (total_entities + 2) // 3  # Ceiling division
        assert estimate == expected
    
    def test_estimate_output_files_entity_type(self, sample_dxf_file):
        """Test estimating output files for entity type splitting."""
        model = DxfSplitterModel()
        model.load_dxf(sample_dxf_file)
        
        # Test separate files mode
        estimate = model.estimate_output_files(
            SplitMethod.ENTITY_TYPE,
            selected_types=['LINE', 'CIRCLE'],
            max_entities=2,
            separate_files=True
        )
        
        assert estimate >= 2  # At least one file per type


class TestGeographicSplitter:
    """Test the GeographicSplitter class."""
    
    def test_splitter_initialization(self):
        """Test splitter initialization."""
        splitter = GeographicSplitter()
        assert splitter.logger is not None
    
    def test_split_by_grid_validation(self, sample_dxf_doc, temp_output_dir):
        """Test input validation for grid splitting."""
        splitter = GeographicSplitter()
        
        # Test invalid grid dimensions
        result = splitter.split_by_grid(
            sample_dxf_doc, "test.dxf", 0, 3, temp_output_dir
        )
        assert result.success is False
        assert "positive integers" in result.error_message
        
        # Test negative overlap
        result = splitter.split_by_grid(
            sample_dxf_doc, "test.dxf", 3, 3, temp_output_dir, overlap=-1.0
        )
        assert result.success is False
        assert "negative" in result.error_message
    
    @patch('ezdxf.new')
    def test_split_by_grid_success(self, mock_new, sample_dxf_doc, temp_output_dir):
        """Test successful grid splitting."""
        # Mock the new document creation
        mock_doc = Mock()
        mock_doc.saveas = Mock()
        mock_new.return_value = mock_doc
        
        splitter = GeographicSplitter()
        
        result = splitter.split_by_grid(
            sample_dxf_doc, "test.dxf", 2, 2, temp_output_dir, include_empty=True
        )
        
        # Should succeed and create files
        assert result.success is True
        assert len(result.output_files) <= 4  # 2x2 grid, some may be empty
    
    def test_bounding_box_calculation(self, sample_dxf_doc):
        """Test bounding box calculation."""
        splitter = GeographicSplitter()
        bbox = splitter._calculate_bounding_box(sample_dxf_doc)
        
        assert bbox is not None
        assert bbox.has_data
        assert bbox.size.x > 0
        assert bbox.size.y > 0


class TestEntityCountSplitter:
    """Test the EntityCountSplitter class."""
    
    def test_splitter_initialization(self):
        """Test splitter initialization."""
        splitter = EntityCountSplitter()
        assert splitter.logger is not None
    
    def test_split_by_count_validation(self, sample_dxf_doc, temp_output_dir):
        """Test input validation for count splitting."""
        splitter = EntityCountSplitter()
        
        # Test invalid max_entities
        result = splitter.split_by_count(
            sample_dxf_doc, "test.dxf", 0, temp_output_dir
        )
        assert result.success is False
        assert "positive integer" in result.error_message
        
        # Test invalid strategy
        result = splitter.split_by_count(
            sample_dxf_doc, "test.dxf", 5, temp_output_dir, strategy="invalid"
        )
        assert result.success is False
        assert "Strategy must be" in result.error_message
    
    def test_sequential_groups_creation(self):
        """Test sequential group creation."""
        splitter = EntityCountSplitter()
        entities = list(range(10))  # Mock entities as numbers
        
        groups = splitter._create_sequential_groups(entities, 3)
        
        assert len(groups) == 4  # ceil(10/3) = 4
        assert groups[0] == [0, 1, 2]
        assert groups[1] == [3, 4, 5]
        assert groups[2] == [6, 7, 8]
        assert groups[3] == [9]
    
    def test_balanced_groups_creation(self):
        """Test balanced group creation."""
        splitter = EntityCountSplitter()
        entities = list(range(10))  # Mock entities as numbers
        
        groups = splitter._create_balanced_groups(entities, 3)
        
        assert len(groups) == 4  # ceil(10/3) = 4
        # Check that groups are roughly balanced
        group_sizes = [len(group) for group in groups]
        assert max(group_sizes) - min(group_sizes) <= 1
    
    @patch('ezdxf.new')
    def test_split_by_count_success(self, mock_new, sample_dxf_doc, temp_output_dir):
        """Test successful count splitting."""
        # Mock the new document creation
        mock_doc = Mock()
        mock_doc.saveas = Mock()
        mock_new.return_value = mock_doc
        
        splitter = EntityCountSplitter()
        
        result = splitter.split_by_count(
            sample_dxf_doc, "test.dxf", 3, temp_output_dir, strategy="sequential"
        )
        
        assert result.success is True
        assert len(result.output_files) > 0


class TestEntityTypeSplitter:
    """Test the EntityTypeSplitter class."""
    
    def test_splitter_initialization(self):
        """Test splitter initialization."""
        splitter = EntityTypeSplitter()
        assert splitter.logger is not None
    
    def test_split_by_type_validation(self, sample_dxf_doc, temp_output_dir):
        """Test input validation for type splitting."""
        splitter = EntityTypeSplitter()
        
        # Test invalid max_entities
        result = splitter.split_by_type(
            sample_dxf_doc, "test.dxf", ['LINE'], 0, temp_output_dir
        )
        assert result.success is False
        assert "positive integer" in result.error_message
        
        # Test empty selected_types
        result = splitter.split_by_type(
            sample_dxf_doc, "test.dxf", [], 5, temp_output_dir
        )
        assert result.success is False
        assert "At least one entity type" in result.error_message
    
    def test_filter_entities_by_type(self, sample_dxf_doc):
        """Test entity filtering by type."""
        splitter = EntityTypeSplitter()
        
        entities_by_type = splitter._filter_entities_by_type(
            sample_dxf_doc, ['LINE', 'CIRCLE']
        )
        
        assert 'LINE' in entities_by_type
        assert 'CIRCLE' in entities_by_type
        assert 'POINT' not in entities_by_type  # Not selected
        
        # Check that we have the expected counts
        assert len(entities_by_type['LINE']) >= 2
        assert len(entities_by_type['CIRCLE']) >= 2
    
    def test_separate_type_groups_creation(self):
        """Test separate type groups creation."""
        splitter = EntityTypeSplitter()
        
        # Mock entities by type
        entities_by_type = {
            'LINE': list(range(5)),  # 5 LINE entities
            'CIRCLE': list(range(3))  # 3 CIRCLE entities
        }
        
        groups = splitter._create_separate_type_groups(entities_by_type, 2)
        
        # Should create separate groups for each type
        line_groups = [g for g in groups if g['type'] == 'LINE']
        circle_groups = [g for g in groups if g['type'] == 'CIRCLE']
        
        assert len(line_groups) == 3  # ceil(5/2) = 3
        assert len(circle_groups) == 2  # ceil(3/2) = 2
    
    def test_combined_type_groups_creation(self):
        """Test combined type groups creation."""
        splitter = EntityTypeSplitter()
        
        # Mock entities by type
        entities_by_type = {
            'LINE': list(range(5)),  # 5 LINE entities
            'CIRCLE': list(range(3))  # 3 CIRCLE entities
        }
        
        groups = splitter._create_combined_type_groups(entities_by_type, 3)
        
        # Should combine all entities into mixed groups
        assert len(groups) == 3  # ceil(8/3) = 3
        for group in groups:
            assert group['type'] == 'mixed'
    
    @patch('ezdxf.new')
    def test_split_by_type_success(self, mock_new, sample_dxf_doc, temp_output_dir):
        """Test successful type splitting."""
        # Mock the new document creation
        mock_doc = Mock()
        mock_doc.saveas = Mock()
        mock_new.return_value = mock_doc
        
        splitter = EntityTypeSplitter()
        
        result = splitter.split_by_type(
            sample_dxf_doc, "test.dxf", ['LINE', 'CIRCLE'], 5, temp_output_dir
        )
        
        assert result.success is True
        assert len(result.output_files) > 0


class TestDxfSplitterController:
    """Test the DxfSplitterController class."""
    
    @patch('translatio_delineationis_recens.tools.dxf_splitter_tool.controller.DxfSplitterView')
    def test_controller_initialization(self, mock_view):
        """Test controller initialization."""
        controller = DxfSplitterController()
        
        assert controller.model is not None
        assert controller.view is not None
        
        # Check that callbacks are set
        assert controller.view.on_load_file == controller.load_file
        assert controller.view.on_split_geographic == controller.split_geographic
        assert controller.view.on_split_entity_count == controller.split_entity_count
        assert controller.view.on_split_entity_type == controller.split_entity_type
    
    @patch('translatio_delineationis_recens.tools.dxf_splitter_tool.controller.DxfSplitterView')
    def test_load_file_success(self, mock_view, sample_dxf_file):
        """Test successful file loading through controller."""
        controller = DxfSplitterController()
        
        controller.load_file(sample_dxf_file)
        
        # Check that model was updated
        assert controller.model.dxf_doc is not None
        assert controller.model.input_filepath == sample_dxf_file
    
    @patch('translatio_delineationis_recens.tools.dxf_splitter_tool.controller.DxfSplitterView')
    def test_load_file_failure(self, mock_view):
        """Test file loading failure through controller."""
        controller = DxfSplitterController()
        
        controller.load_file("nonexistent.dxf")
        
        # Check that model was not updated
        assert controller.model.dxf_doc is None
    
    @patch('translatio_delineationis_recens.tools.dxf_splitter_tool.controller.DxfSplitterView')
    def test_progress_callback(self, mock_view):
        """Test progress callback functionality."""
        controller = DxfSplitterController()
        
        # Create a mock progress object
        progress = SplitProgress("Testing", 5, 10, "Test message")
        
        # Call the progress callback
        controller.on_progress_update(progress)
        
        # Verify that view update was scheduled
        # Note: In real usage, this would be called on the main thread
        assert True  # Basic test that callback doesn't crash
    
    @patch('translatio_delineationis_recens.tools.dxf_splitter_tool.controller.DxfSplitterView')
    def test_estimate_output_files(self, mock_view, sample_dxf_file):
        """Test output file estimation through controller."""
        controller = DxfSplitterController()
        controller.load_file(sample_dxf_file)
        
        estimate = controller.estimate_output_files(
            SplitMethod.GEOGRAPHIC, grid_cols=2, grid_rows=2
        )
        
        assert estimate == 4
    
    @patch('translatio_delineationis_recens.tools.dxf_splitter_tool.controller.DxfSplitterView')
    def test_get_available_entity_types(self, mock_view, sample_dxf_file):
        """Test getting available entity types through controller."""
        controller = DxfSplitterController()
        controller.load_file(sample_dxf_file)
        
        entity_types = controller.get_available_entity_types()
        
        assert isinstance(entity_types, list)
        assert 'LINE' in entity_types
        assert 'CIRCLE' in entity_types


class TestIntegration:
    """Integration tests for the complete DXF Splitter Tool."""
    
    def test_full_geographic_workflow(self, sample_dxf_file, temp_output_dir):
        """Test complete geographic splitting workflow."""
        model = DxfSplitterModel()
        
        # Load file
        assert model.load_dxf(sample_dxf_file) is True
        
        # Perform geographic split
        result = model.split_geographic(
            grid_cols=2,
            grid_rows=2,
            output_dir=temp_output_dir,
            overlap=0.0,
            include_empty=False
        )
        
        # Check results
        assert result.success is True
        assert len(result.output_files) > 0
        
        # Verify output files exist
        for filepath in result.output_files:
            assert os.path.exists(filepath)
            assert filepath.endswith('.dxf')
    
    def test_full_entity_count_workflow(self, sample_dxf_file, temp_output_dir):
        """Test complete entity count splitting workflow."""
        model = DxfSplitterModel()
        
        # Load file
        assert model.load_dxf(sample_dxf_file) is True
        
        # Perform entity count split
        result = model.split_by_count(
            max_entities=3,
            output_dir=temp_output_dir,
            strategy="sequential"
        )
        
        # Check results
        assert result.success is True
        assert len(result.output_files) > 0
        
        # Verify output files exist
        for filepath in result.output_files:
            assert os.path.exists(filepath)
            assert filepath.endswith('.dxf')
    
    def test_full_entity_type_workflow(self, sample_dxf_file, temp_output_dir):
        """Test complete entity type splitting workflow."""
        model = DxfSplitterModel()
        
        # Load file
        assert model.load_dxf(sample_dxf_file) is True
        
        # Perform entity type split
        result = model.split_by_type(
            selected_types=['LINE', 'CIRCLE'],
            max_entities=5,
            output_dir=temp_output_dir,
            separate_files=False
        )
        
        # Check results
        assert result.success is True
        assert len(result.output_files) > 0
        
        # Verify output files exist
        for filepath in result.output_files:
            assert os.path.exists(filepath)
            assert filepath.endswith('.dxf')


if __name__ == "__main__":
    pytest.main([__file__])
