"""
Tests for the analyze module functionality in the EzDXF library.
"""
import pytest
import math
import os
from pathlib import Path

import ezdxf
from ezdxf.math import Vec2
from ezdxf.entities import (
    EdgePath,
    PolylinePath,
    LineEdge,
    ArcEdge,
    EllipseEdge,
    SplineEdge,
    mleader,
)
from ezdxf.entities.polygon import DXFPolygon
from ezdxf.tools.analyze import (
    HatchAnalyzer,
    MultileaderAnalyzer,
    hatch_report,
    polyline_path_report,
    edge_path_report,
    yes_or_no
)


class TestHatchAnalyzer:
    """Tests for the HatchAnalyzer class."""
    
    def test_hatch_analyzer_creation(self):
        """Test creating a HatchAnalyzer instance."""
        # Create a HatchAnalyzer with default parameters
        analyzer = HatchAnalyzer()
        
        # Verify the analyzer was created with expected properties
        assert analyzer.marker_size == 1.0
        assert analyzer.angle == 45
        assert analyzer.doc is not None
        assert analyzer.msp is not None
        
        # Verify layers were created
        assert "POLYLINE_MARKER" in analyzer.doc.layers
        assert "LINE_MARKER" in analyzer.doc.layers
        assert "ARC_MARKER" in analyzer.doc.layers
        assert "ELLIPSE_MARKER" in analyzer.doc.layers
        assert "SPLINE_MARKER" in analyzer.doc.layers
        assert "HATCH" in analyzer.doc.layers
        
        # Verify marker blocks were created
        assert "EDGE_START_MARKER" in analyzer.doc.blocks
        assert "EDGE_END_MARKER" in analyzer.doc.blocks
    
    def test_hatch_analyzer_with_custom_parameters(self):
        """Test creating a HatchAnalyzer with custom parameters."""
        # Create a HatchAnalyzer with custom parameters
        analyzer = HatchAnalyzer(marker_size=2.0, angle=90)
        
        # Verify the analyzer was created with expected properties
        assert analyzer.marker_size == 2.0
        assert analyzer.angle == 90
    
    def test_add_hatch(self):
        """Test adding a hatch to the analyzer."""
        # Create a HatchAnalyzer
        analyzer = HatchAnalyzer()
        
        # Create a source document with a hatch
        doc = ezdxf.new()
        msp = doc.modelspace()
        
        # Create a simple rectangular hatch
        points = [(0, 0), (10, 0), (10, 10), (0, 10), (0, 0)]
        hatch = msp.add_hatch(color=2)
        hatch.paths.add_polyline_path(points, is_closed=True)
        
        # Add the hatch to the analyzer
        analyzer.add_hatch(hatch)
        
        # Verify the hatch was added to the analyzer's modelspace
        hatches = list(analyzer.msp.query("HATCH"))
        assert len(hatches) == 1
        assert hatches[0].dxf.layer == "HATCH"
    
    def test_add_boundary_markers(self):
        """Test adding boundary markers to a hatch."""
        # Create a HatchAnalyzer
        analyzer = HatchAnalyzer()
        
        # Create a source document with a hatch
        doc = ezdxf.new()
        msp = doc.modelspace()
        
        # Create a simple rectangular hatch with a polyline path
        points = [(0, 0), (10, 0), (10, 10), (0, 10), (0, 0)]
        hatch = msp.add_hatch(color=2)
        hatch.paths.add_polyline_path(points, is_closed=True)
        
        # Add boundary markers
        analyzer.add_boundary_markers(hatch)
        
        # Verify markers were added
        inserts = list(analyzer.msp.query("INSERT"))
        assert len(inserts) > 0
    
    def test_export(self, tmpdir):
        """Test exporting the analyzer document."""
        # Create a HatchAnalyzer
        analyzer = HatchAnalyzer()
        
        # Create a temporary file path
        filename = os.path.join(tmpdir, "hatch_analyzer.dxf")
        
        # Export the document
        analyzer.export(filename)
        
        # Verify the file was created
        assert os.path.exists(filename)
        
        # Verify the file can be opened as a DXF document
        doc = ezdxf.readfile(filename)
        assert doc is not None
    
    def test_add_markers(self):
        """Test adding start and end markers."""
        # Create a HatchAnalyzer
        analyzer = HatchAnalyzer()
        
        # Add start and end markers
        analyzer.add_start_marker(Vec2(0, 0), "Start", "LINE_MARKER")
        analyzer.add_end_marker(Vec2(10, 10), "End", "LINE_MARKER")
        
        # Verify markers were added
        inserts = list(analyzer.msp.query("INSERT"))
        assert len(inserts) == 2
        
        # Verify attributes were set
        for insert in inserts:
            # The Insert entity doesn't have get_attribs method
            # Instead, we need to get the attdefs from the block and check if they exist
            block = analyzer.doc.blocks[insert.dxf.name]
            attdefs = list(block.query("ATTDEF"))
            assert len(attdefs) == 1
            assert attdefs[0].dxf.tag == "NAME"


class TestMultileaderAnalyzer:
    """Tests for the MultileaderAnalyzer class."""
    
    def test_multileader_analyzer_creation(self):
        """Test creating a MultileaderAnalyzer instance."""
        # Create a source document with a multileader
        doc = ezdxf.new("R2013")  # MULTILEADER requires at least R2013
        msp = doc.modelspace()
        
        # Add a simple multileader
        mleader = self._create_test_multileader(doc, msp)
        
        # Create a MultileaderAnalyzer
        analyzer = MultileaderAnalyzer(mleader)
        
        # Verify the analyzer was created with expected properties
        assert analyzer.marker_size == 1.0
        assert analyzer.report_width == 79
        assert analyzer.multileader is not None
        assert analyzer.doc is not None
        assert analyzer.msp is not None
        
        # Verify the MULTILEADER_MARKER layer was created
        assert "MULTILEADER_MARKER" in analyzer.doc.layers
    
    def test_multileader_analyzer_report(self):
        """Test generating a report for a multileader."""
        # Create a source document with a multileader
        doc = ezdxf.new("R2013")  # MULTILEADER requires at least R2013
        msp = doc.modelspace()
        
        # Add a simple multileader
        mleader = self._create_test_multileader(doc, msp)
        
        # Create a MultileaderAnalyzer
        analyzer = MultileaderAnalyzer(mleader)
        
        # Generate a report
        report = analyzer.report()
        
        # Verify the report contains expected sections
        assert isinstance(report, list)
        assert len(report) > 0
        
        # Convert to string for easier checking
        report_str = "\n".join(report)
        
        # Check for key sections
        assert "MULTILEADER" in report_str
        assert "CONTEXT object attributes" in report_str
        
        # Test print_report (should not raise exceptions)
        analyzer.print_report()
    
    def test_multileader_analyzer_leader_attributes(self):
        """Test getting leader attributes from a multileader."""
        # Create a source document with a multileader
        doc = ezdxf.new("R2013")  # MULTILEADER requires at least R2013
        msp = doc.modelspace()
        
        # Add a simple multileader
        mleader = self._create_test_multileader(doc, msp)
        
        # Create a MultileaderAnalyzer
        analyzer = MultileaderAnalyzer(mleader)
        
        # Get leader attributes
        leader_attrs = analyzer.leader_attributes()
        
        # Verify attributes were returned
        assert isinstance(leader_attrs, list)
        assert len(leader_attrs) > 0
        
        # Test print_leader_attributes (should not raise exceptions)
        analyzer.print_leader_attributes()
    
    def test_multileader_analyzer_mleaderstyle_attributes(self):
        """Test getting mleaderstyle attributes from a multileader."""
        # Create a source document with a multileader
        doc = ezdxf.new("R2013")  # MULTILEADER requires at least R2013
        msp = doc.modelspace()
        
        # Add a simple multileader
        mleader = self._create_test_multileader(doc, msp)
        
        # Create a MultileaderAnalyzer
        analyzer = MultileaderAnalyzer(mleader)
        
        # Get mleaderstyle attributes
        style_attrs = analyzer.mleaderstyle_attributes()
        
        # Verify attributes were returned
        assert isinstance(style_attrs, list)
        assert len(style_attrs) > 0
        
        # Test print_mleaderstyle (should not raise exceptions)
        analyzer.print_mleaderstyle()
    
    def _create_test_multileader(self, doc, msp):
        """Helper method to create a test multileader."""
        # Create a mleader style
        mleader_style = doc.mleader_styles.duplicate_entry("Standard", "TestStyle")
        mleader_style.set_mtext_style("Standard")
        
        # Create a multileader with text content using the builder pattern
        ml_builder = msp.add_multileader_mtext("TestStyle")
        ml_builder.set_content("Test Multileader", style="Standard")
        
        # Add leader lines
        from ezdxf.render import mleader as mleader_module
        ml_builder.add_leader_line(mleader_module.ConnectionSide.right, [Vec2(40, 15)])
        
        # Build the multileader at the specified insertion point
        ml_builder.build(insert=Vec2(5, 0))
        
        # Return the created multileader entity
        return ml_builder.multileader


class TestReportFunctions:
    """Tests for the report functions in the analyze module."""
    
    def test_hatch_report(self):
        """Test generating a report for a hatch."""
        # Create a source document with a hatch
        doc = ezdxf.new()
        msp = doc.modelspace()
        
        # Create a simple rectangular hatch
        points = [(0, 0), (10, 0), (10, 10), (0, 10), (0, 0)]
        hatch = msp.add_hatch(color=2)
        hatch.paths.add_polyline_path(points, is_closed=True)
        
        # Generate a report
        report = hatch_report(hatch)
        
        # Verify the report is a list of strings
        assert isinstance(report, list)
        assert len(report) > 0
    
    def test_polyline_path_report(self):
        """Test generating a report for a polyline path."""
        # Create a source document with a hatch
        doc = ezdxf.new()
        msp = doc.modelspace()
        
        # Create a simple rectangular hatch
        points = [(0, 0), (10, 0), (10, 10), (0, 10), (0, 0)]
        hatch = msp.add_hatch(color=2)
        path = hatch.paths.add_polyline_path(points, is_closed=True)
        
        # Generate a report
        report = polyline_path_report(path, 1)
        
        # Verify the report is a list of strings
        assert isinstance(report, list)
        assert len(report) > 0
    
    def test_edge_path_report(self):
        """Test generating a report for an edge path."""
        # Create a source document with a hatch
        doc = ezdxf.new()
        msp = doc.modelspace()
        
        # Create a hatch with an edge path
        hatch = msp.add_hatch(color=2)
        path = hatch.paths.add_edge_path()
        path.add_line((0, 0), (10, 0))
        path.add_line((10, 0), (10, 10))
        path.add_line((10, 10), (0, 10))
        path.add_line((0, 10), (0, 0))
        
        # Generate a report
        report = edge_path_report(path, 1)
        
        # Verify the report is a list of strings
        assert isinstance(report, list)
        assert len(report) > 0
    
    def test_yes_or_no(self):
        """Test the yes_or_no function."""
        assert yes_or_no(True) == "yes"
        assert yes_or_no(False) == "no"
        assert yes_or_no(1) == "yes"
        assert yes_or_no(0) == "no"
        assert yes_or_no(None) == "no"
