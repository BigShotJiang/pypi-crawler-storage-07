"""Tests for the ezdxf.tools.handle module."""
import pytest
from Code.Python.ezdxf.tools.handle import (
    HandleGenerator, UnderlayKeyGenerator, safe_handle, START_HANDLE
)


class TestHandleGenerator:
    """Test cases for HandleGenerator class."""

    def test_init_default(self):
        """Test initialization with default start value."""
        generator = HandleGenerator()
        # Default start handle is "1", which is 1 in decimal
        assert str(generator) == "1"

    def test_init_custom(self):
        """Test initialization with custom start value."""
        generator = HandleGenerator("A")
        # "A" in hex is 10 in decimal
        assert str(generator) == "A"

    def test_init_with_zero(self):
        """Test initialization with "0" - should be converted to "1"."""
        generator = HandleGenerator("0")
        # Should be converted to minimum value of 1
        assert str(generator) == "1"

    def test_next(self):
        """Test next() method."""
        generator = HandleGenerator("1")
        
        # First call should return "1"
        assert generator.next() == "1"
        
        # Second call should return "2"
        assert generator.next() == "2"
        
        # Third call should return "3"
        assert generator.next() == "3"

    def test_reset(self):
        """Test reset() method."""
        generator = HandleGenerator("1")
        
        # Advance the generator
        generator.next()
        generator.next()
        
        # Reset to initial value
        generator.reset("1")
        assert str(generator) == "1"
        
        # Reset to custom value
        generator.reset("FF")
        assert str(generator) == "FF"

    def test_copy(self):
        """Test copy() method."""
        generator = HandleGenerator("A")
        
        # Advance the generator
        generator.next()
        
        # Create a copy
        copy = generator.copy()
        
        # Both should have the same value
        assert str(generator) == str(copy)
        
        # Advancing the original should not affect the copy
        generator.next()
        assert str(generator) != str(copy)

    def test_dunder_next(self):
        """Test __next__() method."""
        generator = HandleGenerator("1")
        
        # __next__ should be an alias for next()
        assert generator.__next__() == "1"
        assert generator.__next__() == "2"

    def test_hex_conversion(self):
        """Test hex conversion in __str__()."""
        # Test with various hex values
        test_values = [
            ("1", "1"),
            ("A", "A"),
            ("10", "10"),
            ("FF", "FF"),
            ("100", "100"),
            ("FFFF", "FFFF"),
        ]
        
        for start, expected in test_values:
            generator = HandleGenerator(start)
            assert str(generator) == expected

    def test_sequential_handles(self):
        """Test generating a sequence of handles."""
        generator = HandleGenerator("1")
        handles = [generator.next() for _ in range(5)]
        
        # Should generate sequential handles
        assert handles == ["1", "2", "3", "4", "5"]


class TestUnderlayKeyGenerator:
    """Test cases for UnderlayKeyGenerator class."""

    def test_init_default(self):
        """Test initialization with default start value."""
        generator = UnderlayKeyGenerator()
        # Default format is "Underlay00001"
        assert str(generator) == "Underlay00001"

    def test_init_custom(self):
        """Test initialization with custom start value."""
        generator = UnderlayKeyGenerator("A")
        # "A" in hex is 10 in decimal, so "Underlay00010"
        assert str(generator) == "Underlay00010"

    def test_next(self):
        """Test next() method."""
        generator = UnderlayKeyGenerator("1")
        
        # First call should return "Underlay00001"
        assert generator.next() == "Underlay00001"
        
        # Second call should return "Underlay00002"
        assert generator.next() == "Underlay00002"
        
        # Third call should return "Underlay00003"
        assert generator.next() == "Underlay00003"

    def test_sequential_keys(self):
        """Test generating a sequence of underlay keys."""
        generator = UnderlayKeyGenerator("1")
        keys = [generator.next() for _ in range(5)]
        
        # Should generate sequential keys
        assert keys == [
            "Underlay00001", 
            "Underlay00002", 
            "Underlay00003", 
            "Underlay00004", 
            "Underlay00005"
        ]


class TestSafeHandle:
    """Test cases for safe_handle function."""

    def test_none_handle(self):
        """Test with None handle."""
        assert safe_handle(None) == "0"

    def test_valid_handle(self):
        """Test with valid handle."""
        assert safe_handle("ABC") == "ABC"

    def test_lowercase_handle(self):
        """Test with lowercase handle - should be converted to uppercase."""
        assert safe_handle("abc") == "ABC"

    def test_invalid_handle_type(self):
        """Test with invalid handle type."""
        with pytest.raises(AssertionError):
            safe_handle(123)  # type: ignore

    def test_with_document_handle_exists(self, monkeypatch):
        """Test with document where handle exists."""
        # Create a custom mock class for entitydb
        class MockEntityDB:
            def __contains__(self, key):
                return True
        
        # Create a simple mock document class
        class MockDoc:
            def __init__(self):
                self.entitydb = MockEntityDB()
        
        # Create mock document
        mock_doc = MockDoc()
        
        assert safe_handle("ABC", mock_doc) == "ABC"

    def test_with_document_handle_not_exists(self, monkeypatch):
        """Test with document where handle does not exist."""
        # Create a custom mock class for entitydb
        class MockEntityDB:
            def __contains__(self, key):
                return False
        
        # Create a simple mock document class
        class MockDoc:
            def __init__(self):
                self.entitydb = MockEntityDB()
        
        # Create mock document
        mock_doc = MockDoc()
        
        assert safe_handle("ABC", mock_doc) == "0"

    def test_invalid_handle_format(self, monkeypatch):
        """Test with invalid handle format."""
        # Mock is_valid_handle to return False
        def mock_is_valid_handle(handle):
            return False
            
        monkeypatch.setattr("Code.Python.ezdxf.tools.handle.is_valid_handle", mock_is_valid_handle)
        
        assert safe_handle("@invalid@") == "0"


class TestStartHandle:
    """Test cases for START_HANDLE constant."""

    def test_start_handle_value(self):
        """Test START_HANDLE value."""
        assert START_HANDLE == "1"

    def test_start_handle_usage(self):
        """Test START_HANDLE usage in HandleGenerator."""
        generator = HandleGenerator(START_HANDLE)
        assert str(generator) == "1"
