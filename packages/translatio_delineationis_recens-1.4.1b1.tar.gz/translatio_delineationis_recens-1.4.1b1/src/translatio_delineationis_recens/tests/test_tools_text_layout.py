import pytest
from ezdxf.tools import text_layout as tl

# --- ENUMS and SIMPLE CLASSES ---
def test_layout_alignment_enum():
    assert tl.LayoutAlignment.TOP_LEFT == 1
    assert tl.LayoutAlignment.BOTTOM_RIGHT == 9

def test_paragraph_alignment_enum():
    assert tl.ParagraphAlignment.LEFT == 1
    assert tl.ParagraphAlignment.JUSTIFIED == 4

def test_cell_alignment_enum():
    assert tl.CellAlignment.BOTTOM == 0
    assert tl.CellAlignment.TOP == 2

def test_tab_stop_type_enum():
    assert tl.TabStopType.LEFT == 0
    assert tl.TabStopType.CENTER == 2

def test_tab_stop_dataclass():
    tab = tl.TabStop(5.5, tl.TabStopType.RIGHT)
    assert tab.pos == 5.5
    assert tab.kind == tl.TabStopType.RIGHT

# --- EXCEPTIONS ---
def test_layout_error():
    with pytest.raises(Exception):
        raise tl.LayoutError()

# --- UTILITY FUNCTIONS ---
def test_resolve_margins():
    # None returns all zeros
    assert tl.resolve_margins(None) == (0, 0, 0, 0)
    # 1-value
    assert tl.resolve_margins([2]) == (2, 2, 2, 2)
    # 2-values
    assert tl.resolve_margins([1, 2]) == (1, 2, 1, 2)
    # 3-values
    assert tl.resolve_margins([1, 2, 3]) == (1, 2, 3, 2)
    # 4-values
    assert tl.resolve_margins([1, 2, 3, 4]) == (1, 2, 3, 4)


def test_insert_location():
    loc = tl.insert_location(tl.LayoutAlignment.TOP_LEFT, 10, 5)
    assert isinstance(loc, tuple) and len(loc) == 2


def test_shift_tab_stops():
    stops = [tl.TabStop(1, tl.TabStopType.LEFT), tl.TabStop(3, tl.TabStopType.RIGHT)]
    shifted = tl.shift_tab_stops(stops, 2, 6)
    assert all(isinstance(t, tl.TabStop) for t in shifted)
    assert shifted[0].pos == 3
    assert shifted[1].pos == 5


# --- ADVANCED: ContentRenderer and DoNothingRenderer ---
def test_do_nothing_renderer_methods():
    renderer = tl.DoNothingRenderer()
    # Should not raise
    renderer.render(0, 0, 1, 1)
    renderer.line(0, 0, 1, 1)


# --- ADVANCED: ContentCell ---
def test_content_cell_properties_and_methods():
    cell = tl.ContentCell(10, 5, tl.CellAlignment.CENTER)
    cell.set_final_location(3, 4)
    assert cell.final_location() == (3, 4)
    assert cell.total_width == 10
    assert cell.total_height == 5
    cell.place(7, 8)
    assert cell.final_location() == (7, 8)


# --- ADVANCED: Glue ---
def test_glue_resize_and_flags():
    glue = tl.Glue(5, min_width=2, max_width=10)
    assert glue._width == 5
    glue.resize(7)
    assert glue._width == 7
    assert glue.can_grow is True
    assert glue.can_shrink is True
    assert glue.total_width == 7
    assert glue.total_height == 0
    space = glue.to_space()
    assert isinstance(space, tl.Space)


# --- ADVANCED: Text and Stroke ---
def test_text_and_stroke_flags():
    class DummyRenderer(tl.DoNothingRenderer):
        def __init__(self):
            self.calls = []
        def line(self, x1, y1, x2, y2, m=None):
            self.calls.append((x1, y1, x2, y2))
    renderer = DummyRenderer()
    text = tl.Text(10, 2, stroke=tl.Stroke.UNDERLINE | tl.Stroke.OVERLINE, renderer=renderer)
    text.place(0, 2)
    text.render_stroke()
    # Should have called line at least twice (underline and overline)
    assert len(renderer.calls) >= 2


# --- COMPLEX LAYOUTS: Layout, Column, Paragraph, Fraction, and error handling ---
def test_layout_column_paragraph_basic():
    layout = tl.Layout(100, 20)
    col = tl.Column(100, 20)
    para = tl.Paragraph(100)
    # Add a simple text cell to the paragraph
    cell = tl.Text(10, 2)
    para._cells.append(cell)
    # Add paragraph to column, column to layout
    col._paragraphs.append(para)
    layout._columns.append(col)
    # Place the layout and check structure
    assert len(layout._columns) == 1
    assert len(col._paragraphs) == 1
    assert para._cells[0].total_width == 10


def test_fraction_stacking_and_render():
    top = tl.Text(3, 1)
    bottom = tl.Text(3, 1)
    class DummyRenderer(tl.DoNothingRenderer):
        def __init__(self): self.calls = []
        def line(self, x1, y1, x2, y2, m=None): self.calls.append((x1, y1, x2, y2))
    renderer = DummyRenderer()
    frac = tl.Fraction(top, bottom, stacking=tl.Stacking.LINE, renderer=renderer)
    frac.set_final_location(0, 0)
    frac._render_line(None)
    assert renderer.calls, "Fraction line should be rendered for LINE stacking"


def test_layout_overflow_error():
    layout = tl.Layout(10)
    col = tl.Column(10)
    para = tl.Paragraph(10)
    cell = tl.Text(20, 2) # Too wide for column
    para._cells.append(cell)
    col._paragraphs.append(para)
    layout._columns.append(col)
    # Try to distribute content, should not raise (renders oversize)
    try:
        para.distribute_content()
    except Exception as e:
        pytest.fail(f"Unexpected error on overflow: {e}")


def test_layout_error_handling():
    layout = tl.Layout(10)
    # Calling _new_column with no columns should raise LayoutError
    with pytest.raises(tl.LayoutError):
        layout._new_column()


def test_justified_line_glue_distribution():
    # Use real Glue and Space objects from text_layout for correct growable_cells logic
    locked = tl.LineCell(cell=tl.Text(5, 1), offset=0, locked=True)
    glue1 = tl.LineCell(cell=tl.Glue(2), offset=5, locked=False)
    glue2 = tl.LineCell(cell=tl.Glue(2), offset=7, locked=False)
    line = tl.JustifiedLine(20)
    line._cells = [locked, glue1, glue2]
    # Should distribute extra space among glue
    line.distribute()
    total = sum(c.cell.total_width for c in line._cells)
    assert abs(total - 20) < 1e-6
