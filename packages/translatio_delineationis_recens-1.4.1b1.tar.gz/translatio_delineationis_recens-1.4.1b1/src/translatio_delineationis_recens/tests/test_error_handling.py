"""
Tests for error handling in the EzDXF library.
"""
import os
import io
import pytest
from pathlib import Path

import ezdxf
from ezdxf.lldxf.const import DXFValueError, DXFStructureError, DXFTableEntryError, DXFVersionError
from ezdxf.lldxf.validator import is_valid_layer_name


class TestInputValidation:
    """Tests for input validation and error handling."""
    
    def test_invalid_dxf_version(self):
        """Test handling of invalid DXF version."""
        with pytest.raises(DXFVersionError):
            ezdxf.new("INVALID_VERSION")
    
    def test_invalid_layer_name(self):
        """Test validation of layer names."""
        # Valid layer names
        assert is_valid_layer_name("LAYER1")
        assert is_valid_layer_name("0")
        assert is_valid_layer_name("LAYER-1")
        
        # Invalid layer names
        # Empty name is actually valid in the implementation
        assert is_valid_layer_name("")  # Empty name is valid in the implementation
        assert not is_valid_layer_name("LAYER<1>")  # Contains invalid characters
        assert not is_valid_layer_name("LAYER/1")  # Contains invalid characters
    
    def test_invalid_entity_creation(self, empty_drawing):
        """Test handling of invalid entity creation."""
        msp = empty_drawing.modelspace()
        
        # Test invalid line coordinates
        with pytest.raises((TypeError, ValueError)):
            msp.add_line("not_a_point", (10, 10))
        
        # Test invalid circle parameters
        with pytest.raises((TypeError, ValueError)):
            msp.add_circle((0, 0), radius="not_a_number")
        
        # Test that numeric text values are converted to strings, not raising an exception
        text = msp.add_text(123)  # Numeric instead of string
        assert text.dxf.text == "123"  # Should be converted to string
    
    def test_duplicate_layer_creation(self, empty_drawing):
        """Test handling of duplicate layer creation."""
        doc = empty_drawing
        
        # Add a layer
        doc.layers.add("TEST_LAYER")
        
        # Adding the same layer again should raise a DXFTableEntryError
        with pytest.raises(DXFTableEntryError):
            doc.layers.add("TEST_LAYER")
        
        # Verify the layer exists
        assert doc.layers.has_entry("TEST_LAYER")
        
        # The correct way to get an existing layer is to use get() method
        layer = doc.layers.get("TEST_LAYER")
        assert layer.dxf.name == "TEST_LAYER"
        layers = [layer.dxf.name for layer in doc.layers]
        assert layers.count("TEST_LAYER") == 1
    
    def test_invalid_color_values(self, empty_drawing):
        """Test handling of invalid color values."""
        msp = empty_drawing.modelspace()
        line = msp.add_line((0, 0), (10, 10))
        
        # Valid color values are 0-257 according to is_valid_aci_color
        line.dxf.color = 255
        assert line.dxf.color == 255
        
        # 256 and 257 are also valid ACI colors
        line.dxf.color = 256
        assert line.dxf.color == 256
        
        line.dxf.color = 257
        assert line.dxf.color == 257
        
        # The library silently clamps invalid color values to valid ones
        # Values > 257 are clamped to 256 (BYLAYER)
        line.dxf.color = 258  # Too high, clamped to 256 (BYLAYER)
        assert line.dxf.color == 256
        
        # Negative values are likely clamped to 0 (BYBLOCK) or another valid value
        line.dxf.color = -1
        assert line.dxf.color >= 0  # Should be clamped to a valid value


class TestFileOperationErrors:
    """Tests for file operation errors."""
    
    def test_nonexistent_file(self):
        """Test handling of nonexistent file."""
        with pytest.raises(IOError):
            ezdxf.readfile("nonexistent_file.dxf")
    
    def test_invalid_file_content(self, tmpdir):
        """Test handling of invalid file content."""
        # Create a file with invalid content
        invalid_file = os.path.join(tmpdir, "invalid.dxf")
        with open(invalid_file, "w") as f:
            f.write("This is not a valid DXF file")
        
        # Attempt to read the invalid file
        with pytest.raises((IOError, DXFStructureError)):
            ezdxf.readfile(invalid_file)
    
    def test_permission_error_handling(self, tmpdir, monkeypatch):
        """Test handling of permission errors."""
        # Create a test file
        test_file = os.path.join(tmpdir, "permission_test.dxf")
        doc = ezdxf.new()
        doc.saveas(test_file)
        
        # Mock os.open to raise PermissionError
        def mock_open(*args, **kwargs):
            raise PermissionError("Permission denied")
        
        # Apply the mock to simulate permission error
        monkeypatch.setattr("builtins.open", mock_open)
        
        # Test reading with permission error
        with pytest.raises(IOError):
            ezdxf.readfile(test_file)
    
    def test_disk_full_error_handling(self, tmpdir, monkeypatch):
        """Test handling of disk full errors."""
        # Create a test document
        doc = ezdxf.new()
        test_file = os.path.join(tmpdir, "disk_full_test.dxf")
        
        # Mock io.open to raise OSError for disk full
        # The Drawing.save method uses io.open for ASCII format
        original_io_open = io.open
        
        def mock_io_open(*args, **kwargs):
            # Check if this is opening our test file for writing
            if args and args[0] == test_file and kwargs.get('mode', '').startswith('w'):
                raise OSError(28, "No space left on device")
            return original_io_open(*args, **kwargs)
        
        # Apply the mock to io.open instead of builtins.open
        monkeypatch.setattr("io.open", mock_io_open)
        
        # Test saving with disk full error
        with pytest.raises(OSError):
            doc.saveas(test_file)


class TestEntityManipulationErrors:
    """Tests for entity manipulation errors."""
    
    def test_delete_nonexistent_entity(self, empty_drawing):
        """Test deleting a nonexistent entity."""
        msp = empty_drawing.modelspace()
        line = msp.add_line((0, 0), (10, 10))
        
        # Delete the line
        msp.delete_entity(line)
        
        # The entity is no longer alive after deletion
        assert not line.is_alive
        
        # Attempting to delete again doesn't raise an error in the current implementation
        # The library silently ignores the request
        msp.delete_entity(line)  # This should not raise an error
    
    def test_invalid_entity_handle(self, empty_drawing):
        """Test handling of invalid entity handles."""
        doc = empty_drawing
        
        # Try to get an entity with an invalid handle
        # The get method returns None for non-existent handles
        assert doc.entitydb.get("INVALID_HANDLE") is None
        
        # However, direct dictionary access with [] should raise KeyError
        with pytest.raises(KeyError):
            doc.entitydb["INVALID_HANDLE"]
    
    def test_invalid_block_operations(self, empty_drawing):
        """Test invalid block operations."""
        doc = empty_drawing
        
        # Create a block
        block = doc.blocks.new("TEST_BLOCK")
        
        # Test creating a block with the same name
        with pytest.raises(DXFTableEntryError):
            doc.blocks.new("TEST_BLOCK")
        
        # Test referencing a nonexistent block
        # The library allows referencing non-existent blocks without raising an error
        msp = doc.modelspace()
        blockref = msp.add_blockref("NONEXISTENT_BLOCK", (0, 0))
        
        # Verify that the block reference was created but points to a non-existent block
        assert blockref.dxf.name == "NONEXISTENT_BLOCK"
        assert blockref.block() is None


class TestEdgeCases:
    """Tests for edge cases."""
    
    def test_empty_polyline(self, empty_drawing):
        """Test handling of empty polylines."""
        msp = empty_drawing.modelspace()
        
        # Create a polyline with no points
        lwpolyline = msp.add_lwpolyline([])
        
        # Verify it has 0 points
        assert len(lwpolyline) == 0
        
        # Add points after creation
        lwpolyline.append_points([(0, 0), (1, 1)])
        assert len(lwpolyline) == 2
    
    def test_zero_radius_circle(self, empty_drawing):
        """Test that creating a circle with zero radius raises ValueError."""
        msp = empty_drawing.modelspace()
        with pytest.raises(ValueError):
            msp.add_circle((0, 0), radius=0)
    
    def test_coincident_line_points(self, empty_drawing):
        """Test handling of lines with coincident endpoints."""
        msp = empty_drawing.modelspace()
        
        # Create a line with the same start and end point
        line = msp.add_line((5, 5), (5, 5))
        
        # Verify the line was created
        assert line.dxf.start == (5, 5, 0)
        assert line.dxf.end == (5, 5, 0)
        
        # The line has zero length
        start = ezdxf.math.Vec3(line.dxf.start)
        end = ezdxf.math.Vec3(line.dxf.end)
        assert start.distance(end) == 0
    
    def test_extreme_coordinate_values(self, empty_drawing):
        """Test handling of extreme coordinate values."""
        msp = empty_drawing.modelspace()
        
        # Test very large coordinates
        large_value = 1e15
        line = msp.add_line((0, 0), (large_value, large_value))
        assert line.dxf.end == (large_value, large_value, 0)
        
        # Test very small coordinates
        small_value = 1e-15
        line = msp.add_line((0, 0), (small_value, small_value))
        assert line.dxf.end == (small_value, small_value, 0)
