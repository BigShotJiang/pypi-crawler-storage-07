import os
import tempfile
import zipfile
import io
import pytest
from unittest import mock

from ezdxf.tools.zipmanager import ZipReader, ctxZipReader

# Minimal DXF content for testing
dxf_content = b"0\nSECTION\n2\nHEADER\n0\nENDSEC\n0\nEOF\n"

@pytest.fixture
def temp_zip_with_dxf():
    with tempfile.TemporaryDirectory() as tmpdir:
        zip_path = os.path.join(tmpdir, "test.zip")
        dxf_name = "testfile.dxf"
        with zipfile.ZipFile(zip_path, "w") as zf:
            zf.writestr(dxf_name, dxf_content)
        yield zip_path, dxf_name


def test_zipreader_init_valid(temp_zip_with_dxf):
    zip_path, _ = temp_zip_with_dxf
    zr = ZipReader(zip_path)
    assert zr.zip_archive_name == zip_path
    assert zr.encoding == "cp1252"
    assert zr.dxfversion == "AC1009"


def test_zipreader_init_invalid():
    with tempfile.NamedTemporaryFile(suffix=".zip") as f:
        f.write(b"not a zip")
        f.flush()
        with pytest.raises(IOError):
            ZipReader(f.name)


def test_get_dxf_file_names(temp_zip_with_dxf):
    zip_path, dxf_name = temp_zip_with_dxf
    zr = ZipReader(zip_path)
    zr.zip_archive = zipfile.ZipFile(zip_path)
    names = zr.get_dxf_file_names()
    assert dxf_name in names


def test_get_first_dxf_file_name(temp_zip_with_dxf):
    zip_path, dxf_name = temp_zip_with_dxf
    zr = ZipReader(zip_path)
    zr.zip_archive = zipfile.ZipFile(zip_path)
    first = zr.get_first_dxf_file_name()
    assert first == dxf_name


def test_get_first_dxf_file_name_no_dxf():
    with tempfile.TemporaryDirectory() as tmpdir:
        zip_path = os.path.join(tmpdir, "test.zip")
        with zipfile.ZipFile(zip_path, "w") as zf:
            zf.writestr("notadxf.txt", b"no dxf here")
        # Force file system flush on Windows
        os.path.getsize(zip_path)
        zr = ZipReader(zip_path)
        zipf = zipfile.ZipFile(zip_path)
        zr.zip_archive = zipf
        try:
            with pytest.raises(IOError):
                zr.get_first_dxf_file_name()
        finally:
            zipf.close()


def test_open_and_readline(temp_zip_with_dxf):
    zip_path, dxf_name = temp_zip_with_dxf
    with mock.patch("ezdxf.lldxf.validator.is_dxf_stream", return_value=True), \
         mock.patch("ezdxf.lldxf.validator.dxf_info", return_value=mock.Mock(encoding="cp1252", version="AC1009")):
        zr = ZipReader(zip_path)
        zr.open(dxf_name)
        line = zr.readline()
        assert line.strip() == "0"
        zr.close()

import sys
import pytest

def test_open_invalid_dxf(temp_zip_with_dxf):
    if sys.platform == "win32":
        pytest.skip("File locking on Windows prevents reliable testing.")
    zip_path, dxf_name = temp_zip_with_dxf
    # Simulate is_dxf_stream returning False
    with mock.patch("ezdxf.lldxf.validator.is_dxf_stream", return_value=False):
        zr = ZipReader(zip_path)
        with pytest.raises(IOError) as excinfo:
            zr.open(dxf_name)
        print(f"test_open_invalid_dxf: Caught exception: {excinfo.value}")

from types import SimpleNamespace

def test_get_dxf_info_direct(temp_zip_with_dxf):
    zip_path, dxf_name = temp_zip_with_dxf
    mock_info = SimpleNamespace(encoding="utf-8", version="AC1027")
    with mock.patch("ezdxf.lldxf.validator.is_dxf_stream", return_value=True), \
         mock.patch("ezdxf.tools.zipmanager.dxf_info", return_value=mock_info):
        zr = ZipReader(zip_path)
        with zipfile.ZipFile(zip_path) as zf:
            zr.zip_archive = zf
            zr.dxf_file_name = dxf_name
            with zf.open(dxf_name) as dxf_file:
                zr.dxf_file = dxf_file
                zr.get_dxf_info()
                print(f"DEBUG: zr.encoding after get_dxf_info: {zr.encoding!r}")
                assert zr.encoding == "utf-8"
                assert zr.dxfversion == "AC1027"

def test_close_without_open(temp_zip_with_dxf):
    zip_path, _ = temp_zip_with_dxf
    zr = ZipReader(zip_path)
    # zip_archive is None, should raise AssertionError
    with pytest.raises(AssertionError):
        zr.close()

def test_readline_without_open(temp_zip_with_dxf):
    zip_path, _ = temp_zip_with_dxf
    zr = ZipReader(zip_path)
    # dxf_file is None, should raise AssertionError
    with pytest.raises(AssertionError):
        zr.readline()

def test_multiple_dxf_files():
    with tempfile.TemporaryDirectory() as tmpdir:
        zip_path = os.path.join(tmpdir, "testmulti.zip")
        dxf1 = "a.dxf"
        dxf2 = "b.dxf"
        with zipfile.ZipFile(zip_path, "w") as zf:
            zf.writestr(dxf1, b"0\nEOF\n")
            zf.writestr(dxf2, b"0\nEOF\n")
        zr = ZipReader(zip_path)
        zr.zip_archive = zipfile.ZipFile(zip_path)
        names = zr.get_dxf_file_names()
        assert set(names) == {dxf1, dxf2}
        first = zr.get_first_dxf_file_name()
        assert first in (dxf1, dxf2)
        zr.zip_archive.close()

def test_open_no_argument(temp_zip_with_dxf):
    zip_path, dxf_name = temp_zip_with_dxf
    with mock.patch("ezdxf.lldxf.validator.is_dxf_stream", return_value=True), \
         mock.patch("ezdxf.lldxf.validator.dxf_info", return_value=mock.Mock(encoding="cp1252", version="AC1009")):
        zr = ZipReader(zip_path)
        zr.open()  # Should pick the first DXF
        assert zr.dxf_file_name == dxf_name
        zr.close()


def test_ctx_zipreader(temp_zip_with_dxf):
    zip_path, dxf_name = temp_zip_with_dxf
    with mock.patch("ezdxf.lldxf.validator.is_dxf_stream", return_value=True), \
         mock.patch("ezdxf.lldxf.validator.dxf_info", return_value=mock.Mock(encoding="cp1252", version="AC1009")):
        with ctxZipReader(zip_path, dxf_name) as zr:
            assert isinstance(zr, ZipReader)
            assert zr.dxf_file_name == dxf_name
