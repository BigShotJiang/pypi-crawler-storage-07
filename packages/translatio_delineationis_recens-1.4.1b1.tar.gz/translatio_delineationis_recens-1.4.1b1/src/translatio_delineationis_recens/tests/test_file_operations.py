"""
Tests for file operations in the EzDXF library.
"""
import os
import pytest
from pathlib import Path
import io

import ezdxf
from ezdxf.lldxf.const import DXFValueError, DXFStructureError


class TestFileOperations:
    """Tests for file operations."""
    
    def test_save_and_read(self, basic_drawing, temp_dxf_file):
        """Test saving and reading a DXF file."""
        # Save the drawing
        basic_drawing.saveas(temp_dxf_file)
        
        # Check that the file exists
        assert os.path.exists(temp_dxf_file)
        
        # Read the file
        doc = ezdxf.readfile(temp_dxf_file)
        
        # Check that the document was read correctly
        msp = doc.modelspace()
        entities = list(msp)
        assert len(entities) == 3
        
        # Check entity types
        entity_types = [entity.dxftype() for entity in entities]
        assert "LINE" in entity_types
        assert "CIRCLE" in entity_types
        assert "TEXT" in entity_types
    
    def test_read_from_stream(self, saved_drawing):
        """Test reading a DXF file from a stream."""
        _, filepath = saved_drawing
        
        # For binary streams, we need to use readfile instead of read
        doc = ezdxf.readfile(filepath)
        
        # Check that the document was read correctly
        msp = doc.modelspace()
        entities = list(msp)
        assert len(entities) == 3
    
    def test_invalid_file_path(self):
        """Test handling of invalid file paths."""
        with pytest.raises(IOError):
            ezdxf.readfile("non_existent_file.dxf")
    
    def test_corrupt_dxf_file(self, tmpdir):
        """Test handling of corrupt DXF files."""
        # Create a corrupt DXF file
        corrupt_file = os.path.join(tmpdir, "corrupt.dxf")
        with open(corrupt_file, "w") as f:
            f.write("This is not a valid DXF file")
        
        # Try to read the corrupt file
        with pytest.raises((DXFStructureError, IOError)):
            ezdxf.readfile(corrupt_file)


class TestDXFVersionCompatibility:
    """Tests for DXF version compatibility."""
    
    @pytest.mark.parametrize("version", ["R12", "R2000", "R2004", "R2007", "R2010", "R2013", "R2018"])
    def test_roundtrip(self, version, tmpdir):
        """Test saving and loading files with different DXF versions."""
        # Create a drawing with the specified version
        doc = ezdxf.new(version)
        msp = doc.modelspace()
        
        # Add some entities
        msp.add_line((0, 0), (10, 10))
        msp.add_circle((5, 5), radius=2.5)
        
        # Save the drawing
        filepath = os.path.join(tmpdir, f"{version}.dxf")
        doc.saveas(filepath)
        
        # Read the drawing back
        loaded_doc = ezdxf.readfile(filepath)
        
        # Check that the version is preserved
        assert loaded_doc.dxfversion == doc.dxfversion
        
        # Check that the entities are preserved
        loaded_msp = loaded_doc.modelspace()
        entities = list(loaded_msp)
        assert len(entities) == 2
        
        entity_types = [entity.dxftype() for entity in entities]
        assert "LINE" in entity_types
        assert "CIRCLE" in entity_types


class TestFileFormats:
    """Tests for different file formats."""
    
    def test_binary_dxf(self, basic_drawing, tmpdir):
        """Test saving and loading binary DXF files."""
        # Save as binary DXF
        filepath = os.path.join(tmpdir, "binary.dxf")
        basic_drawing.saveas(filepath)
        
        # Read the binary DXF
        doc = ezdxf.readfile(filepath)
        
        # Check that the document was read correctly
        msp = doc.modelspace()
        entities = list(msp)
        assert len(entities) == 3
