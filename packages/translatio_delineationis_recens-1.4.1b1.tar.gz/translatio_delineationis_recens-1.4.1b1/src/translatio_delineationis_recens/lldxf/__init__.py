# Low Level DXF modules
# Copyright (c) 2011-2022, Manfred Moitzi
# License: MIT License
"""
ezDXF lldxf Package
-------------------
Provides low-level DXF file parsing, tag processing, and serialization utilities.
Responsible for reading, writing, and interpreting raw DXF data structures and tags for use by higher-level ezDXF modules.
"""
