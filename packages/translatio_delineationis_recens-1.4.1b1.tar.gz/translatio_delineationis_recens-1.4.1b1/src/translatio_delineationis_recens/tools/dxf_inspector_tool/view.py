import tkinter as tk
from tkinter import ttk, filedialog
import ttkbootstrap as tb
from typing import Callable, Optional

class DXFInspectorView:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("DXF Inspector")
        self.root.geometry("900x600")
        self.style = tb.Style("darkly")
        self._open_file_callback: Optional[Callable[[str], None]] = None
        self._setup_menu()
        self._setup_icons()
        self._setup_ui()

    def _setup_icons(self):
        # Use simple built-in bitmaps for demonstration; replace with custom icons as needed
        self.icons = {
            'root': tk.PhotoImage(width=16, height=16),  # blank for now
            'drawing_data': tk.PhotoImage(width=16, height=16),
            'blocks': tk.PhotoImage(width=16, height=16),
            'layers': tk.PhotoImage(width=16, height=16),
            'model_space': tk.PhotoImage(width=16, height=16),
            'paper_space': tk.PhotoImage(width=16, height=16),
            'layout': tk.PhotoImage(width=16, height=16),
            'entity': tk.PhotoImage(width=16, height=16),
        }
        # Draw simple shapes for demonstration (e.g., rectangles, lines)
        # Root icon: filled rectangle
        self.icons['root'].put("#00bcd4", to=(2,2,13,13))
        # Drawing Data: blue rectangle
        self.icons['drawing_data'].put("#2196f3", to=(2,2,13,13))
        # Blocks: green
        self.icons['blocks'].put("#4caf50", to=(2,2,13,13))
        # Layers: orange
        self.icons['layers'].put("#ff9800", to=(2,2,13,13))
        # Model Space: purple
        self.icons['model_space'].put("#9c27b0", to=(2,2,13,13))
        # Paper Space: grey
        self.icons['paper_space'].put("#607d8b", to=(2,2,13,13))
        # Layout: yellow
        self.icons['layout'].put("#ffeb3b", to=(2,2,13,13))
        # Entity: white
        self.icons['entity'].put("#ffffff", to=(2,2,13,13))

    def _setup_menu(self):
        menubar = tk.Menu(self.root)
        filemenu = tk.Menu(menubar, tearoff=0)
        filemenu.add_command(label="Open...", command=self._on_open_file)
        filemenu.add_separator()
        filemenu.add_command(label="Exit", command=self.root.quit)
        menubar.add_cascade(label="File", menu=filemenu)
        self.root.config(menu=menubar)

    def _on_open_file(self):
        filename = filedialog.askopenfilename(
            title="Open DXF File",
            filetypes=[("DXF files", "*.dxf"), ("All files", "*.*")]
        )
        if filename and self._open_file_callback:
            self._open_file_callback(filename)

    def set_on_open_file(self, callback: Callable[[str], None]):
        self._open_file_callback = callback

    def _setup_ui(self):
        self.paned = ttk.PanedWindow(self.root, orient=tk.HORIZONTAL)
        self.paned.pack(fill=tk.BOTH, expand=1)

        # Left: Treeview
        left_frame = ttk.Frame(self.paned)
        self.tree = ttk.Treeview(left_frame, show="tree")
        self.tree.pack(fill=tk.BOTH, expand=1, padx=5, pady=5)
        self.paned.add(left_frame, weight=1)

        # Right: Text area
        right_frame = ttk.Frame(self.paned)
        self.text = tk.Text(right_frame, wrap=tk.WORD, font=("Consolas", 11))
        self.text.pack(fill=tk.BOTH, expand=1, padx=5, pady=5)
        self.paned.add(right_frame, weight=2)

        # Status bar at the bottom
        self.status_var = tk.StringVar(value="Ready")
        self.status_bar = ttk.Label(self.root, textvariable=self.status_var, anchor="w", style="secondary.TLabel")
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)

    def set_status(self, message: str):
        self.status_var.set(message)

    def insert_tree_data(self, structure: dict):
        def icon_for_node(name: str):
            lname = name.lower()
            if lname.endswith('.dxf'):
                return self.icons['root']
            elif name == 'Drawing Data':
                return self.icons['drawing_data']
            elif name == 'Blocks':
                return self.icons['blocks']
            elif name == 'Layers':
                return self.icons['layers']
            elif name == 'Model Space':
                return self.icons['model_space']
            elif name == 'Paper Space':
                return self.icons['paper_space']
            elif name.startswith('Layout'):
                return self.icons['layout']
            else:
                return self.icons['entity']
        def insert_node(parent, node):
            # If node is a dict with 'name' and 'handle', use handle as unique ID but name as label
            if isinstance(node, dict) and 'name' in node and 'handle' in node:
                name = node['name']
                icon = icon_for_node(name)
                node_id = self.tree.insert(parent, 'end', text=name, image=icon, values=(node['handle'],))
            else:
                name = node['name'] if isinstance(node, dict) else str(node)
                icon = icon_for_node(name)
                node_id = self.tree.insert(parent, 'end', text=name, image=icon)
            if isinstance(node, dict) and 'children' in node:
                for child in node['children']:
                    insert_node(node_id, child)
        self.tree.delete(*self.tree.get_children())
        insert_node('', structure)

    # _icon_for_node removed (icon support temporarily disabled)

    def set_on_tree_select(self, callback: Callable[[str], None]):
        def handler(event):
            item = self.tree.focus()
            if item:
                text = self.tree.item(item, 'text')
                callback(text)
        self.tree.bind('<<TreeviewSelect>>', handler)

    def update_text(self, content: str):
        self.text.config(state=tk.NORMAL)
        self.text.delete('1.0', tk.END)
        self.text.insert(tk.END, content)
        self.text.config(state=tk.DISABLED)
