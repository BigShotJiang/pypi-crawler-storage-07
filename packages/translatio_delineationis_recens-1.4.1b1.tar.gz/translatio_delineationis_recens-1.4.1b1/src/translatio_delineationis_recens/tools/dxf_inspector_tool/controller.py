import tkinter as tk
from .model import DXFModel
from .view import DXFInspectorView

class DXFInspectorController:
    def __init__(self, root: tk.Tk, filename: str):
        print("[DXFInspectorController] Initializing controller.")
        self.root = root
        self.model = DXFModel()
        self.view = DXFInspectorView(root)
        print("[DXFInspectorController] View created.")
        self.view.set_on_open_file(self.open_new_file)
        self.view.set_on_tree_select(self.on_tree_select)
        if filename:
            print(f"[DXFInspectorController] Loading file at startup: {filename}")
            self.open_new_file(filename)
        else:
            print("[DXFInspectorController] Started with no file loaded.")
            self.view.update_text("Use File > Open... to load a DXF file.")

    def _setup(self):
        # Deprecated; logic moved to __init__
        pass

    def open_new_file(self, filename: str):
        print(f"[DXFInspectorController] open_new_file called with: {filename}")
        try:
            self.model = DXFModel(filename)
            structure = self.model.get_tree_structure()
            self.view.insert_tree_data(structure)
            self.root.title(f"DXF Inspector - {filename}")
            self.view.update_text("")
            print("[DXFInspectorController] File loaded and tree updated.")
        except Exception as e:
            print(f"[DXFInspectorController] Failed to load file: {e}")
            self.view.update_text(f"Failed to load file: {e}")

    def on_tree_select(self, node_name: str):
        # Try to infer type of node and fetch info
        # For entity nodes, use handle from the tree node's values if available
        tree = self.view.tree
        item_id = tree.focus()
        values = tree.item(item_id, 'values') if item_id else []
        handle = values[0] if values else None
        if node_name == 'Blocks':
            self.view.update_text("Select a block to view details.")
        elif node_name == 'Layers':
            self.view.update_text("Select a layer to view details.")
        elif node_name in [b.name for b in self.model.doc.blocks]:
            self.view.update_text(self.model.get_block_info(node_name))
        elif node_name in [l.dxf.name for l in self.model.doc.layers]:
            self.view.update_text(self.model.get_layer_info(node_name))
        elif handle and handle in self.model.doc.entitydb:
            # Show the entity attribute list for DXF entity nodes (using handle)
            self.view.update_text(self.model.list_entity_attributes(handle))
        elif node_name.isalnum() and node_name in self.model.doc.entitydb:
            # Fallback for legacy nodes
            self.view.update_text(self.model.list_entity_attributes(node_name))
        else:
            self.view.update_text(node_name)

# Entry point for running the inspector as a script
def run_inspector(filename: str):
    root = tk.Tk()
    DXFInspectorController(root, filename)
    root.mainloop()
