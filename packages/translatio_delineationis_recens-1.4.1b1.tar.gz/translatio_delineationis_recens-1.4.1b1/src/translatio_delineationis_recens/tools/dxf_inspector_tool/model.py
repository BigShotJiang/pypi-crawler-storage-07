import ezdxf
from typing import Any, Dict, List

class DXFModel:
    def __init__(self, filename: str = ""):
        self.doc = None
        self.filename = filename
        if filename:
            self.doc = ezdxf.readfile(filename)

    def clear(self):
        self.doc = None
        self.filename = ""

    def get_tree_structure(self) -> Dict[str, Any]:
        """
        Returns a nested dictionary representing the DXF structure for the treeview.
        """
        structure = {
            'name': self.filename,
            'children': [
                {
                    'name': 'Drawing Data',
                    'children': [
                        {'name': 'Blocks', 'children': [b.name for b in self.doc.blocks]},
                        {'name': 'Layers', 'children': [l.dxf.name for l in self.doc.layers]},
                    ]
                },
                {
                    'name': 'Model Space',
                    'children': [
                        {'name': e.dxftype(), 'handle': e.dxf.handle} for e in self.doc.modelspace()
                    ],
                },
                {
                    'name': 'Paper Space',
                    'children': [
                        {
                            'name': layout.dxf.name,
                            'children': [
                                {'name': e.dxftype(), 'handle': e.dxf.handle} for e in layout if layout.dxf.name != 'Model'
                            ],
                        } for layout in self.doc.layouts if layout.dxf.name != 'Model'
                    ]
                }
            ]
        }
        return structure

    def get_entity_info(self, handle: str) -> str:
        """
        Returns a string with detailed information about an entity by its handle.
        """
        try:
            entity = self.doc.entitydb[handle]
            return str(entity)
        except Exception as e:
            return f"Entity not found: {e}"

    def list_entity_attributes(self, handle: str) -> str:
        """
        Returns a formatted list of DXF attributes for the given entity handle.
        """
        try:
            with open("dxf_inspector_debug.log", "a", encoding="utf-8") as log:
                log.write(f"[DEBUG] list_entity_attributes called with handle: {handle}\n")
            entity = self.doc.entitydb[handle]
            # Try to use all_existing_dxf_attribs (if available)
            if hasattr(entity.dxf, 'all_existing_dxf_attribs'):
                attribs = entity.dxf.all_existing_dxf_attribs()
                with open("dxf_inspector_debug.log", "a", encoding="utf-8") as log:
                    log.write(f"[DEBUG] Used all_existing_dxf_attribs, type: {type(attribs)}, value: {attribs}\n")
                if isinstance(attribs, dict):
                    attribs = attribs.items()
            else:
                attribs = entity.dxfattribs()
                with open("dxf_inspector_debug.log", "a", encoding="utf-8") as log:
                    log.write(f"[DEBUG] Used dxfattribs, type: {type(attribs)}, value: {attribs}\n")
                if hasattr(attribs, 'items'):
                    attribs = attribs.items()
                    with open("dxf_inspector_debug.log", "a", encoding="utf-8") as log:
                        log.write(f"[DEBUG] Converted attribs to items, type: {type(attribs)}, value: {list(attribs)}\n")
                    attribs = attribs if isinstance(attribs, list) else list(attribs)
            # Defensive: ensure attribs is iterable of (k, v)
            lines = []
            for item in attribs:
                if isinstance(item, tuple) and len(item) == 2:
                    k, v = item
                    lines.append(f"{k}: {v}")
                else:
                    with open("dxf_inspector_debug.log", "a", encoding="utf-8") as log:
                        log.write(f"[DEBUG] Unexpected item in attribs: {item} (type: {type(item)})\n")
                    lines.append(f"[UNEXPECTED ITEM: {item}]")
            return '\n'.join(lines) if lines else 'No attributes.'
        except Exception as e:
            with open("dxf_inspector_debug.log", "a", encoding="utf-8") as log:
                log.write(f"[DEBUG] Exception in list_entity_attributes: {e}\n")
            return f"Entity not found: {e}"

    def get_block_info(self, block_name: str) -> str:
        try:
            block = self.doc.blocks[block_name]
            return str(block)
        except Exception as e:
            return f"Block not found: {e}"

    def get_layer_info(self, layer_name: str) -> str:
        try:
            layer = self.doc.layers.get(layer_name)
            return str(layer)
        except Exception as e:
            return f"Layer not found: {e}"
