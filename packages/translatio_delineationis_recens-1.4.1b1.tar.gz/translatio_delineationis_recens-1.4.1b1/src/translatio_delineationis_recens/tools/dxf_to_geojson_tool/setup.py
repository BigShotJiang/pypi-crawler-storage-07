#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from setuptools import setup, find_packages

# Read the version from __init__.py
version = {}
with open("dxf_to_geojson/__init__.py") as f:
    exec(f.read(), version)

# Read the long description from README.md
with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="dxf-to-geojson",
    version=version["__version__"],
    description="A tool to convert DXF files to GeoJSON format",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Your Name",
    author_email="your.email@example.com",
    url="https://github.com/yourusername/dxf-to-geojson",
    packages=find_packages(),
    python_requires=">=3.7",
    install_requires=[
        "ezdxf>=1.0.0",
        "ttkbootstrap>=1.10.1",
    ],
    extras_require={
        "dev": [
            "pytest>=6.0",
            "pytest-cov",
            "mypy",
            "pylint",
            "coverage",
        ],
    },
    entry_points={
        "console_scripts": [
            "dxf2geojson=dxf_to_geojson.convert:main",
        ],
        "gui_scripts": [
            "dxf2geojson-gui=dxf_to_geojson.__main__:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Scientific/Engineering :: GIS",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    keywords="dxf geojson gis cad",
    project_urls={
        "Bug Reports": "https://github.com/yourusername/dxf-to-geojson/issues",
        "Source": "https://github.com/yourusername/dxf-to-geojson",
    },
)
