#!/usr/bin/env python
"""
Command-line interface for DXF to GeoJSON conversion.
"""
import argparse
import os
import sys
from .model import DxfToGeoJSONModel

def main():
    """Main entry point for the command-line interface."""
    parser = argparse.ArgumentParser(
        description='Convert DXF files to GeoJSON format.',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    
    parser.add_argument(
        'input',
        help='Input DXF file path',
    )
    
    parser.add_argument(
        'output',
        nargs='?',
        help='Output GeoJSON file path (default: <input>.geojson)',
    )
    
    parser.add_argument(
        '--version',
        action='version',
        version=f'%(prog)s {__import__(__package__).__version__}'
    )
    
    args = parser.parse_args()
    
    # Set default output path if not provided
    if not args.output:
        base_name = os.path.splitext(args.input)[0]
        args.output = f"{base_name}.geojson"
    
    # Check if input file exists
    if not os.path.exists(args.input):
        print(f"Error: Input file '{args.input}' not found.", file=sys.stderr)
        return 1
    
    # Check if output directory exists
    output_dir = os.path.dirname(os.path.abspath(args.output))
    if not os.path.exists(output_dir):
        print(f"Error: Output directory '{output_dir}' does not exist.", file=sys.stderr)
        return 1
    
    # Perform the conversion
    print(f"Converting {args.input} to {args.output}...")
    
    try:
        model = DxfToGeoJSONModel()
        
        print("Loading DXF file...")
        if not model.load_dxf(args.input):
            print(f"Error: Failed to load DXF file '{args.input}'.", file=sys.stderr)
            return 1
        
        print("Converting to GeoJSON...")
        if not model.convert_to_geojson():
            print("Error: Failed to convert DXF to GeoJSON.", file=sys.stderr)
            return 1
        
        print(f"Saving to {args.output}...")
        if not model.save_geojson(args.output):
            print(f"Error: Failed to save GeoJSON file '{args.output}'.", file=sys.stderr)
            return 1
        
        print("Conversion completed successfully!")
        return 0
        
    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        return 1

if __name__ == "__main__":
    sys.exit(main())
