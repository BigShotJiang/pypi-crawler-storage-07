"""View for DXF to GeoJSON converter."""
import tkinter as tk
from tkinter import ttk, filedialog
from typing import Callable, Optional, Tuple
import ttkbootstrap as ttk
from ttkbootstrap.constants import *

class DxfToGeoJSONView(ttk.Frame):
    """Main application view for DXF to GeoJSON converter."""
    
    def __init__(self, master=None, **kwargs):
        super().__init__(master, **kwargs)
        self.master = master
        self.master.title("DXF to GeoJSON Converter")
        self.master.geometry("700x300")
        
        # Set application style
        self.style = ttk.Style()
        self.style.configure('TButton', padding=5)
        self.style.configure('TLabel', padding=5)
        
        # Callback functions
        self.browse_dxf_callback: Optional[Callable] = None
        self.browse_geojson_callback: Optional[Callable] = None
        self.convert_callback: Optional[Callable] = None
        
        self._setup_ui()
        
    def _setup_ui(self):
        """Set up the user interface."""
        # Main container
        self.main_frame = ttk.Frame(self.master, padding="10")
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        # DXF File Selection
        ttk.Label(self.main_frame, text="DXF File:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.dxf_path_var = tk.StringVar()
        self.dxf_entry = ttk.Entry(self.main_frame, textvariable=self.dxf_path_var, width=60)
        self.dxf_entry.grid(row=0, column=1, padx=5, pady=5, sticky=tk.EW)
        
        self.browse_dxf_btn = ttk.Button(
            self.main_frame, 
            text="Browse...", 
            command=self._on_browse_dxf,
            style='primary.TButton'
        )
        self.browse_dxf_btn.grid(row=0, column=2, padx=5, pady=5)
        
        # GeoJSON File Selection
        ttk.Label(self.main_frame, text="GeoJSON File:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.geojson_path_var = tk.StringVar()
        self.geojson_entry = ttk.Entry(self.main_frame, textvariable=self.geojson_path_var, width=60)
        self.geojson_entry.grid(row=1, column=1, padx=5, pady=5, sticky=tk.EW)
        
        self.browse_geojson_btn = ttk.Button(
            self.main_frame, 
            text="Browse...", 
            command=self._on_browse_geojson,
            style='primary.TButton'
        )
        self.browse_geojson_btn.grid(row=1, column=2, padx=5, pady=5)
        
        # Convert Button
        self.convert_btn = ttk.Button(
            self.main_frame, 
            text="Convert to GeoJSON", 
            command=self._on_convert,
            style='success.TButton',
            width=20
        )
        self.convert_btn.grid(row=2, column=1, pady=20)
        
        # Status Bar
        self.status_var = tk.StringVar()
        self.status_var.set("Ready")
        self.status_bar = ttk.Label(
            self.main_frame, 
            textvariable=self.status_var, 
            relief=tk.SUNKEN, 
            anchor=tk.W,
            padding=5
        )
        self.status_bar.grid(row=3, column=0, columnspan=3, sticky=tk.EW, pady=10)
        
        # Configure grid weights
        self.main_frame.columnconfigure(1, weight=1)
        
    def _on_browse_dxf(self):
        """Handle DXF browse button click."""
        if self.browse_dxf_callback:
            self.browse_dxf_callback()
    
    def _on_browse_geojson(self):
        """Handle GeoJSON browse button click."""
        if self.browse_geojson_callback:
            self.browse_geojson_callback()
    
    def _on_convert(self):
        """Handle convert button click."""
        if self.convert_callback:
            self.convert_callback()
    
    def get_dxf_path(self) -> str:
        """Get the selected DXF file path."""
        return self.dxf_path_var.get()
    
    def get_geojson_path(self) -> str:
        """Get the selected GeoJSON file path."""
        return self.geojson_path_var.get()
    
    def set_dxf_path(self, path: str):
        """Set the DXF file path."""
        self.dxf_path_var.set(path)
    
    def set_geojson_path(self, path: str):
        """Set the GeoJSON file path."""
        self.geojson_path_var.set(path)
    
    def set_status(self, message: str):
        """Update the status bar message."""
        self.status_var.set(message)
        self.update_idletasks()
    
    def show_error(self, title: str, message: str):
        """Show an error message dialog."""
        tk.messagebox.showerror(title, message)
    
    def show_info(self, title: str, message: str):
        """Show an information message dialog."""
        tk.messagebox.showinfo(title, message)
    
    def set_convert_button_state(self, enabled: bool):
        """Enable or disable the convert button."""
        state = tk.NORMAL if enabled else tk.DISABLED
        self.convert_btn.config(state=state)

    def ask_save_filename(self, initialfile: str = "") -> str:
        """Show save file dialog."""
        return filedialog.asksaveasfilename(
            defaultextension=".geojson",
            filetypes=[("GeoJSON files", "*.geojson"), ("All files", "*.*")],
            initialfile=initialfile
        )
    
    def ask_open_filename(self) -> str:
        """Show open file dialog."""
        return filedialog.askopenfilename(
            filetypes=[("DXF files", "*.dxf"), ("All files", "*.*")]
        )
