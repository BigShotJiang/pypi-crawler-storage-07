"""Controller for DXF to GeoJSON converter."""
import os
from typing import Optional
from .model import DxfToGeoJSONModel
from .view import DxfToGeoJSONView

class DxfToGeoJSONController:
    """Controller for the DXF to GeoJSON conversion process."""
    
    def __init__(self, root):
        """Initialize the controller with model and view."""
        self.model = DxfToGeoJSONModel()
        self.view = DxfToGeoJSONView(root)
        self._setup_handlers()
        
    def _setup_handlers(self):
        """Set up event handlers for the view."""
        self.view.browse_dxf_callback = self.browse_dxf
        self.view.browse_geojson_callback = self.browse_geojson
        self.view.convert_callback = self.convert
        
        # Set initial state
        self.view.set_convert_button_state(False)
        
    def browse_dxf(self):
        """Handle DXF file selection."""
        filepath = self.view.ask_open_filename()
        if filepath:
            self.view.set_dxf_path(filepath)
            
            # Auto-generate GeoJSON path
            base_path = os.path.splitext(filepath)[0] + '.geojson'
            self.view.set_geojson_path(base_path)
            
            # Enable convert button if both paths are set
            if self.view.get_geojson_path():
                self.view.set_convert_button_state(True)
    
    def browse_geojson(self):
        """Handle GeoJSON file selection."""
        initial_file = self.view.get_geojson_path()
        if not initial_file and self.view.get_dxf_path():
            initial_file = os.path.splitext(self.view.get_dxf_path())[0] + '.geojson'
            
        filepath = self.view.ask_save_filename(initial_file or 'output.geojson')
        if filepath:
            self.view.set_geojson_path(filepath)
            
            # Enable convert button if both paths are set
            if self.view.get_dxf_path():
                self.view.set_convert_button_state(True)
    
    def convert(self):
        """Handle the conversion process."""
        dxf_path = self.view.get_dxf_path()
        geojson_path = self.view.get_geojson_path()
        
        if not dxf_path or not geojson_path:
            self.view.show_error("Error", "Please select both DXF and GeoJSON files.")
            return
            
        if not os.path.exists(dxf_path):
            self.view.show_error("Error", f"DXF file not found: {dxf_path}")
            return
            
        try:
            self.view.set_status("Loading DXF file...")
            if not self.model.load_dxf(dxf_path):
                self.view.show_error("Error", f"Failed to load DXF file: {dxf_path}")
                return
                
            self.view.set_status("Converting to GeoJSON...")
            if not self.model.convert_to_geojson():
                self.view.show_error("Error", "Failed to convert DXF to GeoJSON.")
                return
                
            self.view.set_status("Saving GeoJSON file...")
            if not self.model.save_geojson(geojson_path):
                self.view.show_error("Error", f"Failed to save GeoJSON file: {geojson_path}")
                return
                
            self.view.set_status("Conversion completed successfully!")
            self.view.show_info("Success", f"Successfully converted DXF to GeoJSON.\n\nSaved to: {geojson_path}")
            
        except Exception as e:
            self.view.show_error("Error", f"An error occurred during conversion: {str(e)}")
            self.view.set_status("Error during conversion.")
        finally:
            self.view.set_convert_button_state(True)
    
    def run(self):
        """Start the application."""
        self.view.mainloop()
