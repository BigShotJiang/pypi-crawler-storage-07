"""
DXF to GeoJSON Converter
-----------------------
A tool to convert DXF entities to GeoJSON format.
"""

__version__ = "0.1.0"
