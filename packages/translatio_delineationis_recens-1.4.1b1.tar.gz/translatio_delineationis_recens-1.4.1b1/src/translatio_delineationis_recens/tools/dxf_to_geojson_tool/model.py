"""Model for DXF to GeoJSON conversion."""
import io
import json
import os
from typing import Dict, List, Optional, Union, Any, Tuple
import ezdxf
from ezdxf.document import Drawing
from ezdxf.entities import DXFGraphic, LWPolyline, Line, Point, Polyline, Circle, Arc
import math


class DxfToGeoJSONModel:
    """Handles the conversion of DXF entities to GeoJSON format."""

    def __init__(self):
        self.dxf_doc: Optional[Drawing] = None
        self.geojson_data: Dict[str, Any] = {
            "type": "FeatureCollection",
            "features": []
        }

    def load_dxf(self, filepath: str) -> bool:
        """Load a DXF file with enhanced error handling and debugging.
        
        Args:
            filepath: Path to the DXF file
            
        Returns:
            bool: True if loaded successfully, False otherwise
        """
        def print_file_info(path):
            """Print basic file information for debugging."""
            try:
                size = os.path.getsize(path)
                print(f"  File size: {size} bytes")
                
                # Print first few lines of the file
                with open(path, 'r', encoding='utf-8', errors='replace') as f:
                    print("  First 5 lines of the file:")
                    for i, line in enumerate(f):
                        if i < 5:
                            print(f"    {i+1}: {line.strip()}")
                        else:
                            break
                return True
            except Exception as e:
                print(f"  Error reading file info: {e}")
                return False

        try:
            print(f"\n=== Loading DXF file: {filepath} ===")
            
            # Verify file exists and is not empty
            if not os.path.exists(filepath):
                print(f"Error: File does not exist: {filepath}")
                return False
                
            if os.path.getsize(filepath) == 0:
                print("Error: File is empty")
                return False
            
            print("File exists and is not empty")
            
            # Print file info for debugging
            print("\nFile information:")
            print_file_info(filepath)
            
            # Try different loading methods
            methods = [
                self._try_load_binary_dxf,
                self._try_load_text_dxf,
                self._try_direct_load,
            ]
            
            for method in methods:
                if method(filepath):
                    # Verify the document was loaded and has content
                    if self._verify_dxf_document():
                        return True
            
            print("\nAll DXF loading attempts failed")
            self.dxf_doc = None
            return False
            
        except Exception as e:
            print(f"\n!!! Unexpected error loading DXF file: {str(e)}")
            import traceback
            traceback.print_exc()
            self.dxf_doc = None
            return False
    
    def _try_load_binary_dxf(self, filepath):
        """Try to load a binary DXF file."""
        print("\nAttempting to load as binary DXF...")
        try:
            with open(filepath, 'rb') as f:
                # Check if it's a binary DXF by looking for the binary marker
                header = f.read(22)
                f.seek(0)
                
                if header.startswith(b'AC10'):
                    print("  Detected binary DXF signature")
                    self.dxf_doc = ezdxf.read(f)
                    print("  Successfully loaded binary DXF")
                    return True
                else:
                    print("  Not a binary DXF (missing AC10 header)")
                    return False
        except Exception as e:
            print(f"  Error loading binary DXF: {e}")
            return False
    
    def _try_load_text_dxf(self, filepath):
        """Try to load a text DXF file with different encodings."""
        encodings = ['utf-8', 'cp1252', 'latin-1']
        
        for encoding in encodings:
            print(f"\nAttempting to load as text DXF with {encoding} encoding...")
            try:
                with open(filepath, 'r', encoding=encoding) as f:
                    content = f.read()
                
                # Create a temporary file-like object
                from io import StringIO
                file_obj = StringIO(content)
                
                # Try to load the DXF
                self.dxf_doc = ezdxf.read(file_obj)
                print(f"  Successfully loaded text DXF with {encoding} encoding")
                return True
                
            except Exception as e:
                print(f"  Failed to load with {encoding}: {e}")
                continue
        
        return False
    
    def _try_direct_load(self, filepath):
        """Try to load the DXF file directly with ezdxf.read()."""
        print("\nAttempting direct ezdxf.read()...")
        try:
            self.dxf_doc = ezdxf.read(filepath)
            print("  Successfully loaded with direct ezdxf.read()")
            return True
        except Exception as e:
            print(f"  Direct ezdxf.read() failed: {e}")
            return False
    
    def _verify_dxf_document(self):
        """Verify that the loaded DXF document is valid and has content."""
        if not self.dxf_doc:
            print("  No document loaded")
            return False
        
        print("\nDocument verification:")
        print(f"  DXF Version: {getattr(self.dxf_doc, 'acad_release', 'N/A')}")
        print(f"  DXF Encoding: {getattr(self.dxf_doc, 'encoding', 'N/A')}")
        
        # Check modelspace
        try:
            msp = self.dxf_doc.modelspace()
            msp_entities = list(msp)
            print(f"  Found {len(msp_entities)} entities in modelspace")
            
            # Check all entities
            try:
                all_entities = list(self.dxf_doc.entities)
                print(f"  Found {len(all_entities)} total entities in document")
                
                # Print entity types for debugging
                if all_entities:
                    print("  Entity types in document:")
                    entity_types = {}
                    for e in all_entities:
                        try:
                            t = e.dxftype()
                            entity_types[t] = entity_types.get(t, 0) + 1
                        except:
                            pass
                    for t, count in entity_types.items():
                        print(f"    {t}: {count}")
                
            except Exception as e:
                print(f"  Error enumerating all entities: {e}")
            
            return len(all_entities) > 0
            
        except Exception as e:
            print(f"  Error accessing modelspace: {e}")
            return False

    def _point_to_geojson(self, point: Point, layer: str, handle: str) -> Dict[str, Any]:
        """Convert a DXF point to GeoJSON Point feature."""
        return {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [point.dxf.location.x, point.dxf.location.y]
            },
            "properties": {
                "layer": layer,
                "handle": handle,
                "entity_type": "POINT"
            }
        }
        
    def _circle_to_geojson(self, circle: Circle, layer: str, handle: str) -> Dict[str, Any]:
        """Convert a DXF circle to GeoJSON Point feature with radius property."""
        return {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [circle.dxf.center.x, circle.dxf.center.y]
            },
            "properties": {
                "layer": layer,
                "handle": handle,
                "entity_type": "CIRCLE",
                "radius": circle.dxf.radius
            }
        }
        
    def _arc_to_geojson(self, arc: Arc, layer: str, handle: str, segments: int = 16) -> Dict[str, Any]:
        """Convert a DXF arc to GeoJSON LineString feature.
        
        Args:
            arc: The DXF arc entity
            layer: Layer name
            handle: Entity handle
            segments: Number of segments to approximate the arc
            
        Returns:
            GeoJSON feature dictionary
        """
        center = arc.dxf.center
        radius = arc.dxf.radius
        start_angle = math.radians(arc.dxf.start_angle)
        end_angle = math.radians(arc.dxf.end_angle)
        
        # Ensure end_angle is greater than start_angle
        if end_angle <= start_angle:
            end_angle += 2 * math.pi
            
        # Calculate points along the arc
        coordinates = []
        for i in range(segments + 1):
            # Interpolate angle
            t = i / segments
            angle = start_angle + t * (end_angle - start_angle)
            
            # Calculate point on circle
            x = center.x + radius * math.cos(angle)
            y = center.y + radius * math.sin(angle)
            coordinates.append([x, y])
            
        return {
            "type": "Feature",
            "geometry": {
                "type": "LineString",
                "coordinates": coordinates
            },
            "properties": {
                "layer": layer,
                "handle": handle,
                "entity_type": "ARC",
                "radius": radius,
                "start_angle": arc.dxf.start_angle,
                "end_angle": arc.dxf.end_angle,
                "center": [center.x, center.y]
            }
        }

    def _line_to_geojson(self, line: Line, layer: str, handle: str) -> Dict[str, Any]:
        """Convert a DXF line to GeoJSON LineString feature."""
        return {
            "type": "Feature",
            "geometry": {
                "type": "LineString",
                "coordinates": [
                    [line.dxf.start.x, line.dxf.start.y],
                    [line.dxf.end.x, line.dxf.end.y]
                ]
            },
            "properties": {
                "layer": layer,
                "handle": handle,
                "entity_type": "LINE"
            }
        }

    def _lwpolyline_to_geojson(self, lwpolyline: LWPolyline, layer: str, handle: str) -> Dict[str, Any]:
        """Convert a DXF LWPolyline to GeoJSON LineString or Polygon feature."""
        coordinates = [[point[0], point[1]] for point in lwpolyline.get_points()]
        
        # Close the polygon if it's closed in DXF
        if lwpolyline.closed and len(coordinates) > 0:
            coordinates.append(coordinates[0])
            
        geometry_type = "Polygon" if lwpolyline.closed else "LineString"
        
        # For Polygon, we need to wrap coordinates in an extra array
        if geometry_type == "Polygon":
            coordinates = [coordinates]
            
        return {
            "type": "Feature",
            "geometry": {
                "type": geometry_type,
                "coordinates": coordinates
            },
            "properties": {
                "layer": layer,
                "handle": handle,
                "entity_type": "LWPOLYLINE"
            }
        }

    def _polyline_to_geojson(self, polyline: Polyline, layer: str, handle: str) -> Optional[Dict[str, Any]]:
        """Convert a DXF Polyline to GeoJSON LineString or Polygon feature.
        
        Args:
            polyline: The DXF polyline entity
            layer: Layer name
            handle: Entity handle
            
        Returns:
            GeoJSON feature dictionary or None if conversion fails
        """
        try:
            print(f"\nProcessing POLYLINE entity (handle: {handle}, layer: {layer})")
            
            # Initialize coordinates list
            coordinates = []
            
            # Handle different polyline types and vertex access methods
            if hasattr(polyline, 'vertices'):
                try:
                    # Try to get vertices as an iterator
                    vertices = polyline.vertices() if callable(polyline.vertices) else polyline.vertices
                    
                    # Process each vertex
                    for vertex in vertices:
                        try:
                            # Handle different vertex formats
                            if hasattr(vertex, 'dxf') and hasattr(vertex.dxf, 'location'):
                                # Vertex entity with location
                                x, y = vertex.dxf.location.x, vertex.dxf.location.y
                                coordinates.append([x, y])
                            else:
                                print(f"Unsupported vertex format: {type(vertex)}")
                        except Exception as e:
                            print(f"Error processing vertex {vertex}: {e}")
                            continue
                except Exception as e:
                    print(f"Error accessing vertices: {e}")
                    return None
            
            if not coordinates:
                print("No valid coordinates found in polyline")
                return None
            
            # Check if polyline is closed
            is_closed = getattr(polyline, 'is_closed', False)
            
            # For closed polylines, ensure first and last points match
            if is_closed and len(coordinates) > 2:
                if coordinates[0] != coordinates[-1]:
                    coordinates.append(coordinates[0])
                geometry_type = "Polygon"
                # For Polygon, wrap coordinates in an extra array
                coordinates = [coordinates]
            else:
                geometry_type = "LineString"
            
            print(f"Created {geometry_type} with {len(coordinates[0] if is_closed else coordinates)} vertices")
            
            return {
                "type": "Feature",
                "geometry": {
                    "type": geometry_type,
                    "coordinates": coordinates
                },
                "properties": {
                    "layer": layer,
                    "handle": handle,
                    "entity_type": "POLYLINE",
                    "closed": is_closed,
                    "num_vertices": len(coordinates[0] if is_closed else coordinates)
                }
            }
            
        except Exception as e:
            print(f"Error converting polyline: {e}")
            import traceback
            traceback.print_exc()
            return None

    def convert_to_geojson(self) -> bool:
        """Convert loaded DXF entities to GeoJSON format.
        
        Returns:
            bool: True if conversion was successful, False otherwise
        """
        if not self.dxf_doc:
            print("No DXF document loaded")
            return False
            
        self.geojson_data = {
            "type": "FeatureCollection",
            "features": []
        }
        
        # Print DXF document information
        print("\n=== DXF Document Information ===")
        print(f"DXF Version: {getattr(self.dxf_doc, 'acad_release', 'N/A')}")
        print(f"DXF Encoding: {getattr(self.dxf_doc, 'encoding', 'N/A')}")
        print(f"DXF Units: {getattr(self.dxf_doc, 'units', 'N/A')}")
        
        try:
            # Try to get all entities from the document
            print("\n=== Attempting to access document entities ===")
            
            # First, try to get modelspace
            try:
                msp = self.dxf_doc.modelspace()
                print(f"Modelspace type: {type(msp).__name__}")
                msp_entities = list(msp)
                print(f"Found {len(msp_entities)} entities in modelspace")
            except Exception as e:
                print(f"Error accessing modelspace: {e}")
                msp_entities = []
            
            # Try to get all entities
            try:
                all_entities = list(self.dxf_doc.entities)
                print(f"Found {len(all_entities)} total entities in document")
            except Exception as e:
                print(f"Error accessing document entities: {e}")
                all_entities = []
            
            # If we have modelspace entities, use those, otherwise use all entities
            entities_to_process = msp_entities if msp_entities else all_entities
            
            if not entities_to_process:
                print("\n=== No entities found to process ===")
                print("Available document attributes:", dir(self.dxf_doc))
                return False
            
            # Print entity information
            print("\n=== Entities to Process ===")
            for i, entity in enumerate(entities_to_process, 1):
                try:
                    dxftype = entity.dxftype()
                    layer = getattr(entity.dxf, 'layer', '0')
                    handle = getattr(entity.dxf, 'handle', '0')
                    print(f"  {i}. {dxftype} (handle: {handle}, layer: {layer})")
                except Exception as e:
                    print(f"  {i}. [Error getting entity info: {str(e)}]")
            
            # Process entities
            print("\n=== Processing Entities ===")
            converted_count = 0
            
            for i, entity in enumerate(entities_to_process, 1):
                try:
                    if not isinstance(entity, DXFGraphic):
                        print(f"\n--- Entity {i} ---")
                        print(f"Skipping non-graphic entity: {entity.dxftype()}")
                        continue
                        
                    layer = getattr(entity.dxf, 'layer', '0')
                    handle = getattr(entity.dxf, 'handle', '0')
                    dxf_type = entity.dxftype()
                    
                    print(f"\n--- Entity {i} ---")
                    print(f"Type: {dxf_type}")
                    print(f"Layer: {layer}")
                    print(f"Handle: {handle}")
                    
                    # Process based on entity type
                    try:
                        if dxf_type == 'POINT':
                            print(f"Point at: {entity.dxf.location}")
                            feature = self._point_to_geojson(entity, layer, handle)
                        elif dxf_type == 'LINE':
                            print(f"Line from {entity.dxf.start} to {entity.dxf.end}")
                            feature = self._line_to_geojson(entity, layer, handle)
                        elif dxf_type in ['LWPOLYLINE', 'POLYLINE']:
                            feature = self._polyline_to_geojson(entity, layer, handle)
                        elif dxf_type == 'CIRCLE':
                            print(f"Circle at {entity.dxf.center} with radius {entity.dxf.radius}")
                            feature = self._circle_to_geojson(entity, layer, handle)
                        elif dxf_type == 'ARC':
                            print(f"Arc from {entity.dxf.start_angle}° to {entity.dxf.end_angle}° at {entity.dxf.center}")
                            feature = self._arc_to_geojson(entity, layer, handle)
                        else:
                            print(f"Unsupported entity type: {dxf_type}")
                            continue
                        
                        if feature:
                            self.geojson_data["features"].append(feature)
                            converted_count += 1
                            print(f"Successfully converted {dxf_type} to GeoJSON")
                        
                    except Exception as e:
                        print(f"Error converting entity {dxf_type}: {e}")
                        import traceback
                        traceback.print_exc()
                        continue
                    
                except Exception as e:
                    print(f"Error processing entity {i}: {str(e)}")
                    import traceback
                    traceback.print_exc()
                    continue
            
            print("\n=== Conversion Summary ===")
            print(f"Successfully converted {converted_count} out of {len(entities_to_process)} entities to GeoJSON")
            
            if converted_count > 0:
                print("\nSample of converted features:")
                for i, feature in enumerate(self.geojson_data["features"][:3], 1):
                    print(f"  {i}. {feature['geometry']['type']} on layer {feature['properties']['layer']}")
            
            return converted_count > 0
            
        except Exception as e:
            print(f"\n!!! ERROR in convert_to_geojson: {e}")
            import traceback
            traceback.print_exc()
            return False

    def save_geojson(self, filepath: str) -> bool:
        """Save the GeoJSON data to a file.
        
        Args:
            filepath: Path to save the GeoJSON file
            
        Returns:
            bool: True if saved successfully, False otherwise
        """
        try:
            with open(filepath, 'w') as f:
                json.dump(self.geojson_data, f, indent=2)
            return True
        except (IOError, TypeError) as e:
            print(f"Error saving GeoJSON file: {e}")
            return False
