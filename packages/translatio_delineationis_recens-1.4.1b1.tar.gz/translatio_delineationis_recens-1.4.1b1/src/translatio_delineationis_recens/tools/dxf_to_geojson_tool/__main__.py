"""
Main entry point for the DXF to GeoJSON converter package.
"""
import sys

def main():
    """Run the appropriate interface based on command-line arguments."""
    # If no arguments or -h/--help, show help for the command-line interface
    if len(sys.argv) == 1 or sys.argv[1] in ('-h', '--help'):
        from .convert import main as cli_main
        sys.exit(cli_main())
    
    # If first argument is 'gui', run the GUI
    if sys.argv[1] == 'gui':
        from .controller import DxfToGeoJSONController
        import tkinter as tk
        import ttkbootstrap as ttk
        
        root = ttk.Window(
            title="DXF to GeoJSON Converter",
            themename="cosmo",
            size=(700, 300),
            resizable=(True, False)
        )
        root.minsize(600, 250)
        
        app = DxfToGeoJSONController(root)
        app.run()
    else:
        # Otherwise, run the command-line interface
        from .convert import main as cli_main
        sys.exit(cli_main())

if __name__ == "__main__":
    main()
