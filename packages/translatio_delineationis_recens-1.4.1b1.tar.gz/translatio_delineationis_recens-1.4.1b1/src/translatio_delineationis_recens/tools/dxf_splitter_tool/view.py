"""
View for DXF Splitter Tool.

Implements the GUI interface using tkinter and ttkbootstrap.
Follows the MVC architecture pattern.
"""

from __future__ import annotations
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from typing import Optional, Callable, Dict, Any, List, TYPE_CHECKING
import threading
from pathlib import Path

try:
    import ttkbootstrap as ttk_bs
    from ttkbootstrap.constants import *
    TTKBOOTSTRAP_AVAILABLE = True
except ImportError:
    TTKBOOTSTRAP_AVAILABLE = False

if TYPE_CHECKING:
    from .model import SplitMethod, SplitProgress, SplitResult


class DxfSplitterView:
    """
    Main view for the DXF Splitter Tool.
    
    Provides a tabbed interface for different splitting methods with
    modern styling using ttkbootstrap.
    """
    
    def __init__(self, master: Optional[tk.Tk] = None):
        """Initialize the DXF Splitter view."""
        if master is None:
            if TTKBOOTSTRAP_AVAILABLE:
                self.root = ttk_bs.Window(themename="cosmo")
            else:
                self.root = tk.Tk()
        else:
            self.root = master
        
        self.root.title("DXF Splitter Tool")
        self.root.geometry("800x700")
        self.root.minsize(700, 600)
        
        # Callbacks for controller
        self.on_load_file: Optional[Callable[[str], None]] = None
        self.on_split_geographic: Optional[Callable[[Dict[str, Any]], None]] = None
        self.on_split_entity_count: Optional[Callable[[Dict[str, Any]], None]] = None
        self.on_split_entity_type: Optional[Callable[[Dict[str, Any]], None]] = None
        
        # State variables
        self.input_file_path = tk.StringVar()
        self.output_directory = tk.StringVar()
        
        # Progress tracking
        self.progress_var = tk.DoubleVar()
        self.progress_text = tk.StringVar(value="Ready")
        self.is_processing = False
        
        # Entity analysis data
        self.entity_analysis: Dict[str, Any] = {}
        
        self._setup_ui()
        self._setup_styles()
    
    def _setup_styles(self) -> None:
        """Setup custom styles for the interface."""
        if TTKBOOTSTRAP_AVAILABLE:
            # ttkbootstrap handles styling automatically
            return
        
        # Fallback styling for standard tkinter
        style = ttk.Style()
        style.theme_use('clam')
        
        # Configure custom styles
        style.configure('Title.TLabel', font=('Arial', 12, 'bold'))
        style.configure('Heading.TLabel', font=('Arial', 10, 'bold'))
    
    def _setup_ui(self) -> None:
        """Setup the main user interface."""
        # Main container
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky="nsew")
        
        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(0, weight=1)
        main_frame.rowconfigure(2, weight=1)
        
        # Title
        if TTKBOOTSTRAP_AVAILABLE:
            title_label = ttk.Label(
                main_frame, 
                text="DXF Splitter Tool",
                font=('Arial', 16, 'bold')
            )
        else:
            title_label = ttk.Label(
                main_frame, 
                text="DXF Splitter Tool",
                style='Title.TLabel'
            )
        title_label.grid(row=0, column=0, pady=(0, 20))
        
        # File selection section
        self._create_file_selection_section(main_frame, row=1)
        
        # Main notebook for splitting methods
        self.notebook = ttk.Notebook(main_frame)
        self.notebook.grid(row=2, column=0, sticky="nsew", pady=(10, 0))
        
        # Create tabs for different splitting methods
        self._create_geographic_tab()
        self._create_entity_count_tab()
        self._create_entity_type_tab()
        
        # Progress section
        self._create_progress_section(main_frame, row=3)
        
        # Status bar
        self._create_status_bar(main_frame, row=4)
    
    def _create_file_selection_section(self, parent: ttk.Widget, row: int) -> None:
        """Create the file selection section."""
        file_frame = ttk.LabelFrame(parent, text="File Selection", padding="10")
        file_frame.grid(row=row, column=0, sticky="ew", pady=(0, 10))
        file_frame.columnconfigure(1, weight=1)
        
        # Input file selection
        ttk.Label(file_frame, text="Input DXF File:").grid(
            row=0, column=0, sticky=tk.W, padx=(0, 10)
        )
        
        input_frame = ttk.Frame(file_frame)
        input_frame.grid(row=0, column=1, sticky="ew", padx=(0, 10))
        input_frame.columnconfigure(0, weight=1)
        
        self.input_entry = ttk.Entry(input_frame, textvariable=self.input_file_path)
        self.input_entry.grid(row=0, column=0, sticky="ew", padx=(0, 5))
        
        ttk.Button(
            input_frame, text="Browse...", command=self._browse_input_file
        ).grid(row=0, column=1)
        
        # Output directory selection
        ttk.Label(file_frame, text="Output Directory:").grid(
            row=1, column=0, sticky=tk.W, padx=(0, 10), pady=(10, 0)
        )
        
        output_frame = ttk.Frame(file_frame)
        output_frame.grid(row=1, column=1, sticky="ew", padx=(0, 10), pady=(10, 0))
        output_frame.columnconfigure(0, weight=1)
        
        self.output_entry = ttk.Entry(output_frame, textvariable=self.output_directory)
        self.output_entry.grid(row=0, column=0, sticky="ew", padx=(0, 5))
        
        ttk.Button(
            output_frame, text="Browse...", command=self._browse_output_directory
        ).grid(row=0, column=1)
        
        # File info display
        self.file_info_text = tk.Text(
            file_frame, height=4, width=50, wrap=tk.WORD, state=tk.DISABLED
        )
        self.file_info_text.grid(
            row=2, column=0, columnspan=2, sticky="ew", pady=(10, 0)
        )
        
        # Scrollbar for file info
        info_scrollbar = ttk.Scrollbar(file_frame, orient=tk.VERTICAL, command=self.file_info_text.yview)
        info_scrollbar.grid(row=2, column=2, sticky="ns", pady=(10, 0))
        self.file_info_text.config(yscrollcommand=info_scrollbar.set)
    
    def _create_geographic_tab(self) -> None:
        """Create the geographic splitting tab."""
        geo_frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(geo_frame, text="Geographic Splitting")
        
        # Description
        desc_label = ttk.Label(
            geo_frame,
            text="Split DXF file spatially using a grid system. Entities are assigned to grid cells based on their location.",
            wraplength=700,
            justify=tk.LEFT
        )
        desc_label.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 20))
        
        # Grid configuration
        grid_frame = ttk.LabelFrame(geo_frame, text="Grid Configuration", padding="10")
        grid_frame.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        
        # Grid dimensions
        ttk.Label(grid_frame, text="Grid Columns:").grid(row=0, column=0, sticky=tk.W, padx=(0, 10))
        self.geo_cols_var = tk.IntVar(value=3)
        ttk.Spinbox(
            grid_frame, from_=1, to=20, textvariable=self.geo_cols_var, width=10
        ).grid(row=0, column=1, sticky=tk.W, padx=(0, 20))
        
        ttk.Label(grid_frame, text="Grid Rows:").grid(row=0, column=2, sticky=tk.W, padx=(0, 10))
        self.geo_rows_var = tk.IntVar(value=3)
        ttk.Spinbox(
            grid_frame, from_=1, to=20, textvariable=self.geo_rows_var, width=10
        ).grid(row=0, column=3, sticky=tk.W)
        
        # Overlap and options
        ttk.Label(grid_frame, text="Overlap (units):").grid(row=1, column=0, sticky=tk.W, padx=(0, 10), pady=(10, 0))
        self.geo_overlap_var = tk.DoubleVar(value=0.0)
        ttk.Entry(
            grid_frame, textvariable=self.geo_overlap_var, width=10
        ).grid(row=1, column=1, sticky=tk.W, padx=(0, 20), pady=(10, 0))
        
        self.geo_include_empty_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            grid_frame, text="Include empty cells", variable=self.geo_include_empty_var
        ).grid(row=1, column=2, columnspan=2, sticky=tk.W, pady=(10, 0))
        
        # Split button
        if TTKBOOTSTRAP_AVAILABLE:
            self.geo_split_btn = ttk.Button(
                geo_frame, text="Split Geographic", command=self._on_geographic_split,
                style='Accent.TButton'
            )
        else:
            self.geo_split_btn = ttk.Button(
                geo_frame, text="Split Geographic", command=self._on_geographic_split
            )
        self.geo_split_btn.grid(row=2, column=0, columnspan=2, pady=(20, 0))
    
    def _create_entity_count_tab(self) -> None:
        """Create the entity count splitting tab."""
        count_frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(count_frame, text="Entity Count Splitting")
        
        # Description
        desc_label = ttk.Label(
            count_frame,
            text="Split DXF file by limiting the number of entities per output file. Choose between sequential or balanced distribution.",
            wraplength=700,
            justify=tk.LEFT
        )
        desc_label.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 20))
        
        # Count configuration
        count_config_frame = ttk.LabelFrame(count_frame, text="Count Configuration", padding="10")
        count_config_frame.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        
        # Max entities
        ttk.Label(count_config_frame, text="Max Entities per File:").grid(
            row=0, column=0, sticky=tk.W, padx=(0, 10)
        )
        self.count_max_var = tk.IntVar(value=1000)
        ttk.Entry(
            count_config_frame, textvariable=self.count_max_var, width=15
        ).grid(row=0, column=1, sticky=tk.W, padx=(0, 20))
        
        # Strategy selection
        ttk.Label(count_config_frame, text="Distribution Strategy:").grid(
            row=1, column=0, sticky=tk.W, padx=(0, 10), pady=(10, 0)
        )
        
        self.count_strategy_var = tk.StringVar(value="sequential")
        strategy_frame = ttk.Frame(count_config_frame)
        strategy_frame.grid(row=1, column=1, sticky=tk.W, pady=(10, 0))
        
        ttk.Radiobutton(
            strategy_frame, text="Sequential", variable=self.count_strategy_var, value="sequential"
        ).grid(row=0, column=0, sticky=tk.W, padx=(0, 20))
        
        ttk.Radiobutton(
            strategy_frame, text="Balanced", variable=self.count_strategy_var, value="balanced"
        ).grid(row=0, column=1, sticky=tk.W)
        
        # Strategy explanation
        if not TTKBOOTSTRAP_AVAILABLE:
            strategy_info = ttk.Label(
                count_config_frame,
                text="Sequential: Entities are split in order. Balanced: Entities are distributed evenly across files.",
                wraplength=600,
                font=('Arial', 8)
            )
        else:
            strategy_info = ttk.Label(
                count_config_frame,
                text="Sequential: Entities are split in order. Balanced: Entities are distributed evenly across files.",
                wraplength=600
            )
        strategy_info.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(10, 0))
        
        # Split button
        if TTKBOOTSTRAP_AVAILABLE:
            self.count_split_btn = ttk.Button(
                count_frame, text="Split by Count", command=self._on_entity_count_split,
                style='Accent.TButton'
            )
        else:
            self.count_split_btn = ttk.Button(
                count_frame, text="Split by Count", command=self._on_entity_count_split
            )
        self.count_split_btn.grid(row=2, column=0, columnspan=2, pady=(20, 0))
    
    def _create_entity_type_tab(self) -> None:
        """Create the entity type splitting tab."""
        type_frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(type_frame, text="Entity Type Splitting")
        
        # Description
        desc_label = ttk.Label(
            type_frame,
            text="Filter and split DXF file by entity types. Select which entity types to include and how to organize them.",
            wraplength=700,
            justify=tk.LEFT
        )
        desc_label.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 20))
        
        # Type selection
        type_config_frame = ttk.LabelFrame(type_frame, text="Entity Type Selection", padding="10")
        type_config_frame.grid(row=1, column=0, columnspan=2, sticky="nsew", pady=(0, 10))
        type_config_frame.columnconfigure(0, weight=1)
        type_config_frame.rowconfigure(0, weight=1)
        
        # Entity type listbox with checkboxes
        self.type_listbox_frame = ttk.Frame(type_config_frame)
        self.type_listbox_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        self.type_listbox_frame.columnconfigure(0, weight=1)
        self.type_listbox_frame.rowconfigure(0, weight=1)
        
        # Create scrollable frame for entity types
        self.type_canvas = tk.Canvas(self.type_listbox_frame, height=150)
        self.type_scrollbar = ttk.Scrollbar(self.type_listbox_frame, orient=tk.VERTICAL, command=self.type_canvas.yview)
        self.type_scrollable_frame = ttk.Frame(self.type_canvas)
        
        self.type_scrollable_frame.bind(
            "<Configure>",
            lambda e: self.type_canvas.configure(scrollregion=self.type_canvas.bbox("all"))
        )
        
        self.type_canvas.create_window((0, 0), window=self.type_scrollable_frame, anchor="nw")
        self.type_canvas.configure(yscrollcommand=self.type_scrollbar.set)
        
        self.type_canvas.grid(row=0, column=0, sticky="nsew")
        self.type_scrollbar.grid(row=0, column=1, sticky="ns")
        
        # Entity type checkboxes (will be populated when file is loaded)
        self.entity_type_vars: Dict[str, tk.BooleanVar] = {}
        
        # Configuration options
        options_frame = ttk.Frame(type_config_frame)
        options_frame.grid(row=0, column=1, sticky="new", padx=(10, 0))
        
        ttk.Label(options_frame, text="Max Entities per File:").grid(row=0, column=0, sticky=tk.W, pady=(0, 5))
        self.type_max_var = tk.IntVar(value=500)
        ttk.Entry(options_frame, textvariable=self.type_max_var, width=15).grid(row=1, column=0, sticky=tk.W, pady=(0, 10))
        
        self.type_separate_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            options_frame, text="Separate file for\neach entity type", variable=self.type_separate_var
        ).grid(row=2, column=0, sticky=tk.W, pady=(0, 10))
        
        ttk.Button(
            options_frame, text="Select All", command=self._select_all_types
        ).grid(row=3, column=0, sticky="ew", pady=(0, 5))
        
        ttk.Button(
            options_frame, text="Clear All", command=self._clear_all_types
        ).grid(row=4, column=0, sticky="ew")
        
        # Split button
        if TTKBOOTSTRAP_AVAILABLE:
            self.type_split_btn = ttk.Button(
                type_frame, text="Split by Type", command=self._on_entity_type_split,
                style='Accent.TButton'
            )
        else:
            self.type_split_btn = ttk.Button(
                type_frame, text="Split by Type", command=self._on_entity_type_split
            )
        self.type_split_btn.grid(row=2, column=0, columnspan=2, pady=(20, 0))
    
    def _create_progress_section(self, parent: ttk.Widget, row: int) -> None:
        """Create the progress tracking section."""
        progress_frame = ttk.LabelFrame(parent, text="Progress", padding="10")
        progress_frame.grid(row=row, column=0, sticky="ew", pady=(10, 0))
        progress_frame.columnconfigure(0, weight=1)
        
        # Progress bar
        self.progress_bar = ttk.Progressbar(
            progress_frame, variable=self.progress_var, maximum=100
        )
        self.progress_bar.grid(row=0, column=0, sticky="ew", pady=(0, 5))
        
        # Progress text
        self.progress_label = ttk.Label(progress_frame, textvariable=self.progress_text)
        self.progress_label.grid(row=1, column=0, sticky=tk.W)
    
    def _create_status_bar(self, parent: ttk.Widget, row: int) -> None:
        """Create the status bar."""
        self.status_var = tk.StringVar(value="Ready")
        status_bar = ttk.Label(
            parent, textvariable=self.status_var, relief=tk.SUNKEN, anchor=tk.W
        )
        status_bar.grid(row=row, column=0, sticky="ew", pady=(5, 0))
    
    def _browse_input_file(self) -> None:
        """Browse for input DXF file."""
        filename = filedialog.askopenfilename(
            title="Select DXF File",
            filetypes=[("DXF files", "*.dxf"), ("All files", "*.*")]
        )
        if filename:
            self.input_file_path.set(filename)
            # Auto-set output directory to same as input file
            if not self.output_directory.get():
                self.output_directory.set(str(Path(filename).parent))
            
            # Trigger file loading
            if self.on_load_file:
                self.on_load_file(filename)
    
    def _browse_output_directory(self) -> None:
        """Browse for output directory."""
        directory = filedialog.askdirectory(title="Select Output Directory")
        if directory:
            self.output_directory.set(directory)
    
    def _on_geographic_split(self) -> None:
        """Handle geographic split button click."""
        if not self._validate_inputs():
            return
        
        params = {
            'input_file': self.input_file_path.get(),
            'output_dir': self.output_directory.get(),
            'grid_cols': self.geo_cols_var.get(),
            'grid_rows': self.geo_rows_var.get(),
            'overlap': self.geo_overlap_var.get(),
            'include_empty': self.geo_include_empty_var.get()
        }
        
        if self.on_split_geographic:
            self.on_split_geographic(params)
    
    def _on_entity_count_split(self) -> None:
        """Handle entity count split button click."""
        if not self._validate_inputs():
            return
        
        params = {
            'input_file': self.input_file_path.get(),
            'output_dir': self.output_directory.get(),
            'max_entities': self.count_max_var.get(),
            'strategy': self.count_strategy_var.get()
        }
        
        if self.on_split_entity_count:
            self.on_split_entity_count(params)
    
    def _on_entity_type_split(self) -> None:
        """Handle entity type split button click."""
        if not self._validate_inputs():
            return
        
        # Get selected entity types
        selected_types = [
            entity_type for entity_type, var in self.entity_type_vars.items()
            if var.get()
        ]
        
        if not selected_types:
            messagebox.showwarning("No Types Selected", "Please select at least one entity type.")
            return
        
        params = {
            'input_file': self.input_file_path.get(),
            'output_dir': self.output_directory.get(),
            'selected_types': selected_types,
            'max_entities': self.type_max_var.get(),
            'separate_files': self.type_separate_var.get()
        }
        
        if self.on_split_entity_type:
            self.on_split_entity_type(params)
    
    def _validate_inputs(self) -> bool:
        """Validate user inputs before processing."""
        if not self.input_file_path.get():
            messagebox.showerror("Missing Input", "Please select an input DXF file.")
            return False
        
        if not self.output_directory.get():
            messagebox.showerror("Missing Output", "Please select an output directory.")
            return False
        
        if self.is_processing:
            messagebox.showwarning("Processing", "A splitting operation is already in progress.")
            return False
        
        return True
    
    def _select_all_types(self) -> None:
        """Select all entity types."""
        for var in self.entity_type_vars.values():
            var.set(True)
    
    def _clear_all_types(self) -> None:
        """Clear all entity type selections."""
        for var in self.entity_type_vars.values():
            var.set(False)
    
    def update_file_info(self, analysis: Dict[str, Any]) -> None:
        """Update the file information display."""
        self.entity_analysis = analysis
        
        # Update file info text
        self.file_info_text.config(state=tk.NORMAL)
        self.file_info_text.delete(1.0, tk.END)
        
        if analysis:
            info_text = f"Total Entities: {analysis.get('total_entities', 0)}\n"
            info_text += f"Has 3D Entities: {'Yes' if analysis.get('has_3d_entities', False) else 'No'}\n"
            
            # Entity types
            entity_types = analysis.get('entity_types', {})
            if entity_types:
                info_text += f"Entity Types: {len(entity_types)}\n"
                for entity_type, count in sorted(entity_types.items()):
                    info_text += f"  {entity_type}: {count}\n"
            
            # Layers
            layer_counts = analysis.get('layer_counts', {})
            if layer_counts:
                info_text += f"Layers: {len(layer_counts)}\n"
        else:
            info_text = "No file loaded"
        
        self.file_info_text.insert(1.0, info_text)
        self.file_info_text.config(state=tk.DISABLED)
        
        # Update entity type checkboxes
        self._update_entity_type_checkboxes(entity_types if analysis else {})
    
    def _update_entity_type_checkboxes(self, entity_types: Dict[str, int]) -> None:
        """Update the entity type selection checkboxes."""
        # Clear existing checkboxes
        for widget in self.type_scrollable_frame.winfo_children():
            widget.destroy()
        self.entity_type_vars.clear()
        
        # Create new checkboxes
        for i, (entity_type, count) in enumerate(sorted(entity_types.items())):
            var = tk.BooleanVar(value=True)  # Default to selected
            self.entity_type_vars[entity_type] = var
            
            checkbox = ttk.Checkbutton(
                self.type_scrollable_frame,
                text=f"{entity_type} ({count})",
                variable=var
            )
            checkbox.grid(row=i, column=0, sticky=tk.W, padx=5, pady=2)
        
        # Update scroll region
        self.type_scrollable_frame.update_idletasks()
        self.type_canvas.configure(scrollregion=self.type_canvas.bbox("all"))
    
    def update_progress(self, progress: SplitProgress) -> None:
        """Update the progress display."""
        self.progress_var.set(progress.percentage)
        self.progress_text.set(f"{progress.phase}: {progress.message}")
        self.status_var.set(f"Step {progress.current_step}/{progress.total_steps}")
        self.root.update_idletasks()
    
    def set_processing_state(self, processing: bool) -> None:
        """Set the processing state and update UI accordingly."""
        self.is_processing = processing
        
        # Disable/enable split buttons
        state = tk.DISABLED if processing else tk.NORMAL
        self.geo_split_btn.config(state=state)
        self.count_split_btn.config(state=state)
        self.type_split_btn.config(state=state)
        
        if not processing:
            self.progress_var.set(0)
            self.progress_text.set("Ready")
            self.status_var.set("Ready")
    
    def show_result(self, result: SplitResult) -> None:
        """Show the splitting result to the user."""
        if result.success:
            message = f"Successfully created {len(result.output_files)} files:\n\n"
            message += "\n".join(Path(f).name for f in result.output_files[:10])
            if len(result.output_files) > 10:
                message += f"\n... and {len(result.output_files) - 10} more files"
            
            if result.warnings:
                message += f"\n\nWarnings:\n" + "\n".join(result.warnings)
            
            messagebox.showinfo("Split Complete", message)
        else:
            messagebox.showerror("Split Failed", result.error_message or "Unknown error occurred")
    
    def run(self) -> None:
        """Start the GUI main loop."""
        self.root.mainloop()
    
    def destroy(self) -> None:
        """Destroy the GUI."""
        self.root.destroy()
