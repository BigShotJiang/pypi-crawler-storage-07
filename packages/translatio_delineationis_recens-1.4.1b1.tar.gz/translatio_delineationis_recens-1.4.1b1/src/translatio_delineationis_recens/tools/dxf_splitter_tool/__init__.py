"""
DXF Splitter Tool

A GUI application for splitting large DXF files into smaller files using various methods:
- Geographic splitting: Grid-based spatial division
- Entity count splitting: Split by maximum entities per file  
- Entity type splitting: Filter and split by entity types

This tool follows the MVC architecture pattern and integrates with the 
Translatio Delineationis Recens library.
"""

__version__ = "1.0.0"
__author__ = "Translatio Delineationis Recens Team"

from .controller import DxfSplitterController

__all__ = ["DxfSplitterController"]
