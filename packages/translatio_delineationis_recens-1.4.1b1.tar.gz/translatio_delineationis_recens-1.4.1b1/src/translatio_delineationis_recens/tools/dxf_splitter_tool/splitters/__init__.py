"""
Splitter modules for the DXF Splitter Tool.

This package contains the core splitting algorithms:
- GeographicSplitter: Grid-based spatial splitting
- EntityCountSplitter: Count-based splitting
- EntityTypeSplitter: Type-based filtering and splitting
"""

from .geographic import GeographicSplitter
from .entity_count import EntityCountSplitter
from .entity_type import EntityTypeSplitter

__all__ = ["GeographicSplitter", "EntityCountSplitter", "EntityTypeSplitter"]
