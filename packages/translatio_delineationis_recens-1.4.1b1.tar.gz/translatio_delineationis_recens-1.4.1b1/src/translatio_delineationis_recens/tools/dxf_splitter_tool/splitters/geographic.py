"""
Geographic splitter for DXF Splitter Tool.

Implements grid-based spatial splitting of DXF files.
"""

from __future__ import annotations
import os
import logging
from pathlib import Path
from typing import Optional, Callable, List, Dict, Any, Tuple, TYPE_CHECKING
from dataclasses import dataclass

import ezdxf
from ezdxf.math import BoundingBox, Vec2
from ...dxf_streamer import DXFStreamer

if TYPE_CHECKING:
    from ezdxf.document import Drawing
    from ezdxf.entities import DXFEntity  # type: ignore
    from ..model import SplitResult, SplitProgress

logger = logging.getLogger(__name__)


@dataclass
class GridCell:
    """Represents a single grid cell with its bounds and entities."""
    row: int
    col: int
    min_x: float
    min_y: float
    max_x: float
    max_y: float
    entities: List[Any]
    
    @property
    def bounds(self) -> BoundingBox:
        """Get bounding box for this cell."""
        return BoundingBox([(self.min_x, self.min_y), (self.max_x, self.max_y)])
    
    @property
    def center(self) -> Vec2:
        """Get center point of the cell."""
        return Vec2((self.min_x + self.max_x) / 2, (self.min_y + self.max_y) / 2)
    
    @property
    def is_empty(self) -> bool:
        """Check if cell has no entities."""
        return len(self.entities) == 0


class GeographicSplitter:
    """Handles geographic grid-based splitting of DXF files."""
    
    def __init__(self) -> None:
        """Initialize the geographic splitter."""
        self.logger = logging.getLogger(__name__)
    
    def split_by_grid(
        self,
        doc_or_filepath,
        input_filepath: Optional[str] = None,
        grid_cols: Optional[int] = None,
        grid_rows: Optional[int] = None,
        output_dir: Optional[str] = None,
        overlap: float = 0.0,
        include_empty: bool = False,
        progress_callback: Optional[Callable[[SplitProgress], None]] = None
    ) -> SplitResult:
        """
        Split DXF file using geographic grid with memory-efficient streaming.
        
        Supports both old API (doc, filepath, ...) and new API (filepath, ...).
        
        Args:
            doc_or_filepath: Either a Drawing object (old API) or filepath string (new API)
            input_filepath: Path to input DXF file (old API) or grid_cols (new API)
            grid_cols: Number of grid columns (old API) or grid_rows (new API)
            grid_rows: Number of grid rows (old API) or output_dir (new API)
            output_dir: Output directory for split files
            overlap: Overlap buffer in drawing units
            include_empty: Whether to create files for empty grid cells
            progress_callback: Optional progress callback
            
        Returns:
            SplitResult with operation results
        """
        # Handle both old and new API signatures
        if hasattr(doc_or_filepath, 'dxfversion'):  # It's a Drawing object (old API)
            doc = doc_or_filepath
            filepath = input_filepath
            cols = grid_cols
            rows = grid_rows
            out_dir = output_dir
            use_streaming = False
        else:  # It's a filepath string (new API)
            doc = None
            filepath = doc_or_filepath
            cols = input_filepath  # type: ignore
            rows = grid_cols  # type: ignore
            out_dir = grid_rows  # type: ignore
            use_streaming = True
        from ..model import SplitResult, SplitProgress
        
        try:
            self._update_progress(
                progress_callback, "Initializing", 0, 6,
                "Starting geographic splitting..."
            )
            
            # Validate inputs
            if cols <= 0 or rows <= 0:
                return SplitResult(
                    False, [], "Grid dimensions must be positive integers"
                )
            
            if overlap < 0:
                return SplitResult(False, [], "Overlap cannot be negative")
            
            # Ensure output directory exists
            os.makedirs(out_dir, exist_ok=True)
            
            self._update_progress(
                progress_callback, "Analysis", 1, 6,
                "Calculating bounding box..."
            )
            
            # Get overall bounding box
            if use_streaming:
                # Initialize DXF streamer for memory-efficient processing
                streamer = DXFStreamer(filepath)
                streamer.read_metadata()
                bbox = self._calculate_bounding_box_streaming(streamer)
            else:
                # Use traditional method for backward compatibility
                bbox = self._calculate_bounding_box(doc)
                
            if not bbox or not bbox.has_data:
                return SplitResult(False, [], "No entities found or invalid bounds")
            
            self._update_progress(
                progress_callback, "Grid Setup", 2, 6,
                f"Creating {cols}x{rows} grid..."
            )
            
            # Create grid cells
            grid_cells = self._create_grid_cells(
                bbox, cols, rows, overlap
            )
            
            self._update_progress(
                progress_callback, "Entity Assignment", 3, 6,
                "Assigning entities to grid cells..."
            )
            
            # Assign entities to grid cells
            if use_streaming:
                self._assign_entities_to_cells_streaming(streamer, grid_cells)
            else:
                self._assign_entities_to_cells(doc, grid_cells)
            
            self._update_progress(
                progress_callback, "File Generation", 4, 6,
                "Generating output files..."
            )
            
            # Generate output files
            if use_streaming:
                output_files = self._generate_output_files_streaming(
                    streamer, grid_cells, filepath, out_dir,
                    include_empty, progress_callback
                )
            else:
                output_files = self._generate_output_files(
                    doc, grid_cells, filepath, out_dir,
                    include_empty, progress_callback
                )
            
            self._update_progress(
                progress_callback, "Complete", 6, 6,
                f"Successfully created {len(output_files)} files"
            )
            
            return SplitResult(True, output_files)
            
        except Exception as e:
            self.logger.error(f"Geographic splitting failed: {e}")
            return SplitResult(False, [], f"Geographic splitting failed: {e}")
    
    def _update_progress(
        self,
        callback: Optional[Callable[[SplitProgress], None]],
        phase: str,
        current: int,
        total: int,
        message: str
    ) -> None:
        """Update progress if callback is provided."""
        if callback:
            from ..model import SplitProgress
            progress = SplitProgress(phase, current, total, message)
            callback(progress)
    
    def _calculate_bounding_box(self, doc: Drawing) -> Optional[BoundingBox]:
        """Calculate the overall bounding box of all entities."""
        try:
            from ezdxf import bbox
            
            msp = doc.modelspace()
            entities = list(msp)
            
            if not entities:
                return None
            
            # Calculate bounding box using ezdxf bbox module
            cache = bbox.Cache()
            extents = bbox.extents(entities, cache=cache)
            
            return extents if extents.has_data else None
            
        except Exception as e:
            self.logger.error(f"Error calculating bounding box: {e}")
            return None
    
    def _create_grid_cells(
        self,
        bbox: BoundingBox,
        grid_cols: int,
        grid_rows: int,
        overlap: float
    ) -> List[List[GridCell]]:
        """Create grid cells based on bounding box and grid dimensions."""
        cells: List[List[GridCell]] = []
        
        # Calculate cell dimensions
        total_width = bbox.size.x
        total_height = bbox.size.y
        cell_width = total_width / grid_cols
        cell_height = total_height / grid_rows
        
        for row in range(grid_rows):
            cell_row: List[GridCell] = []
            
            for col in range(grid_cols):
                # Calculate base cell bounds
                min_x = bbox.extmin.x + col * cell_width  # type: ignore
                max_x = bbox.extmin.x + (col + 1) * cell_width  # type: ignore
                min_y = bbox.extmin.y + row * cell_height  # type: ignore
                max_y = bbox.extmin.y + (row + 1) * cell_height  # type: ignore
                
                # Apply overlap buffer
                if overlap > 0:
                    min_x -= overlap
                    max_x += overlap
                    min_y -= overlap
                    max_y += overlap
                
                cell = GridCell(
                    row=row,
                    col=col,
                    min_x=min_x,
                    min_y=min_y,
                    max_x=max_x,
                    max_y=max_y,
                    entities=[]
                )
                
                cell_row.append(cell)
            
            cells.append(cell_row)
        
        return cells
    
    def _assign_entities_to_cells(
        self,
        doc: Drawing,
        grid_cells: List[List[GridCell]]
    ) -> None:
        """Assign entities to appropriate grid cells based on their geometry."""
        try:
            from ezdxf import bbox
            
            msp = doc.modelspace()
            entities = list(msp)
            
            # Create bbox cache for efficiency
            cache = bbox.Cache()
            
            for entity in entities:
                try:
                    # Get entity bounding box
                    entity_bbox = bbox.extents([entity], cache=cache)
                    
                    if not entity_bbox.has_data:
                        # Skip entities without valid bounds
                        continue
                    
                    # Find which cells this entity intersects
                    for row_cells in grid_cells:
                        for cell in row_cells:
                            if self._entity_intersects_cell(entity_bbox, cell):
                                cell.entities.append(entity)
                
                except Exception as e:
                    # Log warning but continue with other entities
                    self.logger.warning(
                        f"Could not process entity {entity.dxftype()}: {e}"
                    )
                    continue
        
        except Exception as e:
            self.logger.error(f"Error assigning entities to cells: {e}")
            raise
    
    def _entity_intersects_cell(
        self, entity_bbox: BoundingBox, cell: GridCell
    ) -> bool:
        """Check if entity bounding box intersects with grid cell."""
        # Check for intersection using bounding box overlap
        return not (
            entity_bbox.extmax.x < cell.min_x or  # type: ignore
            entity_bbox.extmin.x > cell.max_x or  # type: ignore
            entity_bbox.extmax.y < cell.min_y or  # type: ignore
            entity_bbox.extmin.y > cell.max_y  # type: ignore
        )
    
    def _generate_output_files(
        self,
        doc: Drawing,
        grid_cells: List[List[GridCell]],
        input_filepath: str,
        output_dir: str,
        include_empty: bool,
        progress_callback: Optional[Callable[[SplitProgress], None]]
    ) -> List[str]:
        """Generate DXF output files for each grid cell."""
        output_files: List[str] = []
        base_name = Path(input_filepath).stem
        
        total_cells = len(grid_cells) * len(grid_cells[0]) if grid_cells else 0
        current_cell = 0
        
        for row_cells in grid_cells:
            for cell in row_cells:
                current_cell += 1
                
                # Skip empty cells if not including them
                if cell.is_empty and not include_empty:
                    continue
                
                self._update_progress(
                    progress_callback, "File Generation", current_cell, total_cells,
                    f"Creating file for cell ({cell.row}, {cell.col})..."
                )
                
                try:
                    # Create output filename
                    output_filename = f"{base_name}_grid_{cell.row}_{cell.col}.dxf"
                    output_path = os.path.join(output_dir, output_filename)
                    
                    # Create new DXF document for this cell
                    cell_doc = self._create_cell_document(doc, cell)
                    
                    # Save the document
                    cell_doc.saveas(output_path)
                    output_files.append(output_path)
                    
                    self.logger.info(
                        f"Created {output_filename} with {len(cell.entities)} entities"
                    )
                
                except Exception as e:
                    self.logger.error(
                        f"Error creating file for cell ({cell.row}, {cell.col}): {e}"
                    )
                    # Continue with other cells
                    continue
        
        return output_files
    
    def _create_cell_document(self, source_doc: Drawing, cell: GridCell) -> Drawing:
        """Create a new DXF document containing entities for a specific cell."""
        # Create new document with same DXF version
        new_doc = ezdxf.new(source_doc.dxfversion)  # type: ignore
        
        # Copy essential document properties
        self._copy_document_structure(source_doc, new_doc)
        
        # Add entities to new document
        new_msp = new_doc.modelspace()
        
        for entity in cell.entities:
            try:
                # Clone entity to new document
                new_entity = entity.copy()
                new_msp.add_entity(new_entity)
            except Exception as e:
                self.logger.warning(
                    f"Could not copy entity {entity.dxftype()}: {e}"
                )
                continue
        
        return new_doc
    
    def _copy_document_structure(
        self, source_doc: Drawing, target_doc: Drawing
    ) -> None:
        """Copy essential document structure (layers, styles, etc.)."""
        try:
            # Copy layers - simplified approach for mypy compatibility
            for layer_name in source_doc.layers:
                if layer_name not in target_doc.layers:
                    try:
                        target_doc.layers.add(layer_name)  # type: ignore
                    except Exception:
                        continue
            
            # Copy text styles - simplified approach
            for style_name in source_doc.styles:
                if style_name not in target_doc.styles:
                    try:
                        target_doc.styles.add(style_name)  # type: ignore
                    except Exception:
                        continue
            
            # Copy linetypes - simplified approach
            for linetype_name in source_doc.linetypes:
                if linetype_name not in target_doc.linetypes:
                    try:
                        target_doc.linetypes.add(linetype_name)  # type: ignore
                    except Exception:
                        continue
        
        except Exception as e:
            self.logger.warning(f"Error copying document structure: {e}")
            # Continue anyway - basic structure will work

    def _calculate_bounding_box_streaming(self, streamer: DXFStreamer) -> Optional[BoundingBox]:
        """Calculate the overall bounding box using streaming."""
        try:
            from ezdxf import bbox
            
            # Stream through entities to calculate bounding box
            extents = []
            for entity in streamer.stream_entities():
                try:
                    entity_bbox = bbox.extents([entity])
                    if entity_bbox.has_data:
                        extents.append(entity_bbox.extmin)
                        extents.append(entity_bbox.extmax)
                except Exception:
                    continue  # Skip entities that can't be processed
            
            if not extents:
                return None
                
            return BoundingBox(extents)
            
        except Exception as e:
            self.logger.error(f"Error calculating bounding box with streaming: {e}")
            return None

    def _assign_entities_to_cells_streaming(
        self, streamer: DXFStreamer, grid_cells: List[List[GridCell]]
    ) -> None:
        """Assign entities to grid cells using streaming."""
        try:
            from ezdxf import bbox
            
            for entity in streamer.stream_entities():
                try:
                    # Get entity bounding box
                    entity_bbox = bbox.extents([entity])
                    if not entity_bbox.has_data:
                        continue
                    
                    # Check which cells this entity intersects
                    for row in grid_cells:
                        for cell in row:
                            if self._entity_intersects_cell(entity_bbox, cell):
                                cell.entities.append(entity)
                                
                except Exception as e:
                    self.logger.debug(f"Error processing entity: {e}")
                    continue
                    
        except Exception as e:
            self.logger.error(f"Error assigning entities to cells: {e}")
            raise

    def _generate_output_files_streaming(
        self,
        streamer: DXFStreamer,
        grid_cells: List[List[GridCell]],
        input_filepath: str,
        output_dir: str,
        include_empty: bool,
        progress_callback: Optional[Callable[[SplitProgress], None]] = None
    ) -> List[str]:
        """Generate output files using streaming approach."""
        output_files = []
        input_name = Path(input_filepath).stem
        
        total_cells = sum(len(row) for row in grid_cells)
        current_cell = 0
        
        for row_idx, row in enumerate(grid_cells):
            for col_idx, cell in enumerate(row):
                current_cell += 1
                
                # Skip empty cells if not requested
                if cell.is_empty and not include_empty:
                    continue
                
                # Update progress
                if progress_callback:
                    from ..model import SplitProgress
                    progress = SplitProgress(
                        "File Generation", current_cell, total_cells,
                        f"Creating file for cell ({row_idx}, {col_idx})"
                    )
                    progress_callback(progress)
                
                # Create output filename
                output_filename = f"{input_name}_r{row_idx:03d}_c{col_idx:03d}.dxf"
                output_path = os.path.join(output_dir, output_filename)
                
                # Create document for this cell using template
                cell_doc = self._create_cell_document_streaming(streamer.template_doc, cell)
                
                # Save the document
                cell_doc.saveas(output_path)
                output_files.append(output_path)
                
                self.logger.info(f"Created {output_path} with {len(cell.entities)} entities")
        
        return output_files

    def _create_cell_document_streaming(self, template_doc: Drawing, cell: GridCell) -> Drawing:
        """Create a new DXF document for a cell using the template document."""
        # Create new document with same DXF version
        new_doc = ezdxf.new(template_doc.dxfversion)
        
        # Copy document structure from template
        self._copy_document_structure(template_doc, new_doc)
        
        # Add entities to the new document
        msp = new_doc.modelspace()
        for entity in cell.entities:
            try:
                # Clone the entity to the new document
                msp.add_entity(entity.copy())
            except Exception as e:
                self.logger.debug(f"Error copying entity: {e}")
                continue
        
        return new_doc
