"""
Entity count splitter for DXF Splitter Tool.

Implements count-based splitting of DXF files.
"""

from __future__ import annotations
import os
import logging
from pathlib import Path
from typing import Optional, Callable, List, Any, TYPE_CHECKING
from math import ceil

import ezdxf

if TYPE_CHECKING:
    from ezdxf.document import Drawing
    from ..model import SplitResult, SplitProgress

logger = logging.getLogger(__name__)


class EntityCountSplitter:
    """Handles entity count-based splitting of DXF files."""
    
    def __init__(self) -> None:
        """Initialize the entity count splitter."""
        self.logger = logging.getLogger(__name__)
    
    def split_by_count(
        self,
        doc: Drawing,
        input_filepath: str,
        max_entities: int,
        output_dir: str,
        strategy: str = "sequential",
        progress_callback: Optional[Callable[[SplitProgress], None]] = None
    ) -> SplitResult:
        """
        Split DXF file by entity count.
        
        Args:
            doc: DXF document to split
            input_filepath: Path to input DXF file
            max_entities: Maximum entities per output file
            output_dir: Output directory for split files
            strategy: Distribution strategy ("sequential" or "balanced")
            progress_callback: Optional progress callback
            
        Returns:
            SplitResult with operation results
        """
        from ..model import SplitResult, SplitProgress
        
        try:
            self._update_progress(
                progress_callback, "Initializing", 0, 5,
                "Starting entity count splitting..."
            )
            
            # Validate inputs
            if max_entities <= 0:
                return SplitResult(
                    False, [], "Maximum entities must be a positive integer"
                )
            
            if strategy not in ["sequential", "balanced"]:
                return SplitResult(
                    False, [], 
                    "Strategy must be 'sequential' or 'balanced'"
                )
            
            # Ensure output directory exists
            os.makedirs(output_dir, exist_ok=True)
            
            self._update_progress(
                progress_callback, "Analysis", 1, 5,
                "Analyzing entities..."
            )
            
            # Get all entities from modelspace
            msp = doc.modelspace()
            all_entities = list(msp)
            
            if not all_entities:
                return SplitResult(False, [], "No entities found in modelspace")
            
            total_entities = len(all_entities)
            num_files = ceil(total_entities / max_entities)
            
            self._update_progress(
                progress_callback, "Planning", 2, 5,
                f"Planning {num_files} output files for {total_entities} entities..."
            )
            
            # Create entity groups based on strategy
            if strategy == "sequential":
                entity_groups = self._create_sequential_groups(
                    all_entities, max_entities
                )
            else:  # balanced
                entity_groups = self._create_balanced_groups(
                    all_entities, max_entities
                )
            
            self._update_progress(
                progress_callback, "File Generation", 3, 5,
                "Generating output files..."
            )
            
            # Generate output files
            output_files = self._generate_output_files(
                doc, entity_groups, input_filepath, output_dir, progress_callback
            )
            
            self._update_progress(
                progress_callback, "Complete", 5, 5,
                f"Successfully created {len(output_files)} files"
            )
            
            return SplitResult(True, output_files)
            
        except Exception as e:
            self.logger.error(f"Entity count splitting failed: {e}")
            return SplitResult(False, [], f"Entity count splitting failed: {e}")
    
    def _update_progress(
        self,
        callback: Optional[Callable[[SplitProgress], None]],
        phase: str,
        current: int,
        total: int,
        message: str
    ) -> None:
        """Update progress if callback is provided."""
        if callback:
            from ..model import SplitProgress
            progress = SplitProgress(phase, current, total, message)
            callback(progress)
    
    def _create_sequential_groups(
        self, entities: List[Any], max_entities: int
    ) -> List[List[Any]]:
        """Create entity groups using sequential distribution."""
        groups: List[List[Any]] = []
        
        for i in range(0, len(entities), max_entities):
            group = entities[i:i + max_entities]
            groups.append(group)
        
        return groups
    
    def _create_balanced_groups(
        self, entities: List[Any], max_entities: int
    ) -> List[List[Any]]:
        """Create entity groups using balanced distribution."""
        total_entities = len(entities)
        num_groups = ceil(total_entities / max_entities)
        
        # Calculate optimal group sizes for balanced distribution
        base_size = total_entities // num_groups
        extra_entities = total_entities % num_groups
        
        groups: List[List[Any]] = []
        start_idx = 0
        
        for i in range(num_groups):
            # Some groups get one extra entity to balance the distribution
            group_size = base_size + (1 if i < extra_entities else 0)
            end_idx = start_idx + group_size
            
            group = entities[start_idx:end_idx]
            groups.append(group)
            
            start_idx = end_idx
        
        return groups
    
    def _generate_output_files(
        self,
        doc: Drawing,
        entity_groups: List[List[Any]],
        input_filepath: str,
        output_dir: str,
        progress_callback: Optional[Callable[[SplitProgress], None]]
    ) -> List[str]:
        """Generate DXF output files for each entity group."""
        output_files: List[str] = []
        base_name = Path(input_filepath).stem
        
        total_groups = len(entity_groups)
        
        for i, entity_group in enumerate(entity_groups):
            self._update_progress(
                progress_callback, "File Generation", i + 1, total_groups,
                f"Creating file {i + 1} of {total_groups}..."
            )
            
            try:
                # Create output filename with zero-padded index
                output_filename = f"{base_name}_part_{i + 1:03d}.dxf"
                output_path = os.path.join(output_dir, output_filename)
                
                # Create new DXF document for this group
                group_doc = self._create_group_document(doc, entity_group)
                
                # Save the document
                group_doc.saveas(output_path)
                output_files.append(output_path)
                
                self.logger.info(
                    f"Created {output_filename} with {len(entity_group)} entities"
                )
            
            except Exception as e:
                self.logger.error(f"Error creating file {i + 1}: {e}")
                # Continue with other groups
                continue
        
        return output_files
    
    def _create_group_document(
        self, source_doc: Drawing, entities: List[Any]
    ) -> Drawing:
        """Create a new DXF document containing a specific group of entities."""
        # Create new document with same DXF version
        new_doc = ezdxf.new(source_doc.dxfversion)  # type: ignore
        
        # Copy essential document properties
        self._copy_document_structure(source_doc, new_doc)
        
        # Add entities to new document
        new_msp = new_doc.modelspace()
        
        for entity in entities:
            try:
                # Clone entity to new document
                new_entity = entity.copy()
                new_msp.add_entity(new_entity)
            except Exception as e:
                self.logger.warning(
                    f"Could not copy entity {entity.dxftype()}: {e}"
                )
                continue
        
        return new_doc
    
    def _copy_document_structure(
        self, source_doc: Drawing, target_doc: Drawing
    ) -> None:
        """Copy essential document structure (layers, styles, etc.)."""
        try:
            # Copy layers - simplified approach for mypy compatibility
            for layer_name in source_doc.layers:
                if layer_name not in target_doc.layers:
                    try:
                        target_doc.layers.add(layer_name)  # type: ignore
                    except Exception:
                        continue
            
            # Copy text styles - simplified approach
            for style_name in source_doc.styles:
                if style_name not in target_doc.styles:
                    try:
                        target_doc.styles.add(style_name)  # type: ignore
                    except Exception:
                        continue
            
            # Copy linetypes - simplified approach
            for linetype_name in source_doc.linetypes:
                if linetype_name not in target_doc.linetypes:
                    try:
                        target_doc.linetypes.add(linetype_name)  # type: ignore
                    except Exception:
                        continue
        
        except Exception as e:
            self.logger.warning(f"Error copying document structure: {e}")
            # Continue anyway - basic structure will work
