"""
Entity type splitter for DXF Splitter Tool.

Implements type-based filtering and splitting of DXF files.
"""

from __future__ import annotations
import os
import logging
from pathlib import Path
from typing import List, Optional, Callable, Dict, Any, TYPE_CHECKING
from collections import defaultdict
from math import ceil

import ezdxf

if TYPE_CHECKING:
    from ezdxf.document import Drawing
    from ..model import SplitResult, SplitProgress

logger = logging.getLogger(__name__)


class EntityTypeSplitter:
    """Handles entity type-based splitting of DXF files."""
    
    def __init__(self) -> None:
        """Initialize the entity type splitter."""
        self.logger = logging.getLogger(__name__)
    
    def split_by_type(
        self,
        doc: Drawing,
        input_filepath: str,
        selected_types: List[str],
        max_entities: int,
        output_dir: str,
        separate_files: bool = False,
        progress_callback: Optional[Callable[[SplitProgress], None]] = None
    ) -> SplitResult:
        """
        Split DXF file by entity type.
        
        Args:
            doc: DXF document to split
            input_filepath: Path to input DXF file
            selected_types: List of entity types to include
            max_entities: Maximum entities per output file
            output_dir: Output directory for split files
            separate_files: Create separate file for each entity type
            progress_callback: Optional progress callback
            
        Returns:
            SplitResult with operation results
        """
        from ..model import SplitResult, SplitProgress
        
        try:
            self._update_progress(
                progress_callback, "Initializing", 0, 6,
                "Starting entity type splitting..."
            )
            
            # Validate inputs
            if max_entities <= 0:
                return SplitResult(
                    False, [], "Maximum entities must be a positive integer"
                )
            
            if not selected_types:
                return SplitResult(
                    False, [], "At least one entity type must be selected"
                )
            
            # Ensure output directory exists
            os.makedirs(output_dir, exist_ok=True)
            
            self._update_progress(
                progress_callback, "Analysis", 1, 6,
                "Analyzing entities by type..."
            )
            
            # Filter and group entities by type
            entities_by_type = self._filter_entities_by_type(doc, selected_types)
            
            if not entities_by_type:
                return SplitResult(
                    False, [], 
                    f"No entities found for selected types: {selected_types}"
                )
            
            # Log entity counts by type
            for entity_type, entities in entities_by_type.items():
                self.logger.info(f"Found {len(entities)} {entity_type} entities")
            
            self._update_progress(
                progress_callback, "Planning", 2, 6,
                "Planning output file structure..."
            )
            
            # Create file groups based on separate_files setting
            if separate_files:
                file_groups = self._create_separate_type_groups(
                    entities_by_type, max_entities
                )
            else:
                file_groups = self._create_combined_type_groups(
                    entities_by_type, max_entities
                )
            
            self._update_progress(
                progress_callback, "File Generation", 3, 6,
                f"Generating {len(file_groups)} output files..."
            )
            
            # Generate output files
            output_files = self._generate_output_files(
                doc, file_groups, input_filepath, output_dir, 
                separate_files, progress_callback
            )
            
            self._update_progress(
                progress_callback, "Complete", 6, 6,
                f"Successfully created {len(output_files)} files"
            )
            
            return SplitResult(True, output_files)
            
        except Exception as e:
            self.logger.error(f"Entity type splitting failed: {e}")
            return SplitResult(False, [], f"Entity type splitting failed: {e}")
    
    def _update_progress(
        self,
        callback: Optional[Callable[[SplitProgress], None]],
        phase: str,
        current: int,
        total: int,
        message: str
    ) -> None:
        """Update progress if callback is provided."""
        if callback:
            from ..model import SplitProgress
            progress = SplitProgress(phase, current, total, message)
            callback(progress)
    
    def _filter_entities_by_type(
        self, doc: Drawing, selected_types: List[str]
    ) -> Dict[str, List[Any]]:
        """Filter entities by selected types and group them."""
        entities_by_type: Dict[str, List[Any]] = defaultdict(list)
        
        # Get all entities from modelspace
        msp = doc.modelspace()
        all_entities = list(msp)
        
        # Filter entities by type
        for entity in all_entities:
            entity_type = entity.dxftype()
            if entity_type in selected_types:
                entities_by_type[entity_type].append(entity)
        
        # Convert defaultdict to regular dict and remove empty types
        return {k: v for k, v in entities_by_type.items() if v}
    
    def _create_separate_type_groups(
        self, entities_by_type: Dict[str, List[Any]], max_entities: int
    ) -> List[Dict[str, Any]]:
        """Create file groups with separate files for each entity type."""
        file_groups: List[Dict[str, Any]] = []
        
        for entity_type, entities in entities_by_type.items():
            # Split entities of this type into chunks
            for i in range(0, len(entities), max_entities):
                chunk = entities[i:i + max_entities]
                
                file_group = {
                    'entities': chunk,
                    'type': entity_type,
                    'index': i // max_entities + 1,
                    'total_for_type': ceil(len(entities) / max_entities)
                }
                file_groups.append(file_group)
        
        return file_groups
    
    def _create_combined_type_groups(
        self, entities_by_type: Dict[str, List[Any]], max_entities: int
    ) -> List[Dict[str, Any]]:
        """Create file groups combining all selected entity types."""
        # Combine all entities into a single list
        all_entities: List[Any] = []
        for entities in entities_by_type.values():
            all_entities.extend(entities)
        
        file_groups: List[Dict[str, Any]] = []
        
        # Split combined entities into chunks
        for i in range(0, len(all_entities), max_entities):
            chunk = all_entities[i:i + max_entities]
            
            file_group = {
                'entities': chunk,
                'type': 'mixed',
                'index': i // max_entities + 1,
                'total_for_type': ceil(len(all_entities) / max_entities)
            }
            file_groups.append(file_group)
        
        return file_groups
    
    def _generate_output_files(
        self,
        doc: Drawing,
        file_groups: List[Dict[str, Any]],
        input_filepath: str,
        output_dir: str,
        separate_files: bool,
        progress_callback: Optional[Callable[[SplitProgress], None]]
    ) -> List[str]:
        """Generate DXF output files for each file group."""
        output_files: List[str] = []
        base_name = Path(input_filepath).stem
        
        total_groups = len(file_groups)
        
        for i, file_group in enumerate(file_groups):
            self._update_progress(
                progress_callback, "File Generation", i + 1, total_groups,
                f"Creating file {i + 1} of {total_groups}..."
            )
            
            try:
                # Create output filename based on type and index
                if separate_files and file_group['type'] != 'mixed':
                    if file_group['total_for_type'] > 1:
                        output_filename = (
                            f"{base_name}_{file_group['type']}_"
                            f"{file_group['index']:03d}.dxf"
                        )
                    else:
                        output_filename = f"{base_name}_{file_group['type']}.dxf"
                else:
                    output_filename = (
                        f"{base_name}_filtered_{file_group['index']:03d}.dxf"
                    )
                
                output_path = os.path.join(output_dir, output_filename)
                
                # Create new DXF document for this group
                group_doc = self._create_group_document(doc, file_group['entities'])
                
                # Save the document
                group_doc.saveas(output_path)
                output_files.append(output_path)
                
                entity_count = len(file_group['entities'])
                self.logger.info(
                    f"Created {output_filename} with {entity_count} entities "
                    f"of type(s): {file_group['type']}"
                )
            
            except Exception as e:
                self.logger.error(f"Error creating file {i + 1}: {e}")
                # Continue with other groups
                continue
        
        return output_files
    
    def _create_group_document(
        self, source_doc: Drawing, entities: List[Any]
    ) -> Drawing:
        """Create a new DXF document containing a specific group of entities."""
        # Create new document with same DXF version
        new_doc = ezdxf.new(source_doc.dxfversion)  # type: ignore
        
        # Copy essential document properties
        self._copy_document_structure(source_doc, new_doc)
        
        # Add entities to new document
        new_msp = new_doc.modelspace()
        
        for entity in entities:
            try:
                # Clone entity to new document
                new_entity = entity.copy()
                new_msp.add_entity(new_entity)
            except Exception as e:
                self.logger.warning(
                    f"Could not copy entity {entity.dxftype()}: {e}"
                )
                continue
        
        return new_doc
    
    def _copy_document_structure(
        self, source_doc: Drawing, target_doc: Drawing
    ) -> None:
        """Copy essential document structure (layers, styles, etc.)."""
        try:
            # Copy layers - simplified approach for mypy compatibility
            for layer_name in source_doc.layers:
                if layer_name not in target_doc.layers:
                    try:
                        target_doc.layers.add(layer_name)  # type: ignore
                    except Exception:
                        continue
            
            # Copy text styles - simplified approach
            for style_name in source_doc.styles:
                if style_name not in target_doc.styles:
                    try:
                        target_doc.styles.add(style_name)  # type: ignore
                    except Exception:
                        continue
            
            # Copy linetypes - simplified approach
            for linetype_name in source_doc.linetypes:
                if linetype_name not in target_doc.linetypes:
                    try:
                        target_doc.linetypes.add(linetype_name)  # type: ignore
                    except Exception:
                        continue
        
        except Exception as e:
            self.logger.warning(f"Error copying document structure: {e}")
            # Continue anyway - basic structure will work
