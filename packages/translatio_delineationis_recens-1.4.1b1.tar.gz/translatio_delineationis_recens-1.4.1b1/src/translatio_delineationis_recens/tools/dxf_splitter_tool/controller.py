"""
Controller for DXF Splitter Tool.

Coordinates between the Model and View components.
Follows the MVC architecture pattern.
"""

from __future__ import annotations
import logging
import threading
from typing import Dict, Any, Optional, TYPE_CHECKING
from pathlib import Path

from .model import DxfSplitterModel, SplitMethod
from .view import DxfSplitterView

if TYPE_CHECKING:
    from .model import SplitProgress, SplitResult

logger = logging.getLogger(__name__)


class DxfSplitterController:
    """
    Controller for the DXF Splitter Tool.
    
    Manages the interaction between the model and view components,
    handles user actions, and coordinates splitting operations.
    """
    
    def __init__(self):
        """Initialize the DXF Splitter controller."""
        self.model = DxfSplitterModel()
        self.view = DxfSplitterView()
        
        # Set up view callbacks
        self.view.on_load_file = self.load_file
        self.view.on_split_geographic = self.split_geographic
        self.view.on_split_entity_count = self.split_entity_count
        self.view.on_split_entity_type = self.split_entity_type
        
        # Set up model progress callback
        self.model.set_progress_callback(self.on_progress_update)
        
        logger.info("DXF Splitter Controller initialized")
    
    def load_file(self, filepath: str) -> None:
        """
        Load a DXF file and update the view with file information.
        
        Args:
            filepath: Path to the DXF file to load
        """
        try:
            logger.info(f"Loading DXF file: {filepath}")
            self.view.status_var.set("Loading file...")
            
            # Load file in model
            success = self.model.load_dxf(filepath)
            
            if success:
                # Get file analysis
                analysis = self.model.get_entity_analysis()
                
                # Update view with file information
                self.view.update_file_info(analysis)
                self.view.status_var.set(f"Loaded: {Path(filepath).name}")
                
                logger.info(f"Successfully loaded DXF file with {analysis.get('total_entities', 0)} entities")
            else:
                self.view.update_file_info({})
                self.view.status_var.set("Failed to load file")
                logger.error(f"Failed to load DXF file: {filepath}")
                
                # Show error to user
                from tkinter import messagebox
                messagebox.showerror(
                    "Load Error", 
                    f"Failed to load DXF file: {Path(filepath).name}\n\nPlease check that the file is a valid DXF file."
                )
        
        except Exception as e:
            logger.error(f"Error loading file {filepath}: {e}")
            self.view.update_file_info({})
            self.view.status_var.set("Error loading file")
            
            from tkinter import messagebox
            messagebox.showerror("Load Error", f"Error loading file: {e}")
    
    def split_geographic(self, params: Dict[str, Any]) -> None:
        """
        Perform geographic splitting in a background thread.
        
        Args:
            params: Dictionary containing splitting parameters
        """
        def split_worker():
            try:
                logger.info(f"Starting geographic split with params: {params}")
                self.view.set_processing_state(True)
                
                result = self.model.split_geographic(
                    grid_cols=params['grid_cols'],
                    grid_rows=params['grid_rows'],
                    output_dir=params['output_dir'],
                    overlap=params['overlap'],
                    include_empty=params['include_empty']
                )
                
                # Update UI on main thread
                self.view.root.after(0, lambda: self._on_split_complete(result))
                
            except Exception as e:
                logger.error(f"Geographic split error: {e}")
                error_result = self._create_error_result(f"Geographic split failed: {e}")
                self.view.root.after(0, lambda: self._on_split_complete(error_result))
        
        # Start splitting in background thread
        thread = threading.Thread(target=split_worker, daemon=True)
        thread.start()
    
    def split_entity_count(self, params: Dict[str, Any]) -> None:
        """
        Perform entity count splitting in a background thread.
        
        Args:
            params: Dictionary containing splitting parameters
        """
        def split_worker():
            try:
                logger.info(f"Starting entity count split with params: {params}")
                self.view.set_processing_state(True)
                
                result = self.model.split_by_count(
                    max_entities=params['max_entities'],
                    output_dir=params['output_dir'],
                    strategy=params['strategy']
                )
                
                # Update UI on main thread
                self.view.root.after(0, lambda: self._on_split_complete(result))
                
            except Exception as e:
                logger.error(f"Entity count split error: {e}")
                error_result = self._create_error_result(f"Entity count split failed: {e}")
                self.view.root.after(0, lambda: self._on_split_complete(error_result))
        
        # Start splitting in background thread
        thread = threading.Thread(target=split_worker, daemon=True)
        thread.start()
    
    def split_entity_type(self, params: Dict[str, Any]) -> None:
        """
        Perform entity type splitting in a background thread.
        
        Args:
            params: Dictionary containing splitting parameters
        """
        def split_worker():
            try:
                logger.info(f"Starting entity type split with params: {params}")
                self.view.set_processing_state(True)
                
                result = self.model.split_by_type(
                    selected_types=params['selected_types'],
                    max_entities=params['max_entities'],
                    output_dir=params['output_dir'],
                    separate_files=params['separate_files']
                )
                
                # Update UI on main thread
                self.view.root.after(0, lambda: self._on_split_complete(result))
                
            except Exception as e:
                logger.error(f"Entity type split error: {e}")
                error_result = self._create_error_result(f"Entity type split failed: {e}")
                self.view.root.after(0, lambda: self._on_split_complete(error_result))
        
        # Start splitting in background thread
        thread = threading.Thread(target=split_worker, daemon=True)
        thread.start()
    
    def on_progress_update(self, progress: SplitProgress) -> None:
        """
        Handle progress updates from the model.
        
        Args:
            progress: Progress information
        """
        # Update UI on main thread
        self.view.root.after(0, lambda: self.view.update_progress(progress))
    
    def _on_split_complete(self, result: SplitResult) -> None:
        """
        Handle completion of a splitting operation.
        
        Args:
            result: Result of the splitting operation
        """
        self.view.set_processing_state(False)
        self.view.show_result(result)
        
        if result.success:
            logger.info(f"Split completed successfully: {len(result.output_files)} files created")
        else:
            logger.error(f"Split failed: {result.error_message}")
    
    def _create_error_result(self, error_message: str) -> SplitResult:
        """
        Create a SplitResult for an error condition.
        
        Args:
            error_message: Error message to include
            
        Returns:
            SplitResult indicating failure
        """
        from .model import SplitResult
        return SplitResult(success=False, output_files=[], error_message=error_message)
    
    def estimate_output_files(self, method: SplitMethod, **kwargs: Any) -> int:
        """
        Estimate the number of output files for a given method and parameters.
        
        Args:
            method: Splitting method
            **kwargs: Method-specific parameters
            
        Returns:
            Estimated number of output files
        """
        return self.model.estimate_output_files(method, **kwargs)
    
    def get_available_entity_types(self) -> list[str]:
        """
        Get the list of available entity types in the loaded DXF file.
        
        Returns:
            List of entity type names
        """
        return self.model.get_available_entity_types()
    
    def run(self) -> None:
        """Start the application."""
        logger.info("Starting DXF Splitter Tool")
        self.view.run()
    
    def shutdown(self) -> None:
        """Shutdown the application."""
        logger.info("Shutting down DXF Splitter Tool")
        self.view.destroy()


def main() -> None:
    """Main entry point for the DXF Splitter Tool."""
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    try:
        # Create and run the application
        controller = DxfSplitterController()
        controller.run()
    except KeyboardInterrupt:
        logger.info("Application interrupted by user")
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        raise


if __name__ == "__main__":
    main()
