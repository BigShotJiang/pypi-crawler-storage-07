"""
Model for DXF Splitter Tool.

Handles DXF file loading, processing, and coordination of splitting operations.
Follows the MVC architecture pattern.
"""

from __future__ import annotations
import os
import logging
from typing import Dict, List, Optional, Any, Callable, TYPE_CHECKING
from dataclasses import dataclass
from enum import Enum

import ezdxf
from ezdxf.document import Drawing
from ezdxf.math import BoundingBox

if TYPE_CHECKING:
    from ezdxf.entities import DXFEntity, DXFGraphic  # type: ignore
    from ezdxf.layouts import Modelspace  # type: ignore
    from .splitters import GeographicSplitter, EntityCountSplitter, EntityTypeSplitter
else:
    # Runtime imports to avoid mypy import issues
    from .splitters import GeographicSplitter, EntityCountSplitter, EntityTypeSplitter

logger = logging.getLogger(__name__)


class SplitMethod(Enum):
    """Enumeration of available splitting methods."""
    GEOGRAPHIC = "geographic"
    ENTITY_COUNT = "entity_count"
    ENTITY_TYPE = "entity_type"


@dataclass
class SplitProgress:
    """Progress tracking for splitting operations."""
    phase: str
    current_step: int
    total_steps: int
    message: str

    @property
    def percentage(self) -> float:
        """Calculate completion percentage."""
        if self.total_steps == 0:
            return 0.0
        return min(100.0, (self.current_step / self.total_steps) * 100.0)


@dataclass
class SplitResult:
    """Result of a splitting operation."""
    success: bool
    output_files: List[str]
    error_message: Optional[str] = None
    warnings: Optional[List[str]] = None

    def __post_init__(self) -> None:
        if self.warnings is None:
            self.warnings = []


class DxfSplitterModel:
    """
    Core model for DXF splitting operations.

    Handles DXF file loading, validation, and coordinates splitting operations
    using various algorithms. Provides progress tracking and error handling.
    """

    def __init__(self) -> None:
        """Initialize the DXF splitter model."""
        self.dxf_doc: Optional[Drawing] = None
        self.input_filepath: Optional[str] = None
        self.output_directory: Optional[str] = None
        self.progress_callback: Optional[Callable[[SplitProgress], None]] = None

        # Initialize splitters
        self.geographic_splitter = GeographicSplitter()
        self.entity_count_splitter = EntityCountSplitter()
        self.entity_type_splitter = EntityTypeSplitter()

        # Cache for entity analysis
        self._entity_cache: Optional[Dict[str, Any]] = None
        self._bbox_cache: Optional[BoundingBox] = None

    def set_progress_callback(
        self, callback: Callable[[SplitProgress], None]
    ) -> None:
        """Set callback function for progress updates."""
        self.progress_callback = callback

    def _update_progress(
        self, phase: str, current: int, total: int, message: str
    ) -> None:
        """Update progress and notify callback if set."""
        if self.progress_callback:
            progress = SplitProgress(phase, current, total, message)
            self.progress_callback(progress)

    def load_dxf(self, filepath: str) -> bool:
        """
        Load a DXF file for processing.

        Args:
            filepath: Path to the DXF file to load

        Returns:
            bool: True if loaded successfully, False otherwise
        """
        try:
            self._update_progress(
                "Loading", 0, 3, f"Loading DXF file: {filepath}"
            )

            # Validate file exists and is readable
            if not os.path.exists(filepath):
                logger.error(f"DXF file not found: {filepath}")
                return False

            if not os.access(filepath, os.R_OK):
                logger.error(f"Cannot read DXF file: {filepath}")
                return False

            self._update_progress("Loading", 1, 3, "Reading DXF structure...")

            # Load the DXF document
            self.dxf_doc = ezdxf.readfile(filepath)  # type: ignore
            self.input_filepath = filepath

            self._update_progress("Loading", 2, 3, "Analyzing entities...")

            # Clear caches
            self._entity_cache = None
            self._bbox_cache = None

            # Validate document has content
            if not self._validate_document():
                return False

            self._update_progress(
                "Loading", 3, 3, "DXF file loaded successfully"
            )
            logger.info(f"Successfully loaded DXF file: {filepath}")
            return True

        except Exception as e:
            logger.error(f"Error loading DXF file {filepath}: {e}")
            self.dxf_doc = None
            self.input_filepath = None
            return False

    def _validate_document(self) -> bool:
        """Validate the loaded DXF document."""
        if not self.dxf_doc:
            return False

        try:
            # Check if modelspace exists and has entities
            msp = self.dxf_doc.modelspace()
            if len(msp) == 0:
                logger.warning("DXF file has no entities in modelspace")
                return False

            return True

        except Exception as e:
            logger.error(f"Error validating DXF document: {e}")
            return False

    def get_entity_analysis(self) -> Dict[str, Any]:
        """
        Get analysis of entities in the loaded DXF file.

        Returns:
            Dict containing entity counts, types, and bounding box info
        """
        if not self.dxf_doc:
            return {}

        if self._entity_cache is not None:
            return self._entity_cache

        try:
            msp = self.dxf_doc.modelspace()
            entities = list(msp)

            # Count entities by type
            type_counts: Dict[str, int] = {}
            layer_counts: Dict[str, int] = {}

            for entity in entities:
                entity_type = entity.dxftype()
                type_counts[entity_type] = type_counts.get(entity_type, 0) + 1

                layer = getattr(entity.dxf, 'layer', '0')
                layer_counts[layer] = layer_counts.get(layer, 0) + 1

            # Calculate bounding box
            bbox = self.get_bounding_box()

            self._entity_cache = {
                'total_entities': len(entities),
                'entity_types': type_counts,
                'layer_counts': layer_counts,
                'bounding_box': bbox,
                'has_3d_entities': self._check_3d_entities(entities)
            }

            return self._entity_cache

        except Exception as e:
            logger.error(f"Error analyzing entities: {e}")
            return {}

    def get_bounding_box(self) -> Optional[BoundingBox]:
        """Get the bounding box of all entities in the DXF file."""
        if not self.dxf_doc:
            return None

        if self._bbox_cache is not None:
            return self._bbox_cache

        try:
            from ezdxf import bbox

            msp = self.dxf_doc.modelspace()
            entities = list(msp)

            if not entities:
                return None

            # Calculate bounding box using ezdxf bbox module
            cache = bbox.Cache()
            extents = bbox.extents(entities, cache=cache)

            if extents.has_data:
                self._bbox_cache = extents
                return extents

            return None

        except Exception as e:
            logger.error(f"Error calculating bounding box: {e}")
            return None

    def _check_3d_entities(self, entities: List[Any]) -> bool:
        """Check if any entities have 3D coordinates."""
        try:
            for entity in entities[:100]:  # Sample first 100 entities
                if hasattr(entity.dxf, 'location'):
                    loc = entity.dxf.location
                    if len(loc) > 2 and loc.z != 0:
                        return True
                elif hasattr(entity.dxf, 'start'):
                    if len(entity.dxf.start) > 2 and entity.dxf.start.z != 0:
                        return True
            return False
        except Exception:
            return False

    def split_geographic(
        self,
        grid_cols: int,
        grid_rows: int,
        output_dir: str,
        overlap: float = 0.0,
        include_empty: bool = False
    ) -> SplitResult:
        """
        Split DXF file geographically using a grid system.

        Args:
            grid_cols: Number of grid columns
            grid_rows: Number of grid rows
            output_dir: Output directory for split files
            overlap: Overlap buffer in drawing units
            include_empty: Whether to create files for empty grid cells

        Returns:
            SplitResult with operation results
        """
        if not self.input_filepath:
            return SplitResult(False, [], "No DXF file loaded")

        try:
            return self.geographic_splitter.split_by_grid(
                self.input_filepath,
                grid_cols,
                grid_rows,
                output_dir,
                overlap,
                include_empty,
                self.progress_callback
            )
        except Exception as e:
            logger.error(f"Geographic splitting failed: {e}")
            return SplitResult(False, [], f"Geographic splitting failed: {e}")

    def split_by_count(
        self,
        max_entities: int,
        output_dir: str,
        strategy: str = "sequential"
    ) -> SplitResult:
        """
        Split DXF file by entity count.

        Args:
            max_entities: Maximum entities per output file
            output_dir: Output directory for split files
            strategy: Distribution strategy ("sequential" or "balanced")

        Returns:
            SplitResult with operation results
        """
        if not self.dxf_doc or not self.input_filepath:
            return SplitResult(False, [], "No DXF file loaded")

        try:
            return self.entity_count_splitter.split_by_count(
                self.dxf_doc,
                self.input_filepath,
                max_entities,
                output_dir,
                strategy,
                self.progress_callback
            )
        except Exception as e:
            logger.error(f"Entity count splitting failed: {e}")
            return SplitResult(
                False, [], f"Entity count splitting failed: {e}"
            )

    def split_by_type(
        self,
        selected_types: List[str],
        max_entities: int,
        output_dir: str,
        separate_files: bool = False
    ) -> SplitResult:
        """
        Split DXF file by entity type.

        Args:
            selected_types: List of entity types to include
            max_entities: Maximum entities per output file
            output_dir: Output directory for split files
            separate_files: Create separate file for each entity type

        Returns:
            SplitResult with operation results
        """
        if not self.dxf_doc or not self.input_filepath:
            return SplitResult(False, [], "No DXF file loaded")

        try:
            return self.entity_type_splitter.split_by_type(
                self.dxf_doc,
                self.input_filepath,
                selected_types,
                max_entities,
                output_dir,
                separate_files,
                self.progress_callback
            )
        except Exception as e:
            logger.error(f"Entity type splitting failed: {e}")
            return SplitResult(False, [], f"Entity type splitting failed: {e}")

    def get_available_entity_types(self) -> List[str]:
        """Get list of entity types available in the loaded DXF file."""
        analysis = self.get_entity_analysis()
        return list(analysis.get('entity_types', {}).keys())

    def estimate_output_files(self, method: SplitMethod, **kwargs: Any) -> int:
        """
        Estimate number of output files for a given splitting method.

        Args:
            method: Splitting method to estimate for
            **kwargs: Method-specific parameters

        Returns:
            Estimated number of output files
        """
        if not self.dxf_doc:
            return 0

        analysis = self.get_entity_analysis()
        total_entities = int(analysis.get('total_entities', 0))

        if method == SplitMethod.GEOGRAPHIC:
            grid_cols = int(kwargs.get('grid_cols', 3))
            grid_rows = int(kwargs.get('grid_rows', 3))
            return grid_cols * grid_rows

        elif method == SplitMethod.ENTITY_COUNT:
            max_entities = int(kwargs.get('max_entities', 1000))
            return max(1, (total_entities + max_entities - 1) // max_entities)

        elif method == SplitMethod.ENTITY_TYPE:
            selected_types = kwargs.get('selected_types', [])
            max_entities = int(kwargs.get('max_entities', 500))
            separate_files = bool(kwargs.get('separate_files', False))

            if separate_files:
                # Estimate files per type
                type_counts = analysis.get('entity_types', {})
                total_files = 0
                for entity_type in selected_types:
                    count = int(type_counts.get(entity_type, 0))
                    files_for_type = max(
                        1, (count + max_entities - 1) // max_entities
                    )
                    total_files += files_for_type
                return total_files
            else:
                # Count total entities of selected types
                type_counts = analysis.get('entity_types', {})
                selected_count = sum(
                    int(type_counts.get(t, 0)) for t in selected_types
                )
                return max(
                    1, (selected_count + max_entities - 1) // max_entities
                )

        return 1
