# Copyright (c) 2021-2022, Manfred Moitzi
# License: MIT License
from __future__ import annotations
from typing import BinaryIO, Optional, Sequence
from ezdxf.lldxf.validator import is_dxf_file, DXFStructureError
from pathlib import Path


class TagWriter:
    """
    Writes DXF tags (group code and value as bytes) to a binary file-like object.
    """
    def __init__(self, fp: BinaryIO) -> None:
        """
        Args:
            fp: A binary file-like object to write tags to.
        """
        self.fp: BinaryIO = fp

    def write(self, raw_code_str: bytes, raw_value_str: bytes) -> None:
        """
        Write a group code and value (as bytes) to the file.
        Args:
            raw_code_str: The group code as bytes.
            raw_value_str: The group value as bytes.
        """
        self.fp.write(raw_code_str)
        self.fp.write(raw_value_str)


class ThumbnailRemover(TagWriter):
    """
    Specialized TagWriter that removes the THUMBNAILIMAGE section from a DXF file.
    """
    def __init__(self, fp: BinaryIO) -> None:
        """
        Args:
            fp: A binary file-like object to write tags to.
        """
        super().__init__(fp)
        self._start_section: bool = False
        self._skip_tags: bool = False
        self._section_code: Optional[bytes] = None
        self._section_value: Optional[bytes] = None
        self.removed_thumbnail_image: bool = False

    def write(self, raw_code_str: bytes, raw_value_str: bytes) -> None:
        """
        Write a group code and value, skipping the THUMBNAILIMAGE section if found.
        Args:
            raw_code_str: The group code as bytes.
            raw_value_str: The group value as bytes.
        """
        code: bytes = raw_code_str.strip()
        value: bytes = raw_value_str.strip()
        if self._start_section:
            self._start_section = False
            if code == b"2" and value == b"THUMBNAILIMAGE":
                self._skip_tags = True
                self.removed_thumbnail_image = True
            else:
                # write buffered section tag:
                super().write(self._section_code, self._section_value)  # type: ignore

        if code == b"0":
            if value == b"SECTION":
                self._start_section = True
                self._skip_tags = False
                # buffer section tag:
                self._section_code = raw_code_str
                self._section_value = raw_value_str
                return
            elif value == b"ENDSEC":
                skip = self._skip_tags
                self._skip_tags = False
                if skip:  # don't write ENDSEC
                    return

        if not self._skip_tags:
            super().write(raw_code_str, raw_value_str)


def strip_tags(
    infile: BinaryIO,
    tagwriter: TagWriter,
    codes: Sequence[int],
    verbose: bool = False,
) -> int:
    """
    Remove tags with specified group codes from a DXF file stream.
    Args:
        infile: Binary file-like object to read from.
        tagwriter: TagWriter instance to write filtered tags to.
        codes: Sequence of group codes to remove.
        verbose: If True, print details of removed tags.
    Returns:
        The number of tags removed.
    Raises:
        DXFStructureError: If the DXF file is malformed.
    """
    search_codes: set[int] = set(codes)
    line_number: int = 1
    removed_tags: int = 0
    while True:
        try:
            raw_code_str = infile.readline()
        except EOFError:
            raw_code_str = b""
        if raw_code_str == b"":  # regular end of file
            return removed_tags
        try:
            code: int = int(raw_code_str)
        except ValueError:
            code_str: str = raw_code_str.strip().decode(encoding="utf8", errors="ignore")
            raise DXFStructureError(
                f'CANCELED: "{getattr(infile, "name", "<unknown>")}" - found invalid '
                f'group code "{code_str}" at line {line_number}'
            )

        try:
            raw_value_str: bytes = infile.readline()
        except EOFError:
            raw_value_str = b""

        if raw_value_str == b"":
            raise DXFStructureError(
                f'CANCELED: "{getattr(infile, "name", "<unknown>")}" - premature end of file'
            )
        line_number += 2
        if code not in search_codes:
            tagwriter.write(raw_code_str, raw_value_str)
        else:
            if verbose:
                value = raw_value_str.strip()
                _value = value.decode(encoding="utf8", errors="ignore")
                print(f'removing tag: ({code}, "{_value}")')
            removed_tags += 1


def safe_rename(source: Path, target: Path, backup: bool = True, verbose: bool = False) -> bool:
    """
    Safely rename a file, optionally creating a backup of the target file.
    Args:
        source: Path to the source file.
        target: Path to the target file.
        backup: If True, keep a backup of the target file (with .bak extension).
        verbose: If True, print details of renaming and backup actions.
    Returns:
        True if the rename was successful, False otherwise.
    """
    backup_file: Path = target.with_suffix(".bak")
    backup_file.unlink(missing_ok=True)
    _target: Path = Path(target)
    if _target.exists():
        if verbose:
            print(f'Renaming "{_target.name}" to "{backup_file.name}"')
        try:
            _target.rename(backup_file)
        except IOError as e:
            print(f"IOError during backup: {str(e)}")
            return False

    if verbose:
        print(f'Renaming "{source.name}" to "{target.name}"')
    try:
        source.rename(target)
    except IOError as e:
        print(f"IOError during rename: {str(e)}")
        return False

    if not backup:
        if verbose:
            print(f'Deleting backup file "{backup_file.name}"')
        backup_file.unlink(missing_ok=True)
    return True


DEFAULT_CODES = (999,)


def strip(
    filename: str,
    backup: bool = False,
    thumbnail: bool = False,
    verbose: bool = False,
    codes: Sequence[int] = DEFAULT_CODES,
) -> None:
    """
    Remove specified DXF tags and/or the THUMBNAILIMAGE section from a DXF file in-place.
    Args:
        filename: Path to the DXF file.
        backup: If True, keep a backup of the original file.
        thumbnail: If True, remove the THUMBNAILIMAGE section.
        verbose: If True, print detailed progress and actions.
        codes: Sequence of group codes to remove (default: (999,)).
    """
    def remove_tmp_file() -> None:
        if tmp_file.exists():
            if verbose:
                print(f'Deleting temp file: "{tmp_file.name}"')
            tmp_file.unlink(missing_ok=True)

    if verbose:
        print(f'\nProcessing file: "{filename}"')
    try:
        if not is_dxf_file(filename):
            print(
                f'CANCELED: "{filename}" is not a DXF file, binary DXF files are not supported.'
            )
            return
    except IOError as e:
        print(f"IOError during DXF check: {str(e)}")
        return
    source_file: Path = Path(filename)
    tmp_file: Path = source_file.with_suffix(".ezdxf.tmp")
    error: bool = False
    tagwriter: TagWriter
    if verbose:
        print(f'Creating temporary copy: "{tmp_file.name}"')
    with open(tmp_file, "wb") as fp, open(source_file, "rb") as infile:
        if thumbnail:
            tagwriter = ThumbnailRemover(fp)
        else:
            tagwriter = TagWriter(fp)
        try:
            removed_tags: int = strip_tags(infile, tagwriter, codes=codes, verbose=verbose)
        except IOError as e:
            print(f"IOError during tag stripping: {str(e)}")
            error = True
        except DXFStructureError as e:
            print(str(e))
            error = True

    if not error:
        rename: bool = False
        if thumbnail and getattr(tagwriter, 'removed_thumbnail_image', False):
            print(f'"{source_file.name}" - removed THUMBNAILIMAGE section')
            rename = True

        if removed_tags > 0:
            tags = "tag" if removed_tags == 1 else "tags"
            print(f'"{source_file.name}" - {removed_tags} {tags} removed')
            rename = True

        if rename:
            safe_rename(tmp_file, source_file, backup, verbose)

    remove_tmp_file()
