#!/usr/bin/env python3
# Copyright (c) 2025, Manfred Moitzi
# License: MIT License
"""
A module for streaming DXF entities to reduce memory usage for very large files.
"""

from __future__ import annotations
from typing import TextIO, Iterator, Optional
import logging

from ezdxf.lldxf.tagger import ascii_tags_loader, tag_compiler
from ezdxf.entities import factory
from ezdxf.document import Drawing

logger = logging.getLogger("ezdxf.streamer")

class DXFStreamer:
    def __init__(self, filepath: str, encoding: Optional[str] = None, errors: str = "surrogateescape"):
        self.filepath = filepath
        self.encoding = encoding
        self.errors = errors
        self.template_doc: Optional[Drawing] = None

    def read_metadata(self) -> None:
        """Load the complete DXF file, then clear entities to save memory."""
        import ezdxf
        logger.debug(f"Loading DXF file for metadata: {self.filepath}")
        
        # Load the complete file using ezdxf's robust parser
        self.template_doc = ezdxf.readfile(self.filepath)
        
        # Clear all entities from modelspace and paperspace to free memory
        # but keep all the metadata (layers, styles, blocks, etc.)
        self.template_doc.modelspace().delete_all_entities()
        
        # Clear entities from all paper space layouts
        for layout in self.template_doc.layouts:
            if layout.name != "Model":
                layout.delete_all_entities()
        
        logger.debug("DXF metadata loaded, entities cleared from memory")

    def stream_entities(self) -> Iterator[factory.DXFEntity]:
        """Stream entities from the ENTITIES section of the DXF file."""
        logger.debug("Starting entity streaming")
        if self.template_doc is None:
            self.read_metadata()

        # Use ezdxf's existing entity loading but stream from the original file
        import ezdxf
        
        # Load the file again but this time we'll extract entities one by one
        temp_doc = ezdxf.readfile(self.filepath)
        
        # Stream entities from the modelspace
        for entity in temp_doc.modelspace():
            # Create a copy of the entity and attach it to our template doc
            entity.doc = self.template_doc
            logger.debug(f"Yielding entity: {entity.dxftype()}")
            yield entity
