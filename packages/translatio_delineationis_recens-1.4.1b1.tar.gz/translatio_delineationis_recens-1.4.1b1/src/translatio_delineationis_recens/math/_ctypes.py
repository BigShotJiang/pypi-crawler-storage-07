"""
Abstraction layer for mathematical types and functions in ezdxf.

This module conditionally imports either C-accelerated (if available) or pure Python
implementations of vector, matrix, Bézier, B-spline, and geometric helper types/functions.
It also defines type aliases for use throughout the ezdxf codebase.

- If the C extensions are available (USE_C_EXT is True), imports are from ezdxf.acc.
- Otherwise, imports are from the local pure Python modules.

This allows the rest of the codebase to use `from ._ctypes import ...` for a unified API
regardless of the underlying implementation.
"""

from typing import Union, Sequence
from typing_extensions import TypeAlias
from ezdxf.acc import USE_C_EXT

__all__ = [
    "Vec3",
    "Vec2",
    "AnyVec",
    "UVec",
    "X_AXIS",
    "Y_AXIS",
    "Z_AXIS",
    "NULLVEC",
    "distance",
    "lerp",
    "Matrix44",
    "Bezier4P",
    "Bezier3P",
    "Basis",
    "Evaluator",
    "cubic_bezier_arc_parameters",
    "cubic_bezier_from_arc",
    "cubic_bezier_from_ellipse",
    "has_clockwise_orientation",
    "intersection_line_line_2d",
    "intersection_ray_ray_3d",
    "arc_angle_span_deg",
    "arc_angle_span_rad",
    "is_point_in_polygon_2d",
    "world_mercator_to_gps",
    "gps_to_world_mercator",
]

# Conditional import of math types/functions:
if USE_C_EXT:
    from ezdxf.acc.vector import (
        Vec3,
        Vec2,
        X_AXIS,
        Y_AXIS,
        Z_AXIS,
        NULLVEC,
        distance,
        lerp,
    )
    from ezdxf.acc.matrix44 import Matrix44
    from ezdxf.acc.bezier4p import (
        Bezier4P,
        cubic_bezier_arc_parameters,
        cubic_bezier_from_arc,
        cubic_bezier_from_ellipse,
    )
    from ezdxf.acc.bezier3p import Bezier3P
    from ezdxf.acc.bspline import Basis, Evaluator
    from ezdxf.acc.construct import (
        has_clockwise_orientation,
        intersection_line_line_2d,
        intersection_ray_ray_3d,
        arc_angle_span_deg,
        arc_angle_span_rad,
        is_point_in_polygon_2d,
        world_mercator_to_gps,
        gps_to_world_mercator,
    )
else:
    from ._vector import (
        Vec3,
        Vec2,
        X_AXIS,
        Y_AXIS,
        Z_AXIS,
        NULLVEC,
        distance,
        lerp,
    )
    from ._matrix44 import Matrix44
    from ._bezier4p import (
        Bezier4P,
        cubic_bezier_arc_parameters,
        cubic_bezier_from_arc,
        cubic_bezier_from_ellipse,
    )
    from ._bezier3p import Bezier3P
    from ._bspline import Basis, Evaluator
    from ._construct import (
        has_clockwise_orientation,
        intersection_line_line_2d,
        intersection_ray_ray_3d,
        arc_angle_span_deg,
        arc_angle_span_rad,
        is_point_in_polygon_2d,
        world_mercator_to_gps,
        gps_to_world_mercator,
    )

# Type aliases for vectors used throughout ezdxf:
AnyVec: TypeAlias = Union[Vec2, Vec3]
"""
AnyVec: Type alias for either a 2D or 3D vector (Vec2 or Vec3).
"""
UVec: TypeAlias = Union[Sequence[float], Vec2, Vec3]
"""
UVec: Type alias for a vector-like object (sequence of floats, Vec2, or Vec3).
"""
