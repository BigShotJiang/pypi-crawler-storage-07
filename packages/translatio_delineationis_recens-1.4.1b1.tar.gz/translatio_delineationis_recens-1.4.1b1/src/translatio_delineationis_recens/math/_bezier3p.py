# Copyright (c) 2021-2024 Manfred Moitzi
# License: MIT License
# pylint: disable=unused-variable
from __future__ import annotations
from typing import (
    Iterator,
    Sequence,
    Optional,
    Generic,
    TypeVar,
)
import math

# The pure Python implementation can't import from ._ctypes or ezdxf.math!
from ._vector import Vec3, Vec2
from ._matrix44 import Matrix44


__all__ = ["Bezier3P"]


def check_if_in_valid_range(t: float) -> None:
    """
    Check if the parameter t is within the valid range [0.0, 1.0].

    Args:
        t (float): Parameter to check.
    Raises:
        ValueError: If t is not within [0.0, 1.0].
    """
    if not isinstance(t, (float, int)):
        raise TypeError(f"Parameter 't' must be a float or int, got {type(t).__name__}.")
    if not 0.0 <= t <= 1.0:
        raise ValueError(f"Parameter 't'={t} is not in range [0.0, 1.0].")


T = TypeVar("T", Vec2, Vec3)


class Bezier3P(Generic[T]):
    """
    Implements an optimized quadratic Bézier curve for exactly 3 control points.

    The class supports points of type :class:`Vec2` and :class:`Vec3` as input. Instances are immutable.

    Args:
        defpoints (Sequence[T]): Sequence of three definition points as Vec2 or Vec3 compatible objects.

    Raises:
        ValueError: If the number of control points is not exactly three.
        TypeError: If the control points are not Vec2 or Vec3.
    """

    __slots__ = ("_control_points", "_offset")

    def __init__(self, defpoints: Sequence[T]) -> None:
        if not isinstance(defpoints, Sequence):
            raise TypeError(f"defpoints must be a sequence, got {type(defpoints).__name__}.")
        if len(defpoints) != 3:
            raise ValueError(f"Three control points required, got {len(defpoints)}.")
        point_type = defpoints[0].__class__
        if point_type.__name__ not in ("Vec2", "Vec3"):
            raise TypeError(f"Invalid point type: {point_type.__name__}. Only Vec2 or Vec3 allowed.")
        offset: T = defpoints[0]
        self._offset: T = offset
        # Move the curve to the origin to reduce floating point errors:
        self._control_points: tuple[T, ...] = tuple(p - offset for p in defpoints)

    @property
    def control_points(self) -> tuple[T, T, T]:
        """
        Returns the control points as a tuple of Vec2 or Vec3 objects, restored to their original positions.

        Returns:
            tuple[T, T, T]: The three control points.
        """
        _, p1, p2 = self._control_points
        offset = self._offset
        return (offset, p1 + offset, p2 + offset)

    def tangent(self, t: float) -> T:
        """
        Returns the direction vector of the tangent at parameter t on the Bézier curve.

        Args:
            t (float): Curve position in the range [0, 1].

        Returns:
            T: Tangent direction vector at position t.

        Raises:
            ValueError: If t is not within [0, 1].
        """
        check_if_in_valid_range(t)
        return self._get_curve_tangent(t)

    def point(self, t: float) -> T:
        """
        Returns the point at parameter t on the Bézier curve.

        Args:
            t (float): Curve position in the range [0, 1].

        Returns:
            T: Point on the Bézier curve at position t.

        Raises:
            ValueError: If t is not within [0, 1].
        """
        check_if_in_valid_range(t)
        return self._get_curve_point(t)

    def approximate(self, segments: int) -> Iterator[T]:
        """
        Approximate the Bézier curve by vertices, yielding (segments + 1) points.

        Args:
            segments (int): Number of segments for approximation (must be >= 1).

        Yields:
            T: Points along the approximated Bézier curve.

        Raises:
            ValueError: If segments < 1.
        """
        if not isinstance(segments, int):
            raise TypeError(f"segments must be an int, got {type(segments).__name__}.")
        if segments < 1:
            raise ValueError(f"segments must be >= 1, got {segments}.")
        delta_t: float = 1.0 / segments
        cp = self.control_points
        yield cp[0]
        for segment in range(1, segments):
            yield self._get_curve_point(delta_t * segment)
        yield cp[2]

    def approximated_length(self, segments: int = 128) -> float:
        """
        Returns an estimated length of the Bézier curve by approximating it with line segments.

        Args:
            segments (int): Number of segments for approximation (default: 128).

        Returns:
            float: Estimated length of the Bézier curve.
        """
        length: float = 0.0
        prev_point: Optional[T] = None
        for point in self.approximate(segments):
            if prev_point is not None:
                length += prev_point.distance(point)
            prev_point = point
        return length

    def flattening(self, distance: float, segments: int = 4) -> Iterator[T]:
        """
        Adaptively flatten the Bézier curve into line segments using recursive subdivision.

        Args:
            distance (float): Maximum allowed distance from the midpoint of the quadratic curve to the midpoint of the linear segment before subdivision occurs.
            segments (int): Minimum segment count (default: 4).

        Yields:
            T: Points along the flattened Bézier curve.

        Raises:
            ValueError: If distance is not positive or segments < 1.
        """
        if not isinstance(distance, (float, int)) or distance <= 0:
            raise ValueError(f"distance must be a positive float, got {distance}.")
        if not isinstance(segments, int) or segments < 1:
            raise ValueError(f"segments must be >= 1, got {segments}.")
        stack: list[tuple[float, T]] = []
        dt: float = 1.0 / segments
        t0: float = 0.0
        t1: float
        cp = self.control_points
        start_point: T = cp[0]
        end_point: T

        yield start_point
        while t0 < 1.0:
            t1 = t0 + dt
            if math.isclose(t1, 1.0):
                end_point = cp[2]
                t1 = 1.0
            else:
                end_point = self._get_curve_point(t1)

            while True:
                mid_t: float = (t0 + t1) * 0.5
                mid_point: T = self._get_curve_point(mid_t)
                chk_point: T = start_point.lerp(end_point)

                d = chk_point.distance(mid_point)
                if d < distance:
                    yield end_point
                    t0 = t1
                    start_point = end_point
                    if stack:
                        t1, end_point = stack.pop()
                    else:
                        break
                else:
                    stack.append((t1, end_point))
                    t1 = mid_t
                    end_point = mid_point

    def _get_curve_point(self, t: float) -> T:
        """
        Compute the Bézier curve point at parameter t (private method).

        Args:
            t (float): Curve position in the range [0, 1].

        Returns:
            T: Point on the Bézier curve at position t.
        """
        _, p1, p2 = self._control_points
        _1_minus_t = 1.0 - t
        b = 2.0 * t * _1_minus_t
        c = t * t
        # Offset is added last for numerical stability
        return p1 * b + p2 * c + self._offset

    def _get_curve_tangent(self, t: float) -> T:
        """
        Compute the tangent vector at parameter t (private method).

        Args:
            t (float): Curve position in the range [0, 1].

        Returns:
            T: Tangent vector at position t (not normalized).
        """
        _, p1, p2 = self._control_points
        b = 2.0 - 4.0 * t
        c = 2.0 * t
        return p1 * b + p2 * c

    def reverse(self) -> Bezier3P[T]:
        """
        Returns a new Bézier curve with the control point order reversed.

        Returns:
            Bezier3P[T]: New Bézier curve with reversed control points.
        """
        return Bezier3P(list(reversed(self.control_points)))

    def transform(self, m: Matrix44) -> Bezier3P[Vec3]:
        """
        Apply a 4x4 transformation matrix to the Bézier curve, always returning a 3D curve.

        Args:
            m (Matrix44): 4x4 transformation matrix.

        Returns:
            Bezier3P[Vec3]: Transformed Bézier curve as a 3D curve.
        """
        defpoints = Vec3.generate(self.control_points)
        return Bezier3P(tuple(m.transform_vertices(defpoints)))
