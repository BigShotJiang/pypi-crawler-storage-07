# Copyright (c) 2021-2022, Manfred Moitzi
# License: MIT License
# Pure Python implementation of the B-spline basis function.
from __future__ import annotations
from typing import Iterable, Sequence, Optional
import math
import bisect

# The pure Python implementation can't import from ._ctypes or ezdxf.math!
from ._vector import Vec3, NULLVEC
from .linalg import binomial_coefficient

__all__ = ["Basis", "Evaluator"]


class Basis:
    """
    Immutable B-spline basis function class.

    Args:
        knots (Iterable[float]): Knot vector.
        order (int): Spline order (degree + 1).
        count (int): Number of control points.
        weights (Optional[Sequence[float]]): Optional weights for rational B-splines.

    Raises:
        ValueError: If the knot or weight counts are invalid.
    """

    __slots__ = ("_knots", "_weights", "_order", "_count")

    def __init__(
        self,
        knots: Iterable[float],
        order: int,
        count: int,
        weights: Optional[Sequence[float]] = None,
    ) -> None:
        self._knots: tuple[float, ...] = tuple(float(k) for k in knots)
        self._weights: tuple[float, ...] = tuple(float(w) for w in (weights or []))
        self._order: int = int(order)
        self._count: int = int(count)

        # validation checks:
        len_weights = len(self._weights)
        if len_weights != 0 and len_weights != self._count:
            raise ValueError(
                f"Invalid weight count: expected {self._count}, got {len_weights}."
            )
        if len(self._knots) != self._order + self._count:
            raise ValueError(
                f"Invalid knot count: expected {self._order + self._count}, got {len(self._knots)}."
            )

    @property
    def max_t(self) -> float:
        """
        Returns the maximum knot value (typically the end parameter value for the curve).
        """
        return self._knots[-1]

    @property
    def order(self) -> int:
        """
        Returns the order (degree + 1) of the B-spline.
        """
        return self._order

    @property
    def degree(self) -> int:
        """
        Returns the degree of the B-spline (order - 1).
        """
        return self._order - 1

    @property
    def knots(self) -> tuple[float, ...]:
        """
        Returns the knot vector as a tuple of floats.
        """
        return self._knots

    @property
    def weights(self) -> tuple[float, ...]:
        """
        Returns the weights as a tuple of floats (empty if not rational).
        """
        return self._weights

    @property
    def is_rational(self) -> bool:
        """
        Returns True if the curve is a rational B-spline (has weights).
        """
        return bool(self._weights)

    def basis_vector(self, t: float) -> list[float]:
        """
        Returns the expanded basis vector for parameter t.

        Args:
            t (float): Curve parameter.
        Returns:
            list[float]: Expanded basis vector (length = number of control points).
        """
        span = self.find_span(t)
        p = self._order - 1
        front = span - p
        back = self._count - span - 1
        basis = self.basis_funcs(span, t)
        return ([0.0] * front) + basis + ([0.0] * back)

    def find_span(self, u: float) -> int:
        """
        Determine the knot span index for parameter u.

        Args:
            u (float): Curve parameter.
        Returns:
            int: Knot span index.
        """
        knots = self._knots
        count = self._count
        if u >= knots[count]:
            return count - 1
        p = self._order - 1
        if knots[p] == 0.0:
            # Use binary search for common clamped splines
            return bisect.bisect_right(knots, u, p, count) - 1
        else:
            # Use linear search for other cases
            span = 0
            while span < count and knots[span] <= u:
                span += 1
            return span - 1

    def basis_funcs(self, span: int, u: float) -> list[float]:
        """
        Compute the non-zero basis functions for a given span and parameter u.

        Args:
            span (int): Knot span index.
            u (float): Curve parameter.
        Returns:
            list[float]: Non-zero basis function values.
        """
        order = self._order
        knots = self._knots
        N = [0.0] * order
        left = [0.0] * order
        right = [0.0] * order
        N[0] = 1.0
        for j in range(1, order):
            left[j] = u - knots[max(0, span + 1 - j)]
            right[j] = knots[span + j] - u
            saved = 0.0
            for r in range(j):
                # lower triangle
                ndu = right[r + 1] + left[j - r]
                temp = N[r] / ndu
                # upper triangle
                N[r] = saved + right[r + 1] * temp
                saved = left[j - r] * temp
            N[j] = saved
        if self.is_rational:
            return self.span_weighting(N, span)
        else:
            return N

    def span_weighting(self, nbasis: list[float], span: int) -> list[float]:
        """
        Apply rational weighting to basis functions for a given span.

        Args:
            nbasis (list[float]): Non-rational basis functions.
            span (int): Knot span index.
        Returns:
            list[float]: Weighted basis functions.
        """
        size = len(nbasis)
        weights = self._weights[span - self._order + 1 : span + 1]
        products = [nb * w for nb, w in zip(nbasis, weights)]
        s = sum(products)
        return [0.0] * size if s == 0.0 else [p / s for p in products]

    def basis_funcs_derivatives(self, span: int, u: float, n: int = 1) -> list[list[float]]:
        """
        Compute basis functions and derivatives up to order n for a given span and parameter u.

        Args:
            span (int): Knot span index.
            u (float): Curve parameter.
            n (int): Number of derivatives to compute (default: 1).
        Returns:
            list[list[float]]: ders[k][j] = k-th derivative of the j-th non-zero basis function.
        """
        order = self._order
        p = order - 1
        knots = self._knots
        ndu = [[0.0] * order for _ in range(order)]
        ndu[0][0] = 1.0
        left = [0.0] * order
        right = [0.0] * order
        for j in range(1, order):
            left[j] = u - knots[span + 1 - j]
            right[j] = knots[span + j] - u
            saved = 0.0
            for r in range(j):
                ndu[j][r] = right[r + 1] + left[j - r]
                temp = ndu[r][j - 1] / ndu[j][r]
                ndu[r][j] = saved + right[r + 1] * temp
                saved = left[j - r] * temp
            ndu[j][j] = saved
        ders = [[0.0] * order for _ in range(n + 1)]
        for j in range(order):
            ders[0][j] = ndu[j][p]
        a = [[0.0] * order for _ in range(2)]
        for r in range(order):
            s1 = 0
            s2 = 1
            a[0][0] = 1.0
            for k in range(1, n + 1):
                d = 0.0
                rk = r - k
                pk = p - k
                if r >= k:
                    a[s2][0] = a[s1][0] / ndu[pk + 1][rk]
                    d = a[s2][0] * ndu[rk][pk]
                if rk >= -1:
                    j1 = 1
                else:
                    j1 = -rk
                if (r - 1) <= pk:
                    j2 = k - 1
                else:
                    j2 = p - r
                for j in range(j1, j2 + 1):
                    a[s2][j] = (a[s1][j] - a[s1][j - 1]) / ndu[pk + 1][rk + j]
                    d += a[s2][j] * ndu[rk + j][pk]
                if r <= pk:
                    a[s2][k] = -a[s1][k - 1] / ndu[pk + 1][r]
                    d += a[s2][k] * ndu[r][pk]
                ders[k][r] = d
                s1, s2 = s2, s1
        r = float(p)
        for k in range(1, n + 1):
            for j in range(order):
                ders[k][j] *= r
            r *= p - k
        return ders[: n + 1]


class Evaluator:
    """
    B-spline curve point and curve derivative evaluator.

    Args:
        basis (Basis): Basis function object.
        control_points (Sequence[Vec3]): Sequence of control points (Vec3).
    """

    __slots__ = ["_basis", "_control_points"]

    def __init__(self, basis: Basis, control_points: Sequence[Vec3]) -> None:
        """
        Initialize the evaluator with a basis and control points.

        Args:
            basis (Basis): Basis function object.
            control_points (Sequence[Vec3]): Sequence of control points.
        """
        self._basis: Basis = basis
        self._control_points: Sequence[Vec3] = control_points

    def point(self, u: float) -> Vec3:
        """
        Evaluate the B-spline curve at parameter u.

        Args:
            u (float): Curve parameter.
        Returns:
            Vec3: Evaluated point on the curve.
        """
        basis = self._basis
        control_points = self._control_points
        if math.isclose(u, basis.max_t):
            u = basis.max_t
        p = basis.degree
        span = basis.find_span(u)
        N = basis.basis_funcs(span, u)
        try:
            return Vec3.sum(
                N[i] * control_points[span - p + i] for i in range(p + 1)
            )
        except IndexError as e:
            raise ValueError(
                f"Invalid control point index in evaluator: span={span}, p={p}, len(control_points)={len(control_points)}"
            ) from e

    def points(self, t: Iterable[float]) -> Iterable[Vec3]:
        """
        Yield evaluated points for an iterable of parameter values.

        Args:
            t (Iterable[float]): Iterable of parameter values.
        Yields:
            Vec3: Evaluated point on the curve.
        """
        for u in t:
            yield self.point(u)

    def derivative(self, u: float, n: int = 1) -> list[Vec3]:
        """
        Return point and derivatives up to n <= degree for parameter u.

        Args:
            u (float): Curve parameter.
            n (int): Number of derivatives to compute (default: 1).
        Returns:
            list[Vec3]: List of Vec3, where index k is the k-th derivative at u.
        """
        basis = self._basis
        control_points = self._control_points
        if math.isclose(u, basis.max_t):
            u = basis.max_t
        p = basis.degree
        span = basis.find_span(u)
        basis_funcs_ders = basis.basis_funcs_derivatives(span, u, n)
        if basis.is_rational:
            # Homogeneous point representation required:
            CKw: list[Vec3] = []
            wders: list[float] = []
            weights = basis.weights
            for k in range(n + 1):
                v = NULLVEC
                wder = 0.0
                for j in range(p + 1):
                    index = span - p + j
                    bas_func_weight = basis_funcs_ders[k][j] * weights[index]
                    v += control_points[index] * bas_func_weight
                    wder += bas_func_weight
                CKw.append(v)
                wders.append(wder)
            # Source: The NURBS Book: Algorithm A4.2
            CK: list[Vec3] = []
            for k in range(n + 1):
                v = CKw[k]
                for i in range(1, k + 1):
                    v -= binomial_coefficient(k, i) * wders[i] * CK[k - i]
                CK.append(v / wders[0])
        else:
            CK = [
                Vec3.sum(
                    basis_funcs_ders[k][j] * control_points[span - p + j]
                    for j in range(p + 1)
                )
                for k in range(n + 1)
            ]
        return CK

    def derivatives(self, t: Iterable[float], n: int = 1) -> Iterable[list[Vec3]]:
        """
        Yield derivatives up to order n for each parameter value in t.

        Args:
            t (Iterable[float]): Iterable of parameter values.
            n (int): Number of derivatives to compute (default: 1).
        Yields:
            list[Vec3]: List of Vec3, where index k is the k-th derivative at each u.
        """
        for u in t:
            yield self.derivative(u, n)
