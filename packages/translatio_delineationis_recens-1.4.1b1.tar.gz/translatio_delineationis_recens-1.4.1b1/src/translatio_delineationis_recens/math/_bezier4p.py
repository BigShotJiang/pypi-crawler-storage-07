# Copyright (c) 2010-2024 Manfred Moitzi
# License: MIT License
from __future__ import annotations
from typing import (
    TYPE_CHECKING,
    Iterable,
    Iterator,
    Sequence,
    TypeVar,
    Generic,
)
import math

# The pure Python implementation can't import from ._ctypes or ezdxf.math!
from ._vector import Vec3, Vec2
from ._matrix44 import Matrix44
from ._construct import arc_angle_span_deg

if TYPE_CHECKING:
    from ezdxf.math import UVec
    from ezdxf.math.ellipse import ConstructionEllipse

__all__ = [
    "Bezier4P",
    "cubic_bezier_arc_parameters",
    "cubic_bezier_from_arc",
    "cubic_bezier_from_ellipse",
]

T = TypeVar("T", Vec2, Vec3)


class Bezier4P(Generic[T]):
    """
    Implements an optimized cubic Bézier curve for exactly 4 control points.

    A Bézier curve is a parametric curve, parameter `t` goes from 0 to 1,
    where 0 is the first control point and 1 is the fourth control point.

    The class supports points of type :class:`Vec2` and :class:`Vec3` as input. Instances are immutable.

    Args:
        defpoints (Sequence[T]): Sequence of four definition points as Vec2 or Vec3 compatible objects.

    Raises:
        ValueError: If the number of control points is not exactly four.
        TypeError: If the control points are not Vec2 or Vec3.
    """

    __slots__ = ("_control_points", "_offset")

    def __init__(self, defpoints: Sequence[T]) -> None:
        if not isinstance(defpoints, Sequence):
            raise TypeError(f"defpoints must be a sequence, got {type(defpoints).__name__}.")
        if len(defpoints) != 4:
            raise ValueError(f"Four control points required, got {len(defpoints)}.")
        point_type = defpoints[0].__class__
        if point_type.__name__ not in ("Vec2", "Vec3"):
            raise TypeError(f"Invalid point type: {point_type.__name__}. Only Vec2 or Vec3 allowed.")
        offset: T = defpoints[0]
        self._offset: T = offset
        # Move the curve to the origin to reduce floating point errors:
        self._control_points: tuple[T, ...] = tuple(p - offset for p in defpoints)

    @property
    def control_points(self) -> tuple[T, T, T, T]:
        """
        Returns the control points as a tuple of Vec2 or Vec3 objects, restored to their original positions.

        Returns:
            tuple[T, T, T, T]: The four control points.
        """
        _, p1, p2, p3 = self._control_points
        offset = self._offset
        return (offset, p1 + offset, p2 + offset, p3 + offset)

    def tangent(self, t: float) -> T:
        """
        Returns the direction vector of the tangent at parameter t on the Bézier curve.

        Args:
            t (float): Curve position in the range [0, 1].

        Returns:
            T: Tangent direction vector at position t.

        Raises:
            ValueError: If t is not within [0, 1].
        """
        if not isinstance(t, (float, int)):
            raise TypeError(f"Parameter 't' must be a float or int, got {type(t).__name__}.")
        if not (0.0 <= t <= 1.0):
            raise ValueError(f"Parameter 't'={t} is not in range [0.0, 1.0].")
        return self._get_curve_tangent(t)

    def point(self, t: float) -> T:
        """
        Returns the point at parameter t on the Bézier curve.

        Args:
            t (float): Curve position in the range [0, 1].

        Returns:
            T: Point on the Bézier curve at position t.

        Raises:
            ValueError: If t is not within [0, 1].
        """
        if not isinstance(t, (float, int)):
            raise TypeError(f"Parameter 't' must be a float or int, got {type(t).__name__}.")
        if not (0.0 <= t <= 1.0):
            raise ValueError(f"Parameter 't'={t} is not in range [0.0, 1.0].")
        return self._get_curve_point(t)

    def approximate(self, segments: int) -> Iterator[T]:
        """
        Approximate the Bézier curve by vertices, yielding (segments + 1) points.

        Args:
            segments (int): Number of segments for approximation (must be >= 1).

        Yields:
            T: Points along the approximated Bézier curve.

        Raises:
            ValueError: If segments < 1.
        """
        if not isinstance(segments, int):
            raise TypeError(f"segments must be an int, got {type(segments).__name__}.")
        if segments < 1:
            raise ValueError(f"segments must be >= 1, got {segments}.")
        delta_t = 1.0 / segments
        cp = self.control_points
        yield cp[0]
        for segment in range(1, segments):
            yield self._get_curve_point(delta_t * segment)
        yield cp[3]

    def flattening(self, distance: float, segments: int = 4) -> Iterator[T]:
        """
        Adaptively flatten the Bézier curve into line segments using recursive subdivision.

        Args:
            distance (float): Maximum allowed distance from the midpoint of the cubic curve to the midpoint of the linear segment before subdivision occurs.
            segments (int): Minimum segment count (default: 4).

        Yields:
            T: Points along the flattened Bézier curve.

        Raises:
            ValueError: If distance is not positive or segments < 1.
        """
        if not isinstance(distance, (float, int)) or distance <= 0:
            raise ValueError(f"distance must be a positive float, got {distance}.")
        if not isinstance(segments, int) or segments < 1:
            raise ValueError(f"segments must be >= 1, got {segments}.")
        stack: list[tuple[float, T]] = []
        dt: float = 1.0 / segments
        t0: float = 0.0
        t1: float
        cp = self.control_points
        start_point: T = cp[0]
        end_point: T

        yield start_point
        while t0 < 1.0:
            t1 = t0 + dt
            if math.isclose(t1, 1.0):
                end_point = cp[3]
                t1 = 1.0
            else:
                end_point = self._get_curve_point(t1)

            while True:
                mid_t: float = (t0 + t1) * 0.5
                mid_point: T = self._get_curve_point(mid_t)
                chk_point: T = start_point.lerp(end_point)

                d = chk_point.distance(mid_point)
                if d < distance:
                    yield end_point
                    t0 = t1
                    start_point = end_point
                    if stack:
                        t1, end_point = stack.pop()
                    else:
                        break
                else:
                    stack.append((t1, end_point))
                    t1 = mid_t
                    end_point = mid_point

    def _get_curve_point(self, t: float) -> T:
        """
        Compute the Bézier curve point at parameter t (private method).

        Args:
            t (float): Curve position in the range [0, 1].

        Returns:
            T: Point on the Bézier curve at position t.
        """
        _, p1, p2, p3 = self._control_points
        _1_minus_t = 1.0 - t
        b = 3.0 * t * (_1_minus_t ** 2)
        c = 3.0 * (t ** 2) * _1_minus_t
        d = t ** 3
        # Offset is added last for numerical stability
        return p1 * b + p2 * c + p3 * d + self._offset

    def _get_curve_tangent(self, t: float) -> T:
        """
        Compute the tangent vector at parameter t (private method).

        Args:
            t (float): Curve position in the range [0, 1].

        Returns:
            T: Tangent vector at position t (not normalized).
        """
        _, p1, p2, p3 = self._control_points
        b = 6.0 * (1 - t) * t
        c = 3.0 * (t ** 2)
        return p1 * b + p2 * c + p3 * c

    def approximated_length(self, segments: int = 128) -> float:
        """
        Returns an estimated length of the Bézier curve by approximating it with line segments.

        Args:
            segments (int): Number of segments for approximation (default: 128).

        Returns:
            float: Estimated length of the Bézier curve.
        """
        length: float = 0.0
        prev_point: T | None = None
        for point in self.approximate(segments):
            if prev_point is not None:
                length += prev_point.distance(point)
            prev_point = point
        return length

    def reverse(self) -> 'Bezier4P[T]':
        """
        Returns a new Bézier curve with the control point order reversed.

        Returns:
            Bezier4P[T]: New Bézier curve with reversed control points.
        """
        return Bezier4P(list(reversed(self.control_points)))

    def transform(self, m: Matrix44) -> 'Bezier4P[Vec3]':
        """
        Apply a 4x4 transformation matrix to the Bézier curve, always returning a 3D curve.

        Args:
            m (Matrix44): 4x4 transformation matrix.

        Returns:
            Bezier4P[Vec3]: Transformed Bézier curve as a 3D curve.
        """
        defpoints = Vec3.generate(self.control_points)
        return Bezier4P(tuple(m.transform_vertices(defpoints)))


def cubic_bezier_from_arc(
    center: UVec = (0, 0, 0),
    radius: float = 1,
    start_angle: float = 0,
    end_angle: float = 360,
    segments: int = 1,
) -> Iterator[Bezier4P[Vec3]]:
    """Returns an approximation for a circular 2D arc by multiple cubic
    Bézier-curves.

    Args:
        center: circle center as :class:`Vec3` compatible object
        radius: circle radius
        start_angle: start angle in degrees
        end_angle: end angle in degrees
        segments: count of Bèzier-curve segments, at least one segment for each
            quarter (90 deg), 1 for as few as possible.

    """
    center_: Vec3 = Vec3(center)
    radius = float(radius)
    angle_span: float = arc_angle_span_deg(start_angle, end_angle)
    if abs(angle_span) < 1e-9:
        return

    s: float = start_angle
    start_angle = math.radians(s) % math.tau
    end_angle = math.radians(s + angle_span)
    while start_angle > end_angle:
        end_angle += math.tau

    for control_points in cubic_bezier_arc_parameters(start_angle, end_angle, segments):
        defpoints = [center_ + (p * radius) for p in control_points]
        yield Bezier4P(defpoints)


PI_2: float = math.pi / 2.0


def cubic_bezier_from_ellipse(
    ellipse: "ConstructionEllipse", segments: int = 1
) -> Iterator[Bezier4P[Vec3]]:
    """Returns an approximation for an elliptic arc by multiple cubic
    Bézier-curves.

    Args:
        ellipse: ellipse parameters as :class:`~ezdxf.math.ConstructionEllipse`
            object
        segments: count of Bèzier-curve segments, at least one segment for each
            quarter (π/2), 1 for as few as possible.

    """
    param_span: float = ellipse.param_span
    if abs(param_span) < 1e-9:
        return
    start_angle: float = ellipse.start_param % math.tau
    end_angle: float = start_angle + param_span
    while start_angle > end_angle:
        end_angle += math.tau

    def transform(points: Iterable[Vec3]) -> Iterator[Vec3]:
        center = Vec3(ellipse.center)
        x_axis: Vec3 = ellipse.major_axis
        y_axis: Vec3 = ellipse.minor_axis
        for p in points:
            yield center + x_axis * p.x + y_axis * p.y

    for defpoints in cubic_bezier_arc_parameters(start_angle, end_angle, segments):
        yield Bezier4P(tuple(transform(defpoints)))


# Circular arc to Bezier curve:
# Source: https://stackoverflow.com/questions/1734745/how-to-create-circle-with-b%C3%A9zier-curves
# Optimization: https://spencermortensen.com/articles/bezier-circle/
# actual c = 0.5522847498307935  = 4.0/3.0*(sqrt(2)-1.0) and max. deviation of ~0.03%
DEFAULT_TANGENT_FACTOR = 4.0 / 3.0  # 1.333333333333333333
# optimal c = 0.551915024494 and max. deviation of ~0.02%
OPTIMIZED_TANGENT_FACTOR = 1.3324407374108935
# Not sure if this is the correct way to apply this optimization,
# so i stick to the original version for now:
TANGENT_FACTOR = DEFAULT_TANGENT_FACTOR


def cubic_bezier_arc_parameters(
    start_angle: float, end_angle: float, segments: int = 1
) -> Iterator[tuple[Vec3, Vec3, Vec3, Vec3]]:
    """Yields cubic Bézier-curve parameters for a circular 2D arc with center
    at (0, 0) and a radius of 1 in the form of [start point, 1. control point,
    2. control point, end point].

    Args:
        start_angle: start angle in radians
        end_angle: end angle in radians (end_angle > start_angle!)
        segments: count of Bèzier-curve segments, at least one segment for each
            quarter (π/2)

    """
    if segments < 1:
        raise ValueError("Invalid argument segments (>= 1).")
    delta_angle: float = end_angle - start_angle
    if delta_angle > 0:
        arc_count = max(math.ceil(delta_angle / math.pi * 2.0), segments)
    else:
        raise ValueError("Delta angle from start- to end angle has to be > 0.")

    segment_angle: float = delta_angle / arc_count
    tangent_length: float = TANGENT_FACTOR * math.tan(segment_angle / 4.0)

    angle: float = start_angle
    end_point: Vec3 = Vec3.from_angle(angle)
    for _ in range(arc_count):
        start_point = end_point
        angle += segment_angle
        end_point = Vec3.from_angle(angle)
        control_point_1 = start_point + (
            -start_point.y * tangent_length,
            start_point.x * tangent_length,
        )
        control_point_2 = end_point + (
            end_point.y * tangent_length,
            -end_point.x * tangent_length,
        )
        yield start_point, control_point_1, control_point_2, end_point
