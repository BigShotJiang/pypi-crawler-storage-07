# Translatio Delineationis Recens (formerly EzDXF) Library

A Python library to create and modify DXF drawings, compatible with Python 3.7 and above.

## Overview

Translatio Delineationis Recens (formerly EzDXF) is an interface library for the DXF file format. The package is designed to facilitate the creation and manipulation of DXF documents, with compatibility across various DXF versions. It empowers users to seamlessly load and edit DXF files while preserving all content, except for comments.

Any unfamiliar DXF tags encountered in the document are gracefully ignored but retained for future modifications. This feature enables the processing of DXF documents containing data from third-party applications without any loss of valuable information.

## Installation

```bash
pip install translatio-delineationis-recens
```

Or install from source:

```bash
git clone https://github.com/yourusername/translatio-delineationis-recens.git
cd translatio-delineationis-recens
pip install -e .
```

## Basic Usage

```python
import translatio_delineationis_recens as tdr

# Create a new DXF document
doc = tdr.new('R2010')  # or R12, R2000, R2004, R2007, R2013, R2018

# Add new entities to modelspace
msp = doc.modelspace()
msp.add_line((0, 0), (10, 10))
msp.add_circle((0, 0), radius=5)

# Save the document
doc.saveas('example.dxf')

# Open an existing DXF document
doc = tdr.readfile('example.dxf')

# Iterate through all entities in modelspace
msp = doc.modelspace()
for entity in msp:
    if entity.dxftype() == 'LINE':
        print(f"Line from {entity.dxf.start} to {entity.dxf.end}")
    elif entity.dxftype() == 'CIRCLE':
        print(f"Circle at {entity.dxf.center} with radius {entity.dxf.radius}")
```

## Features

- Create new DXF documents
- Read and modify existing DXF files
- Support for various DXF versions (R12, R2000, R2004, R2007, R2010, R2013, R2018)
- Comprehensive entity support (lines, circles, arcs, text, dimensions, etc.)
- Block management
- Layer management
- Viewport configuration
- Extended entity data (XDATA)
- Object attribute access via Python properties

## Requirements

- Python 3.7 or higher

## License

MIT License

## Documentation

For more detailed documentation, see the [Docs](./Docs) directory.
