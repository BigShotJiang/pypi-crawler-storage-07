# -*- coding: utf-8 -*-

from .caster import ssm_quicksetup_caster

caster = ssm_quicksetup_caster

__version__ = "1.40.0"