"""Cross-platform Python scripts"""
