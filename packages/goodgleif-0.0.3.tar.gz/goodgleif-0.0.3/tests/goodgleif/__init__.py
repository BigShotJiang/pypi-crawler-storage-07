"""Tests for goodgleif package."""
