"""Test package for goodgleif."""
