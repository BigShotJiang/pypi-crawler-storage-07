"""Test rules resources."""
