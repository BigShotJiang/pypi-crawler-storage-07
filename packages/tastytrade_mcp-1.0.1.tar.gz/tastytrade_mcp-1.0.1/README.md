# TastyTrade MCP Server

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Security: Audited](https://img.shields.io/badge/security-audited-green.svg)](docs/SECURITY.md)

A **Model Context Protocol (MCP) server** that connects your **TastyTrade trading account** to AI assistants like Claude Desktop and ChatGPT for conversational trading and portfolio management.

## 🌟 Features

### **Multi-LLM Support**
- 🤖 **Claude Desktop** - Native MCP integration via stdio
- 💬 **ChatGPT** - HTTP MCP Bridge for Developer Mode
- 🔄 **Universal Deployment** - Works on any cloud platform

### **Trading Capabilities**
- 📊 **Real-time Market Data** - Live quotes, options chains, market search
- 💼 **Portfolio Management** - Account positions, balances, order history
- 🔍 **Symbol Search** - Find stocks, options, and other instruments
- 🔒 **Security First** - Two-step trading confirmation, audit logging

### **API Limitations**
> ⚠️ **Important**: The TastyTrade API has certain limitations. The following features are NOT available:
> - **Options Greeks** - Delta, Gamma, Theta, etc. are not provided by the API
> - **Historical Price Data** - No historical bars/candles endpoint available
> - **These tools have been removed** to avoid misleading functionality

### **Enterprise-Grade Security**
- 🔐 **Secure Authentication** - Your credentials never exposed to AI
- 📝 **Comprehensive Audit Trail** - All operations logged for compliance
- 🚫 **LLM Safety** - Trading requires explicit user confirmation

## 🚀 One-Line Installation

### **Prerequisites**
- TastyTrade trading account
- Python 3.8+ and pip

### **Install & Deploy**

```bash
# Install the CLI tool
pipx install tastytrade-mcp

# Deploy locally for Claude Desktop
tastytrade-mcp local

# OR deploy to cloud for ChatGPT
tastytrade-mcp cloud
```

## ⚙️ Configuration

### **Set Your Credentials**

Create a `.env` file with your **actual TastyTrade credentials**:

```bash
# Required: Your TastyTrade account credentials
TASTYTRADE_USERNAME=your_email@tastytrade.com
TASTYTRADE_PASSWORD=your_password
TASTYTRADE_USE_PRODUCTION=true

# Optional: For cloud deployment (ChatGPT)
CHATGPT_MCP_TOKEN=your-secure-token
```

⚠️ **Important**: Use your **real TastyTrade account** credentials. This is not a demo - it connects to your actual trading account.

### **Security Notes**
- Credentials are stored in `.env` file (never committed to git)
- No credentials are included in config files or shared with AI
- All trading operations require explicit user confirmation

## 📱 Usage

### **For Claude Desktop**
```bash
tastytrade-mcp local
```
Then restart Claude Desktop and ask: *"Show my TastyTrade positions"*

### **For ChatGPT**
```bash
tastytrade-mcp cloud
```
Configure the returned URL in ChatGPT Developer Mode, then ask: *"What's my portfolio balance?"*

## 🌐 Cloud Deployment Options

The server runs as a standard Python web application and can be deployed to any cloud platform:

### **Railway** (Recommended)
```bash
tastytrade-mcp cloud  # Auto-configures Railway
```

### **Heroku**
```bash
# Add to Procfile:
web: python tastytrade_unified_server.py

# Set environment variables in Heroku dashboard
heroku config:set TASTYTRADE_USERNAME=your_email@tastytrade.com
heroku config:set TASTYTRADE_PASSWORD=your_password
heroku config:set TASTYTRADE_USE_PRODUCTION=true
```

### **Google Cloud Run**
```bash
# Deploy with environment variables
gcloud run deploy tastytrade-mcp \
  --source . \
  --set-env-vars TASTYTRADE_USERNAME=your_email@tastytrade.com \
  --set-env-vars TASTYTRADE_PASSWORD=your_password \
  --set-env-vars TASTYTRADE_USE_PRODUCTION=true
```

### **AWS Lambda**
```bash
# Use serverless framework or SAM
# Environment variables configured in AWS Console
```

### **Any Docker Platform**
```bash
docker build -t tastytrade-mcp .
docker run -e TASTYTRADE_USERNAME=your_email@tastytrade.com \
           -e TASTYTRADE_PASSWORD=your_password \
           -e TASTYTRADE_USE_PRODUCTION=true \
           tastytrade-mcp
```

## 🛠️ Available Tools

### **Account Management**
- `accounts` - List all TastyTrade accounts
- `balances` - Get account balance information
- `positions` - View current positions

### **Market Data**
- `search_symbols` - Search stocks, ETFs, and other instruments
- `quote` - Get real-time market quotes
- `search_options` - Find options chains with filtering

### **Security & Audit**
- `audit_log` - View trading activity audit trail
- `security_status` - Check authentication and encryption status

## 📊 Management Commands

```bash
# Check deployment status
tastytrade-mcp status

# Remove all deployments
tastytrade-mcp cleanup

# Check dependencies
tastytrade-mcp setup --check-only
```

## 🔧 Manual Installation (Advanced)

If you prefer manual setup:

```bash
git clone <repository-url>
cd Tasty_MCP
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# Create .env file with your credentials
echo "TASTYTRADE_USERNAME=your_email@tastytrade.com" > .env
echo "TASTYTRADE_PASSWORD=your_password" >> .env
echo "TASTYTRADE_USE_PRODUCTION=true" >> .env

# Start server
python tastytrade_unified_server.py
```

## 🔒 Security Best Practices

1. **Never commit credentials** - Always use `.env` files
2. **Use production accounts** - Connect to your real TastyTrade account
3. **Monitor audit logs** - Review all trading activity
4. **Secure your deployment** - Use HTTPS and authentication tokens
5. **Regular updates** - Keep the server updated for security patches

## ⚠️ Important Disclaimers

- **Real Trading**: This connects to your actual TastyTrade account with real money
- **User Responsibility**: All trades require your explicit confirmation
- **No Financial Advice**: This is a technical tool, not investment advice
- **Security**: Keep your credentials secure and use HTTPS in production

## 📚 Usage Examples

### **Getting Portfolio Information**

```
"Show me my current positions and account balances"
"What are my open orders?"
"Get real-time quotes for NVDA, TSLA, and AAPL"
```

### **Real-Time Market Data**

```
"Get live quotes for my stock holdings"
"Stream real-time data for AAPL for 30 seconds"
"Show me the current market price of Bitcoin futures"
```

### **Options Trading Workflow**

```
# Step 1: Get your current option positions
"Show me all my current option positions"

# Step 2: Get real-time pricing (use exact symbols from positions)
"Get real-time quotes for these symbols: AMD  251121P00165000, NVDA  251121C00240000"

# Step 3: Analyze options strategies
"Analyze my AMD put spread strategy with current market conditions"
```

### **Market Research**

```
"Search for symbols related to artificial intelligence"
"Get the option chain for TSLA expiring in 30 days"
"Find options with delta around 0.30 for SPY"
```

### **Order Management**

```
"Create a buy order for 100 shares of AAPL at market price"
"Set up a stop-loss order for my NVDA position at $200"
"Show me the status of my pending orders"
```

### **Risk Management**

```
"Calculate the total value of my portfolio"
"Show me my unrealized P&L by position"
"What's my current buying power?"
```

## 🔧 Troubleshooting

### **Option Pricing Issues**

If option prices aren't showing:

1. **Get exact symbols first**: Use `get_positions` to see your actual option symbols
2. **Use correct format**: Option symbols look like `AAPL  251121C00150000` (not "AAPL $150 Call")
3. **Try direct quotes**: Use `get_realtime_quotes` with the exact symbols from your positions

### **Authentication Prompts**

If you keep getting "Allow" prompts:
- This is normal security behavior
- Select "Always Allow" to reduce frequency
- Each tool request requires permission for security

### **WebSocket Connection Issues**

If real-time quotes aren't working:
- Check that markets are open
- Verify your internet connection
- Try reducing the duration parameter

## 📞 Support

- **Documentation**: Check the comprehensive guides in `docs/`
- **Issues**: Open GitHub issues for bugs or feature requests
- **Security**: See [SECURITY.md](docs/SECURITY.md) for security policies

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

**🚨 Trading Disclaimer**: This software connects to real trading accounts with actual money. All trading involves financial risk. Users are responsible for their trading decisions and should understand the risks before using this tool.