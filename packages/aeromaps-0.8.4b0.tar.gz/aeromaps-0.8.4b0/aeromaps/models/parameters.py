from json import dump
import pandas as pd

from aeromaps.utils.functions import _dict_from_json, _dict_from_parameters_dict


class Parameters:
    def to_dict(self):
        return self.__dict__

    def from_dict(self, data):
        for key, value in data.items():
            setattr(self, key, value)

    def write_json(self, file_name="parameters.json"):
        with open(file_name, "w", encoding="utf-8") as f:
            dump(self.to_dict(), f, ignore_nan=True, ensure_ascii=False, indent=4)

    def read_json(self, file_name="parameters.json"):
        data = _dict_from_json(file_name=file_name)

        # Old reference data is kept
        self.from_dict(data)

    def read_json_direct(self, parameters_dict):
        data = _dict_from_parameters_dict(parameters_dict)

        # Old reference data is kept
        self.from_dict(data)
