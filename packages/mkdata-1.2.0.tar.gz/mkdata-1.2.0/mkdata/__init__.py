"""mkdata package metadata."""

__all__ = ["__version__", "__authors__"]

__version__ = "1.2.0"
__authors__ = ["RayZh-hs", "rogerflowey"]
