# MkData

Simple but powerful batch data generator based on Python.

---

MkData is a command-line tool that reads a custom type of script named MkData Generator Script (conventionally *.gen) and generates batch data accordingly. It is designed to be simple and fast, with a focus on flexibility and extensibility. For more information and usage guide, please refer to the [README](https://github.com/RayZh-hs/mkdata) on Github.