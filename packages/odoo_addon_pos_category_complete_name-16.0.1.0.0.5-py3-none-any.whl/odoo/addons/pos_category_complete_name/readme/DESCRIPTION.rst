This module extends the functionnality of the Odoo Point of Sale.
It adds a "Complete Name" field on the ``pos.category`` model.

It makes easier the search of categories in Odoo.

