# -*- coding: utf-8 -*-

from .caster import codeguruprofiler_caster

caster = codeguruprofiler_caster

__version__ = "1.40.0"