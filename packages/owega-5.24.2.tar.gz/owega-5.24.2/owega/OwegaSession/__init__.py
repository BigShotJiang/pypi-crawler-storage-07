"""Session init."""
from .promptsession import ps as OwegaSession
from .promptsession import set_ps

__all__ = ['OwegaSession', 'set_ps']
