"""Run the CLI/TUI handler."""
from .owega import main

if __name__ == "__main__":
    main()
