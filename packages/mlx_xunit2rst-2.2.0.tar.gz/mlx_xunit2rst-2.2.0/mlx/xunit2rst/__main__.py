""" Entry point of swcc.xunit2rst package """
from .xunit2rst import main

if __name__ == '__main__':
    main()
