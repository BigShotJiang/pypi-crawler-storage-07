# -*- coding: utf-8 -*-

from .caster import outposts_caster

caster = outposts_caster

__version__ = "1.40.0"