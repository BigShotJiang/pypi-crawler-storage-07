# -*- coding: utf-8 -*-

from .caster import service_quotas_caster

caster = service_quotas_caster

__version__ = "1.40.0"