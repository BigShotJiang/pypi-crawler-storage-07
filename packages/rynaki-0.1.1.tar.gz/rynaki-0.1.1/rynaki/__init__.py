from .main import Akinator, AkinatorError
__version__ = '0.1.0'
