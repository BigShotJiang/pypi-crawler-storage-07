from . import (
    test_auto_assign_storage_type,
    test_package_height_required,
    test_package_type_message,
    test_stock_location,
    test_storage_type,
    test_storage_type_move,
    test_storage_type_putaway_strategy,
    test_storage_category_allow_new_product,
)
