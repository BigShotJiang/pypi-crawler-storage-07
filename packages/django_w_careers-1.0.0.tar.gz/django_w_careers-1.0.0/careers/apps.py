"""AppConf for careers"""

from django.apps import AppConfig


class TheCertainNewsConfig(AppConfig):
    """App configuration for careers"""

    name = "careers"
    default_auto_field = "django.db.models.BigAutoField"
