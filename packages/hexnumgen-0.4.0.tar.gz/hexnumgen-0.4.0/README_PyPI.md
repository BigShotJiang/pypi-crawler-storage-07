# hexnumgen

Number literal generator for the Hex Casting mod for Minecraft.
