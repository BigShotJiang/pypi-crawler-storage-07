# CS3APIs Bindings for Python

[![Join the conversation](https://badges.gitter.im/cs3org/CS3APIS.svg)](https://gitter.im/cs3org/CS3APIS) [![Latest Version](https://img.shields.io/pypi/v/cs3apis)](https://pypi.org/project/cs3apis/) [![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0) 

API definitions can be found at https://github.com/cs3org/cs3apis

## Install with pip

```bash
pip install cs3apis
```
