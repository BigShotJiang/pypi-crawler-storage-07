class eheh:
    def hehe(self, name):
        if "eyansh" in name.lower(): # Friend's name is Reyansh but the dickhead might as well capitalize or not capitalize the "r" so just to make it easier.
            print(f"Congratulations {name}! You are a DICKHEAD!")
        else:
            print("Put ya real name in bruh")