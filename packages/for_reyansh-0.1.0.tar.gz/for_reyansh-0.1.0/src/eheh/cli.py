from .eheh import Eheh

def main():
    name = input("Enter ya name: ")
    Eheh().hehe(name)
