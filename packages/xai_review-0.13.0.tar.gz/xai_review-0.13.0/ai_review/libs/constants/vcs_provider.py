from enum import StrEnum


class VCSProvider(StrEnum):
    GITHUB = "GITHUB"
    GITLAB = "GITLAB"
