# -*- coding: utf-8 -*-

from .caster import pricing_caster

caster = pricing_caster

__version__ = "1.40.0"