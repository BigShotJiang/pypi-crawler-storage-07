"""
.. include:: ./README.md
   :start-line: 2
"""

from airbyte_cdk.cli.source_declarative_manifest._run import run

__all__ = [
    "run",
]
