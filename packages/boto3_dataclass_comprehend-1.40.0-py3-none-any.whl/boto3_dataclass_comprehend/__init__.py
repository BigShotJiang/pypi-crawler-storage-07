# -*- coding: utf-8 -*-

from .caster import comprehend_caster

caster = comprehend_caster

__version__ = "1.40.0"