# optycode SDK

A lightweight optycode SDK to interact with the optycode API.

## Installation

```bash
pip install optycode-sdk
