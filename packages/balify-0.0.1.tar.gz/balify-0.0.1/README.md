<p align="center">
  <img src="https://raw.githubusercontent.com/bali-framework/bali/master/docs/img/bali.png" alt='bali framework' />
</p>
<p align="center">
    <b>balify</b><br />
    <em>🏝 Minimalist declarative API.</em>    
</p>

<p align="center">
    <a href="https://pepy.tech/project/bali-va">
        <img src="https://pepy.tech/badge/bali-va" alt="" />
    </a>
    <a href="https://pypi.org/project/bali-va/">
        <img src="https://img.shields.io/pypi/v/bali-va" alt="" />
    </a>
    <a href="https://github.com/bali-framework/bali-va/actions/workflows/python-ci.yml">
      <img src="https://github.com/bali-framework/bali-va/actions/workflows/python-ci.yml/badge.svg" alt="" />
    </a>
</p>

---

> The framework's conventions are opinionated and follow industry-leading practices.
> 
