# -*- coding: utf-8 -*-

from .caster import personalize_events_caster

caster = personalize_events_caster

__version__ = "1.40.0"