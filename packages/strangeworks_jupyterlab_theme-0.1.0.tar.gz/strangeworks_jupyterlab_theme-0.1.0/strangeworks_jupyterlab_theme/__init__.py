"""Strangeworks JupyterLab Theme"""

__version__ = "0.1.0"