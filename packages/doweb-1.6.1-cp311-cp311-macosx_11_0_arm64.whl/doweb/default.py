"""Default doweb application configuration."""

from doweb.browser import get_app

app = get_app()
