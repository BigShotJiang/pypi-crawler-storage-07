"""Image static files for doweb."""
