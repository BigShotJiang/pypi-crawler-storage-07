"""Interface Python para MTLearn."""

from importlib import import_module

_bindings = import_module("._mtlearn", package=__name__)

TreeStats = _bindings.TreeStats
make_tree_stats = _bindings.make_tree_stats
make_tree_tensor = _bindings.make_tree_tensor

__all__ = [
    "TreeStats",
    "make_tree_stats",
    "make_tree_tensor",
]

__version__ = "0.1.0"
