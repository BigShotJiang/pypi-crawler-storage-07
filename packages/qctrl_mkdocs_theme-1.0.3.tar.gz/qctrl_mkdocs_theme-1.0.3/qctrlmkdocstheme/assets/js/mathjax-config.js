MathJax = {
  tex: {
    inlineMath: {
      '[+]': [['$', '$']]
    }
  }
};
