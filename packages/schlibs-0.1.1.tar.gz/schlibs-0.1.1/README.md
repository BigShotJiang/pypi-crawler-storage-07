# schlibs - Shared Libraries

A BDD-driven library providing utilities for JSON-Path/JSON-Pointer conversion and pointer caching.

## Features

### json_pathlib

Bidirectional conversion between JSON-Path and JSON-Pointer formats:

- **JSON-Pointer → JSON-Path**: Straightforward conversion
- **JSON-Path → JSON-Pointer**: Resolves expressions against actual documents
- Supports wildcards and filter expressions that may produce multiple results

```python
from json_pathlib import pointer_to_path, path_to_pointer, path_to_pointers

# Simple conversion
path = pointer_to_path("/store/book/0/title")
# Result: "$.store.book[0].title"

# Resolve JSON-Path against a document
doc = {"store": {"book": [{"title": "Book 1"}, {"title": "Book 2"}]}}
pointer = path_to_pointer("$.store.book[0].title", doc)
# Result: "/store/book/0/title"

# Multiple results with wildcards
pointers = path_to_pointers("$.store.book[*].title", doc)
# Result: ["/store/book/0/title", "/store/book/1/title"]
```

### pointercache

Caching system with configurable eviction policies (coming soon).

## Installation

```bash
pip install schlibs
```

## Development

This is a dual-language library project (Python + TypeScript) using behavior-driven development:

```bash
cd python/

# Install dev dependencies
pip install -e ".[dev]"

# Run BDD tests
behave

# Run unit tests
pytest
```

## License

MIT License - see [LICENSE](../LICENSE)
