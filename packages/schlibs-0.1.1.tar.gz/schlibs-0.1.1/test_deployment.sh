#!/usr/bin/env bash
set -euo pipefail

# Test deployment by installing the built package in an isolated environment
# and running smoke tests to verify all functionality works

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TEST_VENV="$SCRIPT_DIR/test_venv"

echo "=== Deployment Smoke Test ==="

# Check if dist directory exists
if [ ! -d "$SCRIPT_DIR/dist" ]; then
    echo "Error: dist/ directory not found. Run 'python -m build' first."
    exit 1
fi

# Check if wheel exists
WHEEL=$(ls "$SCRIPT_DIR"/dist/*.whl 2>/dev/null | head -n1)
if [ -z "$WHEEL" ]; then
    echo "Error: No wheel found in dist/. Run 'python -m build' first."
    exit 1
fi

echo "Testing wheel: $(basename "$WHEEL")"

# Clean up old test venv if it exists
if [ -d "$TEST_VENV" ]; then
    echo "Cleaning up old test environment..."
    rm -rf "$TEST_VENV"
fi

# Create isolated venv
echo "Creating isolated test environment..."
python -m venv "$TEST_VENV"

# Activate venv
source "$TEST_VENV/bin/activate"

# Install the wheel
echo "Installing package..."
pip install --quiet "$WHEEL"

# Run smoke tests
echo "Running smoke tests..."
python -c "
from json_pathlib import (
    JsonPath,
    JsonPointer,
    PathResolutionError,
    PathNotFoundError,
    AmbiguousPathError,
    __version__
)

print('Testing JsonPointer.to_path...')
pointer = JsonPointer('/store/book/0')
assert pointer.to_path() == '\$.store.book[0]', 'JsonPointer.to_path failed'

print('Testing JsonPath.match...')
doc = {'store': {'book': [{'title': 'Book 1'}]}}
pointers = JsonPath('\$.store.book[0].title').match(doc)
assert len(pointers) == 1, 'JsonPath.match returned wrong number of results'
assert str(pointers[0]) == '/store/book/0/title', 'JsonPath.match failed'

print('Testing JsonPath.match with wildcards...')
pointers = JsonPath('\$.store.book[*].title').match(doc)
assert len(pointers) == 1, 'JsonPath.match wildcard returned wrong number of results'
assert str(pointers[0]) == '/store/book/0/title', 'JsonPath.match wildcard failed'

print('Verifying version...')
assert __version__ != '0.0.0+unknown', f'Version not set correctly: {__version__}'

print(f'✓ All smoke tests passed (version: {__version__})')
"

# Deactivate and clean up
deactivate
rm -rf "$TEST_VENV"

echo "=== Deployment test completed successfully ==="
