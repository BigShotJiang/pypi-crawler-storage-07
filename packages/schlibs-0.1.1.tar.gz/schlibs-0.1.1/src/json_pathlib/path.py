"""
JsonPath - JSON Path expression implementation.

JSON-Paths can be queries (with filters, wildcards) that need to be matched
against a document to produce concrete JSON-Pointers.
"""
import logging
from typing import List, Any, Optional, Dict
from jsonpath_ng.ext import parse as jsonpath_parse
from jsonpath_ng.exceptions import JsonPathParserError

from .pointer import JsonPointer

logger = logging.getLogger(__name__)


class JsonPath:
    """
    Represents a JSON-Path expression.

    JSON-Paths can be queries (with filters, wildcards) that need to be matched
    against a document to produce concrete JSON-Pointers.

    The parsed expression is cached for reuse across multiple documents.

    Example:
        path = JsonPath("$.store.book[*].title")
        pointers1 = path.match(doc1)  # List[JsonPointer]
        pointers2 = path.match(doc2)  # List[JsonPointer]
    """

    # Class-level cache for parsed expressions
    _parse_cache: Dict[str, Any] = {}

    def __init__(self, path: str):
        """
        Create a JsonPath instance.

        Args:
            path: JSON-Path string (e.g., "$.store.book[0].title")
        """
        self._path = path
        self._parsed: Optional[Any] = None
        logger.debug(f"Created JsonPath: {path}")

    @property
    def parsed(self):
        """
        Get the parsed JSON-Path expression (with caching).

        The expression is parsed once and cached for reuse.
        """
        if self._parsed is None:
            if self._path in self._parse_cache:
                self._parsed = self._parse_cache[self._path]
                logger.debug(f"Retrieved cached parse for: {self._path}")
            else:
                try:
                    self._parsed = jsonpath_parse(self._path)
                    self._parse_cache[self._path] = self._parsed
                    logger.debug(f"Parsed and cached: {self._path}")
                except JsonPathParserError as e:
                    logger.error(f"Failed to parse JSON-Path: {e}")
                    raise ValueError(f"Invalid JSON-Path: {self._path}") from e
        return self._parsed

    def match(self, document: Any) -> List[JsonPointer]:
        """
        Match this JSON-Path against a document and return matching pointers.

        Args:
            document: Document to match the path against

        Returns:
            List of JsonPointer objects (may be empty)

        Raises:
            ValueError: If the JSON-Path syntax is invalid
        """
        logger.debug(f"Matching JSON-Path against document: {self._path}")

        # Handle root case
        if self._path == "$":
            return [JsonPointer("")]

        # Parse and match
        matches = self.parsed.find(document)

        # Convert matches to JsonPointer objects
        pointers = [JsonPointer(self._match_to_pointer(match)) for match in matches]
        logger.debug(f"Found {len(pointers)} matching pointers")
        return pointers

    @staticmethod
    def _match_to_pointer(match) -> str:
        """
        Convert a jsonpath_ng match object to a JSON-Pointer string.

        Args:
            match: A jsonpath_ng Match object

        Returns:
            JSON-Pointer string
        """
        # Build the path from the match
        path_parts = []
        current = match

        while current.context is not None:
            if hasattr(current.path, 'index'):
                # Array index
                path_parts.insert(0, str(current.path.index))
            elif hasattr(current.path, 'fields') and current.path.fields:
                # Object field
                path_parts.insert(0, current.path.fields[0])
            elif hasattr(current.path, 'field'):
                # Single field
                path_parts.insert(0, current.path.field)

            current = current.context

        # Escape for JSON-Pointer
        escaped_parts = []
        for part in path_parts:
            # Escape ~ and /
            part = str(part).replace("~", "~0").replace("/", "~1")
            escaped_parts.append(part)

        result = "/" + "/".join(escaped_parts) if escaped_parts else ""
        return result

    def __str__(self) -> str:
        return self._path

    def __repr__(self) -> str:
        return f"JsonPath({self._path!r})"

    def __eq__(self, other) -> bool:
        if isinstance(other, JsonPath):
            return self._path == other._path
        return self._path == other
