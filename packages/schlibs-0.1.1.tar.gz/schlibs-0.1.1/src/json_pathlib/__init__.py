"""
pathlib - JSON-Path and JSON-Pointer conversion library

This library provides bidirectional conversion between JSON-Path and JSON-Pointer formats
using a fluent, object-oriented API.

Example:
    # JSON-Pointer to JSON-Path (no document required)
    from json_pathlib import JsonPointer
    path = JsonPointer("/store/book/0/title").to_path()

    # JSON-Path to JSON-Pointer (requires document)
    from json_pathlib import JsonPath
    pointers = JsonPath("$.store.book[*].title").match(doc)  # List[JsonPointer]
"""

from .exceptions import (
    PathResolutionError,
    PathNotFoundError,
    AmbiguousPathError,
)
from .path import JsonPath
from .pointer import JsonPointer

try:
    from importlib.metadata import version as _get_version
    __version__ = _get_version("schlibs")
except Exception:
    __version__ = "0.0.0+unknown"

__all__ = [
    'JsonPath',
    'JsonPointer',
    'PathResolutionError',
    'PathNotFoundError',
    'AmbiguousPathError',
    '__version__',
]