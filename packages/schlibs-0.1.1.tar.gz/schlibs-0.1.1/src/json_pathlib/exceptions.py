"""
Exceptions for JSON-Path and JSON-Pointer operations.
"""


class PathResolutionError(LookupError):
    """Base exception for path resolution errors."""
    pass


class PathNotFoundError(PathResolutionError):
    """Raised when a JSON-Path resolves to zero results."""
    pass


class AmbiguousPathError(PathResolutionError):
    """Raised when a JSON-Path resolves to multiple results."""
    pass
