"""
JsonPointer - RFC 6901 JSON Pointer implementation.

JSON-Pointers are concrete paths that always point to exactly one location.
They can be converted to JSON-Path syntax without requiring a document.
"""
import logging
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from .path import JsonPath

from .exceptions import PathNotFoundError, AmbiguousPathError

logger = logging.getLogger(__name__)


class JsonPointer:
    """
    Represents a JSON-Pointer (RFC 6901).

    JSON-Pointers are concrete paths that always point to exactly one location.
    They can be converted to JSON-Path syntax without requiring a document.

    Example:
        pointer = JsonPointer("/store/book/0/title")
        path = pointer.to_path()  # Returns "$.store.book[0].title"
    """

    def __init__(self, pointer: str):
        """
        Create a JsonPointer instance.

        Args:
            pointer: JSON-Pointer string (e.g., "/store/book/0/title")
        """
        self._pointer = pointer
        logger.debug(f"Created JsonPointer: {pointer}")

    def to_path(self) -> str:
        """
        Convert this JSON-Pointer to a JSON-Path.

        This is a straightforward conversion:
        - Empty string or "/" -> "$"
        - "/foo/bar" -> "$.foo.bar"
        - "/foo/0/bar" -> "$.foo[0].bar"

        Returns:
            JSON-Path string (e.g., "$.store.book[0].title")
        """
        logger.debug(f"Converting JSON-Pointer to JSON-Path: {self._pointer}")

        # Handle root cases
        if self._pointer == "" or self._pointer == "/":
            return "$"

        # Remove leading slash
        pointer = self._pointer
        if pointer.startswith("/"):
            pointer = pointer[1:]

        # Split by '/' and convert to JSON-Path
        parts = pointer.split("/")
        path_parts = ["$"]

        for part in parts:
            # Unescape JSON-Pointer encoding
            part = part.replace("~1", "/").replace("~0", "~")

            # Check if part is a numeric index
            if part.isdigit():
                # Array index - add as [n]
                path_parts.append(f"[{part}]")
            elif part == "":
                # Empty key - needs bracket notation
                path_parts.append('[""]')
            else:
                # Object property - add with dot notation
                path_parts.append(f".{part}")

        result = "".join(path_parts)
        logger.debug(f"Converted to JSON-Path: {result}")
        return result

    @classmethod
    def from_path(cls, path: str, document: Any) -> "JsonPointer":
        """
        Create a JsonPointer by resolving a JSON-Path against a document.

        Convenience method for single-result paths.

        Args:
            path: JSON-Path string (e.g., "$.store.book[0].title")
            document: Document to resolve the path against

        Returns:
            JsonPointer instance

        Raises:
            PathNotFoundError: If the path resolves to zero results
            AmbiguousPathError: If the path resolves to multiple results
        """
        from .path import JsonPath  # Import here to avoid circular dependency

        pointers = JsonPath(path).match(document)
        if len(pointers) == 0:
            raise PathNotFoundError(f"Path resolution returned no results: {path}")
        elif len(pointers) > 1:
            raise AmbiguousPathError(f"Ambiguous path resolution: {path} resolved to {len(pointers)} results")
        return pointers[0]

    def __str__(self) -> str:
        return self._pointer

    def __repr__(self) -> str:
        return f"JsonPointer({self._pointer!r})"

    def __eq__(self, other) -> bool:
        if isinstance(other, JsonPointer):
            return self._pointer == other._pointer
        return self._pointer == other
