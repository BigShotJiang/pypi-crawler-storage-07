"""Behave environment configuration for BDD tests."""
import logging


def before_all(context):
    """Set up logging before all tests."""
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
