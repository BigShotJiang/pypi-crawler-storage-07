Feature: As a developer I want to convert between JSON-Paths and JSON-Pointers

  Scenario Outline: Convert JSON-Pointer to JSON-Path
    Given the JSON-Pointer "<jsonpointer>"
    When I convert it to a JSON-Path
    Then the result should be "<expectedPath>"

    Examples:
      | jsonpointer         | expectedPath          |
      | /store/book/0/title | $.store.book[0].title |
      | /store/book/1/title | $.store.book[1].title |
      |                     | $                     |
      | /                   | $                     |

  Scenario Outline: Convert JSON-Path with distinct result to JSON-Pointer
    Given I load the referred document from "<fixturePath>"
    And the JSON-Path "<jsonpath>"
    When I convert it to a JSON-Pointer
    Then the result should be "<expectedPointer>"

    Examples:
      | fixturePath             | jsonpath                            | expectedPointer     |
      | fixtures/store.yaml     | $.store.book[0].title               | /store/book/0/title |
      | fixtures/store.yaml     | $.store.book[?(@.price > 10)].title | /store/book/1/title |
      | fixtures/store.yaml     | $                                   |                     |
      | fixtures/empty_key.yaml | $[""]                               | /                   |

  Scenario Outline: Convert JSON-Path with empty result to JSON-Pointer
    Given I load the referred document from "<fixturePath>"
    And the JSON-Path "<jsonpath>"
    When I convert it to a JSON-Pointer
    Then it should raise "<expectedException>"

    Examples:
      | fixturePath         | jsonpath          | expectedException  |
      | fixtures/store.yaml | $.path_to_nowhere | PathNotFoundError  |

  Scenario Outline: Convert JSON-Path with multiple results to JSON-Pointer
    Given I load the referred document from "<fixturePath>"
    And the JSON-Path "<jsonpath>"
    When I convert it to a JSON-Pointer
    Then it should raise "<expectedException>"

    Examples:
      | fixturePath         | jsonpath              | expectedException  |
      | fixtures/store.yaml | $.store.book[*].title | AmbiguousPathError |

  Scenario Outline: Convert JSON-Path with multiple results to JSON-Pointer List
    Given I load the referred document from "<fixturePath>"
    And the JSON-Path "<jsonpath>"
    When I convert it to a JSON-Pointer List
    Then the result should be "<expectedList>"

    Examples:
      | fixturePath         | jsonpath              | expectedList                             |
      | fixtures/store.yaml | $.store.book[*].title | /store/book/0/title, /store/book/1/title |
      | fixtures/store.yaml | $.store.*[*].title    | /store/book/0/title, /store/book/1/title |
      | fixtures/store.yaml | $..price              | /store/book/0/price, /store/book/1/price |