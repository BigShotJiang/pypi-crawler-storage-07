# qioptiq-iris

## Installation

```console
pip install qioptiq-iris
```

## License

`qioptiq-iris` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
