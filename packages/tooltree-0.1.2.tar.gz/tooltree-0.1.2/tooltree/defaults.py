from __future__ import annotations


default_colors = [
    'limegreen',
    'dodgerblue',
    'orange',
    'paleturquoise',
    '#AF6E4D',
    'mediumslateblue',
    'gold',
    'teal',
    'grey',
    '#E86100',
    '#F2C1D1',
]

default_png_width = 1600
default_png_height = 1200
default_png_scale = 4
