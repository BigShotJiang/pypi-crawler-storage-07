"""
pathlib - JSON-Path and JSON-Pointer conversion library

This library provides bidirectional conversion between JSON-Path and JSON-Pointer formats.
"""

from .conversion import (
    pointer_to_path,
    path_to_pointer,
    path_to_pointers,
    PathResolutionError,
    PathNotFoundError,
    AmbiguousPathError,
)

try:
    from ._version import version as __version__
except ImportError:
    __version__ = "0.0.0+unknown"

__all__ = [
    'pointer_to_path',
    'path_to_pointer',
    'path_to_pointers',
    'PathResolutionError',
    'PathNotFoundError',
    'AmbiguousPathError',
    '__version__',
]