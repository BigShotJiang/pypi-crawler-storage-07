"""
Functional implementation of JSON-Path and JSON-Pointer conversions.

This module provides bidirectional conversion between JSON-Path and JSON-Pointer formats.

Key differences between conversion directions:

1. JSON-Pointer → JSON-Path (pointer_to_path):
   - Does NOT require a document
   - Simple syntactic transformation
   - Always deterministic and unambiguous
   - Example: "/store/book/0/title" → "$.store.book[0].title"

2. JSON-Path → JSON-Pointer (path_to_pointer, path_to_pointers):
   - REQUIRES a document for resolution
   - Resolves expressions (filters, wildcards) against actual data
   - Ensures path exists and is unambiguous
   - Example: "$.store.book[?(@.price > 10)].title" needs document to resolve

The asymmetry exists because:
- JSON-Pointers are concrete paths (always point to exactly one location)
- JSON-Paths can be queries (filters, wildcards) that need evaluation
- Without a document, we cannot resolve which elements match a query
- Requiring a document ensures consistent behavior and validates path existence
"""
import logging
from typing import Optional, List, Any
from jsonpath_ng.ext import parse as jsonpath_parse
from jsonpath_ng.exceptions import JsonPathParserError

logger = logging.getLogger(__name__)


class PathResolutionError(LookupError):
    """Base exception for path resolution errors."""
    pass


class PathNotFoundError(PathResolutionError):
    """Raised when a JSON-Path resolves to zero results."""
    pass


class AmbiguousPathError(PathResolutionError):
    """Raised when a JSON-Path resolves to multiple results."""
    pass


def pointer_to_path(pointer: str) -> str:
    """
    Convert a JSON-Pointer to a JSON-Path.

    This is a straightforward conversion:
    - Empty string or "/" -> "$"
    - "/foo/bar" -> "$.foo.bar"
    - "/foo/0/bar" -> "$.foo[0].bar"

    Args:
        pointer: JSON-Pointer string (e.g., "/store/book/0/title")

    Returns:
        JSON-Path string (e.g., "$.store.book[0].title")
    """
    logger.debug(f"Converting JSON-Pointer to JSON-Path: {pointer}")

    # Handle root cases
    if pointer == "" or pointer == "/":
        return "$"

    # Remove leading slash
    if pointer.startswith("/"):
        pointer = pointer[1:]

    # Split by '/' and convert to JSON-Path
    parts = pointer.split("/")
    path_parts = ["$"]

    for part in parts:
        # Unescape JSON-Pointer encoding
        part = part.replace("~1", "/").replace("~0", "~")

        # Check if part is a numeric index
        if part.isdigit():
            # Array index - add as [n]
            path_parts.append(f"[{part}]")
        elif part == "":
            # Empty key - needs bracket notation
            path_parts.append('[""]')
        else:
            # Object property - add with dot notation
            path_parts.append(f".{part}")

    result = "".join(path_parts)
    logger.debug(f"Converted to JSON-Path: {result}")
    return result


def path_to_pointer(jsonpath: str, document: Any) -> str:
    """
    Convert a JSON-Path to a JSON-Pointer by resolving it against a document.

    The document is required to ensure consistent behavior - the path is always
    resolved against an actual document to verify it exists and is unambiguous.

    If the expression resolves to:
    - Exactly one result: return the corresponding JSON-Pointer
    - Zero results: raise an exception
    - Multiple results: raise an exception

    Args:
        jsonpath: JSON-Path string (e.g., "$.store.book[0].title")
        document: Document to resolve the path against (required)

    Returns:
        JSON-Pointer string (e.g., "/store/book/0/title")

    Raises:
        PathNotFoundError: If the path resolves to zero results
        AmbiguousPathError: If the path resolves to multiple results
        ValueError: If the JSON-Path syntax is invalid
    """
    logger.debug(f"Converting JSON-Path to JSON-Pointer: {jsonpath}")

    # Handle root case
    if jsonpath == "$":
        return ""

    # Parse and resolve the JSON-Path against the document
    try:
        parsed = jsonpath_parse(jsonpath)
        matches = parsed.find(document)

        logger.debug(f"Found {len(matches)} matches")

        if len(matches) == 0:
            raise PathNotFoundError(f"Path resolution returned no results: {jsonpath}")
        elif len(matches) == 1:
            # Convert the match path to JSON-Pointer
            return _match_to_pointer(matches[0])
        else:
            raise AmbiguousPathError(f"Ambiguous path resolution: {jsonpath} resolved to {len(matches)} results")

    except JsonPathParserError as e:
        logger.error(f"Failed to parse JSON-Path: {e}")
        raise ValueError(f"Invalid JSON-Path: {jsonpath}") from e


def path_to_pointers(jsonpath: str, document: Any) -> List[str]:
    """
    Convert a JSON-Path to a list of JSON-Pointers.

    This function handles JSON-Paths that may resolve to multiple results.

    Args:
        jsonpath: JSON-Path string (e.g., "$.store.book[*].title")
        document: Document to resolve the path against

    Returns:
        List of JSON-Pointer strings (e.g., ["/store/book/0/title", "/store/book/1/title"])
    """
    logger.debug(f"Converting JSON-Path to JSON-Pointer list: {jsonpath}")

    try:
        parsed = jsonpath_parse(jsonpath)
        matches = parsed.find(document)

        logger.debug(f"Found {len(matches)} matches")

        pointers = [_match_to_pointer(match) for match in matches]

        logger.debug(f"Converted to JSON-Pointer list: {pointers}")
        return pointers

    except JsonPathParserError as e:
        logger.error(f"Failed to parse JSON-Path: {e}")
        raise ValueError(f"Invalid JSON-Path: {jsonpath}") from e


def _simple_path_to_pointer(jsonpath: str) -> str:
    """
    Simple conversion for JSON-Path to JSON-Pointer without document resolution.

    This only works for simple paths without expressions.
    """
    if jsonpath == "$":
        return ""

    # Remove leading $
    if jsonpath.startswith("$"):
        jsonpath = jsonpath[1:]

    # Handle bracket notation
    parts = []
    current = ""
    in_brackets = False

    for char in jsonpath:
        if char == "[":
            if current and current.startswith("."):
                parts.append(current[1:])
                current = ""
            in_brackets = True
            current += char
        elif char == "]":
            in_brackets = False
            current += char
            # Extract the content from brackets
            bracket_content = current[1:-1]
            if bracket_content.startswith('"') and bracket_content.endswith('"'):
                # String key in brackets
                parts.append(bracket_content[1:-1])
            else:
                # Numeric index
                parts.append(bracket_content)
            current = ""
        elif char == "." and not in_brackets:
            if current:
                parts.append(current)
            current = "."
        else:
            current += char

    if current and current.startswith("."):
        parts.append(current[1:])
    elif current:
        parts.append(current)

    # Escape for JSON-Pointer
    escaped_parts = []
    for part in parts:
        # Escape ~ and /
        part = part.replace("~", "~0").replace("/", "~1")
        escaped_parts.append(part)

    result = "/" + "/".join(escaped_parts) if escaped_parts else ""
    return result


def _match_to_pointer(match) -> str:
    """
    Convert a jsonpath_ng match object to a JSON-Pointer.

    Args:
        match: A jsonpath_ng Match object

    Returns:
        JSON-Pointer string
    """
    # Build the path from the match
    path_parts = []
    current = match

    while current.context is not None:
        if hasattr(current.path, 'index'):
            # Array index
            path_parts.insert(0, str(current.path.index))
        elif hasattr(current.path, 'fields') and current.path.fields:
            # Object field
            path_parts.insert(0, current.path.fields[0])
        elif hasattr(current.path, 'field'):
            # Single field
            path_parts.insert(0, current.path.field)

        current = current.context

    # Escape for JSON-Pointer
    escaped_parts = []
    for part in path_parts:
        # Escape ~ and /
        part = str(part).replace("~", "~0").replace("/", "~1")
        escaped_parts.append(part)

    result = "/" + "/".join(escaped_parts) if escaped_parts else ""
    return result
