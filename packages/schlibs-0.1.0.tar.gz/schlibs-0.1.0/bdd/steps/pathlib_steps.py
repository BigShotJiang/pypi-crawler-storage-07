"""Step definitions for pathlib path conversion feature."""
import logging
import sys
from pathlib import Path as FilePath
from behave import given, when, then
from ruamel.yaml import YAML

# Add the src directory to the path so we can import our pathlib module
sys.path.insert(0, str(FilePath(__file__).resolve().parent.parent.parent / "src"))

from json_pathlib.conversion import pointer_to_path, path_to_pointer, path_to_pointers

logger = logging.getLogger(__name__)


@given('the JSON-Pointer "{jsonpointer}"')
def step_given_json_pointer(context, jsonpointer):
    """Store a JSON-Pointer in the context."""
    logger.debug(f"Given JSON-Pointer: {jsonpointer}")
    context.jsonpointer = jsonpointer


@given('I load the referred document from "{fixturePath}"')
def step_load_document(context, fixturePath):
    """Load a YAML document from the fixtures directory."""
    # The fixture path is relative to features/pathlib/
    # We need to resolve the symlink to get the correct path
    fixture_file = FilePath(__file__).resolve().parent.parent.parent.parent / "features" / "pathlib" / fixturePath
    logger.debug(f"Loading document from: {fixture_file}")

    yaml = YAML(typ='safe')
    with open(fixture_file, 'r') as f:
        context.document = yaml.load(f)

    logger.debug(f"Loaded document: {context.document}")


@given('the JSON-Path "{jsonpath}"')
def step_given_json_path(context, jsonpath):
    """Store a JSON-Path in the context."""
    logger.debug(f"Given JSON-Path: {jsonpath}")
    context.jsonpath = jsonpath


@when('I convert it to a JSON-Path')
def step_convert_to_jsonpath(context):
    """Convert JSON-Pointer to JSON-Path."""
    logger.debug(f"Converting JSON-Pointer to JSON-Path: {context.jsonpointer}")
    context.result = pointer_to_path(context.jsonpointer)
    logger.debug(f"Conversion result: {context.result}")


@when('I convert it to a JSON-Pointer')
def step_convert_to_jsonpointer(context):
    """Convert JSON-Path to JSON-Pointer."""
    logger.debug(f"Converting JSON-Path to JSON-Pointer: {context.jsonpath}")

    try:
        context.result = path_to_pointer(context.jsonpath, context.document)
        logger.debug(f"Conversion result: {context.result}")
        context.exception = None
    except Exception as e:
        logger.debug(f"Exception raised: {type(e).__name__}: {e}")
        context.exception = e


@when('I convert it to a JSON-Pointer List')
def step_convert_to_jsonpointer_list(context):
    """Convert JSON-Path to a list of JSON-Pointers."""
    logger.debug(f"Converting JSON-Path to JSON-Pointer List: {context.jsonpath}")
    result_list = path_to_pointers(context.jsonpath, context.document)
    # Convert list to comma-separated string for comparison with feature file expectations
    context.result = ", ".join(result_list)
    logger.debug(f"Conversion result: {context.result}")


@then('the result should be "{expected}"')
def step_verify_result(context, expected):
    """Verify the conversion result."""
    logger.debug(f"Expected: {expected}, Got: {context.result}")
    assert context.result == expected, f"Expected '{expected}' but got '{context.result}'"


@then('the result should be ""')
def step_verify_empty_result(context):
    """Verify the conversion result is an empty string."""
    logger.debug(f"Expected: (empty string), Got: {context.result}")
    assert context.result == "", f"Expected empty string but got '{context.result}'"


@given('the JSON-Pointer ""')
def step_given_empty_json_pointer(context):
    """Store an empty JSON-Pointer in the context."""
    logger.debug("Given empty JSON-Pointer")
    context.jsonpointer = ""


@then('it should raise "{expected_exception}"')
def step_verify_exception(context, expected_exception):
    """Verify that a specific exception was raised."""
    logger.debug(f"Verifying exception: {expected_exception}")
    assert hasattr(context, 'exception'), "Expected an exception to be raised, but none was"
    assert context.exception is not None, f"Expected {expected_exception} to be raised, but no exception occurred"

    actual_exception_name = type(context.exception).__name__
    assert actual_exception_name == expected_exception, \
        f"Expected {expected_exception} but got {actual_exception_name}: {context.exception}"
