Command Line Interface
======================

bioregistry automatically installs the command ``bioregistry``. See ``bioregistry
--help`` for usage details.

.. click:: bioregistry.cli:main
    :prog: bioregistry
    :show-nested:
