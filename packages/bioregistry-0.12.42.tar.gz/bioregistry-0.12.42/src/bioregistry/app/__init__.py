"""Web application for the Bioregistry."""
