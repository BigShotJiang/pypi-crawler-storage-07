"""Export the Bioregistry."""

from .cli import export

if __name__ == "__main__":
    export()
