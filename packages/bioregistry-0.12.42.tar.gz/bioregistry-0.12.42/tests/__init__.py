"""Tests for the Bioregistry."""
