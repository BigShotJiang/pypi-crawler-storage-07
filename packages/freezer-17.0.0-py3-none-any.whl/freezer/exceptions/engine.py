# (c) Copyright 2016 Hewlett-Packard Development Enterprise, L.P.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


class EngineException(Exception):
    msg = "An unknown error occurred."

    def __init__(self, message=None, **kwargs):
        if not message:
            message = self.msg
        super(EngineException, self).__init__(message, kwargs)


class EngineNotFound(EngineException):

    def __init__(self, message):
        super(EngineNotFound, self).__init__(message)
