# -*- coding: utf-8 -*-

from .caster import qldb_caster

caster = qldb_caster

__version__ = "1.40.0"