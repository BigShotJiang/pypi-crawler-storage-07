# placeholder for poetry-dynamic-versioning
__version__ = "0.42.2"
