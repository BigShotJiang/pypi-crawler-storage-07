# TODO: Parity with pre-commit

This page tracks gaps that prevent `prek` from being a drop-in replacement for `pre-commit`.

## Subcommands not implemented

- `gc`
- `try-repo`

## Languages not supported yet

- `conda`
- `coursier`
- `dart`
- `dotnet`
- `haskell`
- `julia`
- `lua`
- `perl`
- `r`
- `ruby`
- `rust`
- `swift`
