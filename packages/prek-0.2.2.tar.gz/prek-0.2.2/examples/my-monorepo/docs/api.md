# API Documentation

This document describes the API endpoints.

## Endpoints

- `GET /api/v1/users` - Get all users
- `POST /api/v1/users` - Create a new user
