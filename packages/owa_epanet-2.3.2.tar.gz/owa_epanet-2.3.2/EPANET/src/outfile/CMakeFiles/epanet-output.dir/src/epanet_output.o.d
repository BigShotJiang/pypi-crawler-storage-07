CMakeFiles/epanet-output.dir/src/epanet_output.o: \
 /home/epanet-python/owa-epanet/EPANET/src/outfile/src/epanet_output.c \
 /usr/include/stdc-predef.h /usr/include/stdlib.h \
 /usr/include/aarch64-linux-gnu/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/aarch64-linux-gnu/bits/wordsize.h \
 /usr/include/aarch64-linux-gnu/bits/timesize.h \
 /usr/include/aarch64-linux-gnu/sys/cdefs.h \
 /usr/include/aarch64-linux-gnu/bits/long-double.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h \
 /usr/lib/gcc/aarch64-linux-gnu/12/include/stddef.h \
 /usr/include/aarch64-linux-gnu/bits/waitflags.h \
 /usr/include/aarch64-linux-gnu/bits/waitstatus.h \
 /usr/include/aarch64-linux-gnu/bits/floatn.h \
 /usr/include/aarch64-linux-gnu/bits/floatn-common.h \
 /usr/include/aarch64-linux-gnu/sys/types.h \
 /usr/include/aarch64-linux-gnu/bits/types.h \
 /usr/include/aarch64-linux-gnu/bits/typesizes.h \
 /usr/include/aarch64-linux-gnu/bits/time64.h \
 /usr/include/aarch64-linux-gnu/bits/types/clock_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/clockid_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/time_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/timer_t.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-intn.h /usr/include/endian.h \
 /usr/include/aarch64-linux-gnu/bits/endian.h \
 /usr/include/aarch64-linux-gnu/bits/endianness.h \
 /usr/include/aarch64-linux-gnu/bits/byteswap.h \
 /usr/include/aarch64-linux-gnu/bits/uintn-identity.h \
 /usr/include/aarch64-linux-gnu/sys/select.h \
 /usr/include/aarch64-linux-gnu/bits/select.h \
 /usr/include/aarch64-linux-gnu/bits/types/sigset_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__sigset_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_timeval.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h \
 /usr/include/aarch64-linux-gnu/bits/pthreadtypes.h \
 /usr/include/aarch64-linux-gnu/bits/thread-shared-types.h \
 /usr/include/aarch64-linux-gnu/bits/pthreadtypes-arch.h \
 /usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h \
 /usr/include/aarch64-linux-gnu/bits/struct_mutex.h \
 /usr/include/aarch64-linux-gnu/bits/struct_rwlock.h \
 /usr/include/alloca.h /usr/include/aarch64-linux-gnu/bits/stdlib-float.h \
 /usr/include/stdio.h /usr/lib/gcc/aarch64-linux-gnu/12/include/stdarg.h \
 /usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__FILE.h \
 /usr/include/aarch64-linux-gnu/bits/types/FILE.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h \
 /usr/include/aarch64-linux-gnu/bits/stdio_lim.h /usr/include/string.h \
 /usr/include/aarch64-linux-gnu/bits/types/locale_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__locale_t.h \
 /usr/include/strings.h \
 /home/epanet-python/owa-epanet/EPANET/src/outfile/../util/errormanager.h \
 /home/epanet-python/owa-epanet/EPANET/src/outfile/../util/filemanager.h \
 /home/epanet-python/owa-epanet/EPANET/src/outfile/../util/cstr_helper.h \
 /usr/lib/gcc/aarch64-linux-gnu/12/include/stdbool.h \
 /home/epanet-python/owa-epanet/EPANET/src/outfile/include/epanet_output.h \
 /home/epanet-python/owa-epanet/EPANET/src/outfile/include/epanet_output_enums.h \
 /home/epanet-python/owa-epanet/EPANET/src/outfile/include/epanet_output_export.h \
 /home/epanet-python/owa-epanet/EPANET/src/outfile/src/messages.h
