"""
Error handling module for Irys Core.

This module contains custom exception classes and error handlers.
"""

from .errors import (
    HttpStatus,
    Messages,
    AppException,
    NotFoundException,
    BadRequestException,
    UnauthorizedException,
    InternalServerError,
    ForbiddenException,
    ConflictException,
    UnprocessableEntityException,
    SxTError,
    SxTAuthError,
    SxTQueryError,
    RedisError,
    RedisConnectionError,
    LoggingError,
    LoggingConfigError,
)
from .exception_handlers import app_exception_handler

__all__ = [
    "HttpStatus",
    "Messages",
    "AppException",
    "NotFoundException", 
    "BadRequestException",
    "UnauthorizedException",
    "InternalServerError",
    "ForbiddenException",
    "ConflictException",
    "UnprocessableEntityException",
    "SxTError",
    "SxTAuthError",
    "SxTQueryError",
    "RedisError",
    "RedisConnectionError",
    "LoggingError",
    "LoggingConfigError",
    "app_exception_handler",
]
