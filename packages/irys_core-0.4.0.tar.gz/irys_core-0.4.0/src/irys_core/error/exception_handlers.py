# irys_core/exception_handlers.py
from fastapi import Request
from fastapi.responses import JSONResponse
from irys_core.logging.logging_config import logger
from .errors import AppException, Messages, HttpStatus

async def app_exception_handler(request: Request, exc: AppException):
    """
    Handles known application errors (subclasses of AppException).
    """
    log_context = {
        "path": str(request.url),
        "status_code": exc.status_code,
        "error_message": exc.message,
    }

    if exc.module:
        log_context["module"] = exc.module

    # Use a more descriptive event message
    event_message = f"Application exception caught: {type(exc).__name__}"

    logger.error(
        event_message,
        exc_info=True,
        **log_context
    )
    
    return JSONResponse(
        status_code=exc.status_code,
        content={"message": exc.message},
    )

async def generic_exception_handler(request: Request, exc: Exception):
    """
    Handles any unexpected, unhandled exceptions. This is the critical fallback.
    """
    logger.critical(
        "Unhandled exception caught",
        exc_info=True, # This ensures the full traceback is logged
        module="unhandled_exceptions",
        path=str(request.url),
        error_type=type(exc).__name__
    )
    
    return JSONResponse(
        status_code=HttpStatus.INTERNAL_SERVER_ERROR,
        content={"message": Messages.INTERNAL_SERVER_ERROR},
    )