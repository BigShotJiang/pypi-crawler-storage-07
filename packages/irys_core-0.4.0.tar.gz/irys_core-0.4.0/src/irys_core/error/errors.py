from enum import IntEnum
from typing import List, Any

class HttpStatus(IntEnum):
    """
    HTTP status codes.
    """
    OK = 200
    CREATED = 201
    NO_CONTENT = 204
    BAD_REQUEST = 400
    UNAUTHORIZED = 401
    FORBIDDEN = 403
    NOT_FOUND = 404
    CONFLICT = 409
    UNPROCESSABLE_ENTITY = 422
    INTERNAL_SERVER_ERROR = 500

class Messages:
    """
    A central repository for user-facing messages.
    """
    INTERNAL_SERVER_ERROR = 'Internal server error'
    USER_NOT_FOUND = 'User not found'
    INVALID_CREDENTIALS = 'Invalid email or password'
    EMAIL_ALREADY_EXISTS = 'Email already exists'
    NOT_FOUND = 'Not found'
    SUCCESS_MESSAGE = 'Success'
    FORBIDDEN = 'You do not have permission to perform this action.'
    CONFLICT = 'A resource with this identifier already exists.'
    UNPROCESSABLE_ENTITY = 'The request was well-formed but was unable to be followed due to semantic errors.'
    
    @staticmethod
    def MISSING_FIELDS(fields: List[str]) -> str:
        return f"The following fields are missing or invalid: {', '.join(fields)}"

class AppException(Exception):
    """
    Base exception class for the application.
    It's updated to carry an optional 'module' name.
    """
    def __init__(self, status_code: int, message: Any, module: str | None = None):
        self.status_code = status_code
        self.message = message
        self.module = module
        super().__init__(message)

class NotFoundException(AppException):
    def __init__(self, message: str = Messages.NOT_FOUND, module: str | None = None):
        super().__init__(HttpStatus.NOT_FOUND, message, module=module)

class BadRequestException(AppException):
    def __init__(self, message: str = "Bad Request", module: str | None = None):
        super().__init__(HttpStatus.BAD_REQUEST, message, module=module)

class UnauthorizedException(AppException):
    def __init__(self, message: str = "Unauthorized", module: str | None = None):
        super().__init__(HttpStatus.UNAUTHORIZED, message, module=module)

class InternalServerError(AppException):
    def __init__(self, message: str = Messages.INTERNAL_SERVER_ERROR, module: str | None = None):
        super().__init__(HttpStatus.INTERNAL_SERVER_ERROR, message, module=module)

class ForbiddenException(AppException):
    def __init__(self, message: str = Messages.FORBIDDEN, module: str | None = None):
        super().__init__(HttpStatus.FORBIDDEN, message, module=module)

class ConflictException(AppException):
    def __init__(self, message: str = Messages.CONFLICT, module: str | None = None):
        super().__init__(HttpStatus.CONFLICT, message, module=module)

class UnprocessableEntityException(AppException):
    def __init__(self, message: Any = Messages.UNPROCESSABLE_ENTITY, module: str | None = None):
        super().__init__(HttpStatus.UNPROCESSABLE_ENTITY, message, module=module)

# SxT Specific Exceptions
class SxTError(Exception):
    """Base exception class for SxT-related errors."""
    pass


class SxTAuthError(SxTError):
    """Exception raised when SxT authentication fails."""
    def __init__(self, message: str = "SxT authentication failed"):
        self.message = message
        super().__init__(message)


class SxTQueryError(SxTError):
    """Exception raised when SxT query execution fails."""
    def __init__(self, message: str = "SxT query execution failed"):
        self.message = message
        super().__init__(message)


# Redis Specific Exceptions
class RedisError(Exception):
    """Base exception class for Redis-related errors."""
    pass


class RedisConnectionError(RedisError):
    """Exception raised when Redis connection fails."""
    def __init__(self, message: str = "Redis connection failed"):
        self.message = message
        super().__init__(message)


# Logging Specific Exceptions
class LoggingError(Exception):
    """Base exception class for logging-related errors."""
    pass


class LoggingConfigError(LoggingError):
    """Exception raised when logging configuration fails."""
    def __init__(self, message: str = "Logging configuration failed"):
        self.message = message
        super().__init__(message)