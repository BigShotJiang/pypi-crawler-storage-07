# This is a script to manually test Redis functionality, not an automated test

from irys_core.redis_setup_code.client import RedisClient
import time

def main():
    # Initialize Redis client
    r = RedisClient()

    # 1️⃣ Set a key with TTL (50 seconds)
    r.set("test_token", "12345", ttl=50)

    # 2️⃣ Immediately get the key
    value = r.get("test_token")
    print("Right after set:", value)  # Should print: 12345

    # 3️⃣ Wait for some time to check TTL
    time.sleep(5)
    
    # Check the TTL
    ttl = r.ttl("test_token")
    print(f"TTL after 5 seconds: {ttl}")

    # Optional: Wait longer to see it expire
    # time.sleep(50)
    # value = r.get("test_token")
    # print("After TTL expiry:", value)  # Should print: None

if __name__ == "__main__":
    main()
