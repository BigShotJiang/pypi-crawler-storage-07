# Redis-backed idempotency helper
