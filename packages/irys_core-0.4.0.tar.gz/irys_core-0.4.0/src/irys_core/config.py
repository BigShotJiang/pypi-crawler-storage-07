# from typing import Optional
from typing import Optional
from pydantic_settings import BaseSettings
from dotenv import load_dotenv
import os

# Explicitly load .env file before settings are read
load_dotenv(dotenv_path=os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), ".env"))

class Settings(BaseSettings):
    # SXT CREDS
    SXT_API_KEY: str = ""
    SXT_PROXY_URL: str = ""
    SXT_BASE_URL: str = ""
    SXT_MASTER_BISCUIT: str = ""
    SXT_BISCUIT_QUERY: str = ""
    SXT_QUERY_TYPE: str = ""
    SXT_PROJECT_ID: str = ""
    GOOGLE_APPLICATION_CREDENTIALS: str = ""
    SXT_BUSINESS_BISCUIT: str = ""
    # SXT_TOKEN_TTL_MARGIN_SEC: int = 30
    # SXT_BISCUIT_REFRESH_HOURS: int = 24

    # REDIS CREDS by SAANACHI MAM
    REDIS_URL: str = ""
    REDIS_PASSWORD: str = ""
    REDIS_PORT: str = ""
    REDIS_DB: str = ""
    
    JWT_SECRET_KEY: Optional[str] = None

    # Auth0 settings (optional to prevent startup crashes)
    AUTH0_DOMAIN: Optional[str] = None
    AUTH0_AUDIENCE: Optional[str] = None

    class Config:
        case_sensitive = False
        env_file = ".env"
        env_file_encoding = "utf-8"

settings = Settings()
