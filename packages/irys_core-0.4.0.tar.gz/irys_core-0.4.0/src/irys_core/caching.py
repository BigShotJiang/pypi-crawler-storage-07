# Simple TTL cache decorators
