import logging
import logging.config
from pathlib import Path
import structlog
from datetime import datetime, timedelta
import os

LOGS_DIR = Path(__file__).resolve().parent / "logs"
LOGS_DIR.mkdir(parents=True, exist_ok=True)
# LOG_FILE will now be created dynamically with the current date

def to_custom_dict(_, __, event_dict):
    """
    Reshapes the log, prioritizing a manually passed 'module'
    and keeping the main 'event' message at the top level.
    """
    module = event_dict.pop("module", None)
    if module is None:
        module = event_dict.pop("logger", "unknown")

    # Move the main message (event) to the top level for clarity
    event = event_dict.pop("event", "No event message")

    return {
        "level": event_dict.pop("level", None),
        "module": module,
        "timestamp": event_dict.pop("timestamp", None),
        "event": event, # Main message is now here
        "data": event_dict, # The rest of the context goes here
    }

structlog_processors = [
    structlog.processors.TimeStamper(fmt="iso", key="timestamp"),
    structlog.stdlib.add_log_level,
    structlog.stdlib.add_logger_name,
    structlog.processors.format_exc_info,
    # This renders the event dictionary as a string, which we don't want before JSONRenderer
    # structlog.processors.StackInfoRenderer(), 
    structlog.dev.set_exc_info,
    to_custom_dict,
    structlog.processors.JSONRenderer(),
]

def setup_logging():
    # Create a filename with the current date, e.g., "2025-09-24.log"
    log_filename = LOGS_DIR / f"{datetime.now().strftime('%Y-%m-%d')}.log"

    # --- Manual cleanup of old log files (older than 15 days) ---
    cutoff_date = datetime.now() - timedelta(days=15)
    for log_file in LOGS_DIR.glob("*.log"):
        try:
            # Extract date from a filename like "YYYY-MM-DD.log"
            file_date_str = log_file.stem
            file_date = datetime.strptime(file_date_str, '%Y-%m-%d')
            if file_date < cutoff_date:
                os.remove(log_file)
        except (ValueError, FileNotFoundError):
            # Ignore files that don't match the date format or are deleted concurrently
            continue

    logging_config = {
        "version": 1,
        "disable_existing_loggers": False,
        "handlers": {
            "console": {
                "class": "logging.StreamHandler",
                "level": "DEBUG",
            },
            "file": {
                "class": "logging.FileHandler", # Changed from TimedRotatingFileHandler
                "filename": str(log_filename), # Use the new dated filename
                "level": "INFO",
            },
        },
        "root": {
            "handlers": ["console", "file"],
            "level": "DEBUG",
        },
    }
    logging.config.dictConfig(logging_config)
    structlog.configure(
        processors=structlog_processors,
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )

# Run setup when the module is imported
setup_logging()

# Global logger for the application
logger = structlog.get_logger("irys_core")

