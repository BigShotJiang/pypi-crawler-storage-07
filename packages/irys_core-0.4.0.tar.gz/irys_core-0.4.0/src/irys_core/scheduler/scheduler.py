from fastapi import FastAPI
from irys_core.logging.logging_config import logger
import asyncio
# import httpx
# import redis.asyncio as redis
# import fakeredis.aioredis
# from tenacity import retry, wait_exponential, stop_after_attempt
# import os
from irys_core.config import settings
from irys_core.redis_setup_code.client import RedisClient
# from ..sxt.sxt_auth import SxTAuth

app = FastAPI()

# --- Env Vars ---
REDIS_HOST = settings.REDIS_URL
REDIS_PORT = settings.REDIS_PORT
REDIS_PASSWORD = settings.REDIS_PASSWORD

# SXT_API_KEY = settings.SXT_API_KEY
# SXT_PROXY_URL = settings.SXT_PROXY_URL
# SXT_BASE_URL = settings.SXT_BASE_URL
# SXT_MASTER_BISCUIT = settings.SXT_MASTER_BISCUIT
# SXT_BISCUIT_QUERY = settings.SXT_BISCUIT_QUERY
# SXT_PROJECT_ID = settings.SXT_PROJECT_ID

# # --- Redis / FakeRedis Setup ---
# async def init_redis():
#     try:
#         client = RedisClient()
#         logger.info(" Connected to real Redis", host=REDIS_HOST, port=REDIS_PORT)
#         return client
#     except Exception as e:
#         logger.warning(" Redis not available, using FakeRedis instead", error=str(e))

# redis_client: redis.Redis = None  # initialized at startup


# --- Token Refresh ---
# @retry(wait=wait_exponential(multiplier=1, min=2, max=10), stop=stop_after_attempt(3))
# async def refresh_token():
#     logger.info("Refreshing SxT token...")

#     if not SXT_PROXY_URL or not SXT_API_KEY:
#         # Local stub
#         fake_token = "local_fake_token"
#         await redis_client.set("sxt:token", fake_token, ex=3600)
#         logger.info("Stub token set in Redis (local dev mode).")
#         return

#     headers = {"accept": "application/json", "x-api-key": SXT_API_KEY}
#     async with httpx.AsyncClient() as client:
#         response = await client.post(SXT_PROXY_URL, headers=headers, timeout=10)

#         if response.status_code != 200:
#             logger.error("Token refresh failed", status_code=response.status_code, body=response.text)
#             response.raise_for_status()

#         data = response.json()
#         access_token = data["accessToken"]
#         expires_in = data.get("expiresIn", 3600)

#         await redis_client.set("sxt:token", access_token, ex=expires_in)
#         logger.info("Token refreshed successfully", expires_in=expires_in)

# cron refresher for main token
async def dynamic_cron_refresher(token_key: str, interval_seconds: int, refresh_func):
    """
    Runs every `interval_seconds` to ensure the token is fresh in Redis.
    Uses the provided refresh_func to refresh the token.
    """
    redis_client = RedisClient()  # Create an instance
    while True:
        try:
            ttl = redis_client.ttl(token_key)
            if ttl == -2:  # no key
                logger.info(f"No token '{token_key}' in Redis, refreshing...")
                await refresh_func()
            elif ttl != -1 and ttl < interval_seconds:
                logger.info(f"Token '{token_key}' expiring in {ttl}s, refreshing...")
                await refresh_func()
            else:
                logger.debug(f"Token '{token_key}' TTL is {ttl}, no refresh needed.")
        except Exception as e:
            logger.error(f"Error in cron refresher for '{token_key}'", error=str(e))

        await asyncio.sleep(interval_seconds)






