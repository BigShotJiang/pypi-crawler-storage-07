# Expose RedisClient when importing the package
# from .client import RedisClient
