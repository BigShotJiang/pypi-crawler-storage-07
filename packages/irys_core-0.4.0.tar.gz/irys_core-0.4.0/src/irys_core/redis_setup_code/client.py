from dotenv import load_dotenv
# import os
import redis
import logging
from typing import Optional
from irys_core.config import settings

# Load environment variables from .env
load_dotenv()

class RedisClient:
    """
    Simple Redis client wrapper:
    - Connects using .env values
    - Provides get() and set() with optional TTL
    - Handles graceful failure if Redis is down
    """

    def __init__(self):
        # Read Redis config from environment variables
        redis_url = settings.REDIS_URL
        redis_password = settings.REDIS_PASSWORD
        redis_port = settings.REDIS_PORT
        db = settings.REDIS_DB

        try:
            self.client = redis.Redis(
                host=redis_url,
                port=redis_port,
                password=redis_password,
                db=db,                    # use db after defining it
                decode_responses=True
            )
            self.client.ping()  # Test connection
            logging.info(" Connected to Redis successfully.")
        except Exception as e:
            logging.error(f" Redis connection failed: {e}")
            self.client = None

    def set(self, key: str, value: str, ttl: Optional[int] = None) -> bool:
        """Set a key in Redis with optional TTL (seconds)."""
        if not self.client:
            logging.warning("Redis not available. Skipping set().")
            return False
        try:
            self.client.set(name=key, value=value, ex=ttl)
            logging.info(f" Key '{key}' set with TTL={ttl}")
            return True
        except Exception as e:
            logging.error(f" Failed to set key '{key}': {e}")
            return False

    def get(self, key: str):
        """Retrieve a key from Redis. Returns None if key not found."""
        if not self.client:
            logging.warning("Redis not available. Returning None.")
            return None
        try:
            value = self.client.get(key)
            logging.info(f" Retrieved key '{key}': {value}")
            return value
        except Exception as e:
            logging.error(f" Failed to get key '{key}': {e}")
            return None

    def ttl(self, key: str) -> int:
        """
        Get the time-to-live (TTL) for a key in Redis.
        Returns:
            int: TTL in seconds, -2 if key does not exist, -1 if key exists but has no associated expire.
        """
        if not self.client:
            logging.warning("Redis not available. Returning TTL as -2.")
            return -2
        try:
            ttl_value = self.client.ttl(key)
            logging.info(f" TTL for key '{key}': {ttl_value}")
            return int(ttl_value)
        except Exception as e:
            logging.error(f" Failed to get TTL for key '{key}': {e}")
            return -2

    def close(self):
        """Gracefully close the Redis connection."""
        if self.client:
            try:
                self.client.close()
                logging.info(" Redis connection closed.")
            except Exception as e:
                logging.error(f" Failed to close Redis connection: {e}")
