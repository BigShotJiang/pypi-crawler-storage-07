from typing import Optional, List, Any
from pydantic import BaseModel

# Pydantic models
class AuthResponse(BaseModel):
    accessToken: str
    accessTokenExpires: int

class SQLRequest(BaseModel):
    biscuits: Optional[List[str]] = None
    queryType: str = "OLTP"
    sqlText: str

class SQLResponse(BaseModel):
    data: List[Any]

class BiscuitRecord(BaseModel):
    TABLE_CATEGORY: Optional[str] = None
    BISCUIT_LOCATION: Optional[str] = None
