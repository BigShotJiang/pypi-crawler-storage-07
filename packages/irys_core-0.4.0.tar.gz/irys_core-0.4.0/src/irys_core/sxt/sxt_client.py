# SxT client wrapper
from typing import Optional, List, Dict, Any
import httpx
from tenacity import AsyncRetrying, stop_after_attempt, wait_fixed, retry_if_exception_type

from irys_core.redis_setup_code.client import RedisClient

from .biscuit_gsm import fetch_biscuits_from_gsm
# from redis.asyncio import Redis

from ..config import settings
from ..error.errors import SxTQueryError
from .sxt_auth import SxTAuth
from .sxt_models import SQLRequest, SQLResponse, BiscuitRecord


class SxTClient:
    def __init__(self, settings, auth: SxTAuth):
        self.settings = settings
        self.auth = auth
        
    async def sxt_query(
        self,
        sql: str,
        biscuits: List[str] = [settings.SXT_BUSINESS_BISCUIT],
        tenant: Optional[str] = None,
        query_type: str = settings.SXT_QUERY_TYPE,
    ) -> Dict[str, Any]:
        """
        Execute a SQL query against SxT.
        If `tenant` is provided, resolve its biscuit and inject.
        """
        # TODO: integrate BiscuitManager (later step)
        biscuits = biscuits

        req = SQLRequest(sqlText=sql, queryType=query_type, biscuits=biscuits)
        json=req.model_dump()
        print("SQL Request:", json)
        # print("Using token:", self.auth.accessToken)
        async def do_request(token: str) -> Dict[str, Any]:
            async with httpx.AsyncClient(timeout=20) as client:
                resp = await client.post(
                    self.settings.SXT_BASE_URL,
                    headers={
                        "Authorization": f"Bearer {token}",
                        "Content-Type": "application/json",
                    },
                    json=req.model_dump(),
                )
                print("SQL Response:", resp.status_code, resp.text)
                if resp.status_code == 401:  # expired token
                    raise PermissionError("Unauthorized")
                if resp.status_code != 200:
                    raise SxTQueryError(f"Query failed: {resp.status_code} {resp.text}")
                # First create the response object
                response_obj = SQLResponse(data=resp.json())
                # Get model_dump but handle it explicitly as Dict[str, Any]
                model_data = response_obj.model_dump()
                result: Dict[str, Any] = {}
                # Explicitly copy each field with its proper type
                result["data"] = model_data["data"]
                return result

        try:
            token = await self.auth.get_access_token()

            async for attempt in AsyncRetrying(
                stop=stop_after_attempt(3),
                wait=wait_fixed(2),
                retry=retry_if_exception_type((httpx.RequestError, SxTQueryError)),
            ):
                with attempt:
                    try:
                        print("Using token:", token)
                        result = await do_request(token)
                        return result
                    except PermissionError:
                        # refresh token once
                        token = await self.auth.get_access_token(force_refresh=True)
                        result = await do_request(token)
                        return result

        except Exception as e:
            raise SxTQueryError("Failed to run SQL query") from e
        return {"data": []}  # Return a properly typed empty result

    async def biscuit_query(self) -> List[BiscuitRecord]:
        sql = self.settings.SXT_BISCUIT_QUERY
        biscuits = [self.settings.SXT_MASTER_BISCUIT] if self.settings.SXT_MASTER_BISCUIT else []
        query_type = self.settings.SXT_QUERY_TYPE

        result = await self.sxt_query(sql=sql, biscuits=biscuits, query_type=query_type)
        # print("Biscuit query result:", result)
        # Parse rows into BiscuitRecord objects
        return [BiscuitRecord(**data) for data in result["data"]]

    async def sxt_init(self) -> Dict[str, Any]:
        redis_client = RedisClient()
        auth = SxTAuth(settings, redis_client)
        client = SxTClient(settings, auth)
        biscuit_records = await client.biscuit_query()
        biscuits_map = await fetch_biscuits_from_gsm(biscuit_records, settings.SXT_PROJECT_ID, redis_client)
        token = await auth.get_access_token()
        return {"token": token, "biscuits": biscuits_map}