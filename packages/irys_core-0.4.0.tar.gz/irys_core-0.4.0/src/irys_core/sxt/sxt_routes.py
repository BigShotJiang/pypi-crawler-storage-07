from fastapi import APIRouter
from irys_core.config import settings
from .sxt_auth import SxTAuth
from .sxt_client import SxTClient
# from irys_core.sxt.biscuit_gsm import fetch_biscuits_from_gsm

router = APIRouter()

@router.get("/fetch_biscuits")
async def fetch_biscuits():
    client = SxTClient(settings, SxTAuth(settings))
    result = await client.sxt_init()
    return result


@router.get("/test_query")
async def test_query():
    auth = SxTAuth(settings)
    client = SxTClient(settings, auth)
    sql = "select * from irys_Dev.biscuit_Registry WHERE table_name = 'FORM_DATA' "
    result = await client.sxt_query(sql)
    return result