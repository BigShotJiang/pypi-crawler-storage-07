from typing import List, Dict, Optional
from google.cloud import secretmanager
from .sxt_models import BiscuitRecord
import logging

logger = logging.getLogger(__name__)

async def fetch_biscuits_from_gsm(records: List[BiscuitRecord], project_id: str, redis=None) -> Dict[str, Optional[str]]:
    """
    Fetch biscuits from Google Secret Manager using biscuit_location from BiscuitRecord.
    Returns a mapping of table_category to biscuit value.
    Uses Redis for caching if provided.
    """
    client = secretmanager.SecretManagerServiceClient()
    result = {}

    for record in records:
        if record.TABLE_CATEGORY is None:
            logger.warning("Skipping record with None TABLE_CATEGORY")
            continue
        cache_key = f"sxt:biscuit:{record.TABLE_CATEGORY}"
        biscuit = None

        # Try Redis first
        if redis:
            cached =  redis.get(cache_key)
            if cached:
                biscuit = cached.decode() if isinstance(cached, bytes) else cached
                result[record.TABLE_CATEGORY] = biscuit
                logger.info(f"Fetched biscuit for {record.TABLE_CATEGORY} from Redis")
                continue

        # If not in Redis, fetch from GSM
        try:
            secret_path = f"projects/{project_id}/secrets/{record.BISCUIT_LOCATION}/versions/latest"
            response = client.access_secret_version(request={"name": secret_path})
            biscuit = response.payload.data.decode("UTF-8")
            result[record.TABLE_CATEGORY] = biscuit
            logger.info(f"Fetched biscuit for {record.TABLE_CATEGORY} from GSM")

            # Store in Redis
            if redis and biscuit:
                await redis.set(cache_key, biscuit, ttl=24*3600)  # 24h expiry
        except Exception as e:
            logger.error(f"Failed to fetch biscuit for {record.TABLE_CATEGORY}: {e}")
            result[record.TABLE_CATEGORY] = None

    return result
