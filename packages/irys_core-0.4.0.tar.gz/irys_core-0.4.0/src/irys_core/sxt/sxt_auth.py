# from typing import Optional
import httpx
from tenacity import AsyncRetrying, stop_after_attempt, wait_fixed, retry_if_exception_type
# from ..config import settings
from .sxt_models import AuthResponse
from irys_core.error.errors import SxTAuthError
from irys_core.redis_setup_code.client import RedisClient
from irys_core.logging.logging_config import logger  # Add logger import


class SxTAuth:
    def __init__(self, settings, redis: RedisClient):
        self.settings = settings
        self.redis = redis

    async def get_access_token(self, force_refresh=False):
        cache_key = "sxt:token"
        token = self.redis.get(cache_key)
        if token and not force_refresh:
            logger.info("SxT token retrieved from Redis cache.", module="SxTAuth")
            return token

        logger.info("Fetching new SxT access token...", module="SxTAuth")

        async def fetch_token():
            try:
                async with httpx.AsyncClient() as client:
                    resp = await client.post(
                        self.settings.SXT_PROXY_URL,
                        headers={"Apikey": self.settings.SXT_API_KEY},
                        data=""  # mimic empty payload
                    )
                if resp.status_code != 200:
                    logger.error(f"Auth failed: {resp.status_code}", module="SxTAuth", body=resp.text)
                    raise SxTAuthError(f"Auth failed: {resp.status_code}")

                data = resp.json()
                auth = AuthResponse(**data)
                print(auth)
                self.redis.set(
                    cache_key,
                    auth.accessToken,
                    ttl=auth.accessTokenExpires,
                )
                logger.info("SxT access token refreshed and stored in Redis.", module="SxTAuth")
                return auth.accessToken

            except httpx.RequestError as e:
                logger.error(f"Request failed: {e}", module="SxTAuth")
                raise SxTAuthError("Request failed") from e
            except Exception as e:
                logger.error(f"Invalid auth response: {e}", module="SxTAuth")
                raise SxTAuthError("Invalid auth response") from e

        try:
            async for attempt in AsyncRetrying(
                stop=stop_after_attempt(3),
                wait=wait_fixed(2),
                retry=retry_if_exception_type((httpx.RequestError, SxTAuthError)),
            ):
                with attempt:
                    return await fetch_token()
        except Exception as e:
            logger.error(f"Failed to obtain SxT access token: {e}", module="SxTAuth")
            raise SxTAuthError("Failed to obtain SxT access token") from e
