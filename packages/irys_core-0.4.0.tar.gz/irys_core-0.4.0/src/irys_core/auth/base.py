# AuthProvider ABC
from datetime import datetime, timedelta, timezone
import jwt  # type: ignore
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from irys_core.config import settings
from irys_core.logging.logging_config import logger
from .auth0 import _decode_auth0_token
import uuid

JWT_SECRET_KEY: str | None = settings.JWT_SECRET_KEY
ALGORITHM = "HS256"
MAX_TOKEN_LIFETIME_HOURS = 24 * 7  # To Be decided based on security policy

def generate_unified_token(
    user_data: dict,
    expires_in: timedelta | int | float = timedelta(hours=1)
) -> dict:
    """
    Generate a unified JWT containing required identity fields.
    Adds 'iat' and 'exp' claims. Capped at MAX_TOKEN_LIFETIME_HOURS.
    Returns:
        {"unified_token": <token>, "irys_User_Id": <id>}
    Raises:
        ValueError on validation issues.
        RuntimeError if secret key is missing.
    """
    logger.info("generate_unified_token called", module="Authentication")

    if not JWT_SECRET_KEY:
        logger.critical("JWT secret key not configured", module="Authentication")
        raise RuntimeError("JWT secret key not configured")

    required = [
        "entity_Reference_Id",
        "entity_Tenant_Id",
        "irys_User_Id",
        "user_Tenant_Id",
        "auth0_Token",
    ]
    
    # Validate required fields (non-empty after stripping)
    missing = [k for k in required if k not in user_data or not str(user_data[k]).strip()]
    if missing:
        raise ValueError(f"Missing or empty fields: {', '.join(missing)}")

    # Verify Auth0 token before proceeding
    auth0_token = user_data.get("auth0_Token", "").strip()
    try:
        auth0_validation = _decode_auth0_token(auth0_token)
        if not auth0_validation.get("valid", False):
            raise ValueError("The Authentication Token provided is invalid. Please try logging in again.")
        logger.info("Auth0 token verified successfully", module="Authentication")
    except HTTPException as e:
        logger.error("Auth0 token validation failed", module="Authentication", error=e.detail)
        raise ValueError("The Authentication Token provided is invalid. Please try logging in again.")
    except Exception as e:
        logger.error("Unexpected error validating Auth0 token", module="Authentication", error=str(e))
        raise ValueError("The Authentication Token provided is invalid. Please try logging in again.")

    # Normalize expires_in
    if isinstance(expires_in, (int, float)):
        expires_in = timedelta(hours=float(expires_in))
    if not isinstance(expires_in, timedelta):
        raise ValueError("Invalid expires_in type; expected timedelta or number (hours).")
    if expires_in.total_seconds() <= 0:
        raise ValueError("Expiration must be positive.")
    max_delta = timedelta(hours=MAX_TOKEN_LIFETIME_HOURS)
    if expires_in > max_delta:
        logger.warning(
            "Expiration capped to max",
            module="Authentication",
            requested_seconds=expires_in.total_seconds(),
            capped_seconds=max_delta.total_seconds(),
        )
        expires_in = max_delta

    now = datetime.now(timezone.utc)
    exp_dt = now + expires_in
    if exp_dt <= now:
        raise ValueError("Expiration must be in the future.")

    # Build payload with only required keys (avoid leaking extraneous data)
    payload = {k: str(user_data[k]).strip() for k in required}
    # Use appropriate types for JWT timestamps
    payload["iat"] = int(now.timestamp())  # type: ignore
    payload["exp"] = int(exp_dt.timestamp())  # type: ignore

    try:
        encoded_jwt = jwt.encode(payload, JWT_SECRET_KEY, algorithm=ALGORITHM)
    except Exception as e:
        logger.error("JWT encoding failed", module="Authentication", error_type=type(e).__name__)
        raise RuntimeError("Token generation failed") from e

    irys_user_id = payload.get("irys_User_Id", "")
    logger.info(
        "Generated unified token",
        module="Authentication",
        irys_user_id=irys_user_id
    )
    return {"unified_token": encoded_jwt, "irys_User_Id": irys_user_id}

class UnifiedTokenRequest(BaseModel):
    entity_Reference_Id: str = Field(min_length=1)
    entity_Tenant_Id: str = Field(min_length=1)
    irys_User_Id: str = Field(min_length=1)
    user_Tenant_Id: str = Field(min_length=1)
    auth0_Token: str = Field(min_length=1)

router = APIRouter()

@router.post("/v2/tenant/set")
def unified_token_endpoint(body: UnifiedTokenRequest):
    request_id = str(uuid.uuid4())
    timestamp = datetime.now(timezone.utc).isoformat()
    
    try:
        result = generate_unified_token(body.model_dump())
        logger.info(
            "Unified token generated successfully",
            module="Authentication",
            irys_user_id=result.get("irys_User_Id", ""),
            request_id=request_id
        )
        return {
            "success": True,
            "statusCode": 200,
            "message": "Unified token generated successfully",
            "data": {
                "accessToken": result["unified_token"]
            },
            "meta": {
                "requestId": request_id,
                "timestamp": timestamp,
                "module": "Authentication",
                "apiCategory": "UnifiedToken"
            }
        }
        
    except ValueError as ve:
        logger.error(
            "Validation error in unified token endpoint",
            module="Authentication",
            request_id=request_id,
            error=str(ve)
        )
        return {
            "success": False,
            "statusCode": 422,
            "message": "Validation error in Authentication Token",
            "error": {
                "code": "VALIDATION_ERROR",
                "fields": {"request": str(ve)}
            },
            "meta": {
                "requestId": request_id,
                "timestamp": timestamp,
                "module": "Authentication",
                "apiCategory": "UnifiedToken"
            }
        }
        
    except RuntimeError as re:
        logger.error(
            "Runtime error in unified token endpoint",
            module="Authentication",
            request_id=request_id,
            error=str(re)
        )
        return {
            "success": False,
            "statusCode": 500,
            "message": "Internal server error",
            "error": {
                "code": "INTERNAL_ERROR"
            },
            "meta": {
                "requestId": request_id,
                "timestamp": timestamp,
                "module": "Authentication",
                "apiCategory": "UnifiedToken"
            }
        }
        
    except Exception as e:
        logger.error(
            "Unexpected error in unified token endpoint",
            module="Authentication",
            request_id=request_id,
            error=str(e)
        )
        return {
            "success": False,
            "statusCode": 500,
            "message": "Unexpected error occurred",
            "error": {
                "code": "UNEXPECTED_ERROR"
            },
            "meta": {
                "requestId": request_id,
                "timestamp": timestamp,
                "module": "Authentication",
                "apiCategory": "UnifiedToken"
            }
        }

# Explicit exports & helper
__all__ = ["router", "generate_unified_token", "UnifiedTokenRequest", "get_auth_router"]

def get_auth_router():
    return router

