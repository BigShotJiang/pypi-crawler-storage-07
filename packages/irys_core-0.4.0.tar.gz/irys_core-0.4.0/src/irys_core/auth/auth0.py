# Auth0/OAuth flows
import requests
from fastapi import HTTPException, status, APIRouter
from fastapi.security import OAuth2PasswordBearer
from jose import jwt as jose_jwt, JWTError
from typing import Dict, Any
from irys_core.logging.logging_config import logger
from irys_core.config import settings
JWT_SECRET_KEY: str | None = settings.JWT_SECRET_KEY
AUTH0_ALGORITHM = "RS256"
UNIFIED_ALGORITHM = "HS256"  

# Handle missing AUTH0 environment variables gracefully
AUTH0_DOMAIN = settings.AUTH0_DOMAIN
API_AUDIENCE = settings.AUTH0_AUDIENCE
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")
jwks_cache: Dict[str, Any] = {}

router = APIRouter()

def get_jwks():
    """
    Fetches the JSON Web Key Set (JWKS) from Auth0 and caches it.
    """
    global jwks_cache
    
    if not AUTH0_DOMAIN:
        logger.error("AUTH0_DOMAIN not configured", module="Authentication")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Auth0 domain not configured"
        )
    
    if not jwks_cache:
        # Construct the well-known URL for JWKS
        jwks_url = f"https://{AUTH0_DOMAIN}/.well-known/jwks.json"
        try:
            jwks_cache = requests.get(jwks_url).json()
        except requests.exceptions.RequestException as e:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail=f"Could not connect to Auth0 to get public keys: {e}"
            )
    return jwks_cache


def _decode_auth0_token(token: str) -> Dict:

    if not token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing bearer token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Check if required Auth0 configuration is available
    if not AUTH0_DOMAIN or not API_AUDIENCE:
        logger.error("Auth0 configuration missing", module="Authentication", 
                    domain_present=bool(AUTH0_DOMAIN), audience_present=bool(API_AUDIENCE))
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Auth0 configuration not available"
        )
    
    try:
        logger.info("Decoding Auth0 token", module="Authentication")
        unverified_header = jose_jwt.get_unverified_header(token)
        kid = unverified_header.get("kid")
        if not kid:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Missing 'kid' in token header",
                headers={"WWW-Authenticate": "Bearer"},
            )

        jwks = get_jwks()
        rsa_key = {}
        for key in jwks.get("keys", []):
            if key.get("kid") == kid:
                rsa_key = {
                    "kty": key.get("kty"),
                    "kid": key.get("kid"),
                    "use": key.get("use"),
                    "n": key.get("n"),
                    "e": key.get("e"),
                }
                break

        if not rsa_key:
            logger.warning("Auth0 JWKS key not found for kid", module="Authentication", kid=kid)
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Unable to find matching key",
                headers={"WWW-Authenticate": "Bearer"},
            )

        auth0_claims = jose_jwt.decode(
            token,
            rsa_key,
            algorithms=[AUTH0_ALGORITHM],
            audience=API_AUDIENCE,
            issuer=f"https://{AUTH0_DOMAIN}/",
        )
        logger.info("Auth0 token validated", module="Authentication", sub=auth0_claims.get("sub"))
        return {"valid": True,}
    except JWTError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Token validation error: {e}",
            headers={"WWW-Authenticate": "Bearer"},
        )








