# Small shared helpers
