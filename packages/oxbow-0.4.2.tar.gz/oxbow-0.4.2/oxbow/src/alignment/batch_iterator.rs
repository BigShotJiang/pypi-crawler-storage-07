mod query;
mod stream;

pub use query::BatchIterator as QueryBatchIterator;
pub use stream::BatchIterator;
