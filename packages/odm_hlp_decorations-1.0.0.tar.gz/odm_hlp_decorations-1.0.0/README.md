# ODM Helper Decorations

[![PyPI version](https://badge.fury.io/py/odm-hlp-decorations.svg)](https://badge.fury.io/py/odm-hlp-decorations)
[![Python](https://img.shields.io/pypi/pyversions/odm-hlp-decorations.svg)](https://pypi.org/project/odm-hlp-decorations/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

A Python library providing decorators for ETL functions with built-in logging and error handling. Designed to simplify error management and logging in data processing workflows.

## Features

- **Task Decorator**: Wraps functions with comprehensive error handling and logging
- **Environment Configuration**: Automatic loading of `.env` files for configuration
- **Flexible Logging**: Configurable logging with automatic log directory creation
- **Error Management**: Choose between exiting on error or re-raising exceptions
- **Security**: Automatic masking of sensitive values in configuration output
- **Minimal Dependencies**: Only requires `python-dotenv` for environment variable handling

## Installation

```bash
pip install odm-hlp-decorations
```

## Quick Start

### Basic Usage

```python
from odm_hlp_decorations import task

@task()
def my_etl_function():
    # Your ETL logic here
    print("Processing data...")
    return "Success"

# Function will automatically handle errors and log them
result = my_etl_function()
```

### Advanced Configuration

```python
from odm_hlp_decorations import task

@task(
    show_config=True,           # Display configuration on first run
    log_filename="etl.log",     # Custom log file name
    env_file=".env.prod",       # Custom environment file
    exit_on_error=False         # Re-raise errors instead of exiting
)
def advanced_etl_function():
    # Your ETL logic here
    pass
```

### Environment Configuration

Create a `.env` file in your project root:

```env
# Database configuration
DB_HOST=localhost
DB_PORT=5432
DB_NAME=mydb
DB_PASSWORD=secret123

# Logging configuration
logs_path=./logs/
```

The decorator will automatically:
- Load these variables
- Create the logs directory if it doesn't exist
- Mask sensitive values (password, secret, key, token) when displaying configuration

## API Reference

### `@task` Decorator

```python
@task(
    show_config: bool = False,
    log_filename: str = "python.log", 
    env_file: str = ".env",
    exit_on_error: bool = True
)
```

**Parameters:**

- `show_config` (bool): Print environment configuration on first function call
- `log_filename` (str): Name of the log file (stored in `logs_path` from config)
- `env_file` (str): Path to the environment variables file
- `exit_on_error` (bool): Whether to exit the program on error (True) or re-raise the exception (False)

### Utility Functions

```python
from odm_hlp_decorations import load_config, setup_logging

# Load configuration manually
config = load_config(".env")

# Setup logging manually
setup_logging(config, "custom.log")
```

## Log Format

Logs are written in the following format:
```
2024-01-15 10:30:45,123 | ERROR | script.py:module:function_name | Error message
```

## Error Handling

The decorator provides two error handling modes:

1. **Exit on Error** (default): Logs the error and exits the program with code 1
2. **Re-raise**: Logs the error and re-raises the original exception

## Use Cases

- **ETL Pipelines**: Wrap data processing functions for automatic error handling
- **Data Scripts**: Add logging and error management to data analysis scripts  
- **Automation**: Ensure scripts fail gracefully with proper logging
- **Development**: Quick debugging with automatic configuration display

## Requirements

- Python 3.8+
- python-dotenv (automatically installed)

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Changelog

### 1.0.0
- First stable release
- Task decorator with logging and error handling
- Environment configuration loading
- Automatic log directory creation
- Sensitive value masking

## Suggestions for a good README
Every project is different, so consider which of these sections apply to yours. The sections used in the template are suggestions for most open source projects. Also keep in mind that while a README can be too long and detailed, too long is better than too short. If you think your README is too long, consider utilizing another form of documentation rather than cutting out information.

## Name
Choose a self-explaining name for your project.

## Description
Let people know what your project can do specifically. Provide context and add a link to any reference visitors might be unfamiliar with. A list of Features or a Background subsection can also be added here. If there are alternatives to your project, this is a good place to list differentiating factors.

## Badges
On some READMEs, you may see small images that convey metadata, such as whether or not all the tests are passing for the project. You can use Shields to add some to your README. Many services also have instructions for adding a badge.

## Visuals
Depending on what you are making, it can be a good idea to include screenshots or even a video (you'll frequently see GIFs rather than actual videos). Tools like ttygif can help, but check out Asciinema for a more sophisticated method.

## Installation
Within a particular ecosystem, there may be a common way of installing things, such as using Yarn, NuGet, or Homebrew. However, consider the possibility that whoever is reading your README is a novice and would like more guidance. Listing specific steps helps remove ambiguity and gets people to using your project as quickly as possible. If it only runs in a specific context like a particular programming language version or operating system or has dependencies that have to be installed manually, also add a Requirements subsection.

## Usage
Use examples liberally, and show the expected output if you can. It's helpful to have inline the smallest example of usage that you can demonstrate, while providing links to more sophisticated examples if they are too long to reasonably include in the README.

## Support
Tell people where they can go to for help. It can be any combination of an issue tracker, a chat room, an email address, etc.

## Roadmap
If you have ideas for releases in the future, it is a good idea to list them in the README.

## Contributing
State if you are open to contributions and what your requirements are for accepting them.

For people who want to make changes to your project, it's helpful to have some documentation on how to get started. Perhaps there is a script that they should run or some environment variables that they need to set. Make these steps explicit. These instructions could also be useful to your future self.

You can also document commands to lint the code or run tests. These steps help to ensure high code quality and reduce the likelihood that the changes inadvertently break something. Having instructions for running tests is especially helpful if it requires external setup, such as starting a Selenium server for testing in a browser.

## Authors and acknowledgment
Show your appreciation to those who have contributed to the project.

## License
For open source projects, say how it is licensed.

## Project status
If you have run out of energy or time for your project, put a note at the top of the README saying that development has slowed down or stopped completely. Someone may choose to fork your project or volunteer to step in as a maintainer or owner, allowing your project to keep going. You can also make an explicit request for maintainers.
