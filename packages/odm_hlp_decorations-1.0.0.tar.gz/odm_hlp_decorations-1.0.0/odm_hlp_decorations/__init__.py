"""
ODM Helper Decorations

Decorators for ETL functions with logging and error handling.
"""

import os
import logging
import sys
from functools import wraps
from typing import Callable, Optional, Dict, Any

try:
    from dotenv import dotenv_values
except ImportError:
    # Fallback if dotenv is not installed
    def dotenv_values(path: str) -> Dict[str, str]:
        return {}

__version__ = "1.0.0"
__author__ = "Marc Monteys"

def load_config(env_file: str = ".env") -> Dict[str, str]:
    """
    Load configuration from .env file
    
    Args:
        env_file: Path to the .env file (default: ".env")
    
    Returns:
        Dictionary with environment variables
    """
    if os.path.exists(env_file):
        return dotenv_values(env_file)
    return {}

def setup_logging(config: Dict[str, str], log_filename: str = "python.log") -> None:
    """
    Setup logging configuration
    
    Args:
        config: Configuration dictionary
        log_filename: Name of the log file
    """
    logs_path = config.get('logs_path', './logs/')
    
    # Create logs directory if it doesn't exist
    os.makedirs(logs_path, exist_ok=True)
    
    log_format = "%(asctime)s | %(levelname)s | %(message)s"
    log_file = os.path.join(logs_path, log_filename)
    
    logging.basicConfig(
        filename=log_file,
        encoding='utf-8',
        format=log_format,
        level=logging.WARNING,
        filemode='a'
    )

def task(
    show_config: bool = False, 
    log_filename: str = "python.log",
    env_file: str = ".env",
    exit_on_error: bool = True
):
    """
    Decorator for ETL tasks with logging and error handling
    
    Args:
        show_config: Whether to print configuration on first use
        log_filename: Name of the log file
        env_file: Path to the .env file
        exit_on_error: Whether to exit on error (True) or re-raise (False)
    
    Returns:
        Decorated function with error handling and logging
    """
    def decorator(func: Callable):
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                # Load config only once per function
                if not hasattr(wrapper, '_config_loaded'):
                    config = load_config(env_file)
                    setup_logging(config, log_filename)
                    
                    if show_config:
                        print(f"\nProject path: {os.getcwd()}")
                        print(f"Current path: {os.path.dirname(__file__)}")
                        print("\nEnvironment variables:")
                        for key, value in config.items():
                            # Mask sensitive values
                            display_value = "***" if any(
                                sensitive in key.lower() 
                                for sensitive in ['password', 'secret', 'key', 'token']
                            ) else value
                            print(f"{key}={display_value}")
                    
                    wrapper._config_loaded = True
                
                # Execute the function
                result = func(*args, **kwargs)
                return result
                
            except Exception as e:
                # Get error information
                exc_type, exc_obj, exc_tb = sys.exc_info()
                file_origin = os.path.basename(sys.argv[0]) if sys.argv else "unknown"
                
                # Log the error
                error_msg = f"{file_origin}:{func.__module__}:{func.__name__} | {e}"
                logging.error(error_msg)
                
                # Print error for immediate feedback
                print(f"ERROR in {func.__name__}: {e}")
                
                if exit_on_error:
                    sys.exit(1)
                else:
                    raise e
        
        return wrapper
    return decorator

# Export main functions
__all__ = ["task", "load_config", "setup_logging"]

