# Changelog

```{changelog}
:changelog-url: https://github.com/scientific-python/repo-review/releases
:github: https://github.com/scientific-python/repo-review/releases
:pypi: https://pypi.org/project/repo-review
```
