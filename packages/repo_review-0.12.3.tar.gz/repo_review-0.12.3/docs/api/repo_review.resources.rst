repo\_review.resources package
==============================

.. automodule:: repo_review.resources
   :members:
   :show-inheritance:
   :undoc-members:
