# heimdall-decompiler

Decompiles EVM bytecode to human-readable representations
