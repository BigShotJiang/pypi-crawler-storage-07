from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.utils import AnalysisException

from abc import ABC, abstractmethod

from amigo.configuracoes import ConfigManager

import importlib.resources as pkg_resources
import amigo

class SparkBaseSession(ABC):
    """Classe base para gerenciar a SparkSession."""

    def __init__(self, app_name="DefaultSparkApp", master="local[*]"):        

        self.app_name = app_name
        self.master = master
        self.spark = self._create_session()

    def _create_session(self):
        """Cria a SparkSession."""
        print(f"Iniciando a sessão spark default {self.app_name}!")

        jar_paths = [
            str(pkg_resources.files(amigo).joinpath("jars/kafka/kafka-clients-3.5.1.jar")),
            str(pkg_resources.files(amigo).joinpath("jars/kafka/spark-sql-kafka-0-10_2.12-3.5.1.jar")),
            str(pkg_resources.files(amigo).joinpath("jars/kafka/spark-token-provider-kafka-0-10_2.12-3.5.1.jar")),
            str(pkg_resources.files(amigo).joinpath("jars/kafka/commons-pool2-2.12.0.jar")),
            str(pkg_resources.files(amigo).joinpath("jars/postgres/postgresql-42.7.7.jar")),
        ]

        jars_for_spark = ",".join(jar_paths)

        return (
            SparkSession.builder
            .appName(self.app_name)
            .master(self.master)            
            .config("spark.jars", jars_for_spark)
            .getOrCreate()
        )

    def stop(self):
        """Encerra a sessão."""
        print ("Encerrando a sessão Spark!")
        self.spark.stop()
    

    def save_dataframe(self, df, path, format="parquet", mode="overwrite"):
        """Salva um DataFrame em um arquivo."""
        print(f"Salvando DataFrame no formato {format} em {path}")
        df.write.format(format).mode(mode).save(path)

    @abstractmethod
    def write(self):
        pass
    def read(self):
        pass

    def get_config(self, arquivo_config, bloco):
        return ConfigManager(arquivo_config).get_block(bloco)
    
    def filter_dataframe(self, df, condition : str):
        """Aplica um filtro a um DataFrame."""
        return df.filter(condition)

class PostgresSparkSession(SparkBaseSession):
    """Extensão da sessão Spark para Postgres."""

    def __init__(self, app_name="PostgresApp", master="local[*]", arquivo_config=None, bloco="postgres"):
        super().__init__(app_name, master)

        self.cfg = self.get_config(arquivo_config, bloco)

        self.jdbc_url = self.cfg.get("jdbc_url")
        self.user = self.cfg.get("user")
        self.password = self.cfg.get("password")


    def read_table(self, table):
        """Lê uma tabela do Postgres via JDBC."""
        print(f"Executando a query na tabela {table} no Postgres")
        return (
            self.spark.read
            .format("jdbc")
            .option("url", self.jdbc_url)
            .option("dbtable", table)
            .option("user", self.user)
            .option("password", self.password)
            .option("driver", "org.postgresql.Driver")
            .load()
        )

    def read(self, base_query: str, params: dict = None):
        """
        Lê dados do Postgres via JDBC usando uma query parametrizada.

        :param base_query: string da query com placeholders {param_name}
        :param params: dict com valores para substituir os placeholders
        """
        print("Executando a query no Postgres")
        if params:
            # Substitui os placeholders de forma segura (certifique-se de validar os valores!)
            query = base_query.format(**params)
        else:
            query = base_query

        # Spark exige alias para subquery
        dbtable = f"({query}) as subquery"

        return (
            self.spark.read
            .format("jdbc")
            .option("url", self.jdbc_url)
            .option("dbtable", dbtable)
            .option("user", self.user)
            .option("password", self.password)
            .option("driver", "org.postgresql.Driver")
            .load()
        )
   
    def write(self, df, table_name: str, mode: str = "append"):
        print(f"Começando a escrever no Postgres na tabela: {table_name}")
        # Função interna para escrever cada batch
        def write_batch(batch_df, batch_id):
            batch_df.write \
                .format("jdbc") \
                .option("dbtable", table_name) \
                .option("url", self.jdbc_url) \
                .option("user", self.user) \
                .option("password", self.password) \
                .option("driver", "org.postgresql.Driver") \
                .mode(mode) \
                .save()
        
        # Detecta se é streaming
        if df.isStreaming:
            df.writeStream \
                .foreachBatch(write_batch) \
                .outputMode("append") \
                .start() \
                .awaitTermination()
        else:
            df.write \
                .format("jdbc") \
                .option("dbtable", table_name) \
                .option("url", self.jdbc_url) \
                .option("user", self.user) \
                .option("password", self.password) \
                .option("driver", "org.postgresql.Driver") \
                .mode(mode) \
                .save()
        print(f"Escrita do Postgres na tabela: {table_name} finalizada")    

class MongoSparkSession(SparkBaseSession):
    """Extensão da sessão Spark para MongoDB."""

    def __init__(self, app_name="MongoApp", master="local[*]",  arquivo_config=None, bloco="mongodb"):    

        self.app_name = app_name
        self.master = master

        self.cfg = self.get_config(arquivo_config, bloco)

        self.mongo_uri = self.cfg.get("mongo_uri")
        self.database = self.cfg.get("database")
        self.collection = self.cfg.get("collection")

        # adiciona configs específicas do Mongo
        print(f"Iniciando a sessão spark do {self.app_name}")
        
        jar_paths = [
            str(pkg_resources.files(amigo).joinpath("jars/kafka/kafka-clients-3.5.1.jar")),
            str(pkg_resources.files(amigo).joinpath("jars/kafka/spark-sql-kafka-0-10_2.12-3.5.1.jar")),
            str(pkg_resources.files(amigo).joinpath("jars/kafka/spark-token-provider-kafka-0-10_2.12-3.5.1.jar")),
            str(pkg_resources.files(amigo).joinpath("jars/kafka/commons-pool2-2.12.0.jar")),
            str(pkg_resources.files(amigo).joinpath("jars/postgres/postgresql-42.7.7.jar")),
            str(pkg_resources.files(amigo).joinpath("jars/mongodb/mongo-spark-connector_2.12-10.5.0.jar")),
            str(pkg_resources.files(amigo).joinpath("jars/mongodb/mongodb-driver-sync-5.1.4.jar")),
            str(pkg_resources.files(amigo).joinpath("jars/mongodb/mongodb-driver-core-5.1.4.jar")),
            str(pkg_resources.files(amigo).joinpath("jars/mongodb/bson-5.1.4.jar")),
            str(pkg_resources.files(amigo).joinpath("jars/mongodb/bson-record-codec-5.1.4.jar")),
        ]

        jars_for_spark = ",".join(jar_paths)

        self.spark = (
            SparkSession.builder
            .appName(self.app_name)
            .master(self.master)
            .config("spark.mongodb.read.connection.uri", self.mongo_uri)
            .config("spark.mongodb.write.connection.uri", self.mongo_uri)
            .config("spark.jars", jars_for_spark)
            .getOrCreate()
        )

    def read(self):
        """Lê uma coleção do MongoDB."""
        print(f"Lendo a colleção {self.collection}")
        return (
            self.spark.read
            .format("mongodb")
            .option("database", self.database)
            .option("collection", self.collection)
            .load()
        )

    def write(self, df, mode="append"):
        """Escreve um DataFrame em uma coleção do MongoDB."""
        print(f"Escrevendo na colleção {self.collection}")
        (
            df.write
            .format("mongodb")
            .mode(mode)
            .option("database", self.database)
            .option("collection", self.collection)
            .save()
        )
        print(f"Escrita na colleção {self.collection} concluída")
        
class KafkaSparkSession(SparkBaseSession):
    """Extensão da sessão Spark para Kafka."""

    def __init__(self, app_name="KafkaApp", master="local[*]", arquivo_config=None, bloco="kafka"):
        super().__init__(app_name, master)        

        self.cfg = self.get_config(arquivo_config, bloco)
        self.bootstrap_servers = self.cfg.get("bootstrap_servers")
        self.schema_registry = self.cfg.get("schema_registry")
        self.checkpoint_location = self.cfg.get("checkpoint_location")

    def set_value_topic(self, topic):
        """
        Lê uma amostra do tópico Kafka, infere o schema do JSON e retorna um StructType.        
        """
        print(f"Trabalhando no schema do tópico {topic}")
        try:
            # Lê apenas uma mensagem do tópico
            df = self._read(topic).limit(1).selectExpr("CAST(value AS STRING) as value")
            
            # Verifica se há dados
            first_row = df.head(1)
            if not first_row:
                raise ValueError(f"O tópico '{topic}' está vazio ou não retornou mensagens.")

            sample_json = first_row[0]["value"]
            if not sample_json:
                raise ValueError(f"A primeira mensagem do tópico '{topic}' está vazia.")

            # Cria um DataFrame temporário para inferir o schema
            sample_df = self.spark.read.json(self.spark.sparkContext.parallelize([sample_json]))

            return sample_df.schema

        except AnalysisException as e:
            raise RuntimeError(f"Erro ao ler o tópico '{topic}': {e}")
        except Exception as e:
            raise RuntimeError(f"Falha ao inferir o schema do tópico '{topic}': {e}")
        
        print(f"Schema do tópico {topic} definido")

    def _read(self, topic, starting_offsets="earliest"):
        """Lê mensagens de um tópico Kafka."""
        return (
            self.spark.read
            .format("kafka")
            .option("kafka.bootstrap.servers", self.bootstrap_servers)
            .option("subscribe", topic)
            .option("startingOffsets", starting_offsets)
            .load()
        )

    def read(self, topic, starting_offsets="earliest", read_type=None):
        """Lê mensagens de um tópico Kafka."""
        if (read_type):
            """Lê mensagens de um tópico Kafka como stream."""
            print(f"Lendo o tópico {topic} em streaming")
            df = (self.spark.readStream
                .format("kafka")
                .option("kafka.bootstrap.servers", self.bootstrap_servers)
                .option("subscribe", topic)
                .option("startingOffsets", starting_offsets)
                .load())
        else :
            print(f"Lendo o tópico {topic} em bath")
            df = self._read(topic, starting_offsets)
        
        return self.return_values(df, topic) 

    def write(self, df, topic, mode="append"):        
        """Escreve mensagens em um tópico Kafka."""
        if df.isStreaming:
            print(f"Escrevendo no tópico {topic} em streaming")
            (
                df.writeStream
                .format("kafka")
                .option("kafka.bootstrap.servers", self.bootstrap_servers)
                .option("topic", topic)
                .option("checkpointLocation", self.checkpoint_location)
                .outputMode(mode)
            )  
        else:
            print(f"Escrevendo no tópico {topic} em bath")
            df = df.withColumn("value", F.to_json(F.struct([F.col(c) for c in df.columns])))
            (
                df.write
                .format("kafka")
                .option("kafka.bootstrap.servers", self.bootstrap_servers)
                .option("topic", topic)
                .mode(mode)
                .save()
            )

    def return_values(self, df, topic):
        print(f"Transformando dados do values quebrados por coluna no tópico {topic}")
        df = df.selectExpr("CAST(value AS STRING)").withColumn("json_data", F.from_json(F.col("value"), self.set_value_topic(topic))).drop("value")
        return df.select("json_data.*")

    def read_stream(self, topic, starting_offsets="latest"):
        """Lê mensagens de um tópico Kafka como stream."""
        print(f"Lendo o tópico {topic} em streaming")
        df = (self.spark.readStream
            .format("kafka")
            .option("kafka.bootstrap.servers", self.bootstrap_servers)
            .option("subscribe", topic)
            .option("startingOffsets", starting_offsets)
            .load())
        return self.return_values(df, topic)      
    
    def await_termination(self, df = None):
        return df.writeStream \
            .format("console") \
            .start() \
            .awaitTermination() 