# config_manager.py
import configparser

class ConfigManager:
    def __init__(self, file_path: str):
        """
        Inicializa o ConfigManager lendo o arquivo INI.
        """
        self.config = configparser.ConfigParser()
        self.config.read(file_path, encoding="utf-8")

    def get_block(self, block_name: str) -> dict:
        """
        Retorna todas as chaves/valores de um bloco específico.
        """
        if block_name in self.config:
            return dict(self.config[block_name])
        else:
            raise ValueError(f"Bloco '{block_name}' não encontrado no arquivo de configuração.")

    def get_field(self, field_name: str) -> dict:
        """
        Busca o valor de um campo específico em todos os blocos.
        Retorna um dicionário {bloco: valor}.
        """
        result = {}
        for section in self.config.sections():
            if field_name in self.config[section]:
                result[section] = self.config[section][field_name]
        return result
