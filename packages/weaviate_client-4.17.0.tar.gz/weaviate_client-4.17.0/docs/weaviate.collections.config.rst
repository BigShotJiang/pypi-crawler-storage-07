weaviate.collections.config
===========================

.. automodule:: weaviate.collections.config
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

.. weaviate.collections.config.config
.. ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. .. automodule:: weaviate.collections.config.config
..    :members:
..    :undoc-members:
..    :show-inheritance:
..    :private-members:

.. weaviate.collections.config.sync
.. ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. .. automodule:: weaviate.collections.config.sync
..    :members:
..    :undoc-members:
..    :show-inheritance:
..    :private-members:
