weaviate.collections.queries.near\_vector
=========================================

.. automodule:: weaviate.collections.queries.near_vector
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

.. weaviate.collections.queries.near\_vector.generate module
.. ---------------------------------------------------------

.. .. automodule:: weaviate.collections.queries.near_vector.generate
..    :members:
..    :undoc-members:
..    :show-inheritance:
..    :private-members:

.. weaviate.collections.queries.near\_vector.query module
.. ------------------------------------------------------

.. .. automodule:: weaviate.collections.queries.near_vector.query
..    :members:
..    :undoc-members:
..    :show-inheritance:
..    :private-members:
