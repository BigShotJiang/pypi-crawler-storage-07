class DomainError(Exception):
    pass
