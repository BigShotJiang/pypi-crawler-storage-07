# -*- coding: utf-8 -*-

from .caster import clouddirectory_caster

caster = clouddirectory_caster

__version__ = "1.40.0"