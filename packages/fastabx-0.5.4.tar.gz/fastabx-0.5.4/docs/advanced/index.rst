========
Advanced
========

.. toctree::

	comparison
	slicing
