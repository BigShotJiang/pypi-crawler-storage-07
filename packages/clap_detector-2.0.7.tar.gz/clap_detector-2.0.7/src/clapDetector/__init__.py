from .clapDetector import ClapDetector
from .clapDetector import getDefaultMicrophone
from .clapDetector import printDeviceInfo