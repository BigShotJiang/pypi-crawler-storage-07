# MetricType


## Enum

* `QUERYRELEVANCE` (value: `'QueryRelevance'`)

* `RESPONSERELEVANCE` (value: `'ResponseRelevance'`)

* `TOOLSELECTION` (value: `'ToolSelection'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


