# -*- coding: utf-8 -*-

from .caster import pinpoint_sms_voice_caster

caster = pinpoint_sms_voice_caster

__version__ = "1.40.0"