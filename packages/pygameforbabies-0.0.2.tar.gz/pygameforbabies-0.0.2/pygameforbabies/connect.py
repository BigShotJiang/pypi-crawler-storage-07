def _defaultfunc(arg = None):
    pass
onupdate = _defaultfunc
onkeypress = _defaultfunc
onkeydown = _defaultfunc
onmouseclicked = _defaultfunc
onmousedown = _defaultfunc
onmousemove = _defaultfunc