from setuptools import setup, find_packages

setup(
    name="modulem",
    version="0.0",
    author="Zaheen Iqbal Khan",
    author_email="zaheen6iqbal@gmail.com",
    description="This is just a Test package",
    packages=find_packages(),
    python_requires=">=3.6",
    entry_point={
        "console_script":[
            "zaheen6iqbal@gmail.com"
            
            ],
        
        
        },

    )