# print loop

def ploop(x,y,z):
    
    pl = [a for a in range(x,y,z)]
    return pl