mp.register_event("file-loaded", function()
    mp.set_property("pause", "no")
end)