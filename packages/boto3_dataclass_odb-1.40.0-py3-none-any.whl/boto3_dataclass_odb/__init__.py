# -*- coding: utf-8 -*-

from .caster import odb_caster

caster = odb_caster

__version__ = "1.40.0"