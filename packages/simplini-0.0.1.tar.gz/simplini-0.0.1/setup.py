import os
from setuptools import find_packages, setup

setup(
    name="simplini",
    version=os.environ.get("PACKAGE_VERSION", "0.0.1"),
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    install_requires=[],
    python_requires=">=3.10",
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "ruff>=0.1.0",
        ],
    },
    author="Eugene Gubenkov",
    author_email="gubenkoved@gmail.com",
    description="A simple INI file parser/writer",
    long_description=open("README.md").read() if open("README.md") else "",
    long_description_content_type="text/markdown",
    keywords="ini, config, parser",
    url="https://github.com/gubenkoved/simplini",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
)
