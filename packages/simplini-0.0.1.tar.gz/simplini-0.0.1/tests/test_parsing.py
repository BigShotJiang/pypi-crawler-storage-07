import logging
import os

from simplini import IniConfig, ParsingError
from tests.common import CaseBase

LOGGER = logging.getLogger(__name__)

CUR_DIR = os.path.dirname(os.path.abspath(__file__))
FIXTURES_DIR = os.path.join(CUR_DIR, "fixtures")


class ParsingTestCases(CaseBase):
    def test_load_sample_config(self):
        fixture_path = os.path.join(FIXTURES_DIR, "sample.ini")

        config = IniConfig.load(fixture_path)

        self.assertEqual("value", config.default_section["val1"].value)
        self.assertEqual("value with spaces", config.default_section["val2"].value)
        self.assertEqual('value with "quotes"', config.default_section["val3"].value)
        self.assertEqual(
            "value with 'single quotes'", config.default_section["val4"].value
        )
        self.assertEqual("multiline\nvalue", config.default_section["val5"].value)

        # check comments
        self.assertEqual(["comment for value1"], config.default_section["val1"].comment)
        self.assertEqual(
            "inline comment for value1",
            config.default_section["val1"].inline_comment,
        )
        self.assertEqual(["comment for value2"], config.default_section["val2"].comment)
        self.assertEqual(["comment for value3"], config.default_section["val3"].comment)
        self.assertEqual([], config.default_section["val4"].comment)
        self.assertEqual(["comment for value5"], config.default_section["val5"].comment)

    def test_unquoted_values(self):
        fixture_path = os.path.join(FIXTURES_DIR, "unquoted-value.ini")

        config = IniConfig.load(fixture_path)

        self.assertEqual("sample", config.default_section["value1"].value)
        self.assertEqual(
            "sample with leading and trailing spaces",
            config.default_section["value2"].value,
        )
        self.assertEqual("", config.default_section["value3"].value)

        self.assertEqual("value", config.default_section["value4"].value)
        self.assertEqual(
            "inline comment", config.default_section["value4"].inline_comment
        )

    def test_comment_only_file(self):
        fixture_path = os.path.join(FIXTURES_DIR, "comment-only.ini")

        config = IniConfig.load(fixture_path)

        self.assertEqual(0, len(config.default_section.options))
        self.assertEqual(0, len(config.sections))

        self.assertEqual(
            ["this is just a comment", "and nothing else"],
            config.default_section.comment,
        )

    def test_new_lines_inside_comments(self):
        fixture_path = os.path.join(FIXTURES_DIR, "comments-with-new-lines.ini")

        config = IniConfig.load(fixture_path)

        self.assertEqual(
            [
                "value comment",
                "with new lines in between",
                "and even more lines in between",
            ],
            config.default_section["value"].comment,
        )

        self.assertEqual(
            [
                "section comment",
                "can also have new lines in between",
            ],
            config.sections["foo"].comment,
        )

    def test_multiline_values(self):
        fixture_path = os.path.join(FIXTURES_DIR, "multiline-values.ini")

        config = IniConfig.load(fixture_path)

        foo_section = config.sections["foo"]
        self.assertEqual(
            "this is\na multiline\nvalue",
            foo_section["value"].value,
        )


class InvalidConfigParsingCases(CaseBase):
    def test_not_closed_literal(self):
        fixture_path = os.path.join(FIXTURES_DIR, "invalid-not-closed-literal.ini")

        self.assertRaises(
            ParsingError,
            lambda: IniConfig.load(fixture_path),
        )

    def test_not_closed_section(self):
        fixture_path = os.path.join(FIXTURES_DIR, "invalid-not-closed-section.ini")

        self.assertRaises(
            ParsingError,
            lambda: IniConfig.load(fixture_path),
        )
