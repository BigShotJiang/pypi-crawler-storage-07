# -*- coding: utf-8 -*-
"""Penney modules."""
from .params import PENNEY_VERSION
__version__ = PENNEY_VERSION
