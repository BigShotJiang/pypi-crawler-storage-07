class RemoteDeviceAllocationError(Exception):
    """Exception raised when there is an error allocating a remote device."""

    pass
