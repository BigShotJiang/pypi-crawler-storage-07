from __future__ import annotations
import os
from typing import Protocol, runtime_checkable

# Import OpenAI lazily to avoid hard dependency if user supplies custom client
try:  # pragma: no cover - optional dependency
    import openai  # type: ignore
    from openai import OpenAI  # type: ignore
except Exception:  # pragma: no cover - absence is acceptable
    openai = None  # type: ignore
    OpenAI = None  # type: ignore


@runtime_checkable
class LLMClientProtocol(Protocol):
    """Protocol for pluggable LLM clients.

    A custom client only needs to implement generate_function_body(prompt)->str returning
    raw Python function *body* text (no def line). Implementations may raise exceptions
    which will propagate to the evolver retry logic.
    """

    def generate_function_body(
        self, prompt: str
    ) -> str:  # pragma: no cover - interface only
        ...


class OpenAILLMClient:
    """Default OpenAI-backed generator implementing LLMClientProtocol.

    Kept separate so users can supply their own client without importing openai.
    """

    def __init__(self, *, model: str | None = None, temperature: float = 0.0):
        if OpenAI is None:  # pragma: no cover - runtime safeguard
            raise RuntimeError(
                "openai package not available. Install openai or provide a custom LLM client."
            )
        self.model = model or os.getenv("EVOLVERX_OPENAI_MODEL", "gpt-5")
        self.temperature = float(os.getenv("EVOLVERX_TEMPERATURE", str(temperature)))
        self._client = OpenAI()

    def generate_function_body(self, prompt: str) -> str:
        print(f"LLM involved. The prompt is:\n{prompt}\n---")
        system = (
            "You write minimal, deterministic Python function BODIES only. "
            "Return raw code text without fences, without leading 'def'. "
        )

        request_args = {
            "model": self.model,
            "input": [
                {"role": "system", "content": system},
                {"role": "user", "content": prompt},
            ],
        }

        resp = None
        try:
            resp = self._client.responses.create(
                **{**request_args, "temperature": self.temperature}
            )
        except Exception as e:
            if openai is not None and (
                isinstance(e, openai.BadRequestError)
                or "Unsupported parameter: 'temperature'" in str(e)
            ):
                resp = self._client.responses.create(**request_args)
            else:
                raise

        try:
            out = resp.output[0].content[0].text  # type: ignore[attr-defined]
        except Exception:
            try:
                out = resp.output_text  # type: ignore[attr-defined]
            except Exception:
                out = str(resp)

        out = out.strip()
        if out.startswith("```"):
            out = out.strip("`\n")
            if out.startswith("python\n"):
                out = out[len("python\n") :]
        result = out.strip() + ("\n" if not out.endswith("\n") else "")
        print(f"LLM produced function body:\n{result}")
        return result


# Backwards compatibility: expose name LLMClient referencing default implementation
LLMClient = OpenAILLMClient

__all__ = [
    "LLMClientProtocol",
    "OpenAILLMClient",
    "LLMClient",  # backward compat
]
