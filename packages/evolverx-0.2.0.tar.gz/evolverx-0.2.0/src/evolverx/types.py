from __future__ import annotations
from dataclasses import dataclass
from typing import Sequence, Callable, Protocol

try:  # Local import guard to avoid circular import at runtime
    from .llm import LLMClientProtocol  # type: ignore
except Exception:  # pragma: no cover - during type checking or circular

    class LLMClientProtocol(Protocol):  # type: ignore
        def generate_function_body(self, prompt: str) -> str: ...


@dataclass
class EvolverxConfig:
    persist_mode: str = "cache"  # "cache" | "source" (source TODO)
    allow_imports: tuple[str, ...] = (
        "json",
        "re",
        "math",
        "datetime",
        "typing",
        "time",
        "requests",
    )
    max_body_lines: int = 200
    auto_resynthesize_on_any_error: bool = True
    cache_dir: str | None = None  # default resolved at runtime
    network_allowlist: Sequence[str] | None = None  # e.g., ["api.example.com"]
    timeout_seconds: float = 10.0  # sandbox exec timeout
    max_attempts: int = 3  # max evolution attempts per function
    # Optional: provide a concrete LLM client implementing LLMClientProtocol
    llm_client: LLMClientProtocol | None = None
    # Or, provide a factory callable returning a fresh client when decorator applied
    llm_factory: Callable[[], LLMClientProtocol] | None = None

    def resolve_llm(self) -> LLMClientProtocol:
        """Return an LLM client instance following precedence:
        1. Explicit llm_client if supplied
        2. llm_factory() if supplied
        3. Default OpenAI client
        """
        if self.llm_client is not None:
            return self.llm_client
        if self.llm_factory is not None:
            return self.llm_factory()
        # Lazy import to avoid dependency if not needed
        from .llm import OpenAILLMClient

        return OpenAILLMClient()
