import base64
from datetime import datetime
from typing import ClassVar, Literal, Self

from fastmcp.utilities.logging import get_logger
from githubkit.versions.v2022_11_28.models import CodeSearchResultItem as GitHubKitCodeSearchResultItem
from githubkit.versions.v2022_11_28.models import (
    ContentFile as GitHubKitContentFile,
)
from githubkit.versions.v2022_11_28.models import DiffEntry as GitHubKitDiffEntry
from githubkit.versions.v2022_11_28.models import (
    FullRepository as GitHubKitFullRepository,
)
from githubkit.versions.v2022_11_28.models import (
    GitRef as GitHubKitGitRef,
)
from githubkit.versions.v2022_11_28.models import (
    LicenseSimple as GitHubKitLicenseSimple,
)
from pydantic import BaseModel, ConfigDict, Field, RootModel

logger = get_logger(__name__)

DEFAULT_TRUNCATE_CONTENT_LINES = 500
DEFAULT_TRUNCATE_CONTENT_CHARACTERS = 20000

DEFAULT_README_TRUNCATE_CONTENT_LINES = 2000
DEFAULT_README_TRUNCATE_CONTENT_CHARACTERS = 60000


class FileLines(RootModel[dict[int, str]]):
    """A dictionary of line numbers and content pairs."""

    @classmethod
    def from_text(cls, text: str) -> Self:
        text_lines = text.split("\n")

        file_lines = {i + 1: line for i, line in enumerate(text_lines)}

        return cls(root=file_lines)

    def truncate(self, truncate_lines: int, truncate_characters: int) -> Self:
        total_characters: int = 0
        new_lines: dict[int, str] = {}

        for line_number, line in self.root.items():
            if line_number > truncate_lines:
                break

            total_characters += len(line)
            if total_characters > truncate_characters:
                break

            new_lines[line_number] = line

        return self.model_copy(update={"root": new_lines})


class RepositoryLicense(BaseModel):
    """A repository license."""

    name: str = Field(description="The name of the license.")
    url: str | None = Field(description="The URL of the license.")

    @classmethod
    def from_license_simple(cls, license_simple: GitHubKitLicenseSimple) -> Self:
        return cls(name=license_simple.name, url=license_simple.url)


def try_decode_base64_utf8(content: bytes) -> str | None:
    try:
        return content.decode("utf-8")
    except Exception:
        return None


class Repository(BaseModel):
    """A repository."""

    model_config: ClassVar[ConfigDict] = ConfigDict(extra="forbid", frozen=True)

    name: str = Field(description="The name of the repository.")
    description: str | None = Field(description="The description of the repository.")
    fork: bool = Field(description="Whether the repository is a fork.")
    url: str = Field(description="The URL of the repository.")
    stars: int = Field(description="The number of stars the repository has.")
    homepage_url: str | None = Field(description="The homepage URL of the repository.")
    language: str | None = Field(description="The language of the repository.")
    default_branch: str = Field(description="The default branch of the repository.")
    topics: list[str] = Field(
        description="The topics of the repository.",
    )
    archived: bool = Field(description="Whether the repository is archived.")
    created_at: datetime = Field(description="The date and time the repository was created.")
    updated_at: datetime = Field(description="The date and time the repository was updated.")
    pushed_at: datetime = Field(description="The date and time the repository was pushed to.")
    license: RepositoryLicense | None = Field(description="The license information of the repository.")

    @classmethod
    def from_full_repository(cls, full_repository: GitHubKitFullRepository) -> Self:
        repository_license = (
            RepositoryLicense.from_license_simple(license_simple=full_repository.license_) if full_repository.license_ else None
        )
        return cls(
            name=full_repository.name,
            description=full_repository.description,
            fork=full_repository.fork,
            url=full_repository.url,
            stars=full_repository.stargazers_count,
            homepage_url=full_repository.homepage,
            language=full_repository.language,
            default_branch=full_repository.default_branch,
            topics=full_repository.topics or [],
            archived=full_repository.archived,
            created_at=full_repository.created_at,
            updated_at=full_repository.updated_at,
            pushed_at=full_repository.pushed_at,
            license=repository_license,
        )


class RepositoryFileWithContent(BaseModel):
    """A file with its path and content."""

    path: str = Field(description="The path of the file.")
    encoding: str = Field(description="The encoding of the file.")
    content: FileLines | None = Field(description="The content of the file.")
    total_lines: int | None = Field(description="The total number of lines in the file.")
    truncated: bool = Field(default=False, description="Whether the content has been truncated.")

    @classmethod
    def from_content_file(
        cls,
        content_file: GitHubKitContentFile,
        truncate_lines: int = DEFAULT_TRUNCATE_CONTENT_LINES,
        truncate_characters: int = DEFAULT_TRUNCATE_CONTENT_CHARACTERS,
    ) -> Self:
        content: str | None = None
        encoding: str = "binary"
        file_lines: FileLines | None = None

        if content_file.encoding == "base64":
            content_bytes: bytes = base64.b64decode(content_file.content)
            if content_text := try_decode_base64_utf8(content_bytes):
                content = content_text
                encoding = "utf-8"
                file_lines = FileLines.from_text(text=content)

        total_lines: int | None = len(file_lines.root) if file_lines else None

        return cls(path=content_file.path, encoding=encoding, content=file_lines, total_lines=total_lines).truncate(
            truncate_lines=truncate_lines, truncate_characters=truncate_characters
        )

    def truncate(self, truncate_lines: int, truncate_characters: int) -> Self:
        if self.content is None:
            return self

        return self.model_copy(
            update={"content": self.content.truncate(truncate_lines=truncate_lines, truncate_characters=truncate_characters)}
        )


class RepositoryFileWithLineMatches(BaseModel):
    """A file with its path and line matches from a search result."""

    path: str = Field(description="The path of the file.")
    matches: list[str] = Field(description="The fragments of the file that match the search query.")
    keywords: list[str] = Field(description="The keywords from the search that match the file.")

    @classmethod
    def from_code_search_result_item(cls, code_search_result_item: GitHubKitCodeSearchResultItem) -> Self:
        if not code_search_result_item.text_matches:
            msg = f"Expected a list of SearchResultTextMatchesItems, got {type(code_search_result_item.text_matches)}"
            raise TypeError(msg)

        keyword_matches: set[str] = set()
        text_matches: list[str] = []

        for text_match in code_search_result_item.text_matches:
            if matches := text_match.matches:
                keyword_matches.update(match.text for match in matches if match.text)

            if text_match.fragment:
                text_matches.append(text_match.fragment)

        return cls(path=code_search_result_item.path, matches=text_matches, keywords=sorted(keyword_matches))


class GitReference(BaseModel):
    """A git reference."""

    name: str = Field(description="The name of the reference.")
    sha: str = Field(description="The SHA of the reference.")
    ref_type: str = Field(description="The type of the reference.")

    @classmethod
    def from_git_ref(cls, git_ref: GitHubKitGitRef) -> Self:
        return cls(name=git_ref.ref, sha=git_ref.object_.sha, ref_type=git_ref.object_.type)


class PullRequestFileDiff(BaseModel):
    path: str = Field(description="The path of the file.")
    status: Literal["added", "removed", "modified", "renamed", "copied", "changed", "unchanged"] = Field(
        description="The status of the file."
    )
    patch: str | None = Field(default=None, description="The patch of the file.")
    previous_filename: str | None = Field(default=None, description="The previous filename of the file.")
    truncated: bool = Field(default=False, description="Whether the patch has been truncated to reduce response size.")

    @classmethod
    def from_diff_entry(cls, diff_entry: GitHubKitDiffEntry, truncate: int = 100) -> Self:
        pr_file_diff: Self = cls(
            path=diff_entry.filename,
            status=diff_entry.status,
            patch=diff_entry.patch if diff_entry.patch else None,
            previous_filename=diff_entry.previous_filename if diff_entry.previous_filename else None,
        )

        return pr_file_diff.truncate(truncate=truncate)

    @property
    def lines(self) -> list[str]:
        return self.patch.split("\n") if self.patch else []

    def truncate(self, truncate: int) -> Self:
        lines: list[str] = self.lines

        if len(lines) > truncate:
            lines = lines[:truncate]
            return self.model_copy(update={"patch": "\n".join(lines), "truncated": True})

        return self


class PullRequestDiff(BaseModel):
    file_diffs: list[PullRequestFileDiff] = Field(description="The diff of the pull request.")

    @classmethod
    def from_diff_entries(cls, diff_entries: list[GitHubKitDiffEntry], truncate: int = 100) -> Self:
        return cls(
            file_diffs=[PullRequestFileDiff.from_diff_entry(diff_entry=diff_entry, truncate=truncate) for diff_entry in diff_entries]
        )
