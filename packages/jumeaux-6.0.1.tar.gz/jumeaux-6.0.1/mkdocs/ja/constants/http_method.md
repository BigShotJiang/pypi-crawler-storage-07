| Name |    Description     |
| ---- | ------------------ |
| GET  | HTTPのGETメソッド  |
| POST | HTTPのPOSTメソッド |
