| Name | Description |
| ---- | ----------- |
| and  | AND条件     |
| or   | OR条件      |
