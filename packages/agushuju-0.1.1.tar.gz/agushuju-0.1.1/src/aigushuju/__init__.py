from agushuju import api  # 提供 aigushuju.api 的同名入口

__all__ = ["api"]


