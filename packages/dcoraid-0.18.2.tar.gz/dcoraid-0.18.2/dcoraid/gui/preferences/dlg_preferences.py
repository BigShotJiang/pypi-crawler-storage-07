import logging
import pathlib
from importlib import resources
import random
import socket
import string
import traceback as tb

from PyQt6 import uic, QtCore, QtWidgets
from PyQt6.QtCore import QStandardPaths
from PyQt6.QtWidgets import QMessageBox

from ...api import NoAPIKeyError, CKANAPI
from ...common import ConnectionTimeoutErrors
from ..tools import show_wait_cursor

from ..api import get_ckan_api


class PreferencesDialog(QtWidgets.QMainWindow):
    def __init__(self, *args, **kwargs):
        """Create a new window for preferences
        """
        super(PreferencesDialog, self).__init__(*args, **kwargs)
        ref_ui = resources.files(
            "dcoraid.gui.preferences") / "dlg_preferences.ui"
        with resources.as_file(ref_ui) as path_ui:
            uic.loadUi(path_ui, self)

        self.setWindowTitle("DCOR-Aid Preferences")
        # general
        self.checkBox_check_updates.toggled.connect(
            self.on_general_check_for_updates)
        # server
        self.toolButton_server_update.clicked.connect(self.on_update_server)
        self.tabWidget.currentChanged.connect(self.on_tab_changed)
        self.toolButton_api_token_renew.clicked.connect(
            self.on_server_api_token_renew)
        self.toolButton_api_token_revoke.clicked.connect(
            self.on_server_api_token_revoke)
        self.toolButton_eye.clicked.connect(
            self.on_server_toggle_api_password_view)
        # uploads
        self.toolButton_uploads_cache_browse.clicked.connect(
            self.on_uploads_browse)
        self.toolButton_uploads_path_apply.clicked.connect(
            self.on_uploads_path_apply)
        self.checkBox_upload_write_task_id.toggled.connect(
            self.on_uploads_write_task_id)
        # downloads
        self.toolButton_downloads_browse.clicked.connect(
            self.on_downloads_browse)
        self.toolButton_downloads_path_apply.clicked.connect(
            self.on_downloads_path_apply)
        # account
        self.toolButton_user_update.clicked.connect(self.on_update_user)

        self.settings = QtCore.QSettings()
        self.init_uploads()
        self.init_general()
        self.init_downloads()

        self.logger = logging.getLogger(__name__)

        # hidden initially
        self.hide()

    def ask_change_server_or_api_key(self):
        """Ask user whether he really wants to change things

        ...because it implies a restart of DCOR-Aid.
        """
        button_reply = QMessageBox.question(
            self,
            'DCOR-Aid restart required',
            "Changing the server or API token requires a restart of "
            + "DCOR-Aid. If you choose 'No', then the original server "
            + "and API token are NOT changed. Do you really want to quit "
            + "DCOR-Aid?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No)
        if button_reply == QMessageBox.StandardButton.Yes:
            return True
        else:
            return False

    def init_downloads(self):
        fallback = QStandardPaths.writableLocation(
                      QStandardPaths.StandardLocation.DownloadLocation)
        dl_path = self.settings.value("downloads/default path", fallback)
        self.lineEdit_downloads_path.setText(dl_path)

    def init_general(self):
        ck_updates = int(self.settings.value("check for updates", "1"))
        self.checkBox_check_updates.blockSignals(True)
        self.checkBox_check_updates.setChecked(bool(ck_updates))
        self.checkBox_check_updates.blockSignals(False)

    def init_uploads(self):
        fallback = QStandardPaths.writableLocation(
                      QStandardPaths.StandardLocation.CacheLocation)
        cache_path = self.settings.value("uploads/cache path", fallback)
        if not pathlib.Path(cache_path).exists():
            cache_path = fallback
        else:
            # set it in the settings (in case it's not there)
            self.settings.setValue("uploads/cache path", cache_path)
        self.lineEdit_uploads_cache.setText(cache_path)

        utwdid = int(self.settings.value("uploads/update task with dataset id",
                                         "1"))
        self.checkBox_upload_write_task_id.blockSignals(True)
        self.checkBox_upload_write_task_id.setChecked(bool(utwdid))
        self.checkBox_upload_write_task_id.blockSignals(False)

    @QtCore.pyqtSlot()
    def on_downloads_browse(self):
        default = self.settings.value("downloads/default path", ".")
        path = QtWidgets.QFileDialog.getExistingDirectory(
            self,
            "Choose download location",
            default,
        )
        if path and pathlib.Path(path).exists():
            self.lineEdit_downloads_path.setText(path)

    @QtCore.pyqtSlot()
    def on_downloads_path_apply(self):
        path = self.lineEdit_downloads_path.text()
        self.settings.setValue("downloads/default path", path)

    @QtCore.pyqtSlot(bool)
    def on_general_check_for_updates(self, check_for_updates):
        self.settings.setValue("check for updates",
                               int(bool(check_for_updates)))

    @QtCore.pyqtSlot()
    def on_server_api_token_renew(self):
        if self.ask_change_server_or_api_key():
            api_key = self.settings.value("auth/api key")
            if len(api_key) == 36:
                # deprecated API key
                ret = QMessageBox.question(
                    self,
                    "Deprecated API key",
                    "You are using an API key instead of an API token. "
                    + "API keys are deprecated and cannot be invalidated. "
                    + "DCOR-Aid can only remove it locally. A new API token "
                    + "will be created. Proceed?"
                )
                if ret != QMessageBox.StandardButton.Yes:
                    # Abort
                    return
            # Create a new token
            api = get_ckan_api()
            # create a new token
            user_dict = api.get_user_dict()
            token_name = "DCOR-Aid {} {}".format(
                socket.gethostname(),
                ''.join(random.choice(string.ascii_letters) for _ in range(5)))

            tret = api.post("api_token_create",
                            data={"user": user_dict["id"],
                                  "name": token_name})
            self.settings.setValue("auth/api key", tret["token"])

            if len(api_key) != 36:
                # revoke the old API token
                api.post("api_token_revoke",
                         data={"token": api_key})
            self.logger.info("Exiting, because user renewed API token.")
            QtWidgets.QApplication.quit()

    @QtCore.pyqtSlot()
    def on_server_api_token_revoke(self):
        if self.ask_change_server_or_api_key():
            api_key = self.settings.value("auth/api key")
            if len(api_key) == 36:
                # deprecated API key
                ret = QMessageBox.question(
                    self,
                    "Deprecated API key",
                    "You are using an API key instead of an API token. "
                    + "API keys are deprecated and cannot be invalidated. "
                    + "DCOR-Aid can only remove it locally. Proceed?"
                )
                if ret != QMessageBox.StandardButton.Yes:
                    # Abort
                    return
            else:
                # API token
                api = get_ckan_api()
                api.post("api_token_revoke",
                         data={"token": self.settings.value("auth/api key")})
            self.settings.remove("auth/api key")
            self.logger.info("Exiting, because user revoked API token.")
            QtWidgets.QApplication.quit()

    @QtCore.pyqtSlot()
    def on_server_toggle_api_password_view(self):
        cur_em = self.lineEdit_api_key.echoMode()
        if cur_em == QtWidgets.QLineEdit.EchoMode.Normal:
            new_em = QtWidgets.QLineEdit.EchoMode.PasswordEchoOnEdit
        else:
            new_em = QtWidgets.QLineEdit.EchoMode.Normal
        self.lineEdit_api_key.setEchoMode(new_em)

    @QtCore.pyqtSlot()
    def on_show_server(self):
        self.comboBox_server.clear()
        for server in self.settings.value("server list",
                                          ["dcor.mpl.mpg.de"]):
            self.comboBox_server.addItem(server)
        self.comboBox_server.setCurrentText(
            self.settings.value("auth/server", "dcor.mpl.mpg.de"))
        self.lineEdit_api_key.setText(self.settings.value("auth/api key", ""))
        self.tabWidget.setCurrentWidget(self.tab_server)
        self.lineEdit_api_key.setEchoMode(
            QtWidgets.QLineEdit.EchoMode.PasswordEchoOnEdit)
        self.show()
        self.activateWindow()

    @QtCore.pyqtSlot()
    @show_wait_cursor
    def on_show_user(self):
        api = get_ckan_api()
        try:
            user_dict = api.get_user_dict()
        except tuple(list(ConnectionTimeoutErrors) + [NoAPIKeyError]):
            self.logger.error(tb.format_exc())
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Warning)
            msg.setText("No connection or wrong server or invalid API token!")
            msg.setWindowTitle("Warning")
            msg.setDetailedText(tb.format_exc())
            msg.exec()
            self.on_show_server()
        else:
            self.lineEdit_user_id.setText(user_dict["name"])
            self.lineEdit_user_name.setText(user_dict["fullname"])
            self.lineEdit_user_email.setText(user_dict["email"])
            self.plainTextEdit_user_about.setPlainText(user_dict["about"])
            self.show()
            self.activateWindow()

    @QtCore.pyqtSlot(int)
    def on_tab_changed(self, index):
        widget = self.tabWidget.widget(index)
        if widget is self.tab_server:
            self.on_show_server()
        elif widget is self.tab_user:
            self.on_show_user()

    @QtCore.pyqtSlot()
    @show_wait_cursor
    def on_update_user(self):
        api = get_ckan_api()
        try:
            user_dict = api.get_user_dict()
        except (ConnectionError, NoAPIKeyError):
            self.logger.error(tb.format_exc())
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Warning)
            msg.setText("No connection or wrong server or invalid API token!")
            msg.setWindowTitle("Warning")
            msg.setDetailedText(tb.format_exc())
            msg.exec()
            self.on_show_server()
        update_dict = {}
        update_dict["id"] = user_dict["id"]
        update_dict["fullname"] = self.lineEdit_user_name.text()
        update_dict["email"] = self.lineEdit_user_email.text()
        update_dict["about"] = self.plainTextEdit_user_about.toPlainText()
        api.post("user_update", data=update_dict)

    @QtCore.pyqtSlot()
    def on_uploads_browse(self):
        default = self.settings.value("uploads/cache path", ".")
        path = QtWidgets.QFileDialog.getExistingDirectory(
            self,
            "Choose upload cache location",
            default,
        )
        self.lineEdit_uploads_cache.setText(path)

    @QtCore.pyqtSlot()
    def on_uploads_path_apply(self):
        current = self.settings.value("uploads/cache path", ".")
        path_cache = self.lineEdit_uploads_cache.text()
        self.settings.setValue("uploads/cache path", path_cache)
        if path_cache != current:
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Warning)
            msg.setText("In order for the new cache path to be used, please "
                        "restart DCOR-Aid!")
            msg.setWindowTitle("Please restart DCOR-Aid")
            msg.exec()

    @QtCore.pyqtSlot(bool)
    def on_uploads_write_task_id(self, check_for_updates):
        self.settings.setValue("uploads/update task with dataset id",
                               int(bool(check_for_updates)))

    @QtCore.pyqtSlot()
    @show_wait_cursor
    def on_update_server(self):
        old_server = self.settings.value("auth/server", "")
        old_api_key = self.settings.value("auth/api key", "")
        api_key = self.lineEdit_api_key.text()
        if len(api_key) == 36:
            # deprecated API Key (UUID)
            valid = "0123456789abcdef-"
        else:
            # new API tokens
            valid = "0123456789" \
                    + "abcdefghijklmnopqrstuvwxyz" \
                    + "ABCDEFGHIJKLMNOPQRSTUVWXYZ" \
                    + "._-"
        api_key = "".join([ch for ch in api_key if ch in valid])
        server = self.comboBox_server.currentText().strip()
        # Test whether that works
        try:
            cur_api = get_ckan_api()  # maybe only name or api key changed
            api = CKANAPI(server=server, api_key=api_key,
                          ssl_verify=cur_api.verify)
            api.get_user_dict()  # raises an exception if credentials are wrong
        except BaseException:
            self.logger.error(tb.format_exc())
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Icon.Critical)
            msg.setText("Bad server / API token combination!")
            msg.setWindowTitle("Error")
            msg.setDetailedText(tb.format_exc())
            msg.exec()
        else:
            if old_server != server or old_api_key != api_key:
                if self.ask_change_server_or_api_key():
                    self.settings.setValue("auth/api key", api_key)
                    self.settings.setValue("auth/server", server)
                    self.logger.info("Exiting, because of new credentials.")
                    QtWidgets.QApplication.quit()
