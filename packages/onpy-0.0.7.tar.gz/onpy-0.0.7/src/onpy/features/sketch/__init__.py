"""Sketch features and entities."""
