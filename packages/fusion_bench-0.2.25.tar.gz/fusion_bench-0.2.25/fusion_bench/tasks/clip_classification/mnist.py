classnames = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]

templates = [
    lambda c: f'a photo of the number: "{c}".',
]
