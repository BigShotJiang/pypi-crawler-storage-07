classnames = ["lymph node", "lymph node containing metastatic tumor tissue"]

templates = [
    lambda c: f"this is a photo of {c}",
]
