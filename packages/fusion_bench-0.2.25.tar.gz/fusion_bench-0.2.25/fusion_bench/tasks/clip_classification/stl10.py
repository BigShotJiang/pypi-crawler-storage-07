classnames = [
    "airplane",
    "bird",
    "car",
    "cat",
    "deer",
    "dog",
    "horse",
    "monkey",
    "ship",
    "truck",
]

templates = [
    lambda c: f"a photo of a {c}.",
    lambda c: f"a photo of the {c}.",
]
