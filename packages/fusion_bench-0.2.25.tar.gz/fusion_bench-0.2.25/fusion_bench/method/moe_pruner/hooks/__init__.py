from .deepseek_v2 import (
    MoEPrunerHookFnForDeepseekV2Gate,
    MoEPrunerHookFnForDeepseekV2Linear,
)
from .hook import BaseHookFn
