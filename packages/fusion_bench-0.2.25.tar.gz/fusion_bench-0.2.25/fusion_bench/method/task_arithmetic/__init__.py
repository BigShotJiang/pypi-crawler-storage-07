# flake8: noqa F401
from .task_arithmetic import TaskArithmeticAlgorithm, task_arithmetic_merge
