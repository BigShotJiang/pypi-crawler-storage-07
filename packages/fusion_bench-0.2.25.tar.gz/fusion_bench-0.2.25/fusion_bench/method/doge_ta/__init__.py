# flake8: noqa F401
from .doge_ta import DOGE_TA_Algorithm
