# -*- coding: utf-8 -*-

from .caster import partnercentral_selling_caster

caster = partnercentral_selling_caster

__version__ = "1.40.0"