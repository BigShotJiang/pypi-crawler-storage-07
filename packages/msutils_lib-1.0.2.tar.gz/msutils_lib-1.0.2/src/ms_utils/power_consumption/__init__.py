from .power_consumption import PowerConsumption

__all__ = ["PowerConsumption"]
