# Licensing model

Archimedes is available under a dual-licensing model:

1. The open-source code is licensed under the [GNU General Public License v3.0](https://github.com/pinetreelabs/archimedes/LICENSE).

2. For organizations that would like more flexible licensing, commercial licenses are available that permit use in proprietary applications.  Contact [info@archimedes.sh](mailto:info@archimedes.sh) for details.