# Parametric Derivatives

::: eikonax.derivator
