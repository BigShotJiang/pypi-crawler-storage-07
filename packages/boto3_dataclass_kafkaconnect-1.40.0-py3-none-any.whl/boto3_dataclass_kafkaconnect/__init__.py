# -*- coding: utf-8 -*-

from .caster import kafkaconnect_caster

caster = kafkaconnect_caster

__version__ = "1.40.0"