######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.18.7.5+obcheckpoint(0.2.7);ob(v1)                                                    #
# Generated on 2025-09-29T21:43:14.630617                                                            #
######################################################################################################

from __future__ import annotations



cached_aws_sandbox_creds: None

cached_provider_class: None

class Boto3ClientProvider(object, metaclass=type):
    @staticmethod
    def get_client(module, with_error = False, role_arn = None, session_vars = None, client_params = None):
        ...
    ...

def get_aws_client(module, with_error = False, role_arn = None, session_vars = None, client_params = None):
    ...

