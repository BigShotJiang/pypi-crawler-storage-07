######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.18.7.5+obcheckpoint(0.2.7);ob(v1)                                                    #
# Generated on 2025-09-29T21:43:14.592775                                                            #
######################################################################################################

from __future__ import annotations


from . import pytorch as pytorch

