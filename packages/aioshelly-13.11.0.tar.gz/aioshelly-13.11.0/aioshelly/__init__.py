"""Shelly library."""
