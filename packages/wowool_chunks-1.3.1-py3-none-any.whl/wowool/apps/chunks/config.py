CONFIG = {
    "release": False,
    "short_description": "Chunks the text.",
    "long_description": "Chunks the text.",
}
