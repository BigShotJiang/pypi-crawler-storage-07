Building HydraPlatform templates
================================
