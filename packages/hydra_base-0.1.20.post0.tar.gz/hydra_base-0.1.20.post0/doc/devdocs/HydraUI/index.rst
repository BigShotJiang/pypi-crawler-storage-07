Hydra user interface
====================
