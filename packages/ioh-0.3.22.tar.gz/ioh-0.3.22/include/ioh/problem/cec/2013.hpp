#pragma once

#include "2013/cec_problem.hpp"
#include "2013/five_uneven_peak_trap.hpp"
#include "2013/equal_maxima.hpp"
#include "2013/uneven_decreasing_maxima.hpp"
#include "2013/himmelblau.hpp"
#include "2013/six_hump_camelback.hpp"
#include "2013/shubert.hpp"
#include "2013/vincent.hpp"
#include "2013/modified_rastrigin.hpp"
#include "2013/composition.hpp"
