#pragma once

#include "funnel/double_funnel.hpp"
#include "funnel/double_sphere.hpp"
#include "funnel/double_rastrigin.hpp"
