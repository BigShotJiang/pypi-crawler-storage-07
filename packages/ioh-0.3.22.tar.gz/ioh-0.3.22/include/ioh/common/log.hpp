#pragma once

#include "clutchlog.h"

#define IOH_DBG CLUTCHLOG
#define IOH_DBG_DUMP CLUTCHDUMP
