SELECT *
FROM employees;

SELECT COUNT(*) FROM employees;
