from .plugin import SQLiteConsole

VERSION = "2.0.3"
