"""Version information for gac package."""

__version__ = "1.0.1"
