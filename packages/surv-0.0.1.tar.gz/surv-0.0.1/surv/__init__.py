"""
surv - A placeholder package

This package is reserved for future use.
"""

__version__ = "0.0.1"
__author__ = "Surv Team"
__description__ = "Reserved for CareSurveyor project"
