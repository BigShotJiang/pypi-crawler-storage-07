from setuptools import setup, find_packages

setup(
    name="surv",
    version="0.0.1",
    author="Surv Team",
    author_email="",
    description="Reserved package name",
    long_description="Reserved.",
    long_description_content_type="text/markdown",
    url="https://github.com/caresurveyor/surv",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 1 - Planning",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
    python_requires=">=3.6",
)
