To configure this module, you need to:

1.  Go General settings/Mail/Show Followers on mails/Show Internal
    Users CC and set if want to show or not internal users in cc
    details.
2.  Go Settings/Users & Company select any user in 'Preferences' check
    or not the 'Show in CC' field if this user need to appear in the cc
    note.
3.  Go General settings/Mail/Show Followers on mails/Text 'Sent to'
    and set the initial part of the message.
4.  Go General settings/Mail/Show Followers on mails/Partner format
    and choose desired fields to show on CC recipients.
5.  Go General settings/Mail/Show Followers on mails/Text 'Replies'
    and choose desired warn message
6.  Go General settings/Mail/Show Followers in 'Models to exclude'
    enter the models you want to exclude from the CC note.
