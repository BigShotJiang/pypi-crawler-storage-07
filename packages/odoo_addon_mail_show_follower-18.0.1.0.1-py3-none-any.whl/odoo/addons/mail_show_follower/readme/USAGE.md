To use this module, you need to:

1.  Send an email from any document of odoo.
