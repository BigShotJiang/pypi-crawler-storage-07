This module extends the functionality of mailing to show the document
followers in head of the mails. In the cc, only appear when:

1.  The followers only count if are contacts or external users (Inner
    Followers will be discriminated)
2.  The number of followers are more than 1.
