__version__ = "0.1.0"

from .main import calculate_sta
from . import example

__all__ = ['calculate_sta', 'example', '__version__']