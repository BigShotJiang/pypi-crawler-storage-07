<!--Mettre ici une phrase d'introduction de la recherche.-->
<div>%SEARCH%</div>
