Algorithms
==========

.. automodule:: pymbolic.algorithm
