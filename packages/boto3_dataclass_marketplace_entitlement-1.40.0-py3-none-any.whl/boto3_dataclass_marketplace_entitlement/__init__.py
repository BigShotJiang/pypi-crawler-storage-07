# -*- coding: utf-8 -*-

from .caster import marketplace_entitlement_caster

caster = marketplace_entitlement_caster

__version__ = "1.40.0"