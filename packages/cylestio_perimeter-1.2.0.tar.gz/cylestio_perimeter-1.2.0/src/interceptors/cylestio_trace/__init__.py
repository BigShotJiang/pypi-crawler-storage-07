"""Cylestio trace interceptor for sending events to Cylestio API."""

from .interceptor import CylestioTraceInterceptor

__all__ = ["CylestioTraceInterceptor"]
