from .outetts import Model, ModelConfig
