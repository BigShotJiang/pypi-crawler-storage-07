from mlx_audio.tts.models.indextts.indextts import Model, ModelArgs

__all__ = ["Model", "ModelArgs"]
