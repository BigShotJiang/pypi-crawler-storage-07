# streamlit-custom-component

Filter Component for Streamlit and Cube Alchemy

## Installation instructions

```sh
pip cube-alchemy-streamlit-components
```

## Usage

from cube_alchemy_streamlit_components import filter