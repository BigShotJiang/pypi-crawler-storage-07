# License: MIT
# Copyright © 2024 Frequenz Energy-as-a-Service GmbH

"""Core utilities to complement Python's standard library."""
