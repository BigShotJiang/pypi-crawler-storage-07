# -*- coding: utf-8 -*-

from .caster import iottwinmaker_caster

caster = iottwinmaker_caster

__version__ = "1.40.0"