#  Copyright (c) yibocat 2025 All Rights Reserved
#  Python: 3.12.7
#  Date: 2025/8/18 18:23
#  Author: yibow
#  Email: yibocat@yeah.net
#  Software: AxisFuzzy

from .experimental import experimental
from .deprecated import deprecated

__all__ = []
__all__.extend(['experimental', 'deprecated'])
