To use this module, you need to:

1.  Go to products and create one of type "Stockable".
2.  Update quantities on hand to have stock of it.
3.  Go to inventory dashboard and click on "Delivery Orders" card to
    create a new transfer.
4.  Create a picking and select the product to do the transfer and save
    it.
5.  Click on button *Change Location*, select in wizard the old location
    or product and new location.
