# -*- coding: utf-8 -*-

from .caster import opensearch_caster

caster = opensearch_caster

__version__ = "1.40.0"