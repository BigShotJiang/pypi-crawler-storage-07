# -*- coding: utf-8 -*-

from .caster import rds_caster

caster = rds_caster

__version__ = "1.40.0"