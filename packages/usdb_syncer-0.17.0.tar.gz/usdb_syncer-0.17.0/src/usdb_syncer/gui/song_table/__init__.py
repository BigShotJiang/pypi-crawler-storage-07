"""Song table module."""
