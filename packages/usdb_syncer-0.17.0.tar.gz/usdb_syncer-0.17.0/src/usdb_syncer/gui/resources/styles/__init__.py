"""This file was generated using `write_resource_files.py`."""

from importlib import resources

DARK_QSS = resources.files() / "dark.qss"
