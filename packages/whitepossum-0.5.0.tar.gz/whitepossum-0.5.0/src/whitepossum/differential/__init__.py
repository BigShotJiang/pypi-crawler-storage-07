"""
Subpackage containing differential functions.
"""

from .discrete import diff