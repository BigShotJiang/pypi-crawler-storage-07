"""Storage package initialization."""

