"""Pipeline package initialization."""

