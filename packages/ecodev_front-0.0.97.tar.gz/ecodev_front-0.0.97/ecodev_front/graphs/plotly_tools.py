PLOTLY_TOOLS = [
    'zoom2d', 'pan2d', 'select2d', 'lasso2d', 'zoomIn2d', 'zoomOut2d',
    'autoScale2d', 'resetScale2d', 'hoverClosestCartesian',
    'hoverCompareCartesian', 'zoom3d', 'pan3d', 'resetCameraDefault3d',
    'resetCameraLastSave3d', 'hoverClosest3d', 'orbitRotation', 'tableRotation',
    'hoverClosestGeo', 'toImage', 'sendDataToCloud',
    'hoverClosestGl2d', 'hoverClosestPie', 'toggleHover',
    'resetViews', 'toggleSpikelines', 'resetViewMapbox'
]
