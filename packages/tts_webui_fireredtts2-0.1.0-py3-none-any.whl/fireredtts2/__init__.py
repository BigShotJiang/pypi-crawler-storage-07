
from .fireredtts2 import FireRedTTS2

__all__ = ["FireRedTTS2"]
