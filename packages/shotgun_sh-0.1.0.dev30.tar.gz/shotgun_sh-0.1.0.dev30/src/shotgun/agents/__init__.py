"""Shotgun AI Agents."""
