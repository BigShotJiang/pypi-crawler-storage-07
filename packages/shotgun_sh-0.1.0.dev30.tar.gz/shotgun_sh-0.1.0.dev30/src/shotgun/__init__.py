"""Shotgun CLI package."""

from importlib.metadata import version

__version__ = version("shotgun-sh")
