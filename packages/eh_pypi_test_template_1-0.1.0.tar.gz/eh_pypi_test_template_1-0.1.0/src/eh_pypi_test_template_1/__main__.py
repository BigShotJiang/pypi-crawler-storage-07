"""Entry point for {{ package_name }} package."""

def main():
    """Main entry point."""
    print("Hello from {{ package_name }}!")

if __name__ == "__main__":
    main()
