|:seedling:| BaseNode
============================================

.. automodule:: bigtree.node.basenode
   :members:
   :show-inheritance:
