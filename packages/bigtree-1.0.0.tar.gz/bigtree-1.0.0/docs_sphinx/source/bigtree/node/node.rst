|:hibiscus:| Node
============================================

.. automodule:: bigtree.node.node
   :members:
   :show-inheritance:
