|:sparkles:| Construct
============================================

Construct Binary Tree from list.

.. list-table:: Binary Tree Construct Methods
   :widths: 30 40 30
   :header-rows: 1

   * - Construct Binary Tree from
     - Using heapq structure
     - Add node attributes
   * - List
     - `list_to_binarytree`
     - No

.. automodule:: bigtree.binarytree.construct
   :members:
   :show-inheritance:
