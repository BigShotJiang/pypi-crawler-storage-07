"""MCP command module."""
