"""Space initialization package."""
