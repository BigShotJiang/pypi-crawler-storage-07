# -*- coding: utf-8 -*-

from .caster import ce_caster

caster = ce_caster

__version__ = "1.40.0"