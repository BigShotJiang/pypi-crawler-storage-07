# Light compressor

Пока пишу по-русски и как обычный комментарий, в последствии переделаю.

Суть библиотеки - обеспечить оптимальную скорость распаковки и упаковки сжатого потока данных из БД и файлов.
Для моего проекта требуется максимально быстро обработать поток байт и передать в другой поток упакованные данные в сжатом формате.
Проверил все готовые решения, скорость не устроила, поэтому поправил то что было как смог, стало быстрее.
У стрим ридера нет и не может быть методов tell и seek, только прямое последовательное чтение из потока.
Для моего проекта этого достаточно, поэтому делаю так.
Форматы сжатия только LZ4 и ZSTD.


Для ридера при чтении из файла доступно автоматическое определение формата сжатия (проверка по сигнатуре LZ4, ZSTD или сжатие отсутствует)

```python
from light_compressor import define_reader


fileobj = open("some_path_to_file.bin", "rb")
decompressed_stream = define_reader(fileobj)
```

Для чтения в потоке требуется явно передать метод сжатия

```python
from light_compressor import define_reader, CompressionMethod


# Получение распакованного файлоподобного объекта из потока, сжатого в ZSTD
decompressed_stream = define_reader(fileobj, CompressionMethod.ZSTD)
```

Упаковка в режиме стрим


```python
from light_compressor import define_writer, CompressionMethod

# Получение генератора упакованного массива байт, сжатого в ZSTD
compressed_stream = define_writer(bytes_data, CompressionMethod.ZSTD)
```
