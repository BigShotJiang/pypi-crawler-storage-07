"""Common exception classes for MCP services"""
