# ruff: noqa: UP006 UP007 UP045
# @omlish-lite
import typing as ta


ConfigMap = ta.Mapping[str, ta.Any]  # ta.TypeAlias


##
