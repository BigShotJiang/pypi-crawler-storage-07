# -*- coding: utf-8 -*-

from .caster import gameliftstreams_caster

caster = gameliftstreams_caster

__version__ = "1.40.0"