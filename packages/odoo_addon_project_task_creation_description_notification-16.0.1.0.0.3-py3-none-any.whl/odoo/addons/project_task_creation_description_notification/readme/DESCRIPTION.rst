This module automatically adds ``project_task.description`` to messages posted on project.task creation, providing immediate context without requiring recipients to open the task itself.
