
DA validation procedures
------------------------