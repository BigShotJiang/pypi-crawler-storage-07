
Deep learning DA methods
------------------------