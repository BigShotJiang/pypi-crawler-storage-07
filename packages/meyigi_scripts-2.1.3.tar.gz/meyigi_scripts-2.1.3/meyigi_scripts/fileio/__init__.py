from .json import append_to_json
from .excel import append_to_excel
from .text import append_to_txt, load_txt
from .loaders import load_html_files