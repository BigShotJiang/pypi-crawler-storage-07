"""
enterprise_learner_portal app.
"""

from django.apps import AppConfig


class EnterpriseLearnerPortalConfig(AppConfig):
    """
    enterprise_learner_portal app config.
    """

    name = 'enterprise_learner_portal'
