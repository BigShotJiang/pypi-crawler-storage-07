"""
API endpoint for enterprise app.
"""
