The developers of PSI decide to rename their project to PSI4. The first version is PSI4/1.0.
To keep up with upstream, we have also stopped adding easyconfigs here and now continue with PSI4 as
program name. Look in the directory 'PSI4' for the latest version of PSI.
More information:
- https://github.com/psi4/psi4/issues/213#issuecomment-182766378
- https://github.com/psi4/psi4/wiki/Versioning#how-to-get-and-interpret-the-version-number
