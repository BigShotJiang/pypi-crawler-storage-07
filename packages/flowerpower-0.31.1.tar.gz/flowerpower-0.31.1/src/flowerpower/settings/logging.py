import os

# LOGGING
LOG_LEVEL = os.getenv("FP_LOG_LEVEL", "CRITICAL")
