import warnings

warnings.warn(
    "The flowerpower.plugins.io module is deprecated. "
    "Please use 'flowerpower-io' instead. Install it with 'pip install flowerpower-io'.",
    DeprecationWarning,
    stacklevel=2,
)
