Think harder to complete these tasks:
You are helping consolidate and clean up the project feature backlog.
1. Review artifacts/backlog/ folder contents
2. Review project files and code to understand the current state
3. Review the git history for releases done so far
3. Move all open features in the artifacts/backlog/active.md file
4. Make sure any open issues, fixes, bugs are prioritized on top of the sequence of open features
5. Move all completed features into release-version.md files
6. If there is any documentation or learning or analysis in backlog folder then move it to appropriately named file in docs/ folder
7. The backlog folder should only have active.md and release-version.md files
8. Remove any other redundant files from the backlog folder
