Think harder to complete these tasks:
1. Read artifacts/backlog/ folder contents
2. Understand the current state of the project
3. Identify the next feature to implement
4. Develop the feature
5. When done, mark the feature complete in the backlog