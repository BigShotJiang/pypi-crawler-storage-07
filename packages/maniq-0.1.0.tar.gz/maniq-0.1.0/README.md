# helloworld

A minimal "Hello, World!" command-line tool for demonstration and PyPI publishing.

## Installation

```bash
pip install helloworld