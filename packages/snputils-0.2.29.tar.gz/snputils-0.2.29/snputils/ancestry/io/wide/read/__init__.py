from .admixture import AdmixtureReader
from .functional import read_adm, read_admixture
