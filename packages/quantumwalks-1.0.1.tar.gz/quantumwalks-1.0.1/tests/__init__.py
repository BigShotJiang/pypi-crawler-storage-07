"""
Test suite for quantumwalks package.
"""