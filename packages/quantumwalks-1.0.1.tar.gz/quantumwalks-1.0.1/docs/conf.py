import os
import sys
sys.path.insert(0, os.path.abspath('../src'))

project = 'Quantum Walks'
copyright = '2025, LiangWen'
author = 'LiangWen'

extensions = [
    'sphinx.ext.autodoc',
    'sphinx.ext.napoleon',
    'sphinx.ext.viewcode',
    'sphinx.ext.mathjax',
]

html_theme = 'sphinx_rtd_theme'