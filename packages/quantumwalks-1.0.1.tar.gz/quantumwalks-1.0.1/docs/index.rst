Quantum Walks Documentation
===========================

A comprehensive Python package for simulating quantum walks in various dimensions and on complex networks.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installation
   usage

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`