Usage
=====

Basic Quantum Walks
-------------------

1D Quantum Walk
~~~~~~~~~~~~~~~

.. code-block:: python

   from quantumwalks import DTQW1D
   import numpy as np

   qw = DTQW1D(N=100, coin_type='hadamard')
   qw.initialize_state(init_pos=0)
   qw.evolve(50)
   qw.plot()

2D and 3D Quantum Walks
~~~~~~~~~~~~~~~~~~~~~~~

.. code-block:: python

   from quantumwalks import DTQW2D, DTQW3D

   # 2D walk
   qw2d = DTQW2D(Nx=30, Ny=30, coin_type='grover')
   qw2d.initialize_state()
   qw2d.evolve(20)
   qw2d.plot()

   # 3D walk  
   qw3d = DTQW3D(Nx=5, Ny=5, Nz=5, coin_type='fourier')
   qw3d.initialize_state()
   qw3d.evolve(10)
   qw3d.plot()

Graph Quantum Walks
-------------------

.. code-block:: python

   import networkx as nx
   from quantumwalks import GraphDTQW, SzegedyQW

   graph = nx.karate_club_graph()

   # Graph walk
   gqw = GraphDTQW(graph, coin_type='grover')
   gqw.evolve(10)
   gqw.plot()

   # Szegedy walk
   sqw = SzegedyQW(graph, initial_nodes=[0])
   sqw.evolve(34)
   sqw.plot(register='first')

Quantum Ranking
---------------

.. code-block:: python

   from quantumwalks import DTQWPageRank, QuantumPageRank

   # DTQW PageRank
   dtqw_pr = DTQWPageRank(graph.to_directed())
   dtqw_scores = dtqw_pr.get_ranking()

   # Quantum PageRank
   qpr = QuantumPageRank(graph)
   quantum_scores = qpr.get_ranking()

   # Compare with classical
   classical_pr = nx.pagerank(graph)