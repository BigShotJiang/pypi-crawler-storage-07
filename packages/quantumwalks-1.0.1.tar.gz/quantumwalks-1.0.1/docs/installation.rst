Installation
============

From PyPI
---------

.. code-block:: bash

   pip install quantumwalks

From Source
-----------

.. code-block:: bash

   git clone https://github.com/yourusername/quantumwalks
   cd quantumwalks
   pip install -e .

Dependencies
------------

* Python >= 3.8
* NumPy >= 1.21.0
* SciPy >= 1.7.0
* Matplotlib >= 3.5.0
* NetworkX >= 2.6.0