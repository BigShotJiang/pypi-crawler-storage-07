"""
Examples for quantumwalks package.
"""