"""
Basic usage examples for quantumwalks package.
"""

import numpy as np
import matplotlib.pyplot as plt
from quantumwalks import DTQW1D, DTQW2D, DTQW3D

def example_1d():
    """1D quantum walk example."""
    print("Running 1D quantum walk...")
    
    # Initialize with Hadamard coin
    qw = DTQW1D(N=100, coin_type='hadamard')
    qw.initialize_state(init_pos=0, init_coin=np.array([1, 1j])/np.sqrt(2))
    
    # Evolve and plot
    qw.evolve(100)
    fig = qw.plot(color='blue', alpha=0.7)
    plt.show()

def example_2d():
    """2D quantum walk example."""
    print("Running 2D quantum walk...")
    
    # Initialize with Grover coin
    qw = DTQW2D(Nx=30, Ny=30, coin_type='grover')
    qw.initialize_state(init_pos=(0, 0))
    
    # Evolve and plot
    qw.evolve(20)
    fig = qw.plot()
    plt.show()

def example_3d():
    """3D quantum walk example."""
    print("Running 3D quantum walk...")
    
    # Initialize with Fourier coin
    qw = DTQW3D(Nx=5, Ny=5, Nz=5, coin_type='fourier')
    qw.initialize_state(init_pos=(0, 0, 0))
    
    # Evolve and plot
    qw.evolve(10)
    fig = qw.plot(threshold=1e-4)
    plt.show()

if __name__ == "__main__":
    example_1d()
    example_2d()
    example_3d()