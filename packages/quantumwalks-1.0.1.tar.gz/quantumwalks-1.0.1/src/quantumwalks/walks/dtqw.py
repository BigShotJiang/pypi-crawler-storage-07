import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from typing import Tuple, Optional, Union
from ..coins import hadamard_coin, grover_coin, fourier_coin, su_n_coin


class DTQW1D:
    """Discrete Time Quantum Walk in 1D."""

    def __init__(self, N: int, coin_type: str = 'hadamard', coin_params: Optional[Tuple] = None):
        """
        Initialize 1D DTQW.

        Parameters:
        -----------
        N : int
            Half-size of line (positions -N to N)
        coin_type : str
            Type of coin operator: 'hadamard', 'grover', 'fourier', 'su2'
        coin_params : tuple, optional
            Parameters for SU(2) coin: (theta, phi, lambda)
        """
        self.N = N
        self.positions = np.arange(-N, N + 1)
        self.num_pos = len(self.positions)
        self.coin_dim = 2
        self.total_dim = self.num_pos * self.coin_dim
        self.state = np.zeros(self.total_dim, dtype=complex)
        self.coin_type = coin_type
        self.coin = self._get_coin(coin_type, coin_params)
        self._build_operators()

    def _get_coin(self, coin_type: str, params: Optional[Tuple]) -> np.ndarray:
        coin_operators = {
            'hadamard': lambda: hadamard_coin(2),
            'grover': lambda: grover_coin(2),
            'fourier': lambda: fourier_coin(2),
            'su2': lambda: su_n_coin(2, params)
        }

        if coin_type not in coin_operators:
            raise ValueError(f"Unknown coin type: {coin_type}")

        return coin_operators[coin_type]()

    def _build_operators(self):
        # Coin operator
        self.coin_op = np.kron(np.eye(self.num_pos), self.coin)

        # Shift operator - using periodic boundary conditions
        self.shift_op = np.zeros((self.total_dim, self.total_dim), dtype=complex)
        for i in range(self.num_pos):
            # |x, 0> -> |x+1, 0> (right shift, periodic boundary)
            next_pos = (i + 1) % self.num_pos
            self.shift_op[self.coin_dim * next_pos, self.coin_dim * i] = 1

            # |x, 1> -> |x-1, 1> (left shift, periodic boundary)
            prev_pos = (i - 1) % self.num_pos
            self.shift_op[self.coin_dim * prev_pos + 1, self.coin_dim * i + 1] = 1

    def initialize_state(self, init_pos: int = 0, init_coin: np.ndarray = None):
        """
        Initialize quantum walk state.

        Parameters:
        -----------
        init_pos : int
            Initial position
        init_coin : np.ndarray
            Initial coin state (normalized)
        """
        if init_coin is None:
            init_coin = np.array([1, 0]) / np.sqrt(2)

        idx = init_pos + self.N
        if 0 <= idx < self.num_pos:
            self.state[self.coin_dim * idx: self.coin_dim * (idx + 1)] = (
                    init_coin / np.linalg.norm(init_coin)
            )
        else:
            raise ValueError("Initial position out of bounds")

    def step(self):
        """Perform one evolution step."""
        self.state = self.shift_op @ (self.coin_op @ self.state)

        # Add numerical stability check: ensure state normalization
        current_norm = np.linalg.norm(self.state)
        if not np.isclose(current_norm, 1.0, atol=1e-12):
            self.state = self.state / current_norm

    def evolve(self, num_steps: int):
        """Evolve for multiple steps."""
        for _ in range(num_steps):
            self.step()

    def get_probabilities(self) -> np.ndarray:
        """Get probability distribution over positions."""
        probs = np.zeros(self.num_pos)
        for i in range(self.num_pos):
            probs[i] = np.sum(np.abs(self.state[self.coin_dim * i: self.coin_dim * (i + 1)]) ** 2)

        # Verify probability conservation, normalize if not conserved
        total_prob = np.sum(probs)
        if not np.isclose(total_prob, 1.0, atol=1e-10):
            probs = probs / total_prob

        return probs

    def plot(self, **kwargs):
        """Plot probability distribution."""
        probs = self.get_probabilities()
        plt.figure(figsize=(10, 6))
        plt.plot(self.positions, probs, marker='o', linestyle='-',** kwargs)
        plt.xlabel('Position')
        plt.ylabel('Probability')
        plt.title(f'1D Quantum Walk ({self.coin_type} coin)')
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        return plt.gcf()


class DTQW2D:
    """Discrete Time Quantum Walk in 2D"""

    def __init__(self, Nx: int, Ny: int, coin_type: str = 'grover', coin_params: Optional[Tuple] = None):
        self.Nx = Nx
        self.Ny = Ny
        self.positions_x = np.arange(-Nx, Nx + 1)
        self.positions_y = np.arange(-Ny, Ny + 1)
        self.num_x = len(self.positions_x)
        self.num_y = len(self.positions_y)
        self.coin_dim = 4  # up, down, left, right
        self.total_dim = self.num_x * self.num_y * self.coin_dim
        self.state = np.zeros(self.total_dim, dtype=complex)
        self.coin_type = coin_type
        self.coin = self._get_coin(coin_type, coin_params)

        # No longer precompute huge coin operator matrix
        # Apply coin operation dynamically in step()

    def _get_coin(self, coin_type: str, params: Optional[Tuple]) -> np.ndarray:
        coin_operators = {
            'hadamard': lambda: hadamard_coin(4),
            'grover': lambda: grover_coin(4),
            'fourier': lambda: fourier_coin(4)
        }

        if coin_type not in coin_operators:
            raise ValueError(f"Unknown coin type: {coin_type}")

        return coin_operators[coin_type]()

    def initialize_state(self, init_pos: Tuple[int, int] = (0, 0),
                         init_coin: np.ndarray = None):
        if init_coin is None:
            init_coin = np.ones(4) / 2

        idx_x = init_pos[0] + self.Nx
        idx_y = init_pos[1] + self.Ny

        if 0 <= idx_x < self.num_x and 0 <= idx_y < self.num_y:
            flat_idx = (idx_x * self.num_y + idx_y) * self.coin_dim
            self.state[flat_idx: flat_idx + self.coin_dim] = (
                    init_coin / np.linalg.norm(init_coin)
            )
        else:
            raise ValueError("Initial position out of bounds")

    def step(self):
        """
        Perform one evolution step
        Using point-wise coin operation instead of large matrix multiplication
        """
        # Reshape state to (num_x, num_y, coin_dim)
        state_reshaped = self.state.reshape((self.num_x, self.num_y, self.coin_dim))

        # Apply coin operation point-wise
        for i in range(self.num_x):
            for j in range(self.num_y):
                coin_state = state_reshaped[i, j, :].copy()
                state_reshaped[i, j, :] = self.coin @ coin_state

        # Create new state for shifting
        new_state = np.zeros_like(state_reshaped)

        # Shift operation with periodic boundary conditions
        # Up (0): y + 1 (periodic boundary)
        new_state[:, :, 0] = np.roll(state_reshaped[:, :, 0], shift=-1, axis=1)
        # Down (1): y - 1 (periodic boundary)
        new_state[:, :, 1] = np.roll(state_reshaped[:, :, 1], shift=1, axis=1)
        # Left (2): x - 1 (periodic boundary)
        new_state[:, :, 2] = np.roll(state_reshaped[:, :, 2], shift=1, axis=0)
        # Right (3): x + 1 (periodic boundary)
        new_state[:, :, 3] = np.roll(state_reshaped[:, :, 3], shift=-1, axis=0)

        # Flatten back to original state
        self.state = new_state.flatten()

        # Add numerical stability check
        current_norm = np.linalg.norm(self.state)
        if not np.isclose(current_norm, 1.0, atol=1e-12):
            self.state = self.state / current_norm

    def evolve(self, num_steps: int):
        """Evolve for multiple steps with progress display"""
        for step in range(num_steps):
            self.step()
            # Display progress every 10 steps (optional)
            if num_steps >= 10 and (step + 1) % (num_steps // 10) == 0:
                progress = (step + 1) / num_steps * 100
                print(f"2D Quantum Walk Progress: {progress:.0f}%")

    def get_probabilities(self) -> np.ndarray:
        """
        Return 2D probability distribution (num_x, num_y)
        """
        state_reshaped = self.state.reshape((self.num_x, self.num_y, self.coin_dim))
        probs = np.sum(np.abs(state_reshaped) **2, axis=2)

        # Verify probability conservation, normalize if not conserved
        total_prob = np.sum(probs)
        if not np.isclose(total_prob, 1.0, atol=1e-10):
            probs = probs / total_prob

        return probs

    def plot(self,** kwargs):
        probs = self.get_probabilities()
        extent = [self.positions_x[0], self.positions_x[-1],
                  self.positions_y[0], self.positions_y[-1]]

        plt.figure(figsize=(10, 8))
        plt.imshow(probs.T, origin='lower', cmap='YlGnBu',
                   extent=extent, aspect='equal', **kwargs)
        plt.colorbar(label='Probability')
        plt.xlabel('X Position')
        plt.ylabel('Y Position')
        plt.title(f'2D Quantum Walk ({self.coin_type} coin)')
        plt.tight_layout()
        return plt.gcf()


class DTQW3D:
    """Discrete Time Quantum Walk in 3D"""

    def __init__(self, Nx: int, Ny: int, Nz: int,
                 coin_type: str = 'grover', coin_params: Optional[Tuple] = None):
        self.Nx = Nx
        self.Ny = Ny
        self.Nz = Nz
        self.positions_x = np.arange(-Nx, Nx + 1)
        self.positions_y = np.arange(-Ny, Ny + 1)
        self.positions_z = np.arange(-Nz, Nz + 1)
        self.num_x = len(self.positions_x)
        self.num_y = len(self.positions_y)
        self.num_z = len(self.positions_z)
        self.coin_dim = 6  # ±x, ±y, ±z
        self.total_dim = self.num_x * self.num_y * self.num_z * self.coin_dim
        self.state = np.zeros(self.total_dim, dtype=complex)
        self.coin_type = coin_type
        self.coin = self._get_coin(coin_type, coin_params)
        # No longer precompute huge coin operator matrix

    def _get_coin(self, coin_type: str, params: Optional[Tuple]) -> np.ndarray:
        coin_operators = {
            'grover': lambda: grover_coin(6),
            'fourier': lambda: fourier_coin(6),
            'su_n': lambda: su_n_coin(6, params)
        }

        if coin_type not in coin_operators:
            raise ValueError(f"Unknown coin type: {coin_type}")

        return coin_operators[coin_type]()

    def initialize_state(self, init_pos: Tuple[int, int, int] = (0, 0, 0),
                         init_coin: np.ndarray = None):
        if init_coin is None:
            init_coin = np.ones(6) / np.sqrt(6)

        idx_x = init_pos[0] + self.Nx
        idx_y = init_pos[1] + self.Ny
        idx_z = init_pos[2] + self.Nz

        if (0 <= idx_x < self.num_x and 0 <= idx_y < self.num_y and
                0 <= idx_z < self.num_z):
            flat_idx = ((idx_x * self.num_y * self.num_z +
                         idx_y * self.num_z + idx_z) * self.coin_dim)
            self.state[flat_idx: flat_idx + self.coin_dim] = (
                    init_coin / np.linalg.norm(init_coin)
            )
        else:
            raise ValueError("Initial position out of bounds")

    def step(self):
        """
        Perform one evolution step
        Using point-wise coin operation
        """
        # Reshape state to (num_x, num_y, num_z, coin_dim)
        state_reshaped = self.state.reshape((self.num_x, self.num_y, self.num_z, self.coin_dim))

        # Apply coin operation point-wise
        for i in range(self.num_x):
            for j in range(self.num_y):
                for k in range(self.num_z):
                    coin_state = state_reshaped[i, j, k, :].copy()
                    state_reshaped[i, j, k, :] = self.coin @ coin_state

        # Create new state
        new_state = np.zeros_like(state_reshaped)

        # Shift operation with periodic boundary conditions
        # +x (0): x + 1 (periodic boundary)
        new_state[:, :, :, 0] = np.roll(state_reshaped[:, :, :, 0], shift=-1, axis=0)
        # -x (1): x - 1 (periodic boundary)
        new_state[:, :, :, 1] = np.roll(state_reshaped[:, :, :, 1], shift=1, axis=0)
        # +y (2): y + 1 (periodic boundary)
        new_state[:, :, :, 2] = np.roll(state_reshaped[:, :, :, 2], shift=-1, axis=1)
        # -y (3): y - 1 (periodic boundary)
        new_state[:, :, :, 3] = np.roll(state_reshaped[:, :, :, 3], shift=1, axis=1)
        # +z (4): z + 1 (periodic boundary)
        new_state[:, :, :, 4] = np.roll(state_reshaped[:, :, :, 4], shift=-1, axis=2)
        # -z (5): z - 1 (periodic boundary)
        new_state[:, :, :, 5] = np.roll(state_reshaped[:, :, :, 5], shift=1, axis=2)

        # Flatten back to original state
        self.state = new_state.flatten()

        # Add numerical stability check
        current_norm = np.linalg.norm(self.state)
        if not np.isclose(current_norm, 1.0, atol=1e-12):
            self.state = self.state / current_norm

    def evolve(self, num_steps: int):
        """Evolve for multiple steps with progress display"""
        for step in range(num_steps):
            self.step()
            # Display progress for each step (3D is slow)
            progress = (step + 1) / num_steps * 100
            print(f"3D Quantum Walk Progress: {progress:.0f}%")

    def get_probabilities(self) -> np.ndarray:
        """
        Return 3D probability distribution (num_x, num_y, num_z)
        """
        state_reshaped = self.state.reshape((self.num_x, self.num_y,
                                             self.num_z, self.coin_dim))
        probs = np.sum(np.abs(state_reshaped) **2, axis=3)

        # Verify probability conservation, normalize if not conserved
        total_prob = np.sum(probs)
        if not np.isclose(total_prob, 1.0, atol=1e-10):
            probs = probs / total_prob

        return probs

    def plot(self, threshold: float = 1e-5,** kwargs):
        probs = self.get_probabilities()
        x, y, z = np.meshgrid(self.positions_x, self.positions_y,
                              self.positions_z, indexing='ij')
        mask = probs > threshold

        fig = plt.figure(figsize=(12, 9))
        ax = fig.add_subplot(111, projection='3d')
        scatter = ax.scatter(x[mask], y[mask], z[mask],
                             c=probs[mask], s=probs[mask] * 1000,
                             cmap='viridis', **kwargs)
        plt.colorbar(scatter, label='Probability')
        ax.set_xlabel('X Position')
        ax.set_ylabel('Y Position')
        ax.set_zlabel('Z Position')
        ax.set_title(f'3D Quantum Walk ({self.coin_type} coin)')
        plt.tight_layout()
        return plt.gcf()