"""
Quantum Walks - A comprehensive Python package for simulating quantum walks
in various dimensions and on complex networks.
"""

__version__ = "1.0.1"
__author__ = "LiangWen"
__email__ = "louvian@sylu.edu.cn"

from .coins import (
    hadamard_coin,
    grover_coin,
    fourier_coin,
    su_n_coin
)

from .walks.dtqw import (
    DTQW1D,
    DTQW2D,
    DTQW3D
)

from .walks.graph_walk import GraphDTQW
from .walks.szegedy import SzegedyQW
from .walks.pagerank import (
    DTQWPageRank,
    QuantumPageRank
)

from .utils import (
    plot_probability_distribution,
    analyze_convergence,
    validate_graph,
    plot_convergence_analysis,  # 添加这行
    compare_classical_quantum,  # 添加这行
    export_results  # 可选添加，如果你在utils.py中修复了它
)

__all__ = [
    # Coin operators
    "hadamard_coin",
    "grover_coin",
    "fourier_coin",
    "su_n_coin",

    # Discrete-time quantum walks
    "DTQW1D",
    "DTQW2D",
    "DTQW3D",

    # Graph-based walks
    "GraphDTQW",
    "SzegedyQW",

    # Ranking algorithms
    "DTQWPageRank",
    "QuantumPageRank",

    # Utilities
    "plot_probability_distribution",
    "analyze_convergence",
    "validate_graph",
    "plot_convergence_analysis",  # 添加这行
    "compare_classical_quantum",  # 添加这行
    "export_results"  # 可选添加
]