"""Top-level package initialization."""

from .grammar import parse
