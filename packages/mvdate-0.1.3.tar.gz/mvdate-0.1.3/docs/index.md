# Welcome to mvdate

A Python package to search for files and move them to a directory structure based on date, whether that is the date they
were created on or modified. The directory structure is highly customisable and can include any of year, month, day,
hour, minute or second.

Why would I want to do this? See the [motivation](motivation) page for that.

To get started see the [installation](installation) instructions.

If you have problems installing or using `mvdate` please create an [issue][issue]. If you know how to fix the problems
please fork the repository and create a [pull request][pull].

I hope you find `mvdate` useful. If you have any feedback please create an [issue][issue].

`mvdate` is licensed under the [GNU GPL v3][gnu_gpl_v3].

[gnu_gpl_v3]: https://www.gnu.org/licenses/gpl-3.0.en.html
[issue]: https://codeberg.org/slackline/mvdate/issues
[pull]: https://codeberg.org/slackline/mvdate/pulls
