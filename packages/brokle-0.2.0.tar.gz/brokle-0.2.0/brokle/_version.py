"""Version information for Brokle SDK."""

__version__ = "0.2.0"
__version_info__ = (0, 2, 0)
