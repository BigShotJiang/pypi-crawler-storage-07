__all__ = ["LOG_NAME"]


# Name of the primary log used by uvicorn.
# This value is from https://stackoverflow.com/a/77007723
LOG_NAME = "uvicorn.error"
