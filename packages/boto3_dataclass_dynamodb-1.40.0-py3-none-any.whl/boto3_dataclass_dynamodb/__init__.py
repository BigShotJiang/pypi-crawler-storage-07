# -*- coding: utf-8 -*-

from .caster import dynamodb_caster

caster = dynamodb_caster

__version__ = "1.40.0"