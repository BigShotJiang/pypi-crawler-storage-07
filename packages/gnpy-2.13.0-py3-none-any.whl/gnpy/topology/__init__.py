"""
Tracking :py:mod:`.request` for spectrum and their :py:mod:`.spectrum_assignment`.
"""
