# This code is part of Tergite
#
# (C) Copyright Chalmers Next Labs 2024
# (C) Copyright Michele Faucci Giannelli 2025
#
# This code is licensed under the Apache License, Version 2.0. You may
# obtain a copy of this license in the LICENSE.txt file in the root directory
# of this source tree or at http://www.apache.org/licenses/LICENSE-2.0.
#
# Any modifications or derivative works of this code must retain this
# copyright notice, and modified files need to carry a notice indicating
# that they have been altered from the originals.

import os.path
from datetime import datetime
from typing import List, Optional

from tergite_autocalibration.config.base import TOMLConfigurationFile
from tergite_autocalibration.utils.dto.enums import ApplicationStatus


class RunConfiguration(TOMLConfigurationFile):
    """
    A class to handle all run specific configurations.
    A run is e.g. when you call `acli start` and it is over as soon as the program terminates
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Create a run id in the form of YYYY-MM-DD--HH-MM-SS--tac-run-id e.g. 2024-11-27--13-52-10--tac-run-id
        # This can be used e.g. to name output folders
        timestamp_ = datetime.now()
        self._run_id = f"{timestamp_.strftime('%Y-%m-%d--%H-%M-%S')}--tac-run-id"

        # Create a file path in the form of YYYY-MM-DD/"ACTIVE"_HH-MM-SS--target_node

        self._log_dir = os.path.join(
            timestamp_.strftime("%Y-%m-%d"),
            f"{timestamp_.strftime('%H-%M-%S')}_{self.name}-{str(ApplicationStatus.ACTIVE.value)}",
        )

        # We need to know the data directory to write the original acquisition date
        self._data_dir = None

    @property
    def id(self) -> str:
        """
        Returns:
            str: Run ID in form of YYYY-MM-DD--HH-MM-SS--"tac-run-id"

        """
        return self._run_id

    @property
    def log_dir(self) -> str:
        """
        Returns:
            str: Run directory in form YYYY-MM-DD/"ACTIVE"_HH-MM-SS--target_node

        """
        return self._log_dir

    @log_dir.setter
    def log_dir(self, value):
        self._log_dir = value

    @property
    def data_dir(self) -> Optional[str]:
        """
        Returns:
            Data directory in form YYYY-MM-DD/"ACTIVE"_HH-MM-SS--target_node

        """
        return self._data_dir

    @data_dir.setter
    def data_dir(self, value):
        self._data_dir = value

    @property
    def target_node(self) -> str:
        """
        Returns:
            Node to calibrate to

        """
        return self._dict.get("target_node", None)

    @property
    def qubits(self) -> List[str]:
        """
        Returns:
            Qubits to be calibrated. This should be a subset or equal the qubits in the device_config.toml

        """
        return self._dict.get("qubits", [])

    @property
    def couplers(self) -> List[str]:
        """
        Returns:
            Coupler to be calibrated. This should be a subset or equal the couplers in the device_config.toml

        """
        return self._dict.get("couplers", None)

    @property
    def cooldown(self) -> str:
        """
        Returns:
            Date of the last cooldown.

        """
        return self._dict.get("cooldown", "no_cooldown_configured")

    @property
    def name(self) -> str:
        """
        Returns:
            A name given for the run, takes target node as default if not specified
        """
        if "name" in self._dict.keys():
            return self._dict["name"]
        else:
            return self._dict["target_node"]

    @property
    def is_internal(self) -> bool:
        """
        Returns:
            flag if the plots are for internal use or not.

        """
        return self._dict.get("is_internal", True)

    @property
    def runner_logo(self) -> str:
        """
        Returns:
            Path to the logo to be used in the runner.

        """
        return self._dict.get("runner_logo", None)
