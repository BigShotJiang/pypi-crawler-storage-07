---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: XkunW

---

### Describe the bug
A clear and concise description of what the bug is.

### To Reproduce
Code snippet or clear steps to reproduce behaviour.

### Expected behavior
A clear and concise description of what you expected to happen.

### Screenshots
If applicable, add screenshots to help explain your problem.

### Version
 - Version info such as v0.1.5

### Additional context
Add any other context about the problem here.
