# tabwrap/config/__init__.py
"""Configuration and setup."""

from .logging import setup_logging

__all__ = [
    "setup_logging",
]
