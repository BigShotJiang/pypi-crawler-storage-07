# flake8: noqa

# import apis into api package
from perigon.api.supplemental_endpoints_api import SupplementalEndpointsApi
from perigon.api.v1_api import V1Api
