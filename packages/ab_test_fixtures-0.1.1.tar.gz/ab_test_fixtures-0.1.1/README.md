# Open Banking, Opened | Template

Template Package for Open Banking, Opened API packages.
