"""Package contains templates."""
