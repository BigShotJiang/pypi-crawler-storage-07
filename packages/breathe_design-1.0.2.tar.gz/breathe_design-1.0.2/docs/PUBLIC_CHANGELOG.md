# Changelog

## [1.0.2] - 25/09/2025

### Fixed

- fixed possible timeout when running a large number of simulations at once


## [1.0.0] - 16/09/2025

- Breathe Design is released.
