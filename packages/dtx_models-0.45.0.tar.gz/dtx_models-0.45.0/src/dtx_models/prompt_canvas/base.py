from pydantic import BaseModel


# --- Base Class for Prompt Canvas Objects ---

class PromptCanvasBase(BaseModel):
    """
    A base model for all Prompt Canvas objects.
    """
    pass