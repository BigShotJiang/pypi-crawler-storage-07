from setuptools import setup, find_packages

# Чтение содержимого README.md для длинного описания
with open('README.md', 'r', encoding='utf-8') as f:
    long_description = f.read()

setup(
    # Имя, которое пользователь будет вводить: pip install brainmesh-ai
    name='brainmesh-ai',
    version='0.1.0',
    description='A RAG client for personalized AI knowledge bases powered by Ollama.',
    long_description=long_description,
    long_description_content_type='text/markdown',
    license='MIT',
    author='Your Name',
    url='https://github.com/yourusername/brainmesh-ai',
    # Ищем пакет, который мы импортируем: import brainmesh_ai_pkg
    packages=find_packages(),
    install_requires=[
        'requests>=2.28.1',
        'chromadb>=0.4.15',
        'sentence-transformers>=2.2.2',
        # Дополнительно: чтобы ChromaDB мог работать
        'numpy>=1.22.0',
    ],
    classifiers=[
        'Programming Language :: Python :: 3',
        'Operating System :: OS Independent',
        'Topic :: Scientific/Engineering :: Artificial Intelligence',
    ],
    python_requires='>=3.8',
)
