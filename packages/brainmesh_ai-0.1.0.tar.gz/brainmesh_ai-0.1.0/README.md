🧠 BrainMesh AI Client
BrainMesh AI — это Python-клиент, предназначенный для взаимодействия с персонализированными базами знаний (RAG), созданными вашим Telegram-ботом.

Этот клиент позволяет запускать вашего индивидуально настроенного ИИ-сотрудника локально, используя Ollama для генерации ответов и ChromaDB для поиска контекста в ваших документах.

🚀 Установка
Для установки клиента используйте pip:

pip install brainmesh-ai

⚙️ Предварительные требования
Для работы клиента необходимо, чтобы на вашем компьютере были установлены и запущены:

Ollama: Должен быть запущен на http://localhost:11434.

Модель Llama 3: Убедитесь, что вы скачали модель llama3 через Ollama:

ollama pull llama3

💡 Использование
Экспорт данных: Получите ZIP-архив с базой знаний (памятью) из Telegram-бота (команда /export).

Скрипт: Используйте следующие шаги в вашем Python-коде:

from brainmesh_ai_pkg import EmployeeRAGClient, unpack_and_get_path
import os
import shutil

# 1. Определите путь к ZIP-файлу, который вы скачали из Telegram
ZIP_PATH = "path/to/ai_knowledge_12345.zip"
TEMP_DIR = "temp_rag_data" # Временная папка для распаковки

# 2. Распаковка архива и получение пути к базе данных ChromaDB
try:
    db_folder_path = unpack_and_get_path(ZIP_PATH, destination_dir=TEMP_DIR)
    print(f"База знаний распакована в: {db_folder_path}")

    # 3. Инициализация клиента
    client = EmployeeRAGClient(data_path=db_folder_path)

    # 4. Запрос к ИИ-сотруднику
    query = "Какие основные пункты моего рабочего регламента?"
    response = client.query_employee(query)
    
    print("\n--- ОТВЕТ ИИ-СОТРУДНИКА ---")
    print(response)

except Exception as e:
    print(f"Произошла ошибка: {e}")

finally:
    # 5. Очистка (удаление временной папки)
    if os.path.exists(TEMP_DIR):
        shutil.rmtree(TEMP_DIR)
        print(f"\nОчистка: Временная папка {TEMP_DIR} удалена.")

🤝 Вклад в проект
Мы приветствуем Pull Requests и сообщения об ошибках. Пожалуйста, посетите наш GitHub репозиторий для получения дополнительной информации.