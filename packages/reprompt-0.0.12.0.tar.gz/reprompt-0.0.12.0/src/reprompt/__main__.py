"""Main entry point for reprompt CLI."""

from .cli import app

if __name__ == "__main__":
    app()
