def f()
        return True
