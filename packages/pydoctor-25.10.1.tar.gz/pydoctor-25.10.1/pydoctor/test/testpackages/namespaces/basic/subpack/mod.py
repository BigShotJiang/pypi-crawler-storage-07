
class C:
    """Class docstring."""
    