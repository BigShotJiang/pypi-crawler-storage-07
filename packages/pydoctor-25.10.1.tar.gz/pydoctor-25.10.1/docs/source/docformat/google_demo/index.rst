Google-style demo package
=========================
