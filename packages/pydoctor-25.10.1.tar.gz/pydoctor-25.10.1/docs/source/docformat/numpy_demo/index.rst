Numpy-style demo package
========================
