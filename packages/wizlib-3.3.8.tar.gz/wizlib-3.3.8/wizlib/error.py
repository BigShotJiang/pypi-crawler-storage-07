class ConfigHandlerError(Exception):
    pass
