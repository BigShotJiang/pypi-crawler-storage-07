import values as vals 
import functions as fn
no = fn.getin("Enter any number: ")
noNeg = no*vals.iSquare
fn.out(f"Negative of {no} is {noNeg}")