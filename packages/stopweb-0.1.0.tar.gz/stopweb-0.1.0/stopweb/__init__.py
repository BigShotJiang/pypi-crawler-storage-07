"""
StopWeb - A CLI tool to temporarily block websites
"""

__version__ = "0.2.0"
__author__ = "StopWeb"
__email__ = "stopweb@example.com"
