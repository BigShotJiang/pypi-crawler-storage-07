"""VCP CLI test package."""
