# -*- coding: utf-8 -*-

from .caster import proton_caster

caster = proton_caster

__version__ = "1.40.0"