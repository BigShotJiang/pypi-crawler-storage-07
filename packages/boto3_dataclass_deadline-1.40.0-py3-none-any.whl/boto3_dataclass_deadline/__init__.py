# -*- coding: utf-8 -*-

from .caster import deadline_caster

caster = deadline_caster

__version__ = "1.40.0"