__version__ = "0.15.0"


def get_version() -> str:
    return __version__
