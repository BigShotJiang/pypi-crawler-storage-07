from typing import Optional, List
import logging

from .....domain.agents.interfaces.llm_embedding_repository import LlmEmbeddingRepository
from .base_huggingface_repository import BaseHuggingFaceRepository


class HuggingFaceEmbeddingRepository(BaseHuggingFaceRepository, LlmEmbeddingRepository):
    """
    Repository for creating embeddings using the Hugging Face Inference API.
    """

    def __init__(self, api_url: str, model_name: str, api_token: str = None, timeout: int = None):
        super().__init__(api_url, model_name, api_token, timeout)
        self.logger = logging.getLogger(__name__)

    def embed(self, text: str) -> Optional[List[float]]:
        payload = {
            "model": self.model_name,
            "input": text
        }
        endpoint = "feature_extraction"

        self.logger.info(f"Creating embedding with model {self.model_name}")
        response_data = self.http_client.post(endpoint, payload)
        if response_data:
            embedding = response_data.get("embedding")
            if embedding:
                self.logger.info("Embedding created successfully")
                self.logger.debug(f"Embedding vector length: {len(embedding)}")
                return embedding
            else:
                self.logger.error("Embedding response did not contain embedding data")
        else:
            self.logger.error("Failed to get response from embeddings API")

        return None
