# -*- coding: utf-8 -*-

from .caster import resiliencehub_caster

caster = resiliencehub_caster

__version__ = "1.40.0"