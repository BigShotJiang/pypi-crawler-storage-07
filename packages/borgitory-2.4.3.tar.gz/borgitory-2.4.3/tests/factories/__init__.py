"""
Tests for protocol-based service factories.
"""
