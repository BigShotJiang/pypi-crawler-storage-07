# -*- coding: utf-8 -*-

from .caster import lakeformation_caster

caster = lakeformation_caster

__version__ = "1.40.0"