# -*- coding: utf-8 -*-

from .caster import chime_sdk_voice_caster

caster = chime_sdk_voice_caster

__version__ = "1.40.0"