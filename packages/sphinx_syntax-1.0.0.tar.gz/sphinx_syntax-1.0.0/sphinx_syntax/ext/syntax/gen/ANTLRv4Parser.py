# Generated from ANTLRv4Parser.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,77,652,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,39,
        2,40,7,40,2,41,7,41,2,42,7,42,2,43,7,43,2,44,7,44,2,45,7,45,2,46,
        7,46,2,47,7,47,2,48,7,48,2,49,7,49,2,50,7,50,2,51,7,51,2,52,7,52,
        2,53,7,53,2,54,7,54,2,55,7,55,2,56,7,56,2,57,7,57,2,58,7,58,2,59,
        7,59,2,60,7,60,1,0,5,0,124,8,0,10,0,12,0,127,9,0,1,0,1,0,1,0,1,0,
        5,0,133,8,0,10,0,12,0,136,9,0,1,0,1,0,5,0,140,8,0,10,0,12,0,143,
        9,0,1,0,1,0,1,1,1,1,1,1,1,1,1,1,3,1,152,8,1,1,2,1,2,1,2,1,2,1,2,
        3,2,159,8,2,1,3,1,3,1,3,1,3,5,3,165,8,3,10,3,12,3,168,9,3,1,3,1,
        3,1,4,1,4,1,4,1,4,1,5,1,5,1,5,5,5,179,8,5,10,5,12,5,182,9,5,1,5,
        1,5,1,5,3,5,187,8,5,1,6,1,6,1,6,1,6,5,6,193,8,6,10,6,12,6,196,9,
        6,1,6,1,6,1,7,1,7,1,8,1,8,1,8,1,8,5,8,206,8,8,10,8,12,8,209,9,8,
        1,8,3,8,212,8,8,1,8,1,8,1,9,5,9,217,8,9,10,9,12,9,220,9,9,1,9,5,
        9,223,8,9,10,9,12,9,226,9,9,1,9,1,9,1,10,1,10,1,10,1,10,5,10,234,
        8,10,10,10,12,10,237,9,10,1,10,3,10,240,8,10,1,10,1,10,1,11,1,11,
        1,11,1,11,3,11,248,8,11,1,11,1,11,1,11,1,12,1,12,1,12,3,12,256,8,
        12,1,13,1,13,5,13,260,8,13,10,13,12,13,263,9,13,1,13,1,13,1,14,1,
        14,5,14,269,8,14,10,14,12,14,272,9,14,1,14,1,14,1,15,1,15,1,15,1,
        15,5,15,280,8,15,10,15,12,15,283,9,15,1,16,5,16,286,8,16,10,16,12,
        16,289,9,16,1,17,5,17,292,8,17,10,17,12,17,295,9,17,1,17,1,17,3,
        17,299,8,17,1,18,5,18,302,8,18,10,18,12,18,305,9,18,1,18,3,18,308,
        8,18,1,18,1,18,3,18,312,8,18,1,18,3,18,315,8,18,1,18,3,18,318,8,
        18,1,18,3,18,321,8,18,1,18,5,18,324,8,18,10,18,12,18,327,9,18,1,
        18,1,18,1,18,1,18,1,18,1,19,5,19,335,8,19,10,19,12,19,338,9,19,1,
        19,3,19,341,8,19,1,20,1,20,1,20,1,20,1,21,1,21,1,21,1,22,1,22,3,
        22,352,8,22,1,23,1,23,1,23,1,24,1,24,1,24,1,24,5,24,361,8,24,10,
        24,12,24,364,9,24,1,25,1,25,1,25,1,26,1,26,1,26,1,26,1,27,4,27,374,
        8,27,11,27,12,27,375,1,28,1,28,1,29,1,29,1,30,1,30,1,30,5,30,385,
        8,30,10,30,12,30,388,9,30,1,31,1,31,1,31,3,31,393,8,31,1,32,5,32,
        396,8,32,10,32,12,32,399,9,32,1,32,3,32,402,8,32,1,32,1,32,1,32,
        1,32,1,32,1,33,1,33,1,34,1,34,1,34,5,34,414,8,34,10,34,12,34,417,
        9,34,1,35,1,35,3,35,421,8,35,1,35,3,35,424,8,35,1,36,4,36,427,8,
        36,11,36,12,36,428,1,37,1,37,3,37,433,8,37,1,37,1,37,3,37,437,8,
        37,1,37,1,37,3,37,441,8,37,1,37,1,37,3,37,445,8,37,3,37,447,8,37,
        1,38,1,38,1,38,1,38,3,38,453,8,38,1,39,1,39,1,39,1,39,1,40,1,40,
        1,40,1,40,5,40,463,8,40,10,40,12,40,466,9,40,1,41,1,41,1,41,1,41,
        1,41,1,41,3,41,474,8,41,1,42,1,42,3,42,478,8,42,1,43,1,43,3,43,482,
        8,43,1,44,1,44,1,44,5,44,487,8,44,10,44,12,44,490,9,44,1,45,3,45,
        493,8,45,1,45,4,45,496,8,45,11,45,12,45,497,1,45,3,45,501,8,45,1,
        46,1,46,3,46,505,8,46,1,46,1,46,3,46,509,8,46,1,46,1,46,3,46,513,
        8,46,1,46,1,46,3,46,517,8,46,1,46,3,46,520,8,46,1,47,1,47,1,47,1,
        47,3,47,526,8,47,1,48,1,48,3,48,530,8,48,1,48,1,48,3,48,534,8,48,
        1,48,1,48,3,48,538,8,48,3,48,540,8,48,1,49,1,49,1,49,1,49,1,49,1,
        49,3,49,548,8,49,1,49,3,49,551,8,49,1,50,1,50,1,50,1,50,1,50,3,50,
        558,8,50,3,50,560,8,50,1,51,1,51,1,51,1,51,3,51,566,8,51,1,52,1,
        52,1,52,1,52,5,52,572,8,52,10,52,12,52,575,9,52,1,52,1,52,1,53,1,
        53,3,53,581,8,53,1,53,1,53,3,53,585,8,53,1,53,1,53,3,53,589,8,53,
        1,54,1,54,3,54,593,8,54,1,54,5,54,596,8,54,10,54,12,54,599,9,54,
        1,54,3,54,602,8,54,1,54,1,54,1,54,1,55,1,55,3,55,609,8,55,1,55,3,
        55,612,8,55,1,56,1,56,1,56,1,56,1,57,1,57,3,57,620,8,57,1,57,1,57,
        3,57,624,8,57,3,57,626,8,57,1,58,1,58,1,58,1,58,5,58,632,8,58,10,
        58,12,58,635,9,58,1,58,1,58,1,59,1,59,1,59,1,59,1,59,3,59,644,8,
        59,3,59,646,8,59,1,60,1,60,3,60,650,8,60,1,60,0,0,61,0,2,4,6,8,10,
        12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,
        56,58,60,62,64,66,68,70,72,74,76,78,80,82,84,86,88,90,92,94,96,98,
        100,102,104,106,108,110,112,114,116,118,120,0,2,2,0,18,18,22,24,
        2,0,41,41,44,44,699,0,125,1,0,0,0,2,151,1,0,0,0,4,158,1,0,0,0,6,
        160,1,0,0,0,8,171,1,0,0,0,10,186,1,0,0,0,12,188,1,0,0,0,14,199,1,
        0,0,0,16,201,1,0,0,0,18,218,1,0,0,0,20,229,1,0,0,0,22,243,1,0,0,
        0,24,255,1,0,0,0,26,257,1,0,0,0,28,266,1,0,0,0,30,275,1,0,0,0,32,
        287,1,0,0,0,34,293,1,0,0,0,36,303,1,0,0,0,38,336,1,0,0,0,40,342,
        1,0,0,0,42,346,1,0,0,0,44,351,1,0,0,0,46,353,1,0,0,0,48,356,1,0,
        0,0,50,365,1,0,0,0,52,368,1,0,0,0,54,373,1,0,0,0,56,377,1,0,0,0,
        58,379,1,0,0,0,60,381,1,0,0,0,62,389,1,0,0,0,64,397,1,0,0,0,66,408,
        1,0,0,0,68,410,1,0,0,0,70,423,1,0,0,0,72,426,1,0,0,0,74,446,1,0,
        0,0,76,448,1,0,0,0,78,454,1,0,0,0,80,458,1,0,0,0,82,473,1,0,0,0,
        84,477,1,0,0,0,86,481,1,0,0,0,88,483,1,0,0,0,90,500,1,0,0,0,92,519,
        1,0,0,0,94,521,1,0,0,0,96,539,1,0,0,0,98,550,1,0,0,0,100,559,1,0,
        0,0,102,565,1,0,0,0,104,567,1,0,0,0,106,588,1,0,0,0,108,590,1,0,
        0,0,110,606,1,0,0,0,112,613,1,0,0,0,114,625,1,0,0,0,116,627,1,0,
        0,0,118,645,1,0,0,0,120,649,1,0,0,0,122,124,5,5,0,0,123,122,1,0,
        0,0,124,127,1,0,0,0,125,123,1,0,0,0,125,126,1,0,0,0,126,128,1,0,
        0,0,127,125,1,0,0,0,128,129,3,2,1,0,129,130,3,120,60,0,130,134,5,
        34,0,0,131,133,3,4,2,0,132,131,1,0,0,0,133,136,1,0,0,0,134,132,1,
        0,0,0,134,135,1,0,0,0,135,137,1,0,0,0,136,134,1,0,0,0,137,141,3,
        32,16,0,138,140,3,30,15,0,139,138,1,0,0,0,140,143,1,0,0,0,141,139,
        1,0,0,0,141,142,1,0,0,0,142,144,1,0,0,0,143,141,1,0,0,0,144,145,
        5,0,0,1,145,1,1,0,0,0,146,147,5,19,0,0,147,152,5,21,0,0,148,149,
        5,20,0,0,149,152,5,21,0,0,150,152,5,21,0,0,151,146,1,0,0,0,151,148,
        1,0,0,0,151,150,1,0,0,0,152,3,1,0,0,0,153,159,3,6,3,0,154,159,3,
        12,6,0,155,159,3,16,8,0,156,159,3,20,10,0,157,159,3,22,11,0,158,
        153,1,0,0,0,158,154,1,0,0,0,158,155,1,0,0,0,158,156,1,0,0,0,158,
        157,1,0,0,0,159,5,1,0,0,0,160,166,5,14,0,0,161,162,3,8,4,0,162,163,
        5,34,0,0,163,165,1,0,0,0,164,161,1,0,0,0,165,168,1,0,0,0,166,164,
        1,0,0,0,166,167,1,0,0,0,167,169,1,0,0,0,168,166,1,0,0,0,169,170,
        5,37,0,0,170,7,1,0,0,0,171,172,3,120,60,0,172,173,5,41,0,0,173,174,
        3,10,5,0,174,9,1,0,0,0,175,180,3,120,60,0,176,177,5,49,0,0,177,179,
        3,120,60,0,178,176,1,0,0,0,179,182,1,0,0,0,180,178,1,0,0,0,180,181,
        1,0,0,0,181,187,1,0,0,0,182,180,1,0,0,0,183,187,5,10,0,0,184,187,
        3,26,13,0,185,187,5,9,0,0,186,175,1,0,0,0,186,183,1,0,0,0,186,184,
        1,0,0,0,186,185,1,0,0,0,187,11,1,0,0,0,188,189,5,17,0,0,189,194,
        3,14,7,0,190,191,5,33,0,0,191,193,3,14,7,0,192,190,1,0,0,0,193,196,
        1,0,0,0,194,192,1,0,0,0,194,195,1,0,0,0,195,197,1,0,0,0,196,194,
        1,0,0,0,197,198,5,34,0,0,198,13,1,0,0,0,199,200,3,120,60,0,200,15,
        1,0,0,0,201,202,5,15,0,0,202,207,3,18,9,0,203,204,5,33,0,0,204,206,
        3,18,9,0,205,203,1,0,0,0,206,209,1,0,0,0,207,205,1,0,0,0,207,208,
        1,0,0,0,208,211,1,0,0,0,209,207,1,0,0,0,210,212,5,33,0,0,211,210,
        1,0,0,0,211,212,1,0,0,0,212,213,1,0,0,0,213,214,5,37,0,0,214,17,
        1,0,0,0,215,217,5,6,0,0,216,215,1,0,0,0,217,220,1,0,0,0,218,216,
        1,0,0,0,218,219,1,0,0,0,219,224,1,0,0,0,220,218,1,0,0,0,221,223,
        5,5,0,0,222,221,1,0,0,0,223,226,1,0,0,0,224,222,1,0,0,0,224,225,
        1,0,0,0,225,227,1,0,0,0,226,224,1,0,0,0,227,228,3,120,60,0,228,19,
        1,0,0,0,229,230,5,16,0,0,230,235,3,120,60,0,231,232,5,33,0,0,232,
        234,3,120,60,0,233,231,1,0,0,0,234,237,1,0,0,0,235,233,1,0,0,0,235,
        236,1,0,0,0,236,239,1,0,0,0,237,235,1,0,0,0,238,240,5,33,0,0,239,
        238,1,0,0,0,239,240,1,0,0,0,240,241,1,0,0,0,241,242,5,37,0,0,242,
        21,1,0,0,0,243,247,5,50,0,0,244,245,3,24,12,0,245,246,5,32,0,0,246,
        248,1,0,0,0,247,244,1,0,0,0,247,248,1,0,0,0,248,249,1,0,0,0,249,
        250,3,120,60,0,250,251,3,26,13,0,251,23,1,0,0,0,252,256,3,120,60,
        0,253,256,5,19,0,0,254,256,5,20,0,0,255,252,1,0,0,0,255,253,1,0,
        0,0,255,254,1,0,0,0,256,25,1,0,0,0,257,261,5,13,0,0,258,260,3,26,
        13,0,259,258,1,0,0,0,260,263,1,0,0,0,261,259,1,0,0,0,261,262,1,0,
        0,0,262,264,1,0,0,0,263,261,1,0,0,0,264,265,5,67,0,0,265,27,1,0,
        0,0,266,270,5,12,0,0,267,269,3,28,14,0,268,267,1,0,0,0,269,272,1,
        0,0,0,270,268,1,0,0,0,270,271,1,0,0,0,271,273,1,0,0,0,272,270,1,
        0,0,0,273,274,5,59,0,0,274,29,1,0,0,0,275,276,5,30,0,0,276,277,3,
        120,60,0,277,281,5,34,0,0,278,280,3,64,32,0,279,278,1,0,0,0,280,
        283,1,0,0,0,281,279,1,0,0,0,281,282,1,0,0,0,282,31,1,0,0,0,283,281,
        1,0,0,0,284,286,3,34,17,0,285,284,1,0,0,0,286,289,1,0,0,0,287,285,
        1,0,0,0,287,288,1,0,0,0,288,33,1,0,0,0,289,287,1,0,0,0,290,292,5,
        6,0,0,291,290,1,0,0,0,292,295,1,0,0,0,293,291,1,0,0,0,293,294,1,
        0,0,0,294,298,1,0,0,0,295,293,1,0,0,0,296,299,3,36,18,0,297,299,
        3,64,32,0,298,296,1,0,0,0,298,297,1,0,0,0,299,35,1,0,0,0,300,302,
        5,5,0,0,301,300,1,0,0,0,302,305,1,0,0,0,303,301,1,0,0,0,303,304,
        1,0,0,0,304,307,1,0,0,0,305,303,1,0,0,0,306,308,3,54,27,0,307,306,
        1,0,0,0,307,308,1,0,0,0,308,309,1,0,0,0,309,311,5,2,0,0,310,312,
        3,28,14,0,311,310,1,0,0,0,311,312,1,0,0,0,312,314,1,0,0,0,313,315,
        3,46,23,0,314,313,1,0,0,0,314,315,1,0,0,0,315,317,1,0,0,0,316,318,
        3,48,24,0,317,316,1,0,0,0,317,318,1,0,0,0,318,320,1,0,0,0,319,321,
        3,50,25,0,320,319,1,0,0,0,320,321,1,0,0,0,321,325,1,0,0,0,322,324,
        3,44,22,0,323,322,1,0,0,0,324,327,1,0,0,0,325,323,1,0,0,0,325,326,
        1,0,0,0,326,328,1,0,0,0,327,325,1,0,0,0,328,329,5,31,0,0,329,330,
        3,58,29,0,330,331,5,34,0,0,331,332,3,38,19,0,332,37,1,0,0,0,333,
        335,3,40,20,0,334,333,1,0,0,0,335,338,1,0,0,0,336,334,1,0,0,0,336,
        337,1,0,0,0,337,340,1,0,0,0,338,336,1,0,0,0,339,341,3,42,21,0,340,
        339,1,0,0,0,340,341,1,0,0,0,341,39,1,0,0,0,342,343,5,28,0,0,343,
        344,3,28,14,0,344,345,3,26,13,0,345,41,1,0,0,0,346,347,5,29,0,0,
        347,348,3,26,13,0,348,43,1,0,0,0,349,352,3,6,3,0,350,352,3,52,26,
        0,351,349,1,0,0,0,351,350,1,0,0,0,352,45,1,0,0,0,353,354,5,25,0,
        0,354,355,3,28,14,0,355,47,1,0,0,0,356,357,5,27,0,0,357,362,3,120,
        60,0,358,359,5,33,0,0,359,361,3,120,60,0,360,358,1,0,0,0,361,364,
        1,0,0,0,362,360,1,0,0,0,362,363,1,0,0,0,363,49,1,0,0,0,364,362,1,
        0,0,0,365,366,5,26,0,0,366,367,3,28,14,0,367,51,1,0,0,0,368,369,
        5,50,0,0,369,370,3,120,60,0,370,371,3,26,13,0,371,53,1,0,0,0,372,
        374,3,56,28,0,373,372,1,0,0,0,374,375,1,0,0,0,375,373,1,0,0,0,375,
        376,1,0,0,0,376,55,1,0,0,0,377,378,7,0,0,0,378,57,1,0,0,0,379,380,
        3,60,30,0,380,59,1,0,0,0,381,386,3,62,31,0,382,383,5,46,0,0,383,
        385,3,62,31,0,384,382,1,0,0,0,385,388,1,0,0,0,386,384,1,0,0,0,386,
        387,1,0,0,0,387,61,1,0,0,0,388,386,1,0,0,0,389,392,3,90,45,0,390,
        391,5,51,0,0,391,393,3,120,60,0,392,390,1,0,0,0,392,393,1,0,0,0,
        393,63,1,0,0,0,394,396,5,5,0,0,395,394,1,0,0,0,396,399,1,0,0,0,397,
        395,1,0,0,0,397,398,1,0,0,0,398,401,1,0,0,0,399,397,1,0,0,0,400,
        402,5,18,0,0,401,400,1,0,0,0,401,402,1,0,0,0,402,403,1,0,0,0,403,
        404,5,1,0,0,404,405,5,31,0,0,405,406,3,66,33,0,406,407,5,34,0,0,
        407,65,1,0,0,0,408,409,3,68,34,0,409,67,1,0,0,0,410,415,3,70,35,
        0,411,412,5,46,0,0,412,414,3,70,35,0,413,411,1,0,0,0,414,417,1,0,
        0,0,415,413,1,0,0,0,415,416,1,0,0,0,416,69,1,0,0,0,417,415,1,0,0,
        0,418,420,3,72,36,0,419,421,3,80,40,0,420,419,1,0,0,0,420,421,1,
        0,0,0,421,424,1,0,0,0,422,424,1,0,0,0,423,418,1,0,0,0,423,422,1,
        0,0,0,424,71,1,0,0,0,425,427,3,74,37,0,426,425,1,0,0,0,427,428,1,
        0,0,0,428,426,1,0,0,0,428,429,1,0,0,0,429,73,1,0,0,0,430,432,3,76,
        38,0,431,433,3,96,48,0,432,431,1,0,0,0,432,433,1,0,0,0,433,447,1,
        0,0,0,434,436,3,98,49,0,435,437,3,96,48,0,436,435,1,0,0,0,436,437,
        1,0,0,0,437,447,1,0,0,0,438,440,3,78,39,0,439,441,3,96,48,0,440,
        439,1,0,0,0,440,441,1,0,0,0,441,447,1,0,0,0,442,444,3,26,13,0,443,
        445,5,42,0,0,444,443,1,0,0,0,444,445,1,0,0,0,445,447,1,0,0,0,446,
        430,1,0,0,0,446,434,1,0,0,0,446,438,1,0,0,0,446,442,1,0,0,0,447,
        75,1,0,0,0,448,449,3,120,60,0,449,452,7,1,0,0,450,453,3,98,49,0,
        451,453,3,78,39,0,452,450,1,0,0,0,452,451,1,0,0,0,453,77,1,0,0,0,
        454,455,5,35,0,0,455,456,3,68,34,0,456,457,5,36,0,0,457,79,1,0,0,
        0,458,459,5,38,0,0,459,464,3,82,41,0,460,461,5,33,0,0,461,463,3,
        82,41,0,462,460,1,0,0,0,463,466,1,0,0,0,464,462,1,0,0,0,464,465,
        1,0,0,0,465,81,1,0,0,0,466,464,1,0,0,0,467,468,3,84,42,0,468,469,
        5,35,0,0,469,470,3,86,43,0,470,471,5,36,0,0,471,474,1,0,0,0,472,
        474,3,84,42,0,473,467,1,0,0,0,473,472,1,0,0,0,474,83,1,0,0,0,475,
        478,3,120,60,0,476,478,5,30,0,0,477,475,1,0,0,0,477,476,1,0,0,0,
        478,85,1,0,0,0,479,482,3,120,60,0,480,482,5,9,0,0,481,479,1,0,0,
        0,481,480,1,0,0,0,482,87,1,0,0,0,483,488,3,90,45,0,484,485,5,46,
        0,0,485,487,3,90,45,0,486,484,1,0,0,0,487,490,1,0,0,0,488,486,1,
        0,0,0,488,489,1,0,0,0,489,89,1,0,0,0,490,488,1,0,0,0,491,493,3,116,
        58,0,492,491,1,0,0,0,492,493,1,0,0,0,493,495,1,0,0,0,494,496,3,92,
        46,0,495,494,1,0,0,0,496,497,1,0,0,0,497,495,1,0,0,0,497,498,1,0,
        0,0,498,501,1,0,0,0,499,501,1,0,0,0,500,492,1,0,0,0,500,499,1,0,
        0,0,501,91,1,0,0,0,502,504,3,94,47,0,503,505,3,96,48,0,504,503,1,
        0,0,0,504,505,1,0,0,0,505,520,1,0,0,0,506,508,3,100,50,0,507,509,
        3,96,48,0,508,507,1,0,0,0,508,509,1,0,0,0,509,520,1,0,0,0,510,512,
        3,108,54,0,511,513,3,96,48,0,512,511,1,0,0,0,512,513,1,0,0,0,513,
        520,1,0,0,0,514,516,3,26,13,0,515,517,5,42,0,0,516,515,1,0,0,0,516,
        517,1,0,0,0,517,520,1,0,0,0,518,520,5,5,0,0,519,502,1,0,0,0,519,
        506,1,0,0,0,519,510,1,0,0,0,519,514,1,0,0,0,519,518,1,0,0,0,520,
        93,1,0,0,0,521,522,3,120,60,0,522,525,7,1,0,0,523,526,3,100,50,0,
        524,526,3,108,54,0,525,523,1,0,0,0,525,524,1,0,0,0,526,95,1,0,0,
        0,527,529,5,42,0,0,528,530,5,42,0,0,529,528,1,0,0,0,529,530,1,0,
        0,0,530,540,1,0,0,0,531,533,5,43,0,0,532,534,5,42,0,0,533,532,1,
        0,0,0,533,534,1,0,0,0,534,540,1,0,0,0,535,537,5,45,0,0,536,538,5,
        42,0,0,537,536,1,0,0,0,537,538,1,0,0,0,538,540,1,0,0,0,539,527,1,
        0,0,0,539,531,1,0,0,0,539,535,1,0,0,0,540,97,1,0,0,0,541,551,3,112,
        56,0,542,551,3,114,57,0,543,551,3,102,51,0,544,551,5,3,0,0,545,547,
        5,49,0,0,546,548,3,116,58,0,547,546,1,0,0,0,547,548,1,0,0,0,548,
        551,1,0,0,0,549,551,5,5,0,0,550,541,1,0,0,0,550,542,1,0,0,0,550,
        543,1,0,0,0,550,544,1,0,0,0,550,545,1,0,0,0,550,549,1,0,0,0,551,
        99,1,0,0,0,552,560,3,114,57,0,553,560,3,110,55,0,554,560,3,102,51,
        0,555,557,5,49,0,0,556,558,3,116,58,0,557,556,1,0,0,0,557,558,1,
        0,0,0,558,560,1,0,0,0,559,552,1,0,0,0,559,553,1,0,0,0,559,554,1,
        0,0,0,559,555,1,0,0,0,560,101,1,0,0,0,561,562,5,52,0,0,562,566,3,
        106,53,0,563,564,5,52,0,0,564,566,3,104,52,0,565,561,1,0,0,0,565,
        563,1,0,0,0,566,103,1,0,0,0,567,568,5,35,0,0,568,573,3,106,53,0,
        569,570,5,46,0,0,570,572,3,106,53,0,571,569,1,0,0,0,572,575,1,0,
        0,0,573,571,1,0,0,0,573,574,1,0,0,0,574,576,1,0,0,0,575,573,1,0,
        0,0,576,577,5,36,0,0,577,105,1,0,0,0,578,580,5,1,0,0,579,581,3,116,
        58,0,580,579,1,0,0,0,580,581,1,0,0,0,581,589,1,0,0,0,582,584,5,10,
        0,0,583,585,3,116,58,0,584,583,1,0,0,0,584,585,1,0,0,0,585,589,1,
        0,0,0,586,589,3,112,56,0,587,589,5,3,0,0,588,578,1,0,0,0,588,582,
        1,0,0,0,588,586,1,0,0,0,588,587,1,0,0,0,589,107,1,0,0,0,590,601,
        5,35,0,0,591,593,3,6,3,0,592,591,1,0,0,0,592,593,1,0,0,0,593,597,
        1,0,0,0,594,596,3,52,26,0,595,594,1,0,0,0,596,599,1,0,0,0,597,595,
        1,0,0,0,597,598,1,0,0,0,598,600,1,0,0,0,599,597,1,0,0,0,600,602,
        5,31,0,0,601,592,1,0,0,0,601,602,1,0,0,0,602,603,1,0,0,0,603,604,
        3,88,44,0,604,605,5,36,0,0,605,109,1,0,0,0,606,608,5,2,0,0,607,609,
        3,28,14,0,608,607,1,0,0,0,608,609,1,0,0,0,609,611,1,0,0,0,610,612,
        3,116,58,0,611,610,1,0,0,0,611,612,1,0,0,0,612,111,1,0,0,0,613,614,
        5,10,0,0,614,615,5,48,0,0,615,616,5,10,0,0,616,113,1,0,0,0,617,619,
        5,1,0,0,618,620,3,116,58,0,619,618,1,0,0,0,619,620,1,0,0,0,620,626,
        1,0,0,0,621,623,5,10,0,0,622,624,3,116,58,0,623,622,1,0,0,0,623,
        624,1,0,0,0,624,626,1,0,0,0,625,617,1,0,0,0,625,621,1,0,0,0,626,
        115,1,0,0,0,627,628,5,39,0,0,628,633,3,118,59,0,629,630,5,33,0,0,
        630,632,3,118,59,0,631,629,1,0,0,0,632,635,1,0,0,0,633,631,1,0,0,
        0,633,634,1,0,0,0,634,636,1,0,0,0,635,633,1,0,0,0,636,637,5,40,0,
        0,637,117,1,0,0,0,638,646,3,120,60,0,639,640,3,120,60,0,640,643,
        5,41,0,0,641,644,3,120,60,0,642,644,5,10,0,0,643,641,1,0,0,0,643,
        642,1,0,0,0,644,646,1,0,0,0,645,638,1,0,0,0,645,639,1,0,0,0,646,
        119,1,0,0,0,647,650,5,2,0,0,648,650,5,1,0,0,649,647,1,0,0,0,649,
        648,1,0,0,0,650,121,1,0,0,0,88,125,134,141,151,158,166,180,186,194,
        207,211,218,224,235,239,247,255,261,270,281,287,293,298,303,307,
        311,314,317,320,325,336,340,351,362,375,386,392,397,401,415,420,
        423,428,432,436,440,444,446,452,464,473,477,481,488,492,497,500,
        504,508,512,516,519,525,529,533,537,539,547,550,557,559,565,573,
        580,584,588,592,597,601,608,611,619,623,625,633,643,645,649
    ]

class ANTLRv4Parser ( Parser ):

    grammarFileName = "ANTLRv4Parser.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "'['", "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "'import'", "'fragment'", "'lexer'", "'parser'", "'grammar'", 
                     "'protected'", "'public'", "'private'", "'returns'", 
                     "'locals'", "'throws'", "'catch'", "'finally'", "'mode'", 
                     "':'", "'::'", "<INVALID>", "<INVALID>", "'('", "')'", 
                     "<INVALID>", "'->'", "'<'", "'>'", "<INVALID>", "'?'", 
                     "<INVALID>", "'+='", "'+'", "'|'", "'$'", "'..'", "<INVALID>", 
                     "'@'", "'#'", "'~'" ]

    symbolicNames = [ "<INVALID>", "TOKEN_REF", "RULE_REF", "LEXER_CHAR_SET", 
                      "LBRACE", "DOC_COMMENT", "HEADER", "BLOCK_COMMENT", 
                      "LINE_COMMENT", "INT", "STRING_LITERAL", "UNTERMINATED_STRING_LITERAL", 
                      "BEGIN_ARGUMENT", "BEGIN_ACTION", "OPTIONS", "TOKENS", 
                      "CHANNELS", "IMPORT", "FRAGMENT", "LEXER", "PARSER", 
                      "GRAMMAR", "PROTECTED", "PUBLIC", "PRIVATE", "RETURNS", 
                      "LOCALS", "THROWS", "CATCH", "FINALLY", "MODE", "COLON", 
                      "COLONCOLON", "COMMA", "SEMI", "LPAREN", "RPAREN", 
                      "RBRACE", "RARROW", "LT", "GT", "ASSIGN", "QUESTION", 
                      "STAR", "PLUS_ASSIGN", "PLUS", "OR", "DOLLAR", "RANGE", 
                      "DOT", "AT", "POUND", "NOT", "ID", "WS", "ERRCHAR", 
                      "ARGUMENT_ESCAPE", "ARGUMENT_STRING_LITERAL", "ARGUMENT_CHAR_LITERAL", 
                      "END_ARGUMENT", "UNTERMINATED_ARGUMENT", "ARGUMENT_CONTENT", 
                      "ACTION_ESCAPE", "ACTION_STRING_LITERAL", "ACTION_CHAR_LITERAL", 
                      "ACTION_BLOCK_COMMENT", "ACTION_LINE_COMMENT", "END_ACTION", 
                      "UNTERMINATED_ACTION", "ACTION_CONTENT", "OPT_BLOCK_COMMENT", 
                      "OPT_LINE_COMMENT", "OPT_WS", "TOK_BLOCK_COMMENT", 
                      "TOK_LINE_COMMENT", "CHN_BLOCK_COMMENT", "CHN_LINE_COMMENT", 
                      "UNTERMINATED_CHAR_SET" ]

    RULE_grammarSpec = 0
    RULE_grammarType = 1
    RULE_prequelConstruct = 2
    RULE_optionsSpec = 3
    RULE_option = 4
    RULE_optionValue = 5
    RULE_delegateGrammars = 6
    RULE_delegateGrammar = 7
    RULE_tokensSpec = 8
    RULE_tokenSpec = 9
    RULE_channelsSpec = 10
    RULE_action = 11
    RULE_actionScopeName = 12
    RULE_actionBlock = 13
    RULE_argActionBlock = 14
    RULE_modeSpec = 15
    RULE_rules = 16
    RULE_ruleSpec = 17
    RULE_parserRuleSpec = 18
    RULE_exceptionGroup = 19
    RULE_exceptionHandler = 20
    RULE_finallyClause = 21
    RULE_rulePrequel = 22
    RULE_ruleReturns = 23
    RULE_throwsSpec = 24
    RULE_localsSpec = 25
    RULE_ruleAction = 26
    RULE_ruleModifiers = 27
    RULE_ruleModifier = 28
    RULE_ruleBlock = 29
    RULE_ruleAltList = 30
    RULE_labeledAlt = 31
    RULE_lexerRuleSpec = 32
    RULE_lexerRuleBlock = 33
    RULE_lexerAltList = 34
    RULE_lexerAlt = 35
    RULE_lexerElements = 36
    RULE_lexerElement = 37
    RULE_labeledLexerElement = 38
    RULE_lexerBlock = 39
    RULE_lexerCommands = 40
    RULE_lexerCommand = 41
    RULE_lexerCommandName = 42
    RULE_lexerCommandExpr = 43
    RULE_altList = 44
    RULE_alternative = 45
    RULE_element = 46
    RULE_labeledElement = 47
    RULE_ebnfSuffix = 48
    RULE_lexerAtom = 49
    RULE_atom = 50
    RULE_notSet = 51
    RULE_blockSet = 52
    RULE_setElement = 53
    RULE_block = 54
    RULE_ruleref = 55
    RULE_characterRange = 56
    RULE_terminal = 57
    RULE_elementOptions = 58
    RULE_elementOption = 59
    RULE_identifier = 60

    ruleNames =  [ "grammarSpec", "grammarType", "prequelConstruct", "optionsSpec", 
                   "option", "optionValue", "delegateGrammars", "delegateGrammar", 
                   "tokensSpec", "tokenSpec", "channelsSpec", "action", 
                   "actionScopeName", "actionBlock", "argActionBlock", "modeSpec", 
                   "rules", "ruleSpec", "parserRuleSpec", "exceptionGroup", 
                   "exceptionHandler", "finallyClause", "rulePrequel", "ruleReturns", 
                   "throwsSpec", "localsSpec", "ruleAction", "ruleModifiers", 
                   "ruleModifier", "ruleBlock", "ruleAltList", "labeledAlt", 
                   "lexerRuleSpec", "lexerRuleBlock", "lexerAltList", "lexerAlt", 
                   "lexerElements", "lexerElement", "labeledLexerElement", 
                   "lexerBlock", "lexerCommands", "lexerCommand", "lexerCommandName", 
                   "lexerCommandExpr", "altList", "alternative", "element", 
                   "labeledElement", "ebnfSuffix", "lexerAtom", "atom", 
                   "notSet", "blockSet", "setElement", "block", "ruleref", 
                   "characterRange", "terminal", "elementOptions", "elementOption", 
                   "identifier" ]

    EOF = Token.EOF
    TOKEN_REF=1
    RULE_REF=2
    LEXER_CHAR_SET=3
    LBRACE=4
    DOC_COMMENT=5
    HEADER=6
    BLOCK_COMMENT=7
    LINE_COMMENT=8
    INT=9
    STRING_LITERAL=10
    UNTERMINATED_STRING_LITERAL=11
    BEGIN_ARGUMENT=12
    BEGIN_ACTION=13
    OPTIONS=14
    TOKENS=15
    CHANNELS=16
    IMPORT=17
    FRAGMENT=18
    LEXER=19
    PARSER=20
    GRAMMAR=21
    PROTECTED=22
    PUBLIC=23
    PRIVATE=24
    RETURNS=25
    LOCALS=26
    THROWS=27
    CATCH=28
    FINALLY=29
    MODE=30
    COLON=31
    COLONCOLON=32
    COMMA=33
    SEMI=34
    LPAREN=35
    RPAREN=36
    RBRACE=37
    RARROW=38
    LT=39
    GT=40
    ASSIGN=41
    QUESTION=42
    STAR=43
    PLUS_ASSIGN=44
    PLUS=45
    OR=46
    DOLLAR=47
    RANGE=48
    DOT=49
    AT=50
    POUND=51
    NOT=52
    ID=53
    WS=54
    ERRCHAR=55
    ARGUMENT_ESCAPE=56
    ARGUMENT_STRING_LITERAL=57
    ARGUMENT_CHAR_LITERAL=58
    END_ARGUMENT=59
    UNTERMINATED_ARGUMENT=60
    ARGUMENT_CONTENT=61
    ACTION_ESCAPE=62
    ACTION_STRING_LITERAL=63
    ACTION_CHAR_LITERAL=64
    ACTION_BLOCK_COMMENT=65
    ACTION_LINE_COMMENT=66
    END_ACTION=67
    UNTERMINATED_ACTION=68
    ACTION_CONTENT=69
    OPT_BLOCK_COMMENT=70
    OPT_LINE_COMMENT=71
    OPT_WS=72
    TOK_BLOCK_COMMENT=73
    TOK_LINE_COMMENT=74
    CHN_BLOCK_COMMENT=75
    CHN_LINE_COMMENT=76
    UNTERMINATED_CHAR_SET=77

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class GrammarSpecContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._DOC_COMMENT = None # type: Token
            self.docs = list() # type: list[Token]
            self.gtype = None # type: ANTLRv4Parser.GrammarTypeContext
            self.gname = None # type: ANTLRv4Parser.IdentifierContext

        def SEMI(self):
            return self.getToken(ANTLRv4Parser.SEMI, 0)

        def rules(self):
            return self.getTypedRuleContext(ANTLRv4Parser.RulesContext,0)


        def EOF(self):
            return self.getToken(ANTLRv4Parser.EOF, 0)

        def grammarType(self):
            return self.getTypedRuleContext(ANTLRv4Parser.GrammarTypeContext,0)


        def identifier(self):
            return self.getTypedRuleContext(ANTLRv4Parser.IdentifierContext,0)


        def prequelConstruct(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ANTLRv4Parser.PrequelConstructContext)
            else:
                return self.getTypedRuleContext(ANTLRv4Parser.PrequelConstructContext,i)


        def modeSpec(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ANTLRv4Parser.ModeSpecContext)
            else:
                return self.getTypedRuleContext(ANTLRv4Parser.ModeSpecContext,i)


        def DOC_COMMENT(self, i:int=None):
            if i is None:
                return self.getTokens(ANTLRv4Parser.DOC_COMMENT)
            else:
                return self.getToken(ANTLRv4Parser.DOC_COMMENT, i)

        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_grammarSpec

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGrammarSpec" ):
                listener.enterGrammarSpec(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGrammarSpec" ):
                listener.exitGrammarSpec(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitGrammarSpec" ):
                return visitor.visitGrammarSpec(self)
            else:
                return visitor.visitChildren(self)




    def grammarSpec(self):

        localctx = ANTLRv4Parser.GrammarSpecContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_grammarSpec)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 125
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==5:
                self.state = 122
                localctx._DOC_COMMENT = self.match(ANTLRv4Parser.DOC_COMMENT)
                localctx.docs.append(localctx._DOC_COMMENT)
                self.state = 127
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 128
            localctx.gtype = self.grammarType()
            self.state = 129
            localctx.gname = self.identifier()
            self.state = 130
            self.match(ANTLRv4Parser.SEMI)
            self.state = 134
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 1125899907088384) != 0):
                self.state = 131
                self.prequelConstruct()
                self.state = 136
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 137
            self.rules()
            self.state = 141
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==30:
                self.state = 138
                self.modeSpec()
                self.state = 143
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 144
            self.match(ANTLRv4Parser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class GrammarTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LEXER(self):
            return self.getToken(ANTLRv4Parser.LEXER, 0)

        def GRAMMAR(self):
            return self.getToken(ANTLRv4Parser.GRAMMAR, 0)

        def PARSER(self):
            return self.getToken(ANTLRv4Parser.PARSER, 0)

        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_grammarType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGrammarType" ):
                listener.enterGrammarType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGrammarType" ):
                listener.exitGrammarType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitGrammarType" ):
                return visitor.visitGrammarType(self)
            else:
                return visitor.visitChildren(self)




    def grammarType(self):

        localctx = ANTLRv4Parser.GrammarTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_grammarType)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 151
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [19]:
                self.state = 146
                self.match(ANTLRv4Parser.LEXER)
                self.state = 147
                self.match(ANTLRv4Parser.GRAMMAR)
                pass
            elif token in [20]:
                self.state = 148
                self.match(ANTLRv4Parser.PARSER)
                self.state = 149
                self.match(ANTLRv4Parser.GRAMMAR)
                pass
            elif token in [21]:
                self.state = 150
                self.match(ANTLRv4Parser.GRAMMAR)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrequelConstructContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def optionsSpec(self):
            return self.getTypedRuleContext(ANTLRv4Parser.OptionsSpecContext,0)


        def delegateGrammars(self):
            return self.getTypedRuleContext(ANTLRv4Parser.DelegateGrammarsContext,0)


        def tokensSpec(self):
            return self.getTypedRuleContext(ANTLRv4Parser.TokensSpecContext,0)


        def channelsSpec(self):
            return self.getTypedRuleContext(ANTLRv4Parser.ChannelsSpecContext,0)


        def action(self):
            return self.getTypedRuleContext(ANTLRv4Parser.ActionContext,0)


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_prequelConstruct

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrequelConstruct" ):
                listener.enterPrequelConstruct(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrequelConstruct" ):
                listener.exitPrequelConstruct(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrequelConstruct" ):
                return visitor.visitPrequelConstruct(self)
            else:
                return visitor.visitChildren(self)




    def prequelConstruct(self):

        localctx = ANTLRv4Parser.PrequelConstructContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_prequelConstruct)
        try:
            self.state = 158
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [14]:
                self.enterOuterAlt(localctx, 1)
                self.state = 153
                self.optionsSpec()
                pass
            elif token in [17]:
                self.enterOuterAlt(localctx, 2)
                self.state = 154
                self.delegateGrammars()
                pass
            elif token in [15]:
                self.enterOuterAlt(localctx, 3)
                self.state = 155
                self.tokensSpec()
                pass
            elif token in [16]:
                self.enterOuterAlt(localctx, 4)
                self.state = 156
                self.channelsSpec()
                pass
            elif token in [50]:
                self.enterOuterAlt(localctx, 5)
                self.state = 157
                self.action()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OptionsSpecContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OPTIONS(self):
            return self.getToken(ANTLRv4Parser.OPTIONS, 0)

        def RBRACE(self):
            return self.getToken(ANTLRv4Parser.RBRACE, 0)

        def option(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ANTLRv4Parser.OptionContext)
            else:
                return self.getTypedRuleContext(ANTLRv4Parser.OptionContext,i)


        def SEMI(self, i:int=None):
            if i is None:
                return self.getTokens(ANTLRv4Parser.SEMI)
            else:
                return self.getToken(ANTLRv4Parser.SEMI, i)

        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_optionsSpec

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOptionsSpec" ):
                listener.enterOptionsSpec(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOptionsSpec" ):
                listener.exitOptionsSpec(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOptionsSpec" ):
                return visitor.visitOptionsSpec(self)
            else:
                return visitor.visitChildren(self)




    def optionsSpec(self):

        localctx = ANTLRv4Parser.OptionsSpecContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_optionsSpec)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 160
            self.match(ANTLRv4Parser.OPTIONS)
            self.state = 166
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==1 or _la==2:
                self.state = 161
                self.option()
                self.state = 162
                self.match(ANTLRv4Parser.SEMI)
                self.state = 168
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 169
            self.match(ANTLRv4Parser.RBRACE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OptionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.name = None # type: ANTLRv4Parser.IdentifierContext
            self.value = None # type: ANTLRv4Parser.OptionValueContext

        def ASSIGN(self):
            return self.getToken(ANTLRv4Parser.ASSIGN, 0)

        def identifier(self):
            return self.getTypedRuleContext(ANTLRv4Parser.IdentifierContext,0)


        def optionValue(self):
            return self.getTypedRuleContext(ANTLRv4Parser.OptionValueContext,0)


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_option

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOption" ):
                listener.enterOption(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOption" ):
                listener.exitOption(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOption" ):
                return visitor.visitOption(self)
            else:
                return visitor.visitChildren(self)




    def option(self):

        localctx = ANTLRv4Parser.OptionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_option)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 171
            localctx.name = self.identifier()
            self.state = 172
            self.match(ANTLRv4Parser.ASSIGN)
            self.state = 173
            localctx.value = self.optionValue()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OptionValueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_optionValue

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class StringOptionContext(OptionValueContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.OptionValueContext
            super().__init__(parser)
            self.value = None # type: Token
            self.copyFrom(ctx)

        def STRING_LITERAL(self):
            return self.getToken(ANTLRv4Parser.STRING_LITERAL, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStringOption" ):
                listener.enterStringOption(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStringOption" ):
                listener.exitStringOption(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStringOption" ):
                return visitor.visitStringOption(self)
            else:
                return visitor.visitChildren(self)


    class IntOptionContext(OptionValueContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.OptionValueContext
            super().__init__(parser)
            self.value = None # type: Token
            self.copyFrom(ctx)

        def INT(self):
            return self.getToken(ANTLRv4Parser.INT, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIntOption" ):
                listener.enterIntOption(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIntOption" ):
                listener.exitIntOption(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIntOption" ):
                return visitor.visitIntOption(self)
            else:
                return visitor.visitChildren(self)


    class ActionOptionContext(OptionValueContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.OptionValueContext
            super().__init__(parser)
            self.value = None # type: ANTLRv4Parser.ActionBlockContext
            self.copyFrom(ctx)

        def actionBlock(self):
            return self.getTypedRuleContext(ANTLRv4Parser.ActionBlockContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterActionOption" ):
                listener.enterActionOption(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitActionOption" ):
                listener.exitActionOption(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitActionOption" ):
                return visitor.visitActionOption(self)
            else:
                return visitor.visitChildren(self)


    class PathOptionContext(OptionValueContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.OptionValueContext
            super().__init__(parser)
            self._identifier = None # type: ANTLRv4Parser.IdentifierContext
            self.value = list() # type: list[ANTLRv4Parser.IdentifierContext]
            self.copyFrom(ctx)

        def identifier(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ANTLRv4Parser.IdentifierContext)
            else:
                return self.getTypedRuleContext(ANTLRv4Parser.IdentifierContext,i)

        def DOT(self, i:int=None):
            if i is None:
                return self.getTokens(ANTLRv4Parser.DOT)
            else:
                return self.getToken(ANTLRv4Parser.DOT, i)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPathOption" ):
                listener.enterPathOption(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPathOption" ):
                listener.exitPathOption(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPathOption" ):
                return visitor.visitPathOption(self)
            else:
                return visitor.visitChildren(self)



    def optionValue(self):

        localctx = ANTLRv4Parser.OptionValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_optionValue)
        self._la = 0 # Token type
        try:
            self.state = 186
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1, 2]:
                localctx = ANTLRv4Parser.PathOptionContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 175
                localctx._identifier = self.identifier()
                localctx.value.append(localctx._identifier)
                self.state = 180
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==49:
                    self.state = 176
                    self.match(ANTLRv4Parser.DOT)
                    self.state = 177
                    localctx._identifier = self.identifier()
                    localctx.value.append(localctx._identifier)
                    self.state = 182
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                pass
            elif token in [10]:
                localctx = ANTLRv4Parser.StringOptionContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 183
                localctx.value = self.match(ANTLRv4Parser.STRING_LITERAL)
                pass
            elif token in [13]:
                localctx = ANTLRv4Parser.ActionOptionContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 184
                localctx.value = self.actionBlock()
                pass
            elif token in [9]:
                localctx = ANTLRv4Parser.IntOptionContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 185
                localctx.value = self.match(ANTLRv4Parser.INT)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DelegateGrammarsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IMPORT(self):
            return self.getToken(ANTLRv4Parser.IMPORT, 0)

        def delegateGrammar(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ANTLRv4Parser.DelegateGrammarContext)
            else:
                return self.getTypedRuleContext(ANTLRv4Parser.DelegateGrammarContext,i)


        def SEMI(self):
            return self.getToken(ANTLRv4Parser.SEMI, 0)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(ANTLRv4Parser.COMMA)
            else:
                return self.getToken(ANTLRv4Parser.COMMA, i)

        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_delegateGrammars

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDelegateGrammars" ):
                listener.enterDelegateGrammars(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDelegateGrammars" ):
                listener.exitDelegateGrammars(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDelegateGrammars" ):
                return visitor.visitDelegateGrammars(self)
            else:
                return visitor.visitChildren(self)




    def delegateGrammars(self):

        localctx = ANTLRv4Parser.DelegateGrammarsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_delegateGrammars)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 188
            self.match(ANTLRv4Parser.IMPORT)
            self.state = 189
            self.delegateGrammar()
            self.state = 194
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==33:
                self.state = 190
                self.match(ANTLRv4Parser.COMMA)
                self.state = 191
                self.delegateGrammar()
                self.state = 196
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 197
            self.match(ANTLRv4Parser.SEMI)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DelegateGrammarContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.value = None # type: ANTLRv4Parser.IdentifierContext

        def identifier(self):
            return self.getTypedRuleContext(ANTLRv4Parser.IdentifierContext,0)


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_delegateGrammar

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDelegateGrammar" ):
                listener.enterDelegateGrammar(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDelegateGrammar" ):
                listener.exitDelegateGrammar(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDelegateGrammar" ):
                return visitor.visitDelegateGrammar(self)
            else:
                return visitor.visitChildren(self)




    def delegateGrammar(self):

        localctx = ANTLRv4Parser.DelegateGrammarContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_delegateGrammar)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 199
            localctx.value = self.identifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TokensSpecContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TOKENS(self):
            return self.getToken(ANTLRv4Parser.TOKENS, 0)

        def RBRACE(self):
            return self.getToken(ANTLRv4Parser.RBRACE, 0)

        def tokenSpec(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ANTLRv4Parser.TokenSpecContext)
            else:
                return self.getTypedRuleContext(ANTLRv4Parser.TokenSpecContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(ANTLRv4Parser.COMMA)
            else:
                return self.getToken(ANTLRv4Parser.COMMA, i)

        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_tokensSpec

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTokensSpec" ):
                listener.enterTokensSpec(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTokensSpec" ):
                listener.exitTokensSpec(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTokensSpec" ):
                return visitor.visitTokensSpec(self)
            else:
                return visitor.visitChildren(self)




    def tokensSpec(self):

        localctx = ANTLRv4Parser.TokensSpecContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_tokensSpec)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 201
            self.match(ANTLRv4Parser.TOKENS)

            self.state = 202
            self.tokenSpec()
            self.state = 207
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,9,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 203
                    self.match(ANTLRv4Parser.COMMA)
                    self.state = 204
                    self.tokenSpec() 
                self.state = 209
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,9,self._ctx)

            self.state = 211
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==33:
                self.state = 210
                self.match(ANTLRv4Parser.COMMA)


            self.state = 213
            self.match(ANTLRv4Parser.RBRACE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TokenSpecContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._HEADER = None # type: Token
            self.headers = list() # type: list[Token]
            self._DOC_COMMENT = None # type: Token
            self.docs = list() # type: list[Token]
            self.name = None # type: ANTLRv4Parser.IdentifierContext

        def identifier(self):
            return self.getTypedRuleContext(ANTLRv4Parser.IdentifierContext,0)


        def HEADER(self, i:int=None):
            if i is None:
                return self.getTokens(ANTLRv4Parser.HEADER)
            else:
                return self.getToken(ANTLRv4Parser.HEADER, i)

        def DOC_COMMENT(self, i:int=None):
            if i is None:
                return self.getTokens(ANTLRv4Parser.DOC_COMMENT)
            else:
                return self.getToken(ANTLRv4Parser.DOC_COMMENT, i)

        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_tokenSpec

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTokenSpec" ):
                listener.enterTokenSpec(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTokenSpec" ):
                listener.exitTokenSpec(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTokenSpec" ):
                return visitor.visitTokenSpec(self)
            else:
                return visitor.visitChildren(self)




    def tokenSpec(self):

        localctx = ANTLRv4Parser.TokenSpecContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_tokenSpec)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 218
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==6:
                self.state = 215
                localctx._HEADER = self.match(ANTLRv4Parser.HEADER)
                localctx.headers.append(localctx._HEADER)
                self.state = 220
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 224
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==5:
                self.state = 221
                localctx._DOC_COMMENT = self.match(ANTLRv4Parser.DOC_COMMENT)
                localctx.docs.append(localctx._DOC_COMMENT)
                self.state = 226
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 227
            localctx.name = self.identifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ChannelsSpecContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CHANNELS(self):
            return self.getToken(ANTLRv4Parser.CHANNELS, 0)

        def identifier(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ANTLRv4Parser.IdentifierContext)
            else:
                return self.getTypedRuleContext(ANTLRv4Parser.IdentifierContext,i)


        def RBRACE(self):
            return self.getToken(ANTLRv4Parser.RBRACE, 0)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(ANTLRv4Parser.COMMA)
            else:
                return self.getToken(ANTLRv4Parser.COMMA, i)

        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_channelsSpec

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterChannelsSpec" ):
                listener.enterChannelsSpec(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitChannelsSpec" ):
                listener.exitChannelsSpec(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitChannelsSpec" ):
                return visitor.visitChannelsSpec(self)
            else:
                return visitor.visitChildren(self)




    def channelsSpec(self):

        localctx = ANTLRv4Parser.ChannelsSpecContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_channelsSpec)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 229
            self.match(ANTLRv4Parser.CHANNELS)
            self.state = 230
            self.identifier()
            self.state = 235
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,13,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 231
                    self.match(ANTLRv4Parser.COMMA)
                    self.state = 232
                    self.identifier() 
                self.state = 237
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,13,self._ctx)

            self.state = 239
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==33:
                self.state = 238
                self.match(ANTLRv4Parser.COMMA)


            self.state = 241
            self.match(ANTLRv4Parser.RBRACE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ActionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def AT(self):
            return self.getToken(ANTLRv4Parser.AT, 0)

        def identifier(self):
            return self.getTypedRuleContext(ANTLRv4Parser.IdentifierContext,0)


        def actionBlock(self):
            return self.getTypedRuleContext(ANTLRv4Parser.ActionBlockContext,0)


        def actionScopeName(self):
            return self.getTypedRuleContext(ANTLRv4Parser.ActionScopeNameContext,0)


        def COLONCOLON(self):
            return self.getToken(ANTLRv4Parser.COLONCOLON, 0)

        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_action

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAction" ):
                listener.enterAction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAction" ):
                listener.exitAction(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAction" ):
                return visitor.visitAction(self)
            else:
                return visitor.visitChildren(self)




    def action(self):

        localctx = ANTLRv4Parser.ActionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_action)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 243
            self.match(ANTLRv4Parser.AT)
            self.state = 247
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,15,self._ctx)
            if la_ == 1:
                self.state = 244
                self.actionScopeName()
                self.state = 245
                self.match(ANTLRv4Parser.COLONCOLON)


            self.state = 249
            self.identifier()
            self.state = 250
            self.actionBlock()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ActionScopeNameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(ANTLRv4Parser.IdentifierContext,0)


        def LEXER(self):
            return self.getToken(ANTLRv4Parser.LEXER, 0)

        def PARSER(self):
            return self.getToken(ANTLRv4Parser.PARSER, 0)

        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_actionScopeName

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterActionScopeName" ):
                listener.enterActionScopeName(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitActionScopeName" ):
                listener.exitActionScopeName(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitActionScopeName" ):
                return visitor.visitActionScopeName(self)
            else:
                return visitor.visitChildren(self)




    def actionScopeName(self):

        localctx = ANTLRv4Parser.ActionScopeNameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_actionScopeName)
        try:
            self.state = 255
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1, 2]:
                self.enterOuterAlt(localctx, 1)
                self.state = 252
                self.identifier()
                pass
            elif token in [19]:
                self.enterOuterAlt(localctx, 2)
                self.state = 253
                self.match(ANTLRv4Parser.LEXER)
                pass
            elif token in [20]:
                self.enterOuterAlt(localctx, 3)
                self.state = 254
                self.match(ANTLRv4Parser.PARSER)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ActionBlockContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BEGIN_ACTION(self):
            return self.getToken(ANTLRv4Parser.BEGIN_ACTION, 0)

        def END_ACTION(self):
            return self.getToken(ANTLRv4Parser.END_ACTION, 0)

        def actionBlock(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ANTLRv4Parser.ActionBlockContext)
            else:
                return self.getTypedRuleContext(ANTLRv4Parser.ActionBlockContext,i)


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_actionBlock

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterActionBlock" ):
                listener.enterActionBlock(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitActionBlock" ):
                listener.exitActionBlock(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitActionBlock" ):
                return visitor.visitActionBlock(self)
            else:
                return visitor.visitChildren(self)




    def actionBlock(self):

        localctx = ANTLRv4Parser.ActionBlockContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_actionBlock)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 257
            self.match(ANTLRv4Parser.BEGIN_ACTION)
            self.state = 261
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==13:
                self.state = 258
                self.actionBlock()
                self.state = 263
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 264
            self.match(ANTLRv4Parser.END_ACTION)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArgActionBlockContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BEGIN_ARGUMENT(self):
            return self.getToken(ANTLRv4Parser.BEGIN_ARGUMENT, 0)

        def END_ARGUMENT(self):
            return self.getToken(ANTLRv4Parser.END_ARGUMENT, 0)

        def argActionBlock(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ANTLRv4Parser.ArgActionBlockContext)
            else:
                return self.getTypedRuleContext(ANTLRv4Parser.ArgActionBlockContext,i)


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_argActionBlock

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArgActionBlock" ):
                listener.enterArgActionBlock(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArgActionBlock" ):
                listener.exitArgActionBlock(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitArgActionBlock" ):
                return visitor.visitArgActionBlock(self)
            else:
                return visitor.visitChildren(self)




    def argActionBlock(self):

        localctx = ANTLRv4Parser.ArgActionBlockContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_argActionBlock)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 266
            self.match(ANTLRv4Parser.BEGIN_ARGUMENT)
            self.state = 270
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==12:
                self.state = 267
                self.argActionBlock()
                self.state = 272
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 273
            self.match(ANTLRv4Parser.END_ARGUMENT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ModeSpecContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def MODE(self):
            return self.getToken(ANTLRv4Parser.MODE, 0)

        def identifier(self):
            return self.getTypedRuleContext(ANTLRv4Parser.IdentifierContext,0)


        def SEMI(self):
            return self.getToken(ANTLRv4Parser.SEMI, 0)

        def lexerRuleSpec(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ANTLRv4Parser.LexerRuleSpecContext)
            else:
                return self.getTypedRuleContext(ANTLRv4Parser.LexerRuleSpecContext,i)


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_modeSpec

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterModeSpec" ):
                listener.enterModeSpec(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitModeSpec" ):
                listener.exitModeSpec(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitModeSpec" ):
                return visitor.visitModeSpec(self)
            else:
                return visitor.visitChildren(self)




    def modeSpec(self):

        localctx = ANTLRv4Parser.ModeSpecContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_modeSpec)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 275
            self.match(ANTLRv4Parser.MODE)
            self.state = 276
            self.identifier()
            self.state = 277
            self.match(ANTLRv4Parser.SEMI)
            self.state = 281
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 262178) != 0):
                self.state = 278
                self.lexerRuleSpec()
                self.state = 283
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RulesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ruleSpec(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ANTLRv4Parser.RuleSpecContext)
            else:
                return self.getTypedRuleContext(ANTLRv4Parser.RuleSpecContext,i)


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_rules

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRules" ):
                listener.enterRules(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRules" ):
                listener.exitRules(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRules" ):
                return visitor.visitRules(self)
            else:
                return visitor.visitChildren(self)




    def rules(self):

        localctx = ANTLRv4Parser.RulesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_rules)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 287
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 29622374) != 0):
                self.state = 284
                self.ruleSpec()
                self.state = 289
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RuleSpecContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._HEADER = None # type: Token
            self.headers = list() # type: list[Token]

        def parserRuleSpec(self):
            return self.getTypedRuleContext(ANTLRv4Parser.ParserRuleSpecContext,0)


        def lexerRuleSpec(self):
            return self.getTypedRuleContext(ANTLRv4Parser.LexerRuleSpecContext,0)


        def HEADER(self, i:int=None):
            if i is None:
                return self.getTokens(ANTLRv4Parser.HEADER)
            else:
                return self.getToken(ANTLRv4Parser.HEADER, i)

        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_ruleSpec

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRuleSpec" ):
                listener.enterRuleSpec(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRuleSpec" ):
                listener.exitRuleSpec(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRuleSpec" ):
                return visitor.visitRuleSpec(self)
            else:
                return visitor.visitChildren(self)




    def ruleSpec(self):

        localctx = ANTLRv4Parser.RuleSpecContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_ruleSpec)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 293
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==6:
                self.state = 290
                localctx._HEADER = self.match(ANTLRv4Parser.HEADER)
                localctx.headers.append(localctx._HEADER)
                self.state = 295
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 298
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,22,self._ctx)
            if la_ == 1:
                self.state = 296
                self.parserRuleSpec()
                pass

            elif la_ == 2:
                self.state = 297
                self.lexerRuleSpec()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParserRuleSpecContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._DOC_COMMENT = None # type: Token
            self.docs = list() # type: list[Token]
            self.name = None # type: Token

        def COLON(self):
            return self.getToken(ANTLRv4Parser.COLON, 0)

        def ruleBlock(self):
            return self.getTypedRuleContext(ANTLRv4Parser.RuleBlockContext,0)


        def SEMI(self):
            return self.getToken(ANTLRv4Parser.SEMI, 0)

        def exceptionGroup(self):
            return self.getTypedRuleContext(ANTLRv4Parser.ExceptionGroupContext,0)


        def RULE_REF(self):
            return self.getToken(ANTLRv4Parser.RULE_REF, 0)

        def ruleModifiers(self):
            return self.getTypedRuleContext(ANTLRv4Parser.RuleModifiersContext,0)


        def argActionBlock(self):
            return self.getTypedRuleContext(ANTLRv4Parser.ArgActionBlockContext,0)


        def ruleReturns(self):
            return self.getTypedRuleContext(ANTLRv4Parser.RuleReturnsContext,0)


        def throwsSpec(self):
            return self.getTypedRuleContext(ANTLRv4Parser.ThrowsSpecContext,0)


        def localsSpec(self):
            return self.getTypedRuleContext(ANTLRv4Parser.LocalsSpecContext,0)


        def rulePrequel(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ANTLRv4Parser.RulePrequelContext)
            else:
                return self.getTypedRuleContext(ANTLRv4Parser.RulePrequelContext,i)


        def DOC_COMMENT(self, i:int=None):
            if i is None:
                return self.getTokens(ANTLRv4Parser.DOC_COMMENT)
            else:
                return self.getToken(ANTLRv4Parser.DOC_COMMENT, i)

        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_parserRuleSpec

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParserRuleSpec" ):
                listener.enterParserRuleSpec(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParserRuleSpec" ):
                listener.exitParserRuleSpec(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParserRuleSpec" ):
                return visitor.visitParserRuleSpec(self)
            else:
                return visitor.visitChildren(self)




    def parserRuleSpec(self):

        localctx = ANTLRv4Parser.ParserRuleSpecContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_parserRuleSpec)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 303
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==5:
                self.state = 300
                localctx._DOC_COMMENT = self.match(ANTLRv4Parser.DOC_COMMENT)
                localctx.docs.append(localctx._DOC_COMMENT)
                self.state = 305
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 307
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 29622272) != 0):
                self.state = 306
                self.ruleModifiers()


            self.state = 309
            localctx.name = self.match(ANTLRv4Parser.RULE_REF)
            self.state = 311
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==12:
                self.state = 310
                self.argActionBlock()


            self.state = 314
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==25:
                self.state = 313
                self.ruleReturns()


            self.state = 317
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==27:
                self.state = 316
                self.throwsSpec()


            self.state = 320
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==26:
                self.state = 319
                self.localsSpec()


            self.state = 325
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==14 or _la==50:
                self.state = 322
                self.rulePrequel()
                self.state = 327
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 328
            self.match(ANTLRv4Parser.COLON)
            self.state = 329
            self.ruleBlock()
            self.state = 330
            self.match(ANTLRv4Parser.SEMI)
            self.state = 331
            self.exceptionGroup()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExceptionGroupContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def exceptionHandler(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ANTLRv4Parser.ExceptionHandlerContext)
            else:
                return self.getTypedRuleContext(ANTLRv4Parser.ExceptionHandlerContext,i)


        def finallyClause(self):
            return self.getTypedRuleContext(ANTLRv4Parser.FinallyClauseContext,0)


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_exceptionGroup

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExceptionGroup" ):
                listener.enterExceptionGroup(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExceptionGroup" ):
                listener.exitExceptionGroup(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExceptionGroup" ):
                return visitor.visitExceptionGroup(self)
            else:
                return visitor.visitChildren(self)




    def exceptionGroup(self):

        localctx = ANTLRv4Parser.ExceptionGroupContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_exceptionGroup)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 336
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==28:
                self.state = 333
                self.exceptionHandler()
                self.state = 338
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 340
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==29:
                self.state = 339
                self.finallyClause()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExceptionHandlerContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CATCH(self):
            return self.getToken(ANTLRv4Parser.CATCH, 0)

        def argActionBlock(self):
            return self.getTypedRuleContext(ANTLRv4Parser.ArgActionBlockContext,0)


        def actionBlock(self):
            return self.getTypedRuleContext(ANTLRv4Parser.ActionBlockContext,0)


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_exceptionHandler

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExceptionHandler" ):
                listener.enterExceptionHandler(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExceptionHandler" ):
                listener.exitExceptionHandler(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExceptionHandler" ):
                return visitor.visitExceptionHandler(self)
            else:
                return visitor.visitChildren(self)




    def exceptionHandler(self):

        localctx = ANTLRv4Parser.ExceptionHandlerContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_exceptionHandler)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 342
            self.match(ANTLRv4Parser.CATCH)
            self.state = 343
            self.argActionBlock()
            self.state = 344
            self.actionBlock()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FinallyClauseContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FINALLY(self):
            return self.getToken(ANTLRv4Parser.FINALLY, 0)

        def actionBlock(self):
            return self.getTypedRuleContext(ANTLRv4Parser.ActionBlockContext,0)


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_finallyClause

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFinallyClause" ):
                listener.enterFinallyClause(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFinallyClause" ):
                listener.exitFinallyClause(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFinallyClause" ):
                return visitor.visitFinallyClause(self)
            else:
                return visitor.visitChildren(self)




    def finallyClause(self):

        localctx = ANTLRv4Parser.FinallyClauseContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_finallyClause)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 346
            self.match(ANTLRv4Parser.FINALLY)
            self.state = 347
            self.actionBlock()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RulePrequelContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def optionsSpec(self):
            return self.getTypedRuleContext(ANTLRv4Parser.OptionsSpecContext,0)


        def ruleAction(self):
            return self.getTypedRuleContext(ANTLRv4Parser.RuleActionContext,0)


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_rulePrequel

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRulePrequel" ):
                listener.enterRulePrequel(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRulePrequel" ):
                listener.exitRulePrequel(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRulePrequel" ):
                return visitor.visitRulePrequel(self)
            else:
                return visitor.visitChildren(self)




    def rulePrequel(self):

        localctx = ANTLRv4Parser.RulePrequelContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_rulePrequel)
        try:
            self.state = 351
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [14]:
                self.enterOuterAlt(localctx, 1)
                self.state = 349
                self.optionsSpec()
                pass
            elif token in [50]:
                self.enterOuterAlt(localctx, 2)
                self.state = 350
                self.ruleAction()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RuleReturnsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RETURNS(self):
            return self.getToken(ANTLRv4Parser.RETURNS, 0)

        def argActionBlock(self):
            return self.getTypedRuleContext(ANTLRv4Parser.ArgActionBlockContext,0)


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_ruleReturns

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRuleReturns" ):
                listener.enterRuleReturns(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRuleReturns" ):
                listener.exitRuleReturns(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRuleReturns" ):
                return visitor.visitRuleReturns(self)
            else:
                return visitor.visitChildren(self)




    def ruleReturns(self):

        localctx = ANTLRv4Parser.RuleReturnsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_ruleReturns)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 353
            self.match(ANTLRv4Parser.RETURNS)
            self.state = 354
            self.argActionBlock()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ThrowsSpecContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def THROWS(self):
            return self.getToken(ANTLRv4Parser.THROWS, 0)

        def identifier(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ANTLRv4Parser.IdentifierContext)
            else:
                return self.getTypedRuleContext(ANTLRv4Parser.IdentifierContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(ANTLRv4Parser.COMMA)
            else:
                return self.getToken(ANTLRv4Parser.COMMA, i)

        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_throwsSpec

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterThrowsSpec" ):
                listener.enterThrowsSpec(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitThrowsSpec" ):
                listener.exitThrowsSpec(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitThrowsSpec" ):
                return visitor.visitThrowsSpec(self)
            else:
                return visitor.visitChildren(self)




    def throwsSpec(self):

        localctx = ANTLRv4Parser.ThrowsSpecContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_throwsSpec)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 356
            self.match(ANTLRv4Parser.THROWS)
            self.state = 357
            self.identifier()
            self.state = 362
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==33:
                self.state = 358
                self.match(ANTLRv4Parser.COMMA)
                self.state = 359
                self.identifier()
                self.state = 364
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LocalsSpecContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LOCALS(self):
            return self.getToken(ANTLRv4Parser.LOCALS, 0)

        def argActionBlock(self):
            return self.getTypedRuleContext(ANTLRv4Parser.ArgActionBlockContext,0)


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_localsSpec

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLocalsSpec" ):
                listener.enterLocalsSpec(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLocalsSpec" ):
                listener.exitLocalsSpec(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLocalsSpec" ):
                return visitor.visitLocalsSpec(self)
            else:
                return visitor.visitChildren(self)




    def localsSpec(self):

        localctx = ANTLRv4Parser.LocalsSpecContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_localsSpec)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 365
            self.match(ANTLRv4Parser.LOCALS)
            self.state = 366
            self.argActionBlock()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RuleActionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def AT(self):
            return self.getToken(ANTLRv4Parser.AT, 0)

        def identifier(self):
            return self.getTypedRuleContext(ANTLRv4Parser.IdentifierContext,0)


        def actionBlock(self):
            return self.getTypedRuleContext(ANTLRv4Parser.ActionBlockContext,0)


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_ruleAction

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRuleAction" ):
                listener.enterRuleAction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRuleAction" ):
                listener.exitRuleAction(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRuleAction" ):
                return visitor.visitRuleAction(self)
            else:
                return visitor.visitChildren(self)




    def ruleAction(self):

        localctx = ANTLRv4Parser.RuleActionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_ruleAction)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 368
            self.match(ANTLRv4Parser.AT)
            self.state = 369
            self.identifier()
            self.state = 370
            self.actionBlock()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RuleModifiersContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ruleModifier(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ANTLRv4Parser.RuleModifierContext)
            else:
                return self.getTypedRuleContext(ANTLRv4Parser.RuleModifierContext,i)


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_ruleModifiers

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRuleModifiers" ):
                listener.enterRuleModifiers(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRuleModifiers" ):
                listener.exitRuleModifiers(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRuleModifiers" ):
                return visitor.visitRuleModifiers(self)
            else:
                return visitor.visitChildren(self)




    def ruleModifiers(self):

        localctx = ANTLRv4Parser.RuleModifiersContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_ruleModifiers)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 373 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 372
                self.ruleModifier()
                self.state = 375 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 29622272) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RuleModifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PUBLIC(self):
            return self.getToken(ANTLRv4Parser.PUBLIC, 0)

        def PRIVATE(self):
            return self.getToken(ANTLRv4Parser.PRIVATE, 0)

        def PROTECTED(self):
            return self.getToken(ANTLRv4Parser.PROTECTED, 0)

        def FRAGMENT(self):
            return self.getToken(ANTLRv4Parser.FRAGMENT, 0)

        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_ruleModifier

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRuleModifier" ):
                listener.enterRuleModifier(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRuleModifier" ):
                listener.exitRuleModifier(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRuleModifier" ):
                return visitor.visitRuleModifier(self)
            else:
                return visitor.visitChildren(self)




    def ruleModifier(self):

        localctx = ANTLRv4Parser.RuleModifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_ruleModifier)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 377
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 29622272) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RuleBlockContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ruleAltList(self):
            return self.getTypedRuleContext(ANTLRv4Parser.RuleAltListContext,0)


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_ruleBlock

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRuleBlock" ):
                listener.enterRuleBlock(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRuleBlock" ):
                listener.exitRuleBlock(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRuleBlock" ):
                return visitor.visitRuleBlock(self)
            else:
                return visitor.visitChildren(self)




    def ruleBlock(self):

        localctx = ANTLRv4Parser.RuleBlockContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_ruleBlock)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 379
            self.ruleAltList()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RuleAltListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._labeledAlt = None # type: ANTLRv4Parser.LabeledAltContext
            self.alts = list() # type: list[ANTLRv4Parser.LabeledAltContext]

        def labeledAlt(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ANTLRv4Parser.LabeledAltContext)
            else:
                return self.getTypedRuleContext(ANTLRv4Parser.LabeledAltContext,i)


        def OR(self, i:int=None):
            if i is None:
                return self.getTokens(ANTLRv4Parser.OR)
            else:
                return self.getToken(ANTLRv4Parser.OR, i)

        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_ruleAltList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRuleAltList" ):
                listener.enterRuleAltList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRuleAltList" ):
                listener.exitRuleAltList(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRuleAltList" ):
                return visitor.visitRuleAltList(self)
            else:
                return visitor.visitChildren(self)




    def ruleAltList(self):

        localctx = ANTLRv4Parser.RuleAltListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_ruleAltList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 381
            localctx._labeledAlt = self.labeledAlt()
            localctx.alts.append(localctx._labeledAlt)
            self.state = 386
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==46:
                self.state = 382
                self.match(ANTLRv4Parser.OR)
                self.state = 383
                localctx._labeledAlt = self.labeledAlt()
                localctx.alts.append(localctx._labeledAlt)
                self.state = 388
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LabeledAltContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def alternative(self):
            return self.getTypedRuleContext(ANTLRv4Parser.AlternativeContext,0)


        def POUND(self):
            return self.getToken(ANTLRv4Parser.POUND, 0)

        def identifier(self):
            return self.getTypedRuleContext(ANTLRv4Parser.IdentifierContext,0)


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_labeledAlt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLabeledAlt" ):
                listener.enterLabeledAlt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLabeledAlt" ):
                listener.exitLabeledAlt(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLabeledAlt" ):
                return visitor.visitLabeledAlt(self)
            else:
                return visitor.visitChildren(self)




    def labeledAlt(self):

        localctx = ANTLRv4Parser.LabeledAltContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_labeledAlt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 389
            self.alternative()
            self.state = 392
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==51:
                self.state = 390
                self.match(ANTLRv4Parser.POUND)
                self.state = 391
                self.identifier()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LexerRuleSpecContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._DOC_COMMENT = None # type: Token
            self.docs = list() # type: list[Token]
            self.frag = None # type: Token
            self.name = None # type: Token

        def COLON(self):
            return self.getToken(ANTLRv4Parser.COLON, 0)

        def lexerRuleBlock(self):
            return self.getTypedRuleContext(ANTLRv4Parser.LexerRuleBlockContext,0)


        def SEMI(self):
            return self.getToken(ANTLRv4Parser.SEMI, 0)

        def TOKEN_REF(self):
            return self.getToken(ANTLRv4Parser.TOKEN_REF, 0)

        def DOC_COMMENT(self, i:int=None):
            if i is None:
                return self.getTokens(ANTLRv4Parser.DOC_COMMENT)
            else:
                return self.getToken(ANTLRv4Parser.DOC_COMMENT, i)

        def FRAGMENT(self):
            return self.getToken(ANTLRv4Parser.FRAGMENT, 0)

        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_lexerRuleSpec

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLexerRuleSpec" ):
                listener.enterLexerRuleSpec(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLexerRuleSpec" ):
                listener.exitLexerRuleSpec(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLexerRuleSpec" ):
                return visitor.visitLexerRuleSpec(self)
            else:
                return visitor.visitChildren(self)




    def lexerRuleSpec(self):

        localctx = ANTLRv4Parser.LexerRuleSpecContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_lexerRuleSpec)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 397
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==5:
                self.state = 394
                localctx._DOC_COMMENT = self.match(ANTLRv4Parser.DOC_COMMENT)
                localctx.docs.append(localctx._DOC_COMMENT)
                self.state = 399
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 401
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==18:
                self.state = 400
                localctx.frag = self.match(ANTLRv4Parser.FRAGMENT)


            self.state = 403
            localctx.name = self.match(ANTLRv4Parser.TOKEN_REF)
            self.state = 404
            self.match(ANTLRv4Parser.COLON)
            self.state = 405
            self.lexerRuleBlock()
            self.state = 406
            self.match(ANTLRv4Parser.SEMI)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LexerRuleBlockContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def lexerAltList(self):
            return self.getTypedRuleContext(ANTLRv4Parser.LexerAltListContext,0)


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_lexerRuleBlock

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLexerRuleBlock" ):
                listener.enterLexerRuleBlock(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLexerRuleBlock" ):
                listener.exitLexerRuleBlock(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLexerRuleBlock" ):
                return visitor.visitLexerRuleBlock(self)
            else:
                return visitor.visitChildren(self)




    def lexerRuleBlock(self):

        localctx = ANTLRv4Parser.LexerRuleBlockContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_lexerRuleBlock)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 408
            self.lexerAltList()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LexerAltListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._lexerAlt = None # type: ANTLRv4Parser.LexerAltContext
            self.alts = list() # type: list[ANTLRv4Parser.LexerAltContext]

        def lexerAlt(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ANTLRv4Parser.LexerAltContext)
            else:
                return self.getTypedRuleContext(ANTLRv4Parser.LexerAltContext,i)


        def OR(self, i:int=None):
            if i is None:
                return self.getTokens(ANTLRv4Parser.OR)
            else:
                return self.getToken(ANTLRv4Parser.OR, i)

        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_lexerAltList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLexerAltList" ):
                listener.enterLexerAltList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLexerAltList" ):
                listener.exitLexerAltList(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLexerAltList" ):
                return visitor.visitLexerAltList(self)
            else:
                return visitor.visitChildren(self)




    def lexerAltList(self):

        localctx = ANTLRv4Parser.LexerAltListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_lexerAltList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 410
            localctx._lexerAlt = self.lexerAlt()
            localctx.alts.append(localctx._lexerAlt)
            self.state = 415
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==46:
                self.state = 411
                self.match(ANTLRv4Parser.OR)
                self.state = 412
                localctx._lexerAlt = self.lexerAlt()
                localctx.alts.append(localctx._lexerAlt)
                self.state = 417
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LexerAltContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def lexerElements(self):
            return self.getTypedRuleContext(ANTLRv4Parser.LexerElementsContext,0)


        def lexerCommands(self):
            return self.getTypedRuleContext(ANTLRv4Parser.LexerCommandsContext,0)


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_lexerAlt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLexerAlt" ):
                listener.enterLexerAlt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLexerAlt" ):
                listener.exitLexerAlt(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLexerAlt" ):
                return visitor.visitLexerAlt(self)
            else:
                return visitor.visitChildren(self)




    def lexerAlt(self):

        localctx = ANTLRv4Parser.LexerAltContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_lexerAlt)
        self._la = 0 # Token type
        try:
            self.state = 423
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1, 2, 3, 5, 10, 13, 35, 49, 52]:
                self.enterOuterAlt(localctx, 1)
                self.state = 418
                self.lexerElements()
                self.state = 420
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==38:
                    self.state = 419
                    self.lexerCommands()


                pass
            elif token in [34, 36, 46]:
                self.enterOuterAlt(localctx, 2)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LexerElementsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._lexerElement = None # type: ANTLRv4Parser.LexerElementContext
            self.elements = list() # type: list[ANTLRv4Parser.LexerElementContext]

        def lexerElement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ANTLRv4Parser.LexerElementContext)
            else:
                return self.getTypedRuleContext(ANTLRv4Parser.LexerElementContext,i)


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_lexerElements

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLexerElements" ):
                listener.enterLexerElements(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLexerElements" ):
                listener.exitLexerElements(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLexerElements" ):
                return visitor.visitLexerElements(self)
            else:
                return visitor.visitChildren(self)




    def lexerElements(self):

        localctx = ANTLRv4Parser.LexerElementsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_lexerElements)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 426 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 425
                localctx._lexerElement = self.lexerElement()
                localctx.elements.append(localctx._lexerElement)
                self.state = 428 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 5066583940539438) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LexerElementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_lexerElement

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class LexerElementLabeledContext(LexerElementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.LexerElementContext
            super().__init__(parser)
            self.value = None # type: ANTLRv4Parser.LabeledLexerElementContext
            self.suffix = None # type: ANTLRv4Parser.EbnfSuffixContext
            self.copyFrom(ctx)

        def labeledLexerElement(self):
            return self.getTypedRuleContext(ANTLRv4Parser.LabeledLexerElementContext,0)

        def ebnfSuffix(self):
            return self.getTypedRuleContext(ANTLRv4Parser.EbnfSuffixContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLexerElementLabeled" ):
                listener.enterLexerElementLabeled(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLexerElementLabeled" ):
                listener.exitLexerElementLabeled(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLexerElementLabeled" ):
                return visitor.visitLexerElementLabeled(self)
            else:
                return visitor.visitChildren(self)


    class LexerElementBlockContext(LexerElementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.LexerElementContext
            super().__init__(parser)
            self.value = None # type: ANTLRv4Parser.LexerBlockContext
            self.suffix = None # type: ANTLRv4Parser.EbnfSuffixContext
            self.copyFrom(ctx)

        def lexerBlock(self):
            return self.getTypedRuleContext(ANTLRv4Parser.LexerBlockContext,0)

        def ebnfSuffix(self):
            return self.getTypedRuleContext(ANTLRv4Parser.EbnfSuffixContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLexerElementBlock" ):
                listener.enterLexerElementBlock(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLexerElementBlock" ):
                listener.exitLexerElementBlock(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLexerElementBlock" ):
                return visitor.visitLexerElementBlock(self)
            else:
                return visitor.visitChildren(self)


    class LexerElementActionContext(LexerElementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.LexerElementContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def actionBlock(self):
            return self.getTypedRuleContext(ANTLRv4Parser.ActionBlockContext,0)

        def QUESTION(self):
            return self.getToken(ANTLRv4Parser.QUESTION, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLexerElementAction" ):
                listener.enterLexerElementAction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLexerElementAction" ):
                listener.exitLexerElementAction(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLexerElementAction" ):
                return visitor.visitLexerElementAction(self)
            else:
                return visitor.visitChildren(self)


    class LexerElementAtomContext(LexerElementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.LexerElementContext
            super().__init__(parser)
            self.value = None # type: ANTLRv4Parser.LexerAtomContext
            self.suffix = None # type: ANTLRv4Parser.EbnfSuffixContext
            self.copyFrom(ctx)

        def lexerAtom(self):
            return self.getTypedRuleContext(ANTLRv4Parser.LexerAtomContext,0)

        def ebnfSuffix(self):
            return self.getTypedRuleContext(ANTLRv4Parser.EbnfSuffixContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLexerElementAtom" ):
                listener.enterLexerElementAtom(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLexerElementAtom" ):
                listener.exitLexerElementAtom(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLexerElementAtom" ):
                return visitor.visitLexerElementAtom(self)
            else:
                return visitor.visitChildren(self)



    def lexerElement(self):

        localctx = ANTLRv4Parser.LexerElementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_lexerElement)
        self._la = 0 # Token type
        try:
            self.state = 446
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,47,self._ctx)
            if la_ == 1:
                localctx = ANTLRv4Parser.LexerElementLabeledContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 430
                localctx.value = self.labeledLexerElement()
                self.state = 432
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & 48378511622144) != 0):
                    self.state = 431
                    localctx.suffix = self.ebnfSuffix()


                pass

            elif la_ == 2:
                localctx = ANTLRv4Parser.LexerElementAtomContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 434
                localctx.value = self.lexerAtom()
                self.state = 436
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & 48378511622144) != 0):
                    self.state = 435
                    localctx.suffix = self.ebnfSuffix()


                pass

            elif la_ == 3:
                localctx = ANTLRv4Parser.LexerElementBlockContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 438
                localctx.value = self.lexerBlock()
                self.state = 440
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & 48378511622144) != 0):
                    self.state = 439
                    localctx.suffix = self.ebnfSuffix()


                pass

            elif la_ == 4:
                localctx = ANTLRv4Parser.LexerElementActionContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 442
                self.actionBlock()
                self.state = 444
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==42:
                    self.state = 443
                    self.match(ANTLRv4Parser.QUESTION)


                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LabeledLexerElementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(ANTLRv4Parser.IdentifierContext,0)


        def ASSIGN(self):
            return self.getToken(ANTLRv4Parser.ASSIGN, 0)

        def PLUS_ASSIGN(self):
            return self.getToken(ANTLRv4Parser.PLUS_ASSIGN, 0)

        def lexerAtom(self):
            return self.getTypedRuleContext(ANTLRv4Parser.LexerAtomContext,0)


        def lexerBlock(self):
            return self.getTypedRuleContext(ANTLRv4Parser.LexerBlockContext,0)


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_labeledLexerElement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLabeledLexerElement" ):
                listener.enterLabeledLexerElement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLabeledLexerElement" ):
                listener.exitLabeledLexerElement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLabeledLexerElement" ):
                return visitor.visitLabeledLexerElement(self)
            else:
                return visitor.visitChildren(self)




    def labeledLexerElement(self):

        localctx = ANTLRv4Parser.LabeledLexerElementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_labeledLexerElement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 448
            self.identifier()
            self.state = 449
            _la = self._input.LA(1)
            if not(_la==41 or _la==44):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 452
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1, 3, 5, 10, 49, 52]:
                self.state = 450
                self.lexerAtom()
                pass
            elif token in [35]:
                self.state = 451
                self.lexerBlock()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LexerBlockContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LPAREN(self):
            return self.getToken(ANTLRv4Parser.LPAREN, 0)

        def lexerAltList(self):
            return self.getTypedRuleContext(ANTLRv4Parser.LexerAltListContext,0)


        def RPAREN(self):
            return self.getToken(ANTLRv4Parser.RPAREN, 0)

        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_lexerBlock

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLexerBlock" ):
                listener.enterLexerBlock(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLexerBlock" ):
                listener.exitLexerBlock(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLexerBlock" ):
                return visitor.visitLexerBlock(self)
            else:
                return visitor.visitChildren(self)




    def lexerBlock(self):

        localctx = ANTLRv4Parser.LexerBlockContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_lexerBlock)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 454
            self.match(ANTLRv4Parser.LPAREN)
            self.state = 455
            self.lexerAltList()
            self.state = 456
            self.match(ANTLRv4Parser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LexerCommandsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RARROW(self):
            return self.getToken(ANTLRv4Parser.RARROW, 0)

        def lexerCommand(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ANTLRv4Parser.LexerCommandContext)
            else:
                return self.getTypedRuleContext(ANTLRv4Parser.LexerCommandContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(ANTLRv4Parser.COMMA)
            else:
                return self.getToken(ANTLRv4Parser.COMMA, i)

        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_lexerCommands

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLexerCommands" ):
                listener.enterLexerCommands(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLexerCommands" ):
                listener.exitLexerCommands(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLexerCommands" ):
                return visitor.visitLexerCommands(self)
            else:
                return visitor.visitChildren(self)




    def lexerCommands(self):

        localctx = ANTLRv4Parser.LexerCommandsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 80, self.RULE_lexerCommands)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 458
            self.match(ANTLRv4Parser.RARROW)
            self.state = 459
            self.lexerCommand()
            self.state = 464
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==33:
                self.state = 460
                self.match(ANTLRv4Parser.COMMA)
                self.state = 461
                self.lexerCommand()
                self.state = 466
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LexerCommandContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def lexerCommandName(self):
            return self.getTypedRuleContext(ANTLRv4Parser.LexerCommandNameContext,0)


        def LPAREN(self):
            return self.getToken(ANTLRv4Parser.LPAREN, 0)

        def lexerCommandExpr(self):
            return self.getTypedRuleContext(ANTLRv4Parser.LexerCommandExprContext,0)


        def RPAREN(self):
            return self.getToken(ANTLRv4Parser.RPAREN, 0)

        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_lexerCommand

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLexerCommand" ):
                listener.enterLexerCommand(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLexerCommand" ):
                listener.exitLexerCommand(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLexerCommand" ):
                return visitor.visitLexerCommand(self)
            else:
                return visitor.visitChildren(self)




    def lexerCommand(self):

        localctx = ANTLRv4Parser.LexerCommandContext(self, self._ctx, self.state)
        self.enterRule(localctx, 82, self.RULE_lexerCommand)
        try:
            self.state = 473
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,50,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 467
                self.lexerCommandName()
                self.state = 468
                self.match(ANTLRv4Parser.LPAREN)
                self.state = 469
                self.lexerCommandExpr()
                self.state = 470
                self.match(ANTLRv4Parser.RPAREN)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 472
                self.lexerCommandName()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LexerCommandNameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(ANTLRv4Parser.IdentifierContext,0)


        def MODE(self):
            return self.getToken(ANTLRv4Parser.MODE, 0)

        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_lexerCommandName

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLexerCommandName" ):
                listener.enterLexerCommandName(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLexerCommandName" ):
                listener.exitLexerCommandName(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLexerCommandName" ):
                return visitor.visitLexerCommandName(self)
            else:
                return visitor.visitChildren(self)




    def lexerCommandName(self):

        localctx = ANTLRv4Parser.LexerCommandNameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 84, self.RULE_lexerCommandName)
        try:
            self.state = 477
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1, 2]:
                self.enterOuterAlt(localctx, 1)
                self.state = 475
                self.identifier()
                pass
            elif token in [30]:
                self.enterOuterAlt(localctx, 2)
                self.state = 476
                self.match(ANTLRv4Parser.MODE)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LexerCommandExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(ANTLRv4Parser.IdentifierContext,0)


        def INT(self):
            return self.getToken(ANTLRv4Parser.INT, 0)

        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_lexerCommandExpr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLexerCommandExpr" ):
                listener.enterLexerCommandExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLexerCommandExpr" ):
                listener.exitLexerCommandExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLexerCommandExpr" ):
                return visitor.visitLexerCommandExpr(self)
            else:
                return visitor.visitChildren(self)




    def lexerCommandExpr(self):

        localctx = ANTLRv4Parser.LexerCommandExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 86, self.RULE_lexerCommandExpr)
        try:
            self.state = 481
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1, 2]:
                self.enterOuterAlt(localctx, 1)
                self.state = 479
                self.identifier()
                pass
            elif token in [9]:
                self.enterOuterAlt(localctx, 2)
                self.state = 480
                self.match(ANTLRv4Parser.INT)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AltListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._alternative = None # type: ANTLRv4Parser.AlternativeContext
            self.alts = list() # type: list[ANTLRv4Parser.AlternativeContext]

        def alternative(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ANTLRv4Parser.AlternativeContext)
            else:
                return self.getTypedRuleContext(ANTLRv4Parser.AlternativeContext,i)


        def OR(self, i:int=None):
            if i is None:
                return self.getTokens(ANTLRv4Parser.OR)
            else:
                return self.getToken(ANTLRv4Parser.OR, i)

        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_altList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAltList" ):
                listener.enterAltList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAltList" ):
                listener.exitAltList(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAltList" ):
                return visitor.visitAltList(self)
            else:
                return visitor.visitChildren(self)




    def altList(self):

        localctx = ANTLRv4Parser.AltListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 88, self.RULE_altList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 483
            localctx._alternative = self.alternative()
            localctx.alts.append(localctx._alternative)
            self.state = 488
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==46:
                self.state = 484
                self.match(ANTLRv4Parser.OR)
                self.state = 485
                localctx._alternative = self.alternative()
                localctx.alts.append(localctx._alternative)
                self.state = 490
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AlternativeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._element = None # type: ANTLRv4Parser.ElementContext
            self.elements = list() # type: list[ANTLRv4Parser.ElementContext]

        def elementOptions(self):
            return self.getTypedRuleContext(ANTLRv4Parser.ElementOptionsContext,0)


        def element(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ANTLRv4Parser.ElementContext)
            else:
                return self.getTypedRuleContext(ANTLRv4Parser.ElementContext,i)


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_alternative

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAlternative" ):
                listener.enterAlternative(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAlternative" ):
                listener.exitAlternative(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAlternative" ):
                return visitor.visitAlternative(self)
            else:
                return visitor.visitChildren(self)




    def alternative(self):

        localctx = ANTLRv4Parser.AlternativeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 90, self.RULE_alternative)
        self._la = 0 # Token type
        try:
            self.state = 500
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1, 2, 5, 10, 13, 35, 39, 49, 52]:
                self.enterOuterAlt(localctx, 1)
                self.state = 492
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==39:
                    self.state = 491
                    self.elementOptions()


                self.state = 495 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while True:
                    self.state = 494
                    localctx._element = self.element()
                    localctx.elements.append(localctx._element)
                    self.state = 497 
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 5066583940539430) != 0)):
                        break

                pass
            elif token in [34, 36, 46, 51]:
                self.enterOuterAlt(localctx, 2)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ElementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_element

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class ParserElementLabeledContext(ElementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.ElementContext
            super().__init__(parser)
            self.value = None # type: ANTLRv4Parser.LabeledElementContext
            self.suffix = None # type: ANTLRv4Parser.EbnfSuffixContext
            self.copyFrom(ctx)

        def labeledElement(self):
            return self.getTypedRuleContext(ANTLRv4Parser.LabeledElementContext,0)

        def ebnfSuffix(self):
            return self.getTypedRuleContext(ANTLRv4Parser.EbnfSuffixContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParserElementLabeled" ):
                listener.enterParserElementLabeled(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParserElementLabeled" ):
                listener.exitParserElementLabeled(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParserElementLabeled" ):
                return visitor.visitParserElementLabeled(self)
            else:
                return visitor.visitChildren(self)


    class ParserElementBlockContext(ElementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.ElementContext
            super().__init__(parser)
            self.value = None # type: ANTLRv4Parser.BlockContext
            self.suffix = None # type: ANTLRv4Parser.EbnfSuffixContext
            self.copyFrom(ctx)

        def block(self):
            return self.getTypedRuleContext(ANTLRv4Parser.BlockContext,0)

        def ebnfSuffix(self):
            return self.getTypedRuleContext(ANTLRv4Parser.EbnfSuffixContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParserElementBlock" ):
                listener.enterParserElementBlock(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParserElementBlock" ):
                listener.exitParserElementBlock(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParserElementBlock" ):
                return visitor.visitParserElementBlock(self)
            else:
                return visitor.visitChildren(self)


    class ParserElementAtomContext(ElementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.ElementContext
            super().__init__(parser)
            self.value = None # type: ANTLRv4Parser.AtomContext
            self.suffix = None # type: ANTLRv4Parser.EbnfSuffixContext
            self.copyFrom(ctx)

        def atom(self):
            return self.getTypedRuleContext(ANTLRv4Parser.AtomContext,0)

        def ebnfSuffix(self):
            return self.getTypedRuleContext(ANTLRv4Parser.EbnfSuffixContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParserElementAtom" ):
                listener.enterParserElementAtom(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParserElementAtom" ):
                listener.exitParserElementAtom(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParserElementAtom" ):
                return visitor.visitParserElementAtom(self)
            else:
                return visitor.visitChildren(self)


    class ParserInlineDocContext(ElementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.ElementContext
            super().__init__(parser)
            self.value = None # type: Token
            self.copyFrom(ctx)

        def DOC_COMMENT(self):
            return self.getToken(ANTLRv4Parser.DOC_COMMENT, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParserInlineDoc" ):
                listener.enterParserInlineDoc(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParserInlineDoc" ):
                listener.exitParserInlineDoc(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParserInlineDoc" ):
                return visitor.visitParserInlineDoc(self)
            else:
                return visitor.visitChildren(self)


    class ParserElementActionContext(ElementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.ElementContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def actionBlock(self):
            return self.getTypedRuleContext(ANTLRv4Parser.ActionBlockContext,0)

        def QUESTION(self):
            return self.getToken(ANTLRv4Parser.QUESTION, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParserElementAction" ):
                listener.enterParserElementAction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParserElementAction" ):
                listener.exitParserElementAction(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParserElementAction" ):
                return visitor.visitParserElementAction(self)
            else:
                return visitor.visitChildren(self)



    def element(self):

        localctx = ANTLRv4Parser.ElementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 92, self.RULE_element)
        self._la = 0 # Token type
        try:
            self.state = 519
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,61,self._ctx)
            if la_ == 1:
                localctx = ANTLRv4Parser.ParserElementLabeledContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 502
                localctx.value = self.labeledElement()
                self.state = 504
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & 48378511622144) != 0):
                    self.state = 503
                    localctx.suffix = self.ebnfSuffix()


                pass

            elif la_ == 2:
                localctx = ANTLRv4Parser.ParserElementAtomContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 506
                localctx.value = self.atom()
                self.state = 508
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & 48378511622144) != 0):
                    self.state = 507
                    localctx.suffix = self.ebnfSuffix()


                pass

            elif la_ == 3:
                localctx = ANTLRv4Parser.ParserElementBlockContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 510
                localctx.value = self.block()
                self.state = 512
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & 48378511622144) != 0):
                    self.state = 511
                    localctx.suffix = self.ebnfSuffix()


                pass

            elif la_ == 4:
                localctx = ANTLRv4Parser.ParserElementActionContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 514
                self.actionBlock()
                self.state = 516
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==42:
                    self.state = 515
                    self.match(ANTLRv4Parser.QUESTION)


                pass

            elif la_ == 5:
                localctx = ANTLRv4Parser.ParserInlineDocContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 518
                localctx.value = self.match(ANTLRv4Parser.DOC_COMMENT)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LabeledElementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(ANTLRv4Parser.IdentifierContext,0)


        def ASSIGN(self):
            return self.getToken(ANTLRv4Parser.ASSIGN, 0)

        def PLUS_ASSIGN(self):
            return self.getToken(ANTLRv4Parser.PLUS_ASSIGN, 0)

        def atom(self):
            return self.getTypedRuleContext(ANTLRv4Parser.AtomContext,0)


        def block(self):
            return self.getTypedRuleContext(ANTLRv4Parser.BlockContext,0)


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_labeledElement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLabeledElement" ):
                listener.enterLabeledElement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLabeledElement" ):
                listener.exitLabeledElement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLabeledElement" ):
                return visitor.visitLabeledElement(self)
            else:
                return visitor.visitChildren(self)




    def labeledElement(self):

        localctx = ANTLRv4Parser.LabeledElementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 94, self.RULE_labeledElement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 521
            self.identifier()
            self.state = 522
            _la = self._input.LA(1)
            if not(_la==41 or _la==44):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 525
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1, 2, 10, 49, 52]:
                self.state = 523
                self.atom()
                pass
            elif token in [35]:
                self.state = 524
                self.block()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EbnfSuffixContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def QUESTION(self, i:int=None):
            if i is None:
                return self.getTokens(ANTLRv4Parser.QUESTION)
            else:
                return self.getToken(ANTLRv4Parser.QUESTION, i)

        def STAR(self):
            return self.getToken(ANTLRv4Parser.STAR, 0)

        def PLUS(self):
            return self.getToken(ANTLRv4Parser.PLUS, 0)

        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_ebnfSuffix

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEbnfSuffix" ):
                listener.enterEbnfSuffix(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEbnfSuffix" ):
                listener.exitEbnfSuffix(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEbnfSuffix" ):
                return visitor.visitEbnfSuffix(self)
            else:
                return visitor.visitChildren(self)




    def ebnfSuffix(self):

        localctx = ANTLRv4Parser.EbnfSuffixContext(self, self._ctx, self.state)
        self.enterRule(localctx, 96, self.RULE_ebnfSuffix)
        self._la = 0 # Token type
        try:
            self.state = 539
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [42]:
                self.enterOuterAlt(localctx, 1)
                self.state = 527
                self.match(ANTLRv4Parser.QUESTION)
                self.state = 529
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==42:
                    self.state = 528
                    self.match(ANTLRv4Parser.QUESTION)


                pass
            elif token in [43]:
                self.enterOuterAlt(localctx, 2)
                self.state = 531
                self.match(ANTLRv4Parser.STAR)
                self.state = 533
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==42:
                    self.state = 532
                    self.match(ANTLRv4Parser.QUESTION)


                pass
            elif token in [45]:
                self.enterOuterAlt(localctx, 3)
                self.state = 535
                self.match(ANTLRv4Parser.PLUS)
                self.state = 537
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==42:
                    self.state = 536
                    self.match(ANTLRv4Parser.QUESTION)


                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LexerAtomContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_lexerAtom

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class LexerAtomNotContext(LexerAtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.LexerAtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def notSet(self):
            return self.getTypedRuleContext(ANTLRv4Parser.NotSetContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLexerAtomNot" ):
                listener.enterLexerAtomNot(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLexerAtomNot" ):
                listener.exitLexerAtomNot(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLexerAtomNot" ):
                return visitor.visitLexerAtomNot(self)
            else:
                return visitor.visitChildren(self)


    class LexerAtomRangeContext(LexerAtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.LexerAtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def characterRange(self):
            return self.getTypedRuleContext(ANTLRv4Parser.CharacterRangeContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLexerAtomRange" ):
                listener.enterLexerAtomRange(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLexerAtomRange" ):
                listener.exitLexerAtomRange(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLexerAtomRange" ):
                return visitor.visitLexerAtomRange(self)
            else:
                return visitor.visitChildren(self)


    class LexerAtomCharSetContext(LexerAtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.LexerAtomContext
            super().__init__(parser)
            self.value = None # type: Token
            self.copyFrom(ctx)

        def LEXER_CHAR_SET(self):
            return self.getToken(ANTLRv4Parser.LEXER_CHAR_SET, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLexerAtomCharSet" ):
                listener.enterLexerAtomCharSet(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLexerAtomCharSet" ):
                listener.exitLexerAtomCharSet(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLexerAtomCharSet" ):
                return visitor.visitLexerAtomCharSet(self)
            else:
                return visitor.visitChildren(self)


    class LexerAtomWildcardContext(LexerAtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.LexerAtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def DOT(self):
            return self.getToken(ANTLRv4Parser.DOT, 0)
        def elementOptions(self):
            return self.getTypedRuleContext(ANTLRv4Parser.ElementOptionsContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLexerAtomWildcard" ):
                listener.enterLexerAtomWildcard(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLexerAtomWildcard" ):
                listener.exitLexerAtomWildcard(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLexerAtomWildcard" ):
                return visitor.visitLexerAtomWildcard(self)
            else:
                return visitor.visitChildren(self)


    class LexerAtomTerminalContext(LexerAtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.LexerAtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def terminal(self):
            return self.getTypedRuleContext(ANTLRv4Parser.TerminalContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLexerAtomTerminal" ):
                listener.enterLexerAtomTerminal(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLexerAtomTerminal" ):
                listener.exitLexerAtomTerminal(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLexerAtomTerminal" ):
                return visitor.visitLexerAtomTerminal(self)
            else:
                return visitor.visitChildren(self)


    class LexerAtomDocContext(LexerAtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.LexerAtomContext
            super().__init__(parser)
            self.value = None # type: Token
            self.copyFrom(ctx)

        def DOC_COMMENT(self):
            return self.getToken(ANTLRv4Parser.DOC_COMMENT, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLexerAtomDoc" ):
                listener.enterLexerAtomDoc(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLexerAtomDoc" ):
                listener.exitLexerAtomDoc(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLexerAtomDoc" ):
                return visitor.visitLexerAtomDoc(self)
            else:
                return visitor.visitChildren(self)



    def lexerAtom(self):

        localctx = ANTLRv4Parser.LexerAtomContext(self, self._ctx, self.state)
        self.enterRule(localctx, 98, self.RULE_lexerAtom)
        self._la = 0 # Token type
        try:
            self.state = 550
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,68,self._ctx)
            if la_ == 1:
                localctx = ANTLRv4Parser.LexerAtomRangeContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 541
                self.characterRange()
                pass

            elif la_ == 2:
                localctx = ANTLRv4Parser.LexerAtomTerminalContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 542
                self.terminal()
                pass

            elif la_ == 3:
                localctx = ANTLRv4Parser.LexerAtomNotContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 543
                self.notSet()
                pass

            elif la_ == 4:
                localctx = ANTLRv4Parser.LexerAtomCharSetContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 544
                localctx.value = self.match(ANTLRv4Parser.LEXER_CHAR_SET)
                pass

            elif la_ == 5:
                localctx = ANTLRv4Parser.LexerAtomWildcardContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 545
                self.match(ANTLRv4Parser.DOT)
                self.state = 547
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==39:
                    self.state = 546
                    self.elementOptions()


                pass

            elif la_ == 6:
                localctx = ANTLRv4Parser.LexerAtomDocContext(self, localctx)
                self.enterOuterAlt(localctx, 6)
                self.state = 549
                localctx.value = self.match(ANTLRv4Parser.DOC_COMMENT)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AtomContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_atom

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class AtomTerminalContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def terminal(self):
            return self.getTypedRuleContext(ANTLRv4Parser.TerminalContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtomTerminal" ):
                listener.enterAtomTerminal(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtomTerminal" ):
                listener.exitAtomTerminal(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAtomTerminal" ):
                return visitor.visitAtomTerminal(self)
            else:
                return visitor.visitChildren(self)


    class AtomWildcardContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def DOT(self):
            return self.getToken(ANTLRv4Parser.DOT, 0)
        def elementOptions(self):
            return self.getTypedRuleContext(ANTLRv4Parser.ElementOptionsContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtomWildcard" ):
                listener.enterAtomWildcard(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtomWildcard" ):
                listener.exitAtomWildcard(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAtomWildcard" ):
                return visitor.visitAtomWildcard(self)
            else:
                return visitor.visitChildren(self)


    class AtomRuleRefContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ruleref(self):
            return self.getTypedRuleContext(ANTLRv4Parser.RulerefContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtomRuleRef" ):
                listener.enterAtomRuleRef(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtomRuleRef" ):
                listener.exitAtomRuleRef(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAtomRuleRef" ):
                return visitor.visitAtomRuleRef(self)
            else:
                return visitor.visitChildren(self)


    class AtomNotContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def notSet(self):
            return self.getTypedRuleContext(ANTLRv4Parser.NotSetContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtomNot" ):
                listener.enterAtomNot(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtomNot" ):
                listener.exitAtomNot(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAtomNot" ):
                return visitor.visitAtomNot(self)
            else:
                return visitor.visitChildren(self)



    def atom(self):

        localctx = ANTLRv4Parser.AtomContext(self, self._ctx, self.state)
        self.enterRule(localctx, 100, self.RULE_atom)
        self._la = 0 # Token type
        try:
            self.state = 559
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1, 10]:
                localctx = ANTLRv4Parser.AtomTerminalContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 552
                self.terminal()
                pass
            elif token in [2]:
                localctx = ANTLRv4Parser.AtomRuleRefContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 553
                self.ruleref()
                pass
            elif token in [52]:
                localctx = ANTLRv4Parser.AtomNotContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 554
                self.notSet()
                pass
            elif token in [49]:
                localctx = ANTLRv4Parser.AtomWildcardContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 555
                self.match(ANTLRv4Parser.DOT)
                self.state = 557
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==39:
                    self.state = 556
                    self.elementOptions()


                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NotSetContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_notSet

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class NotBlockContext(NotSetContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.NotSetContext
            super().__init__(parser)
            self.value = None # type: ANTLRv4Parser.BlockSetContext
            self.copyFrom(ctx)

        def NOT(self):
            return self.getToken(ANTLRv4Parser.NOT, 0)
        def blockSet(self):
            return self.getTypedRuleContext(ANTLRv4Parser.BlockSetContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNotBlock" ):
                listener.enterNotBlock(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNotBlock" ):
                listener.exitNotBlock(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNotBlock" ):
                return visitor.visitNotBlock(self)
            else:
                return visitor.visitChildren(self)


    class NotElementContext(NotSetContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.NotSetContext
            super().__init__(parser)
            self.value = None # type: ANTLRv4Parser.SetElementContext
            self.copyFrom(ctx)

        def NOT(self):
            return self.getToken(ANTLRv4Parser.NOT, 0)
        def setElement(self):
            return self.getTypedRuleContext(ANTLRv4Parser.SetElementContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNotElement" ):
                listener.enterNotElement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNotElement" ):
                listener.exitNotElement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNotElement" ):
                return visitor.visitNotElement(self)
            else:
                return visitor.visitChildren(self)



    def notSet(self):

        localctx = ANTLRv4Parser.NotSetContext(self, self._ctx, self.state)
        self.enterRule(localctx, 102, self.RULE_notSet)
        try:
            self.state = 565
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,71,self._ctx)
            if la_ == 1:
                localctx = ANTLRv4Parser.NotElementContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 561
                self.match(ANTLRv4Parser.NOT)
                self.state = 562
                localctx.value = self.setElement()
                pass

            elif la_ == 2:
                localctx = ANTLRv4Parser.NotBlockContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 563
                self.match(ANTLRv4Parser.NOT)
                self.state = 564
                localctx.value = self.blockSet()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BlockSetContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._setElement = None # type: ANTLRv4Parser.SetElementContext
            self.elements = list() # type: list[ANTLRv4Parser.SetElementContext]

        def LPAREN(self):
            return self.getToken(ANTLRv4Parser.LPAREN, 0)

        def RPAREN(self):
            return self.getToken(ANTLRv4Parser.RPAREN, 0)

        def setElement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ANTLRv4Parser.SetElementContext)
            else:
                return self.getTypedRuleContext(ANTLRv4Parser.SetElementContext,i)


        def OR(self, i:int=None):
            if i is None:
                return self.getTokens(ANTLRv4Parser.OR)
            else:
                return self.getToken(ANTLRv4Parser.OR, i)

        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_blockSet

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBlockSet" ):
                listener.enterBlockSet(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBlockSet" ):
                listener.exitBlockSet(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBlockSet" ):
                return visitor.visitBlockSet(self)
            else:
                return visitor.visitChildren(self)




    def blockSet(self):

        localctx = ANTLRv4Parser.BlockSetContext(self, self._ctx, self.state)
        self.enterRule(localctx, 104, self.RULE_blockSet)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 567
            self.match(ANTLRv4Parser.LPAREN)
            self.state = 568
            localctx._setElement = self.setElement()
            localctx.elements.append(localctx._setElement)
            self.state = 573
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==46:
                self.state = 569
                self.match(ANTLRv4Parser.OR)
                self.state = 570
                localctx._setElement = self.setElement()
                localctx.elements.append(localctx._setElement)
                self.state = 575
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 576
            self.match(ANTLRv4Parser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SetElementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_setElement

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class SetElementRefContext(SetElementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.SetElementContext
            super().__init__(parser)
            self.value = None # type: Token
            self.copyFrom(ctx)

        def TOKEN_REF(self):
            return self.getToken(ANTLRv4Parser.TOKEN_REF, 0)
        def elementOptions(self):
            return self.getTypedRuleContext(ANTLRv4Parser.ElementOptionsContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSetElementRef" ):
                listener.enterSetElementRef(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSetElementRef" ):
                listener.exitSetElementRef(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSetElementRef" ):
                return visitor.visitSetElementRef(self)
            else:
                return visitor.visitChildren(self)


    class SetElementRangeContext(SetElementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.SetElementContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def characterRange(self):
            return self.getTypedRuleContext(ANTLRv4Parser.CharacterRangeContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSetElementRange" ):
                listener.enterSetElementRange(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSetElementRange" ):
                listener.exitSetElementRange(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSetElementRange" ):
                return visitor.visitSetElementRange(self)
            else:
                return visitor.visitChildren(self)


    class SetElementLitContext(SetElementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.SetElementContext
            super().__init__(parser)
            self.value = None # type: Token
            self.copyFrom(ctx)

        def STRING_LITERAL(self):
            return self.getToken(ANTLRv4Parser.STRING_LITERAL, 0)
        def elementOptions(self):
            return self.getTypedRuleContext(ANTLRv4Parser.ElementOptionsContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSetElementLit" ):
                listener.enterSetElementLit(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSetElementLit" ):
                listener.exitSetElementLit(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSetElementLit" ):
                return visitor.visitSetElementLit(self)
            else:
                return visitor.visitChildren(self)


    class SetElementCharSetContext(SetElementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.SetElementContext
            super().__init__(parser)
            self.value = None # type: Token
            self.copyFrom(ctx)

        def LEXER_CHAR_SET(self):
            return self.getToken(ANTLRv4Parser.LEXER_CHAR_SET, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSetElementCharSet" ):
                listener.enterSetElementCharSet(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSetElementCharSet" ):
                listener.exitSetElementCharSet(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSetElementCharSet" ):
                return visitor.visitSetElementCharSet(self)
            else:
                return visitor.visitChildren(self)



    def setElement(self):

        localctx = ANTLRv4Parser.SetElementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 106, self.RULE_setElement)
        self._la = 0 # Token type
        try:
            self.state = 588
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,75,self._ctx)
            if la_ == 1:
                localctx = ANTLRv4Parser.SetElementRefContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 578
                localctx.value = self.match(ANTLRv4Parser.TOKEN_REF)
                self.state = 580
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==39:
                    self.state = 579
                    self.elementOptions()


                pass

            elif la_ == 2:
                localctx = ANTLRv4Parser.SetElementLitContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 582
                localctx.value = self.match(ANTLRv4Parser.STRING_LITERAL)
                self.state = 584
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==39:
                    self.state = 583
                    self.elementOptions()


                pass

            elif la_ == 3:
                localctx = ANTLRv4Parser.SetElementRangeContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 586
                self.characterRange()
                pass

            elif la_ == 4:
                localctx = ANTLRv4Parser.SetElementCharSetContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 587
                localctx.value = self.match(ANTLRv4Parser.LEXER_CHAR_SET)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BlockContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LPAREN(self):
            return self.getToken(ANTLRv4Parser.LPAREN, 0)

        def altList(self):
            return self.getTypedRuleContext(ANTLRv4Parser.AltListContext,0)


        def RPAREN(self):
            return self.getToken(ANTLRv4Parser.RPAREN, 0)

        def COLON(self):
            return self.getToken(ANTLRv4Parser.COLON, 0)

        def optionsSpec(self):
            return self.getTypedRuleContext(ANTLRv4Parser.OptionsSpecContext,0)


        def ruleAction(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ANTLRv4Parser.RuleActionContext)
            else:
                return self.getTypedRuleContext(ANTLRv4Parser.RuleActionContext,i)


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_block

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBlock" ):
                listener.enterBlock(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBlock" ):
                listener.exitBlock(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBlock" ):
                return visitor.visitBlock(self)
            else:
                return visitor.visitChildren(self)




    def block(self):

        localctx = ANTLRv4Parser.BlockContext(self, self._ctx, self.state)
        self.enterRule(localctx, 108, self.RULE_block)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 590
            self.match(ANTLRv4Parser.LPAREN)
            self.state = 601
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 1125902054342656) != 0):
                self.state = 592
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==14:
                    self.state = 591
                    self.optionsSpec()


                self.state = 597
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==50:
                    self.state = 594
                    self.ruleAction()
                    self.state = 599
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 600
                self.match(ANTLRv4Parser.COLON)


            self.state = 603
            self.altList()
            self.state = 604
            self.match(ANTLRv4Parser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RulerefContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.value = None # type: Token

        def RULE_REF(self):
            return self.getToken(ANTLRv4Parser.RULE_REF, 0)

        def argActionBlock(self):
            return self.getTypedRuleContext(ANTLRv4Parser.ArgActionBlockContext,0)


        def elementOptions(self):
            return self.getTypedRuleContext(ANTLRv4Parser.ElementOptionsContext,0)


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_ruleref

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRuleref" ):
                listener.enterRuleref(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRuleref" ):
                listener.exitRuleref(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRuleref" ):
                return visitor.visitRuleref(self)
            else:
                return visitor.visitChildren(self)




    def ruleref(self):

        localctx = ANTLRv4Parser.RulerefContext(self, self._ctx, self.state)
        self.enterRule(localctx, 110, self.RULE_ruleref)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 606
            localctx.value = self.match(ANTLRv4Parser.RULE_REF)
            self.state = 608
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==12:
                self.state = 607
                self.argActionBlock()


            self.state = 611
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==39:
                self.state = 610
                self.elementOptions()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CharacterRangeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.start = None # type: Token
            self.end = None # type: Token

        def RANGE(self):
            return self.getToken(ANTLRv4Parser.RANGE, 0)

        def STRING_LITERAL(self, i:int=None):
            if i is None:
                return self.getTokens(ANTLRv4Parser.STRING_LITERAL)
            else:
                return self.getToken(ANTLRv4Parser.STRING_LITERAL, i)

        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_characterRange

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCharacterRange" ):
                listener.enterCharacterRange(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCharacterRange" ):
                listener.exitCharacterRange(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCharacterRange" ):
                return visitor.visitCharacterRange(self)
            else:
                return visitor.visitChildren(self)




    def characterRange(self):

        localctx = ANTLRv4Parser.CharacterRangeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 112, self.RULE_characterRange)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 613
            localctx.start = self.match(ANTLRv4Parser.STRING_LITERAL)
            self.state = 614
            self.match(ANTLRv4Parser.RANGE)
            self.state = 615
            localctx.end = self.match(ANTLRv4Parser.STRING_LITERAL)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TerminalContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_terminal

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class TerminalRefContext(TerminalContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.TerminalContext
            super().__init__(parser)
            self.value = None # type: Token
            self.copyFrom(ctx)

        def TOKEN_REF(self):
            return self.getToken(ANTLRv4Parser.TOKEN_REF, 0)
        def elementOptions(self):
            return self.getTypedRuleContext(ANTLRv4Parser.ElementOptionsContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTerminalRef" ):
                listener.enterTerminalRef(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTerminalRef" ):
                listener.exitTerminalRef(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTerminalRef" ):
                return visitor.visitTerminalRef(self)
            else:
                return visitor.visitChildren(self)


    class TerminalLitContext(TerminalContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.TerminalContext
            super().__init__(parser)
            self.value = None # type: Token
            self.copyFrom(ctx)

        def STRING_LITERAL(self):
            return self.getToken(ANTLRv4Parser.STRING_LITERAL, 0)
        def elementOptions(self):
            return self.getTypedRuleContext(ANTLRv4Parser.ElementOptionsContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTerminalLit" ):
                listener.enterTerminalLit(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTerminalLit" ):
                listener.exitTerminalLit(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTerminalLit" ):
                return visitor.visitTerminalLit(self)
            else:
                return visitor.visitChildren(self)



    def terminal(self):

        localctx = ANTLRv4Parser.TerminalContext(self, self._ctx, self.state)
        self.enterRule(localctx, 114, self.RULE_terminal)
        self._la = 0 # Token type
        try:
            self.state = 625
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1]:
                localctx = ANTLRv4Parser.TerminalRefContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 617
                localctx.value = self.match(ANTLRv4Parser.TOKEN_REF)
                self.state = 619
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==39:
                    self.state = 618
                    self.elementOptions()


                pass
            elif token in [10]:
                localctx = ANTLRv4Parser.TerminalLitContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 621
                localctx.value = self.match(ANTLRv4Parser.STRING_LITERAL)
                self.state = 623
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==39:
                    self.state = 622
                    self.elementOptions()


                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ElementOptionsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LT(self):
            return self.getToken(ANTLRv4Parser.LT, 0)

        def elementOption(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ANTLRv4Parser.ElementOptionContext)
            else:
                return self.getTypedRuleContext(ANTLRv4Parser.ElementOptionContext,i)


        def GT(self):
            return self.getToken(ANTLRv4Parser.GT, 0)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(ANTLRv4Parser.COMMA)
            else:
                return self.getToken(ANTLRv4Parser.COMMA, i)

        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_elementOptions

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterElementOptions" ):
                listener.enterElementOptions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitElementOptions" ):
                listener.exitElementOptions(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitElementOptions" ):
                return visitor.visitElementOptions(self)
            else:
                return visitor.visitChildren(self)




    def elementOptions(self):

        localctx = ANTLRv4Parser.ElementOptionsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 116, self.RULE_elementOptions)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 627
            self.match(ANTLRv4Parser.LT)
            self.state = 628
            self.elementOption()
            self.state = 633
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==33:
                self.state = 629
                self.match(ANTLRv4Parser.COMMA)
                self.state = 630
                self.elementOption()
                self.state = 635
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 636
            self.match(ANTLRv4Parser.GT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ElementOptionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ANTLRv4Parser.IdentifierContext)
            else:
                return self.getTypedRuleContext(ANTLRv4Parser.IdentifierContext,i)


        def ASSIGN(self):
            return self.getToken(ANTLRv4Parser.ASSIGN, 0)

        def STRING_LITERAL(self):
            return self.getToken(ANTLRv4Parser.STRING_LITERAL, 0)

        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_elementOption

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterElementOption" ):
                listener.enterElementOption(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitElementOption" ):
                listener.exitElementOption(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitElementOption" ):
                return visitor.visitElementOption(self)
            else:
                return visitor.visitChildren(self)




    def elementOption(self):

        localctx = ANTLRv4Parser.ElementOptionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 118, self.RULE_elementOption)
        try:
            self.state = 645
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,86,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 638
                self.identifier()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 639
                self.identifier()
                self.state = 640
                self.match(ANTLRv4Parser.ASSIGN)
                self.state = 643
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [1, 2]:
                    self.state = 641
                    self.identifier()
                    pass
                elif token in [10]:
                    self.state = 642
                    self.match(ANTLRv4Parser.STRING_LITERAL)
                    pass
                else:
                    raise NoViableAltException(self)

                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IdentifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return ANTLRv4Parser.RULE_identifier

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class RuleRefIdentifierContext(IdentifierContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.IdentifierContext
            super().__init__(parser)
            self.value = None # type: Token
            self.copyFrom(ctx)

        def RULE_REF(self):
            return self.getToken(ANTLRv4Parser.RULE_REF, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRuleRefIdentifier" ):
                listener.enterRuleRefIdentifier(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRuleRefIdentifier" ):
                listener.exitRuleRefIdentifier(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRuleRefIdentifier" ):
                return visitor.visitRuleRefIdentifier(self)
            else:
                return visitor.visitChildren(self)


    class TokenRefIdentifierContext(IdentifierContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a ANTLRv4Parser.IdentifierContext
            super().__init__(parser)
            self.value = None # type: Token
            self.copyFrom(ctx)

        def TOKEN_REF(self):
            return self.getToken(ANTLRv4Parser.TOKEN_REF, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTokenRefIdentifier" ):
                listener.enterTokenRefIdentifier(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTokenRefIdentifier" ):
                listener.exitTokenRefIdentifier(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTokenRefIdentifier" ):
                return visitor.visitTokenRefIdentifier(self)
            else:
                return visitor.visitChildren(self)



    def identifier(self):

        localctx = ANTLRv4Parser.IdentifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 120, self.RULE_identifier)
        try:
            self.state = 649
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [2]:
                localctx = ANTLRv4Parser.RuleRefIdentifierContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 647
                localctx.value = self.match(ANTLRv4Parser.RULE_REF)
                pass
            elif token in [1]:
                localctx = ANTLRv4Parser.TokenRefIdentifierContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 648
                localctx.value = self.match(ANTLRv4Parser.TOKEN_REF)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





