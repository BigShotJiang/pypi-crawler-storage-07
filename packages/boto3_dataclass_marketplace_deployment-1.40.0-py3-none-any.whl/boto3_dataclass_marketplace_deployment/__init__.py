# -*- coding: utf-8 -*-

from .caster import marketplace_deployment_caster

caster = marketplace_deployment_caster

__version__ = "1.40.0"