# -*- coding: utf-8 -*-

from .caster import sdb_caster

caster = sdb_caster

__version__ = "1.40.0"