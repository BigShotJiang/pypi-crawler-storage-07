﻿guarneri.instrument.Instrument.load
===================================

.. currentmodule:: guarneri.instrument

.. automethod:: Instrument.load