﻿guarneri.instrument.Instrument.parse\_config
============================================

.. currentmodule:: guarneri.instrument

.. automethod:: Instrument.parse_config