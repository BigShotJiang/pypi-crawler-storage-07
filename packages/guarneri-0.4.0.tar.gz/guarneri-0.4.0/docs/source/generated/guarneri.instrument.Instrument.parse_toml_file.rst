﻿guarneri.instrument.Instrument.parse\_toml\_file
================================================

.. currentmodule:: guarneri.instrument

.. automethod:: Instrument.parse_toml_file