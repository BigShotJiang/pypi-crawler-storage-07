API
---

.. autosummary::
    :toctree: generated

    guarneri.instrument
    guarneri.instrument.Instrument
    guarneri.instrument.Instrument.load
    guarneri.instrument.Instrument.parse_config
    guarneri.instrument.Instrument.parse_toml_file
    guarneri.instrument.Instrument.parse_yaml_file
