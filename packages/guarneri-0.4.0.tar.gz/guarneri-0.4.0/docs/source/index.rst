Welcome to guarneri's documentation!
===========================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   tutorials/index
   how_to_guides/index
   api

.. toctree::
    :maxdepth: 1
    :caption: Links
    :hidden:

    Github Repository <https://github.com/spc-group/guarneri>



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
