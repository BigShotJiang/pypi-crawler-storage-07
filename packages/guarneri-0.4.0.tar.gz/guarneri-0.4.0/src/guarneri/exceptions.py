class InvalidConfiguration(TypeError):
    """The configuration files for Haven are missing keys."""

    ...
