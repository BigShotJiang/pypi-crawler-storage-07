import re
from urllib.parse import urlparse, parse_qs

import requests
import time
from urlextract import URLExtract

from ..api import g_tk
from ..exceptions import ClientkeyLoginException

__all__ = [
    "login_by_clientkey"
]

login_datas = [
    {
        "proxy_url": "https://qzs.qq.com/qzone/v6/portal/proxy.html",
        "daid": "5",
        "hide_title_bar": "1",
        "low_login": "0",
        "qlogin_auto_login": "1",
        "no_verifyimg": "1",
        "link_target": "blank",
        "appid": "549000912",
        "style": "22",
        "target": "self",
        "s_url": "https://qzs.qq.com/qzone/v5/loginsucc.html?para=izone",
        "pt_qr_app": "手机QQ空间",
        "pt_qr_link": "https://z.qzone.com/download.html",
        "self_regurl": "https://qzs.qq.com/qzone/v6/reg/index.html",
        "pt_qr_help_link": "https://z.qzone.com/download.html",
        "pt_no_auth": "0"
    },
    {
        "pt_disable_pwd": "1",
        "appid": "715030901",
        "hide_close_icon": "1",
        "daid": "73",
        "pt_no_auth": "1",
        "s_url": "https://qun.qq.com/"
    },
    # {"u1":"https://wx.mail.qq.com/list/readtemplate?name=login_page.html","s_url":None},
    {
        "target": "self",
        "appid": "522005705",
        "daid": "4",
        "s_url": "https://wx.mail.qq.com/list/readtemplate?name=login_jump.html",
        "style": "25",
        "low_login": "1",
        "proxy_url": "https://mail.qq.com/proxy.html",
        "need_qr": "0",
        "hide_border": "1",
        "border_radius": "0",
        "self_regurl": "https://reg.mail.qq.com",
        "app_id": "11005?t=regist",
        "pt_feedback_link": "http://support.qq.com/discuss/350_1.shtml",
        "css": "https://res.mail.qq.com/zh_CN/htmledition/style/ptlogin_input_for_xmail.css",
        "enable_qlogin": "0"
    },
    {
        "appid": "8000201",
        "style": "20",
        "s_url": "https://vip.qq.com/loginsuccess.html",
        "maskOpacity": "60",
        "daid": "18",
        "target": "self"
    },
    {
        "appid": "527020901",
        "daid": "372",
        "low_login": "0",
        "qlogin_auto_login": "1",
        "s_url": "https://www.weiyun.com/web/callback/common_qq_login_ok.html?login_succ",
        "style": "20",
        "hide_title": "1",
        "target": "self",
        "link_target": "blank",
        "hide_close_icon": "1",
        "pt_no_auth": "1",
        'u1': "https://www.weiyun.com/?adtag=ntqqmainpanel"
    },
    {
        "style": "40",
        "appid": "1600001573",
        "s_url": "https://accounts.qq.com/homepage#/",
        "daid": "761",
        "hide_close_icon": "0"
    },
    {
        "appid": "10000101",
        "s_url": "https://qqshow.qq.com/manage/myCreation",
        "hide_close_icon": "1"
    },
    {
        "s_url": "https://huifu.qq.com/recovery/index.html?frag=1",
        "style": "20",
        "appid": "715021417",
        "daid": "768",
        "proxy_url": "https://huifu.qq.com/proxy.html"
    },
    {"u1": "https://docs.qq.com/desktop/?tdsourcetag=s_ntpcqq_panel_app", "s_url": None},
    {
        "daid": "377",
        "style": "11",
        "appid": "716027613",
        "target": "self",
        "pt_disable_pwd": "1",
        "s_url": "https://connect.qq.com/login_success.html",
        "t": str(time.time())
    },
    {
        "appid": "501038301",
        "target": "self",
        "s_url": "https://im.qq.com/loginSuccess"
    }
]

def login_by_clientkey(uin:str, clientkey:str, which:int=0, force_clientkey_url:bool=False) -> str:
    """
    通过clientkey登录
    :param uin: 账号
    :param clientkey: clientkey
    :param which: 登录方式，0为QQ空间，1为QQ群，2为QQ邮箱，3为QQ会员，
                  4为微云，5为QQ账号中心，6为QQ秀，7为QQ恢复中心，
                  8为腾讯文档，9为QQ互联，10为腾讯IM
    :param force_clientkey_url: 是否强制使用clientkey登录网址，默认False(https://ssl.ptlogin2.qq.com/jump?...),如没有将报KeyError(仅支持which=0,1,4)
    :return: 登录网址
    """
    if force_clientkey_url and which not in [0, 4]:
        raise ClientkeyLoginException(f"Not support force_clientkey_url")
    login_datas[0]['u1'] = f"https://user.qzone.qq.com/{uin}/infocenter"
    session = requests.session()
    login_data = login_datas[which]
    if force_clientkey_url or not login_data['s_url']:
        return f"https://ssl.ptlogin2.qq.com/jump?ptlang={1033 if len(clientkey) == 96 else 2052}&clientuin={uin}&clientkey={clientkey}&u1={login_data['u1']}&keyindex={19 if len(clientkey) == 96 else 9}"
    if which == 2 and len(clientkey) == 96:
        login_html = session.get(
            "https://xui.ptlogin2.qq.com/cgi-bin/xlogin?appid=716027609&daid=383&style=33&login_text=%E7%99%BB%E5%BD%95&hide_title_bar=1&hide_border=1&target=self&s_url=https%3A%2F%2Fgraph.qq.com%2Foauth2.0%2Flogin_jump&pt_3rd_aid=102013353&pt_feedback_link=https%3A%2F%2Fsupport.qq.com%2Fproducts%2F77942%3FcustomInfo%3D.appid102013353&theme=10&verify_theme=")
        x_cookies = login_html.cookies.get_dict()
        pt_local_token = x_cookies.get("pt_local_token")
        session.cookies.update({"clientuin": uin, "clientkey": clientkey})
        jump_req = session.get("https://ssl.ptlogin2.qq.com/jump", params={
            "clientuin": uin,
            "keyindex": "19",
            "pt_aid": "716027609",
            "daid": "383",
            "u1": "https://graph.qq.com/oauth2.0/login_jump",
            "pt_local_tk": pt_local_token,
            "pt_3rd_aid": "102013353",
            "ptopt": "1",
            "style": "40",
            "has_onekey": "1"
        })
        sigx_jump_url = re.findall("'(.*?)'", jump_req.text)[1]
        session.get(sigx_jump_url)
        auth_data = {
            "response_type": "code",
            "client_id": "102013353",
            "redirect_uri": "https://wx.mail.qq.com/list/readtemplate?name=login_jump.html",
            "scene": "1",
            "login_type": "qq",
            "scope": "get_user_info,get_app_friends",
            "state": "",
            "switch": "",
            "from_ptlogin": "1",
            "src": "1",
            "update_auth": "1",
            "openapi": "1010",
            "g_tk": g_tk(session.cookies.get("p_skey")),
            "auth_time": int(time.time() * 1000),
        }
        auth_req = session.post("https://graph.qq.com/oauth2.0/authorize", data=auth_data, json=auth_data,
                                allow_redirects=False)
        redirect_url = urlparse(auth_req.headers['Location'])
        code = parse_qs(redirect_url.query)['code'][0]
        login_url = f"https://wx.mail.qq.com/list/readtemplate?name=login_jump.html&scene=1&login_type=qq&from=qq_panel&code={code}"
        return login_url
    if login_data['s_url']:
        login_htm = session.get(
            "https://xui.ptlogin2.qq.com/cgi-bin/xlogin", params=login_data)
        q_cookies = requests.utils.dict_from_cookiejar(login_htm.cookies)
        pt_local_token = q_cookies.get("pt_local_token")
        headers = {"Referer": "https://xui.ptlogin2.qq.com/",
                   "Host": "ssl.ptlogin2.qq.com",
                   "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0"}
        params = {
            "u1": login_data['s_url'],
            "clientuin": uin,
            "pt_aid": login_data['appid'],
            "keyindex": "19",
            "pt_local_tk": pt_local_token,
            "pt_3rd_aid": "0",
            "ptopt": "1",
            "style": "40"
        }
        if login_data.get("daid"): params['daid'] = login_data.get("daid")
        cookies = {
            "clientkey": clientkey,
            "clientuin": str(uin),
            "pt_local_token": pt_local_token
        }
        login_res = session.get("https://ssl.ptlogin2.qq.com/jump", params=params, cookies=cookies, headers=headers)
        extractor = URLExtract()
        login_url = extractor.find_urls(login_res.text)[0]
        return login_url
