class ClientkeyLoginException(Exception):
    pass
