# -*- coding: UTF-8 -*-
"""
test_project.spiders
========================
存放所有的爬虫。
"""

# 自动导入所有爬虫以确保它们被注册
# 示例：
# from .YourSpider import YourSpider