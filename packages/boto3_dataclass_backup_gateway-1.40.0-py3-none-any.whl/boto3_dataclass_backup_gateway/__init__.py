# -*- coding: utf-8 -*-

from .caster import backup_gateway_caster

caster = backup_gateway_caster

__version__ = "1.40.0"