# -*- coding: utf-8 -*-

from .caster import appconfig_caster

caster = appconfig_caster

__version__ = "1.40.0"