"""Module for glchat_plugin context."""
