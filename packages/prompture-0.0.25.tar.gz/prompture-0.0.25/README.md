# Prompture

**Prompture** is an API-first library for getting **structured JSON** (or any structure) from LLMs, validating it, and benchmarking multiple models with one spec.

## ✨ Features

- ✅ **Structured output** → JSON schema enforcement, or direct **Pydantic** instances
- ✅ **Stepwise extraction** → Per-field prompts, with smart type conversion (incl. shorthand numbers)
- ✅ **Multi-driver** → OpenAI, Azure, Claude, Ollama, HTTP, Mock, HuggingFace (via `get_driver()`)
- ✅ **Usage & cost** → Token + $ tracking on every call (`usage` from driver meta)
- ✅ **AI cleanup** → Optional LLM pass to fix malformed JSON
- ✅ **Batch testing** → Define suites and compare models (spec-driven)

<br>

> [!TIP]
> Starring this repo helps more developers discover Prompture ✨
> 
>![prompture_no_forks](https://github.com/user-attachments/assets/720f888e-a885-4eb3-970c-ba5809fe2ce7)
> 
>  🔥 Also check out my other project [RepoGif](https://github.com/jhd3197/RepoGif) – the tool I used to generate the GIF above!
<br>


---

## Installation

```bash
pip install prompture
````

---

## Configure a Provider

`get_driver()` (used by high-level helpers) selects a driver from env:

```bash
# One of: ollama | openai | azure | claude | http | huggingface
export AI_PROVIDER=ollama

# Only if the provider needs them:
export OPENAI_API_KEY=...
export AZURE_OPENAI_ENDPOINT=...
export AZURE_OPENAI_API_KEY=...
export ANTHROPIC_API_KEY=...
```

| Provider (AI_PROVIDER) | Example models              | Cost calc       |
| ---------------------- | --------------------------- | --------------- |
| `ollama`               | `llama3.1:8b`, `qwen2.5:3b` | `$0.00` (local) |
| `openai`               | `gpt-*`                     | Automatic       |
| `azure`                | Deployed names              | Automatic       |
| `claude`               | `claude-*`                  | Automatic       |
| `huggingface`          | local/endpoint              | `$0.00` (local) |
| `http`                 | self-hosted                 | `$0.00`         |

---

## Quickstart: Pydantic in one line (auto driver)

Use `extract_with_model` for a single LLM call that fills your Pydantic model.

```python
from typing import List, Optional
from pydantic import BaseModel
from prompture import extract_with_model

class Person(BaseModel):
    name: str
    age: int
    profession: str
    city: str
    hobbies: List[str]
    education: Optional[str] = None

text = "Maria is 32, a software developer in New York. She loves hiking and photography."

# Uses get_driver() internally (AI_PROVIDER). You can still pass driver/model_name.
person = extract_with_model(Person, text, model_name="gpt-oss:20b")
print(person.dict())
```

**Why start here?** It’s fast (one call), cost-efficient, and returns a validated Pydantic instance.

---

## JSON-first (low-level primitives)

When you want raw JSON with a schema and full control, use `ask_for_json` or `extract_and_jsonify`.
**Note:** these require an explicit `driver`.

```python
from prompture.drivers import get_driver
from prompture import ask_for_json, extract_and_jsonify

driver = get_driver("ollama")  # or "openai", "azure", etc.

schema = {
    "type": "object",
    "required": ["name", "age"],
    "properties": {
        "name": {"type": "string"},
        "age": {"type": "integer"}
    }
}

# 1) ask_for_json: you provide the full content prompt
resp1 = ask_for_json(
    driver=driver,
    content_prompt="Extract the person's info from: John is 28 and lives in Miami.",
    json_schema=schema,
    options={"model": "llama3.1:8b"}
)
print(resp1["json_object"], resp1["usage"])

# 2) extract_and_jsonify: you provide text & an instruction template; it builds the prompt
resp2 = extract_and_jsonify(
    driver=driver,
    text="John is 28 and lives in Miami.",
    json_schema=schema,
    model_name="llama3.1:8b",
    instruction_template="Extract the person's information:"
)
print(resp2["json_object"], resp2["usage"])
```

### Return shape (JSON helpers)

```python
{
  "json_string": str,
  "json_object": dict,
  "usage": {
    "prompt_tokens": int,
    "completion_tokens": int,
    "total_tokens": int,
    "cost": float,
    "model_name": str
  }
}
```

> If the model returns malformed JSON and `ai_cleanup=True`, a second LLM pass tries to fix it.

---

## Pydantic: one-shot vs stepwise

Prompture supports two Pydantic extraction modes:

* **`extract_with_model`** → Single call; global context; best cost/latency; coherent fields
* **`stepwise_extract_with_model`** → One call per field; higher per-field accuracy; resilient

| Aspect         | `extract_with_model` (one-shot)        | `stepwise_extract_with_model` (per-field) |
| -------------- | -------------------------------------- | ----------------------------------------- |
| LLM calls      | 1                                      | N (one per field)                         |
| Speed & cost   | **Faster / cheaper**                   | Slower / higher                           |
| Accuracy       | Good global coherence                  | **Higher per-field accuracy**             |
| Error handling | All-or-nothing                         | **Per-field recovery**                    |
| Best when      | Fields are related; throughput matters | Correctness per field is critical         |

### Examples

```python
from prompture import extract_with_model, stepwise_extract_with_model

person1 = extract_with_model(Person, text, model_name="gpt-oss:20b")
print(person1.dict())

res = stepwise_extract_with_model(Person, text, model_name="gpt-oss:20b")
print(res["model"].dict())
print(res["usage"])  # includes per-field usage and totals
```

**Stepwise extras:** internally uses `tools.create_field_schema` + `tools.convert_value` (with `allow_shorthand=True`) so values like `"3.4m"`, `"2k"`, `"1.2b"` can be converted to typed fields where appropriate.

---

## Manual control with logging

`manual_extract_and_jsonify` is like `extract_and_jsonify` but adds structured debug logging.

```python
from prompture import manual_extract_and_jsonify
from prompture.drivers import get_driver
from prompture.tools import LogLevel

driver = get_driver("ollama")
res = manual_extract_and_jsonify(
    driver=driver,
    text="Maria works as a software developer in New York.",
    json_schema={
      "type": "object",
      "required": ["city", "profession"],
      "properties": {"city": {"type": "string"}, "profession": {"type": "string"}}
    },
    model_name="llama3.1:8b",
    options={"temperature": 0.2},
    verbose_level=LogLevel.DEBUG  # TRACE for full prompts/results
)
print(res["json_object"])
```

---


**Example output (Ollama comparison)** — see `examples/ollama_models_comparison.py` for a richer comparison table.

---


## Ollama Model Comparison Example

This example demonstrates how to compare different Ollama models using a specific script located at `examples/ollama_models_comparison.py`.

| Model            | Success | Prompt | Completion | Total | Fields | Validation | Name                | Price    | Variants | Screen Size | Warranty | Is New |
|------------------|---------|--------|------------|-------|--------|------------|---------------------|----------|----------|-------------|----------|--------|
| gpt-oss:20b      | True    | 801    | 945        | 1746  | 8      | ✓          | GalaxyFold Ultra    | 1299.99  | 9        | 6.9         | 3        | True   |
| deepseek-r1:latest | True  | 757    | 679        | 1436  | 8      | ✗          | GalaxyFold Ultra    | 1299.99  | 3        | 6.9         | None     | True   |
| llama3.1:8b      | True    | 746    | 256        | 1002  | 8      | ✓          | GalaxyFold Ultra    | 1299.99  | 3        | 6.9         | 3        | True   |
| gemma3:latest    | True    | 857    | 315        | 1172  | 8      | ✗          | GalaxyFold Ultra    | 1299.99  | 3        | 6.9         | None     | True   |
| qwen2.5:1.5b     | True    | 784    | 236        | 1020  | 8      | ✓          | GalaxyFold Ultra    | 1299.99  | 3        | 6.9         | 3        | True   |
| qwen2.5:3b       | True    | 784    | 273        | 1057  | 9      | ✓          | GalaxyFold Ultra    | 1299.99  | 3        | 6.9         | 3        | True   |
| mistral:latest   | True    | 928    | 337        | 1265  | 8      | ✓          | GalaxyFold Ultra    | 1299.99  | 3        | 6.9         | 3        | True   |

> **Successful models (7):** gpt-oss:20b, deepseek-r1:latest, llama3.1:8b, gemma3:latest, qwen2.5:1.5b, qwen2.5:3b, mistral:latest

You can run this comparison yourself with:
`python examples/ollama_models_comparison.py`

This example script compares multiple Ollama models on a complex task of extracting structured information from a smartphone description using a detailed JSON schema. The purpose of this example is to illustrate how `Prompture` can be used to test and compare different models on the same structured output task, showing their success rates, token usage, and validation results.

---

## Error handling notes

* With `ai_cleanup=True`, a second LLM pass attempts to fix malformed JSON; on success, `usage` may be a minimal stub.
* `extract_and_jsonify` will **skip tests** under `pytest` if there’s a local server connection error (e.g., Ollama), instead of failing the suite.
* All functions raise `ValueError` for empty text.

---

## Tips & Best Practices

* Add `description` to schema fields (or Pydantic field metadata) for better extractions.
* Start with **one-shot Pydantic**; switch specific fields to **stepwise** if they’re noisy.
* Track usage/cost before scaling; tweak `temperature` in `options` if consistency wobbles.
* Use `verbose_level=TRACE` in dev to see prompts/results and tighten your specs.

---

## Contributing

PRs welcome! Add tests and—if adding drivers or patterns—drop an example under `examples/`.
