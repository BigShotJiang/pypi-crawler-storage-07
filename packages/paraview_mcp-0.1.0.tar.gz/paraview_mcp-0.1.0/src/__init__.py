"""
ParaView MCP - Model Context Protocol server for ParaView
"""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

from .paraview_manager import ParaViewManager

__all__ = ["ParaViewManager"]