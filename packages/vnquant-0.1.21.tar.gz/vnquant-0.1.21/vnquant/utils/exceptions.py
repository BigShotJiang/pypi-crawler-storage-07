class ShortTimePeriod(Exception):
    pass
