# Руководство пользователя PyLite

## Что такое PyLite?

PyLite - это упрощённая версия языка Python, созданная специально для обучения детей программированию. Она сохраняет основы Python, но убирает сложные конструкции, которые могут запутать начинающих.

## Установка

```bash
pip install pylite
```

## Как начать

### Интерактивный режим (REPL)

Просто запустите команду:

```bash
pylite
```

Вы увидите приглашение `pylite>` и сможете вводить команды:

```
pylite> print("Привет!")
Привет!
pylite> x = 5 + 3
pylite> print(x)
8
```

### Запуск файлов

Создайте файл с расширением `.pyl` и запустите:

```bash
pylite my_program.pyl
```

## Основы языка

### Переменные

```python
name = "Анна"
age = 12
height = 1.45
is_student = True
```

### Вывод на экран

```python
print("Привет, мир!")
print("Меня зовут", name)
print("Мне", age, "лет")
```

### Математические операции

```python
a = 10
b = 3

print("Сложение:", a + b)      # 13
print("Вычитание:", a - b)     # 7
print("Умножение:", a * b)     # 30
print("Деление:", a / b)       # 3.333...
print("Остаток:", a % b)       # 1
print("Степень:", a ** b)      # 1000
```

### Условия

```python
score = 85

if score >= 90:
    print("Отлично!")
elif score >= 70:
    print("Хорошо!")
elif score >= 50:
    print("Удовлетворительно")
else:
    print("Нужно постараться!")
```

### Циклы

#### Цикл for

```python
# Перебор чисел
for i in range(5):
    print("Число:", i)

# Перебор списка
fruits = ["яблоко", "банан", "апельсин"]
for fruit in fruits:
    print("Фрукт:", fruit)
```

#### Цикл while

```python
count = 0
while count < 5:
    print("Счётчик:", count)
    count = count + 1
```

### Функции

```python
def greet(name):
    print("Привет, " + name + "!")

def add(a, b):
    return a + b

greet("Алиса")
result = add(5, 3)
print("Результат:", result)
```

### Списки

```python
numbers = [1, 2, 3, 4, 5]
colors = ["красный", "зелёный", "синий"]

# Получение элемента
first_number = numbers[0]  # 1

# Длина списка
length = len(numbers)  # 5

# Добавление элемента (через создание нового списка)
new_numbers = numbers + [6]
```

### Словари

```python
student = {"name": "Петя", "age": 13, "grade": 7}

# Получение значения
name = student["name"]
age = student["age"]

print(name, "учится в", student["grade"], "классе")
```

### Классы

```python
class Pet:
    def __init__(self, name, animal_type):
        self.name = name
        self.type = animal_type
    
    def speak(self):
        if self.type == "собака":
            print(self.name + " говорит: Гав!")
        elif self.type == "кот":
            print(self.name + " говорит: Мяу!")

my_dog = Pet("Рекс", "собака")
my_cat = Pet("Мурка", "кот")

my_dog.speak()
my_cat.speak()
```

## Встроенные модули

### Модуль math

```python
import math

print("Пи:", math.pi)
print("Корень из 16:", math.sqrt(16))
print("2 в степени 3:", math.pow(2, 3))
print("Синус 90 градусов:", math.sin(math.pi/2))
```

### Модуль random

```python
import random

# Случайное число от 0 до 1
print("Случайное число:", random.random())

# Случайное целое число
print("Кубик:", random.randint(1, 6))

# Случайный выбор из списка
colors = ["красный", "синий", "зелёный"]
print("Случайный цвет:", random.choice(colors))
```

### Модуль time

```python
import time

print("Сейчас спать на 2 секунды...")
time.sleep(2)
print("Проснулся!")
```

## Встроенные функции

- `print()` - вывод на экран
- `len()` - длина объекта
- `str()` - преобразование в строку
- `int()` - преобразование в целое число
- `float()` - преобразование в дробное число
- `range()` - создание последовательности чисел
- `max()` - максимальное значение
- `min()` - минимальное значение
- `sum()` - сумма элементов списка

## Понимание ошибок

PyLite показывает дружелюбные сообщения об ошибках:

```
📝 Ой! Ты забыл закрыть кавычки в строке 3.
🔍 Ты забыл поставить двоеточие ':' после if в строке 5.
🚀 Переменная 'my_var' не определена. Ты забыл её создать?
```

## Ограничения PyLite

В базовом режиме PyLite имеет следующие ограничения:
- Максимум 500 строк в программе
- Максимум 80 символов в строке
- Глубина вложенности до 3 уровней
- Нет сложных конструкций Python (генераторы, декораторы и т.д.)

Эти ограничения помогают сосредоточиться на основах программирования!

## Примеры программ

Посмотрите папку `examples/` в проекте PyLite для множества примеров программ.

## Получение помощи

Если у вас есть вопросы или предложения:
- Посетите наш Discord: https://getpochi.com/discord
- Сообщите об ошибке: https://github.com/TabbyML/pochi/issues

Удачи в изучении программирования! 🐍✨
