"""Middleware for the Google Trends API."""
