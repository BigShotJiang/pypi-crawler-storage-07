"""API schemas for request and response models."""
