"""Google Trends Core Library.

This core library contains the business logic and data handling for Google Trends data.
"""

__version__ = "0.3.5"
