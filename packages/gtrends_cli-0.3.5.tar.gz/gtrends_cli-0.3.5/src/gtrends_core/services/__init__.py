"""Services for the Google Trends core functionality."""

# from gtrends_core.services.comparison_service import ComparisonService
# from gtrends_core.services.geo_service import GeoService
# from gtrends_core.services.growth_service import GrowthService
# from gtrends_core.services.opportunity_service import OpportunityService
# from gtrends_core.services.related_service import RelatedService
# from gtrends_core.services.suggestion_service import SuggestionService
# from gtrends_core.services.trending_service import TrendingService
