"""Utility functions for the Google Trends Core."""
