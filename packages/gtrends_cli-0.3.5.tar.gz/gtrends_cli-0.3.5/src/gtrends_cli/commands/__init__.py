"""Command modules for Google Trends CLI."""
