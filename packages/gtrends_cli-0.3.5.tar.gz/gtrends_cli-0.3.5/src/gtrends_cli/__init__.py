"""Google Trends CLI Interface.

This module provides the command-line interface for interacting with the Google Trends Core.
"""
