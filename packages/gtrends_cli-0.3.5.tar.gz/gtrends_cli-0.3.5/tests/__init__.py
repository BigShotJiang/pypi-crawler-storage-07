"""Test package for Google Trends CLI."""
