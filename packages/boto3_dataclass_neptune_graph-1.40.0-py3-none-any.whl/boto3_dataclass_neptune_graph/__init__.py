# -*- coding: utf-8 -*-

from .caster import neptune_graph_caster

caster = neptune_graph_caster

__version__ = "1.40.0"