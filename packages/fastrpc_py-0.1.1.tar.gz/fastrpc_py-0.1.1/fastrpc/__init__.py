from .fastrpc import FastRpc, FastRpcClient

__version__ = "0.1.0"
__all__ = [
    "FastRpc",
    "FastRpcClient",
]
