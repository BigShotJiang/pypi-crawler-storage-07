from setuptools import setup, find_packages

setup(
    name="fastrpc-py",
    version="0.1.1",
    packages=find_packages(),
    description="基于fastapi快速构建rpc",
    author="xingshuyin",
    author_email="xing-shuyin@qq.com",
)
