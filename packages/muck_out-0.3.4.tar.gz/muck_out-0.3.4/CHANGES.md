# changes to muck_out


## 0.3.4

- Add hubzilla add example [muck_out#25](https://codeberg.org/bovine/muck_out/issues/25)
- Add following / followers [muck_out#26](https://codeberg.org/bovine/muck_out/issues/26)
- Ensure `ParsedEmbeddedObject` works with transformer result [muck_out#21](https://codeberg.org/bovine/muck_out/issues/21)
- Add support for mastodon like [muck_out#22](https://codeberg.org/bovine/muck_out/issues/22)

## 0.3.3

- Make serialize_by_alias default for normalized objects [muck_out#19](https://codeberg.org/bovine/muck_out/issues/19)

## 0.3.2

- cattle_grid is no longer a main dependency
- Add methods to work within transformers

## 0.3.1

- Add identifiers to actor [muck_out#14](https://codeberg.org/bovine/muck_out/issues/14)
- Add annotations for fetching objects
- Add annotations to receive parsed objects [muck_out#13](https://codeberg.org/bovine/muck_out/issues/13)

## 0.3.0

- Split into stubs and types
- Allow some classes in links [muck_out#11](https://codeberg.org/bovine/muck_out/issues/11)

## 0.2.0

- Add stub objects [muck_out#6](https://codeberg.org/bovine/muck_out/issues/6)
- Remove griffe-fieldz as dependency [muck_out#5](https://codeberg.org/bovine/muck_out/issues/5)

## 0.1.1

- Fix publish credentials

## 0.1.0

- Add release pipeline [muck_out](https://codeberg.org/bovine/muck_out/issues/2)
