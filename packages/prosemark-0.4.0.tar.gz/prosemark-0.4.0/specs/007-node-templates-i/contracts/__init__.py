"""Template system contract specifications."""
