from typing import Optional

import wise_api_client

from .configuration import Context
import uuid


def create_transfer(
  api_client,
  context: Context,
  quote_uuid: str,
  target_account: int,
  source_account: Optional[int] = None,
  reference: Optional[str] = None,
  customer_transaction_id: Optional[str] = None,
  transfer_purpose: Optional[str] = None,
  transfer_purpose_sub: Optional[str] = None,
  transfer_purpose_invoice: Optional[str] = None,
  source_of_funds: Optional[str] = None
):
  """
  Create a transfer.

  Parameters:
          api_client: The Wise API client.
          context (Context): The context.
          quote_uuid (str): The UUID of the quote.
          target_account (int): The ID of the target recipient account.
          source_account (int, optional): The ID of the source account (refund).
          customer_transaction_id (str, optional): Customer transaction ID. If not provided, a UUID will be generated.
          reference (str, optional): Reference for the transfer (required).
          transfer_purpose (str, optional): Purpose of the transfer.
          transfer_purpose_sub (str, optional): Sub-purpose of the transfer.
          transfer_purpose_invoice (str, optional): Invoice number.
          source_of_funds (str, optional): Source of funds.

  Returns:
          The created transfer.
  """
  transfer_api = wise_api_client.TransfersApi(api_client)

  if not customer_transaction_id:
    customer_transaction_id = str(uuid.uuid4())

  details = None
  if reference:
    details = wise_api_client.TransferDetails(
      reference=reference,
      transfer_purpose=transfer_purpose,
      transfer_purpose_sub_transfer_purpose=transfer_purpose_sub,
      transfer_purpose_invoice_number=transfer_purpose_invoice,
      source_of_funds=source_of_funds
    )

  # Create CreateStandardTransferRequest object using Python field names
  create_standard_transfer_request = wise_api_client.CreateStandardTransferRequest(
    target_account=target_account,
    source_account=source_account,
    quote_uuid=quote_uuid,
    customer_transaction_id=customer_transaction_id,
    details=details
  )

  return transfer_api.create_transfer(create_standard_transfer_request)


def create_quote(
  api_client,
  context: Context,
  source_currency: str,
  target_currency: str,
  source_amount: Optional[float] = None,
  target_amount: Optional[float] = None,
  target_account: Optional[int] = None,
  pay_out: Optional[str] = None,
  preferred_pay_in: Optional[str] = None,
  profile_id: Optional[str] = None,
):
  """
  Create a quote with enhanced parameter support.

  Parameters:
      api_client: The Wise API client.
      context (Context): The context.
      source_currency (str): ISO 4217 three-letter currency code for source.
      target_currency (str): ISO 4217 three-letter currency code for target.
      source_amount (float): The amount in the source currency. Must be greater than 0.
      target_amount (float): The amount in the target currency. Must be greater than 0.
      target_account (int, optional): A unique recipient account identifier.
      pay_out (str, optional): Preferred payout method. Default is BANK_TRANSFER.
      preferred_pay_in (str, optional): Preferred payin method.
      profile_id (str, optional): The profile ID. If not provided, will be taken from context.

  Returns:
      The created quote.
  """
  quotes_api = wise_api_client.QuotesApi(api_client)

  # Get profile ID from context if not provided
  if not profile_id:
    profile_id = context.get("profile_id")
    if not profile_id:
      raise ValueError("Profile ID must be provided either as a parameter or in context.")

  # Either source_amount or target_amount should be provided, but not both
  if source_amount is not None and target_amount is not None:
    raise ValueError("Please provide either source_amount or target_amount, not both.")
  elif source_amount is None and target_amount is None:
    raise ValueError("Either source_amount or target_amount must be provided.")

  # Build quote request data
  quote_request_data = {
    "source_currency": source_currency,
    "target_currency": target_currency,
  }

  # Add optional fields
  if target_account is not None:
    quote_request_data["target_account"] = target_account

  if pay_out is not None:
    quote_request_data["pay_out"] = pay_out

  if preferred_pay_in is not None:
    quote_request_data["preferred_pay_in"] = preferred_pay_in

  if source_amount is not None:
    quote_request_data["source_amount"] = source_amount
    r = wise_api_client.CreateAuthenticatedSourceAmountQuoteRequest(**quote_request_data)
  else:
    quote_request_data["target_amount"] = target_amount
    r = wise_api_client.CreateAuthenticatedTargetAmountQuoteRequest(**quote_request_data)

  create_authenticated_quote_request = wise_api_client.CreateAuthenticatedQuoteRequest(r)
  return quotes_api.create_authenticated_quote(int(profile_id), create_authenticated_quote_request)

def create_recipient_account(
  api_client,
  context: Context,
  account_holder_name: str,
  currency: str,
  type: str,
  profile_id: Optional[int] = None,
  owned_by_customer: Optional[bool] = None,
  **kwargs
):
  """
  Create a recipient account.

  Parameters:
      api_client: The Wise API client.
      context (Context): The context.
      account_holder_name (str): The name of the account holder.
      currency (str): The currency code (3-letter ISO currency code).
      type (str): The type of recipient account.
      profile_id (int, optional): The profile ID. If not provided, will be taken from context.
      owned_by_customer (bool, optional): Whether this account is owned by the sending user.
      **kwargs: Dynamic fields based on account requirements (e.g., details, address, etc.).

  Returns:
      Recipient: The created recipient account.
  """
  recipients_api = wise_api_client.RecipientsApi(api_client)

  # Get profile ID from context if not provided
  if profile_id is None:
    profile_id = context.get("profile_id")
    if not profile_id:
      raise ValueError("Profile ID must be provided either as a parameter or in context.")

  # Create the request dictionary with fixed fields
  create_recipient_request_dict = {
    "accountHolderName": account_holder_name,
    "currency": currency,
    "type": type,
    "profile": int(profile_id)
  }

  # Add optional fixed field
  if owned_by_customer is not None:
    create_recipient_request_dict["ownedByCustomer"] = owned_by_customer

  # Add all dynamic fields
  create_recipient_request_dict.update(kwargs)

  # Create the request object from dictionary
  create_recipient_request = wise_api_client.CreateRecipientRequest.from_dict(create_recipient_request_dict)

  # Make the API call
  return recipients_api.create_recipient_account(create_recipient_request)


def list_recipient_accounts(
  api_client,
  context: Context,
  profile_id: Optional[str] = None,
  currency: Optional[str] = None,
  size: Optional[int] = None,
  seek_position: Optional[int] = None,
):
  """
  List recipient accounts.

  Parameters:
      api_client: The Wise API client.
      context (Context): The context.
      profile_id (str, optional): The profile ID. If not provided, will be taken from context.
      currency (str, optional): Filter by currency.
      size (int, optional): Number of items per page.
      seek_position (int, optional): Position to start seeking from.

  Returns:
      PaginatedRecipients: A paginated list of recipient accounts.
  """
  recipients_api = wise_api_client.RecipientsApi(api_client)

  # Get profile ID from context if not provided
  if not profile_id:
    profile_id = context.get("profile_id")
    if not profile_id:
      raise ValueError("Profile ID must be provided either as a parameter or in context.")

  # Make the API call
  return recipients_api.list_recipient_accounts(
    profile_id=int(profile_id),
    currency=currency,
    size=size,
    seek_position=seek_position
  )
