CREATE_TRANSFER_PROMPT = """
This tool will create a transfer between accounts in Wise.

It takes the following arguments:
- target_account (int): The ID of the target recipient account.
- quote_uuid (str): The UUID of the quote.
- reference (str, optional): Reference for the transfer (optional, max 100 chars).
- source_account (int, optional): The ID of the source account (for refunds).
- customer_transaction_id (str, optional): A unique ID for this transaction. If not provided, a UUID will be generated.
- transfer_purpose (str, optional): Purpose of the transfer.
- transfer_purpose_sub (str, optional): Sub-purpose of the transfer.
- transfer_purpose_invoice (str, optional): Invoice number related to the transfer.
- source_of_funds (str, optional): Source of funds for the transfer.

Returns:
    The created transfer object from Wise.
"""

CREATE_QUOTE_PROMPT = """
This tool will create a quote for currency conversion in Wise.

It takes the following arguments:
- source_currency (str): The source currency code (3-letter ISO currency code).
- target_currency (str): The target currency code (3-letter ISO currency code).
- source_amount (float, optional): The amount in the source currency to be converted.
- target_amount (float, optional): The amount in the target currency to receive.
  Note: Provide either source_amount or target_amount, not both.
- target_account (int, optional): A unique recipient account identifier.
- profile_id (str, optional): The profile ID. If not provided, will be taken from context.
- pay_out (str, optional): The pay out method.
- preferred_pay_in (str, optional): The preferred pay in method.

Returns:
    The created quote object from Wise.
"""

LIST_RECIPIENT_ACCOUNTS_PROMPT = """
This tool will list recipient accounts registered in Wise.

It takes the following arguments:
- profile_id (str, optional): The profile ID to list recipients for. If not provided, will be taken from context.
- currency (str, optional): Filter recipients by currency (3-letter ISO currency code).
- size (int, optional): Number of items per page for pagination.
- seek_position (int, optional): Position to start seeking from for pagination.

Returns:
    A paginated list of recipient accounts from Wise containing information about each recipient.
"""

CREATE_RECIPIENT_ACCOUNT_PROMPT = """
This tool will create a recipient account in Wise.

It takes the following arguments:
- account_holder_name (str): The recipient's full name.
- currency (str): 3 character currency code for the recipient's account.
- type (str): The type of recipient account, determined from the account requirements.
- profile_id (int, optional): The profile ID that the recipient will be created under. If not provided, will be taken from context.
- owned_by_customer (bool, optional): Whether this account is owned by the sending user.
- **kwargs: Dynamic fields based on account requirements. This can include:
  - details (dict): Account-specific details like legalType, email, IBAN, sort code, account number, etc.
  - address (dict): Address information with country, city, postCode, firstLine, etc.
  - Any other fields required by the specific currency route as returned by /v1/quotes/{quoteId}/account-requirements.

Returns:
    The created recipient account object from Wise.
"""