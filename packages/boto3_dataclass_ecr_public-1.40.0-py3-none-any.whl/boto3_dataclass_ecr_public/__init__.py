# -*- coding: utf-8 -*-

from .caster import ecr_public_caster

caster = ecr_public_caster

__version__ = "1.40.0"