from tecton_materialization.ray.materialization import main


main()
