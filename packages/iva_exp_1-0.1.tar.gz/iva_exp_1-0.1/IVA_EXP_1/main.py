def hello():
    print("""import tensorflow as tf
import numpy as np
# Load and preprocess MNIST
(x_train, y_train), (x_test, y_test) = tf.keras.datasets.mnist.load_data()
x_train = x_train[..., tf.newaxis] / 255.0
x_test = x_test[..., tf.newaxis] / 255.0
y_train = tf.one_hot(y_train, 10)
y_test = tf.one_hot(y_test, 10)
# Load and preprocess MNIST
(x_train, y_train), (x_test, y_test) = tf.keras.datasets.mnist.load_data()
x_train = x_train[..., tf.newaxis] / 255.0
x_test = x_test[..., tf.newaxis] / 255.0
y_train = tf.one_hot(y_train, 10)
y_test = tf.one_hot(y_test, 10)
# Load and preprocess MNIST
(x_train, y_train), (x_test, y_test) = tf.keras.datasets.mnist.load_data()
x_train = x_train[..., tf.newaxis] / 255.0
x_test = x_test[..., tf.newaxis] / 255.0
y_train = tf.one_hot(y_train, 10)
y_test = tf.one_hot(y_test, 10)

# CNN forward function
def model(x):
    x = tf.nn.relu(tf.nn.conv2d(x, W1, 1, 'SAME') + B1)
    x = tf.nn.max_pool2d(x, 2, 2, 'SAME')
    x = tf.nn.relu(tf.nn.conv2d(x, W2, 1, 'SAME') + B2)
    x = tf.nn.max_pool2d(x, 2, 2, 'SAME')
    x = tf.nn.relu(tf.nn.conv2d(x, W3, 1, 'SAME') + B3)
    x = tf.reshape(x, [-1, 7*7*64])
    x = tf.nn.relu(tf.matmul(x, W_fc1) + B_fc1)
    return tf.matmul(x, W_fc2) + B_fc2

# Optimizer and training loop
optimizer = tf.optimizers.Adam()
batch_size = 64

for epoch in range(5):
    for i in range(0, len(x_train), batch_size):
        x_batch = x_train[i:i+batch_size]
        y_batch = y_train[i:i+batch_size]
        with tf.GradientTape() as tape:
            logits = model(x_batch)
            loss = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(logits=logits, labels=y_batch))
        grads = tape.gradient(loss, [W1,W2,W3,W_fc1,W_fc2,B1,B2,B3,B_fc1,B_fc2])
        optimizer.apply_gradients(zip(grads, [W1,W2,W3,W_fc1,W_fc2,B1,B2,B3,B_fc1,B_fc2]))
    print(f"Epoch {epoch+1} done")

# Evaluate
pred = tf.argmax(model(x_test), axis=1)
true = tf.argmax(y_test, axis=1)
acc = tf.reduce_mean(tf.cast(tf.equal(pred, true), tf.float32))
print(f"Test Accuracy: {acc.numpy():.4f}")
from PIL import Image
import numpy as np
import tensorflow as tf
from tkinter import filedialog, Tk

def upload_and_predict():
    root = Tk()
    root.withdraw()
    path = filedialog.askopenfilename()
    if not path: return "No file selected"
    img = Image.open(path).convert('L').resize((28, 28))
    x = np.expand_dims(255 - np.array(img), axis=(0, -1)) / 255.0
    pred = tf.argmax(model(x), axis=1).numpy()[0]
    print("Predicted Digit:", pred)
    return pred
# user to enter the index of the image to predict
image_index = int(input("Enter the index of the image to predict (0-9999): "))
# Get the image from the test set
img = x_test[image_index]
# Reshape the image to match the input_shape of the model
img_reshaped = img.reshape(1, 28, 28, 1)
# Predict the class
prediction = model(img_reshaped)
# Get the index of the highest probability
predicted_class = np.argmax(prediction)
import matplotlib.pyplot as plt
# Display the image and predicted class
plt.imshow(img.reshape(28, 28), cmap='gray')
plt.title(f'Predicted class: {predicted_class}')
plt.axis('off')
plt.show()""")