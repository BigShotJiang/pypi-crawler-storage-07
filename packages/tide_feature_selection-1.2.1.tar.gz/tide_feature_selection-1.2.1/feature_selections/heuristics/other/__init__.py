from .rand import Random
