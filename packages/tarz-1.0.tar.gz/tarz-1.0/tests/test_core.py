import TArz

btc_price = TArz.crypto('bitcoin')
print(f"Bitcoin Price: {btc_price}")

eth_price = TArz.crypto('ethereum')
print(f"Ethereum Price: {eth_price}")
