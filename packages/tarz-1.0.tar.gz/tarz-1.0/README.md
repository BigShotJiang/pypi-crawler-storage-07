# TArz - Cryptocurrency and Gold Price Tracker

**TArz** is a Python package designed for tracking real-time cryptocurrency prices and gold prices from trusted sources. Whether you are a crypto enthusiast or just need the latest price of gold, TArz offers an easy-to-use interface for fetching live prices. With TArz, you can access a wide range of cryptocurrencies and gold prices directly within your Python applications.

---

## Key Features

- **Real-Time Gold Price**: Fetch the current price of gold from reliable financial websites.
- **Track Cryptocurrency Prices**: Get the latest prices for popular cryptocurrencies such as **Bitcoin (BTC)**, **Ethereum (ETH)**, **Ripple (XRP)**, and many others.
- **Asynchronous Support**: Optimized for asynchronous programming to ensure fast responses.
- **Lightweight**: Minimal dependencies, simple and efficient design.
- **Documentation**: Detailed documentation to guide you through installation and usage.
- **Extensible**: Easily extendable to add more features or integrate with other APIs.

---

## Installation

You can install **TArz** directly from the Python Package Index (PyPI) using pip:

## Dependencies

* ** requests ** for HTTP requests
* ** beautifulsoup4 ** for parsing HTML data

You can install the dependencies with:
```bash 
pip install requests beautifulsoup4
pip install TArz

