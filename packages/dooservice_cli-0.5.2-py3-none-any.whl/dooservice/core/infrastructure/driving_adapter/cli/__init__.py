"""CLI driving adapters."""
