"""Patterns used in the postcode validation."""

import re

GIR_PATTERN = re.compile(r"^(?P<outward>GIR)\s?(?P<inward>0AA)?$", re.IGNORECASE)

BFPO_PATTERN = re.compile(r"^(?P<outward>BFPO)\s?(?P<inward>\d{1,4})?$", re.IGNORECASE)

GIB_PATTERN = re.compile(r"^(?P<outward>GX11)\s?(?P<inward>1AA)?$", re.IGNORECASE)

OVERSEAS_PATTERN = re.compile(
    r"^(?P<outward>ASCN|BBND|BIQQ|FIQQ|PCRN|SIQQ|STHL|TDCU|TKCA)\s?(?P<inward>1ZZ)?$",
    re.IGNORECASE,
)

SANTA_OLD_PATTERN = re.compile(r"^(?P<outward>SAN)\s?(?P<inward>TA1)?$", re.IGNORECASE)
SANTA_NEW_PATTERN = re.compile(r"^(?P<outward>XM4)\s?(?P<inward>5HQ)?$", re.IGNORECASE)

ZZ99_PATTERN = re.compile(r"^(?P<outward>ZZ99)\s?(?P<inward>3WZ)?$", re.IGNORECASE)

SPECIAL_POSTCODE_PATTERNS = (
    GIR_PATTERN,
    BFPO_PATTERN,
    GIB_PATTERN,
    OVERSEAS_PATTERN,
    SANTA_OLD_PATTERN,
    SANTA_NEW_PATTERN,
    ZZ99_PATTERN,
)

STANDARD_POSTCODE_PATTERN = re.compile(
    r"^(?!(?:GX11|XM4|ZZ99))(?:(?P<outward>(?P<area>[A-PR-UWYZ][A-HK-Y]?)(?P<district>(?:\d{1,2}|\d[A-HJ-NP-Z])))"
    r"(?:\s?(?P<inward>(?P<sector>\d)(?P<unit>[ABD-HJLNP-UW-Z]{2}))?))$",
    re.IGNORECASE,
)
