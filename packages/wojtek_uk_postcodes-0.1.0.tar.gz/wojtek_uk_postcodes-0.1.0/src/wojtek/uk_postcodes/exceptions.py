"""Exceptions raised by the package."""


class InvalidPostcodeError(Exception):
    """Raised when a postcode fails validation."""
