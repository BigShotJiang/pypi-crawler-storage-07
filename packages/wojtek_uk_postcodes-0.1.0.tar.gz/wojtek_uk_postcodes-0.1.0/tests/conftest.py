from collections.abc import Generator
from pathlib import Path
from typing import Any

import pytest

from wojtek.uk_postcodes import UKPostcode

VALID_POSTCODES_DATA_PATH = Path(__file__).parent / "data" / "valid_postcodes"
INVALID_POSTCODES_DATA_PATH = Path(__file__).parent / "data" / "invalid_postcodes"


def valid_postcodes() -> Generator[str, Any, None]:
    with VALID_POSTCODES_DATA_PATH.open() as file:
        yield from (line.strip() for line in file)


def invalid_postcodes() -> Generator[str, Any, None]:
    with INVALID_POSTCODES_DATA_PATH.open() as file:
        yield from (line.strip() for line in file)


@pytest.fixture(scope="session")
def special_postcodes() -> set[str]:
    return {
        "GIR 0AA",
        "BFPO 801",
        "GX11 1AA",
        "SAN TA1",
        "XM4 5HQ",
        "ZZ99 3WZ",
        "ASCN 1ZZ",
        "BBND 1ZZ",
        "BIQQ 1ZZ",
        "FIQQ 1ZZ",
        "PCRN 1ZZ",
        "SIQQ 1ZZ",
        "STHL 1ZZ",
        "TDCU 1ZZ",
        "TKCA 1ZZ",
    }


@pytest.fixture
def uk_postcode() -> UKPostcode:
    """Provide a populated postcode instance."""
    return UKPostcode(
        raw="SW1A 1AA",
        outward="SW1A",
        inward="1AA",
        area="SW",
        district="1A",
        sector="1",
        unit="AA",
        is_special=False,
    )
