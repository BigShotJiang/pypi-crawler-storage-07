"""Tests for postcode models."""

import pytest

from wojtek.uk_postcodes.models import FormatStyle, UKPostcode


def test_format_standard(uk_postcode: UKPostcode) -> None:
    """Ensure standard formatting keeps the space."""
    assert uk_postcode.format(FormatStyle.STANDARD) == "SW1A 1AA"


def test_format_no_spaces(uk_postcode: UKPostcode) -> None:
    """Ensure no-spaces formatting compacts the code."""
    assert uk_postcode.format(FormatStyle.NO_SPACES) == "SW1A1AA"


def test_to_dict_round_trip(uk_postcode: UKPostcode) -> None:
    """Ensure to_dict exposes all fields."""
    assert uk_postcode.to_dict() == {
        "raw": "SW1A 1AA",
        "outward": "SW1A",
        "inward": "1AA",
        "area": "SW",
        "district": "1A",
        "sector": "1",
        "unit": "AA",
        "is_special": False,
    }


def test_raises_on_invalid_format_style(uk_postcode: UKPostcode) -> None:
    """Ensure passing an invalid format style raises an error."""
    with pytest.raises(ValueError, match="Invalid format style"):
        uk_postcode.format(style="invalid")
