#!/usr/bin/env bash

set -o errexit

uv sync --active

uv run --active mypy src --exclude "tests" --namespace-packages --explicit-package-bases
