from timbal import Tool
from timbal.core.llm_router import _llm_router
from timbal.types.message import Message

from dotenv import load_dotenv

load_dotenv()


def get_datetime():
    return "2025-10-02 15:12:11"

tool = Tool(
    name="get_datetime",
    description="Get the current date and time",
    handler=get_datetime,
)


async def main():
    messages = [
        Message.validate({"role": "user", "content": "Hello"}),
        Message.validate({'role': 'assistant', 'content': [{'type': 'tool_use', 'id': 'call_AyakmADBZGl5B5A9qy3FUm3r', 'name': 'get_datetime', 'input': {}}]}),
        Message.validate({"role": "tool", "content": [{"type": "tool_result", "id": "call_AyakmADBZGl5B5A9qy3FUm3r", "content": "Tool was cancelled"}]}),
        Message.validate({"role": "user", "content": "Please try again"}),
    ]
    print(messages)
    async for event in _llm_router(
        model="openai/gpt-4o-mini",
        messages=messages,
        tools=[tool],
    ):
        try:
            print(event)
        except Exception as e:
            print(e)


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
