from artistools.nonthermal import solvespencerfanocmd


def main() -> None:
    solvespencerfanocmd.main()


if __name__ == "__main__":
    main()
