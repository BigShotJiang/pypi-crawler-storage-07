Lsun_to_erg_per_s = 3.826e33
megaparsec_to_cm = 3.0856e24
