# -*- coding: utf-8 -*-

from .caster import payment_cryptography_caster

caster = payment_cryptography_caster

__version__ = "1.40.0"