"""
Main package initialization.
"""
