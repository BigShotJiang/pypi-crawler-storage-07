export const allowedTypes = ['ndarray', 'DataFrame', 'list', 'Series'];
