========================
Products.MeetingCommunes
========================

``Products.MeetingCommunes`` is a custom profile for ``Products.PloneMeeting``.

.. image:: https://coveralls.io/repos/github/IMIO/Products.MeetingCommunes/badge.svg?branch=master
    :target: https://coveralls.io/github/IMIO/Products.MeetingCommunes?branch=master

.. image:: http://img.shields.io/pypi/v/Products.MeetingCommunes.svg
   :alt: PyPI badge
   :target: https://pypi.org/project/Products.MeetingCommunes
