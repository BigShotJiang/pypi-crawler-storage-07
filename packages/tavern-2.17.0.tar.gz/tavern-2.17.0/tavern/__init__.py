"""Stop pytest warning about module already imported: PYTEST_DONT_REWRITE"""

__version__ = "2.17.0"
