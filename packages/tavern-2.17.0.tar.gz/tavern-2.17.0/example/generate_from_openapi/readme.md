Example script to autogenerate the travern yaml test file from a given openapi.json file
