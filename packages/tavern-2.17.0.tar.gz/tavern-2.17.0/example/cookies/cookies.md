# Cookie example

This is very similar to the 'advanced' example but uses cookies (using Flask's
`session` object) to authenticate a user instead.
