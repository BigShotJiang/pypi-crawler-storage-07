"""
Submodule for functionality that ensures backwards compatibility.
"""
