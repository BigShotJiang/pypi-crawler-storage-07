"""
Configuration settings for the XAC package.
"""

# Maximum size for request body logging (in characters)
MAX_REQUEST_BODY_SIZE = 10000
