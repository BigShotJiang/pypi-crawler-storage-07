# MCP Guardian - Development Tools

This directory contains optional tools for development and testing.

## Installation

```bash
# Install from PyPI (recommended)
pip install mcp-guardian-auth

# Or install from source
pip install -r requirements.txt
```

## Files

- **`test_tokens.py`** - JWT token generation utility for testing
- **`main.py`** - Simple demo FastAPI application

## Usage

### Generate Test Tokens
```bash
python tools/test_tokens.py
```

### Run Simple Demo
```bash
# First, copy and configure your config
cp config.example.yaml config.yaml
# Edit config.yaml with your settings

# Then run the demo
python tools/main.py
```

## Note

These are optional development tools. The main library is in the `mcp_guardian/` directory.
