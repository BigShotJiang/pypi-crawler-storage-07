"""
MCP Guardian - A lightweight, plug-and-play security middleware for FastAPI.

This package provides JWT authentication, scope-based authorization, and rate limiting
for FastAPI applications, specifically designed for MCP (Model Context Protocol) servers.
"""

from .guardian import Guardian

__version__ = "1.0.0"
__author__ = "Zheng H. Chen"
__email__ = "zheng@example.com"

__all__ = ["Guardian"]
