"""
Setup configuration for MCP Guardian package.
"""

from setuptools import setup, find_packages
import os

# Read the README file for long description
def read_readme():
    with open("README.md", "r", encoding="utf-8") as fh:
        return fh.read()

# Read requirements
def read_requirements():
    with open("requirements.txt", "r", encoding="utf-8") as fh:
        return [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="mcp-guardian-auth",
    version="1.1.0",
    author="Zheng H. Chen",
    author_email="zheng@example.com",
    description="A lightweight, plug-and-play security middleware for FastAPI applications with comprehensive audit trail logging, specifically designed for MCP (Model Context Protocol) servers.",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    url="https://github.com/zhengchen/mcp-guardian",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Framework :: FastAPI",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Internet :: WWW/HTTP :: HTTP Servers",
        "Topic :: Security",
        "Topic :: System :: Systems Administration :: Authentication/Directory",
    ],
    python_requires=">=3.10",
    install_requires=read_requirements(),
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "black>=23.0.0",
            "flake8>=6.0.0",
            "mypy>=1.0.0",
        ],
    },
    keywords="fastapi, jwt, authentication, authorization, rate-limiting, mcp, ai-agents, security, middleware",
    project_urls={
        "Bug Reports": "https://github.com/zhengchen/mcp-guardian/issues",
        "Source": "https://github.com/zhengchen/mcp-guardian",
        "Documentation": "https://github.com/zhengchen/mcp-guardian#readme",
    },
)
