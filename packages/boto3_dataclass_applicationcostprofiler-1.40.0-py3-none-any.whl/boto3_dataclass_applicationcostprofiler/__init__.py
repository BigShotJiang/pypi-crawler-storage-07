# -*- coding: utf-8 -*-

from .caster import applicationcostprofiler_caster

caster = applicationcostprofiler_caster

__version__ = "1.40.0"