# flake8: noqa

# import apis into api package
from wise_api_client.api.activities_api import ActivitiesApi
from wise_api_client.api.profiles_api import ProfilesApi
from wise_api_client.api.quotes_api import QuotesApi
from wise_api_client.api.recipients_api import RecipientsApi
from wise_api_client.api.transfers_api import TransfersApi

