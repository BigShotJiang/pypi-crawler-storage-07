"""
Viblr SDK - Context as a Service

Enhance your AI prompts with rich context from connected sources.
"""

from .client import ViblrClient, ViblrResponse
from .exceptions import ViblrError, ViblrAPIError, ViblrAuthError, ViblrTimeoutError, ViblrQuotaError

__version__ = "1.0.0"
__author__ = "Viblr Team"
__email__ = "support@viblr.ai"

__all__ = [
    "ViblrClient",
    "ViblrResponse", 
    "ViblrError",
    "ViblrAPIError",
    "ViblrAuthError",
    "ViblrTimeoutError",
    "ViblrQuotaError"
]