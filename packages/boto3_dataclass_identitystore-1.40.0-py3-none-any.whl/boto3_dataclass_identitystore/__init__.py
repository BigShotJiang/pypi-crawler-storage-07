# -*- coding: utf-8 -*-

from .caster import identitystore_caster

caster = identitystore_caster

__version__ = "1.40.0"