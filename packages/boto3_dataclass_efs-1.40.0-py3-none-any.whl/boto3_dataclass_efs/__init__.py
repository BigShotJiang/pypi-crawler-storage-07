# -*- coding: utf-8 -*-

from .caster import efs_caster

caster = efs_caster

__version__ = "1.40.0"