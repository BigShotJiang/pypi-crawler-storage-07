"""Analysis and explanation functions"""
