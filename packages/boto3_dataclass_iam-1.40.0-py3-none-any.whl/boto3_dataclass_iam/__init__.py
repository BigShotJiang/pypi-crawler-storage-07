# -*- coding: utf-8 -*-

from .caster import iam_caster

caster = iam_caster

__version__ = "1.40.0"