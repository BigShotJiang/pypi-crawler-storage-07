"""Core algorithms."""
