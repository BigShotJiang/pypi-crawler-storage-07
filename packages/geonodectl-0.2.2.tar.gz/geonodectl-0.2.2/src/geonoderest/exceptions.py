class GeoNodeRestException(Exception):
    """
    GeoNodeRestException

    """

    pass
