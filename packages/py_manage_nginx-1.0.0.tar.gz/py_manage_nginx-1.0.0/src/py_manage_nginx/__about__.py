# SPDX-FileCopyrightText: 2025-present Trương Hải Đăng <haidanghth910@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "1.0.0"
