# `ryo3-sqlformat`

python + `sqlformat` crate.

`sqlformat`:

- [crates.io](https://crates.io/crates/sqlformat)
- [docs.rs](https://docs.rs/sqlformat)
