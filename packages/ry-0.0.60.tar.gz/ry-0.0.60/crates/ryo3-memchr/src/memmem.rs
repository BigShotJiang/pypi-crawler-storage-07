//! FUTURE IMPL OF `memchr::memmem`
