# `ryo3-same-file`

ryo3-wrapper for `same-file` crate

[//]: # "<GENERATED>"

## Ref:

- docs.rs: [https://docs.rs/same-file](https://docs.rs/same-file)
- crates:
  [https://crates.io/crates/same-file](https://crates.io/crates/same-file)

[//]: # "</GENERATED>"
