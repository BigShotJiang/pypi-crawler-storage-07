# `ryo3-core`

shared, and common and utiles, oh my!
