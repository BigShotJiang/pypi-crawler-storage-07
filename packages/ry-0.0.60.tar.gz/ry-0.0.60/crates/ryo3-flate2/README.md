# `ryo3-flate2`

Wrapper around the `flate2` crate for Python.

REF:

- [crates.io](https://crates.io/crates/flate2)
- [docs.rs](https://docs.rs/flate2)
