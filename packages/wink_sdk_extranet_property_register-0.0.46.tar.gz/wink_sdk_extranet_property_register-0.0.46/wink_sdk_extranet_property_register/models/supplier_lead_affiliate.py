# coding: utf-8

"""
    Wink API

     # Introduction  Welcome to the Wink API - A programmer-friendly way to manage, sell and book travel inventory on the Wink platform. The API gives you all the tools you need to ready your properties and inventory for sale across 1000s of our native sales channels.  Integrators, affiliates, travel agents and content creators have the ability search for your travel inventory and promote / sell it in a wide variety of ways.   # Integrations  We have already integrated with the most well-known channel managers so you don't have to. To see our current integrations, please go to https://extranet.wink.travel and scroll to Connectivity section. Once your properties are set up, you can finish the setup by mapping your property to Wink using your channel manager partner portal. If your properties don't have a channel manager, you can easily manage rates and availability with this API.   # Intended Audience  Programmers are [most likely] a requirement to start integrating with Wink. Companies and organizations that would most benefit from integrating with us are new and existing travel companies that have relationships with suppliers and that need an advanced system from which to manage their travel inventory and get that same inventory out to as many eyeballs as possible at the lowest price possible.  - Hotel chains  - Hotel brands  - Travel tech companies  - Destination sites  - Integrators  - Aggregators  - Destination management companies  - Travel agencies  - OTAs   ## APIs  Not every integrator needs every API. For that reason, we have separated APIs into context.  ### Test API   - [Ping](/ping): The Ping API is a quick test endpoint to verify that your credentials work Wink.  ### Common APIs  - [Notifications](/notifications): The Notifications API is a way for us to stay in touch with your user, property or affiliate account. - [User Settings](/user-settings): The User Settings API exposes endpoints to allow 3rd party integrators to communicate with Wink.  ### Consume APIs Consume endpoints are for developers who want to find existing travel inventory and either book it or use it to advertise through one of their Wink affiliate accounts.   - [Configuration](/customization-client): A single endpoint to retrieve whitelabel + customization information for the booking customization.  - [Lookup](/lookup): All APIs related to locating inventory by region, locale and property flags.  - [Inventory](/inventory): All APIs related to retrieve known travel inventory as it was found using the Lookup API..  - [Booking](/booking): All APIs related to creating bookings on the platform.  - [Travel Agent](/travel-agent): The Travel Agent API exposes endpoints to manage agent-facilitated bookings.   ### Produce APIs  Produce endpoints are for developers who want to create and manage travel inventory.   #### Property  - [Property registration](/extranet/property/register): As a producer, this is, oftentimes, where you start your journey. These endpoints let you create properties on Wink.  - [Property](/extranet/property): This collection of property endpoints are mostly management endpoints that let you display, change status and similar for your existing properties.  - [Facilities](/extranet/facilities): This collection of endpoints let you manage facilities; such as room types.  - [Experiences](/extranet/experiences): This collection of endpoints let you manage experiences, such as activities.  - [Monetize](/extranet/monetize): The Monetize API exposes endpoints for managing cancellation polies, rate plans, promotions and more on Wink.  - [Distribution](/extranet/distribution): The Distribution API exposes endpoints for sales channels, connecting with affiliates, managing rates and inventory calendars and more on Wink.  - [Property Booking](/extranet/booking): The Property Booking API exposes endpoints for managing bookings and reviews at the property-level.   #### Affiliate  - [Affiliate](/affiliate): This collection of affiliate endpoints are mostly management endpoints that let you display, change status and similar for your existing accounts.  - [Browse](/affiliate/browse): The Browse API exposes endpoints for affiliates to find suppliers and inventory to sell.  - [Inventory](/affiliate/inventory): The Inventory API exposes endpoints for affiliates to manage the inventory they want to sell and how they want to sell it.  - [Sales Channel](/affiliate/sales-channel): The Sales Channel API exposes endpoints for affiliates to manage existing sales channels as well as find new ones.  - [WinkLinks](/affiliate/winklinks): The WinkLinks API exposes endpoints for affiliates to manage their WinkLinks page.   #### Rate provider  - [Channel manager](/channel-manager): The Channel Manager API enables external channel manager partners to map, exchange rate / availability information with us as well as be informed of bookings that occur on the Wink platform for one of their properties.   ### Taxonomy APIs  Taxonomy endpoints are for developers who want to consume and produce travel inventory and need taxonomies of standard and non-standard codes for inventory types, classes, statuses etc.   - [Reference](/reference): All APIs related to retrieving platform-supported taxonomies.   ### Insight APIs  Insight endpoints do exactly what the name implies - They offer platform-level insight into the activities of producers and consumers.   - [Analytics](/analytics): All APIs related to tracking metrics across a wide variety of data source segments including, more entertaining, leaderboard metrics.   ### Payment APIs  Payment endpoints are for developers who want to purchase travel inventory. This can be done via the API as a registered Travel Agent or using our API in conjunction with our PCI compliant payment widget for all other entities.   - [TripPay](/payment): All APIs related to TripPay account management, booking, mapping and integration features.   ## SDKs  We are actively working on supporting the most used languages out there. If you don't see your language here, reach out to us with a request to officially add your language. In the meantime, if you want to roll your own SDK, you can do so by downloading the OpenAPI spec and using one of the many available OpenAPI generators available: [https://openapi-generator.tech/docs/generators](https://openapi-generator.tech/docs/generators).   - Java SDK [https://github.com/wink-travel/wink-sdk-java](https://github.com/wink-travel/wink-sdk-java)   ## Usage  These features are made available to you via a [REST API](https://en.wikipedia.org/wiki/Representational_state_transfer). This API is language agnostic.   ## Versioning  We chose to version our endpoints in a way that we hope affects your integration minimally. You request the version of our API you wish to work with via the `Wink-Version` header. When it's time for you to upgrade, you only have to change the version number to get access to our updated endpoints.   ## Release history  - Follow updates on Github: https://github.com/wink-travel/wink-sdk-java/blob/master/CHANGELOG.md    # Extranet Property Registration API This part of the documentation concerns itself about adding new properties to Wink. There are two endpoints for you to onboard a property:  1. Manage leads 2. Manually: Use this endpoint if you already have all the property data. Use case: You want to migrate your existing properties to Wink. 3. Intelligently: With the assistance of Google Business Pages, you can select an existing property on Google, ingest it with the lead endpoint and let us create a Wink property for you. Note: This isn't always straightforward in places with non-standard addresses.  Browse the endpoints in the left navigation bar to get started.  

    The version of the OpenAPI document: 30.22.2
    Contact: bjorn@wink.travel
    Generated by OpenAPI Generator (https://openapi-generator.tech)

    Do not edit the class manually.
"""  # noqa: E501


from __future__ import annotations
import pprint
import re  # noqa: F401
import json

from datetime import datetime
from pydantic import BaseModel, ConfigDict, Field, StrictFloat, StrictInt, StrictStr, field_validator
from typing import Any, ClassVar, Dict, List, Optional, Union
from typing_extensions import Annotated
from wink_sdk_extranet_property_register.models.address_affiliate import AddressAffiliate
from wink_sdk_extranet_property_register.models.geo_json_point_affiliate import GeoJsonPointAffiliate
from wink_sdk_extranet_property_register.models.key_value_pair_affiliate import KeyValuePairAffiliate
from wink_sdk_extranet_property_register.models.simple_address_affiliate import SimpleAddressAffiliate
from wink_sdk_extranet_property_register.models.simple_multimedia_affiliate import SimpleMultimediaAffiliate
from typing import Optional, Set
from typing_extensions import Self

class SupplierLeadAffiliate(BaseModel):
    """
    SupplierLeadAffiliate
    """ # noqa: E501
    id: Optional[StrictStr] = Field(default=None, description="Document UUID")
    created_date: Optional[datetime] = Field(default=None, description="Datetime this record was first created", alias="createdDate")
    last_update: Optional[datetime] = Field(default=None, description="Datetime this record was last updated", alias="lastUpdate")
    version: Optional[StrictInt] = Field(default=None, description="Version property that shows how many times this document has been persisted. Document will not persist if the version property is less than current version property in the system. Result in an optimistic locking exception.")
    user: KeyValuePairAffiliate = Field(description="The user who initiated the creation of this object. Contains userId as value and username as label.")
    owner: Optional[KeyValuePairAffiliate] = Field(default=None, description="Usually the company account ID that the lead occurred under. Contains company ID as value and company name as label.")
    status: StrictStr = Field(description="Lead status")
    place_id: Annotated[str, Field(min_length=1, strict=True)] = Field(description="Unique ID", alias="placeId")
    name_in_english: Annotated[str, Field(min_length=1, strict=True)] = Field(description="Name of lead", alias="nameInEnglish")
    name_in_local_language: Optional[StrictStr] = Field(default=None, description="Name of lead in local language", alias="nameInLocalLanguage")
    google_maps_url: Annotated[str, Field(min_length=1, strict=True)] = Field(description="Google Maps URL of the place", alias="googleMapsUrl")
    phone: Optional[StrictStr] = Field(default=None, description="Telephone of lead")
    address: Optional[AddressAffiliate] = Field(default=None, description="Address in English")
    address_local: Optional[SimpleAddressAffiliate] = Field(default=None, description="Address in local language if available", alias="addressLocal")
    formatted_address: Optional[StrictStr] = Field(default=None, description="Formatted address in English", alias="formattedAddress")
    formatted_address_local: Optional[StrictStr] = Field(default=None, description="Formatted address in local language if available", alias="formattedAddressLocal")
    html_address: Optional[StrictStr] = Field(default=None, description="Html address in English", alias="htmlAddress")
    html_address_local: Optional[StrictStr] = Field(default=None, description="Html address in local language if available", alias="htmlAddressLocal")
    location: GeoJsonPointAffiliate = Field(description="Country")
    photos: Optional[List[SimpleMultimediaAffiliate]] = Field(default=None, description="Photos for property")
    rating: Optional[Union[StrictFloat, StrictInt]] = Field(default=None, description="Hotel rating")
    user_rating_total: Optional[StrictInt] = Field(default=None, description="Total umber of user ratings", alias="userRatingTotal")
    utc_offset_minutes: StrictInt = Field(description="UTC offset minutes", alias="utcOffsetMinutes")
    website: Optional[StrictStr] = Field(default=None, description="Website")
    message_from_user: Optional[StrictStr] = Field(default=None, description="A personalized message from the inviter", alias="messageFromUser")
    city_options: Optional[List[Any]] = Field(default=None, alias="cityOptions")
    __properties: ClassVar[List[str]] = ["id", "createdDate", "lastUpdate", "version", "user", "owner", "status", "placeId", "nameInEnglish", "nameInLocalLanguage", "googleMapsUrl", "phone", "address", "addressLocal", "formattedAddress", "formattedAddressLocal", "htmlAddress", "htmlAddressLocal", "location", "photos", "rating", "userRatingTotal", "utcOffsetMinutes", "website", "messageFromUser", "cityOptions"]

    @field_validator('status')
    def status_validate_enum(cls, value):
        """Validates the enum"""
        if value not in set(['CREATED', 'IN_PROGRESS', 'INVITED', 'CLAIMED', 'REJECTED', 'INACTIVE']):
            raise ValueError("must be one of enum values ('CREATED', 'IN_PROGRESS', 'INVITED', 'CLAIMED', 'REJECTED', 'INACTIVE')")
        return value

    model_config = ConfigDict(
        populate_by_name=True,
        validate_assignment=True,
        protected_namespaces=(),
    )


    def to_str(self) -> str:
        """Returns the string representation of the model using alias"""
        return pprint.pformat(self.model_dump(by_alias=True))

    def to_json(self) -> str:
        """Returns the JSON representation of the model using alias"""
        # TODO: pydantic v2: use .model_dump_json(by_alias=True, exclude_unset=True) instead
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, json_str: str) -> Optional[Self]:
        """Create an instance of SupplierLeadAffiliate from a JSON string"""
        return cls.from_dict(json.loads(json_str))

    def to_dict(self) -> Dict[str, Any]:
        """Return the dictionary representation of the model using alias.

        This has the following differences from calling pydantic's
        `self.model_dump(by_alias=True)`:

        * `None` is only added to the output dict for nullable fields that
          were set at model initialization. Other fields with value `None`
          are ignored.
        """
        excluded_fields: Set[str] = set([
        ])

        _dict = self.model_dump(
            by_alias=True,
            exclude=excluded_fields,
            exclude_none=True,
        )
        # override the default output from pydantic by calling `to_dict()` of user
        if self.user:
            _dict['user'] = self.user.to_dict()
        # override the default output from pydantic by calling `to_dict()` of owner
        if self.owner:
            _dict['owner'] = self.owner.to_dict()
        # override the default output from pydantic by calling `to_dict()` of address
        if self.address:
            _dict['address'] = self.address.to_dict()
        # override the default output from pydantic by calling `to_dict()` of address_local
        if self.address_local:
            _dict['addressLocal'] = self.address_local.to_dict()
        # override the default output from pydantic by calling `to_dict()` of location
        if self.location:
            _dict['location'] = self.location.to_dict()
        # override the default output from pydantic by calling `to_dict()` of each item in photos (list)
        _items = []
        if self.photos:
            for _item_photos in self.photos:
                if _item_photos:
                    _items.append(_item_photos.to_dict())
            _dict['photos'] = _items
        return _dict

    @classmethod
    def from_dict(cls, obj: Optional[Dict[str, Any]]) -> Optional[Self]:
        """Create an instance of SupplierLeadAffiliate from a dict"""
        if obj is None:
            return None

        if not isinstance(obj, dict):
            return cls.model_validate(obj)

        _obj = cls.model_validate({
            "id": obj.get("id"),
            "createdDate": obj.get("createdDate"),
            "lastUpdate": obj.get("lastUpdate"),
            "version": obj.get("version"),
            "user": KeyValuePairAffiliate.from_dict(obj["user"]) if obj.get("user") is not None else None,
            "owner": KeyValuePairAffiliate.from_dict(obj["owner"]) if obj.get("owner") is not None else None,
            "status": obj.get("status"),
            "placeId": obj.get("placeId"),
            "nameInEnglish": obj.get("nameInEnglish"),
            "nameInLocalLanguage": obj.get("nameInLocalLanguage"),
            "googleMapsUrl": obj.get("googleMapsUrl"),
            "phone": obj.get("phone"),
            "address": AddressAffiliate.from_dict(obj["address"]) if obj.get("address") is not None else None,
            "addressLocal": SimpleAddressAffiliate.from_dict(obj["addressLocal"]) if obj.get("addressLocal") is not None else None,
            "formattedAddress": obj.get("formattedAddress"),
            "formattedAddressLocal": obj.get("formattedAddressLocal"),
            "htmlAddress": obj.get("htmlAddress"),
            "htmlAddressLocal": obj.get("htmlAddressLocal"),
            "location": GeoJsonPointAffiliate.from_dict(obj["location"]) if obj.get("location") is not None else None,
            "photos": [SimpleMultimediaAffiliate.from_dict(_item) for _item in obj["photos"]] if obj.get("photos") is not None else None,
            "rating": obj.get("rating"),
            "userRatingTotal": obj.get("userRatingTotal"),
            "utcOffsetMinutes": obj.get("utcOffsetMinutes"),
            "website": obj.get("website"),
            "messageFromUser": obj.get("messageFromUser"),
            "cityOptions": obj.get("cityOptions")
        })
        return _obj


