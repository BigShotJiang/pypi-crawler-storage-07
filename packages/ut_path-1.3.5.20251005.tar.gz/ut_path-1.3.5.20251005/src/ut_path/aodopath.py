# coding=utf-8
import importlib
import os

from ut_log.log import LogEq

from typing import Any

TyDic = dict[Any, Any]
TyPath = str
TyDoPath = dict[Any, TyPath]
TyAoDoPath = list[TyDoPath]
TyStr = str
TyAoS = list[TyStr]


class AoDoPath:

    @staticmethod
    def resolve_path(aodopath: TyAoDoPath, kwargs: TyDic) -> TyAoDoPath:
        _aodopath_new: TyAoDoPath = []
        _package = kwargs.get('package', '')
        _pac: TyPath = str(importlib.resources.files(_package))
        for _dopath in aodopath:
            _dopath_new: TyDoPath = {}
            for _key, _path in _dopath.items():
                LogEq.debug("_path", _path)
                _normalized_path: TyPath = os.path.normpath(_path)
                _a_part: TyAoS = _normalized_path.split(os.sep)
                _a_part_new: TyAoS = []
                for _part in _a_part:
                    if _part[0] == '$':
                        if _part == '$pac':
                            _part = _pac
                        else:
                            _val = kwargs.get(_part[1:])
                            if _val is None:
                                _msg = (f"Variable='{_part}' is not "
                                        f"contained in kwargs={kwargs}")
                                raise Exception(_msg)
                            _part = _val
                    _a_part_new.append(_part)
                _path_new = os.path.join(*_a_part_new)
                _dopath_new[_key] = _path_new
            _aodopath_new.append(_dopath_new)
        return _aodopath_new
