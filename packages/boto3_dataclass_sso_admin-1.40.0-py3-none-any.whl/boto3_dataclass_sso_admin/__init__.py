# -*- coding: utf-8 -*-

from .caster import sso_admin_caster

caster = sso_admin_caster

__version__ = "1.40.0"