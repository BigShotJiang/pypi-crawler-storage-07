# Copyright (C) 2021 Nippon Telegraph and Telephone Corporation
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from tacker.sol_refactored.objects import base
from tacker.sol_refactored.objects import fields


# NFV-SOL 003
# - v3.3.1 9.5.3.2 (API version: 1.4.0)
@base.TackerObjectRegistry.register
class ResourceDefinitionV1(base.TackerObject, base.TackerObjectDictCompat):

    # Version 1.0: Initial version
    VERSION = '1.0'

    fields = {
        'id': fields.StringField(nullable=False),
        'type': fields.EnumField(
            valid_values=[
                'COMPUTE',
                'VL',
                'STORAGE',
                'LINKPORT',
            ],
            nullable=False,
        ),
        'vduId': fields.StringField(nullable=True),
        'vnfdId': fields.StringField(nullable=True),
        'resourceTemplateId': fields.StringField(nullable=False),
        'resource': fields.ObjectField(
            'ResourceHandle', nullable=True),
        'snapshotResDef': fields.ObjectField(
            'SnapshotResourceDefinitionV1', nullable=True),
    }
