# -*- coding: utf-8 -*-

from .caster import sagemaker_featurestore_runtime_caster

caster = sagemaker_featurestore_runtime_caster

__version__ = "1.40.0"