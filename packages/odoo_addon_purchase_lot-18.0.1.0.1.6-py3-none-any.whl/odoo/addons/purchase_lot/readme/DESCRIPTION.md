This module adds the lot_id field in the purchase order lines,
and propagates it to stock pickings in the order confirmation.

This module can also be used along with sale_order_lot_selection to propagate lot from sale orders to purchase orders.
It allows to buy specific lot for a sale order (may be useful for fully configurable products)
