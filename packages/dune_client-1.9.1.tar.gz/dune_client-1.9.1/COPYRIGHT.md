# Intellectual Property Notice
 
Copyright (c) 2022 Cow Services Lda
Copyright (c) 2023 Dune Analytics AS

Except as otherwise noted (below and/or in individual files), this project is licensed under
the Apache License, Version 2.0 ([`LICENSE-APACHE`](LICENSE-APACHE) or <http://www.apache.org/licenses/LICENSE-2.0>).
