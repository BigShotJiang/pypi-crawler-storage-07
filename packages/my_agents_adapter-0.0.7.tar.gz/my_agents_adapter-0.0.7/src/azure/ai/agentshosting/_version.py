# Simple version management for my-agents-adapter package
VERSION = "0.0.7"

__all__ = ["VERSION"]