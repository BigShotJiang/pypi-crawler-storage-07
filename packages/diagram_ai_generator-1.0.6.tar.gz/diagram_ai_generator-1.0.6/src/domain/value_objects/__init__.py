"""Domain value objects"""

