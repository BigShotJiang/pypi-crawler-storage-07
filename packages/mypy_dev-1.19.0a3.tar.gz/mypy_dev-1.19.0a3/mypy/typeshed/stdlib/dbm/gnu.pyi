from _gdbm import *
