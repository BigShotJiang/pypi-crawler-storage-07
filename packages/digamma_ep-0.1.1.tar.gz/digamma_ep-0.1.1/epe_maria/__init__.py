from .info import teach
