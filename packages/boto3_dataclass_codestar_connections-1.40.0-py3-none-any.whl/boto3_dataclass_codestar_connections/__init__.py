# -*- coding: utf-8 -*-

from .caster import codestar_connections_caster

caster = codestar_connections_caster

__version__ = "1.40.0"