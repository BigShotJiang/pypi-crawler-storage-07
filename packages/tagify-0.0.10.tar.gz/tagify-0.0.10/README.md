# tagify
Parser that converts strings with variables and functions to more advance strings

Style is a bit inspired by jinja2 format, but not 100% the same.

This project is very early development, I might use it or not, but I'm not sure.

## Requirements
- Python >=3.11

## Install
```
pip install tagify
```
