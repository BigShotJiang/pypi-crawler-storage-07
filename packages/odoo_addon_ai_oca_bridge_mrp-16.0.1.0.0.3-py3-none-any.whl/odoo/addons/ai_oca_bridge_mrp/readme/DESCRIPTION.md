This module is intended to allow external AI systems to perform actions with the correct context, based on triggers related to MRP.
