Depending on the bridges you have created, create, update or delete a MRP record matching the bridge domain. You should see the execution on the AI Bridge Execution menu.
