# -*- coding: utf-8 -*-

from .caster import glacier_caster

caster = glacier_caster

__version__ = "1.40.0"