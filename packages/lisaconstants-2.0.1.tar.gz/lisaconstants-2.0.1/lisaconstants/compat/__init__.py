"""
Compatibility modules
=====================

.. automodule:: lisaconstants.compat.astropy
"""

from . import astropy

__all__ = ["astropy"]
