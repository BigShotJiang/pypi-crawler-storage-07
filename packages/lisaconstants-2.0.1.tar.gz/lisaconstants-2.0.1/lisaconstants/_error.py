"""Definition of package base exception."""


class LisaConstantsException(Exception):
    """Base exception for errors raised by LISA Constants."""
