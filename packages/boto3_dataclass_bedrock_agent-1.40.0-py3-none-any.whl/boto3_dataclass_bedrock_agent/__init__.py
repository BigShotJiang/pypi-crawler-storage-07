# -*- coding: utf-8 -*-

from .caster import bedrock_agent_caster

caster = bedrock_agent_caster

__version__ = "1.40.0"