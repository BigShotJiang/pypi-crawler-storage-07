This module manages the payment mode from sale order to contract.
