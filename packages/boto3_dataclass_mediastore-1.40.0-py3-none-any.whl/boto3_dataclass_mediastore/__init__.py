# -*- coding: utf-8 -*-

from .caster import mediastore_caster

caster = mediastore_caster

__version__ = "1.40.0"