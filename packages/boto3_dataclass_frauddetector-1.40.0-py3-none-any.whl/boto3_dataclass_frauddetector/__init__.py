# -*- coding: utf-8 -*-

from .caster import frauddetector_caster

caster = frauddetector_caster

__version__ = "1.40.0"