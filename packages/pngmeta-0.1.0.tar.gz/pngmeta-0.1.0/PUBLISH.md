# Publishing pngmeta to PyPI

## Pre-publish Checklist

- [ ] Update version in `pyproject.toml`
- [ ] Update `CHANGELOG.md` (if you create one)
- [ ] Update `README.md` with any new features
- [ ] Run tests: `pytest`
- [ ] Format code: `black pngmeta tests examples`
- [ ] Lint code: `ruff check pngmeta tests examples`
- [ ] Update author info in `pyproject.toml`
- [ ] Update GitHub URL in `pyproject.toml`

## First Time Setup

1. Create a PyPI account at https://pypi.org/account/register/

2. Create an API token at https://pypi.org/manage/account/token/
   - Token name: `pngmeta-upload`
   - Scope: Entire account (or specific to project after first upload)

3. Configure uv with your token:
   ```bash
   # Create/edit ~/.pypirc
   cat > ~/.pypirc << EOF
   [distutils]
   index-servers =
       pypi
       testpypi

   [pypi]
   username = __token__
   password = pypi-YOUR-TOKEN-HERE

   [testpypi]
   repository = https://test.pypi.org/legacy/
   username = __token__
   password = pypi-YOUR-TESTPYPI-TOKEN-HERE
   EOF

   chmod 600 ~/.pypirc
   ```

## Build the Package

```bash
# Clean previous builds
rm -rf dist/

# Build with uv
uv build
```

This creates:
- `dist/pngmeta-0.1.0-py3-none-any.whl` (wheel)
- `dist/pngmeta-0.1.0.tar.gz` (source distribution)

## Test on TestPyPI First

```bash
# Upload to TestPyPI
uv publish --publish-url https://test.pypi.org/legacy/

# Test installation in a new environment
uv venv test-env
source test-env/bin/activate
uv pip install --index-url https://test.pypi.org/simple/ pngmeta

# Try it out
python -c "from pngmeta import PngMeta; print(PngMeta.__doc__)"

# Clean up
deactivate
rm -rf test-env
```

## Publish to PyPI

Once you've verified everything works on TestPyPI:

```bash
uv publish
```

Your package will be live at: https://pypi.org/project/pngmeta/

## After Publishing

1. Tag the release in git:
   ```bash
   git tag -a v0.1.0 -m "Release version 0.1.0"
   git push origin v0.1.0
   ```

2. Create a GitHub release with release notes

3. Test installation:
   ```bash
   uv pip install pngmeta
   ```

## Updating the Package

1. Update version in `pyproject.toml`
2. Run through the checklist above
3. Build and publish:
   ```bash
   uv build
   uv publish
   ```

## Quick Commands

```bash
# Complete workflow
black pngmeta tests examples
ruff check pngmeta tests examples
pytest
uv build
uv publish --publish-url https://test.pypi.org/legacy/  # Test first
uv publish  # Then real PyPI
```
