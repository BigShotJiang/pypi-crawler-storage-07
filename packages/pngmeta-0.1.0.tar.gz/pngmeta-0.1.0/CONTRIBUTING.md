# Contributing to pngmeta

## Development Setup with uv

1. Install [uv](https://github.com/astral-sh/uv) if you haven't already:
```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

2. Clone the repository:
```bash
git clone https://github.com/yourusername/pngmeta.git
cd pngmeta
```

3. Create a virtual environment and install dependencies:
```bash
uv venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
uv pip install -e ".[dev]"
```

## Running Tests

```bash
pytest
```

With coverage:
```bash
pytest --cov=pngmeta --cov-report=html
```

## Code Quality

Format code with black:
```bash
black pngmeta tests examples
```

Lint with ruff:
```bash
ruff check pngmeta tests examples
```

## Building the Package

Build with uv:
```bash
uv build
```

This creates wheel and source distributions in `dist/`.

## Publishing to PyPI

1. Build the package:
```bash
uv build
```

2. Publish to TestPyPI first:
```bash
uv publish --publish-url https://test.pypi.org/legacy/
```

3. Test the installation:
```bash
uv pip install --index-url https://test.pypi.org/simple/ pngmeta
```

4. Publish to PyPI:
```bash
uv publish
```

You'll need PyPI credentials configured. See [PyPI documentation](https://pypi.org/help/) for details.

## Project Structure

```
pngmeta/
├── pngmeta/           # Main package
│   ├── __init__.py    # Package exports
│   ├── pngmeta.py     # Core PngMeta class
│   └── exceptions.py  # Exception classes
├── tests/             # Test suite
├── examples/          # Usage examples
├── pyproject.toml     # Package configuration
├── README.md          # User documentation
└── LICENSE            # Unlicense
```

## Guidelines

- Keep the API simple and similar to iptcinfo3
- Maintain Python 3.8+ compatibility
- Add tests for new features
- Update README.md with examples
- Follow PEP 8 (enforced by black and ruff)
