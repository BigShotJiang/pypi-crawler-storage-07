def hello():
    """A simple hello function."""
    return "Hello from Nitro!"
