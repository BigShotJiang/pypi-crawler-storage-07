# Version file for build-time import
# This file should have no dependencies to avoid import issues during build
__version__ = "1.2.0"
