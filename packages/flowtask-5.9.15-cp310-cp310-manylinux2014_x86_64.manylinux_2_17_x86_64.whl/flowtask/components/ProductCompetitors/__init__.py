from .scrapper import ProductCompetitors

__all__ = (
    'ProductCompetitors',
)
