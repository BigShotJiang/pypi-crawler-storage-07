"""Version information for aiogram-sentinel."""

__version__ = "0.1.0"
