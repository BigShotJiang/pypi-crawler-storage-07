# -*- coding: utf-8 -*-

from .caster import securitylake_caster

caster = securitylake_caster

__version__ = "1.40.0"