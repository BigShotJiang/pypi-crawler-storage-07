=====
Usage
=====

Start by importing ganrec.

.. code-block:: python

    import ganrc
