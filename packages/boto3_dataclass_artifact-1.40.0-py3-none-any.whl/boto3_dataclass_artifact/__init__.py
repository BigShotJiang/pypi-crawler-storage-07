# -*- coding: utf-8 -*-

from .caster import artifact_caster

caster = artifact_caster

__version__ = "1.40.0"