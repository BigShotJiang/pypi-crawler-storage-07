"""Módulos do model do mtcli."""
