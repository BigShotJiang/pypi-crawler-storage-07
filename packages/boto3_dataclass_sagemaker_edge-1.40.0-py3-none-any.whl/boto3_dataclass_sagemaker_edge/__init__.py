# -*- coding: utf-8 -*-

from .caster import sagemaker_edge_caster

caster = sagemaker_edge_caster

__version__ = "1.40.0"