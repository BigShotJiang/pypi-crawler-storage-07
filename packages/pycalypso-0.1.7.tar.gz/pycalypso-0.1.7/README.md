![banner](https://raw.githubusercontent.com/Game-K-Hack/calypso/master/assets/calypso-banner-rounded.jpg)

### CALYPSO

The *Calypso* is an oceanographic vessel equipped and used by the maritime explorer Jacques-Yves Cousteau for his scientific expeditions and documentary film productions.

Named after Calypso, the sea nymph from Greek mythology, the ship and its crew sailed the world’s seas and oceans from November 24, 1951, until January 1996. Through television and books, the *Calypso* became one of the symbols of maritime exploration and global ecology in the second half of the 20th century, in the tradition of its illustrious predecessors such as *La Boussole* and *L’Astrolabe*, the *Beagle*, the *Challenger*, the *Pourquoi Pas?*, and the *Hirondelle*.

## Description

**Calypso** is not only the name of a famous exploration vessel: it’s also a Python library for **web scraping**.  
Unlike general-purpose tools such as HTTrack, which download an entire site before extracting data, Calypso is designed to be **fast and targeted**. It only retrieves the information you need, in an optimized way.  
If the website you want to scrape is supported by the library, **Calypso is the ideal choice**.  

## Supported website

| Logo | Name | Address | Function |
| ---- | ---- | ------- | -------- |
| ![Bin.sx logo](https://raw.githubusercontent.com/Game-K-Hack/calypso/master/assets/logo/__not_found__.png) |  Bin.sx |  [bin.sx](https://paste.bin.sx) |  `get_text_by_id` |
| ![Coomer logo](./assets/logo/coomer.png) |  Coomer |  [coomer.st](https://coomer.st/) |  `search`, `get_posts`, `download` |
| ![Got any Nudes? logo](./assets/logo/gotanynudes.png) |  Got any Nudes? |  [gotanynudes.com](https://gotanynudes.com/) |  `search`, `get_posts`, `download` |
| ![Leaked zone logo](./assets/logo/leakedzone.png) |  Leaked zone |  [leakedzone.com](https://leakedzone.com/) |  `search`, `get_posts`, `download` |
| ![Open Food Facts (API V3) logo](./assets/logo/openfoodfactsv3.png) |  Open Food Facts (API V3) |  [openfoodfacts.org](https://fr.openfoodfacts.org/) |  `get_products`, `get_list_of_preference_importance_values`, `get_list_of_attribute_groups_and_attributes`, `get_canonical_tags_for_a_list_of_local_tags`, `get_display_tags_in_a_specific_language_for_a_list_of_taxonomy_tags`, `get_taxonomy_suggestions`, `get_tag_knowledge_panels` |
| ![Voir Anime logo](./assets/logo/voiranime.png) |  Voir Anime |  [voiranime.com](https://v6.voiranime.com/) |  `search`, `get_anime` |
| ![Voir Drama logo](./assets/logo/voirdrama.png) |  Voir Drama |  [voirdrama.org](https://voirdrama.org/) |  `search`, `get_drama` |
