# -*- coding: utf-8 -*-

from .caster import servicecatalog_caster

caster = servicecatalog_caster

__version__ = "1.40.0"