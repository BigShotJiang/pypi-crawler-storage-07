## [0.2.0] - 2025-01-XX
   
   ### Added
   - New feature X
   
   ### Fixed
   - Bug fix Y