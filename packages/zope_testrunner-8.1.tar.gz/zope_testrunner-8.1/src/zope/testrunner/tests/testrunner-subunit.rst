Subunit Output
==============

Subunit is a streaming protocol for interchanging test results. More
information can be found at https://launchpad.net/subunit.  To enable
support for ``subunit``, install it and its dependencies via the
``zope.testrunner`` extra:

    $ pip install zope.testrunner[subunit]

or directly:

    $ pip install python-subunit

First we set up some defaults:

    >>> import os.path, sys

    >>> defaults = [
    ...     '--subunit',
    ...     '--path', os.path.join(this_directory, 'testrunner-ex'),
    ...     '--tests-pattern', '^sampletestsf?$',
    ...     ]

    >>> from zope import testrunner


Basic output
------------

Subunit output is line-based, with a 'test:' line for the start of each test
and a 'successful:' line for each successful test.

Zope layer setup and teardown events are represented as tests tagged with
'zope:layer'. This allows them to be distinguished from actual tests, provides
a place for the layer timing information in the subunit stream and allows us
to include error information if necessary.

Once the layer is set up, all future tests are tagged with
'zope:layer:LAYER_NAME'.

    >>> sys.argv = 'test --layer 122 -t TestNotMuch'.split()
    >>> testrunner.run_internal(defaults)
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: samplelayers.Layer1:setUp
    tags: zope:layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: samplelayers.Layer1:setUp
    tags: zope:layer:samplelayers.Layer1
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: samplelayers.Layer12:setUp
    tags: zope:layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: samplelayers.Layer12:setUp
    tags: zope:layer:samplelayers.Layer12
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: samplelayers.Layer122:setUp
    tags: zope:layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: samplelayers.Layer122:setUp
    tags: zope:layer:samplelayers.Layer122
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample1.sampletests.test122.TestNotMuch.test_1
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: sample1.sampletests.test122.TestNotMuch.test_1
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample1.sampletests.test122.TestNotMuch.test_2
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: sample1.sampletests.test122.TestNotMuch.test_2
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample1.sampletests.test122.TestNotMuch.test_3
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: sample1.sampletests.test122.TestNotMuch.test_3
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sampletests.test122.TestNotMuch.test_1
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: sampletests.test122.TestNotMuch.test_1
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sampletests.test122.TestNotMuch.test_2
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: sampletests.test122.TestNotMuch.test_2
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sampletests.test122.TestNotMuch.test_3
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: sampletests.test122.TestNotMuch.test_3
    tags: -zope:layer:samplelayers.Layer122
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: samplelayers.Layer122:tearDown
    tags: zope:layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: samplelayers.Layer122:tearDown
    tags: -zope:layer:samplelayers.Layer12
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: samplelayers.Layer12:tearDown
    tags: zope:layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: samplelayers.Layer12:tearDown
    tags: -zope:layer:samplelayers.Layer1
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: samplelayers.Layer1:tearDown
    tags: zope:layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: samplelayers.Layer1:tearDown
    False


Listing tests
-------------

A subunit stream is a stream of test results, more or less, so the most
natural way of listing tests in subunit is to simply emit successful test
results without actually running the tests.

Note that in this stream, we don't emit fake tests for the layer set up and
tear down, because it simply doesn't happen.

We also don't include the dependent layers in the stream (in this case Layer1
and Layer12), since they are not provided to the reporter.

    >>> sys.argv = 'test --layer 122 --list-tests -t TestNotMuch'.split()
    >>> testrunner.run_internal(defaults)
    tags: zope:layer:samplelayers.Layer122
    test: sample1.sampletests.test122.TestNotMuch.test_1
    successful: sample1.sampletests.test122.TestNotMuch.test_1
    test: sample1.sampletests.test122.TestNotMuch.test_2
    successful: sample1.sampletests.test122.TestNotMuch.test_2
    test: sample1.sampletests.test122.TestNotMuch.test_3
    successful: sample1.sampletests.test122.TestNotMuch.test_3
    test: sampletests.test122.TestNotMuch.test_1
    successful: sampletests.test122.TestNotMuch.test_1
    test: sampletests.test122.TestNotMuch.test_2
    successful: sampletests.test122.TestNotMuch.test_2
    test: sampletests.test122.TestNotMuch.test_3
    successful: sampletests.test122.TestNotMuch.test_3
    tags: -zope:layer:samplelayers.Layer122
    False


Profiling tests
---------------

Test suites often cover a lot of code, and the performance of test suites
themselves is often a critical part of the development process. Thus, it's
good to be able to profile a test run.

    >>> import tempfile
    >>> tempdir = tempfile.mkdtemp(prefix='zope.testrunner-test-')

    >>> sys.argv = [
    ...     'test', '--layer=122', '--profile=cProfile',
    ...     '--profile-directory', tempdir,
    ...     '-t', 'TestNotMuch']
    >>> testrunner.run_internal(defaults)
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: samplelayers.Layer1:setUp
    ...
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: samplelayers.Layer1:tearDown
    test: zope:profiler_stats
    tags: zope:profiler_stats
    successful: zope:profiler_stats [ multipart
    Content-Type: application/x-binary-profile
    profiler-stats
    ...\r
    <BLANKLINE>
    ...
    <BLANKLINE>
    ]
    False

    >>> import shutil
    >>> shutil.rmtree(tempdir)


Errors
------

Errors are recorded in the subunit stream as MIME-encoded chunks of text.

    >>> sys.argv = ['test', '--tests-pattern', '^sampletests_e$']
    >>> testrunner.run_internal(defaults)
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: zope.testrunner.layer.UnitTests:setUp
    tags: zope:layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: zope.testrunner.layer.UnitTests:setUp
    tags: zope:layer:zope.testrunner.layer.UnitTests
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample2.sampletests_e.eek
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    failure: sample2.sampletests_e.eek [ multipart
    Content-Type: text/x-traceback...
    traceback
    NNN\r
    <BLANKLINE>
    Failed doctest test for sample2.sampletests_e.eek
     testrunner-ex/sample2/sampletests_e.py", Line NNN, in eek
    <BLANKLINE>
    ----------------------------------------------------------------------
    File testrunner-ex/sample2/sampletests_e.py", Line NNN, in sample2.sampletests_e.eek
    Failed example:
        f()
    Exception raised:
        Traceback (most recent call last):
          File "<doctest sample2.sampletests_e.eek[0]>", Line NNN, in ?
            f()
     testrunner-ex/sample2/sampletests_e.py", Line NNN, in f
            g()
     testrunner-ex/sample2/sampletests_e.py", Line NNN, in g
            x = y + 1  # noqa: F821
           - __traceback_info__: I don't know what Y should be.
        NameError: name 'y' is not defined
    0\r
    <BLANKLINE>
    ]
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample2.sampletests_e.Test.test1
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: sample2.sampletests_e.Test.test1
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample2.sampletests_e.Test.test2
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: sample2.sampletests_e.Test.test2
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample2.sampletests_e.Test.test3
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    error: sample2.sampletests_e.Test.test3 [ multipart
    Content-Type: text/x-traceback...
    traceback
    NNN\r
    <BLANKLINE>
    Traceback (most recent call last):
     testrunner-ex/sample2/sampletests_e.py", Line NNN, in test3
        f()
     testrunner-ex/sample2/sampletests_e.py", Line NNN, in f
        g()
     testrunner-ex/sample2/sampletests_e.py", Line NNN, in g
        x = y + 1  # noqa: F821
       - __traceback_info__: I don't know what Y should be.
    NameError: name 'y' is not defined
    0\r
    <BLANKLINE>
    ]
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample2.sampletests_e.Test.test4
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: sample2.sampletests_e.Test.test4
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample2.sampletests_e.Test.test5
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: sample2.sampletests_e.Test.test5
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: e_rst
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    failure: e_rst [ multipart
    Content-Type: text/x-traceback...
    traceback
    NNN\r
    <BLANKLINE>
    Failed doctest test for e.rst
     testrunner-ex/sample2/e.rst", line 0
    <BLANKLINE>
    ----------------------------------------------------------------------
    File testrunner-ex/sample2/e.rst", Line NNN, in e.rst
    Failed example:
        f()
    Exception raised:
        Traceback (most recent call last):
          File "<doctest e.rst[1]>", Line NNN, in ?
            f()
          File "<doctest e.rst[0]>", Line NNN, in f
            return x
        NameError: name 'x' is not defined
    0\r
    <BLANKLINE>
    ]
    tags: -zope:layer:zope.testrunner.layer.UnitTests
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: zope.testrunner.layer.UnitTests:tearDown
    tags: zope:layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: zope.testrunner.layer.UnitTests:tearDown
    True


Capturing output
----------------

To avoid corrupting subunit streams, any output on stdout and stderr is
buffered; for failing and erroring tests, it is recorded in the subunit
stream as MIME-encoded chunks of text.

    >>> sys.argv = 'test -ssample2 --tests-pattern ^stdstreamstest$'.split()
    >>> testrunner.run_internal(defaults)
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: zope.testrunner.layer.UnitTests:setUp
    tags: zope:layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: zope.testrunner.layer.UnitTests:setUp
    tags: zope:layer:zope.testrunner.layer.UnitTests
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample2.stdstreamstest.Test.test_stderr_error
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    error: sample2.stdstreamstest.Test.test_stderr_error [ multipart
    Content-Type: text/plain;charset=utf8
    test-stderr
    35\r
    stderr output on error
    stderr buffer output on error
    0\r
    <BLANKLINE>
    Content-Type: text/x-traceback...
    traceback
    NNN\r
    <BLANKLINE>
    Traceback (most recent call last):
     testrunner-ex/sample2/stdstreamstest.py", Line NNN, in test_stderr_error
        raise Exception("boom")
    Exception: boom
    0\r
    <BLANKLINE>
    ]
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample2.stdstreamstest.Test.test_stderr_failure
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    failure: sample2.stdstreamstest.Test.test_stderr_failure [ multipart
    Content-Type: text/plain;charset=utf8
    test-stderr
    39\r
    stderr output on failure
    stderr buffer output on failure
    0\r
    <BLANKLINE>
    Content-Type: text/x-traceback...
    traceback
    NNN\r
    <BLANKLINE>
    Traceback (most recent call last):
     testrunner-ex/sample2/stdstreamstest.py", Line NNN, in test_stderr_failure
        self.assertTrue(False)
    AssertionError: False is not true
    0\r
    <BLANKLINE>
    ]
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample2.stdstreamstest.Test.test_stderr_success
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: sample2.stdstreamstest.Test.test_stderr_success
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample2.stdstreamstest.Test.test_stdout_error
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    error: sample2.stdstreamstest.Test.test_stdout_error [ multipart
    Content-Type: text/plain;charset=utf8
    test-stdout
    35\r
    stdout output on error
    stdout buffer output on error
    0\r
    <BLANKLINE>
    Content-Type: text/x-traceback...
    traceback
    NNN\r
    <BLANKLINE>
    Traceback (most recent call last):
     testrunner-ex/sample2/stdstreamstest.py", Line NNN, in test_stdout_error
        raise Exception("boom")
    Exception: boom
    0\r
    <BLANKLINE>
    ]
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample2.stdstreamstest.Test.test_stdout_failure
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    failure: sample2.stdstreamstest.Test.test_stdout_failure [ multipart
    Content-Type: text/plain;charset=utf8
    test-stdout
    39\r
    stdout output on failure
    stdout buffer output on failure
    0\r
    <BLANKLINE>
    Content-Type: text/x-traceback...
    traceback
    NNN\r
    <BLANKLINE>
    Traceback (most recent call last):
     testrunner-ex/sample2/stdstreamstest.py", Line NNN, in test_stdout_failure
        self.assertTrue(False)
    AssertionError: False is not true
    0\r
    <BLANKLINE>
    ]
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample2.stdstreamstest.Test.test_stdout_success
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: sample2.stdstreamstest.Test.test_stdout_success
    tags: -zope:layer:zope.testrunner.layer.UnitTests
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: zope.testrunner.layer.UnitTests:tearDown
    tags: zope:layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: zope.testrunner.layer.UnitTests:tearDown
    True


Layers that can't be torn down
------------------------------

A layer can have a tearDown method that raises NotImplementedError. If this is
the case, the subunit stream will say that the layer skipped its tearDown.

    >>> sys.argv = 'test -ssample2 --tests-pattern sampletests_ntd$'.split()
    >>> testrunner.run_internal(defaults)
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample2.sampletests_ntd.Layer:setUp
    tags: zope:layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: sample2.sampletests_ntd.Layer:setUp
    tags: zope:layer:sample2.sampletests_ntd.Layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample2.sampletests_ntd.TestSomething.test_something
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: sample2.sampletests_ntd.TestSomething.test_something
    tags: -zope:layer:sample2.sampletests_ntd.Layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample2.sampletests_ntd.Layer:tearDown
    tags: zope:layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    skip: sample2.sampletests_ntd.Layer:tearDown [
    tearDown not supported
    ]
    False


Layer failures
--------------

If a layer's setUp or tearDown method fails in some other way, this is shown
in the subunit stream.

    >>> sys.argv = 'test --tests-pattern ^brokenlayer$'.split()
    >>> testrunner.run_internal(defaults)
    time: ...
    test: brokenlayer.BrokenSetUpLayer:setUp
    tags: zope:layer
    failure: brokenlayer.BrokenSetUpLayer:setUp [
    Traceback (most recent call last):
    ...
    ValueError: No value is good enough for me!
    ]
    time: ...
    test: brokenlayer.BrokenTearDownLayer:tearDown
    tags: zope:layer
    failure: brokenlayer.BrokenTearDownLayer:tearDown [
    Traceback (most recent call last):
    ...
    TypeError: You are not my type.  No-one is my type!
    ]
    True


Module import errors
--------------------

We report module import errors too. They get encoded as tests with errors. The
name of the test is the module that could not be imported, the test's result
is an error containing the traceback. These "tests" are tagged with
zope:import_error.

Let's run tests including a module with some bad syntax:

    >>> sys.argv = [
    ...     'test', '--tests-pattern', '^(badsyntax|sampletests(f|_i)?)$',
    ...     '--layer', '1']
    >>> testrunner.run_internal(defaults)
    test: sample2.badsyntax
    tags: zope:import_error
    error: sample2.badsyntax [...
      File "/home/benji/workspace/all-the-trunks/zope.testrunner/src/zope/testrunner/testrunner-ex/sample2/badsyntax.py", line 16
        importx unittest  # noqa: E999
                    ...^
    SyntaxError: invalid syntax...
    ]
    test: sample2.sample21.sampletests_i
    tags: zope:import_error
    error: sample2.sample21.sampletests_i [
    Traceback (most recent call last):
      File "/home/benji/workspace/all-the-trunks/zope.testrunner/src/zope/testrunner/testrunner-ex/sample2/sample21/sampletests_i.py", line 16, in <module>
        import zope.testrunner.huh  # noqa: F401...
    ModuleNotFoundError: No module named 'zope.testrunner.huh'
    ]
    test: sample2.sample23.sampletests_i
    tags: zope:import_error
    error: sample2.sample23.sampletests_i [
    Traceback (most recent call last):
      File "/home/benji/workspace/all-the-trunks/zope.testrunner/src/zope/testrunner/testrunner-ex/sample2/sample23/sampletests_i.py", line 17, in <module>
        class Test(unittest.TestCase):
      ...
        raise TypeError('eek')
    TypeError: eek
    ]
    time: 2010-07-19 21:27:16.708260Z
    test: samplelayers.Layer1:setUp
    tags: zope:layer
    ...
    True


Tests in subprocesses
---------------------

If the tearDown method raises NotImplementedError and there are remaining
layers to run, the test runner will restart itself as a new process,
resuming tests where it left off:

    >>> sys.argv = [testrunner_script, '--tests-pattern', 'sampletests_ntd$']
    >>> testrunner.run_internal(defaults)
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample1.sampletests_ntd.Layer:setUp
    tags: zope:layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: sample1.sampletests_ntd.Layer:setUp
    tags: zope:layer:sample1.sampletests_ntd.Layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample1.sampletests_ntd.TestSomething.test_something
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: sample1.sampletests_ntd.TestSomething.test_something
    tags: -zope:layer:sample1.sampletests_ntd.Layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample1.sampletests_ntd.Layer:tearDown
    tags: zope:layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    skip: sample1.sampletests_ntd.Layer:tearDown [
    tearDown not supported
    ]
    test: Running in a subprocess.
    tags: zope:info_suboptimal
    successful: Running in a subprocess.
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample2.sampletests_ntd.Layer:setUp
    tags: zope:layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: sample2.sampletests_ntd.Layer:setUp
    tags: zope:layer:sample2.sampletests_ntd.Layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample2.sampletests_ntd.TestSomething.test_something
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: sample2.sampletests_ntd.TestSomething.test_something
    tags: -zope:layer:sample2.sampletests_ntd.Layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample2.sampletests_ntd.Layer:tearDown
    tags: zope:layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    skip: sample2.sampletests_ntd.Layer:tearDown [
    tearDown not supported
    ]
    test: Running in a subprocess.
    tags: zope:info_suboptimal
    successful: Running in a subprocess.
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample3.sampletests_ntd.Layer:setUp
    tags: zope:layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: sample3.sampletests_ntd.Layer:setUp
    tags: zope:layer:sample3.sampletests_ntd.Layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample3.sampletests_ntd.TestSomething.test_error1
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    error: sample3.sampletests_ntd.TestSomething.test_error1 [ multipart
    Content-Type: text/x-traceback...
    traceback
    14F\r
    <BLANKLINE>
    Traceback (most recent call last):
     testrunner-ex/sample3/sampletests_ntd.py", Line NNN, in test_error1
        raise TypeError("Can we see errors")
    TypeError: Can we see errors
    0\r
    <BLANKLINE>
    ]
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample3.sampletests_ntd.TestSomething.test_error2
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    error: sample3.sampletests_ntd.TestSomething.test_error2 [ multipart
    Content-Type: text/x-traceback...
    traceback
    13F\r
    <BLANKLINE>
    Traceback (most recent call last):
     testrunner-ex/sample3/sampletests_ntd.py", Line NNN, in test_error2
        raise TypeError("I hope so")
    TypeError: I hope so
    0\r
    <BLANKLINE>
    ]
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample3.sampletests_ntd.TestSomething.test_fail1
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    failure: sample3.sampletests_ntd.TestSomething.test_fail1 [ multipart
    Content-Type: text/x-traceback...
    traceback
    1AA\r
    <BLANKLINE>
    Traceback (most recent call last):
     testrunner-ex/sample3/sampletests_ntd.py", Line NNN, in test_fail1
        self.assertEqual(1, 2)
    AssertionError: 1 != 2
    0\r
    <BLANKLINE>
    ]
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample3.sampletests_ntd.TestSomething.test_fail2
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    failure: sample3.sampletests_ntd.TestSomething.test_fail2 [ multipart
    Content-Type: text/x-traceback...
    traceback
    1AA\r
    <BLANKLINE>
    Traceback (most recent call last):
     testrunner-ex/sample3/sampletests_ntd.py", Line NNN, in test_fail2
        self.assertEqual(1, 3)
    AssertionError: 1 != 3
    0\r
    <BLANKLINE>
    ]
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample3.sampletests_ntd.TestSomething.test_something
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: sample3.sampletests_ntd.TestSomething.test_something
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample3.sampletests_ntd.TestSomething.test_something_else
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: sample3.sampletests_ntd.TestSomething.test_something_else
    tags: -zope:layer:sample3.sampletests_ntd.Layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample3.sampletests_ntd.Layer:tearDown
    tags: zope:layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    skip: sample3.sampletests_ntd.Layer:tearDown [
    tearDown not supported
    ]
    True

Note that debugging doesn't work when running tests in a subprocess:

    >>> sys.argv = [testrunner_script, '--tests-pattern', 'sampletests_ntd$',
    ...             '-D', ]
    >>> testrunner.run_internal(defaults)
    time: 2010-02-10 22:41:25.279692Z
    test: sample1.sampletests_ntd.Layer:setUp
    tags: zope:layer
    time: 2010-02-10 22:41:25.279695Z
    successful: sample1.sampletests_ntd.Layer:setUp
    tags: zope:layer:sample1.sampletests_ntd.Layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample1.sampletests_ntd.TestSomething.test_something
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: sample1.sampletests_ntd.TestSomething.test_something
    tags: -zope:layer:sample1.sampletests_ntd.Layer
    time: 2010-02-10 22:41:25.310078Z
    test: sample1.sampletests_ntd.Layer:tearDown
    tags: zope:layer
    time: 2010-02-10 22:41:25.310171Z
    skip: sample1.sampletests_ntd.Layer:tearDown [
    tearDown not supported
    ]
    test: Running in a subprocess.
    tags: zope:info_suboptimal
    successful: Running in a subprocess.
    time: 2010-02-10 22:41:25.753076Z
    test: sample2.sampletests_ntd.Layer:setUp
    tags: zope:layer
    time: 2010-02-10 22:41:25.753079Z
    successful: sample2.sampletests_ntd.Layer:setUp
    tags: zope:layer:sample2.sampletests_ntd.Layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample2.sampletests_ntd.TestSomething.test_something
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: sample2.sampletests_ntd.TestSomething.test_something
    tags: -zope:layer:sample2.sampletests_ntd.Layer
    time: 2010-02-10 22:41:25.779256Z
    test: sample2.sampletests_ntd.Layer:tearDown
    tags: zope:layer
    time: 2010-02-10 22:41:25.779326Z
    skip: sample2.sampletests_ntd.Layer:tearDown [
    tearDown not supported
    ]
    test: Running in a subprocess.
    tags: zope:info_suboptimal
    successful: Running in a subprocess.
    time: 2010-02-10 22:41:26.310296Z
    test: sample3.sampletests_ntd.Layer:setUp
    tags: zope:layer
    time: 2010-02-10 22:41:26.310299Z
    successful: sample3.sampletests_ntd.Layer:setUp
    tags: zope:layer:sample3.sampletests_ntd.Layer
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample3.sampletests_ntd.TestSomething.test_error1
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    error: sample3.sampletests_ntd.TestSomething.test_error1 [ multipart
    Content-Type: text/x-traceback...
    traceback
    16A\r
    <BLANKLINE>
    Traceback (most recent call last):
      File "/usr/lib/python3.11/unittest.py", line 305, in debug
        getattr(self, self._testMethodName)()
      File "/home/jml/src/zope.testrunner/subunit-output-formatter/src/zope/testing/testrunner/testrunner-ex/sample3/sampletests_ntd.py", line 42, in test_error1
        raise TypeError("Can we see errors")
    TypeError: Can we see errors
    0\r
    <BLANKLINE>
    ]
    test: Can't post-mortem debug when running a layer as a subprocess!
    tags: zope:error_with_banner
    successful: Can't post-mortem debug when running a layer as a subprocess!
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample3.sampletests_ntd.TestSomething.test_error2
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    error: sample3.sampletests_ntd.TestSomething.test_error2 [ multipart
    Content-Type: text/x-traceback...
    traceback
    15A\r
    <BLANKLINE>
    Traceback (most recent call last):
      File "/usr/lib/python3.11/unittest.py", line 305, in debug
        getattr(self, self._testMethodName)()
      File "/home/jml/src/zope.testrunner/subunit-output-formatter/src/zope/testing/testrunner/testrunner-ex/sample3/sampletests_ntd.py", line 45, in test_error2
        raise TypeError("I hope so")
    TypeError: I hope so
    0\r
    <BLANKLINE>
    ]
    test: Can't post-mortem debug when running a layer as a subprocess!
    tags: zope:error_with_banner
    successful: Can't post-mortem debug when running a layer as a subprocess!
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample3.sampletests_ntd.TestSomething.test_fail1
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    error: sample3.sampletests_ntd.TestSomething.test_fail1 [ multipart
    Content-Type: text/x-traceback...
    traceback
    1C5\r
    <BLANKLINE>
    Traceback (most recent call last):
      File "/usr/lib/python3.11/unittest.py", line 305, in debug
        getattr(self, self._testMethodName)()
      File "/home/jml/src/zope.testrunner/subunit-output-formatter/src/zope/testing/testrunner/testrunner-ex/sample3/sampletests_ntd.py", line 48, in test_fail1
        self.assertEqual(1, 2)
      File "/usr/lib/python3.11/unittest.py", line 350, in failUnlessEqual
        (msg or '%r != %r' % (first, second))
    AssertionError: 1 != 2
    0\r
    <BLANKLINE>
    ]
    test: Can't post-mortem debug when running a layer as a subprocess!
    tags: zope:error_with_banner
    successful: Can't post-mortem debug when running a layer as a subprocess!
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample3.sampletests_ntd.TestSomething.test_fail2
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    error: sample3.sampletests_ntd.TestSomething.test_fail2 [ multipart
    Content-Type: text/x-traceback...
    traceback
    1C5\r
    <BLANKLINE>
    Traceback (most recent call last):
      File "/usr/lib/python3.11/unittest.py", line 305, in debug
        getattr(self, self._testMethodName)()
      File "/home/jml/src/zope.testrunner/subunit-output-formatter/src/zope/testing/testrunner/testrunner-ex/sample3/sampletests_ntd.py", line 51, in test_fail2
        self.assertEqual(1, 3)
      File "/usr/lib/python3.11/unittest.py", line 350, in failUnlessEqual
        (msg or '%r != %r' % (first, second))
    AssertionError: 1 != 3
    0\r
    <BLANKLINE>
    ]
    test: Can't post-mortem debug when running a layer as a subprocess!
    tags: zope:error_with_banner
    successful: Can't post-mortem debug when running a layer as a subprocess!
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample3.sampletests_ntd.TestSomething.test_something
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: sample3.sampletests_ntd.TestSomething.test_something
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    test: sample3.sampletests_ntd.TestSomething.test_something_else
    time: YYYY-MM-DD HH:MM:SS.mmmmmmZ
    successful: sample3.sampletests_ntd.TestSomething.test_something_else
    tags: -zope:layer:sample3.sampletests_ntd.Layer
    time: 2010-02-10 22:41:26.340878Z
    test: sample3.sampletests_ntd.Layer:tearDown
    tags: zope:layer
    time: 2010-02-10 22:41:26.340945Z
    skip: sample3.sampletests_ntd.Layer:tearDown [
    tearDown not supported
    ]
    True


Support skipped tests
---------------------

    >>> directory_with_skipped_tests = os.path.join(this_directory,
    ...                                             'testrunner-ex-skip')
    >>> skip_defaults = [
    ...     '--path', directory_with_skipped_tests,
    ...     '--tests-pattern', '^sample_skipped_tests$',
    ...  ]
    >>> sys.argv = ['test']
    >>> testrunner.run_internal(
    ...     skip_defaults + ["--subunit", "-t", "TestSkipppedNoLayer"])
    time: ...
    test: zope.testrunner.layer.UnitTests:setUp
    tags: zope:layer
    time: ...
    successful: zope.testrunner.layer.UnitTests:setUp
    tags: zope:layer:zope.testrunner.layer.UnitTests
    time: ...
    test: sample_skipped_tests.TestSkipppedNoLayer.test_skipped
    skip: sample_skipped_tests.TestSkipppedNoLayer.test_skipped [
    I'm a skipped test!
    ]
    tags: -zope:layer:zope.testrunner.layer.UnitTests
    time: ...
    test: zope.testrunner.layer.UnitTests:tearDown
    tags: zope:layer
    time: ...
    successful: zope.testrunner.layer.UnitTests:tearDown
    False
