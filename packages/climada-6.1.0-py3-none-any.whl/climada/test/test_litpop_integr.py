"""
This file is part of CLIMADA.

Copyright (C) 2017 ETH Zurich, CLIMADA contributors listed in AUTHORS.

CLIMADA is free software: you can redistribute it and/or modify it under the
terms of the GNU General Public License as published by the Free
Software Foundation, version 3.

CLIMADA is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with CLIMADA. If not, see <https://www.gnu.org/licenses/>.

---

Tests on LitPop exposures.
"""

import unittest

import numpy as np
from rasterio import Affine
from rasterio.crs import CRS
from shapely.geometry import Polygon

import climada.util.coordinates as u_coord
from climada import CONFIG
from climada.entity.exposures.litpop import gpw_population
from climada.entity.exposures.litpop import litpop as lp
from climada.util.constants import SYSTEM_DIR
from climada.util.finance import gdp, income_group, world_bank_wealth_account

bounds = (8.41, 47.2, 8.70, 47.45)  # (min_lon, max_lon, min_lat, max_lat)
shape = Polygon(
    [
        (bounds[0], bounds[3]),
        (bounds[2], bounds[3]),
        (bounds[2], bounds[1]),
        (bounds[0], bounds[1]),
    ]
)


class TestLitPopExposures(unittest.TestCase):
    """Test LitPop exposure data model:"""

    def test_netherlands150_pass(self):
        """Test from_countries for Netherlands at 150 arcsec, first shape is empty"""
        ent = lp.LitPop.from_countries(
            "Netherlands", res_arcsec=150, reference_year=2016
        )
        self.assertEqual(ent.gdf.shape[0], 2829)

    def test_BLM150_pass(self):
        """Test from_countries for BLM at 150 arcsec, 2 data points
        The world bank doesn't provide data for Saint Barthélemy, fall back to natearth
        """
        ent = lp.LitPop.from_countries("BLM", res_arcsec=150, reference_year=2016)
        self.assertEqual(ent.gdf.shape[0], 2)

    def test_Monaco150_pass(self):
        """Test from_countries for Moncao at 150 arcsec, 1 data point"""
        ent = lp.LitPop.from_countries("Monaco", res_arcsec=150, reference_year=2016)
        self.assertEqual(ent.gdf.shape[0], 1)

    def test_switzerland300_pass(self):
        """Create LitPop entity for Switzerland on 300 arcsec:"""
        country_name = ["CHE"]
        resolution = 300
        fin_mode = "income_group"
        with self.assertLogs("climada.entity.exposures.litpop", level="INFO") as cm:
            ent = lp.LitPop.from_countries(
                country_name,
                res_arcsec=resolution,
                fin_mode=fin_mode,
                reference_year=2016,
            )

        self.assertIn("LitPop: Init Exposure for country: CHE", cm.output[0])
        self.assertEqual(ent.region_id.min(), 756)
        self.assertEqual(ent.region_id.max(), 756)
        # confirm that the total value is equal to GDP * (income_group+1):
        self.assertAlmostEqual(
            ent.gdf["value"].sum() / gdp("CHE", 2016)[1],
            (income_group("CHE", 2016)[1] + 1),
        )
        self.assertIn(
            "LitPop Exposure for ['CHE'] at 300 as, year: 2016", ent.description
        )
        self.assertIn("income_group", ent.description)
        self.assertIn("1, 1", ent.description)
        self.assertTrue(u_coord.equal_crs(ent.crs, "epsg:4326"))
        self.assertEqual(ent.meta["width"], 54)
        self.assertEqual(ent.meta["height"], 23)
        self.assertTrue(u_coord.equal_crs(ent.meta["crs"], "epsg:4326"))
        self.assertAlmostEqual(ent.meta["transform"][0], 0.08333333333333333)
        self.assertAlmostEqual(ent.meta["transform"][1], 0)
        self.assertAlmostEqual(ent.meta["transform"][2], 5.91666666666666666)
        self.assertAlmostEqual(ent.meta["transform"][3], 0)
        self.assertAlmostEqual(ent.meta["transform"][4], 0.08333333333333333)
        self.assertAlmostEqual(ent.meta["transform"][5], 45.8333333333333333)

    def test_switzerland30normPop_pass(self):
        """Create LitPop entity for Switzerland on 30 arcsec:"""
        country_name = ["CHE"]
        resolution = 30
        exp = [0, 1]
        fin_mode = "norm"
        with self.assertLogs("climada.entity.exposures.litpop", level="INFO") as cm:
            ent = lp.LitPop.from_countries(
                country_name,
                res_arcsec=resolution,
                exponents=exp,
                fin_mode=fin_mode,
                reference_year=2015,
            )
        self.assertIn("LitPop: Init Exposure for country: CHE", cm.output[0])
        self.assertEqual(ent.region_id.min(), 756)
        self.assertEqual(ent.region_id.max(), 756)
        self.assertEqual(ent.value.sum(), 1.0)
        self.assertEqual(ent.ref_year, 2015)

    def test_suriname30_nfw_pass(self):
        """Create LitPop entity for Suriname for non-finanical wealth in 2016:"""
        country_name = ["SUR"]
        fin_mode = "nfw"
        ent = lp.LitPop.from_countries(
            country_name, reference_year=2016, fin_mode=fin_mode
        )

        self.assertEqual(ent.region_id.min(), 740)
        self.assertEqual(ent.region_id.max(), 740)
        self.assertEqual(ent.ref_year, 2016)

    def test_switzerland300_admin1_pc2016_pass(self):
        """Create LitPop entity for Switzerland 2016 with admin1 and produced capital:"""
        country_name = ["CHE"]
        fin_mode = "pc"
        resolution = 300
        ref_year = 2016
        adm1 = True
        comparison_total_val = world_bank_wealth_account(
            country_name[0], ref_year, no_land=1
        )[1]
        ent = lp.LitPop.from_countries(
            country_name,
            res_arcsec=resolution,
            reference_year=ref_year,
            fin_mode=fin_mode,
            admin1_calc=adm1,
        )

        self.assertAlmostEqual(
            np.around(ent.gdf["value"].sum() * 1e-9, 0),
            np.around(comparison_total_val * 1e-9, 0),
            places=0,
        )
        self.assertEqual(ent.value_unit, "USD")

    def test_from_shape_zurich_pass(self):
        """test initiating LitPop for custom shape (square around Zurich City)
        Distributing an imaginary total value of 1000 USD"""
        total_value = 1000
        ent = lp.LitPop.from_shape(
            shape, total_value, res_arcsec=30, reference_year=2016
        )
        self.assertAlmostEqual(ent.value.sum(), 1000.0)
        self.assertEqual(ent.value.min(), 0.0)
        self.assertAlmostEqual(ent.value.max(), 5.058, places=4)
        self.assertEqual(ent.region_id.min(), 756)
        self.assertEqual(ent.region_id.max(), 756)
        self.assertAlmostEqual(ent.latitude.min(), 47.2 + 15 / 3600)
        # index and coord. of largest value:
        self.assertEqual(
            ent.gdf.loc[ent.gdf["value"] == ent.gdf["value"].max()].index[0], 434
        )
        self.assertAlmostEqual(
            ent.gdf.loc[ent.gdf["value"] == ent.gdf["value"].max()].geometry.y.values[
                0
            ],
            5681.5 * 30 / 3600,
        )
        self.assertAlmostEqual(
            ent.gdf.loc[ent.gdf["value"] == ent.gdf["value"].max()].geometry.x.values[
                0
            ],
            1023.5 * 30 / 3600,
        )

    def test_from_shape_and_countries_zurich_pass(self):
        """test initiating LitPop for custom shape (square around Zurich City)
        with from_shape_and_countries()"""

        ent = lp.LitPop.from_shape_and_countries(
            shape, "Switzerland", res_arcsec=30, reference_year=2016
        )
        self.assertEqual(ent.value.min(), 0.0)
        self.assertEqual(ent.region_id.min(), 756)
        self.assertEqual(ent.region_id.max(), 756)
        self.assertAlmostEqual(ent.latitude.min(), 47.20416666666661)
        # coord of largest value:
        self.assertEqual(
            ent.gdf.loc[ent.gdf.value == ent.gdf.value.max()].index[0], 434
        )
        self.assertAlmostEqual(
            ent.gdf.loc[ent.gdf["value"] == ent.gdf["value"].max()].geometry.y.values[
                0
            ],
            47.34583333333325,
        )
        self.assertAlmostEqual(
            ent.gdf.loc[ent.gdf["value"] == ent.gdf["value"].max()].geometry.x.values[
                0
            ],
            8.529166666666658,
        )

    def test_Liechtenstein_15_lit_pass(self):
        """Create Nightlights entity for Liechtenstein 2016:"""
        country_name = "Liechtenstein"
        ref_year = 2016
        ent = lp.LitPop.from_nightlight_intensity(country_name, reference_year=ref_year)

        self.assertAlmostEqual(ent.value.sum(), 36469.0)
        self.assertEqual(ent.region_id[1], 438)
        self.assertEqual(ent.value_unit, "")
        self.assertAlmostEqual(ent.latitude.max(), 47.260416666666664)
        self.assertAlmostEqual(ent.meta["transform"][4], 15 / 3600)

    def test_Liechtenstein_30_pop_pass(self):
        """Create population count entity for Liechtenstein 2015:"""
        country_name = "Liechtenstein"
        ref_year = 2015
        ent = lp.LitPop.from_population(country_name, reference_year=ref_year)

        self.assertEqual(ent.value.sum(), 30068.970703125)
        self.assertEqual(ent.region_id[1], 438)
        self.assertEqual(ent.value_unit, "people")
        self.assertAlmostEqual(ent.latitude.max(), 47.2541666666666)
        self.assertAlmostEqual(ent.meta["transform"][0], 30 / 3600)

    def test_from_nightlight_intensity(self):
        """Test raises, logger and if methods from_countries and from_shape are
        are used."""

        with self.assertRaises(ValueError) as cm:
            lp.LitPop.from_nightlight_intensity()
        self.assertEqual(
            "Either `countries` or `shape` required. Aborting.", str(cm.exception)
        )

        with self.assertRaises(ValueError) as cm:
            lp.LitPop.from_nightlight_intensity(countries="Liechtenstein", shape=shape)
        self.assertEqual(
            "Not allowed to set both `countries` and `shape`. Aborting.",
            str(cm.exception),
        )

        exp = lp.LitPop.from_nightlight_intensity(countries="Liechtenstein")
        self.assertEqual(exp.fin_mode, "none")

        exp = lp.LitPop.from_nightlight_intensity(shape=shape)
        self.assertEqual(exp.value_unit, "")

        with self.assertLogs(
            "climada.entity.exposures.litpop.litpop", level="WARNING"
        ) as cm:
            lp.LitPop.from_nightlight_intensity(shape=shape)
        self.assertIn(
            "Note: set_nightlight_intensity sets values to raw nightlight intensity,",
            cm.output[0],
        )

    def test_from_population(self):
        """Test raises, logger and if methods from_countries and from_shape are
        are used."""

        with self.assertRaises(ValueError) as cm:
            lp.LitPop.from_population()
        self.assertEqual(
            "Either `countries` or `shape` required. Aborting.", str(cm.exception)
        )

        exp = lp.LitPop.from_population(countries="Liechtenstein")
        self.assertEqual(exp.fin_mode, "pop")

        exp = lp.LitPop.from_population(shape=shape)
        self.assertEqual(exp.value_unit, "people")

        with self.assertRaises(ValueError) as cm:
            lp.LitPop.from_population(countries="Liechtenstein", shape=shape)
        self.assertEqual(
            "Not allowed to set both `countries` and `shape`. Aborting.",
            str(cm.exception),
        )


class TestAdmin1(unittest.TestCase):
    """Test the admin1 functionalities within the LitPop module"""

    def test_from_countries_calc_admin1_pass(self):
        """test method from_countries with admin1_calc=True for Switzerland"""
        country = "Switzerland"
        resolution = 90
        fin_mode = "gdp"

        ent = lp.LitPop.from_countries(
            country,
            res_arcsec=resolution,
            fin_mode=fin_mode,
            reference_year=2016,
            admin1_calc=True,
        )
        ent_adm0 = lp.LitPop.from_countries(
            country,
            res_arcsec=resolution,
            fin_mode=fin_mode,
            reference_year=2016,
            admin1_calc=False,
        )
        # shape must be same as with admin1_calc = False, otherwise there
        # is a problem with handling of the admin1 shapes:
        self.assertEqual(ent.gdf.shape[0], 7800)
        self.assertEqual(ent.gdf.shape[0], ent_adm0.gdf.shape[0])

    def test_calc_admin1(self):
        """test function _calc_admin1_one_country for Switzerland."""
        resolution = 300
        country = "CHE"
        ent = lp._calc_admin1_one_country(
            country,
            resolution,
            exponents=(2, 1),
            fin_mode="pc",
            total_value=None,
            reference_year=2016,
            gpw_version=lp.GPW_VERSION,
            data_dir=SYSTEM_DIR,
            target_grid=None,
        )

        self.assertEqual(ent.gdf.shape[0], 699)
        self.assertEqual(ent.region_id[88], 756)
        self.assertAlmostEqual(ent.latitude.max(), 47.708333333333336)
        # shape must be same as with admin1_calc = False, otherwise there
        # is a problem with handling of the admin1 shapes:
        ent_adm0 = lp.LitPop.from_countries(
            country,
            res_arcsec=resolution,
            fin_mode="pc",
            reference_year=2016,
            admin1_calc=False,
        )
        self.assertEqual(ent.gdf.shape[0], ent_adm0.gdf.shape[0])

    def test_brandenburg(self):
        """test functions from_shape_and_countries and from_shape
        for admin1 shape of Brandenburg"""
        reslution_arcsec = 120
        country = "DEU"
        state_name = "Brandenburg"
        # get the shape of Brandenburg:
        admin1_info, admin1_shapes = u_coord.get_admin1_info(country)
        admin1_info = admin1_info[country]
        admin1_shapes = admin1_shapes[country]
        admin1_names = [record["name"] for record in admin1_info]

        idx = next(
            idx
            for idx, _name in enumerate(admin1_names)
            if admin1_names[idx] == state_name
        )
        self.assertEqual(idx, 8)

        # init LitPop for Brandenburg
        exp_bra2 = lp.LitPop.from_shape_and_countries(
            admin1_shapes[idx],
            country,
            res_arcsec=reslution_arcsec,
            reference_year=2016,
        )
        exp_bra = lp.LitPop.from_shape(
            admin1_shapes[idx], 1000, res_arcsec=reslution_arcsec, reference_year=2016
        )
        self.assertAlmostEqual(exp_bra.gdf["value"].sum(), 1000)
        # compare number of data points:
        self.assertEqual(exp_bra.gdf.shape[0], exp_bra2.gdf.shape[0])
        self.assertEqual(exp_bra.gdf.shape[0], 3566)
        # check for double entries:
        self.assertEqual(len(exp_bra.gdf.geometry.unique()), len(exp_bra.gdf.geometry))
        self.assertEqual(len(exp_bra.gdf.geometry.unique()), 3566)


class TestGPWPopulation(unittest.TestCase):
    """Test gpw_population submodule"""

    def test_get_gpw_file_path_pass(self):
        """test method gpw_population.get_gpw_file_path"""
        gpw_version = CONFIG.exposures.litpop.gpw_population.gpw_version.int()
        try:
            path = gpw_population.get_gpw_file_path(gpw_version, 2020, verbose=False)
            self.assertIn("gpw_v4_population", str(path))
        except FileExistsError as err:
            self.assertIn("lease download", err.args[0])
            # pylint: disable=consider-using-f-string
            self.skipTest("GPW input data for GPW v4.%i not found." % (gpw_version))

    def test_load_gpw_pop_shape_pass(self):
        """test method gpw_population.load_gpw_pop_shape"""
        gpw_version = CONFIG.exposures.litpop.gpw_population.gpw_version.int()
        try:
            data, meta, glb_transform = gpw_population.load_gpw_pop_shape(
                shape, 2020, gpw_version, verbose=False
            )
            self.assertEqual(data.shape, (31, 36))
            self.assertAlmostEqual(meta["transform"][0], 0.00833333333333333)
            self.assertAlmostEqual(meta["transform"][0], glb_transform[0])
            self.assertEqual(meta["driver"], "GTiff")
            self.assertEqual(meta["height"], data.shape[0])
            self.assertEqual(meta["width"], data.shape[1])
            self.assertIsInstance(data, np.ndarray)
            self.assertEqual(len(data.shape), 2)
        except FileExistsError as err:
            self.assertIn("lease download", err.args[0])
            # pylint: disable=consider-using-f-string
            self.skipTest("GPW input data for GPW v4.%i not found." % (gpw_version))


class TestLitPopGridAlignment(unittest.TestCase):
    """Test grid alignment, geometry validity, and expected structure in LitPop."""

    @classmethod
    def setUpClass(cls):
        """Set up common test parameters."""
        # Define the target resolution in degrees (150 arcseconds = 0.0416667°)
        target_res_deg = 150 / 3600  # Convert arcseconds to degrees (0.0416667°)

        # Ensure the grid is aligned exactly at half-cell positions
        aligned_lon_min = -180 + (target_res_deg / 2)  # Shift half a cell right
        aligned_lat_max = 90 - (target_res_deg / 2)  # Shift half a cell down
        # Compute grid width & height
        width = int(360 / target_res_deg)  # 360° longitude range
        height = int(180 / target_res_deg)  # 180° latitude range

        # Define the affine transform for the target grid
        transform = Affine(
            target_res_deg,
            0,
            aligned_lon_min,  # X resolution, rotation, X origin
            0,
            -target_res_deg,
            aligned_lat_max,  # Y rotation, Y resolution (negative),
            # Y origin
        )

        # Define the target grid metadata
        cls.target_grid = {
            "driver": "GTiff",
            "width": width,
            "height": height,
            "count": 1,  # Assuming a single-band raster
            "crs": CRS.from_epsg(4326),  # WGS84 (Lat/Lon)
            "transform": transform,
        }

        cls.test_countries = ["JPN", "TGO"]
        cls.test_shape = Polygon([(-10, -10), (10, -10), (10, 10), (-10, 10)])
        cls.test_total_value = 1e6
        cls.test_year = 2020

        # Define test cases with correct resolution
        cls.test_cases = [
            ("from_countries", {"countries": cls.test_countries, "res_arcsec": 30}),
            (
                "from_nightlight_intensity",
                {"countries": cls.test_countries, "res_arcsec": 30},
            ),
            ("from_population", {"countries": cls.test_countries, "res_arcsec": 30}),
            (
                "from_shape_and_countries",
                {
                    "shape": cls.test_shape,
                    "countries": cls.test_countries,
                    "res_arcsec": 30,
                },
            ),
            (
                "from_shape",
                {
                    "shape": cls.test_shape,
                    "total_value": cls.test_total_value,
                    "res_arcsec": 30,
                },
            ),
        ]

    def check_exposure_geometry(self, exp, method_name):
        """Validate that the exposure data points align correctly to the expected grid."""

        # Ensure exposure data exists
        self.assertIsNotNone(exp, f"{method_name} returned None")
        self.assertFalse(exp.gdf.empty, f"GeoDataFrame is empty in {method_name}!")

        # Extract coordinates from exposure dataset
        latitudes = exp.gdf.geometry.y
        longitudes = exp.gdf.geometry.x

        # Define the target resolution in degrees (150 arcseconds = 0.0416667°)
        target_res_deg = 150 / 3600  # Convert arcseconds to degrees (0.0416667°)

        # Ensure the grid is aligned exactly at half-cell positions
        aligned_lon_min = -180  # Shift half a cell right
        aligned_lat_max = 90
        # Compute expected alignment positions
        expected_lons = np.arange(
            aligned_lon_min, aligned_lon_min + 360, target_res_deg
        )
        expected_lats = np.arange(
            aligned_lat_max - 180, aligned_lat_max, target_res_deg
        )
        # Check that all longitudes and latitudes align to expected values
        self.assertTrue(
            np.all(np.isin(np.round(longitudes, 6), np.round(expected_lons, 6))),
            f"Longitude coordinates are not aligned to the expected grid in {method_name}!",
        )
        self.assertTrue(
            np.all(np.isin(np.round(latitudes, 6), np.round(expected_lats, 6))),
            f"Latitude coordinates are not aligned to the expected grid in {method_name}!",
        )

    def test_litpop_grid_alignment(self):
        """Loop through LitPop methods and validate grid alignment."""
        for method_name, kwargs in self.test_cases:
            with self.subTest(method=method_name):
                exp = getattr(lp.LitPop, method_name)(
                    **kwargs, target_grid=self.target_grid
                )
                self.check_exposure_geometry(exp, method_name)

    def test_litpop_grid_consistency(self):
        """Ensure total exposure values and dataset lengths remain consistent across different grid
        configurations."""

        country = "FRA"  # Example country, adjust as needed
        default_res = 30  # Default resolution in arcseconds
        test_res = 150  # Test resolution in arcseconds (5x coarser)

        # Compute exposure with different configurations
        # Default settings (30 arcseconds):
        exp_default = lp.LitPop.from_countries([country])
        # Using specified resolution (150 arcseconds):
        exp_res = lp.LitPop.from_countries([country], res_arcsec=test_res)
        # Using target grid:
        exp_grid = lp.LitPop.from_countries([country], target_grid=self.target_grid)

        # Extract total exposure values
        sum_default = exp_default.gdf["value"].sum()
        sum_res = exp_res.gdf["value"].sum()
        sum_grid = exp_grid.gdf["value"].sum()

        # Extract dataset lengths (number of grid points)
        len_default = len(exp_default.gdf)
        len_res = len(exp_res.gdf)
        len_grid = len(exp_grid.gdf)

        # Allow for a 10% difference in total exposure values
        tolerance = 0.1 * sum_default  # 10% of default value

        # Check that the total exposure values are within tolerance
        self.assertAlmostEqual(
            sum_res,
            sum_default,
            delta=tolerance,
            msg="Exposure sum differs by more than 10% when using resolution.",
        )
        self.assertAlmostEqual(
            sum_grid,
            sum_default,
            delta=tolerance,
            msg="Exposure sum differs by more than 10% when using a target grid.",
        )

        # Check that the number of grid points is similar when using the same resolution
        self.assertAlmostEqual(
            len_res,
            len_grid,
            delta=0.05 * len_res,
            msg="Dataset lengths differ significantly between resolution and target grid.",
        )


if __name__ == "__main__":
    TESTS = unittest.TestLoader().loadTestsFromTestCase(TestLitPopExposures)
    TESTS.addTests(unittest.TestLoader().loadTestsFromTestCase(TestAdmin1))
    TESTS.addTests(unittest.TestLoader().loadTestsFromTestCase(TestGPWPopulation))
    TESTS.addTests(unittest.TestLoader().loadTestsFromTestCase(TestLitPopGridAlignment))
    unittest.TextTestRunner(verbosity=2).run(TESTS)
