"""
This file is part of CLIMADA.

Copyright (C) 2017 ETH Zurich, CLIMADA contributors listed in AUTHORS.

CLIMADA is free software: you can redistribute it and/or modify it under the
terms of the GNU General Public License as published by the Free
Software Foundation, version 3.

CLIMADA is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with CLIMADA. If not, see <https://www.gnu.org/licenses/>.

---
Impact function calibration module
"""

from .base import Input, OutputEvaluator
from .bayesian_optimizer import (
    BayesianOptimizer,
    BayesianOptimizerController,
    BayesianOptimizerOutput,
    BayesianOptimizerOutputEvaluator,
    select_best,
)
from .cost_func import mse, msle
from .ensemble import (
    AverageEnsembleOptimizer,
    EnsembleOptimizerOutput,
    TragedyEnsembleOptimizer,
)
from .scipy_optimizer import ScipyMinimizeOptimizer
