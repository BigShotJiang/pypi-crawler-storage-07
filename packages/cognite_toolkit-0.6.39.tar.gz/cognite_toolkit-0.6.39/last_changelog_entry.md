## cdf 

### Added

- Support dumping instance spaces, `cdf dump spaces`.

## templates

No changes.