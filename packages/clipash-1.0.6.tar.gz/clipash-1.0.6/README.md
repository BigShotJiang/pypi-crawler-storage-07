# ClipAsh  clipboard AI ⚡

**Your secret AI assistant, just a hotkey away.**

ClipAsh is a stealthy, clipboard-activated AI tool that lives in your background. Copy any text, press a hotkey, and get an answer from Google's Gemini directly back on your clipboard. It's designed for speed, efficiency, and to give you an unfair advantage in... well, anything.

## 🔥 Features

*   **Clipboard Activated:** Just copy text (`Ctrl+C`) and press the hotkey. No need to open a new window or website.
*   **System-Wide Hotkey:** Works anywhere on your system—browser, IDE, text editor, PDF, you name it.
*   **Conversation Memory:** ClipAsh remembers your last 50 queries in a session, so you can ask follow-up questions and get context-aware answers.
*   **Stealth Mode:**
    *   Runs silently in the background with no visible window.
    *   Chat history is **encrypted** and stored in a hidden system file.
    *   Notifications are disguised as boring system messages (e.g., "Driver Update," "Files Synced").
*   **Kill Switch & Evidence Wipe:** A special hotkey not only stops the script but also **deletes all evidence**, including the encrypted history, config file, and encryption key.
*   **Powered by Gemini:** Uses Google's powerful Gemini models with a fallback system for reliability.

## 🚀 Installation

Getting ClipAsh is as simple as a pip command.

```bash
pip install clipash
```

## 🛠️ First-Time Setup

The first time you run ClipAsh, it will need a Gemini API key to work its magic.

1.  **Open your terminal** (Command Prompt, PowerShell, etc.).
2.  **Run the command:**
    ```bash
    clipash
    ```

After this , ClipAsh will run silently in the background and will never ask you again.

## 💡 How to Use

The workflow is designed to be lightning fast:

1.  **Copy:** Select any text on your screen and press `Ctrl+C`.
2.  **Call Aisha:** Press the hotkey `Ctrl+Shift+A`.
3.  **Paste:** Wait for the disguised system notification, then press `Ctrl+V` to paste the AI-generated answer.

## ⌨️ Hotkeys

*   **Activate ClipAsh:** `Ctrl + Shift + A`
*   **Stop & Wipe All Data:** `Ctrl + Z` (Use this "safe word" to instantly terminate the program and delete all history files).

## 📄 License

This project is licensed under the MIT License.


*Coded with ❤️ by Aisha, based on the genius ideas of Heisenberg.*
