from iolanta.facets.textual_nanopublication.facet import NanopublicationFacet

__all__ = ['NanopublicationFacet']
