

class PeripheralsManager:
    pass