# GeoBot SDK

Python SDK для управления роверами Geoscan GeoBot.

## Установка
через uv
```bash
uv add geobot-sdk
```
или через pip
```bash
pip install geobot-sdk
```
## Документация
Полная документация с примерами использования находится тут[link].

## Разработка
Для разработки и контрибьютинга смотрите CONTRIBUTING.md


## Лицензия
Проект распространяется под лицензией MIT.