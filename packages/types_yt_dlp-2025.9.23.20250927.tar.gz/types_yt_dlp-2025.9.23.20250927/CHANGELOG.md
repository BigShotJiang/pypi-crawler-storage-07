## 2025.9.23.20250927 (2025-09-27)

[yt-dlp] Use Final ([#14788](https://github.com/python/typeshed/pull/14788))

## 2025.9.23.20250925 (2025-09-25)

[yt-dlp] Update to 2025.9.23 ([#14776](https://github.com/python/typeshed/pull/14776))

## 2025.9.5.20250907 (2025-09-07)

[yt-dlp] Update to 2025.9.5 ([#14681](https://github.com/python/typeshed/pull/14681))

## 2025.8.27.20250829 (2025-08-29)

[stubsabot] Bump yt-dlp to 2025.8.27 ([#14654](https://github.com/python/typeshed/pull/14654))

## 2025.8.22.20250824 (2025-08-24)

[stubsabot] Bump yt-dlp to 2025.8.22 ([#14629](https://github.com/python/typeshed/pull/14629))

Release: https://pypi.org/pypi/yt-dlp/2025.8.22
Repository: https://github.com/yt-dlp/yt-dlp
Typeshed stubs: https://github.com/python/typeshed/tree/main/stubs/yt-dlp
Diff: https://github.com/yt-dlp/yt-dlp/compare/2025.08.20...2025.08.22

Stubsabot analysis of the diff between the two releases:
 - 0 public Python files have been added.
 - 0 files included in typeshed's stubs have been deleted.
 - 2 files included in typeshed's stubs have been modified or renamed: `yt_dlp/cookies.py`, `yt_dlp/version.py`.
 - Total lines of Python code added: 188.
 - Total lines of Python code deleted: 179.

If stubtest fails for this PR:
- Leave this PR open (as a reminder, and to prevent stubsabot from opening another PR)
- Fix stubtest failures in another PR, then close this PR

Note that you will need to close and re-open the PR in order to trigger CI

Co-authored-by: stubsabot <>

## 2025.8.20.20250822 (2025-08-22)

Add missing defaults to third-party stubs ([#14617](https://github.com/python/typeshed/pull/14617))

[yt-dlp] Update to 2025.8.20 ([#14609](https://github.com/python/typeshed/pull/14609))

## 2025.8.11.20250813 (2025-08-13)

[yt-dlp] Update to 2025.8.11 ([#14564](https://github.com/python/typeshed/pull/14564))

## 2025.7.21.20250728 (2025-07-28)

Fully annotate `yt-dlp` (#14481)

## 2025.7.21.20250727 (2025-07-27)

Add yt-dlp stubs (#14216)

