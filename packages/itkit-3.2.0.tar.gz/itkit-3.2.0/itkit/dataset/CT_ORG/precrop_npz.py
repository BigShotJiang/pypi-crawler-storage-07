from itkit.process.PreCrop_3D import StandardMhaCropper3D

if __name__ == '__main__':
    StandardMhaCropper3D()