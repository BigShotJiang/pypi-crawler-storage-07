CLASS_INDEX_MAP = {
    'background': 0,
    'liver': 1,
    'bladder': 2,
    'lungs': 3,
    'kidneys': 4,
    'bone': 5,
    # 'brain': 6,
}