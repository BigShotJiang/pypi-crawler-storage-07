from itkit.process.PreCrop_3D import SemiSupervisedMhaCropper3D

if __name__ == '__main__':
    SemiSupervisedMhaCropper3D()