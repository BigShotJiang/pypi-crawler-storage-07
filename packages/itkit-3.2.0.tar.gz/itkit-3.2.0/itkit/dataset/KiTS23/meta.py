CLASS_INDEX_MAP = {
    'background': 0,
    'Kidney': 1,    # 肾脏
    'Tumor': 2,     # 肿瘤
    'Cyst': 3,      # 囊肿
}