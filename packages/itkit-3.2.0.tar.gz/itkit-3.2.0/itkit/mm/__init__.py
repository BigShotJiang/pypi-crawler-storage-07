import os

MM_WORK_DIR_ROOT = os.environ.get('mm_workdir', None)
MM_TEST_DIR_ROOT = os.environ.get('mm_testdir', None)
MM_CONFIG_ROOT = os.environ.get('mm_configdir', None)
