"""The mellea standard library."""
