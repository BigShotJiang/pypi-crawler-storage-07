"""Tests package for awsquery."""
