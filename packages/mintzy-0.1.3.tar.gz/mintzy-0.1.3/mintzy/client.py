
# mintzy/client.py
import requests

class Client:
    # Define valid keys (for soft protection)
    VALID_KEYS = {"XYZ123", "ABC456", "CLIENT789"}

    def __init__(self, api_key, base_url="http://34.172.210.29/predict"):
        self.base_url = base_url
        self.api_key = api_key

    def _check_key(self):
        return self.api_key in self.VALID_KEYS

    def get_prediction(self, tickers, time_frame, parameters):
        if not self._check_key():
            return {"success": False, "error": "Unauthorized: Invalid API key"}

        # Ensure tickers is a list and max 3 allowed
        if isinstance(tickers, str):
            tickers = [tickers]
        if not isinstance(tickers, list):
            return {"success": False, "error": "Tickers must be a string or list"}
        if len(tickers) > 3:
            return {"success": False, "error": "Maximum of 3 tickers allowed"}

        # Ensure parameters is a list
        if isinstance(parameters, str):
            parameters = [parameters]

        payload = {
            "action": {
                "action_type": "predict",
                "predict": {
                    "given": {"ticker": tickers, "time_frame": time_frame},
                    "required": {"parameters": parameters}
                }
            }
        }

        try:
            response = requests.post(
                self.base_url,
                json=payload,
                headers={"X-API-Key": self.api_key},
                timeout=30
            )
            response.raise_for_status()
            return {"success": True, "data": response.json()}

        except requests.exceptions.HTTPError as e:
            return {"success": False, "error": "Server error occurred, please try again later"}
        except requests.exceptions.Timeout:
            return {"success": False, "error": "Request timed out, please try again"}
        except requests.exceptions.ConnectionError:
            return {"success": False, "error": "Failed to connect to server"}
        except Exception:
            return {"success": False, "error": "Unexpected error occurred"}

    def batch_predict(self, tickers, time_frame, parameters=None):
        if not self._check_key():
            return [{"success": False, "error": "Unauthorized: Invalid API key", "ticker": t} for t in tickers]

        if len(tickers) > 3:
            return [{"success": False, "error": "Maximum of 3 tickers allowed", "ticker": t} for t in tickers]

        results = []
        for ticker in tickers:
            result = self.get_prediction([ticker], time_frame, parameters)
            result["ticker"] = ticker
            results.append(result)
        return results

