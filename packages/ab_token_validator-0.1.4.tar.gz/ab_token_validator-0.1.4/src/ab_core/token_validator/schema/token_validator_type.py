from enum import StrEnum


class TokenValidatorType(StrEnum):
    OIDC = "OIDC"
    TEMPLATE = "TEMPLATE"
