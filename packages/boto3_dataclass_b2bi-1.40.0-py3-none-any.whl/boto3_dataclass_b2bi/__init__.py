# -*- coding: utf-8 -*-

from .caster import b2bi_caster

caster = b2bi_caster

__version__ = "1.40.0"