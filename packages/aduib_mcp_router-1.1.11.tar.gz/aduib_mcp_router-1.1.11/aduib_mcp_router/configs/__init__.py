from .app_config import AduibAiConfig

config = AduibAiConfig()
