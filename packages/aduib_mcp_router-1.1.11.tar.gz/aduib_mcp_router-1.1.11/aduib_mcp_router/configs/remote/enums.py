from enum import StrEnum


class RemoteSettingsSourceName(StrEnum):
    NACOS="nacos"