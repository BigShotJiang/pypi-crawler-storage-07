def plus(a,b):
    add=a+b
    return add



def minus(a,b):
    sub=a-b
    return sub


def x(a,b):
    mul=a*b
    return mul


def div(a,b):
    division=a/b
    return division


def currency_exchangedollar():
    
    convert=int(input("\nEnter your Value in Dollar to convert into PKR: "))
    
    
    print(f"Converted PKR into Dollar is {convert*280}")

    










