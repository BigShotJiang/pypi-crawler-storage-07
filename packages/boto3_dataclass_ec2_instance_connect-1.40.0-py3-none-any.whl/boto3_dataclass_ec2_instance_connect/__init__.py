# -*- coding: utf-8 -*-

from .caster import ec2_instance_connect_caster

caster = ec2_instance_connect_caster

__version__ = "1.40.0"