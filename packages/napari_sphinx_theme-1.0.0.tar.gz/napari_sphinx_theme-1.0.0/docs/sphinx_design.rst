Sphinx-design
=============

This is how sphinx-design elements look like with the napari Sphinx theme.

Tabs
----

.. tab-set::

    .. tab-item:: Tab 1

        This is the content of Tab 1.

    .. tab-item:: Tab 2

        This is the content of Tab 2.

    .. tab-item:: Tab 3

        This is the content of Tab 3.

Dropdowns
---------

.. dropdown:: Click to expand

    This is the content inside the dropdown.
