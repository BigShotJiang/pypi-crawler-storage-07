Testing a very long page name
=============================

This page is to test how the theme handles very long page names in the sidebar and navbar.
