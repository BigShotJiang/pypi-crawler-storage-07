from number_even import example


example = example.Example(4)

print(example.number_even())
print(example.n)