"""Top-level package for Study Lyte ."""

__author__ = """Micah Johnson """
__email__ = 'info@adventuredata.com'
__version__ = '0.10.2'
