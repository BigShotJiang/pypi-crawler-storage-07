from xdsl.xdsl_opt_main import xDSLOptMain


def main():
    xDSLOptMain().run()


if "__main__" == __name__:
    main()
