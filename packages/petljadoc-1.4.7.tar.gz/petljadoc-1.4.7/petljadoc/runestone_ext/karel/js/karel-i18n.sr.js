$.i18n().load({
    "sr": {
        "msg_karel_crashed": "Робот је ударио у зид!",
        "msg_karel_no_ball": "Не постоји лоптица на пољу!",
        "msg_karel_out_of_bounds": "Робот је ударио у спољни зид!",
        "msg_karel_no_balls_with_robot": "Робот нема лоптица код себе!",
        "msg_karel_incorrect": "Нетачно!",
        "msg_karel_correct": "Тачно!",
	    "msg_karel_true": "Тачно",
	    "msg_karel_false": "Нетачно"
    }
})