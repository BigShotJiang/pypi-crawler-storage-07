# Configuration file for the Sphinx documentation builder.
#
# This file only contains a selection of the most common options. For a full
# list see the documentation:
# https://www.sphinx-doc.org/en/master/usage/configuration.html

# -- Path setup --------------------------------------------------------------

# If extensions (or modules to document with autodoc) are in another directory,
# add these directories to sys.path here. If the directory is relative to the
# documentation root, use os.path.abspath to make it absolute, like shown here.
#
import os
import sys

sys.path.insert(0, os.path.abspath("../../src/alfred3_interact"))


# -- Project information -----------------------------------------------------

project = "alfred3_interact"
copyright = "2021, Johannes Brachem, Christian Treffenstädt"
author = "Johannes Brachem, Christian Treffenstädt"

# The full version, including alpha/beta/rc tags
# Parse version from _version.py in package directory
# See https://packaging.python.org/guides/single-sourcing-package-version/#single-sourcing-the-version
versiondict = {}
with open("../../src/alfred3_interact/_version.py") as f:
    exec(f.read(), versiondict)
release = versiondict["__version__"]


# -- General configuration ---------------------------------------------------

# Add any Sphinx extension module names here, as strings. They can be
# extensions coming with Sphinx (named 'sphinx.ext.*') or your custom
# ones.
extensions = [
    "sphinx.ext.napoleon",
    "sphinx.ext.intersphinx",
    "sphinx.ext.autodoc",
    "sphinx.ext.todo",
    "sphinx.ext.autosummary",
    "sphinx.ext.autosectionlabel",
    "sphinx.ext.linkcode",
    "recommonmark",
]

autosummary_generate = True

intersphinx_mapping = {"python": ("https://docs.python.org/3", None)}

# Add any paths that contain templates here, relative to this directory.
templates_path = ["_templates"]

# List of patterns, relative to source directory, that match files and
# directories to ignore when looking for source files.
# This pattern also affects html_static_path and html_extra_path.
exclude_patterns = []


# -- Options for HTML output -------------------------------------------------

# The theme to use for HTML and HTML Help pages.  See the documentation for
# a list of builtin themes.
#
html_theme = "sphinx_book_theme"

html_theme_options = {
    "repository_url": "https://github.com/jobrachem/alfred3-interact",
    "use_repository_button": True,
}

html_title = "alfred3_interact"
html_logo = "_static/alfred_logo_color.png"

# Add any paths that contain custom static files (such as style sheets) here,
# relative to this directory. They are copied after the builtin static files,
# so a file named "default.css" will overwrite the builtin "default.css".
html_static_path = ["_static"]
html_css_files = ["custom.css"]

master_doc = "index"
pygments_style = "sphinx"

# Monkey patch for issue #2044 (None by by default for instance attributes? #2044)
# Should be resolved in next release of sphinx
# from sphinx.ext.autodoc import ClassLevelDocumenter, InstanceAttributeDocumenter


# def iad_add_directive_header(self, sig):
#     ClassLevelDocumenter.add_directive_header(self, sig)


# InstanceAttributeDocumenter.add_directive_header = iad_add_directive_header

autodoc_default_options = {"member-order": "bysource", "inherited-members": False}


def linkcode_resolve(domain, info):
    if domain != "py":
        return None
    if not info["module"]:
        return None
    filename = info["module"].replace(".", "/")

    return f"https://github.com/jobrachem/alfred3-interact/blob/main/src/{filename}.py"
