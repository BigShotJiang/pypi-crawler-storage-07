# -*- coding: utf-8 -*-

from .caster import ivs_caster

caster = ivs_caster

__version__ = "1.40.0"