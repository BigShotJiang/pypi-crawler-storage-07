# Examples
(Examples)=

## Encodings
```{base-gallery}
:caption: Encoding Examples
:tooltip:

notebooks/growing_trees
notebooks/rett
notebooks/huffman
notebooks/bonsai
```

## Hamiltonians
```{base-gallery}
:caption: Hamiltonian Examples
:tooltip:

notebooks/molecular_hamiltonian
notebooks/hubbard_hamiltonian
```
s
## Optimization
```{base-gallery}
:caption: Optimization Examples
:tooltip:

notebooks/pauli_weight
```
