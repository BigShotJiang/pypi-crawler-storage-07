from .core import QGISCore, QGISLocator, QGISAction


class QGISLibrary(QGISCore, QGISLocator, QGISAction):
    pass
