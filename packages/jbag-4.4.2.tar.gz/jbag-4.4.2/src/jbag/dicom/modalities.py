from enum import Enum


class Modality(Enum):
    CT = 1
