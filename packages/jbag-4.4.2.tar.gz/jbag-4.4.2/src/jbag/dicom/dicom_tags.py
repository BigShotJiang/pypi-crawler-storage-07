# Largest Image Pixel Value
Largest_Image_Pixel_Value = (0x0028, 0x0107)
# Smallest Image Pixel Value
Smallest_Image_Pixel_Value = (0x0028, 0x0106)
# Rescale Slope
Rescale_Slope = (0x0028, 0x1053)
# Rescale Intercept
Rescale_Intercept = (0x0028, 0x1052)
# Pixel Padding Value
Pixel_Padding_Value = (0x0028,0x0120)
