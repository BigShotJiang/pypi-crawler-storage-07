# -*- coding: utf-8 -*-

from .caster import lexv2_runtime_caster

caster = lexv2_runtime_caster

__version__ = "1.40.0"