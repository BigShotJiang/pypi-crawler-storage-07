from .main import fact
from .fib import fib
from .palindrome import palindrome
from .add_or_even import add_or_even
