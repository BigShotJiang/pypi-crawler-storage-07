calute.multimodal
=================

.. automodule:: calute.multimodal
    :members:
    :undoc-members:
    :show-inheritance:
