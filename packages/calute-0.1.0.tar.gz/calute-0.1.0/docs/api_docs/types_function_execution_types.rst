calute.types.function_execution_types
=====================================

.. automodule:: calute.types.function_execution_types
    :members:
    :undoc-members:
    :show-inheritance:
