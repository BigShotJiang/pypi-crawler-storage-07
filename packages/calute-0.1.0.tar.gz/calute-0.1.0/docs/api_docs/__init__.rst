calute.__init__
===============

.. automodule:: calute.__init__
    :members:
    :undoc-members:
    :show-inheritance:
