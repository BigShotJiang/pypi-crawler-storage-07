calute.cortex.delegation
========================

.. automodule:: calute.cortex.delegation
    :members:
    :undoc-members:
    :show-inheritance:
