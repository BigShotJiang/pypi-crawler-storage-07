calute.cortex.chains
====================

.. automodule:: calute.cortex.chains
    :members:
    :undoc-members:
    :show-inheritance:
