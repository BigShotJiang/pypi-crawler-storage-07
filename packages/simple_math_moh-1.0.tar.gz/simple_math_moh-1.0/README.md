# SimpleMath

A beginner-friendly Python package that can **add, multiply, and divide** numbers.

## Installation
```bash
pip install simplemath
