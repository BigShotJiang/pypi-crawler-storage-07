types
========

.. automodule:: freewili.types
   :members:
   :undoc-members:
   :show-inheritance: