'''

   THE LIBRARY VERSION

 '''
__version__ = '0.8.0'
