"""Wrapper for the CLI test function."""

from __future__ import annotations

from ..cli_test import do_test

__all__ = ["do_test"]
