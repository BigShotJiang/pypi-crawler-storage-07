"""GDSFactory+ CLI app."""

from __future__ import annotations

import typer

app = typer.Typer()

__all__ = ["app"]
