from .genialntools import Slowed, Speed
__all__ = ['Speed', 'Slowed']
