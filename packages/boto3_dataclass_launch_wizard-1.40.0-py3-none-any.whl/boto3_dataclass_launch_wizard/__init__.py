# -*- coding: utf-8 -*-

from .caster import launch_wizard_caster

caster = launch_wizard_caster

__version__ = "1.40.0"