# SPDX-License-Identifier: BSD-3-Clause OR Apache-2.0
# encoding: utf-8
"""Python library for the µD3TN project"""

from . import config

__all__ = ['config']
