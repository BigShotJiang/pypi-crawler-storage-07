# -*- coding: utf-8 -*-

from .caster import dynamodbstreams_caster

caster = dynamodbstreams_caster

__version__ = "1.40.0"