import { Widget } from '@lumino/widgets';
import { NotebookPanel } from '@jupyterlab/notebook';
import { LabIcon } from '@jupyterlab/ui-components';
import { ISettingRegistry } from '@jupyterlab/settingregistry';

import { CellIssueWidget } from './issueWidget';

import { ICellIssue } from '../utils/types';
import { IModelSettings } from '../utils/ai-utils';
import { issueToCategory, issueCategoryNames } from '../utils/metadata';

import { analyzeCellsAccessibility } from '../utils/detection/base';
import { analyzeTableIssues } from '../utils/detection/category/table';

export class MainPanelWidget extends Widget {
  private aiEnabled: boolean = false;
  private currentNotebook: NotebookPanel | null = null;
  private languageModelSettings: IModelSettings;
  private visionModelSettings: IModelSettings;

  constructor(settingRegistry?: ISettingRegistry) {
    super();

    // Default settings
    this.languageModelSettings = {
      baseUrl: '',
      apiKey: '',
      model: ''
    };

    this.visionModelSettings = {
      baseUrl: '',
      apiKey: '',
      model: ''
    };

    // Load settings if available
    if (settingRegistry) {
      this.loadSettings(settingRegistry);
    }

    this.addClass('a11y-panel');
    this.id = 'a11y-sidebar';
    const accessibilityIcon = new LabIcon({
      name: 'a11y:accessibility',
      svgstr:
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path fill="#154F92" d="M256 48c114.953 0 208 93.029 208 208 0 114.953-93.029 208-208 208-114.953 0-208-93.029-208-208 0-114.953 93.029-208 208-208m0-40C119.033 8 8 119.033 8 256s111.033 248 248 248 248-111.033 248-248S392.967 8 256 8zm0 56C149.961 64 64 149.961 64 256s85.961 192 192 192 192-85.961 192-192S362.039 64 256 64zm0 44c19.882 0 36 16.118 36 36s-16.118 36-36 36-36-16.118-36-36 16.118-36 36-36zm117.741 98.023c-28.712 6.779-55.511 12.748-82.14 15.807.851 101.023 12.306 123.052 25.037 155.621 3.617 9.26-.957 19.698-10.217 23.315-9.261 3.617-19.699-.957-23.316-10.217-8.705-22.308-17.086-40.636-22.261-78.549h-9.686c-5.167 37.851-13.534 56.208-22.262 78.549-3.615 9.255-14.05 13.836-23.315 10.217-9.26-3.617-13.834-14.056-10.217-23.315 12.713-32.541 24.185-54.541 25.037-155.621-26.629-3.058-53.428-9.027-82.141-15.807-8.6-2.031-13.926-10.648-11.895-19.249s10.647-13.926 19.249-11.895c96.686 22.829 124.283 22.783 220.775 0 8.599-2.03 17.218 3.294 19.249 11.895 2.029 8.601-3.297 17.219-11.897 19.249z"/></svg>'
    });

    this.title.icon = accessibilityIcon;
    this.node.innerHTML = `
      <div class="main-container">
          <div class="notice-container">
              <div class="notice-header">
                  <div class="notice-title">
                      <span class="chevron material-icons">expand_more</span>
                      <strong>Notice: Known cell navigation error </strong>
                  </div>
                  <button class="notice-delete-button">✕</button>
              </div>
              <div class="notice-content hidden">
                  <p>
                      The jupyterlab-a11y-checker has a known cell navigation issue for Jupyterlab version 4.2.5 or later. 
                      To fix this, please navigate to 'Settings' → 'Settings Editor' → Notebook, scroll down to 'Windowing mode', 
                      and choose 'defer' from the dropdown. Please note that this option may reduce the performance of the application. 
                      For more information, please see the <a href="https://jupyter-notebook.readthedocs.io/en/stable/changelog.html" target="_blank" style="text-decoration: underline;">Jupyter Notebook changelog.</a>
                  </p>
              </div>
          </div>
          <h1 class="main-title">Accessibility Checker</h1>
          <div class="controls-container">
              <button class="control-button ai-control-button">
                <span class="material-icons">auto_awesome</span>
                Use AI : Disabled
              </button>
              <button class="control-button analyze-control-button">
                <span class="material-icons">science</span>  
                Analyze Notebook
              </button>
          </div>
          <div class="issues-container"></div>
      </div>
        `;

    // Notice
    const noticeContainer = this.node.querySelector('.notice-container');
    const noticeContent = this.node.querySelector(
      '.notice-content'
    ) as HTMLElement;
    const noticeToggleButton = this.node.querySelector('.notice-title');
    const noticeDeleteButton = this.node.querySelector('.notice-delete-button');
    const expandIcon = this.node.querySelector('.chevron');

    noticeToggleButton?.addEventListener('click', () => {
      noticeContent?.classList.toggle('hidden');
      expandIcon?.classList.toggle('expanded');
    });

    noticeDeleteButton?.addEventListener('click', () => {
      noticeContainer?.classList.add('hidden');
    });

    // Controls
    const aiControlButton = this.node.querySelector(
      '.ai-control-button'
    ) as HTMLButtonElement;
    const analyzeControlButton = this.node.querySelector(
      '.analyze-control-button'
    ) as HTMLButtonElement;
    const progressIcon = `
    <svg class="icon loading" viewBox="0 0 24 24">
        <path d="M12 4V2C6.48 2 2 6.48 2 12h2c0-4.41 3.59-8 8-8z"/>
    </svg>
    `;

    aiControlButton?.addEventListener('click', async () => {
      const aiIcon = '<span class="material-icons">auto_awesome</span>';

      this.aiEnabled = !this.aiEnabled;
      aiControlButton.innerHTML = `${aiIcon} Use AI : ${this.aiEnabled ? 'Enabled' : 'Disabled'}`;

      // Update every ai suggestion button visibility
      const suggestButtons = this.node.querySelectorAll('.suggest-button');
      suggestButtons.forEach(button => {
        (button as HTMLElement).style.display = this.aiEnabled
          ? 'flex'
          : 'none';
      });
    });

    analyzeControlButton?.addEventListener('click', async () => {
      if (!this.currentNotebook) {
        console.log('No current notebook found');
        return;
      }

      const analyzeControlButtonText = analyzeControlButton.innerHTML;

      const issuesContainer = this.node.querySelector(
        '.issues-container'
      ) as HTMLElement;
      issuesContainer.innerHTML = '';
      analyzeControlButton.innerHTML = `${progressIcon} Please wait...`;
      analyzeControlButton.disabled = true;

      try {
        // Identify issues
        const notebookIssues: ICellIssue[] = await analyzeCellsAccessibility(
          this.currentNotebook
        );

        // Log a human-readable summary for troubleshooting
        try {
          const total = notebookIssues.length;

          const byViolation = notebookIssues.reduce(
            (acc: Record<string, number>, issue) => {
              acc[issue.violationId] = (acc[issue.violationId] || 0) + 1;
              return acc;
            },
            {} as Record<string, number>
          );
          const cellsAffected = Array.from(
            new Set(notebookIssues.map(i => i.cellIndex))
          ).length;

          const lines: string[] = [];
          lines.push('A11Y Analysis Summary');
          lines.push(`- Total issues: ${total}`);
          lines.push(`- Cells affected: ${cellsAffected}`);

          const allViolations = Object.entries(byViolation)
            .sort((a, b) => b[1] - a[1])
            .map(([v, c]) => `  - ${v}: ${c}`);
          if (allViolations.length) {
            lines.push('- Violations:');
            lines.push(...allViolations);
          }
          console.log(lines.join('\n'));
        } catch {
          console.log('Summary Unavailable');
        }

        if (notebookIssues.length === 0) {
          issuesContainer.innerHTML =
            '<div class="no-issues">No issues found</div>';
          return;
        }

        // Group issues by category
        const issuesByCategory = new Map<string, ICellIssue[]>();

        notebookIssues.forEach(notebookIssue => {
          const categoryName: string =
            issueToCategory.get(notebookIssue.violationId) || 'Other';
          if (!issuesByCategory.has(categoryName)) {
            issuesByCategory.set(categoryName, []);
          }
          issuesByCategory.get(categoryName)!.push(notebookIssue);
        });
        // Create widgets for each category
        for (const categoryName of issueCategoryNames) {
          const categoryIssues: ICellIssue[] =
            issuesByCategory.get(categoryName) || [];

          if (categoryIssues.length === 0) {
            continue;
          }

          const categoryWidget: HTMLDivElement = document.createElement('div');
          categoryWidget.classList.add('category');
          categoryWidget.innerHTML = `
            <h2 class="category-title">${categoryName}</h2>
            <hr>
            <div class="issues-list"></div>
          `;

          const issuesContainer = this.node.querySelector(
            '.issues-container'
          ) as HTMLElement;
          issuesContainer.appendChild(categoryWidget);

          const issuesList: HTMLDivElement = categoryWidget.querySelector(
            '.issues-list'
          ) as HTMLDivElement;

          categoryIssues.forEach(issue => {
            const issueWidget = new CellIssueWidget(
              issue,
              this.currentNotebook!.content.widgets[issue.cellIndex],
              this.aiEnabled,
              this
            );
            issuesList.appendChild(issueWidget.node);
          });
        }
      } catch (error) {
        issuesContainer.innerHTML = '';
        console.error('Error analyzing notebook:', error);
      } finally {
        analyzeControlButton.innerHTML = analyzeControlButtonText;
        analyzeControlButton.disabled = false;
      }
    });

    // Add event listener for notebookReanalyzed event
    // Listen on both the panel node and document to ensure we catch bubbled events
    const handler = async (event: Event) => {
      const customEvent = event as CustomEvent;
      const newIssues = customEvent.detail.issues;
      const isHeadingUpdate = customEvent.detail.isHeadingUpdate;
      const isTableUpdate = customEvent.detail.isTableUpdate;
      const isCellUpdate = customEvent.detail.isCellUpdate;

      if (isHeadingUpdate) {
        // Find the Headings category section
        const headingsCategory = Array.from(
          this.node.querySelectorAll('.category-title')
        )
          .find(title => title.textContent === 'Headings')
          ?.closest('.category');

        if (headingsCategory) {
          // Clear only the issues list in the Headings section
          const issuesList = headingsCategory.querySelector('.issues-list');
          if (issuesList) {
            issuesList.innerHTML = '';

            // Add new heading issues to this section
            newIssues.forEach((issue: ICellIssue) => {
              const issueWidget = new CellIssueWidget(
                issue,
                this.currentNotebook!.content.widgets[issue.cellIndex],
                this.aiEnabled,
                this
              );
              issuesList.appendChild(issueWidget.node);
            });
          }
        }
      } else if (isTableUpdate) {
        // Find the Tables category section
        const tablesCategory = Array.from(
          this.node.querySelectorAll('.category-title')
        )
          .find(title => title.textContent === 'Tables')
          ?.closest('.category');

        if (tablesCategory) {
          // Clear only the issues list in the Tables section
          const issuesList = tablesCategory.querySelector('.issues-list');
          if (issuesList) {
            issuesList.innerHTML = '';

            // Reanalyze table issues
            const tableIssues = await analyzeTableIssues(this.currentNotebook!);

            // Add new table issues to this section
            tableIssues.forEach((issue: ICellIssue) => {
              const issueWidget = new CellIssueWidget(
                issue,
                this.currentNotebook!.content.widgets[issue.cellIndex],
                this.aiEnabled,
                this
              );
              issuesList.appendChild(issueWidget.node);
            });
          }
        }
      } else if (isCellUpdate) {
        // Single-cell update: replace only issues from impacted cell(s) per category
        const incomingIssues = newIssues as ICellIssue[];
        const issuesByCategory = new Map<string, ICellIssue[]>();
        incomingIssues.forEach(issue => {
          const categoryName =
            issueToCategory.get(issue.violationId) || 'Other';
          if (!issuesByCategory.has(categoryName)) {
            issuesByCategory.set(categoryName, []);
          }
          issuesByCategory.get(categoryName)!.push(issue);
        });

        for (const [categoryName, categoryIssues] of issuesByCategory) {
          // Find or create the category section
          let categoryEl = Array.from(
            this.node.querySelectorAll('.category-title')
          )
            .find(title => title.textContent === categoryName)
            ?.closest('.category') as HTMLElement | undefined | null;

          if (!categoryEl) {
            categoryEl = document.createElement('div');
            categoryEl.classList.add('category');
            categoryEl.innerHTML = `
              <h2 class="category-title">${categoryName}</h2>
              <hr>
              <div class="issues-list"></div>
            `;
            const container = this.node.querySelector(
              '.issues-container'
            ) as HTMLElement;
            container.appendChild(categoryEl);
          }

          const issuesList = categoryEl.querySelector(
            '.issues-list'
          ) as HTMLElement;

          // Remove existing widgets for impacted cell indices only
          const impacted = new Set(categoryIssues.map(i => i.cellIndex));
          Array.from(issuesList.children).forEach(child => {
            const el = child as HTMLElement;
            const idxAttr = el.getAttribute('data-cell-index');
            if (idxAttr && impacted.has(parseInt(idxAttr))) {
              el.remove();
            }
          });

          // Append new issues for this category
          categoryIssues.forEach(issue => {
            const issueWidget = new CellIssueWidget(
              issue,
              this.currentNotebook!.content.widgets[issue.cellIndex],
              this.aiEnabled,
              this
            );
            issuesList.appendChild(issueWidget.node);
          });
        }
      }
    };
    this.node.addEventListener('notebookReanalyzed', handler as EventListener);
    //document.addEventListener('notebookReanalyzed', handler as EventListener);
  }

  private async loadSettings(settingRegistry: ISettingRegistry): Promise<void> {
    try {
      const settings = await settingRegistry.load(
        'jupyterlab-a11y-checker:plugin'
      );

      if (settings.get('languageModel').composite) {
        const langModel = settings.get('languageModel').composite as any;
        this.languageModelSettings = {
          baseUrl: langModel.baseUrl || this.languageModelSettings.baseUrl,
          apiKey: langModel.apiKey || this.languageModelSettings.apiKey,
          model: langModel.model || this.languageModelSettings.model
        };
      }

      if (settings.get('visionModel').composite) {
        const visionModel = settings.get('visionModel').composite as any;
        this.visionModelSettings = {
          baseUrl: visionModel.baseUrl || this.visionModelSettings.baseUrl,
          apiKey: visionModel.apiKey || this.visionModelSettings.apiKey,
          model: visionModel.model || this.visionModelSettings.model
        };
      }
    } catch (error) {
      console.warn('Failed to load settings:', error);
    }
  }

  getLanguageModelSettings(): IModelSettings {
    return this.languageModelSettings;
  }

  getVisionModelSettings(): IModelSettings {
    return this.visionModelSettings;
  }

  setNotebook(notebook: NotebookPanel) {
    this.currentNotebook = notebook;

    const issuesContainer = this.node.querySelector(
      '.issues-container'
    ) as HTMLElement;
    issuesContainer.innerHTML = '';
  }
}
