# src/my_awesome_package/__init__.py

# Expose the main function so users can import it easily
from .main import greet

# Package version
__version__ = "0.1.2"  # <--- UPDATED VERSION
