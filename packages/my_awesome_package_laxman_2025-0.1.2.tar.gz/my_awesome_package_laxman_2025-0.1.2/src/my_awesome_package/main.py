# src/my_awesome_package/main.py

def greet(name):
    """Greets the user with their name."""
    return f"Hello, {name}! Your awesome package is working."


if __name__ == '__main__':
    print(greet("PyPI User"))
