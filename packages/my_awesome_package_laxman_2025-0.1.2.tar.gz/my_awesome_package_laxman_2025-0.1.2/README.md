# My Awesome Package (Laxman)

A small, awesome utility package created by Laxman. This package is a quick demonstration of creating and publishing a modern Python project using `pyproject.toml` and the `src/` layout.

## Installation

```bash
pip install my-awesome-package-laxman-2025