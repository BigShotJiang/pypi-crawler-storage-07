This module is a glue module between AI OCA Bridge and Field Service.
