package sample;

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello from Ant-built Java");
    }
}
