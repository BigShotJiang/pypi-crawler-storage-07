def main():
    print("it works with uv too!")
