"""Integration tests with just partitions enabled."""
