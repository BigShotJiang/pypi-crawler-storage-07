Lifecycle manager
=================

The lifecycle manager holds information about the parts specification
and the project state, and coordinates planning and execution of actions
required to run steps for a given set of parts.

.. autoclass:: craft_parts.lifecycle_manager.LifecycleManager
   :members:
   :noindex:
