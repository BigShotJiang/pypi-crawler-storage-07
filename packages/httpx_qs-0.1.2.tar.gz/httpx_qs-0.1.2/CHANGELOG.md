## 0.1.2

* [DOCS] add Sphinx documentation

## 0.1.1

* [CHORE] limit httpx to `>=0.28.1, <1.0.0`

## 0.1.0

* [CHORE] initial release
