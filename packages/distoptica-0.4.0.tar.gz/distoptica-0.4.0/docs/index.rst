DistOptica (distoptica)
=======================

``distoptica`` is a Python library for modelling optical distortions.

Setting up distoptica
---------------------

For instructions on installing the ``distoptica`` library, see the
:ref:`installation_instructions_sec` page.

Learning how to use distoptica
------------------------------

For those new to the ``distoptica`` library, it is recommended that they take a
look at the :ref:`examples_sec` page, which contain code examples that show how
one can use the ``distoptica`` library. While going through the examples,
readers can consult the :ref:`reference_guide_sec` to understand what each line
of code is doing.

Contents
--------
.. toctree::
   :maxdepth: 6
   :numbered:

   Home <self>
   INSTALL
   Reference <_autosummary/distoptica>
   examples
   literature
   license

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
