Once the module is installed:

1.  Go to a sale order.
2.  You can now delete a sale order line if it hasn't been invoiced or
    delivered.
