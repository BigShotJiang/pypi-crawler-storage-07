This module allows the removal of sale order lines even after the order
has been confirmed, under certain conditions. Specifically, a sale order
line can be removed if:

- It has not been invoiced.
- It has not been delivered.
