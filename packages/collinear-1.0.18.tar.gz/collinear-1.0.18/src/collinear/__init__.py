"""Collinear Python SDK."""
