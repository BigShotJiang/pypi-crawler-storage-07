"""Unit tests for database adapters."""

__all__ = ()
