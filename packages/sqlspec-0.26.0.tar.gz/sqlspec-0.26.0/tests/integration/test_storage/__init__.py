"""Integration tests for storage backends."""
