"""Integration tests for SQLSpec migration module.

Tests for database migration integration with real database connections,
file system operations, and migration execution.
"""
