"""Integration tests for asyncpg adapter."""
