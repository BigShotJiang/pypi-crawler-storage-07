This is attempts to do the https://eugenkiss.github.io/7guis/ with HTAG.

There are 7 tasks :
- 1) counter : done
- 2) Temp Converter : done
- 3) Flight Booker : done
- 4) Timer : **IN PROGRESS**
- 5) CRUD : done
- 6) Circle Drawer : **TODO**
- 7) Cells : **TODO**

It's not complete yet.
