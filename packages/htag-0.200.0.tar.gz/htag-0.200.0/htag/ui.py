# -*- coding: utf-8 -*-
# # #############################################################################
# Copyright (C) 2024 manatlan manatlan[at]gmail(dot)com
#
# MIT licence
#
# https://github.com/manatlan/htag
# #############################################################################
try:
  from htagui.basics import *  # htagui>=0.3
except ImportError:
  from htagui import *  # htagui<0.3
