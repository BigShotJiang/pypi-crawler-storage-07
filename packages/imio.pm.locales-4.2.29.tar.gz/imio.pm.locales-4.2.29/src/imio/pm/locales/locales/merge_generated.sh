i18ndude merge --pot PloneMeeting.pot --merge generated.pot
