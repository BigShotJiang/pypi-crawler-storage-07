README.rst
==========

These are the locales for Products.PloneMeeting

