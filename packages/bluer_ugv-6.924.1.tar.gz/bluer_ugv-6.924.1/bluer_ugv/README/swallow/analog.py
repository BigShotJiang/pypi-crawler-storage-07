from bluer_objects.README.items import ImageItems

items = [
    {
        "path": "../docs/bluer_swallow/analog",
        "items": ImageItems(
            {
                "../../../../diagrams/bluer_swallow/analog.png": "../../../../diagrams/bluer_swallow/analog.svg",
            }
        ),
    }
]
