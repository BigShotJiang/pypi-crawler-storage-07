from bluer_objects.README.items import ImageItems

from bluer_ugv.README.consts import assets2_bluer_fire

items = ImageItems({})
