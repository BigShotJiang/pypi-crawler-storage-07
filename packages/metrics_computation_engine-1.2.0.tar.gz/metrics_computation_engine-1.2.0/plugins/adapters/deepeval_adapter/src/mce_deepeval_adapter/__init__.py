from .model_loader import load_model

__all__ = ["load_model"]
