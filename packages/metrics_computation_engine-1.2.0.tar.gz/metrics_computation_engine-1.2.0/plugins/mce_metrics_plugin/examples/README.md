# MCE metrics plugin examples
## LLM Uncertainty Scores
### Steps to run the test

1. install the virtual environment by running this command in the root folder `deepeval_adapter`:
    ```shell
    uv sync
    ```
2. run the example file :
    ```shell
    uv run examples/run_llm_uncertainty_scores.py
    ```
