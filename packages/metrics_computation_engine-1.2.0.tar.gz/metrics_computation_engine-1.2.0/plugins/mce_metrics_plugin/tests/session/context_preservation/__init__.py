"""
Test module for context preservation plugin.
"""
