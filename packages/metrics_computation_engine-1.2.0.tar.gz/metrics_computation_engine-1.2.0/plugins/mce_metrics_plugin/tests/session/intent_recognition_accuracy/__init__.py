"""
Test module for intent recognition accuracy plugin.
"""
