"""
Test module for workflow cohesion index plugin.
"""
