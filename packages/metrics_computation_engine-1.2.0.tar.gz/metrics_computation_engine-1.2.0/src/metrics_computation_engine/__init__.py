# Copyright AGNTCY Contributors (https://github.com/agntcy)
# SPDX-License-Identifier: Apache-2.0

"""Metrics Computation Engine

A FastAPI-based service for computing metrics on AI agent performance data.
"""

__version__ = "0.1.0"
