# -*- coding: utf-8 -*-

from .caster import cleanroomsml_caster

caster = cleanroomsml_caster

__version__ = "1.40.0"