__version__ = "74.20250926"
GIT_REF = "85fd080"
URL = "https://github.com/micro-manager/mmCoreAndDevices/tree/85fd080"