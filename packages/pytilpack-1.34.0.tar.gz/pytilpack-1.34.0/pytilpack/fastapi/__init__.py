"""FastAPI関連のユーティリティ。"""

# flake8: noqa

from .asserts import *
