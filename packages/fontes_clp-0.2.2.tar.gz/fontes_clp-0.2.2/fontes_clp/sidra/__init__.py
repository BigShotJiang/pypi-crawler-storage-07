from . import sidra

from .sidra import Sidra, Tabela, Variavel

__all__ = [
    "Sidra",
    "Tabela",
    "Variavel",
    "sidra",
]
