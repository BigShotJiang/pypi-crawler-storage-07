from .decodoc import decodoc_setup, decodoc, get_dict
