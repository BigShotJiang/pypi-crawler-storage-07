# -*- coding: utf-8 -*-

from .caster import forecast_caster

caster = forecast_caster

__version__ = "1.40.0"