import TElectric

result = TElectric.power(current=5, voltage=220)
print(result)  # باید خروجی بده: 1100
