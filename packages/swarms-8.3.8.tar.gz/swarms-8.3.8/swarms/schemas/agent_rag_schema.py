from pydantic import BaseModel


class AgentRAGConfig(BaseModel):
    """
    Configuration for the AgentRAG class.
    """
