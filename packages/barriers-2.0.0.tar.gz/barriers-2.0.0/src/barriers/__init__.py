"""Allow users to access decorator/function directly."""
from barriers.barriers import barriers
