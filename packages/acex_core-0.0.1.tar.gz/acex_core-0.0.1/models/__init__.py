
from .asset import Asset, AssetInterface, AssetResponse, Ned
from .logical_node import LogicalNode, LogicalNodeResponse, LogicalNodeListResponse
from .node import Node, NodeResponse
from .external_value import ExternalValue


system_models = [Asset, AssetInterface, Ned, LogicalNode, Node]