# -*- coding: utf-8 -*-

from .caster import cloudfront_keyvaluestore_caster

caster = cloudfront_keyvaluestore_caster

__version__ = "1.40.0"