| %Own  | %Total | OwnTime | TotalTime | Function (filename) |
| ----- | ------ | ------- | --------- | -------------------- |
| 0.00% | 0.00%  | 7.42s   | 15.66s    | run (asyncio/runners.py) |
| 0.00% | 0.00%  | 1.43s   | 1.72s     | on_headers_complete (lihil/server/server.py) |
| 0.00% | 0.00%  | 1.04s   | 1.58s     | send (lihil/server/server.py) |
| 0.00% | 0.00%  | 0.870s  | 3.00s     | data_received (lihil/server/server.py) |
| 0.00% | 0.00%  | 0.600s  | 1.15s     | body (starlette/requests.py) |
| 0.00% | 0.00%  | 0.480s  | 4.38s     | call_plain (lihil/routing.py) |
| 0.00% | 0.00%  | 0.440s  | 0.440s    | on_response_complete (lihil/server/server.py) |
| 0.00% | 0.00%  | 0.280s  | 1.86s     | __call__ (starlette/responses.py) |
| 0.00% | 0.00%  | 0.280s  | 1.55s     | prepare_params (lihil/routing.py) |
| 0.00% | 0.00%  | 0.270s  | 0.270s    | add (_weakrefset.py) |
| 0.00% | 0.00%  | 0.250s  | 4.94s     | __call__ (lihil/lihil.py) |
| 0.00% | 0.00%  | 0.250s  | 5.19s     | run_asgi (lihil/server/server.py) |
| 0.00% | 0.00%  | 0.190s  | 0.230s    | receive (lihil/server/server.py) |
| 0.00% | 0.00%  | 0.180s  | 0.180s    | on_header (lihil/server/server.py) |
| 0.00% | 0.00%  | 0.170s  | 0.170s    | set (asyncio/locks.py) |
| 0.00% | 0.00%  | 0.160s  | 0.390s    | stream (starlette/requests.py) |
| 0.00% | 0.00%  | 0.160s  | 0.160s    | init_headers (starlette/responses.py) |
| 0.00% | 0.00%  | 0.160s  | 4.54s     | __call__ (lihil/routing.py) |
| 0.00% | 0.00%  | 0.150s  | 0.150s    | match (lihil/routing.py) |
| 0.00% | 0.00%  | 0.130s  | 0.130s    | __init__ (starlette/requests.py) |
| 0.00% | 0.00%  | 0.120s  | 0.120s    | decode (lihil/interface/param.py) |
| 0.00% | 0.00%  | 0.090s  | 0.090s    | __init__ (asyncio/locks.py) |



  %Own   %Total  OwnTime  TotalTime  Function (filename)
  0.00%   0.00%    4.26s    10.09s   run (asyncio/runners.py)
  0.00%   0.00%    1.12s     1.31s   on_headers_complete (lihil/server/server.py)
  0.00%   0.00%   0.670s     1.05s   send (lihil/server/server.py)
  0.00%   0.00%   0.430s     2.05s   data_received (lihil/server/server.py)
  0.00%   0.00%   0.410s    0.750s   body (starlette/requests.py)
  0.00%   0.00%   0.350s    0.360s   on_response_complete (lihil/server/server.py)
  0.00%   0.00%   0.280s     3.06s   call_plain (lihil/routing.py)
  0.00%   0.00%   0.200s    0.200s   match (lihil/routing.py)
  0.00%   0.00%   0.200s     3.76s   run_asgi (lihil/server/server.py)
  0.00%   0.00%   0.190s    0.190s   decode (lihil/interface/param.py)
  0.00%   0.00%   0.160s     3.56s   __call__ (lihil/lihil.py)
  0.00%   0.00%   0.160s     1.10s   prepare_params (lihil/routing.py)
  0.00%   0.00%   0.150s    0.150s   init_headers (starlette/responses.py)
  0.00%   0.00%   0.140s     1.19s   __call__ (starlette/responses.py)
  0.00%   0.00%   0.140s     3.20s   __call__ (lihil/routing.py)
