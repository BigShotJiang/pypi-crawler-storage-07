---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behaviour.

**Expected behaviour**
A clear and concise description of what you expected to happen.

**Screenshots**
If applicable, add screenshots to help explain your problem.

**Operating environment (please complete the following information):**
 - OS: [e.g. macOS Darwin Kernel Version 24.6.0]
 - Python: [e.g. 3.12.0]

**Additional context**
Add any other context about the problem here.
