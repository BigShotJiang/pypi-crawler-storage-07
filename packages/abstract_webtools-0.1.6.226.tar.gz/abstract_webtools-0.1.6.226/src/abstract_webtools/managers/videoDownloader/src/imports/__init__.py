from .imports import *
from .info_registry import *
registry = infoRegistry()
