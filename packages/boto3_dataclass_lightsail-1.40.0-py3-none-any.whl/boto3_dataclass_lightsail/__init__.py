# -*- coding: utf-8 -*-

from .caster import lightsail_caster

caster = lightsail_caster

__version__ = "1.40.0"