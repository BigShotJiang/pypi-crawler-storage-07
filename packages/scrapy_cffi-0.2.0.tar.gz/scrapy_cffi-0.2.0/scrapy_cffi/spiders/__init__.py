from .base import Spider, BaseSpider

__all__ = [
    "BaseSpider",
    "Spider",
]