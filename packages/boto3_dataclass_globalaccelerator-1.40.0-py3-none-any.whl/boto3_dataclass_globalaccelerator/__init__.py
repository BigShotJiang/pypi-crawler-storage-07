# -*- coding: utf-8 -*-

from .caster import globalaccelerator_caster

caster = globalaccelerator_caster

__version__ = "1.40.0"