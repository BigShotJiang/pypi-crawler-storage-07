"""
AWS-related models for reading CloudFormation outputs and other AWS operations.
"""

from pydantic import BaseModel


class StackOutput(BaseModel):
    """Model for actual CloudFormation stack outputs from AWS."""
    output_key: str
    output_value: str
    description: str = ""
