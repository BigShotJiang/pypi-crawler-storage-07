from pydantic import BaseModel


class InfraConfig(BaseModel):
    """
    Base class for all infrastructure configuration classes.
    
    This provides a common `stack` field that defaults to "IICYStack"
    but can be overridden for custom stack names.
    """
    stack: str = "IICYStack"


