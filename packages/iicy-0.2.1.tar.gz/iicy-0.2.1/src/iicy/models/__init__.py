# Models package - features are now at the root level
from .base import InfraConfig
