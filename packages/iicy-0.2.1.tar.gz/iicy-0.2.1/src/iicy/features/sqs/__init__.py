"""
SQS feature module.

This module contains all SQS-related functionality including
the SQS feature implementation.
"""

from .sqs_feature import SQSFeature

__all__ = ['SQSFeature']
