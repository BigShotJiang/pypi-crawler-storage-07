"""
Lambda feature module.

This module contains all Lambda-related functionality including
configuration classes and feature implementations.
"""

from .lambda_config import LambdaInfraConfig, IAMRoleConfig, handler
from .lambda_feature import LambdaFeature

__all__ = ['LambdaInfraConfig', 'IAMRoleConfig', 'handler', 'LambdaFeature']
