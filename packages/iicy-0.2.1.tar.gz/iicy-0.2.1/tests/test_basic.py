"""Basic tests for iicy."""

import iicy


def test_version():
    """Test that version is available."""
    assert hasattr(iicy, '__version__')
    assert isinstance(iicy.__version__, str)
