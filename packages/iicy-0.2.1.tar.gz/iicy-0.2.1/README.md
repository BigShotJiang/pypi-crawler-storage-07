# IICY - Infrastructure In Code Ycombinator

A paradigm-shifting approach to infrastructure management where infrastructure is defined alongside service code, eliminating the need for separate infrastructure definitions.

## The Problem

Traditional infrastructure management requires:
- Separate infrastructure code (Terraform, CDK, CloudFormation)
- Context switching between service and infrastructure code
- Manual synchronization of infrastructure and service changes
- Complex dependency management between services and infrastructure

## The Solution: Infrastructure In Code Ycombinator (IICY)

IICY allows you to define infrastructure directly in your service code using decorators and annotations. A static analyzer extracts these definitions and compiles them into CloudFormation templates.

### Key Benefits

- **Single Source of Truth**: Infrastructure and service code in one place
- **Type Safety**: Infrastructure definitions are part of the code
- **Easier Refactoring**: Changes to service code automatically update infrastructure
- **Better Developer Experience**: No context switching between infrastructure and service code
- **Reduced Complexity**: No need to maintain separate infrastructure files

## How It Works

1. **Define Infrastructure in Code**: Use IICY decorators to define infrastructure alongside your service code
2. **Static Analysis**: The IICY analyzer scans your code to extract infrastructure definitions
3. **Compilation**: Infrastructure definitions are compiled into CloudFormation templates
4. **Deployment**: CloudFormation templates are deployed to AWS
5. **Service Connection**: Service code automatically connects to deployed resources using ARNs and endpoints

## Installation

```bash
# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install in development mode
pip install -e ".[dev]"
```

## Development

### Running Tests

```bash
pytest
```


## Author

Blake Smith (blake@dotle.ca)