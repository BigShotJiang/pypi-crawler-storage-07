HONDO_RESOURCE_ID = "ce18fbb9-296d-4b40-ba66-f81a061051ac"
FORT_SUMNER_RESOURCE_ID = "3fa1cd2c-be33-4bba-a65b-bbc786dcbd39"
ROSWELL_RESOURCE_ID = "75b89cfc-f28c-4b95-b477-09272a2e47d2"
# ============= EOF =============================================
