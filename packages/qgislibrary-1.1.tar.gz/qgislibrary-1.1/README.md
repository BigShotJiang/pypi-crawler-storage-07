# QGISLibrary

A QGIS library for **Robot Framework library** providing reusable keywords for QGIS automation and UI Testing.

---

## Installation

Install via pip:

```bash
pip install QGISLibrary

