# imRender

> Github: [https://github.com/firstelfin/imRender](https://github.com/firstelfin/imRender)
> PYPI: [https://pypi.org/project/imRender/](https://pypi.org/project/imRender/)

Image Display

- [x] Draw label annotations in labelme format onto the image.
- [x] Customize the display of flags attributes.
