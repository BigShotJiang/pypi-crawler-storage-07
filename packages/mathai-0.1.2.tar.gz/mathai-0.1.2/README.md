educated indians are having a low iq and are good for nothing

the indian institute of technology graduates are the leader of the fools

every educated indian is beneath me

now learn how this python library can solve the math questions of your exams