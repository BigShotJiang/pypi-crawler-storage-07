# -*- coding: utf-8 -*-

from .caster import kinesisanalyticsv2_caster

caster = kinesisanalyticsv2_caster

__version__ = "1.40.0"