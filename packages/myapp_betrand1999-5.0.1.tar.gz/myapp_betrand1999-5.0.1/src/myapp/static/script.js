function showMessage() {
    alert("You clicked the button! 🚀");
}
