# Introduction 
fine artifact in this dir 
ls myagent/_work/1/s/dist