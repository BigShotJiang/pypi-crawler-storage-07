"""NextGen Practice Management package."""
