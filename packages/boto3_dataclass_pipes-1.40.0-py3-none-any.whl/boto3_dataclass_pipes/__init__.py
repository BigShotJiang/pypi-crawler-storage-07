# -*- coding: utf-8 -*-

from .caster import pipes_caster

caster = pipes_caster

__version__ = "1.40.0"