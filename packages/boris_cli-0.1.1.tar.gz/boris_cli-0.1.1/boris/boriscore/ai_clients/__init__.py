__version__ = '0.1.1'

# This file initializes the ai_clients package and exposes the version of the package.