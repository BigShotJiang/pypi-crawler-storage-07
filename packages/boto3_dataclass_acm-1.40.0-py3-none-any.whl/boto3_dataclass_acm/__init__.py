# -*- coding: utf-8 -*-

from .caster import acm_caster

caster = acm_caster

__version__ = "1.40.0"