# -*- coding: utf-8 -*-

from .caster import freetier_caster

caster = freetier_caster

__version__ = "1.40.0"