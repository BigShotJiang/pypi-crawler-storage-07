# -*- coding: utf-8 -*-

from .caster import mediaconnect_caster

caster = mediaconnect_caster

__version__ = "1.40.0"