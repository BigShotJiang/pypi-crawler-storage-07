"""linux2mqtt main entry."""

from .linux2mqtt import main

if __name__ == "__main__":
    main()
