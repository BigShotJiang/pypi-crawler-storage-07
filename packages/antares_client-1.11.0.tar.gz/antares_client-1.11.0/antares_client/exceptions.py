class AntaresException(Exception):
    pass
