# -*- coding: utf-8 -*-

# yt-dlp 패키지를 이용한 API 
# GITHUB : https://github.com/yt-dlp/yt-dlp
# PYPI : https://pypi.org/project/yt-dlp/
# DOC : 
# 정상동작 확인일 : 2024-12-28 



import json 
import subprocess
import re 
import os 
import pprint 
pp = pprint.PrettyPrinter(indent=2)
from datetime import datetime, timedelta
import math


import yt_dlp
from yt_dlp import YoutubeDL





################################################################
# GLOBAL VARIABLES 
################################################################

import os
from pathlib import Path, WindowsPath

"""Returns the default download directory based on OS."""
def get_default_download_path():
    if os.name == 'nt':  
        # Windows
        return os.path.join(Path.home(), "Downloads")
    else:  
        # macOS & Linux
        return os.path.join(Path.home(), "Downloads")


try:
    FFMPEG_LOCATION = str(WindowsPath(os.environ['FFMPEG_BIN_PATH']))
except Exception as e:
    print(f"ERROR | {e} | {__file__}")
    raise 








################################################################
# TESTs 
################################################################



################################################################
# Library functions
################################################################

def _print_error(msg, e=None):
    print(f"\nERROR | {msg} | {e}")


################################################################
# Internal functions
################################################################

def rename_playlist(s):
    s = re.sub(r'[\|/\*]+', repl=' ', string=s)
    s = re.sub(r'\s{2,5}', repl=' ', string=s).strip()
    print('\nPlaylist Renamed-->', s)
    return s


def clean_video_title(s):
    s = re.sub(r'[\|/\*]+', repl=' ', string=s)
    s = re.sub(r'\s{2,5}', repl=' ', string=s)
    s = re.sub(r'\.$', repl='', string=s).strip()
    return s


def clean_os_path(s):
    return re.sub(r"\.", repl='_', string=s)


# 컨텐츠 폴더명을 줄인다
def reduce_output(s):
    if len(s) > 250:
        _dir = os.path.dirname(s)
        top_dir = os.path.dirname(_dir)
        folder = os.path.basename(_dir)
        file = os.path.basename(s)
        while True:
            folder = folder[:-1].strip()
            folder = re.sub(r'[\.]$', repl='', string=folder).strip()
            print('folder-->', folder)
            s = os.path.join(os.path.join(top_dir, folder), file)
            if len(s) > 245:
                pass 
            else:
                break 
    else:
        pass 
    # print('\nReduced output-->', s)
    return s 




################################################################
# (Channel)
################################################################
from yt_dlp.utils import YoutubeDLError

class SilentLogger(YoutubeDLError):
    def debug(self, msg): pass
    def warning(self, msg): pass
    def error(self, msg): pass


# 채널정보 가져오기
def get_channel(channel_url)-> dict:
    
    ydl_opts = {
        'extract_flat': False,  # 메타데이터만 빠른 추출 (True)
        'quiet': True,
        'no_warnings': True,
        'skip_download': True,  # 다운로드 생략
        'retries': 3,  # 재시도 횟수
        'sleep_interval': 1,  # 요청 간 딜레이(초)
        'force_generic_extractor': False,
        'ignoreerrors': True,  # 오류무시:True
        'break_on_reject': False, # 거부 시 중단하지 않음
        # 'playlist_items': '1-2',  # 1부터 n_videos까지 항목 가져오기
        'noplaylist': True,
        'extractor_args': {'youtube': {'lang': ['ko']}}, # 한국어로 메타데이터 요청
        # 'cookiesfrombrowser': ('chrome',),  # 브라우저 쿠키 사용
        'logger': SilentLogger(),
        'verbose': False,
    }
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            return ydl.extract_info(channel_url + "/about", download=False)
    except Exception as e:
        _print_error(msg=f"알 수 없는 에러 ({channel_url})", e=e)


# 특정 채널의 비디오탭에 있는 신규 영상 정보 가져오기
def get_channel_videos(
        channel_url:str, 
        n_videos:int,
        duration:int
    )-> dict:
    
    # 공통옵션 
    ydl_opts = {
        'extract_flat': False,  # 메타데이터만 추출 (True)
        'quiet': True,
        'no_warnings': True,
        'skip_download': True,  # 다운로드 생략
        'retries': 3,  # 재시도 횟수
        'sleep_interval': 1,  # 요청 간 딜레이(초)
        'playlistreverse': True,  # 최신 영상 먼저
        'ignoreerrors': True,  # 오류무시:True
        'break_on_reject': False, # 거부 시 중단하지 않음
        'lazy_playlist': True,
        'extractor_args': {'youtube': {'lang': ['ko']}}, # 한국어로 메타데이터 요청
        'no_cache_dir': True,
        'logger': SilentLogger(),
        'verbose': False,
        
        # 'playlist_end': n_videos,  # 최대 100개 영상 확인 (최신 영상 충분히 커버) --> 안먹힌다
        'playlist_items': f'1-{n_videos}' if n_videos else None,  # 1부터 n_videos까지 항목 가져오기 --> 먹힌다 
        'match_filter': lambda info: (
            info.get('duration', 0) > duration and
            info.get('is_available', True)
        ) or None,  # 숏츠 제외
    }
    # pp.pprint(ydl_opts)

    try:
        # 채널 URL로 비디오 목록 가져오기
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            return ydl.extract_info(channel_url + "/videos", download=False)
    except Exception as e:
        _print_error(msg=f"알 수 없는 에러 ({channel_url})", e=e)




################################################################
# (Playlist)
################################################################
import re 

# 플레이리스트 정보/아이템 가져오기 
def get_playlist(playlist_url:str, n_videos:int=None):
    if re.search(r"^https://www.youtube.com/playlist", playlist_url):
        pass 
    else:
        playlist_url = f"https://www.youtube.com/playlist?list={playlist_url}"

    ydl_opts = {
        'extract_flat': False,  # 메타데이터만 추출 (True)
        'quiet': True,
        'no_warnings': True,
        # 'match_filter': lambda info: info.get('duration') > duration or None,  # 숏츠 제외
        'break_on_reject': True,
        'lazy_playlist': True,
        'skip_download': True,
        'ignoreerrors': True,  # 오류 무시 옵션 활성화
        'retries': 3,
        'sleep_interval': 1,
        # 'playlist_end': n_videos,  # 모든 항목 가져오기(최대 500?) --> 안먹힌다 
        'playlist_items': f'1-{n_videos}' if n_videos else None,  # 1부터 n_videos까지 항목 가져오기 (None이면 전체) --> 먹힌다 
        # 'noplaylist': True,
        'match_filter': lambda info: (
            info.get('duration', 0) > 60*2 and
            info.get('is_available', True)
        ) or None,  # 숏츠 제외
        'extractor_args': {'youtube': {'lang': ['ko']}}, # 한국어로 메타데이터 요청
        'no_cache_dir': True,
        'logger': SilentLogger(),
        'verbose': False,
    }
    
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        try:
            info = ydl.extract_info(playlist_url, download=False)
            return ydl.sanitize_info(info)
        except Exception as e:
            _print_error(msg=f"해당 플레이리스트({playlist_url})는 Private 입니다", e=None)




def download_playlist(playlist_url, dl_top_dir=None, **kwargs)-> str:
    # print("\n플레이리스트 메타데이터 다운로드")

    # print("\n파라미터-->")
    # pp.pprint(vars())
    dl_top_dir = get_default_download_path() if dl_top_dir is None else dl_top_dir


    info = get_playlist(playlist_url)

    if info:
        # 플레이리스트 디렉토리 생성
        playlist_name = rename_playlist(info['title'])
        outdir = os.path.join(dl_top_dir, playlist_name)
        print('\n플레이리스트 디렉토리-->', outdir)

        # 메타데이터 파일쓰기
        jsonfile = os.path.join(outdir, 'meta.json')
        ifile.write_jsonfile(jsonfile, info)

        return jsonfile 






################################################################
# (Video)
################################################################

# 영상 메타데이터 가져오기
def get_video(video_url:str, duration:int=60)-> dict:
    
    ydl_opts = {
        'extract_flat': True,  # 메타데이터만 추출
        'quiet': True,
        'no_warnings': True,
        'match_filter': lambda info: info.get('duration') > duration or None,  # 숏츠 제외
        'skip_download': True,
        'ignoreerrors': True,  # 오류 무시 옵션 활성화
        'extractor_args': {'youtube': {'lang': ['ko']}}, # 한국어로 메타데이터 요청
    }
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(video_url, download=False)
            if info:
                return ydl.sanitize_info(info)
            else:
                _print_error(msg=f"비디오 미존재, 성인인증필요, 멤버십온리 등등 ({video_url})", e=None)
    except Exception as e:
        _print_error(msg="알 수 없는 오류", e=e)
    


def download_video(url, **kwargs):
    # print("\nDownloading Video Binary...")
    # print("\n파라미터-->")
    # pp.pprint(vars())

    download_video_with_cli(url)


def _get_video_info(url, dl_top_dir):
    # 다운로드할 파일을 저장할 폴더경로
    info = get_video(url)
    ch_name = info['uploader']
    title = clean_video_title(info['title'])
    out_dir = os.path.join(dl_top_dir, ch_name)

    # 다운로드 파일의 절대경로
    out_file = os.path.join(out_dir, f"{title}.mp4")
    out_file = reduce_output(out_file)
    info.update({'out_file': out_file})
    return info 



def download_video_with_cli(url, dl_top_dir:str=None):
    # Sample command
    # yt-dlp -f bestvideo*+bestaudio/best --ffmpeg-location \"{FFMPEG_LOCATION}\" -o "%(title)s.%(ext)s" https://www.youtube.com/watch?v=Jrmb07ku6ZY&ab_channel=CristianyGabriella


    dl_top_dir = dl_top_dir if dl_top_dir else get_default_download_path()
    info = _get_video_info(url, dl_top_dir)


    # 비디오 옵션생성
    options = {
        '-f': 'bestvideo*+bestaudio/best',
        '--merge-output-format': 'mp4',
        '--ffmpeg-location': f'"{FFMPEG_LOCATION}"',
        # '--windows-filenames': '',
        '-o': f'"{info["out_file"]}"',
        # '--trim-filenames': str(260),
    }
    print("\nYdl-CLI-Options-->")
    pp.pprint(options)
    

    # 커맨드라인 생성 & 실행 
    command = 'yt-dlp'
    for k,v in options.items():
        command = command + " " + k + " " + v
    command += " " + url
    print('\nCOMMAND -->\n', command)
    subprocess.call(command, shell=True)
    
    print('\nDONE.')
    return info 



def download_video_with_ytdlp(url, dl_top_dir:str=None, cookie_browser:str=None):

    dl_top_dir = dl_top_dir if dl_top_dir else get_default_download_path()
    info = _get_video_info(url, dl_top_dir)


    # 비디오 옵션생성
    ydl_opts = {
        # 'outtmpl': f'{info["out_dir"]}\\%(title)s.%(ext)s',
        'outtmpl': info["out_file"],
        'format': 'bestvideo+bestaudio',
        'merge_output_format': 'mp4',  # 병합 최종 포맷 지정
        'verbose': True,
        'ffmpeg_location': FFMPEG_LOCATION,
    }
    if cookie_browser:
        print(f"\n{cookie_browser.capitalize()} 브라우저에서 쿠키 추출")
        ydl_opts.update({'cookiesfrombrowser': (cookie_browser,)}) 

    print("\nYdl-Python-Options-->")
    pp.pprint(ydl_opts)

    with YoutubeDL(ydl_opts) as ydl:
        ydl.download([url])
    
    out_dir = os.path.dirname(info["out_file"])
    for file in os.listdir(out_dir):
        if file.endswith(".part"):
            os.remove(os.path.join(out_dir, file))
    print('\nDONE.')
    return info 





################################################################
# (Audio)
################################################################

def download_audio_v2(url:str, dl_dir:str, **kwargs):

    # 다운로드된 파일 경로를 저장할 리스트
    downloaded_files = []

    try:
        # 진행 상황을 처리하는 훅 함수
        def progress_hook(d):
            if d['status'] == 'finished':
                # 다운로드 완료 시 파일 경로 저장
                file_path = os.path.abspath(d['filename'])
                downloaded_files.append(file_path)
                print(f"다운로드 완료: {file_path}")

        # 기본 옵션 설정
        options = {
            'format': 'bestaudio/best',  # 최고 품질 오디오
            'postprocessors': [{
                'key': 'FFmpegExtractAudio',  # 오디오 추출
                'preferredcodec': 'mp3',      # 출력 포맷 (mp3, wav 등)
                'preferredquality': '320',    # 비트레이트 설정 | 320kbps 품질 (0-9, 0이 최고품질)
            }],
            'restrictfilenames': True,  # 파일명을 안전하게 제한
            'noplaylist': True,  # 플레이리스트 전체가 아닌 단일 영상만
            'ffmpeg_location': f'"{FFMPEG_LOCATION}"',
            'outtmpl': os.path.join(dl_dir, "%(title)s.%(ext)s"), # 출력 경로
            'progress_hooks': [progress_hook],  # 진행 훅 추가
        }

        with yt_dlp.YoutubeDL(options) as ydl:
            rv = ydl.download(url)
            # rv: 0
            # print(rv)

        print(f"\ndownloaded_files-->", downloaded_files)
        return downloaded_files[0].replace(".mp4", ".mp3")
    except Exception as e:
        print(f"\nERROR | {e}")


def download_audio(url:str, audio_file:str, **kwargs):
    # Sample command
    # yt-dlp -x --audio-format mp3 --audio-quality 320k --ffmpeg-location \"{FFMPEG_LOCATION}\" --yes-playlist {URL}

    try:
        # 오디오 옵션 생성
        cli_opts = {
            '--audio-format': 'mp3',
            '--audio-quality': '320k',
            '--ffmpeg-location': f'"{FFMPEG_LOCATION}"',
            '-o': f'"{audio_file}"',
            # '-o': "%(title)s.%(ext)s",
            # '-P': f'"{dl_dir}"',
        }
        # print("\nCLI OPTIONS-->")
        # pp.pprint(cli_opts)

        
        # 커맨드라인 생성 & 실행 
        command = 'yt-dlp -x'
        for k,v in cli_opts.items():
            command = command + " " + k + " " + v
        command += " " + url
        print('\nCOMMAND -->\n', command)

        rv = subprocess.call(command, shell=True)
        return audio_file
    except Exception as e:
        print(f"\nERROR | {e}")


def download_audios_from_playlist(url, **kwargs):
    # Sample command
    # yt-dlp -x --audio-format mp3 --audio-quality 320k --ffmpeg-location \"{FFMPEG_LOCATION}\" --yes-playlist {URL}

    print("\n파라미터-->")
    params = vars()
    pp.pprint(params)
    dl_top_dir = kwargs['dl_top_dir'] if 'dl_top_dir' in kwargs else get_default_download_path()

    jsonfile = download_playlist(url, dl_top_dir=dl_top_dir)
    outdir = os.path.dirname(jsonfile)
    print("\n플레이리스트 음악들 다운로드 경로-->", outdir)


    # 오디오 옵션 생성
    options = {
        '--audio-format': 'mp3',
        '--audio-quality': '320k',
        '--ffmpeg-location': f'"{FFMPEG_LOCATION}"',
        '-o': "%(title)s.%(ext)s",
        '-P': f'"{outdir}"',
        '--yes-playlist': url,
    }
    print("\nOPTIONS-->")
    pp.pprint(options)


    # 커맨드라인 생성 & 실행 
    command = 'yt-dlp -x'
    for k,v in options.items():
        command = command + " " + k + " " + v
    print('\nCOMMAND -->\n', command)
    print("\nDownloading Audios from playlist...")
    subprocess.call(command, shell=True)
    
    print('\nDONE.')



################################################################
# (Search)
################################################################
from urllib.parse import quote

# YouTube 검색 필터 (sp 파라미터)
SP_PARAMS = {
    'upload_date': {
        'hour': 'EgIIAQ%253D%253D',      # 지난 1시간
        'today': 'EgIIAg%253D%253D',     # 오늘
        'week': 'EgIIAw%253D%253D',      # 이번 주
        'month': 'EgIIBA%253D%253D',     # 이번 달
        'year': 'EgIIBQ%253D%253D',      # 올해
    },
    'duration': {
        'short': 'EgIYAQ%253D%253D',     # 4분 미만
        'medium': 'EgIYAg%253D%253D',    # 4-20분
        'long': 'EgIYAw%253D%253D',      # 20분 이상
    },
    'sort': {
        'relevance': '',                 # 관련성 (기본값)
        'upload_date': 'CAI%253D',       # 업로드 날짜
        'view_count': 'CAM%253D',        # 조회수
        'rating': 'CAE%253D',            # 평점
    }
}


def build_sp_params(filters:dict):
    conds = []
    for k1,v1 in filters.items():
        dic = SP_PARAMS.get(k1)
        if dic:
            for k2,v2 in dic.items():
                if k2 == v1:
                    conds.append(f"sp={v2}")
                    break 
    if len(conds) > 0:
        return "&".join(conds)


"""
유튜브 영상을 검색하고, 플레이리스트를 제외하며, 기간 설정을 적용.

Parameters:
- query (str): 검색어
- n_results (int): 최대 결과 수 | None 이면 최대값 
- days (int): 검색 기간 (0: 오늘만,  1: 어제/오늘 이틀간, None 이면 제한 없음)

Returns:
- List of video details (title, url, upload_date)
"""
def search(
        query:str,
        n_results=None, 
        days=7, 
        duration=600,
        web_filter:dict={},
    ):
    params = vars()

    # 현재 날짜
    _now = datetime.now().astimezone()
    _datebefore = (_now + timedelta(days=1)).strftime("%Y%m%d")
    _dateafter = (_now - timedelta(days=days+1)).strftime("%Y%m%d")


    # yt-dlp 검색 옵션 설정
    ydl_opts = {
        'extract_flat': False,  # True: 메타데이터만 추출 | False: 상세한 메타데이터
        'quiet': True,
        'no_warnings': True,
        'skip_download': True,  # 다운로드 생략
        'retries': 3,  # 재시도 횟수
        'sleep_interval': 1,  # 요청 간 딜레이(초)
        'playlistreverse': True,  # 최신 영상 먼저
        'ignoreerrors': True,  # True: 오류무시 | False: 
        'break_on_reject': False, # 거부 시 중단하지 않음
        'lazy_playlist': True,
        'datebefore': _datebefore,
        'dateafter': _dateafter,
        # 'playlist_end': n_videos,  # 최대 100개 영상 확인 (최신 영상 충분히 커버) --> 안먹힌다
        'playlist_items': f'1-{n_results}',  # 1부터 n_videos까지 항목 가져오기 --> 먹힌다 
        # 'noplaylist': True,  # 플레이리스트 제외
        'match_filter': lambda info: (
            info.get('duration', 0) > duration and
            info.get('is_available', True)
        ) or None,  # 숏츠 제외 # 영상 길이 조건 
        'extractor_args': {'youtube': {'lang': ['ko']}}, # 한국어로 메타데이터 요청
        'no_cache_dir': True,
        'logger': SilentLogger(),
        'verbose': False,
    }

    if len(web_filter) == 0:
        # 검색어와 함께 URL 생성
        if n_results:
            search_url = f"ytsearch{n_results}:{query}"
        else:
            search_url = f"ytsearchall:{query}"
    else:
        encoded_query = quote(query)
        search_url = f"https://www.youtube.com/results?search_query={encoded_query}"
        encoded_cond = build_sp_params(web_filter)
        if encoded_cond:
            search_url = f"{search_url}&{encoded_cond}"

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            return ydl.extract_info(search_url, download=False)
    except Exception as e:
        _print_error(msg=f"알수 없는 오류 | {params}", e=e)


