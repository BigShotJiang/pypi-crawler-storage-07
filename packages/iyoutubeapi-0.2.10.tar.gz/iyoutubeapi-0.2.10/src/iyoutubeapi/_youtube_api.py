# -*- coding: utf-8 -*-
# YouTube Data API v3 


import os 
import re
from datetime import datetime, timedelta
import pickle 
import pprint 
pp = pprint.PrettyPrinter(indent=2)


from dateutil import parser
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from google.auth.transport.requests import Request





################################################################
# Internal functions
################################################################
def _print_auth_error(e):
    print(f"\nERROR | 인증 오류: {e}")
    print("해결 방법-->")
    print("1. Google Cloud Console (https://console.cloud.google.com/)에 로그인하세요.")
    print("2. 'APIs & Services' > 'OAuth consent screen'으로 이동하세요.")
    print("3. 'Test users' 섹션에서 'droga.de.nacion@gmail.com'을 추가하세요.")
    print("4. 'client_secrets.json' 파일이 올바른지 확인하세요.")
    print("5. 인증 시 'Advanced' > 'Go to KookPpongAgent (unsafe)'를 클릭하세요.")


def _print_except_error(e, msg=None):
    msg = "에러메시지" if msg is None else msg
    print(f"\nERROR | {msg} | {e}")
    if "quotaExceeded" in str(e):
        print("쿼터 초과: 내일 오후 4시(KST) 이후 재시도하거나 쿼터 증가 요청하세요.")
    else:
        if "403" in str(e):
            print("403 오류: 'droga.de.nacion@gmail.com'이 테스트 사용자로 등록되었는지 확인하세요.")
            print("Google Cloud Console > 'OAuth consent screen' > 'Test users'에서 추가하세요.")
        elif "404" in str(e):
            print("404 오류: 플레이리스트 항목 ID가 잘못되었거나 존재하지 않습니다.")
        else:
            print(f"기타 오류: {str(e)}")
    return e 




################################################################
# (Auth)
################################################################

# OAuth 2.0 인증, 토큰 저장 및 재사용
def get_authenticated_service(credential_file):
    print("\n(YouTube Data API v3) 'OAuth 2.0 인증, 토큰 저장 및 재사용' 시작...")

    # YouTube Data API 설정
    SCOPES = ["https://www.googleapis.com/auth/youtube.force-ssl"]

    TOKEN_FILE = os.path.join(os.path.dirname(credential_file), '_youtube_api_token.json')
    credentials = None
    print("\n인증 파라미터-->")
    pp.pprint(vars())
    

    if os.path.exists(TOKEN_FILE):
        try:
            with open(TOKEN_FILE, 'rb') as token:
                credentials = pickle.load(token)
            
            if credentials and credentials.expired and credentials.refresh_token:
                credentials.refresh(Request())
            print("\n토큰 유효성 확인 및 갱신-->")
            pp.pprint({
                "credentials": credentials, 
                "credentials.expired": credentials.expired, 
                "credentials.refresh_token": credentials.refresh_token
            })
        except Exception as e:
            print(f"\n토큰 로드 오류: {e}")
            credentials = None

    
    if not credentials or not credentials.valid:
        try:
            print("\n토큰 없거나 유효하지 않으면 새로 인증")
            flow = InstalledAppFlow.from_client_secrets_file(credential_file, SCOPES)
            credentials = flow.run_local_server(port=0)
            
            print("\n토큰 저장-->", TOKEN_FILE)
            with open(TOKEN_FILE, 'wb') as token:
                pickle.dump(credentials, token)
        except Exception as e:
            _print_auth_error(e)
            return None

    auth = build("youtube", "v3", credentials=credentials)
    # <class 'googleapiclient.discovery.Resource'>
    print("\nYouTube Client Auth-->", auth)
    return auth 



################################################################
# (Playlist)
################################################################

# 내 계정의 플레이리스트 가져오기
def get_my_playlists(youtube)-> list:

    playlists = []
    page_token = None

    try:
        while True:
            request = youtube.playlists().list(
                part="snippet,contentDetails",
                mine=True,  # 내 계정의 플레이리스트만 조회
                maxResults=50,  # 최대 50개 (API 제한)
                pageToken=page_token
            )
            response = request.execute()
            playlists += response.get("items", [])
            # for item in response.get("items", []):
            #     playlist_id = item["id"]
            #     item.update({
            #         "playlist_name": item["snippet"]["title"],
            #         "playlist_id": playlist_id,
            #         "playlist_url": f"https://www.youtube.com/playlist?list={playlist_id}",
            #         "description": item["snippet"].get("description", ""),
            #         "published_at": item["snippet"]["publishedAt"],
            #         "item_count": item["contentDetails"]["itemCount"]
            #     })
            #     playlists.append(item)

            page_token = response.get("nextPageToken")
            if not page_token:
                break
    except HttpError as e:
        _print_except_error(e, '플레이리스트 조회 오류')

    return playlists


# 새 플레이리스트 생성
def create_playlist(youtube, title, description="", privacy="unlisted")-> str:
    # privacy : public, private, unlisted
    try:
        request = youtube.playlists().insert(
            part="snippet,status",
            body={
                "snippet": {
                    "title": title,
                    "description": description,
                    "defaultLanguage": "ko"
                },
                "status": {
                    "privacyStatus": privacy
                }
            }
        )
        response = request.execute()
        # return response["id"]
        return response
    except HttpError as e:
        _print_except_error(e, '플레이리스트 생성 오류')
        return None


# 플레이리스트 삭제
def delete_playlist(youtube, playlist_id)-> str:
    try:
        request = youtube.playlists().delete(
            id=playlist_id
        )
        response = request.execute()
        return response
    except HttpError as e:
        _print_except_error(e, '플레이리스트 삭제 오류')





################################################################
# (Playlist Items)
################################################################

# 플레이리스트의 영상들 가져오기
# 100개 이상의 아이템을 갖고 있는 플레이리스트 일 경우 사용한다
def get_playlist_items(youtube:object, playlist_id:str)-> list:

    items = []
    page_token = None

    try:
        while True:
            request = youtube.playlistItems().list(
                part="snippet,contentDetails",
                playlistId=playlist_id,
                maxResults=1000,
                pageToken=page_token
            )
            response = request.execute()
            # print("\nRESPONSE-->", response)
            items += response.get("items", [])
            page_token = response.get("nextPageToken")
            if not page_token:
                break
    except HttpError as e:
        _print_except_error(e, '플레이리스트 항목 조회 오류')

    return items


# 플레이리스트에 영상 추가
def add_video_to_playlist(youtube, playlist_id, video_id):

    try:
        request = youtube.playlistItems().insert(
            part="snippet",
            body={
                "snippet": {
                    "playlistId": playlist_id,
                    "resourceId": {
                        "kind": "youtube#video",
                        "videoId": video_id
                    }
                }
            }
        )
        response = request.execute()
        return response
    except HttpError as e:
        _print_except_error(e, f'플레이리스트({playlist_id})에 영상 추가 오류. Video ID: {video_id}')


# 플레이리스트에서 특정 영상 제거
def remove_video_from_playlist(youtube, playlist_item_id):

    try:
        request = youtube.playlistItems().delete(
            id=playlist_item_id
        )
        response = request.execute()
        return response
    except HttpError as e:
        _print_except_error(e, '플레이리스트 항목 삭제 오류')





################################################################
# (Subscriptions)
################################################################

# 구독 중인 채널 정보 가져오기
def get_subscribed_channels(youtube)-> list:

    channels = []
    next_page_token = None

    try:
        while True:
            request = youtube.subscriptions().list(
                part="snippet,contentDetails",
                mine=True,
                maxResults=50,  # 최대 50개 항목/요청
                pageToken=next_page_token
            )
            response = request.execute()
            channels += response.get("items", [])
            # for item in response.get("items", []):
            #     channel_id = item["snippet"]["resourceId"]["channelId"]
            #     channel_name = item["snippet"]["title"]
            #     channel_url = f"https://www.youtube.com/channel/{channel_id}"
                
                # # 채널 상세 정보 (구독자 수, 영상 수)
                # channel_details = youtube.channels().list(
                #     part="snippet,statistics",
                #     id=channel_id
                # ).execute()
                
                # channel_info = channel_details["items"][0]
                # subscriber_count = channel_info["statistics"].get("subscriberCount", "N/A")
                # video_count = channel_info["statistics"].get("videoCount", "N/A")
                
                # channels.append({
                #     'subscription_id': item['id'],
                #     # "subscriber_count": int(subscriber_count),
                #     'subscribed_at': item['snippet']['publishedAt'],
                #     "channel_id": channel_id,
                #     "channel_name": channel_name,
                #     "channel_url": channel_url,
                #     # "video_count": int(video_count),
                #     'uploads_playlist_id': item.get('contentDetails', {}).get('relatedPlaylists', {}).get('uploads'),
                #     'contentDetails': item['contentDetails'],
                #     'n_all_items': item.get('contentDetails', 0).get('totalItemCount', 0),
                #     'n_new_items': item.get('contentDetails', 0).get('newItemCount', 0),
                #     'etag': item['etag'],
                #     'kind': item['kind'],
                # })
            
            next_page_token = response.get("nextPageToken")
            if not next_page_token:
                break
    except HttpError as e:
        _print_except_error(e, "API 요청 오류")
    except Exception as e:
        _print_except_error(e, "알 수 없는 오류")

    return channels


