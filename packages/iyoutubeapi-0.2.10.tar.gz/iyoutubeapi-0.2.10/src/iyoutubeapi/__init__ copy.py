# # -*- coding: utf-8 -*-


# import os 



# from iyoutubeapi import _yt_dlp, _youtube_api 



# class __YouTubeAPI__:

#     def __init__(self):
#         try:
#             self._auth = _youtube_api.get_authenticated_service(os.environ["GOOGLE_CREDENTIAL_PATH"])
#         except Exception as e:
#             print(f"\nERROR | {e} | {__file__}")

# YouTubeAuth = __YouTubeAPI__()._auth 


# class MySubscription(__YouTubeAPI__):

#     def get(self):
#         return _youtube_api.get_subscribed_channels(YouTubeAuth)
    

# class MyPlaylists(__YouTubeAPI__):

#     def get(self):
#         return _youtube_api.get_my_playlists(YouTubeAuth)
    
#     def create(self, title, description="", privacy="unlisted"):
#         return _youtube_api.create_playlist(YouTubeAuth, title, description, privacy)
    
#     def delete(self, playlist_id):
#         return _youtube_api.delete_playlist(YouTubeAuth, playlist_id)
    
#     def get_items(self, playlist_id, video_id=None):
#         return _youtube_api.delete_playlist(YouTubeAuth, playlist_id, video_id)
    
#     def add_item(self, playlist_id, video_id):
#         return _youtube_api.add_video_to_playlist(YouTubeAuth, playlist_id, video_id)
    
#     def remove_item(self, playlist_item_id):
#         return _youtube_api.remove_video_from_playlist(YouTubeAuth, playlist_item_id)



# class Channel:

#     def __init__(self, channel_url:str):
#         self.url = channel_url

#     def get(self):
#         return _yt_dlp.get_channel(self.url)
    
#     def get_videos(self,
#                     days_ago=7, 
#                     max_videos=10,
#                     min_duration=60*2
#         ):
#         return _yt_dlp.get_channel(self.url, days_ago, max_videos, min_duration)
    


# class Playlist:

#     def __init__(self, playlist_url:str):
#         self.url = playlist_url

#     def get(self, max_videos:int=None):
#         return _yt_dlp.get_playlist(self.url, max_videos)
    


# class Video:

#     def get(self, video_url:str, min_duration:int=60):
#         return _yt_dlp.get_video(video_url, min_duration)
    
#     def download(self, video_url:str):
#         return _yt_dlp.download_video(video_url)
    

# class Audio:
    
#     def download(self, video_url:str):
#         return _yt_dlp.download_audio(video_url)
    
#     def download_audios_from_playlist(self, playlist_url:str):
#         return _yt_dlp.download_audios_from_playlist(playlist_url)

