# -*- coding: utf-8 -*-


import os, sys 

sys.path.append(r"C:\pypjts\iYouTubeAPI\src")
os.environ["FFMPEG_BIN_PATH"] = r"C:/FFMPEG/ffmpeg-2025-08-07-git-fa458c7243-full_build/bin/ffmpeg.exe"
import iyoutubeapi 
from iyoutubeapi import _yt_dlp, _youtube_api


GOOGLE_API_AUTH = _youtube_api.get_authenticated_service(r"E:/내 드라이브/__CREDENTIALS__/Google/droga.de.nacion/OAuth 2.0 Client IDs/KookPpongAgent/client_secret.json")

SAMPLE_DATA_DIR = r"C:\pypjts\iYouTubeAPI\data\SampleData"



import json 

def write_jsonfile(file, data):
    os.makedirs(os.path.dirname(file), exist_ok=True)
    with open(file, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


class __Executor__:

    def run(self, func_nos:list):
        for no in func_nos:
            print(f"\nTEST FUNCTION-{no}")
            getattr(self, f"test{str(no).zfill(2)}")()



class YT_DLP(__Executor__):

    def _write(self, file, data):
        file = os.path.join(SAMPLE_DATA_DIR, "yt-dlp", file)
        write_jsonfile(file, data)    

    # 플레이리스트
    def test01(self):
        info = _yt_dlp.get_playlist(
            playlist_url="https://www.youtube.com/playlist?list=PLCndjc5L5W-_NnSErQpl5BvNOT32kKNTb", # Gen_퀀텀컴퓨팅
            # playlist_url="https://www.youtube.com/playlist?list=PLCndjc5L5W-8zABOX3tVOnmdmyOoz7fjI", # Gen_비트코인
            n_videos=None 
        )
        self._write(r"get_playlist.json", info)

    # 비디오
    def test02(self):
        info = _yt_dlp.get_video('https://www.youtube.com/watch?v=A2SG7fKjW48')
        self._write(r"get_video.json", info)

    # 채널
    def test03(self):
        info = _yt_dlp.get_channel("https://www.youtube.com/@연애유치원")
        self._write(r"get_channel.json", info)

    # 채널영상
    def test04(self):
        info = _yt_dlp.get_channel_videos(
            channel_url='https://www.youtube.com/@연애유치원',
            n_videos=10,
            duration=60
        )
        self._write(r"get_channel_videos.json", info)

    # 검색
    def test05(self):
        info = _yt_dlp.search(
            query="intitle:아파트",
            n_results=1,
            days=1, 
            duration=600,
            web_filter={'upload_date': 'today'},
        )
        self._write(r"search.json", info)



class YouTubeDataAPI(__Executor__):

    def _write(self, file, data):
        file = os.path.join(SAMPLE_DATA_DIR, "YouTubeDataAPI", file)
        write_jsonfile(file, data)
    
    def test01(self):
        info = _youtube_api.get_my_playlists(GOOGLE_API_AUTH)
        self._write(r"get_my_playlists.json", info)

    def test02(self):
        info = _youtube_api.create_playlist(youtube=GOOGLE_API_AUTH, title="Gen_Test", description="", privacy="unlisted")
        self._write(r"create_playlist.json", info)

    def test03(self):
        info = _youtube_api.delete_playlist(youtube=GOOGLE_API_AUTH, playlist_id="PLCndjc5L5W-8Fo-E3X2gkpBpaIeCjNSsW")
        self._write(r"delete_playlist.json", info)

    # 내꺼든, 남에 꺼든, 결과는 똑같다
    def test04(self):
        info = _youtube_api.get_playlist_items(
            youtube=GOOGLE_API_AUTH,
            playlist_id="PLCndjc5L5W-9SN0R1vmFVLD0TloZDCa5d",# Gen_남녀
        )
        self._write(r"get_playlist_items.json", info)

    def test05(self):
        info = _youtube_api.add_video_to_playlist(
            youtube=GOOGLE_API_AUTH, 
            playlist_id="PLCndjc5L5W-9d2NF_wP-619FDAjcIaBaX", 
            video_id="H7Ht_och620"
        )
        self._write(r"add_video_to_playlist.json", info)

    def test06(self):
        info = _youtube_api.remove_video_from_playlist(
            youtube=GOOGLE_API_AUTH, 
            playlist_item_id="UExDbmRqYzVMNVctOWQyTkZfd1AtNjE5RkRBamNJYUJhWC41MjE1MkI0OTQ2QzJGNzNG"
        )
        self._write(r"remove_video_from_playlist.json", info)


    def test07(self):
        info = _youtube_api.get_subscribed_channels(GOOGLE_API_AUTH)
        self._write(r"get_subscribed_channels.json", info)




class iYouTubeAPI(__Executor__):

    def _write(self, file, data):
        file = os.path.join(r"C:\pypjts\iYouTubeAPI\tests\Sample Data\iYouTubeAPI", file)
        write_jsonfile(file, data)
    
    # 구독채널
    def test01(self):
        my_sub = iyoutubeapi.MySubscription()
        info = my_sub.get()
        self._write("MySubscription.json", info)

    # MY플레이리스트
    def test02(self):
        my_pl = iyoutubeapi.MyPlaylists()
        info = my_pl.get()
        self._write("MyPlaylists.json", info)
        




print("\n\n메인 시작...")


YT_DLP().run([1,2,3,4,5])
# YouTubeDataAPI().test06()


print("\n프로세스 종료")
sys.exit(1)



