# iYouTubeAPI
Innovata YouTube API


## Introduction 




## Dependency 설치 

    requests
    moviepy
    yt-dlp
    ffmpeg
    google-auth-oauthlib 
    google-api-python-client

한번에 설치 

    pip install requests moviepy yt-dlp ffmpeg google-auth-oauthlib google-api-python-client python-dateutil


## 사용법 

### [1] 환경셋업 

필수 전역변수 셋업 

    os.environ["GOOGLE_CREDENTIAL_PATH"] = "YOUR_GOOGLE_CREDENTIAL_PATH"
    os.environ["FFMPEG_BIN_PATH"] = "YOUR_FFMPEG_BIN_PATH"



### [2] 구독채널 

    from iyoutube import _youtube_api 
    info = _youtube_api.get_subscribed_channels()
    <!-- info: list -->



### [3] MY 플레이리스트 

    from iyoutube import _youtube_api 
    info = _youtube_api.get_my_playlists()
    <!-- info: list -->


### [4] 채널정보 

    from iyoutube import _yt_dlp 
    info = _yt_dlp.get_channel(channel_url)
    <!-- info: dict -->


### [5] 채널 최신영상

    from iyoutube import _yt_dlp 
    info = _yt_dlp.get_channel_videos(
        channel_url, 
        days_ago=7, 
        max_videos=10,
        min_duration=60
    )
    <!-- info: dict -->


### [6] 일반 플레이리스트 

    from iyoutube import _yt_dlp 
    info = _yt_dlp.get_playlist(playlist_url, max_videos=None)
    <!-- info: dict -->


### [7] 비디오 

    from iyoutube import _yt_dlp 
    info = _yt_dlp.get_video(video_url)
    <!-- info: dict -->


### [8] 오디오 

    from iyoutube import _yt_dlp 
    info = _yt_dlp.download_audio(video_url, audio_file)
    <!-- info: dict -->


### [9] 검색 

    from iyoutube import _yt_dlp 
    info = _yt_dlp.search(
        query,
        max_results=None, 
        days_ago=7, 
        duration=600,
        ytweb_filters:dict={},
    )
    <!-- info: dict -->



