from ._native import convert_json_to_parquet

__all__ = ["convert_json_to_parquet"]
