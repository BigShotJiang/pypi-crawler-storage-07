"""Agent service protobuf definitions."""
