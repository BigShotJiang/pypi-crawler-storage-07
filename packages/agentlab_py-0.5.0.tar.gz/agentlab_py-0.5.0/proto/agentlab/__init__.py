"""AgentLab proto definitions."""
