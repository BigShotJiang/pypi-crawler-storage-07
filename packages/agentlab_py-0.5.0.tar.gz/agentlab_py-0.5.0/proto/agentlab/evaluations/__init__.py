"""Evaluations service protobuf definitions."""
