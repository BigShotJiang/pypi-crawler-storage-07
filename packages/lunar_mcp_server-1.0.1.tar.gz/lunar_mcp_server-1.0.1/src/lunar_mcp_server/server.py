"""
Main MCP server implementation for Lunar Calendar services.
"""

import asyncio
import json
import logging
from typing import Any

from mcp.server import Server
from mcp.server.lowlevel import NotificationOptions
from mcp.types import TextContent, Tool

from .auspicious_dates import AuspiciousDateChecker
from .calendar_conversions import CalendarConverter
from .festivals import FestivalManager
from .lunar_calculations import LunarCalculator


class LunarMCPServer:
    """MCP Server for Lunar Calendar operations."""

    def __init__(self) -> None:
        self.server = Server("lunar-mcp-server", version="0.1.0")
        self.lunar_calc = LunarCalculator()
        self.auspicious_checker = AuspiciousDateChecker()
        self.festival_manager = FestivalManager()
        self.calendar_converter = CalendarConverter()
        self._setup_handlers()

    def _setup_handlers(self) -> None:
        """Set up MCP server handlers."""

        @self.server.list_tools()
        async def handle_list_tools() -> list[Tool]:
            """List available tools."""
            return [
                Tool(
                    name="check_auspicious_date",
                    description="Analyzes whether a specific date is favorable for particular activities based on traditional Chinese calendar principles, including zodiac signs, five elements, lunar mansions, and other cultural factors. Returns a comprehensive score (0-10), auspiciousness level (very_good/good/neutral/poor/very_poor), and detailed analysis including what the date is good for and what to avoid.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "date": {
                                "type": "string",
                                "description": "Date in YYYY-MM-DD format",
                            },
                            "activity": {
                                "type": "string",
                                "description": "Activity type (e.g., wedding, business_opening, travel)",
                            },
                            "culture": {
                                "type": "string",
                                "description": "Cultural tradition (chinese)",
                                "default": "chinese",
                            },
                        },
                        "required": ["date", "activity"],
                    },
                ),
                Tool(
                    name="find_good_dates",
                    description="Searches through a specified date range to identify the most auspicious dates for a particular activity. This tool evaluates each date in the range using traditional Chinese calendar methods and returns the top favorable dates ranked by their auspiciousness score. Ideal for planning important events like weddings, business openings, or travel. You can limit the number of results to get only the best options.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "start_date": {
                                "type": "string",
                                "description": "Start date in YYYY-MM-DD format",
                            },
                            "end_date": {
                                "type": "string",
                                "description": "End date in YYYY-MM-DD format",
                            },
                            "activity": {
                                "type": "string",
                                "description": "Activity type",
                            },
                            "culture": {
                                "type": "string",
                                "description": "Cultural tradition",
                                "default": "chinese",
                            },
                            "limit": {
                                "type": "integer",
                                "description": "Maximum number of dates to return",
                                "default": 10,
                            },
                        },
                        "required": ["start_date", "end_date", "activity"],
                    },
                ),
                Tool(
                    name="get_daily_fortune",
                    description="Provides comprehensive daily fortune analysis based on traditional Chinese almanac (通胜/黄历). Returns detailed information about the day's general energy, lucky directions, favorable colors, what activities are suitable, what to avoid, and overall fortune predictions. This gives a holistic view of the day's auspiciousness beyond specific activities.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "date": {
                                "type": "string",
                                "description": "Date in YYYY-MM-DD format",
                            },
                            "culture": {
                                "type": "string",
                                "description": "Cultural tradition",
                                "default": "chinese",
                            },
                        },
                        "required": ["date"],
                    },
                ),
                Tool(
                    name="check_zodiac_compatibility",
                    description="Analyzes the compatibility between two dates based on their Chinese zodiac animals and five elements. This is traditionally used for checking compatibility between birth dates for relationships, partnerships, or selecting compatible dates for joint ventures. Returns compatibility score, detailed analysis of how the zodiac signs interact, and recommendations.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "date1": {
                                "type": "string",
                                "description": "First date in YYYY-MM-DD format",
                            },
                            "date2": {
                                "type": "string",
                                "description": "Second date in YYYY-MM-DD format",
                            },
                            "culture": {
                                "type": "string",
                                "description": "Cultural tradition",
                                "default": "chinese",
                            },
                        },
                        "required": ["date1", "date2"],
                    },
                ),
                Tool(
                    name="get_lunar_festivals",
                    description="Retrieves all traditional festivals and cultural celebrations occurring on a specific date. For Chinese culture, this includes major festivals like Spring Festival (Chinese New Year), Mid-Autumn Festival, Dragon Boat Festival, and many others. Returns festival names, significance, traditional customs, and cultural importance of each celebration.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "date": {
                                "type": "string",
                                "description": "Date in YYYY-MM-DD format",
                            },
                            "culture": {
                                "type": "string",
                                "description": "Cultural tradition",
                                "default": "chinese",
                            },
                        },
                        "required": ["date"],
                    },
                ),
                Tool(
                    name="get_next_festival",
                    description="Finds the next upcoming traditional festival after a given reference date. Useful for planning ahead and understanding which cultural celebration is approaching. Returns the festival name, exact date when it occurs, days remaining until the festival, and brief information about its significance and traditions.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "date": {
                                "type": "string",
                                "description": "Reference date in YYYY-MM-DD format",
                            },
                            "culture": {
                                "type": "string",
                                "description": "Cultural tradition",
                                "default": "chinese",
                            },
                        },
                        "required": ["date"],
                    },
                ),
                Tool(
                    name="get_festival_details",
                    description="Provides in-depth information about a specific traditional festival including its historical origins, cultural significance, traditional customs and practices, symbolic meanings, typical foods, activities, and how it's celebrated. Perfect for learning about cultural traditions or planning authentic festival celebrations.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "festival_name": {
                                "type": "string",
                                "description": "Name of the festival",
                            },
                            "culture": {
                                "type": "string",
                                "description": "Cultural tradition",
                                "default": "chinese",
                            },
                        },
                        "required": ["festival_name"],
                    },
                ),
                Tool(
                    name="get_annual_festivals",
                    description="Generates a complete calendar of all traditional festivals for an entire year. Returns a chronologically ordered list of all cultural celebrations including their dates (both solar and lunar), names, and brief descriptions. Excellent for creating cultural event calendars, planning year-round celebrations, or understanding the annual rhythm of traditional observances.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "year": {"type": "integer", "description": "Year"},
                            "culture": {
                                "type": "string",
                                "description": "Cultural tradition",
                                "default": "chinese",
                            },
                        },
                        "required": ["year"],
                    },
                ),
                Tool(
                    name="get_moon_phase",
                    description="Calculates precise moon phase information for a specific date and location using astronomical algorithms. Returns the moon phase name (new moon, waxing crescent, first quarter, waxing gibbous, full moon, waning gibbous, last quarter, waning crescent), illumination percentage, moon age in days, rise/set times, and position data. Location-aware calculations provide accurate local times.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "date": {
                                "type": "string",
                                "description": "Date in YYYY-MM-DD format",
                            },
                            "location": {
                                "type": "string",
                                "description": "Location for calculations (lat,lon or city name)",
                                "default": "0,0",
                            },
                        },
                        "required": ["date"],
                    },
                ),
                Tool(
                    name="get_moon_calendar",
                    description="Creates a comprehensive monthly calendar showing moon phases for each day of the month. Displays daily moon phase names, illumination percentages, and highlights important lunar events (new moons, full moons, quarters). Perfect for gardening, fishing, photography planning, or any activities influenced by lunar cycles. Provides both visual and detailed numerical moon data.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "month": {"type": "integer", "description": "Month (1-12)"},
                            "year": {"type": "integer", "description": "Year"},
                            "location": {
                                "type": "string",
                                "description": "Location for calculations",
                                "default": "0,0",
                            },
                        },
                        "required": ["month", "year"],
                    },
                ),
                Tool(
                    name="get_moon_influence",
                    description="Analyzes how the moon's phase on a specific date influences various activities based on traditional beliefs and lunar wisdom. Different moon phases are believed to affect activities differently - e.g., new moons for new beginnings, full moons for completion, waxing moons for growth activities. Returns recommendations on whether the lunar phase supports or hinders the specified activity, with detailed explanations of the lunar influence.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "date": {
                                "type": "string",
                                "description": "Date in YYYY-MM-DD format",
                            },
                            "activity": {
                                "type": "string",
                                "description": "Activity type",
                            },
                        },
                        "required": ["date", "activity"],
                    },
                ),
                Tool(
                    name="predict_moon_phases",
                    description="Predicts and lists all major moon phase transitions (new moons, first quarters, full moons, last quarters) within a specified date range. Provides exact dates and times for each lunar phase event. Useful for planning activities around specific moon phases, scheduling lunar observations, or understanding the lunar cycle progression over time. Includes astronomical accuracy for reliable predictions.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "start_date": {
                                "type": "string",
                                "description": "Start date in YYYY-MM-DD format",
                            },
                            "end_date": {
                                "type": "string",
                                "description": "End date in YYYY-MM-DD format",
                            },
                        },
                        "required": ["start_date", "end_date"],
                    },
                ),
                Tool(
                    name="solar_to_lunar",
                    description="Converts Gregorian (solar) calendar dates to traditional lunar calendar dates. Returns the corresponding lunar year, month, day, and leap month information if applicable. For Chinese calendar, also includes the year's zodiac animal, heavenly stem and earthly branch designations. Essential for finding lunar dates for traditional festivals, birth dates, or cultural events that follow the lunar calendar.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "solar_date": {
                                "type": "string",
                                "description": "Solar date in YYYY-MM-DD format",
                            },
                            "culture": {
                                "type": "string",
                                "description": "Cultural tradition",
                                "default": "chinese",
                            },
                        },
                        "required": ["solar_date"],
                    },
                ),
                Tool(
                    name="lunar_to_solar",
                    description="Converts traditional lunar calendar dates to Gregorian (solar) calendar dates. Accurately handles leap months and provides the exact solar date equivalent. Useful for determining when lunar-based festivals occur on the solar calendar, converting lunar birth dates to solar dates, or scheduling events based on lunar calendar information. Includes validation for proper lunar date formats.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "lunar_date": {
                                "type": "string",
                                "description": "Lunar date in YYYY-MM-DD format",
                            },
                            "culture": {
                                "type": "string",
                                "description": "Cultural tradition",
                                "default": "chinese",
                            },
                        },
                        "required": ["lunar_date"],
                    },
                ),
                Tool(
                    name="get_zodiac_info",
                    description="Retrieves comprehensive zodiac information for a specific date. For Chinese zodiac, returns the zodiac animal (one of 12: Rat, Ox, Tiger, Rabbit, Dragon, Snake, Horse, Goat, Monkey, Rooster, Dog, Pig), associated element (Wood, Fire, Earth, Metal, Water), personality traits, compatible signs, lucky numbers, colors, and cultural significance. Provides both yearly and daily zodiac information based on the heavenly stems and earthly branches system.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "date": {
                                "type": "string",
                                "description": "Date in YYYY-MM-DD format",
                            },
                            "culture": {
                                "type": "string",
                                "description": "Cultural tradition",
                                "default": "chinese",
                            },
                        },
                        "required": ["date"],
                    },
                ),
                Tool(
                    name="batch_check_dates",
                    description="Efficiently analyzes multiple dates simultaneously for a specific activity's auspiciousness. Processes up to 30 dates in a single request, returning scores and levels for each date. Also identifies and highlights the best and worst dates in the batch. This bulk analysis tool is perfect for quickly evaluating several potential dates for an event, comparing options across a non-continuous date range, or conducting comparative analysis of multiple candidates.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "dates": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "Array of dates in YYYY-MM-DD format",
                            },
                            "activity": {
                                "type": "string",
                                "description": "Activity type",
                            },
                            "culture": {
                                "type": "string",
                                "description": "Cultural tradition",
                                "default": "chinese",
                            },
                        },
                        "required": ["dates", "activity"],
                    },
                ),
                Tool(
                    name="compare_dates",
                    description="Performs comprehensive side-by-side comparison of multiple dates (up to 10) across various dimensions. For each date, returns auspiciousness analysis (if activity specified), moon phase details, festivals occurring, and zodiac information. Presents all information in an organized comparative format, making it easy to see differences and similarities. If an activity is specified, also provides a recommendation for which date is most suitable. Ideal for final decision-making between several good options.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "dates": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "Array of dates to compare",
                            },
                            "activity": {
                                "type": "string",
                                "description": "Activity type for comparison",
                            },
                            "culture": {
                                "type": "string",
                                "description": "Cultural tradition",
                                "default": "chinese",
                            },
                        },
                        "required": ["dates"],
                    },
                ),
                Tool(
                    name="get_lucky_hours",
                    description="Identifies the most auspicious hours within a specific day based on traditional Chinese time divisions (12 two-hour periods corresponding to the 12 zodiac animals). Each period is analyzed and scored for general favorability and activity-specific suitability. Returns detailed information for each time period including its Chinese name, zodiac animal, auspiciousness score, suitable activities, and recommendations. Perfect for timing important activities, meetings, ceremonies, or decisions within a chosen date for maximum favorable energy.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "date": {
                                "type": "string",
                                "description": "Date in YYYY-MM-DD format",
                            },
                            "activity": {
                                "type": "string",
                                "description": "Activity type",
                            },
                            "culture": {
                                "type": "string",
                                "description": "Cultural tradition",
                                "default": "chinese",
                            },
                        },
                        "required": ["date"],
                    },
                ),
            ]

        @self.server.call_tool()
        async def handle_call_tool(
            name: str, arguments: dict[str, Any]
        ) -> list[TextContent]:
            """Handle tool calls."""
            try:
                if name == "check_auspicious_date":
                    result = await self._check_auspicious_date(**arguments)
                elif name == "find_good_dates":
                    result = await self._find_good_dates(**arguments)
                elif name == "get_daily_fortune":
                    result = await self._get_daily_fortune(**arguments)
                elif name == "check_zodiac_compatibility":
                    result = await self._check_zodiac_compatibility(**arguments)
                elif name == "get_lunar_festivals":
                    result = await self._get_lunar_festivals(**arguments)
                elif name == "get_next_festival":
                    result = await self._get_next_festival(**arguments)
                elif name == "get_festival_details":
                    result = await self._get_festival_details(**arguments)
                elif name == "get_annual_festivals":
                    result = await self._get_annual_festivals(**arguments)
                elif name == "get_moon_phase":
                    result = await self._get_moon_phase(**arguments)
                elif name == "get_moon_calendar":
                    result = await self._get_moon_calendar(**arguments)
                elif name == "get_moon_influence":
                    result = await self._get_moon_influence(**arguments)
                elif name == "predict_moon_phases":
                    result = await self._predict_moon_phases(**arguments)
                elif name == "solar_to_lunar":
                    result = await self._solar_to_lunar(**arguments)
                elif name == "lunar_to_solar":
                    result = await self._lunar_to_solar(**arguments)
                elif name == "get_zodiac_info":
                    result = await self._get_zodiac_info(**arguments)
                elif name == "batch_check_dates":
                    result = await self._batch_check_dates(**arguments)
                elif name == "compare_dates":
                    result = await self._compare_dates(**arguments)
                elif name == "get_lucky_hours":
                    result = await self._get_lucky_hours(**arguments)
                else:
                    raise ValueError(f"Unknown tool: {name}")

                return [TextContent(type="text", text=json.dumps(result, indent=2))]

            except Exception as e:
                error_result = {"error": str(e), "tool": name}
                return [
                    TextContent(type="text", text=json.dumps(error_result, indent=2))
                ]

    async def _check_auspicious_date(
        self, date: str, activity: str, culture: str = "chinese"
    ) -> dict[str, Any]:
        """Check if a date is auspicious for an activity."""
        return await self.auspicious_checker.check_date(date, activity, culture)

    async def _find_good_dates(
        self,
        start_date: str,
        end_date: str,
        activity: str,
        culture: str = "chinese",
        limit: int = 10,
    ) -> dict[str, Any]:
        """Find good dates in a range."""
        return await self.auspicious_checker.find_good_dates(
            start_date, end_date, activity, culture, limit
        )

    async def _get_daily_fortune(
        self, date: str, culture: str = "chinese"
    ) -> dict[str, Any]:
        """Get daily fortune information."""
        return await self.auspicious_checker.get_daily_fortune(date, culture)

    async def _check_zodiac_compatibility(
        self, date1: str, date2: str, culture: str = "chinese"
    ) -> dict[str, Any]:
        """Check zodiac compatibility between dates."""
        return await self.auspicious_checker.check_zodiac_compatibility(
            date1, date2, culture
        )

    async def _get_lunar_festivals(
        self, date: str, culture: str = "chinese"
    ) -> dict[str, Any]:
        """Get festivals for a date."""
        return await self.festival_manager.get_festivals_for_date(date, culture)

    async def _get_next_festival(
        self, date: str, culture: str = "chinese"
    ) -> dict[str, Any]:
        """Get next festival after date."""
        return await self.festival_manager.get_next_festival(date, culture)

    async def _get_festival_details(
        self, festival_name: str, culture: str = "chinese"
    ) -> dict[str, Any]:
        """Get detailed festival information."""
        return await self.festival_manager.get_festival_details(festival_name, culture)

    async def _get_annual_festivals(
        self, year: int, culture: str = "chinese"
    ) -> dict[str, Any]:
        """Get all festivals for a year."""
        return await self.festival_manager.get_annual_festivals(year, culture)

    async def _get_moon_phase(self, date: str, location: str = "0,0") -> dict[str, Any]:
        """Get moon phase for date and location."""
        return await self.lunar_calc.get_moon_phase(date, location)

    async def _get_moon_calendar(
        self, month: int, year: int, location: str = "0,0"
    ) -> dict[str, Any]:
        """Get monthly moon calendar."""
        return await self.lunar_calc.get_moon_calendar(month, year, location)

    async def _get_moon_influence(self, date: str, activity: str) -> dict[str, Any]:
        """Get moon influence on activity."""
        return await self.lunar_calc.get_moon_influence(date, activity)

    async def _predict_moon_phases(
        self, start_date: str, end_date: str
    ) -> dict[str, Any]:
        """Predict moon phases in date range."""
        return await self.lunar_calc.predict_moon_phases(start_date, end_date)

    async def _solar_to_lunar(
        self, solar_date: str, culture: str = "chinese"
    ) -> dict[str, Any]:
        """Convert solar to lunar date."""
        return await self.calendar_converter.solar_to_lunar(solar_date, culture)

    async def _lunar_to_solar(
        self, lunar_date: str, culture: str = "chinese"
    ) -> dict[str, Any]:
        """Convert lunar to solar date."""
        return await self.calendar_converter.lunar_to_solar(lunar_date, culture)

    async def _get_zodiac_info(
        self, date: str, culture: str = "chinese"
    ) -> dict[str, Any]:
        """Get zodiac information for date."""
        return await self.calendar_converter.get_zodiac_info(date, culture)

    async def _batch_check_dates(
        self, dates: list[str], activity: str, culture: str = "chinese"
    ) -> dict[str, Any]:
        """Check multiple dates at once for efficiency."""
        results = []
        for date in dates[:30]:  # Limit to 30 dates to prevent abuse
            try:
                check_result = await self.auspicious_checker.check_date(
                    date, activity, culture
                )
                results.append(
                    {
                        "date": date,
                        "score": check_result.get("score", 0),
                        "level": check_result.get("auspicious_level", "unknown"),
                        "details": check_result,
                    }
                )
            except Exception as e:
                results.append({"date": date, "error": str(e)})

        # Find best and worst dates
        valid_results = [r for r in results if "score" in r]
        best_date = (
            max(valid_results, key=lambda x: x["score"]) if valid_results else None
        )
        worst_date = (
            min(valid_results, key=lambda x: x["score"]) if valid_results else None
        )

        return {
            "total_checked": len(results),
            "results": results,
            "best_date": best_date["date"] if best_date else None,
            "worst_date": worst_date["date"] if worst_date else None,
            "activity": activity,
            "culture": culture,
        }

    async def _compare_dates(
        self, dates: list[str], activity: str | None = None, culture: str = "chinese"
    ) -> dict[str, Any]:
        """Compare multiple dates side-by-side."""
        comparison = {}

        for date in dates[:10]:  # Limit to 10 dates for comparison
            try:
                # Get multiple aspects of the date
                aspects = {}

                if activity:
                    auspicious = await self.auspicious_checker.check_date(
                        date, activity, culture
                    )
                    aspects["auspicious_level"] = auspicious.get("auspicious_level")
                    aspects["score"] = auspicious.get("score")
                    aspects["good_for"] = auspicious.get("good_for", [])
                    aspects["avoid"] = auspicious.get("avoid", [])

                moon = await self.lunar_calc.get_moon_phase(date, "0,0")
                aspects["moon_phase"] = moon.get("phase_name")
                aspects["moon_illumination"] = moon.get("illumination")

                festivals = await self.festival_manager.get_festivals_for_date(
                    date, culture
                )
                aspects["festivals"] = [
                    f.get("name") for f in festivals.get("festivals", [])
                ]

                zodiac = await self.calendar_converter.get_zodiac_info(date, culture)
                aspects["zodiac"] = zodiac.get("zodiac", {})

                comparison[date] = aspects

            except Exception as e:
                comparison[date] = {"error": str(e)}

        # Add recommendation if activity provided
        recommendation = None
        if activity and comparison:
            scores: dict[str, int] = {}
            for d, data in comparison.items():
                if "score" in data:
                    score_val = data.get("score", 0)
                    scores[d] = int(score_val) if score_val is not None else 0
            if scores:
                recommendation = max(scores, key=lambda x: scores[x])

        return {
            "comparison": comparison,
            "recommendation": recommendation,
            "activity": activity,
            "culture": culture,
        }

    async def _get_lucky_hours(
        self, date: str, activity: str | None = None, culture: str = "chinese"
    ) -> dict[str, Any]:
        """Get auspicious hours within a specific day."""
        # Traditional Chinese lucky hours based on stems and branches
        # This is a simplified implementation
        lucky_hours = []

        # Get the daily fortune first to understand the day's energy
        daily_fortune = await self.auspicious_checker.get_daily_fortune(date, culture)

        # Define traditional time periods (12 two-hour periods in Chinese tradition)
        time_periods = [
            ("23:00-01:00", "Zi (子)", "Rat"),
            ("01:00-03:00", "Chou (丑)", "Ox"),
            ("03:00-05:00", "Yin (寅)", "Tiger"),
            ("05:00-07:00", "Mao (卯)", "Rabbit"),
            ("07:00-09:00", "Chen (辰)", "Dragon"),
            ("09:00-11:00", "Si (巳)", "Snake"),
            ("11:00-13:00", "Wu (午)", "Horse"),
            ("13:00-15:00", "Wei (未)", "Goat"),
            ("15:00-17:00", "Shen (申)", "Monkey"),
            ("17:00-19:00", "You (酉)", "Rooster"),
            ("19:00-21:00", "Xu (戌)", "Dog"),
            ("21:00-23:00", "Hai (亥)", "Pig"),
        ]

        # Simplified scoring: some hours are traditionally more auspicious
        # Dragon (07:00-09:00) and Horse (11:00-13:00) hours are generally favorable
        auspicious_indices = [4, 6, 9]  # Dragon, Horse, Rooster hours

        for idx, (time_range, period_name, zodiac_animal) in enumerate(time_periods):
            score = 5  # Base score

            if idx in auspicious_indices:
                score += 3

            if activity:
                # Adjust based on activity type
                if activity in ["business_opening", "signing_contract"] and idx in [
                    4,
                    6,
                ]:
                    score += 2
                elif activity in ["wedding", "celebration"] and idx in [6, 9]:
                    score += 2

            level = "very_good" if score >= 8 else "good" if score >= 6 else "fair"

            lucky_hours.append(
                {
                    "time_range": time_range,
                    "period": period_name,
                    "zodiac_animal": zodiac_animal,
                    "score": score,
                    "level": level,
                    "suitable_for": self._get_suitable_activities(
                        zodiac_animal, activity
                    ),
                }
            )

        # Sort by score
        lucky_hours.sort(
            key=lambda x: int(x["score"]) if isinstance(x["score"], (int, str)) else 0,
            reverse=True,
        )

        # Filter best hours (score >= 7)
        best_hours_list: list[dict[str, Any]] = []
        for h in lucky_hours:
            score_val = h.get("score")
            if isinstance(score_val, int) and score_val >= 7:
                best_hours_list.append(h)

        return {
            "date": date,
            "activity": activity,
            "culture": culture,
            "lucky_hours": lucky_hours,
            "best_hours": best_hours_list,
            "daily_overview": daily_fortune,
        }

    def _get_suitable_activities(
        self, zodiac_animal: str, requested_activity: str | None = None
    ) -> list[str]:
        """Get suitable activities for a zodiac hour."""
        activity_map = {
            "Dragon": ["business_opening", "signing_contract", "important_meetings"],
            "Horse": ["wedding", "celebration", "social_events"],
            "Rooster": ["communication", "negotiation", "presentations"],
            "Tiger": ["starting_new_projects", "bold_initiatives"],
            "Rabbit": ["artistic_work", "meditation", "planning"],
            "Rat": ["financial_planning", "investments"],
            "Ox": ["hard_work", "construction", "farming"],
            "Snake": ["strategy", "research", "wisdom_seeking"],
            "Goat": ["family_matters", "nurturing", "creativity"],
            "Monkey": ["problem_solving", "innovation", "learning"],
            "Dog": ["security_matters", "protection", "loyalty_building"],
            "Pig": ["rest", "enjoyment", "social_gatherings"],
        }

        return activity_map.get(zodiac_animal, ["general_activities"])

    async def run(self, transport_type: str = "stdio") -> None:
        """Run the MCP server."""
        if transport_type == "stdio":
            from mcp.server.stdio import stdio_server

            async with stdio_server() as (read_stream, write_stream):
                await self.server.run(
                    read_stream,
                    write_stream,
                    self.server.create_initialization_options(
                        notification_options=NotificationOptions(tools_changed=True)
                    ),
                )


async def _run_server() -> None:
    """Start the MCP server event loop."""
    server = LunarMCPServer()
    await server.run()


def main() -> None:
    """Synchronous entry point for console scripts."""
    logging.basicConfig(level=logging.INFO)
    asyncio.run(_run_server())


if __name__ == "__main__":
    main()
