"""Differentiable parametric curves in arbitrary dimensions."""

from torchcurves import types as types

from .modules import *  # noqa: F403
