API Documentation
=================

.. toctree::
   torchcurves
   torchcurves.functional
