TorchCurves documentation
=========================
.. toctree::
   :caption: API
   :maxdepth: 1

   torchcurves
   torchcurves.functional

.. toctree::
   :caption: Examples
   :maxdepth: 2

   example_notebooks
