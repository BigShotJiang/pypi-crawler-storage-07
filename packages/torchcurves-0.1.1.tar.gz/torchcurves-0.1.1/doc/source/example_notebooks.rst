Example notebooks
=================

.. toctree::
    :maxdepth: 1

    examples/draw_bspline
    examples/draw_legendre
    examples/kan_bspline_rat
    examples/kan_legendre_rat
    examples/factorization_machine
    examples/transformer_mixed_curves
