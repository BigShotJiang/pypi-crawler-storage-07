__version__ = "0.0.0"

def info():
    return "This is a dummy require_relative package for PyPI."
