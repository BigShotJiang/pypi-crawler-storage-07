# require_relative\nA dummy Python package version of require_relative.
