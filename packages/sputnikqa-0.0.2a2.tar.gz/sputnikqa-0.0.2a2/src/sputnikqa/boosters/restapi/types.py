from typing import TypeVar

# Общий тип для всего API фреймворка
HttpResponse = TypeVar("HttpResponse")