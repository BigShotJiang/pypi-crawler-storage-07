<template>
  <v-toolbar-items>
    <j-tooltip tipid='create-image-viewer'>
      <v-btn icon tile @click="create_image_viewer()">
        <v-icon>mdi-image-plus</v-icon>
      </v-btn>
    </j-tooltip>
  </v-toolbar-items>
</template>
