<template>
  <j-tooltip
    tooltipcontent="plugin results automatically update"
    span_style="display: inline-block"
  >
    <v-icon dense>mdi-reload-alert</v-icon>
  </j-tooltip>
</template>

<script>
  module.exports = {
    props: []
  };
</script>