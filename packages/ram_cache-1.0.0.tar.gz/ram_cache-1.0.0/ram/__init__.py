import json
import time
import threading
from queue import Queue

class RAM:
    def __init__(self, max_size=100, ttl=None, max_workers=5):
        """
        max_size: número máximo de itens na RAM
        ttl: tempo de vida (segundos) de cada item (None = infinito)
        max_workers: número máximo de threads simultâneas
        """
        self.cache = {}
        self.lock = threading.RLock()  # lock reentrante, mais flexível
        self.max_size = max_size
        self.ttl = ttl

        # --- ThreadPool interno ---
        self.tasks = Queue()
        self.threads = []
        for _ in range(max_workers):
            t = threading.Thread(target=self._worker, daemon=True)
            t.start()
            self.threads.append(t)

    # --- Worker da fila ---
    def _worker(self):
        while True:
            func, args, kwargs = self.tasks.get()
            try:
                func(*args, **kwargs)
            except Exception as e:
                print("[RAM ERROR]:", e)
            self.tasks.task_done()

    # --- Funções internas ---
    def _clean_expired(self):
        if self.ttl is None:
            return
        now = time.time()
        expired = [k for k, v in self.cache.items() if now - v["time"] > self.ttl]
        for k in expired:
            del self.cache[k]

    # --- Memória ---
    def set(self, key, value):
        with self.lock:
            self._clean_expired()
            if len(self.cache) >= self.max_size:
                oldest = min(self.cache, key=lambda k: self.cache[k]["time"])
                del self.cache[oldest]
            self.cache[key] = {"value": value, "time": time.time()}

    def get(self, key):
        with self.lock:
            self._clean_expired()
            item = self.cache.get(key)
            return item["value"] if item else None

    def delete(self, key):
        with self.lock:
            if key in self.cache:
                del self.cache[key]

    def clear(self):
        with self.lock:
            self.cache.clear()

    def dump_json(self):
        with self.lock:
            self._clean_expired()
            return json.dumps({k: v["value"] for k, v in self.cache.items()}, indent=2)

    def load_json(self, json_str):
        data = json.loads(json_str)
        with self.lock:
            for k, v in data.items():
                self.set(k, v)

    # --- Execução de tarefas ---
    def run_parallel(self, func, *args, **kwargs):
        """Adiciona função à fila de execução"""
        self.tasks.put((func, args, kwargs))

    def execute_code(self, code_str, globals_dict=None):
        local_vars = {}
        exec(code_str, globals_dict or {}, local_vars)
        return local_vars


# ------------------------
# DEBUG / TESTE RÁPIDO
# ------------------------
if __name__ == "__main__":
    ram = RAM(max_size=5, ttl=10, max_workers=3)

    # Função de teste
    def exemplo(x):
        time.sleep(1)
        ram.set(f"res_{x}", x*2)
        print("Executado:", x)

    # Adiciona várias tarefas
    for i in range(6):
        ram.run_parallel(exemplo, i)

    # Espera a fila esvaziar
    ram.tasks.join()
    print("Dump final da RAM:", ram.dump_json())