from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="ram_cache",  # nome do pacote no PyPI
    version="1.0.0",
    author="Ghost",
    author_email="ghost.gabriel2@gmail.com",
    description="RAM efêmera com TTL, limite de itens e execução paralela de funções",
    long_description=long_description,
    long_description_content_type="text/markdown",
    #url="https://github.com/seuusuario/ram",  # opcional
    packages=find_packages(),  # encontra a pasta ram/
    python_requires=">=3.8",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    install_requires=[],  # sem dependências externas
)