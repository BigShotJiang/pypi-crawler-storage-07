RAM

Pacote Python para RAM efêmera com TTL, limite de tamanho, execução paralela de funções e import/export em JSON.

Permite criar uma memória temporária, segura para acesso concorrente com threads, com expiração automática, dump/load JSON e execução de código ou funções em paralelo.


---

Instalação / Installation

pip install ram


---

Uso em Português / Usage in Portuguese

from ram import RAM
import time

# Cria a RAM com:
# max_size=100 itens
# ttl=10 segundos (cada item expira)
# max_workers=5 threads paralelas
ram = RAM(max_size=5, ttl=10, max_workers=3)

# Armazena um valor
ram.set("chave", "valor")
print(ram.get("chave"))  # Output: "valor"

# Deleta um valor
ram.delete("chave")

# Limpa toda a RAM
ram.clear()

# Exporta RAM para JSON
json_str = ram.dump_json()
print(json_str)

# Carrega valores de JSON
ram.load_json(json_str)

# Executa funções em paralelo
def exemplo(x):
    time.sleep(1)
    ram.set(f"res_{x}", x*2)
    print("Executado:", x)

for i in range(6):
    ram.run_parallel(exemplo, i)

# Espera todas as tarefas da fila terminarem
ram.tasks.join()

# Executa código Python de string
resultado = ram.execute_code("y = 2 + 2")
print(resultado["y"])  # Output: 4


---

Uso em Inglês / Usage in English

from ram import RAM
import time

# Create RAM with:
# max_size=100 items
# ttl=10 seconds (each item expires)
# max_workers=5 parallel threads
ram = RAM(max_size=5, ttl=10, max_workers=3)

# Store a value
ram.set("key", "value")
print(ram.get("key"))  # Output: "value"

# Delete a value
ram.delete("key")

# Clear all RAM
ram.clear()

# Export RAM to JSON
json_str = ram.dump_json()
print(json_str)

# Load values from JSON
ram.load_json(json_str)

# Run functions in parallel
def example(x):
    time.sleep(1)
    ram.set(f"res_{x}", x*2)
    print("Executed:", x)

for i in range(6):
    ram.run_parallel(example, i)

# Wait for all tasks to finish
ram.tasks.join()

# Execute Python code from string
result = ram.execute_code("y = 2 + 2")
print(result["y"])  # Output: 4


---

Funções principais / Main Functions

set(key, value)
Armazena um valor na RAM. Se o limite (max_size) for atingido, o item mais antigo é removido.
Stores a value in RAM. If the max_size limit is reached, the oldest item is removed.

get(key)
Retorna o valor, ou None se não existir ou tiver expirado.
Returns the value, or None if it doesn’t exist or has expired.

delete(key)
Remove o valor da RAM.
Removes a value from RAM.

clear()
Limpa toda a memória.
Clears all memory.

dump_json()
Retorna todos os itens válidos em formato JSON.
Returns all valid items as JSON.

load_json(json_str)
Carrega valores de um JSON.
Loads values from JSON.

run_parallel(func, *args, **kwargs)
Adiciona uma função à fila de execução paralela (thread pool).
Adds a function to the parallel execution queue (thread pool).

execute_code(code_str, globals_dict=None)
Executa código Python passado como string e retorna variáveis locais resultantes.
Executes Python code given as a string and returns resulting local variables.



---

Observações / Notes

max_size define o número máximo de itens na RAM.

ttl é o tempo de vida de cada item (segundos).

max_workers define quantas threads podem executar funções em paralelo.

O acesso à RAM é seguro para uso concorrente com threads.

Valores expirados são removidos automaticamente quando você acessa a RAM ou exporta para JSON.
