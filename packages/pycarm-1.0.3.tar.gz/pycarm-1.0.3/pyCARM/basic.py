# -*- coding: utf-8 -*-

#%%


"""

# Set up the grid and parameters

# Here:
Create a 2D grid to represent the CA, 
Initialize parameters like grid size, number of particles, source cells, and exit cells based on user input.

"""

import numpy as np

# User-defined parameters
grid_rows = 10
grid_cols = 10
num_particles = 15
# source_cells = [(0, 2), (0, 5), (0, 8)] # Original fixed source cells
exit_cells = [(9, 3), (9, 4), (9, 5), (9,6)]
number_of_steps = 100

# New parameter: Number of rows to exclude above exit cells for initial placement
exclude_rows_above_exit = 5 # Example: exclude the 2 rows directly above exit cells

# New parameter: Number of rows at the top of the grid for recycled particles
reentry_depth = 2 # Example: recycled particles can appear in the top 3 rows

# Create the 2D grid
grid = np.zeros((grid_rows, grid_cols), dtype=int)

#%%

"""

# Initialize particles

# Here:
Place the specified number of particles at the source cells, ensuring no two particles occupy the same cell initially.

"""

import random

particle_positions = []
placed_particles = 0

valid_start_rows = list(range(grid_rows - 1 - exclude_rows_above_exit))

if not valid_start_rows:
    print("Error: No valid rows available for particle placement with the current exclusion settings.")
else:
    # Attempt to place particles randomly in valid cells
    while placed_particles < num_particles:
        # Select a random row from the valid starting rows
        row = random.choice(valid_start_rows)
        # Select a random column
        col = random.randrange(grid_cols)

        # Check if the randomly selected cell is already occupied
        if grid[row, col] == 0:
            grid[row, col] = 1
            particle_positions.append((row, col))
            placed_particles += 1
        # If the cell is occupied, the loop continues and tries another random cell

    if placed_particles < num_particles:
        print(f"Warning: Could only place {placed_particles} particles out of {num_particles} due to limited available space.")


#%%

"""

# Define particle movement rules

# Here:
Implement the function to find valid next positions for a particle, 
considering the Moore neighborhood, grid boundaries, and preventing movement across side boundaries.
"""

def get_valid_next_positions(row, col, grid_rows, grid_cols, grid):
    """
    Gets a list of valid next positions for a particle from (row, col).

    Args:
        row: The current row of the particle.
        col: The current column of the particle.
        grid_rows: The total number of rows in the grid.
        grid_cols: The total number of columns in the grid.
        grid: The current state of the grid.

    Returns:
        A list of valid (new_row, new_col) tuples.
    """
    potential_next_positions = []
    for dr in [-1, 0, 1]:
        for dc in [-1, 0, 1]:
            if dr == 0 and dc == 0:  # Exclude the current position
                continue

            new_row = row + dr
            new_col = col + dc

            # Check if within grid boundaries
            if 0 <= new_row < grid_rows and 0 <= new_col < grid_cols:
                # Check for crossing side boundaries
                # If current col is 0, new col cannot be grid_cols - 1
                # If current col is grid_cols - 1, new col cannot be 0
                if not ((col == 0 and new_col == grid_cols - 1) or
                        (col == grid_cols - 1 and new_col == 0)):
                     potential_next_positions.append((new_row, new_col))

    return potential_next_positions

# Example usage (for testing the function)
test_row, test_col = 1, 1
valid_moves = get_valid_next_positions(test_row, test_col, grid_rows, grid_cols, grid)
# print(f"Valid moves from ({test_row}, {test_col}): {valid_moves}")

test_row_side, test_col_side = 5, 0
valid_moves_side = get_valid_next_positions(test_row_side, test_col_side, grid_rows, grid_cols, grid)
# print(f"Valid moves from ({test_row_side}, {test_col_side}): {valid_moves_side}")

test_row_corner, test_col_corner = 0, 0
valid_moves_corner = get_valid_next_positions(test_row_corner, test_col_corner, grid_rows, grid_cols, grid)
# print(f"Valid moves from ({test_row_corner}, {test_col_corner}): {valid_moves_corner}")

"""

# Implement collision avoidance

# Here:
Ensure that particles cannot move into occupied cells.
Modify the `get_valid_next_positions` function to check if a potential next cell is occupied and only include unoccupied cells.
"""

def get_valid_next_positions(row, col, grid_rows, grid_cols, grid):
    """
    Gets a list of valid next positions for a particle from (row, col),
    ensuring the potential next cell is not occupied.

    Args:
        row: The current row of the particle.
        col: The current column of the particle.
        grid_rows: The total number of rows in the grid.
        grid_cols: The total number of columns in the grid.
        grid: The current state of the grid.

    Returns:
        A list of valid (new_row, new_col) tuples.
    """
    potential_next_positions = []
    for dr in [-1, 0, 1]:
        for dc in [-1, 0, 1]:
            if dr == 0 and dc == 0:  # Exclude the current position
                continue

            new_row = row + dr
            new_col = col + dc

            # Check if within grid boundaries
            if 0 <= new_row < grid_rows and 0 <= new_col < grid_cols:
                # Check for crossing side boundaries
                if not ((col == 0 and new_col == grid_cols - 1) or
                        (col == grid_cols - 1 and new_col == 0)):
                    # Check if the potential next cell is not occupied
                    if grid[new_row, new_col] == 0:
                         potential_next_positions.append((new_row, new_col))

    return potential_next_positions

# Example usage (for testing the function)
test_row, test_col = 1, 1
valid_moves = get_valid_next_positions(test_row, test_col, grid_rows, grid_cols, grid)
# print(f"Valid moves from ({test_row}, {test_col}): {valid_moves}")

test_row_side, test_col_side = 5, 0
valid_moves_side = get_valid_next_positions(test_row_side, test_col_side, grid_rows, grid_cols, grid)
# print(f"Valid moves from ({test_row_side}, {test_col_side}): {valid_moves_side}")

test_row_corner, test_col_corner = 0, 0
valid_moves_corner = get_valid_next_positions(test_row_corner, test_col_corner, grid_rows, grid_cols, grid)
# print(f"Valid moves from ({test_row_corner}, {test_col_corner}): {valid_moves_corner}")

#%%

"""

# Implement crowdedness-based movement probability

# Here:
Define how the probability of movement is influenced by the number of occupied cells in the Moore neighborhood.

Create a function to calculate movement probability based on the number of occupied neighbors in the Moore neighborhood.
"""

def get_movement_probability(row, col, grid_rows, grid_cols, grid):
    """
    Calculates the probability of movement for a particle based on its
    Moore neighborhood crowdedness.

    Args:
        row: The current row of the particle.
        col: The current column of the particle.
        grid_rows: The total number of rows in the grid.
        grid_cols: The total number of columns in the grid.
        grid: The current state of the grid.

    Returns:
        A float between 0 and 1 representing the probability of movement.
    """
    occupied_neighbors = 0
    for dr in [-1, 0, 1]:
        for dc in [-1, 0, 1]:
            # Exclude the current position
            if dr == 0 and dc == 0:
                continue

            new_row = row + dr
            new_col = col + dc

            # Check if within grid boundaries
            if 0 <= new_row < grid_rows and 0 <= new_col < grid_cols:
                 # Check for crossing side boundaries (same logic as valid moves)
                if not ((col == 0 and new_col == grid_cols - 1) or
                        (col == grid_cols - 1 and new_col == 0)):
                    if grid[new_row, new_col] == 1:
                        occupied_neighbors += 1

    # Define the relationship between occupied neighbors and movement probability
    # Example relationship: Probability decreases linearly with the number of occupied neighbors
    # Max possible occupied neighbors in Moore neighborhood (excluding self) is 8
    max_neighbors = 8
    movement_probability = 1.0 - (occupied_neighbors / max_neighbors)

    # Ensure probability is between 0 and 1
    movement_probability = max(0.0, min(1.0, movement_probability))

    return movement_probability

# Example usage (for testing the function)
test_row, test_col = 1, 1
# Temporarily set some neighbors to occupied for testing
original_grid_state = np.copy(grid) # Make a copy to restore later
grid[0, 1] = 1
grid[2, 2] = 1

probability = get_movement_probability(test_row, test_col, grid_rows, grid_cols, grid)
# print(f"Movement probability from ({test_row}, {test_col}) with some neighbors occupied: {probability}")

# Restore the original grid state
grid = original_grid_state

#%%

"""

# Implement periodic boundary conditions

# Here:
When particles reach the exit cells, recycle them back to the source cells.

Implement the function to handle periodic boundary conditions for particles reaching exit cells by recycling them to source cells.
"""

import random

def handle_periodic_boundary(new_row, new_col, exit_cells, grid_cols, reentry_depth):
    """
    Handles periodic boundary conditions when a particle reaches an exit cell
    by recycling it back to a random cell within the specified reentry_depth
    at the top of the grid.

    Args:
        new_row: The proposed new row of the particle.
        new_col: The proposed new column of the particle.
        exit_cells: A list of (row, col) tuples representing exit cells.
        grid_cols: The total number of columns in the grid.
        reentry_depth: The number of rows at the top for recycled particles.

    Returns:
        A tuple (final_row, final_col) which is either the original
        (new_row, new_col) if not in an exit cell, or the coordinates of
        a randomly selected cell within the reentry_depth if it is in an exit cell.
    """
    if (new_row, new_col) in exit_cells:
        # Particle reached an exit cell, recycle to a random cell within the reentry depth
        recycled_row = random.randrange(reentry_depth)
        recycled_col = random.randrange(grid_cols)
        return (recycled_row, recycled_col)
    else:
        # Particle did not reach an exit cell, keep the proposed position
        return (new_row, new_col)

# Define source_cells explicitly for potential use in other parts of the code (e.g., visualization)
# Even though handle_periodic_boundary no longer uses this for recycling,
# other functions might still rely on it being defined.
# For visualization, we can define source cells as the reentry area.
source_cells = [(row, col) for row in range(reentry_depth) for col in range(grid_cols)]


# Example usage (for testing the function)
# Assume a particle moves to an exit cell
test_exit_row, test_exit_col = exit_cells[0]
recycled_position_exit = handle_periodic_boundary(test_exit_row, test_exit_col, exit_cells, grid_cols, reentry_depth)
# print(f"Particle reaching exit cell ({test_exit_row}, {test_exit_col}) is recycled to: {recycled_position_exit}")

# Assume a particle moves to a non-exit cell
test_non_exit_row, test_non_exit_col = 1, 1 # A cell not in exit_cells
recycled_position_non_exit = handle_periodic_boundary(test_non_exit_row, test_non_exit_col, exit_cells, grid_cols, reentry_depth)
# print(f"Particle moving to non-exit cell ({test_non_exit_row}, {test_non_exit_col}) stays at: {recycled_position_non_exit}")


#%%

"""

# Implement obstacle avoidance/unblocking mechanism

# Here:
Add a mechanism to help particles navigate around obstacles or adjust their behavior when blocked to prevent them from getting stuck. This could involve random movement, looking for alternative paths, or temporarily changing movement probabilities.

Define the `unblock_particle` function as described in the instructions, incorporating a simple random move strategy if the particle is stuck (no valid moves available).
"""

import random

def unblock_particle(row, col, grid_rows, grid_cols, grid):
    """
    Attempts to unblock a stuck particle by trying a random move to an adjacent empty cell.

    Args:
        row: The current row of the particle.
        col: The current column of the particle.
        grid_rows: The total number of rows in the grid.
        grid_cols: The total number of columns in the grid.
        grid: The current state of the grid.

    Returns:
        A tuple (new_row, new_col) which is the particle's new position if
        successfully unblocked, or its original position if it remains stuck.
    """
    # Check if the particle is stuck (no valid moves)
    valid_moves = get_valid_next_positions(row, col, grid_rows, grid_cols, grid)

    if not valid_moves:
        # Particle is stuck, try a random move to any empty adjacent cell
        potential_unblock_positions = []
        for dr in [-1, 0, 1]:
            for dc in [-1, 0, 1]:
                if dr == 0 and dc == 0:  # Exclude the current position
                    continue

                new_row = row + dr
                new_col = col + dc

                # Check if within grid boundaries
                if 0 <= new_row < grid_rows and 0 <= new_col < grid_cols:
                     # Check for crossing side boundaries (same logic as valid moves)
                    if not ((col == 0 and new_col == grid_cols - 1) or
                            (col == grid_cols - 1 and new_col == 0)):
                        # Check if the potential next cell is not occupied
                        if grid[new_row, new_col] == 0:
                             potential_unblock_positions.append((new_row, new_col))

        if potential_unblock_positions:
            # If there are empty adjacent cells, move to a random one
            return random.choice(potential_unblock_positions)
        else:
            # No empty adjacent cells, particle remains stuck
            return (row, col)
    else:
        # Particle is not stuck, no need to unblock
        return (row, col)

# Example usage (for testing the function)
# Create a small grid to simulate a stuck particle
test_grid = np.ones((3, 3), dtype=int) # All cells occupied
test_grid[1, 1] = 1 # Particle's position
test_grid_rows, test_grid_cols = test_grid.shape
test_row, test_col = 1, 1

# Simulate a stuck particle (surrounded by occupied cells)
# First, make sure get_valid_next_positions returns empty for this scenario
valid_moves_stuck = get_valid_next_positions(test_row, test_col, test_grid_rows, test_grid_cols, test_grid)
# print(f"Valid moves from ({test_row}, {test_col}) in stuck scenario: {valid_moves_stuck}")

# Now, test the unblock function in the stuck scenario
new_pos_stuck = unblock_particle(test_row, test_col, test_grid_rows, test_grid_cols, test_grid)
# print(f"Position after attempting to unblock from ({test_row}, {test_col}) in stuck scenario: {new_pos_stuck}")

# Simulate a particle that is NOT stuck (at least one empty neighbor)
test_grid_not_stuck = np.ones((3, 3), dtype=int)
test_grid_not_stuck[1, 1] = 1 # Particle's position
test_grid_not_stuck[0, 0] = 0 # Make one neighbor empty
test_row_not_stuck, test_col_not_stuck = 1, 1

valid_moves_not_stuck = get_valid_next_positions(test_row_not_stuck, test_col_not_stuck, test_grid_rows, test_grid_cols, test_grid_not_stuck)
# print(f"Valid moves from ({test_row_not_stuck}, {test_col_not_stuck}) in not stuck scenario: {valid_moves_not_stuck}")

new_pos_not_stuck = unblock_particle(test_row_not_stuck, test_col_not_stuck, test_grid_rows, test_grid_cols, test_grid_not_stuck)
# print(f"Position after attempting to unblock from ({test_row_not_stuck}, {test_col_not_stuck}) in not stuck scenario: {new_pos_not_stuck}")

#%%

"""

# Run the simulation

# Here:
Run the simulation by iterating through time steps, updating the position of each particle based on the defined rules.

Implement the main simulation loop, iterating through time steps, updating particle positions based on movement probability, valid moves, periodic boundary conditions, and the unblocking mechanism.
"""

import random
import time
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import numpy as np

# Number of time steps for the simulation
num_time_steps = number_of_steps

# print("Starting simulation for", num_time_steps, " time steps...")

# Create a figure and axis for the animation
# fig, ax = plt.subplots(figsize=(grid.shape[1], grid.shape[0]))
# im = ax.imshow(grid, cmap='binary', origin='upper')
# ax.set_title("Time Step 0")
# ax.set_xticks([]) # Hide x-axis ticks
# ax.set_yticks([]) # Hide y-axis ticks

# Store grid states for animation
grid_states = []
grid_states.append(np.copy(grid)) # Store initial state

# Simulation loop to generate grid states
for t in range(num_time_steps):
    # Create a copy of the current grid for updates in this time step
    current_grid_copy = np.copy(grid)
    updated_particle_positions = []

    # Iterate through each particle's current position
    for i, (row, col) in enumerate(particle_positions):
        # Get movement probability based on crowdedness
        probability = get_movement_probability(row, col, grid_rows, grid_cols, grid)

        # Generate a random number and check if the particle attempts to move
        if random.random() < probability:
            # Particle attempts to move
            all_valid_next_positions = get_valid_next_positions(row, col, grid_rows, grid_cols, grid)

            # Filter valid_next_positions to prevent movement to cells behind
            valid_forward_side_positions = [(r, c) for r, c in all_valid_next_positions if r >= row]

            if valid_forward_side_positions:
                # Randomly select a potential new position from valid forward/side moves
                potential_new_pos = random.choice(valid_forward_side_positions)

                # Handle periodic boundary conditions (recycling to source cells)
                # Note: Periodic boundary condition recycling always sends to source, which is at the top (lower row index).
                # This is an exception to the "no backward movement" rule, as designed by the periodic boundary condition.
                actual_new_pos = handle_periodic_boundary(potential_new_pos[0], potential_new_pos[1], exit_cells, grid_cols, reentry_depth)

                # Check if the particle remains in an occupied cell after attempting to move
                # This check uses the *copied* grid for the current time step's state
                if current_grid_copy[actual_new_pos[0], actual_new_pos[1]] == 1:
                     # Particle is blocked, attempt to unblock (unblocking can still allow backward moves if that's the only option to unstick)
                     final_pos = unblock_particle(row, col, grid_rows, grid_cols, current_grid_copy)
                     # Need to check if unblocking was successful and the target cell is still free in the copy
                     if current_grid_copy[final_pos[0], final_pos[1]] == 0:
                         # Unblocking successful to an empty cell in the copy
                         final_pos = final_pos
                     else:
                         # Unblocking failed or target cell became occupied by another particle this step, stay put
                         final_pos = (row, col)
                else:
                    # Particle moved to a valid, unoccupied cell
                    final_pos = actual_new_pos

            else:
                # No valid forward or side positions, particle stays in current position
                final_pos = (row, col)

        else:
            # Particle does not attempt to move, stays in current position
            final_pos = (row, col)

        # Update the copied grid with the particle's movement
        # Set the old position to 0
        current_grid_copy[row, col] = 0
        # Set the new position to 1
        current_grid_copy[final_pos[0], final_pos[1]] = 1

        # Add the particle's final position for this time step
        updated_particle_positions.append(final_pos)


    # After iterating through all particles, update the main grid and particle positions
    grid = np.copy(current_grid_copy)
    particle_positions = updated_particle_positions

    # Store the grid state for animation
    grid_states.append(np.copy(grid))


# print("\nSimulation finished. Creating animation...")

# Function to update the animation frame
# def update(frame):
#     """Updates the image data for the animation."""
#     im.set_array(grid_states[frame])
#     ax.set_title(f"Time Step {frame}")
#     return [im]

# Create the animation
# interval: Delay between frames in milliseconds
# frames: Number of frames to animate (equal to the number of time steps + initial state)
# blit: Set to True for smoother animation (redraw only the changed parts)
# ani = animation.FuncAnimation(fig, update, frames=len(grid_states), interval=100, blit=True)

# Display the animation
# plt.show()

# Note: In some environments (like certain Jupyter notebooks), you might need to
# install ffmpeg or imagemagick to save the animation as a file (e.g., GIF, MP4).
# You can save the animation using:
# ani.save('cellular_automata.gif', writer='imagemagick')
# ani.save('cellular_automata.mp4', writer='ffmpeg')

#%%

"""

# Visualize the simulation

# Here:
Display the grid at each time step to visualize the particle movement dynamically.

Add code to visualize the simulation using `matplotlib.animation.FuncAnimation` to create a dynamic display of the grid over time, showing particle movements, source cells, and exit cells.
"""

# import matplotlib.pyplot as plt
# import matplotlib.animation as animation
# import numpy as np
# from matplotlib.colors import ListedColormap

# # Create a figure and axis for the animation
# fig, ax = plt.subplots(figsize=(grid.shape[1], grid.shape[0]))

# # Define a custom colormap: 0 for empty (white), 1 for particle (black),
# # 2 for source (e.g., blue), 3 for exit (e.g., red)
# cmap = ListedColormap(['white', 'black', 'blue', 'red'])
# bounds = [-0.5, 0.5, 1.5, 2.5, 3.5]
# norm = plt.Normalize(bounds[0], bounds[-1])

# # Create an initial grid for visualization with source and exit cells marked
# initial_viz_grid = np.copy(grid_states[0])
# for r, c in source_cells:
#     initial_viz_grid[r, c] = 2 # Mark source cells with 2
# for r, c in exit_cells:
#     initial_viz_grid[r, c] = 3 # Mark exit cells with 3

# im = ax.imshow(initial_viz_grid, cmap=cmap, norm=norm, origin='upper')
# ax.set_title("Time Step 0")
# ax.set_xticks(np.arange(-.5, grid.shape[1], 1), minor=True)
# ax.set_yticks(np.arange(-.5, grid.shape[0], 1), minor=True)
# ax.grid(which="minor", color="gray", linestyle='-', linewidth=0.5)
# ax.set_xticklabels([]) # Hide x-axis tick labels
# ax.set_yticklabels([]) # Hide y-axis tick labels
# ax.tick_params(which="minor", size=0) # Hide minor tick marks
# ax.set_xticks([]) # Hide x-axis major ticks
# ax.set_yticks([]) # Hide y-axis major ticks


# Function to update the animation frame
# def update(frame):
#     """Updates the image data for the animation."""
#     # Create a grid for visualization with source and exit cells marked for the current frame
#     viz_grid = np.copy(grid_states[frame])
#     for r, c in source_cells:
#         viz_grid[r, c] = 2 # Mark source cells with 2
#     for r, c in exit_cells:
#         viz_grid[r, c] = 3 # Mark exit cells with 3

#     im.set_array(viz_grid)
#     ax.set_title(f"Time Step {frame}")
#     return [im]


# Create the animation
# interval: Delay between frames in milliseconds
# frames: Number of frames to animate (equal to the number of time steps + initial state)
# blit: Set to True for smoother animation (redraw only the changed parts)

# ani = animation.FuncAnimation(fig, update, frames=len(grid_states), interval=100, blit=True)

# Display the animation

# plt.show()

# Note: In some environments (like certain Jupyter notebooks), you might need to
# install ffmpeg or imagemagick to save the animation as a file (e.g., GIF, MP4).
# You can save the animation using:

# ani.save('cellular_automata.gif', writer='imagemagick')

# ani.save('cellular_automata.mp4', writer='ffmpeg')

#%%

"""

# Compute the average flow of the simulation 

# Here:
Compute the average flow of the simulation based on a user-defined section of rows within which flow will be measured. The average flow is defined as the total number of particle movements within the defined section throughout the simulation divided by the product of the number of particles and the total number of time steps.

Define the flow measurement section

Define the specific range of rows within the grid where the particle flow will be measured.

Define the start and end rows for flow measurement and print them.
"""

# Define the section of rows for flow measurement
flow_measure_start_row = 2  # Example: Start measurement from row 2
flow_measure_end_row = 7    # Example: End measurement at row 7 (inclusive)

# Ensure the defined range is within grid boundaries
flow_measure_start_row = max(0, flow_measure_start_row)
flow_measure_end_row = min(grid_rows - 1, flow_measure_end_row)

# print(f"Flow will be measured within rows {flow_measure_start_row} to {flow_measure_end_row} (inclusive).")

"""

# Analyze grid states for movement

# Here:
Iterate through the stored `grid_states` from the simulation. For each time step and within the defined row section, compare the grid state to the previous time step to identify cell state changes (particle movements).

Initialize the `total_movements` counter and iterate through the grid states to count movements within the defined flow measurement section.
"""

total_movements = 0

# Iterate through the grid states starting from the second state (index 1)
for t in range(1, len(grid_states)):
    prev_grid = grid_states[t - 1]
    curr_grid = grid_states[t]

    # Compare the grids within the defined flow measurement rows
    for r in range(flow_measure_start_row, flow_measure_end_row + 1):
        for c in range(grid_cols):
            # Check if a particle moved out of this cell in this time step
            if prev_grid[r, c] == 1 and curr_grid[r, c] == 0:
                total_movements += 1

# print(f"Total particle movements within rows {flow_measure_start_row} to {flow_measure_end_row}: {total_movements}")

#%%

"""

# Compute average flow

# Here:
Calculate the average flow using the provided formula: (Total number of movements) / (Number of particles * Total number of time steps).

"""

# Calculate the denominator (Number of particles * Total number of time steps)
denominator = num_particles * num_time_steps

# Calculate the average flow
average_flow = total_movements / denominator

# print(f"Average flow: {average_flow}")

#%%

"""

# Runs a simulation for different configurations of `num_particles` and `exclude_rows_above_exit`. 
The script should take a list of configurations (each being a dictionary with `num_particles` and `exclude_rows_above_exit`)
and the number of repetitions for each configuration as input. 
For each configuration, run the simulation the specified number of times, 
calculate the average flow across the repetitions, and print the average flow for each configuration. 


"""

import numpy as np
import random

def run_simulation(grid_rows, grid_cols, num_particles, exclude_rows_above_exit, reentry_depth, exit_cells, number_of_steps):
    """
    Runs a 2D cellular automata simulation and calculates the average flow.

    Args:
        grid_rows: The number of rows in the grid.
        grid_cols: The number of columns in the grid.
        num_particles: The number of particles in the simulation.
        exclude_rows_above_exit: Number of rows above exit cells to exclude for initial placement.
        reentry_depth: Number of rows at the top for recycled particles.
        exit_cells: A list of (row, col) tuples representing exit cells.
        number_of_steps: The total number of time steps for the simulation.

    Returns:
        The calculated average flow within the defined measurement section.
    """
    # 1. Set up the grid and parameters (within function scope)
    grid = np.zeros((grid_rows, grid_cols), dtype=int)
    particle_positions = []

    # 2. Initialize particles
    placed_particles = 0
    valid_start_rows = list(range(grid_rows - 1 - exclude_rows_above_exit))

    if not valid_start_rows:
        print("Error: No valid rows available for initial particle placement.")
        # Handle this case, perhaps return an error code or 0 flow
        return 0.0
    else:
        while placed_particles < num_particles:
            row = random.choice(valid_start_rows)
            col = random.randrange(grid_cols)
            if grid[row, col] == 0:
                grid[row, col] = 1
                particle_positions.append((row, col))
                placed_particles += 1

    if placed_particles < num_particles:
        print(f"Warning: Could only place {placed_particles} particles out of {num_particles}.")

    # Define source cells based on reentry depth for periodic boundary conditions
    source_cells = [(row, col) for row in range(reentry_depth) for col in range(grid_cols)]

    # 3. Define particle movement rules, implement collision avoidance,
    #    implement crowdedness-based movement probability, handle periodic
    #    boundary conditions, implement obstacle avoidance/unblocking mechanism.
    #    These helper functions need to be defined or accessible within this function's scope.
    #    Assuming they are defined globally or nested if preferred.
    #    For now, we'll rely on the previously defined global functions.

    # 4. Run the simulation loop
    grid_states = []
    grid_states.append(np.copy(grid)) # Store initial state

    for t in range(number_of_steps):
        current_grid_copy = np.copy(grid)
        updated_particle_positions = []

        for i, (row, col) in enumerate(particle_positions):
            probability = get_movement_probability(row, col, grid_rows, grid_cols, grid)

            if random.random() < probability:
                all_valid_next_positions = get_valid_next_positions(row, col, grid_rows, grid_cols, grid)
                valid_forward_side_positions = [(r, c) for r, c in all_valid_next_positions if r >= row]

                if valid_forward_side_positions:
                    potential_new_pos = random.choice(valid_forward_side_positions)
                    actual_new_pos = handle_periodic_boundary(potential_new_pos[0], potential_new_pos[1], exit_cells, grid_cols, reentry_depth)

                    if current_grid_copy[actual_new_pos[0], actual_new_pos[1]] == 1:
                         final_pos = unblock_particle(row, col, grid_rows, grid_cols, current_grid_copy)
                         if current_grid_copy[final_pos[0], final_pos[1]] == 0:
                             final_pos = final_pos
                         else:
                             final_pos = (row, col)
                    else:
                        final_pos = actual_new_pos
                else:
                    final_pos = (row, col)
            else:
                final_pos = (row, col)

            current_grid_copy[row, col] = 0
            current_grid_copy[final_pos[0], final_pos[1]] = 1
            updated_particle_positions.append(final_pos)

        grid = np.copy(current_grid_copy)
        particle_positions = updated_particle_positions
        grid_states.append(np.copy(grid))

    # 5. Define the flow measurement section and analyze grid states for movement
    flow_measure_start_row = 2  # Example: Start measurement from row 2
    flow_measure_end_row = 7    # Example: End measurement at row 7 (inclusive)

    flow_measure_start_row = max(0, flow_measure_start_row)
    flow_measure_end_row = min(grid_rows - 1, flow_measure_end_row)

    total_movements = 0
    for t in range(1, len(grid_states)):
        prev_grid = grid_states[t - 1]
        curr_grid = grid_states[t]

        for r in range(flow_measure_start_row, flow_measure_end_row + 1):
            for c in range(grid_cols):
                if prev_grid[r, c] == 1 and curr_grid[r, c] == 0:
                    total_movements += 1

    # 6. Calculate the average flow
    denominator = num_particles * number_of_steps
    average_flow = total_movements / denominator if denominator > 0 else 0.0

    # 7. Return the average flow
    return average_flow

# Note: The helper functions get_valid_next_positions, get_movement_probability,
# handle_periodic_boundary, and unblock_particle are assumed to be defined
# in previous cells or globally accessible when this function is called.

#%%

import numpy as np
from typing import List, Dict, Tuple, Any

def run_multiple_simulations(
    grid_rows: int, 
    grid_cols: int, 
    reentry_depth: int, 
    exit_cells: List[Tuple[int, int]],
    number_of_steps: int,
    configurations: List[Dict[str, int]] = None,
    num_repetitions: int = 5
) -> Dict[Tuple[int, int], float]:
    """
    Runs a simulation for multiple configurations and repetitions, then
    calculates and prints the average flow for each configuration.

    Args:
        run_simulation: The function used to run a single simulation.
        grid_rows: The number of rows in the simulation grid.
        grid_cols: The number of columns in the simulation grid.
        reentry_depth: The depth for particle reentry.
        exit_cells: A list of (row, col) tuples defining the exit cells.
        number_of_steps: The total number of steps in each simulation run.
        configurations: A list of dictionaries, where each dict specifies
                        "num_particles" and "exclude_rows_above_exit" for a run.
                        If None, uses a default list.
        num_repetitions: The number of times to run each configuration.

    Returns:
        A dictionary where the key is a tuple (num_particles, exclude_rows_above_exit)
        and the value is the calculated average flow across all repetitions.
    """
    
    # 1. Define configurations (if not provided) and repetitions
    if configurations is None:
        configurations = [
            {"num_particles": 10, "exclude_rows_above_exit": 3},
            {"num_particles": 20, "exclude_rows_above_exit": 5},
            {"num_particles": 15, "exclude_rows_above_exit": 4}
        ]

    # 2. Run simulations and collect results
    results = {}

    for config in configurations:
        flow_values = []

        # Run the simulation for the specified number of repetitions
        for i in range(num_repetitions):
            # Run the simulation function with the current configuration parameters
            average_flow = run_simulation(
                grid_rows=grid_rows,
                grid_cols=grid_cols,
                num_particles=config["num_particles"],
                exclude_rows_above_exit=config["exclude_rows_above_exit"],
                reentry_depth=reentry_depth,
                exit_cells=exit_cells,
                number_of_steps=number_of_steps
            )
            flow_values.append(average_flow)

        # Store the list of flow values in the results dictionary
        config_key = (config["num_particles"], config["exclude_rows_above_exit"])
        results[config_key] = flow_values

    # 3. Compute and display average flow per configuration
    print("\nAverage flow across repetitions for each configuration:")
    average_results = {}
    
    for config_key, flow_values in results.items():
        # Calculate the mean using numpy
        average_flow_across_repetitions = np.mean(flow_values)
        average_results[config_key] = average_flow_across_repetitions
        
        # Display the result
        print(f"Configuration (num_particles={config_key[0]}, exclude_rows_above_exit={config_key[1]}): {average_flow_across_repetitions:.4f}")
        
    return # average_results


#%%



#%%
