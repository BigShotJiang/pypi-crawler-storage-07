"""Integration tests for SOLLOL."""
