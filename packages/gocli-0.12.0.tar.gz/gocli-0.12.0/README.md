gocli - GenomOncology Command Line Interface
============================================


This is a proprietary package that is available from [GenomOncology] and works
with our [Knowledge Management System].

For more information about licensing please contact us at:

info@genomoncology.com

    
Additional proprietary projects available for download via pypi include:

* [GO VCF] - GenomOncology Variant Call File "call" generator
* [GO SDK] - GenomOncology Software Development Kit
    
Our open source projects include:

* [Related] - Nested Object Models in Python with dictionary, YAML, and JSON transformation support
* [Specd] - Swagger v2 Specification Directories
* [Rigor] - HTTP-based DSL for for validating RESTful APIs


Overview
--------

The GenomOncology Command Line Interface (CLI) is a command line tool built to be
dropped into Bioinformatics pipelines. GO CLI is a "high performance" ETL tool that
understands genomics and directly integrates with the GO KMS via REST API calls
for the following functionality:

* Variant HGVS Calculation (g., p., c.)
* Variant Annotation (e.g. gnomAD, dbSNP, etc.)
* Variant Classification (e.g. ACGM or AMP Tiers)
* Gene and Protein Information
* Clinical Trial Matching
* Therapeutic Matching
* Variant Warehouse Loading and Querying


High Performance
----------------

"High performance" is achieved through functional programming that minimizes
memory consumption and asynchronous programming style (async/await, asyncio) that
maximizes concurrency in high IO situations.



Examples
--------

Generate BED file from List of Genes

    gocli genes.txt genes.bed annotate_genes to_tsv


Filter VCF by BED, Filters, Quality, Mutation Type, and Population Frequency

    gocli demo_1.vcf demo_1.filtered.vcf \
        from_vcf --bed=./snv_cancer.bed \
        filter_in quality GTE 100 \
        filter_in vaf GTE "0.05" \
        annotate_calls \
        retain "annotations.clinvar__CLNSIG__string" HAS "Pathogenic"
        filter_in annotations.canonical_mutation_type IN @mt.txt \
        filter_out annotations.GNOMAD__AF__mfloat GT "0.01" \
        to_vcf


Commands
--------

    $ gocli --help
      add_flag             Add flag based on BED file value/presence.
      aggregate_csv        Rolls up CSV records using a specified key.
      aggregate_tsv        Rolls up TSV records using a specified key.
      aggregate_genie_diseases  aggregates GENIE gene records.
      annotate_calls       Get annotations for stream of calls.
      annotate_genes       Get gene objects by stream of names.
      annotate_match       Get annotations for CSRA.
      annotate_match_bed   Get annotations for gene(s).
      distinct             Remove duplicates from a list of strings.
      extract              Extract a specific field from object stream.
      filter_in            Filter in objects that match comparison.
      filter_out           Filter out objects that match comparison.
      flatten              Flatten list of lists into a list of strings.
      from_bed             Read records from a BED file source.
      from_csv             Parses CSV into name-value pair objects.
      from_excel           Parses Excel into name-value pair objects.
      from_maf             Read records from a MAF file source.
      from_source          Parse file into name-value pair objects.
      from_tsv             Parses TSV into name-value pair objects.
      from_vcf             Parses VCF into variant calls objects.
      invoke               Invoke an external function.
      load_annotations     Loads variant objects into annotations core.
      load_warehouse       Loads variants to warehouse.
      match_contents       Match contents by variants and disease.
      match_therapies      Match therapies by variants and disease.
      match_trials         Match trials by variants and disease.
      refresh_annotations  Rebuilds annotations merged core.
      region_search        Searches for Transcript in region specified...
      retain               Always keep objects that match comparison.
      swagger              Launches local Swagger UI webserver.
      to_excel             Render objects to Excel file format.
      to_pretty            Render indented, syntax highlighted JSON.
      to_python            Render python objects without JSON transform.
      to_tsv               Render objects to TSV file format.
      to_vcf               Render calls to VCF file format.
      transform            Transform input stream to output type.


[GenomOncology]: https://genomoncology.com/
[Knowledge Management System]: https://genomoncology.com/solutions/clinical-oncology/
[Related]: https://github.com/genomoncology/related
[Specd]: https://github.com/genomoncology/specd 
[Rigor]: https://github.com/genomoncology/rigor 
[GO VCF]: https://pypi.org/project/govcf/
[GO SDK]: https://pypi.org/project/gosdk/
