export declare class LayoutHelp {
    render(): any[];
}
