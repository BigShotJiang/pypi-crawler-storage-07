export declare class EmptyState {
    text: string;
    icon: string;
    render(): any;
}
