export interface IDocumentButton {
    label: string;
    icon: string;
    description: string;
    buttonText: string;
}
