import { IRecipient } from '../../types/Recipient';
import { IDocument } from '../../types/Document';
export declare class SelectedRecipientList {
    recipients: IRecipient[];
    document: IDocument;
    render(): any;
}
