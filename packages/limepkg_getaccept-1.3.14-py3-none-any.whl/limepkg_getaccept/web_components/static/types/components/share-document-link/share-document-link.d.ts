import { IRecipient } from '../../types/Recipient';
export declare class ShareDocumentLink {
    recipient: IRecipient;
    constructor();
    render(): any;
    handleCopyLink(): void;
}
