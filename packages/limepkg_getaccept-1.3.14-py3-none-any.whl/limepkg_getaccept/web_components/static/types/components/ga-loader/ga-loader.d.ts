export declare class GALoader {
    render(): any;
}
