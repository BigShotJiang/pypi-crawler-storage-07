import { IProgress } from '../../types/Progress';
export declare const workflowSteps: IProgress[];
