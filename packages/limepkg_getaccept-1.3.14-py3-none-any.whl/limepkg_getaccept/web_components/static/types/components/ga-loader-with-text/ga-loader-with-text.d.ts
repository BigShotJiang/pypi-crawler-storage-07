export declare class GALoaderWithText {
    showText: boolean;
    text: string;
    render(): any;
}
