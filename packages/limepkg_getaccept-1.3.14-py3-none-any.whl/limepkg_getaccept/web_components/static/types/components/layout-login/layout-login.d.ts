import { LimeWebComponentPlatform } from '@limetech/lime-web-components';
export declare class LayoutLogin {
    platform: LimeWebComponentPlatform;
    isSignup: boolean;
    constructor();
    render(): any[];
    private toggleSignupContainer;
}
