export declare class LayoutSettings {
    thumbUrl: string;
    render(): any;
    private getThumbUrl;
}
