export interface IDocumentPage {
    page_id: string;
    thumb_url: string;
    page_time: number;
    order_num: number;
    page_num: number;
}
