export interface ISender {
    email: string;
    name: string;
    sender_id: string;
    thumb_url?: string;
}
