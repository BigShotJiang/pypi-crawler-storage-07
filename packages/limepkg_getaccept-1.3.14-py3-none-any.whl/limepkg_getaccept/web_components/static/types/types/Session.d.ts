export interface ISession {
    username: string;
    access_token: string;
    expires_in: string;
    entity_id?: string;
}
