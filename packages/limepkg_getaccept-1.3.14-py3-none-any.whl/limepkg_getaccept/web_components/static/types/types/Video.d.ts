export interface IVideo {
    thumb_url: string;
    video_id: string;
    video_title: string;
    video_type: string;
    video_url: string;
}
