export interface IView {
    name: string;
}
