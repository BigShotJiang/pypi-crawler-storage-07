export interface IRole {
    label: string;
    value: string;
}
