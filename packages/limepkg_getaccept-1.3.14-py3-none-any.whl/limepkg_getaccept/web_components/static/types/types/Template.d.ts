export interface ITemplate {
    id: string;
    name: string;
    type: string;
    thumb_url: string;
}
