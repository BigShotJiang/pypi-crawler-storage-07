export interface ILoginField {
    id: string;
    style: string;
    label: string;
    type: any;
    value: string;
    required: boolean;
    icon: string;
}
