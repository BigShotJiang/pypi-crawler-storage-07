export interface ISignup {
    company: string;
    first_name: string;
    last_name: string;
    country_code: string;
    mobile: string;
    email: string;
    password: string;
}
