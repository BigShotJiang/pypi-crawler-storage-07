export interface IEntity {
    id: string;
    name: string;
}
