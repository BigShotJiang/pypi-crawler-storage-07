import { EnumViews } from '../models/EnumViews';
export interface IMenuItem {
    label: string;
    icon: string;
    view: EnumViews;
}
