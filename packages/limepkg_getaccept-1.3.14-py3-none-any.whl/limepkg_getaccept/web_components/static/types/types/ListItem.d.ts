export interface IListItem {
    text: string;
    value: string;
    icon: string;
    iconColor?: string;
    thumbUrl?: string;
}
