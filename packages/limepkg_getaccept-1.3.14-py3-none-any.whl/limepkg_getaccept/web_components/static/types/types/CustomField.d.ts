export interface ICustomField {
    id: string;
    value: string;
    label: string;
    is_editable: boolean;
}
