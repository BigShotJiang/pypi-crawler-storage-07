export {};
//# sourceMappingURL=DocumentPage.js.map
