export {};
//# sourceMappingURL=Document.js.map
