export {};
//# sourceMappingURL=Entity.js.map
