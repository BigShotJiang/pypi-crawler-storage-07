export {};
//# sourceMappingURL=Role.js.map
