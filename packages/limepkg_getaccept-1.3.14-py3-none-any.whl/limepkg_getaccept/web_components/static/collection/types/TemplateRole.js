export {};
//# sourceMappingURL=TemplateRole.js.map
