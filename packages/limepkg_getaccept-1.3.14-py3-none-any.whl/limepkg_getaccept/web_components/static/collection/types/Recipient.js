export {};
//# sourceMappingURL=Recipient.js.map
