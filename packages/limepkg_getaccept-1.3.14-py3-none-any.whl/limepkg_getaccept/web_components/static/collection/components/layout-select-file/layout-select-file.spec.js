import { LayoutSelectFile } from "./layout-select-file";
describe('layout-select-file', () => {
    it('builds', () => {
        expect(new LayoutSelectFile()).toBeTruthy();
    });
});
//# sourceMappingURL=layout-select-file.spec.js.map
