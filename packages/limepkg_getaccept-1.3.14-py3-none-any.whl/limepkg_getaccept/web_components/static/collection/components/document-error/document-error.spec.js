import { DocumentError } from "./document-error";
describe('document-error', () => {
    it('builds', () => {
        expect(new DocumentError()).toBeTruthy();
    });
});
//# sourceMappingURL=document-error.spec.js.map
