import { LayoutSettings } from "./layout-settings";
describe('layout-select-file', () => {
    it('builds', () => {
        expect(new LayoutSettings()).toBeTruthy();
    });
});
//# sourceMappingURL=layout-settings.spec.js.map
