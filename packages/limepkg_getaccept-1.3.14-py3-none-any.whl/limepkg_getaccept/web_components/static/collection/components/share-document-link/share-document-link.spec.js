import { ShareDocumentLink } from "./share-document-link";
describe('share-document-link', () => {
    it('builds', () => {
        expect(new ShareDocumentLink()).toBeTruthy();
    });
});
//# sourceMappingURL=share-document-link.spec.js.map
