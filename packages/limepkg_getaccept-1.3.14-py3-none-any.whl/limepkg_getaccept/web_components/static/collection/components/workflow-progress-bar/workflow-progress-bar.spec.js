import { WorkflowProgressBar } from "./workflow-progress-bar";
describe('document-list', () => {
    it('builds', () => {
        expect(new WorkflowProgressBar()).toBeTruthy();
    });
});
//# sourceMappingURL=workflow-progress-bar.spec.js.map
