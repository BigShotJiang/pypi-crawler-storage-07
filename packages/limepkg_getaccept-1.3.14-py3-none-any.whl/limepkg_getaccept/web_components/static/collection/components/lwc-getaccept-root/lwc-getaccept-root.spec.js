import { Root } from "./lwc-getaccept-root";
describe('lwc-getaccept-root', () => {
    it('builds', () => {
        expect(new Root()).toBeTruthy();
    });
});
//# sourceMappingURL=lwc-getaccept-root.spec.js.map
