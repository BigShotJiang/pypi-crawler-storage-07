import { DocumentErrorFeedback } from "../document-error-view/document-error-feedback";
describe('document-error-feedback', () => {
    it('builds', () => {
        expect(new DocumentErrorFeedback()).toBeTruthy();
    });
});
//# sourceMappingURL=document-validate-info.spec.js.map
