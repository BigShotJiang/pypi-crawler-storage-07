import { WorkflowProgressBar } from "../workflow-progress-bar/workflow-progress-bar";
describe('document-list', () => {
    it('builds', () => {
        expect(new WorkflowProgressBar()).toBeTruthy();
    });
});
//# sourceMappingURL=ga-signup.spec.js.map
