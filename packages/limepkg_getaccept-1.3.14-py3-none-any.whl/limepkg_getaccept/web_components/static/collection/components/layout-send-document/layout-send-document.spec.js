import { LayoutSendDocument } from "./layout-send-document";
describe('layout-send-document', () => {
    it('builds', () => {
        expect(new LayoutSendDocument()).toBeTruthy();
    });
});
//# sourceMappingURL=layout-send-document.spec.js.map
