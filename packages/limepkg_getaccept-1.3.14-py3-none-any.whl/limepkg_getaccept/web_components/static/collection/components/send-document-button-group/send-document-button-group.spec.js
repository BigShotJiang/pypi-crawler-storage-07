import { SendDocumentButtonGroup } from "./send-document-button-group";
describe('send-document-button-group', () => {
    it('builds', () => {
        expect(new SendDocumentButtonGroup()).toBeTruthy();
    });
});
//# sourceMappingURL=send-document-button-group.spec.js.map
