import { LayoutHelp } from "./layout-help";
describe('layout-help', () => {
    it('builds', () => {
        expect(new LayoutHelp()).toBeTruthy();
    });
});
//# sourceMappingURL=layout-help.spec.js.map
