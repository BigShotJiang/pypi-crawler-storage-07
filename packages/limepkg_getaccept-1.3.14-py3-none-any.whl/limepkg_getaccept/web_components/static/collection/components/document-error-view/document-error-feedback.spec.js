import { DocumentErrorFeedback } from "./document-error-feedback";
describe('document-error-feedback', () => {
    it('builds', () => {
        expect(new DocumentErrorFeedback()).toBeTruthy();
    });
});
//# sourceMappingURL=document-error-feedback.spec.js.map
