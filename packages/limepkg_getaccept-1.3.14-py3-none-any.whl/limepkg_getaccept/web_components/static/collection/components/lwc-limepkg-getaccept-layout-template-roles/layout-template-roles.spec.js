import { LayoutTemplateRoles } from "./layout-template-roles";
describe('lwc-limepkg-getaccept-layout-template-roles', () => {
    it('builds', () => {
        expect(new LayoutTemplateRoles()).toBeTruthy();
    });
});
//# sourceMappingURL=layout-template-roles.spec.js.map
