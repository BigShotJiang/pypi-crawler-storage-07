import { LayoutDocumentDetails } from "./layout-document-details";
describe('layout-document-details', () => {
    it('builds', () => {
        expect(new LayoutDocumentDetails()).toBeTruthy();
    });
});
//# sourceMappingURL=layout-document-details.spec.js.map
