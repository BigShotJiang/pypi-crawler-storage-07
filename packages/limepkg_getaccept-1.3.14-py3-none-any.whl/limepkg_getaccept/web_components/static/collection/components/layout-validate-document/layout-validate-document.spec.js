import { LayoutValidateDocument } from "./layout-validate-document";
describe('layout-validate-document', () => {
    it('builds', () => {
        expect(new LayoutValidateDocument()).toBeTruthy();
    });
});
//# sourceMappingURL=layout-validate-document.spec.js.map
