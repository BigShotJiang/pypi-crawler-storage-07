import { VideoThumb } from "./video-thumb";
describe('video-thumb', () => {
    it('builds', () => {
        expect(new VideoThumb()).toBeTruthy();
    });
});
//# sourceMappingURL=video-thumb.spec.js.map
