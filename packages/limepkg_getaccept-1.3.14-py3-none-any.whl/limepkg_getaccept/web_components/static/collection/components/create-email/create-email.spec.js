import { CreateEmail } from "./create-email";
describe('create-email', () => {
    it('builds', () => {
        expect(new CreateEmail()).toBeTruthy();
    });
});
//# sourceMappingURL=create-email.spec.js.map
