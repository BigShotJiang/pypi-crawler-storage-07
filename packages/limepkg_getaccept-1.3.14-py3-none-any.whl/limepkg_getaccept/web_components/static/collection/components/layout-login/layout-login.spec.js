import { LayoutLogin } from "./layout-login";
describe('layout-login', () => {
    it('builds', () => {
        expect(new LayoutLogin()).toBeTruthy();
    });
});
//# sourceMappingURL=layout-login.spec.js.map
