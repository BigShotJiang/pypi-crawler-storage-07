import { DocumentPageInfo } from "./document-page-info";
describe('document-page-info', () => {
    it('builds', () => {
        expect(new DocumentPageInfo()).toBeTruthy();
    });
});
//# sourceMappingURL=document-page-info.spec.js.map
