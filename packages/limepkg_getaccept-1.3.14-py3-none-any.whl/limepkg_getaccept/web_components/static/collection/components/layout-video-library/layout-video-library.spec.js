import { LayoutVideoLibrary } from "./layout-video-library";
describe('layout-video-library', () => {
    it('builds', () => {
        expect(new LayoutVideoLibrary()).toBeTruthy();
    });
});
//# sourceMappingURL=layout-video-library.spec.js.map
