"""video-to-ascii: Play videos in terminal using ASCII characters."""

__version__ = "1.3.1"