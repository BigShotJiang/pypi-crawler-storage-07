"""
Este setup.py se mantiene solo para compatibilidad hacia atrás.
El proyecto ahora usa pyproject.toml como configuración principal.
"""

from setuptools import setup

# La configuración real está en pyproject.toml
setup()
