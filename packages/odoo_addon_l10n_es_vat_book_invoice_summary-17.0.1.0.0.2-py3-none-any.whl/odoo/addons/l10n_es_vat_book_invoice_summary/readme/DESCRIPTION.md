Se rellenan las casillas de resumen de las facturas emitidas en el excel
de Libro de IVA
