uv --preview-features extra-build-dependencies sync
uv run test/test-flight-manager.py install
