from plain.urls import Router


class AppRouter(Router):
    namespace = ""
    urls = []
