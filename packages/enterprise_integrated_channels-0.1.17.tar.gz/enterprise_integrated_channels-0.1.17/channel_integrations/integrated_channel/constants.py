"""
Constants used by the integrated channels
"""

ISO_8601_DATE_FORMAT = '%Y-%m-%dT%H:%M:%S.%fZ'
TASK_LOCK_EXPIRY_SECONDS = 60 * 60 * 12
