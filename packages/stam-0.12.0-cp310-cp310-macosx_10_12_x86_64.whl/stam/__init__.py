from .stam import *

__doc__ = stam.__doc__
if hasattr(stam, "__all__"):
    __all__ = stam.__all__