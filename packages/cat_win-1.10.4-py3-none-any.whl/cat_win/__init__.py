"""Simple Text-Processing and -Analytics Command Line Tool made in Python."""

__project__ = 'cat_win'
__version__ = '1.10.4'
__sysversion__ = '3.13.7 (tags/v3.13.7:bcee1c3, Aug 14 2025, 14:15:11) [MSC v.1944 64 bit (AMD64)]'
__author__ = 'Silas A. Kraume'
__url__ = 'https://github.com/SilenZcience/cat_win'
