"""
edit
"""

def getxymax(*_, **__) -> tuple:
    return (30, 120)
