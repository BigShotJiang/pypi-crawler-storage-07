# from unittest.mock import patch
# from unittest import TestCase

# from cat_win.src.service.helper.winstreams import WinStreams
# # import sys
# # sys.path.append('../cat_win')


# class TestEditorHelper(TestCase):
#     maxDiff = None
