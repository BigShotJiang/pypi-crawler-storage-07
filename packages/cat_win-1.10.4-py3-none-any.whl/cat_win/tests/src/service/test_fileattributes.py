from unittest import TestCase
from unittest.mock import patch
import os

from cat_win.tests.mocks.std import StdOutMock
from cat_win.src.service.helper.environment import on_windows_os
from cat_win.src.service.fileattributes import _convert_size, get_file_meta_data, get_file_size, get_dir_size, get_file_mtime, get_file_ctime, print_meta, Signatures
# import sys
# sys.path.append('../cat_win')
res_dir = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'res')
signatures_path = os.path.abspath(os.path.join(res_dir, 'signatures.json'))
test_zip_file_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'resources')
test_zip_file_path  = os.path.abspath(os.path.join(test_zip_file_dir, 'test.zip'))
test_tar_file_path  = os.path.abspath(os.path.join(test_zip_file_dir, 'test.tar.gz'))


class TestSignatures(TestCase):
    def test_read_signature_failed(self):
        Signatures.set_res_path('')
        self.assertEqual(Signatures.read_signature(__file__), 'lookup failed: Signatures not loaded')
        Signatures.set_res_path(signatures_path)
        self.assertEqual(Signatures.read_signature(''), "lookup failed: [Errno 2] No such file or directory: ''")

    def test_read_signatures_empty(self):
        Signatures.set_res_path(signatures_path)
        self.assertEqual(Signatures.read_signature(__file__), '-')

    def test_read_signatures(self):
        Signatures.set_res_path(signatures_path)
        self.assertEqual(Signatures.read_signature(test_zip_file_path), 'application/x-zip-compressed(zip) [aar(aar)]')
        self.assertEqual(Signatures.read_signature(test_tar_file_path), 'application/x-gzip(gz) [application/gzip(tgz);tar.gz(tar.gz)]')


class TestFileAttributes(TestCase):
    def test__convert_size_zero(self):
        self.assertEqual(_convert_size(0), '0  B')

    def test__convert_size_edge_kb(self):
        self.assertEqual(_convert_size(1023), '1023.0  B')

    def test__convert_size_kb_exact(self):
        self.assertEqual(_convert_size(1024), '1.0 KB')

    def test__convert_size_kb(self):
        self.assertEqual(_convert_size(1836), '1.79 KB')

    def test__convert_size_round_kb(self):
        self.assertEqual(_convert_size(2044), '2.0 KB')

    def test__convert_size_tb(self):
        self.assertEqual(_convert_size(1024*1024*1024*1024), '1.0 TB')

    def test__convert_size_uneven_tb(self):
        self.assertEqual(_convert_size(1024*1024*1024*1024 * 2.3), '2.3 TB')

    def test__convert_size_yb(self):
        self.assertEqual(_convert_size(1024*1024*1024*1024*1024*1024*1024*1024), '1.0 YB')

    def test__convert_size_edge_yb(self):
        self.assertEqual(_convert_size(1024*1024*1024*1024*1024*1024*1024*1024 * 1023.99),
                         '1023.99 YB')

    def test__convert_size_out_of_range(self):
        self.assertEqual(_convert_size(1024*1024*1024*1024*1024*1024*1024*1024*1024), '1.0 ?')

    def test_get_file_meta_data(self):
        meta_data = get_file_meta_data(__file__, '')
        self.assertIn('Signature:', meta_data)
        self.assertIn('Size:', meta_data)
        self.assertIn('ATime:', meta_data)
        self.assertIn('MTime:', meta_data)
        self.assertIn('CTime:', meta_data)
        if '+' in meta_data:
            if on_windows_os:
                self.assertIn('Archive', meta_data)
                self.assertIn('System', meta_data)
                self.assertIn('Hidden', meta_data)
                self.assertIn('Readonly', meta_data)
                self.assertIn('Indexed', meta_data)
                self.assertIn('Compressed', meta_data)
                self.assertIn('Encrypted', meta_data)
                self.assertIn('-rw-rw-rw- (666)', meta_data)
                self.assertNotIn('rwx', meta_data)
            else:
                self.assertNotIn('Archive', meta_data)
                self.assertNotIn('System', meta_data)
                self.assertNotIn('Hidden', meta_data)
                self.assertNotIn('Readonly', meta_data)
                self.assertNotIn('Indexed', meta_data)
                self.assertNotIn('Compressed', meta_data)
                self.assertNotIn('Encrypted', meta_data)
                self.assertIn('rwx', meta_data)

        meta_data = get_file_meta_data(
            'randomFileThatHopefullyDoesNotExistWithWeirdCharsForSafety*!?\\/:<>|', '')
        self.assertEqual(meta_data, '')

    def test_get_file_size(self):
        self.assertGreater(get_file_size(__file__), 0)
        self.assertEqual(get_file_size(
            'randomFileThatHopefullyDoesNotExistWithWeirdCharsForSafety*!?\\/:<>|'), 0)

    def test_get_dir_size(self):
        self.assertGreater(get_dir_size(os.path.dirname(__file__)), 180000)
        self.assertEqual(get_dir_size(
            'randomFileThatHopefullyDoesNotExistWithWeirdCharsForSafety*!?\\/:<>|'), 0)

    def test_get_file_mtime(self):
        self.assertGreater(get_file_mtime(__file__), 1500000000)
        self.assertEqual(get_file_mtime(
            'randomFileThatHopefullyDoesNotExistWithWeirdCharsForSafety*!?\\/:<>|'), 0)

    def test_get_file_ctime(self):
        self.assertGreater(get_file_ctime(__file__), 1500000000)
        self.assertEqual(get_file_ctime(
            'randomFileThatHopefullyDoesNotExistWithWeirdCharsForSafety*!?\\/:<>|'), 0)

    def test_print_meta(self):
        with patch('sys.stdout', new=StdOutMock()) as fake_out:
            Signatures.set_res_path('')
            print_meta(__file__, ['A', 'B', 'C', 'D'])
            self.assertIn('Signature:', fake_out.getvalue())
            self.assertIn('Size:', fake_out.getvalue())
            self.assertIn('ATime:', fake_out.getvalue())
            self.assertIn('MTime:', fake_out.getvalue())
            self.assertIn('CTime:', fake_out.getvalue())
