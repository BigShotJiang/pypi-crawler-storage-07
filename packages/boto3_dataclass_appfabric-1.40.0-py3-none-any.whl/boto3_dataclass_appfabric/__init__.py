# -*- coding: utf-8 -*-

from .caster import appfabric_caster

caster = appfabric_caster

__version__ = "1.40.0"