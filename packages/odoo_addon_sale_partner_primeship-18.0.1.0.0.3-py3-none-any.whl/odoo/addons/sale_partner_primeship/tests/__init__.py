# Copyright 2024 Akretion - Olivier Nibart
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import test_res_partner_primeship
from . import test_sale_order_primeship
from . import test_sale_primeship
