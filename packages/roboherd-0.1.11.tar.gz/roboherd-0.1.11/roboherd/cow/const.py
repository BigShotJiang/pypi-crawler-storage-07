default_icon = {
    "mediaType": "image/png",
    "type": "Image",
    "url": "https://dev.bovine.social/assets/bull-horns.png",
}
"""The default icon to be used"""
