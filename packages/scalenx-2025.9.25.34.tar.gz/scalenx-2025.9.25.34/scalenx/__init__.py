"""ScaleNx image rescaling functions for Python >= 3.4.
-

for ScaleNx:

    `from scalenx import scalenx`

for ScaleNxSFX:

    `from scalenx import scalenxsfx`

"""
