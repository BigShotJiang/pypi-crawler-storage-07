"""Embedded palette and ezdxf helper utilities.

This module embeds an index-aligned color palette and provides small
utilities to apply colors to ezdxf layers and entities using True Color.

The palette is intended to be stable across the project, but its size can
vary if additional indices are needed. Always validate indices against the
current palette size using the provided helpers.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from ezdxf.colors import rgb2int
from ezdxf.entities.dxfgfx import DXFGraphic
from ezdxf.entities.layer import Layer

# Composed types used by this module.
PaletteColor = tuple[int, int, int]
Palette = list[PaletteColor]


class _DXFLike(Protocol):
    """Minimal DXF container with a True Color field."""

    true_color: int


@runtime_checkable
class SupportsTrueColor(Protocol):
    """Protocol for ezdxf-like objects that expose a ``dxf.true_color``.

    This is satisfied by ezdxf `Layer` and any `DXFGraphic` entity.
    """

    dxf: _DXFLike


# Index-aligned palette: PALETTE_256[i] == (R, G, B)
# This was manually extracted but MapSys lets the user change colors for each
# palette index, so it must be stored somewhere.
PALETTE_256: Palette = [
    (0, 0, 128),
    (0, 128, 0),
    (0, 128, 128),
    (128, 0, 0),
    (128, 0, 128),
    (255, 255, 0),
    (192, 192, 192),
    (128, 128, 128),
    (0, 0, 255),
    (0, 255, 0),
    (0, 255, 255),
    (255, 0, 0),
    (255, 0, 255),
    (128, 64, 0),
    (255, 255, 255),
    (0, 0, 128),
    (0, 9, 120),
    (0, 18, 111),
    (0, 26, 103),
    (0, 35, 94),
    (0, 43, 86),
    (0, 52, 77),
    (0, 60, 69),
    (0, 69, 60),
    (0, 77, 52),
    (0, 86, 43),
    (0, 94, 35),
    (0, 103, 26),
    (0, 111, 18),
    (0, 120, 9),
    (0, 128, 0),
    (0, 128, 0),
    (0, 128, 9),
    (0, 128, 18),
    (0, 128, 26),
    (0, 128, 35),
    (0, 128, 43),
    (0, 128, 52),
    (0, 128, 60),
    (0, 128, 69),
    (0, 128, 77),
    (0, 128, 86),
    (0, 128, 94),
    (0, 128, 103),
    (0, 128, 111),
    (0, 128, 120),
    (0, 128, 128),
    (0, 128, 128),
    (9, 120, 120),
    (18, 111, 111),
    (26, 103, 103),
    (35, 94, 94),
    (43, 86, 86),
    (52, 77, 77),
    (60, 69, 69),
    (69, 60, 60),
    (77, 52, 52),
    (86, 43, 43),
    (94, 35, 35),
    (103, 26, 26),
    (111, 18, 18),
    (120, 9, 9),
    (128, 0, 0),
    (128, 0, 0),
    (128, 0, 9),
    (128, 0, 18),
    (128, 0, 26),
    (128, 0, 35),
    (128, 0, 43),
    (128, 0, 52),
    (128, 0, 60),
    (128, 0, 69),
    (128, 0, 77),
    (128, 0, 86),
    (128, 0, 94),
    (128, 0, 103),
    (128, 0, 111),
    (128, 0, 120),
    (128, 0, 128),
    (128, 0, 128),
    (137, 17, 120),
    (145, 34, 111),
    (154, 51, 103),
    (162, 68, 94),
    (171, 85, 86),
    (179, 102, 77),
    (188, 119, 69),
    (196, 136, 60),
    (205, 153, 52),
    (213, 170, 43),
    (222, 187, 35),
    (230, 204, 26),
    (239, 221, 18),
    (247, 238, 9),
    (255, 255, 0),
    (255, 255, 0),
    (251, 251, 13),
    (247, 247, 26),
    (243, 243, 39),
    (239, 239, 52),
    (234, 234, 64),
    (230, 230, 77),
    (226, 226, 90),
    (222, 222, 103),
    (218, 218, 116),
    (213, 213, 128),
    (209, 209, 141),
    (205, 205, 154),
    (201, 201, 167),
    (197, 197, 180),
    (192, 192, 192),
    (192, 192, 192),
    (188, 188, 188),
    (184, 184, 184),
    (180, 180, 180),
    (175, 175, 175),
    (171, 171, 171),
    (167, 167, 167),
    (163, 163, 163),
    (158, 158, 158),
    (154, 154, 154),
    (150, 150, 150),
    (146, 146, 146),
    (141, 141, 141),
    (137, 137, 137),
    (133, 133, 133),
    (128, 128, 128),
    (128, 128, 128),
    (120, 120, 137),
    (111, 111, 145),
    (103, 103, 154),
    (94, 94, 162),
    (86, 86, 171),
    (77, 77, 179),
    (69, 69, 188),
    (60, 60, 196),
    (52, 52, 205),
    (43, 43, 213),
    (35, 35, 222),
    (26, 26, 230),
    (18, 18, 239),
    (9, 9, 247),
    (0, 0, 255),
    (0, 0, 255),
    (0, 17, 238),
    (0, 34, 221),
    (0, 51, 204),
    (0, 68, 187),
    (0, 85, 170),
    (0, 102, 153),
    (0, 119, 136),
    (0, 136, 119),
    (0, 153, 102),
    (0, 170, 85),
    (0, 187, 68),
    (0, 204, 51),
    (0, 221, 34),
    (0, 238, 17),
    (0, 255, 0),
    (0, 255, 0),
    (0, 255, 17),
    (0, 255, 34),
    (0, 255, 51),
    (0, 255, 68),
    (0, 255, 85),
    (0, 255, 102),
    (0, 255, 119),
    (0, 255, 136),
    (0, 255, 153),
    (0, 255, 170),
    (0, 255, 187),
    (0, 255, 204),
    (0, 255, 221),
    (0, 255, 238),
    (0, 255, 255),
    (0, 255, 255),
    (17, 238, 238),
    (34, 221, 221),
    (51, 204, 204),
    (68, 187, 187),
    (85, 170, 170),
    (102, 153, 153),
    (119, 136, 136),
    (136, 119, 119),
    (153, 102, 102),
    (170, 85, 85),
    (187, 68, 68),
    (204, 51, 51),
    (221, 34, 34),
    (238, 17, 17),
    (255, 0, 0),
    (255, 0, 0),
    (255, 0, 17),
    (255, 0, 34),
    (255, 0, 51),
    (255, 0, 68),
    (255, 0, 85),
    (255, 0, 102),
    (255, 0, 119),
    (255, 0, 136),
    (255, 0, 153),
    (255, 0, 170),
    (255, 0, 187),
    (255, 0, 204),
    (255, 0, 221),
    (255, 0, 238),
    (255, 0, 255),
    (255, 0, 255),
    (247, 5, 238),
    (239, 9, 221),
    (230, 13, 204),
    (222, 18, 187),
    (213, 22, 170),
    (205, 26, 153),
    (196, 30, 136),
    (188, 35, 119),
    (179, 39, 102),
    (171, 43, 85),
    (162, 47, 68),
    (154, 52, 51),
    (145, 56, 34),
    (137, 60, 17),
    (128, 64, 0),
    (128, 64, 0),
    (137, 77, 17),
    (145, 90, 34),
    (154, 103, 51),
    (162, 115, 68),
    (171, 128, 85),
    (179, 141, 102),
    (188, 154, 119),
    (196, 166, 136),
    (205, 179, 153),
    (213, 192, 170),
    (222, 205, 187),
    (230, 217, 204),
    (239, 230, 221),
    (247, 243, 238),
    (255, 255, 255),
    (255, 255, 255),
    (238, 238, 247),
    (221, 221, 239),
    (204, 204, 230),
    (187, 187, 222),
    (170, 170, 213),
    (153, 153, 205),
    (136, 136, 196),
    (119, 119, 188),
    (102, 102, 179),
    (85, 85, 171),
    (68, 68, 162),
    (51, 51, 154),
    (34, 34, 145),
    (17, 17, 137),
    (0, 0, 128),
    (0, 0, 0),
]


def get_palette_rgb(index: int) -> PaletteColor:
    """Return the palette color for a palette index.

    Args:
        index: The palette index to resolve.

    Returns:
        The color as a 3-tuple ``(R, G, B)``.

    Throws:
        ValueError: If ``index`` is outside ``0..len(PALETTE_256)-1``.
    """
    if not (0 <= index < len(PALETTE_256)):
        raise ValueError(f"Index must be in 0..255, got {index}")
    return PALETTE_256[index]


def set_layer_color_from_index(
    layer: Layer | SupportsTrueColor, index: int
) -> PaletteColor:
    """Set the ezdxf layer's True Color from a palette index.

    Args:
        layer: The ezdxf layer to modify (or any object exposing
            ``dxf.true_color``).
        index: The palette index to look up.

    Returns:
        The applied color as ``(R, G, B)``.

    Throws:
        ValueError: If ``index`` is invalid for the current palette.
    """
    r, g, b = get_palette_rgb(index)
    layer.dxf.true_color = rgb2int((r, g, b))
    return (r, g, b)


def set_entity_color_from_index(
    entity: DXFGraphic | SupportsTrueColor, index: int
) -> PaletteColor:
    """Set the ezdxf entity's True Color from a palette index.

    Args:
        entity: The ezdxf entity to modify (or any object exposing
            ``dxf.true_color``).
        index: The palette index to look up.

    Returns:
        The applied color as ``(R, G, B)``.

    Throws:
        ValueError: If ``index`` is invalid for the current palette.
    """
    r, g, b = get_palette_rgb(index)
    entity.dxf.true_color = rgb2int((r, g, b))
    return (r, g, b)
