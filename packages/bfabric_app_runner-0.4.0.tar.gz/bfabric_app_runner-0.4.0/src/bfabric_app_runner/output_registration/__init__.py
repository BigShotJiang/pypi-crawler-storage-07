from .register import register_outputs

__all__ = ["register_outputs"]
