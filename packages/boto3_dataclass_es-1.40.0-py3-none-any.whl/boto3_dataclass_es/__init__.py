# -*- coding: utf-8 -*-

from .caster import es_caster

caster = es_caster

__version__ = "1.40.0"