# Baudream

## Installation

### Pre-requisites
Python 3.9+
```bash

```bash
pip install baudream
