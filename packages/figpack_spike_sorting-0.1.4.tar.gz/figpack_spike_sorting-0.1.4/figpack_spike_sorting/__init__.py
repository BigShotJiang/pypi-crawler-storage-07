"""
figpack_spike_sorting - Spike Sorting specific extension for figpack
"""

__version__ = "0.1.4"
