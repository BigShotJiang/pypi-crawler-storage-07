::: rumchat_actor.static
