# CLI tool

::: mkdocs-click
    :module: almabtrieb.__main__
    :command: main
    :prog_name: python -malmabtrieb
    :depth: 1