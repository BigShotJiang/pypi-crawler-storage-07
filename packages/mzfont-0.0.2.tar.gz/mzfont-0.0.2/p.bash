#!/bin/bash

#        
#
#       


walk() {
  clear
  echo ""
  echo ""
  echo ""
  echo ""
  echo ""
  echo ""
  echo " "
  echo " "
  echo ""
  sleep 0.3
 
  clear
  echo ""
  echo ""
  echo ""
  echo ""
  echo ""
  echo ""
  echo ""
  echo ""
  echo ""
  sleep 0.3
}

while true; do
  walk
done
