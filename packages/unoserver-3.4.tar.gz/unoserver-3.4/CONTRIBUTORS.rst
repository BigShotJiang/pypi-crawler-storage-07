Contributors
------------

* Lennart Regebro, regebro@gmail.com
* Stephan Richter, srichter@shoobx.com
* Bruno Simão, https://github.com/ankology
* Åsmund Stavdahl, https://github.com/asmundstavdahl
* Balázs Varga, https://github.com/bvarga91
* Alessandro Filippini, https://github.com/AlePini
* Dmitry Shachnev, https://github.com/mitya57
* Socheat Sok, https://github.com/socheatsok78
* BohwaZ, https://github.com/bohwaz
* ReeceJones, https://github.com/ReeceJones
* Grunthos, https://github.com/Grunthos
* Witiko, https://github.com/Witiko
* Prpl, https://github.com/prpladmin
