"""Slack Lists MCP Server Package."""

from slack_lists_mcp.__main__ import main
from slack_lists_mcp.server import mcp

__version__ = "0.1.0"
__all__ = ["main", "mcp"]
