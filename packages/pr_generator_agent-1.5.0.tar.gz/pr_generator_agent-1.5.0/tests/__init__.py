"""
Test suite for AIPR
"""
