#Estableciendo un versionado en el programa
__version__="0.1.0"


#Debemos tener el archivo calculadora.py para que funcione
from .calculadora import *
