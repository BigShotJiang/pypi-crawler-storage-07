# JuanAcunaCalc

Una magnífica calculadora científica desarrrollada con los más grandes estándares de la industria del cálculo científico.

## Instalación

Aquí se documenta como se hace la instalación

''' bash

pip install JuanAcunaCalc