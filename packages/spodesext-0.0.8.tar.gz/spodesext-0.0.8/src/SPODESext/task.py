from dataclasses import dataclass
from typing import Final
from DLMS_SPODES.pardata import ParValues
from StructResult import result
from DLMS_SPODES.types import cdt, cst
from DLMS_SPODES.cosem_interface_classes import disconnect_control
from DLMS_SPODES.cosem_interface_classes import parameters as dlms_par
from DLMS_SPODES.cosem_interface_classes.parameter import Parameter
from DLMS_SPODES.types.implementations import integers
from DLMS_SPODES_client.client import Client
from DLMS_SPODES_client import task
from DLMS_SPODES import exceptions as exc
from . import parameters as spodes_par


@dataclass
class SetSerialNumber(task.SimpleCopy, task.OK):
    data: str
    msg = "Запись серийного номера"

    async def exchange(self, c: Client) -> result.Ok | result.Error:
        return await task.WriteTranscript(
            par=spodes_par.SERIAL_NUMBER.value,
            value=self.data,
        ).exchange(c)


@dataclass
class CloseSeal(task.SimpleCopy, task.OK):
    msg: str = "Обжать электронные пломбы"

    async def exchange(self, c: Client) -> result.Ok | result.Error:
        return await task.WriteTranscript(spodes_par.CLOSE_ELECTRIC_SEAL.value, "1", msg=self.msg).exchange(c)


@dataclass
class ChangeDisconnectControlState(task.SimpleCopy, task.OK):
    state: int
    b: int = 0
    msg: str = "Смена состояния DisconnectControl"

    def __post_init__(self) -> None:
        if not (0 <= self.state <= 2):
            raise ValueError(F"got wrong {self.state=}, expect 0..2")

    async def exchange(self, c: Client) -> result.Ok | result.Error:
        """return output and control state"""
        par = dlms_par.DisconnectControl.from_b(self.b)
        if isinstance(res_obj := c.objects.par2obj(par), result.Error):
            return res_obj
        if not isinstance(res_obj.value, disconnect_control.DisconnectControl):
            return result.Error.from_e(TypeError(f"got {res_obj.value}, expected {disconnect_control.DisconnectControl}"))
        if isinstance(res := await task.Sequence[disconnect_control.ControlState, disconnect_control.ControlMode](
            task.Par2Data(par.control_state),
            task.Par2Data(par.control_mode),
        ).exchange(c), result.Error):
            return res
        state, mode = res.value
        transitions: str = mode.get_letters(int(res_obj.value.control_mode))
        match int(state), self.state:
            case 0, 1 if ("a" in transitions):
                if isinstance(res2 := await task.Execute2(par.remote_reconnect, integers.INTEGER_0).exchange(c), result.Error):
                    return res2
            case 0, 2 if "d" in transitions:
                if isinstance(res2 := await task.Execute2(par.remote_reconnect, integers.INTEGER_0).exchange(c), result.Error):
                    return res2
            case 1, 0 if "b" in transitions:
                if isinstance(res2 := await task.Execute2(par.remote_disconnect, integers.INTEGER_0).exchange(c), result.Error):
                    return res2
            case 2, 0 if "c" in transitions:
                if isinstance(res2 := await task.Execute2(par.remote_disconnect, integers.INTEGER_0).exchange(c), result.Error):
                    return res2
            case 2, 1 if "c" in transitions and "a" in transitions:
                if isinstance(res3 := await task.List(
                    task.Execute2(par.remote_disconnect, integers.INTEGER_0),
                    task.Execute2(par.remote_reconnect, integers.INTEGER_0),
                ).exchange(c), result.Error):
                    return res3
            case 1, 2 if "b" in transitions and "d" in transitions:
                if isinstance(res3 := await task.List(
                    task.Execute2(par.remote_disconnect, integers.INTEGER_0),
                    task.Execute2(par.remote_reconnect, integers.INTEGER_0),
                ).exchange(c), result.Error):
                    return res3
            case a, b if a == b:
                return result.Error.from_e(exc.DLMSException("уже имеется <{disconnect_control.ControlState(self.state)}>"))
            case _:
                return result.Error.from_e(exc.DLMSException(F"переключение на <{disconnect_control.ControlState(self.state)}> невозможно из текущего <{state}>"))
        return result.OK
