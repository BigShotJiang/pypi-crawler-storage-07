"""Dygest package initialization."""

import os

os.environ.setdefault("DISABLE_AIOHTTP_TRANSPORT", "True")
