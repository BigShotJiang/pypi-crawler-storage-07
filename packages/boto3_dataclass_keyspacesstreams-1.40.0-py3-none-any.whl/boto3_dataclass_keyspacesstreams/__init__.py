# -*- coding: utf-8 -*-

from .caster import keyspacesstreams_caster

caster = keyspacesstreams_caster

__version__ = "1.40.0"