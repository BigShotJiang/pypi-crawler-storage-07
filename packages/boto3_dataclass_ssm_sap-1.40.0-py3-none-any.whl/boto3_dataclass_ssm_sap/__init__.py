# -*- coding: utf-8 -*-

from .caster import ssm_sap_caster

caster = ssm_sap_caster

__version__ = "1.40.0"