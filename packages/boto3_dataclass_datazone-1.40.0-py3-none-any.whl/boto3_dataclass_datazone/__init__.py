# -*- coding: utf-8 -*-

from .caster import datazone_caster

caster = datazone_caster

__version__ = "1.40.0"