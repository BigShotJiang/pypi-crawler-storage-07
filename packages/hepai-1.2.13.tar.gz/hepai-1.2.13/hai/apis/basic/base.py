# from damei.nn.uaii.stream.base_module import AbstractModule
# from damei.nn.uaii.stream.base_input import AbstractInput
# from damei.nn.uaii.stream.base_output import AbstractOutput
# from damei.nn.uaii.stream.base_queue import AbstractQue

from hai.uaii.stream.base_module import AbstractModule
from hai.uaii.stream.base_input import AbstractInput
from hai.uaii.stream.base_output import AbstractOutput
from hai.uaii.stream.base_queue import AbstractQue

