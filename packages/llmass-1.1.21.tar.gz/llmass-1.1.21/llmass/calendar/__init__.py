"""Calendar integration for automatic appointment scheduling."""

from llmass.calendar.client import CalendarClient
from llmass.calendar.detector import detect_meeting_request, extract_meeting_preferences
from llmass.calendar.slots import find_available_slots, format_slot_proposal, parse_slot_selection
from llmass.calendar.booking import BookingManager

__all__ = [
    'CalendarClient',
    'detect_meeting_request',
    'extract_meeting_preferences',
    'find_available_slots',
    'format_slot_proposal',
    'parse_slot_selection',
    'BookingManager',
]
