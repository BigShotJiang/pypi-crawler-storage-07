#!/usr/bin/env python3
"""Test language detection for email responses."""

from llmass.responder.conversation import detect_language


def test_detect_language():
    """Test language detection with various emails."""
    
    test_cases = [
        # Polish
        ("Dziękuję za wiadomość. Pozdrawiam.", "pl"),
        ("Witam, proszę o informacje", "pl"),
        
        # German
        ("Vielen Dank für Ihre Nachricht. Beste Grüße.", "de"),
        ("Guten Tag, bitte senden Sie mir die Informationen", "de"),
        ("Ihr Anzeigenauftrag wurde bearbeitet", "de"),
        
        # English
        ("Thank you for your message. Best regards.", "en"),
        ("Hello, please send me the information", "en"),
        ("LIVE NOW: Premium User Auction", "en"),
        
        # French
        ("Merci beaucoup pour votre message. Cordialement.", "fr"),
        ("Bonjour Madame, je vous remercie", "fr"),
        
        # Spanish
        ("Muchas gracias por su mensaje. Saludos.", "es"),
        ("Hola, buenos días", "es"),
    ]
    
    print("🧪 Testing language detection:\n")
    
    passed = 0
    failed = 0
    
    for text, expected_lang in test_cases:
        detected_lang = detect_language(text)
        status = "✅" if detected_lang == expected_lang else "❌"
        
        if detected_lang == expected_lang:
            passed += 1
        else:
            failed += 1
        
        print(f"{status} '{text[:50]}...' -> Detected: {detected_lang}, Expected: {expected_lang}")
    
    print(f"\n📊 Results: {passed} passed, {failed} failed")
    return failed == 0


if __name__ == "__main__":
    success = test_detect_language()
    exit(0 if success else 1)
