# -*- coding: utf-8 -*-

from .caster import groundstation_caster

caster = groundstation_caster

__version__ = "1.40.0"