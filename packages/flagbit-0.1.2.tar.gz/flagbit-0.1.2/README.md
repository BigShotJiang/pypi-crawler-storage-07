
<div class="title-block" style="text-align: center;" align="center">


<p><img title="flagbit logo" src="static/logo.png" width="500" height="300"></p>

[![Test](https://github.com/iplitharas/flagbit/actions/workflows/test.yaml/badge.svg)](https://github.com/iplitharas/flagbit/actions/workflows/test.yaml)
![PyPI](https://img.shields.io/pypi/v/flagbit)
<br/>
![GitHub License](https://img.shields.io/github/license/iplitharas/flagbit)
![PyPI - Downloads](https://img.shields.io/pypi/dm/flagbit)
<br/>
[![pre-commit](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit&logoColor=white)](https://github.com/pre-commit/pre-commit)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)
[![Code Style](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)
[![Checked with mypy](https://www.mypy-lang.org/static/mypy_badge.svg)](https://mypy-lang.org/)

**[Homepage] &nbsp;&nbsp;&bull;&nbsp;&nbsp;**
**[Installation] &nbsp;&nbsp;&bull;&nbsp;&nbsp;**
**[Getting Started] &nbsp;&nbsp;&bull;&nbsp;&nbsp;**

[Homepage]: https://iplitharas.github.io/flagbit/
[Installation]: https://iplitharas.github.io/flagbit/install-and-setup
[Getting Started]:https://iplitharas.github.io/flagbit/tutorial
</div>

## Table of Contents

