from typing import Literal

EXP_UNIT_T = Literal["m", "h", "d", "w"]
