# Django management package
